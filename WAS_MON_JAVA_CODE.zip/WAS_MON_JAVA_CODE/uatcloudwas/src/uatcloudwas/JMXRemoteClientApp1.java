package uatcloudwas;

import java.io.File;
import java.io.IOException;
import java.io.StringBufferInputStream;
import java.net.MalformedURLException;
import java.util.Date;
import java.util.Set;
import java.util.Hashtable;

import javax.management.MBeanAttributeInfo;
import javax.management.MBeanInfo;
import javax.management.Notification;
import javax.management.NotificationListener;
import javax.management.ObjectName;
import javax.management.MBeanServerConnection;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;
import javax.naming.Context;

import org.osgi.framework.BundleContext;

public class JMXRemoteClientApp1  {

   private static MBeanServerConnection mbsc = null;
   
   
   private static final String COM_IBM_WEBSPHERE_NAMING_NAME_SYNTAX = "com.ibm.websphere.naming.name.syntax";
	//private static final String WEBSPHERE_PROTOCOL_PROVIDER_PACKAGES = "com.ibm.ws.naming";
	private static final String WEBSPHERE_PROTOCOL_PROVIDER_PACKAGES = "com.ibm.websphere.management.remote";
	private static final String WEBSPHERE_INITIAL_CONTEXT_FACTORY = "com.ibm.websphere.naming.WsnInitialContextFactory";
	private static final String WAS_JMX_SERVICE_URL_PREFIX = "service:jmx:iiops://";
	private static final String WAS_JMX_SERVICE_URL_SUFFIX = "/jndi/JMXConnector";
	private static BundleContext context = null ;
	static String host="vm-89f0-4cb1";
    static String port="20002";
    
    

   public static void main(String[] args)
   {
	   	System.setProperty("com.ibm.CORBA.ConfigURL", "file:I:/rtview_6.2.1/rtview_6.2.1.0/WAS_DS/SASSecure/sas.client.props");
		System.setProperty("com.ibm.SSL.ConfigURL", "file:I:/rtview_6.2.1/rtview_6.2.1.0/WAS_DS/SASSecure/ssl.client.props");
		System.setProperty("javax.net.ssl.trustStore", "file:I:/rtview_6.2.1/rtview_6.2.1.0/WAS_DS/SASSecure/newstore.p12"); 
		System.setProperty("javax.net.ssl.keyStore", "file:I:/rtview_6.2.1/rtview_6.2.1.0/WAS_DS/SASSecure/newstore.p12"); 
		System.setProperty("javax.net.ssl.trustStorePassword", "password"); 
		System.setProperty("javax.net.ssl.keyStorePassword", "password"); 
		System.setProperty("com.ibm.ssl.trustStoreType", "PKCS12");
	   
      try {

         JMXRemoteClientApp1 client = new JMXRemoteClientApp1();

         client.connect(host,port);

         client.getNodeAgentMBean();
         
         
      } catch (Exception e) {
         e.printStackTrace();
      }
      
   }

   private void connect(String host,String port) throws Exception
   {
      

      JMXServiceURL url = null;
        
      try {
			url = new JMXServiceURL(WAS_JMX_SERVICE_URL_PREFIX + host+":"+port + WAS_JMX_SERVICE_URL_SUFFIX);
    	  
		} catch (MalformedURLException e1) {
			e1.printStackTrace();
			System.out.println("Failed ==> Malformed Url = "+url);
			return;
		}

      
      	Hashtable<String, Object>   parameters = new Hashtable<String, Object>  ();
		String[] credentials = new String[] {"RTViewUser" , "nemesis$" }; 
		parameters.put("jmx.remote.credentials", credentials);
		parameters.put(Context.INITIAL_CONTEXT_FACTORY, WEBSPHERE_INITIAL_CONTEXT_FACTORY);
		parameters.put(javax.management.remote.JMXConnectorFactory.PROTOCOL_PROVIDER_PACKAGES,
				WEBSPHERE_PROTOCOL_PROVIDER_PACKAGES);

		String providerUrl = "corbaloc:iiop:" + host+"_"+port + "/WsnAdminNameService";
		parameters.put(Context.PROVIDER_URL, providerUrl);
		parameters.put("osgi.service.jndi.bundleContext", Context.INITIAL_CONTEXT_FACTORY);
		parameters.put(COM_IBM_WEBSPHERE_NAMING_NAME_SYNTAX, "ins");

		JMXConnector conn = JMXConnectorFactory.connect(url, parameters);
      
	      try{
	    	  
				conn = JMXConnectorFactory.connect(url, parameters); 
				mbsc = conn.getMBeanServerConnection();
				System.out.println("Connected to DeploymentManager");
				
			}
			catch(Exception e){
				
				System.out.println("Failed ==> Not connected = "+url);
			}

      

      
   }


   private void getNodeAgentMBean()
   {

		String types[]={ "JVM" ,"Server","ThreadPool","JDBCProvider","Application", "SessionManager"};
		
		
		String mbeanType=null;
		try {
			
			for( String type : types){
				StringBuffer buffer=null;
				mbeanType=type;
				System.out.println("=====================================================================");
				System.out.println("Processing "+host+"_"+port+" MBEAN TYPE "+mbeanType);
				System.out.println("=====================================================================");
				String query = "WebSphere:type="+mbeanType+",*";
				ObjectName queryName = new ObjectName(query);
				Set s = mbsc.queryNames(queryName, null);
				if (!s.isEmpty()) {
					Object nodeAgent = (ObjectName)s.iterator().next();
					//System.out.println("Success ==> Url = "+jmxurl+" Mbean Type = "+type+" Mbean value = "+ nodeAgent.toString());
					ObjectName pattern=new ObjectName(query);
					//final JVMMBeanDataDisplay display = new JVMMBeanDataDisplay(mbsconn);
					for (ObjectName mbean : mbsc.queryNames(pattern,null)) {
						//============================
						//===============================
						

				        final MBeanInfo info = mbsc.getMBeanInfo(queryName);
				        
				        Hashtable<String, String> s1 = mbean.getKeyPropertyList();
				      
				       
				        
				        buffer.append("\n");
				        buffer.append("TYPE ==> "+mbean.getKeyProperty("type"));
				        
				        buffer.append("\n");
				        buffer.append("WAS_NODE_NAME ==> "+mbean.getKeyProperty("node"));
				       
				        buffer.append("\n");
				        buffer.append("PROCESS ==> "+mbean.getKeyProperty("process"));
				       
				        buffer.append("\n");
				        buffer.append("CELL ==> "+mbean.getKeyProperty("cell"));
				        
				        buffer.append("\n");
				        buffer.append("MBEAN_IDENTIFIER ==> "+mbean.getKeyProperty("mbeanIdentifier"));
				        
				        buffer.append("\n");
				        buffer.append("PLATFORM ==> "+mbean.getKeyProperty("platform"));
				        
				        buffer.append("\n");
				        buffer.append("VERSION ==> "+mbean.getKeyProperty("version"));
				       
				        buffer.append("\n");
				       
				        StringBuffer attributelist = new StringBuffer();
				       if( s!=null){
				        	final MBeanAttributeInfo[] attributes = info.getAttributes();
				        	
				    		for (MBeanAttributeInfo attr : attributes) {
				          	     Object toWrite = null;
				          	     
				          	      try {
				          	    	  	toWrite = mbsc.getAttribute(mbean,attr.getName());
				          	    		  if(!attr.getName().equalsIgnoreCase("stats") && !attr.getName().equalsIgnoreCase("deploymentDescriptor") && !attr.getName().equalsIgnoreCase("serverVersion")){
				          	    			  	buffer.append(attr.getName().toUpperCase()+" ==> "+toWrite);
				          	    			  	buffer.append("\n");
				          	    			  attributelist.append(attr.getName().toUpperCase()+" ==> "+toWrite);
				          	    			  attributelist.append("\n");	
				          	    		  }
				          	    	  }catch (Exception x) {
				                          toWrite = x;
				                      }   
				          	      
				          	    
				              }  
				       }
				    
				    
				    		          
				    		          //======================================
				    		          //==========================
					}
				} else {
					System.out.println("Failed ==> Connection  "+host+"_"+port+" Mbean Type  "+mbeanType+" was not found");
				}
				System.out.println("=====================================================================");
				System.out.println("Completed "+host+"_"+port+" MBEAN TYPE "+mbeanType);
				System.out.println("=====================================================================");					
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Failed ==> while fetching data from mbean for connection "+host+"_"+port);
		}
		

	}
   
  
   
   
}
