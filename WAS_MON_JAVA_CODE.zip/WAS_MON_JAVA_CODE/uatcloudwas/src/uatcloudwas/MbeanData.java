package uatcloudwas;

public class MbeanData {
	
	private String WAS_CONN_NAME;
	
	public String getWAS_CONN_NAME() {
		return WAS_CONN_NAME;
	}

	public void setWAS_CONN_NAME(String wAS_CONN_NAME) {
		WAS_CONN_NAME = wAS_CONN_NAME;
	}

	public String getTYPE() {
		return TYPE;
	}

	public void setTYPE(String tYPE) {
		TYPE = tYPE;
	}

	public String getWAS_NODE_NAME() {
		return WAS_NODE_NAME;
	}

	public void setWAS_NODE_NAME(String wAS_NODE_NAME) {
		WAS_NODE_NAME = wAS_NODE_NAME;
	}

	public String getPROCESS() {
		return PROCESS;
	}

	public void setPROCESS(String pROCESS) {
		PROCESS = pROCESS;
	}

	public String getCELL() {
		return CELL;
	}

	public void setCELL(String cELL) {
		CELL = cELL;
	}

	public String getMBEAN_IDENTIFIER() {
		return MBEAN_IDENTIFIER;
	}

	public void setMBEAN_IDENTIFIER(String mBEAN_IDENTIFIER) {
		MBEAN_IDENTIFIER = mBEAN_IDENTIFIER;
	}

	public String getPLATFORM() {
		return PLATFORM;
	}

	public void setPLATFORM(String pLATFORM) {
		PLATFORM = pLATFORM;
	}

	public String getVERSION() {
		return VERSION;
	}

	public void setVERSION(String vERSION) {
		VERSION = vERSION;
	}

	private String TYPE ;
    
	private String WAS_NODE_NAME ;
    
	private String PROCESS ;
    
	private String CELL ;
    
	private String MBEAN_IDENTIFIER ;
    
	private String PLATFORM ;
    
	private String VERSION ;
	
	private String BEAN_ATTRIBUTES;

	public String getBEAN_ATTRIBUTES() {
		return BEAN_ATTRIBUTES;
	}

	public void setBEAN_ATTRIBUTES(String bEAN_ATTRIBUTES) {
		BEAN_ATTRIBUTES = bEAN_ATTRIBUTES;
	}
    

}
