package uatcloudwas;

import java.io.IOException;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Set;
import java.util.logging.Logger;

import javax.management.JMException;
import javax.management.MBeanAttributeInfo;
import javax.management.MBeanInfo;
import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import javax.management.remote.JMXServiceURL;


public class MBeanDataDisplay {
    

    private static final Logger LOG =
            Logger.getLogger(MBeanDataDisplay.class.getName());
    
    final MBeanServerConnection server;
    final TextDataDisplay dataDisplay = new TextDataDisplay();
    
    public MBeanDataDisplay(MBeanServerConnection conn) {
        this.server = conn;
    }
    
    StringBuffer writeAttribute(StringBuffer buffer, 
            String prefix, ObjectName mbean,
            MBeanAttributeInfo info, Object value) {
            return dataDisplay.write(buffer,prefix,info.getName(),value);
    }
    
    public StringBuffer write(StringBuffer buffer, String prefix, ObjectName mbean, JMXServiceURL jmxurl) throws IOException, JMException {
        final MBeanInfo info = server.getMBeanInfo(mbean);
        
        Hashtable<String, String> s = mbean.getKeyPropertyList();
        MbeanData rtviewObj=new MbeanData();
        buffer.append("WAS_CONN_NAME ==> "+jmxurl.getHost()+"_"+jmxurl.getPort());
       
        buffer.append("\n");
        buffer.append("TYPE ==> "+mbean.getKeyProperty("type"));
        
        buffer.append("\n");
        buffer.append("WAS_NODE_NAME ==> "+mbean.getKeyProperty("node"));
        
        buffer.append("\n");
        buffer.append("PROCESS ==> "+mbean.getKeyProperty("process"));
       
        buffer.append("\n");
        buffer.append("CELL ==> "+mbean.getKeyProperty("cell"));
        
        buffer.append("\n");
        buffer.append("MBEAN_IDENTIFIER ==> "+mbean.getKeyProperty("mbeanIdentifier"));
        
        buffer.append("\n");
        buffer.append("PLATFORM ==> "+mbean.getKeyProperty("platform"));
        
        buffer.append("\n");
        buffer.append("VERSION ==> "+mbean.getKeyProperty("version"));
        
        buffer.append("\n");
       
        StringBuffer attributelist = new StringBuffer();
       if( s!=null){
        	final MBeanAttributeInfo[] attributes = info.getAttributes();
        	
    		for (MBeanAttributeInfo attr : attributes) {
          	     Object toWrite = null;
          	     
          	      try {
          	    	  	toWrite = server.getAttribute(mbean,attr.getName());
          	    		  if(toWrite instanceof String[] ){
          	    			  	buffer.append(attr.getName().toUpperCase()+" ==> "+Arrays.toString((String[])toWrite));
          	    			  	buffer.append("\n");
          	    			 
          	    		  }
          	    		  else{
          	    			buffer.append(attr.getName().toUpperCase()+" ==> "+toWrite.toString());
      	    			  	buffer.append("\n");
          	    			  
          	    		  }
          	    	  }catch (Exception x) {
                          toWrite = x;
                      }   
          	      
          	    
              }  
       }
  
		
		
    		          return buffer;
    }
    
    public String toString(String prefix, ObjectName mbean, JMXServiceURL jmxurl) 
        throws IOException, JMException {
        return write(new StringBuffer(),prefix,mbean, jmxurl).toString();
    }
    
    public String toString(ObjectName mbean,JMXServiceURL jmxurl) 
        throws IOException, JMException {
        return toString("",mbean, jmxurl);
    }
}
