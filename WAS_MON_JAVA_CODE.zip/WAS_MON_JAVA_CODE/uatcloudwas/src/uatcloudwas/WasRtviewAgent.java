package uatcloudwas;



import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;



import com.sl.gmsjagent.RtvAgent;
import com.sl.gmsjrt.GmsTabularData;

public class WasRtviewAgent {
	
	//protected static final Logger logger = Logger.getLogger(WasRtviewAgent.class);

	private static RtvAgent rtvAgent;
	
	private static String agentClass = "WAS Metric Collector";

	private static GmsTabularData WasMetricTable = null;
	
	private static WasRtviewAgent WasRtViewAgent = null;
	
	private static int row = 0;
	


	public static synchronized int getRow() {
		return row;
	}


	public static synchronized void setRow(int row) {
		WasRtviewAgent.row = row;
	}


	private WasRtviewAgent() {
		creteAgent();
		createTable();
	}
	
	
	public static synchronized WasRtviewAgent getInstance() {
		if(WasRtViewAgent == null) {
			WasRtViewAgent = new WasRtviewAgent();
		}
		
		return WasRtViewAgent;
	}
	

	private static void creteAgent() {
		if (rtvAgent == null) {
			try {
				final String connectString = "GCOTDVMSW786268:5666";
				final String agentName = "wasNdAgent^^GCOTDVMSW786268";
				System.out.println("Creating agent for " + connectString);
				rtvAgent = new RtvAgent(agentName, agentClass);
				rtvAgent.connect(connectString);
			} catch(Exception e)
			{
				e.printStackTrace();
			} 
			
			
		}
		
	}
	
	private static void createTable() {
		System.out.println("Creating table WASMetricTable..!");
		WasMetricTable = new GmsTabularData();
		WasMetricTable.addColumn("TIMETAKENINMILLIS", GmsTabularData.STRING);
		WasMetricTable.addColumn("WAS_CONN_NAME", GmsTabularData.STRING); // 1
		WasMetricTable.addColumn("TYPE", GmsTabularData.STRING); // 2
		WasMetricTable.addColumn("WAS_NODE_NAME", GmsTabularData.STRING); // 3
		WasMetricTable.addColumn("PROCESS", GmsTabularData.STRING); // 4
		WasMetricTable.addColumn("CELL", GmsTabularData.STRING); // 5
		WasMetricTable.addColumn("MBEAN_IDENTIFIER", GmsTabularData.STRING); // 8
		WasMetricTable.addColumn("PLATFORM", GmsTabularData.STRING);
		WasMetricTable.addColumn("VERSION", GmsTabularData.STRING);
		WasMetricTable.addColumn("ROWNUM", GmsTabularData.STRING);
		WasMetricTable.addColumn("ATTRIBUTES", GmsTabularData.STRING);
		System.out.println("rtview table created ");
	}

	public synchronized void addDataToRtviewAgent(MbeanData rtviewObj) {
		
		
		try {
			
			if (rtviewObj == null)
				return;
			
			int col = 0;
			WasMetricTable.addRow("");
			DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SSS");
			Date date = new Date();
			
			
			System.out.println(" ROW NUM IS "+row);
			WasMetricTable.setCellValue(dateFormat.format(date), WasRtviewAgent.getRow(), col++); 
			WasMetricTable.setCellValue(rtviewObj.getWAS_CONN_NAME(), WasRtviewAgent.getRow(), col++); // 1
			WasMetricTable.setCellValue(rtviewObj.getTYPE(), WasRtviewAgent.getRow(), col++); // 2
			WasMetricTable.setCellValue(rtviewObj.getWAS_NODE_NAME(), WasRtviewAgent.getRow(), col++); // 3
			WasMetricTable.setCellValue(rtviewObj.getPROCESS(), WasRtviewAgent.getRow(), col++); // 4
			WasMetricTable.setCellValue(rtviewObj.getCELL()+"", WasRtviewAgent.getRow(), col++); // 5
			WasMetricTable.setCellValue(rtviewObj.getMBEAN_IDENTIFIER(), WasRtviewAgent.getRow(), col++); // 8
			WasMetricTable.setCellValue(rtviewObj.getPLATFORM()+"", WasRtviewAgent.getRow(), col++); // 5
			WasMetricTable.setCellValue(rtviewObj.getVERSION(), WasRtviewAgent.getRow(), col++); 
			WasMetricTable.setCellValue(String.valueOf(getRow()), WasRtviewAgent.getRow(), col++);
			WasMetricTable.setCellValue(rtviewObj.getBEAN_ATTRIBUTES(), WasRtviewAgent.getRow(), col++);
			
			boolean sent = rtvAgent.sendTable("WASMetricTable", WasMetricTable,false);

			
			 String msg = dateFormat.format(date)+" >> WAS CONN NAME :"+rtviewObj.getWAS_CONN_NAME().toString() +" agent " + rtvAgent.getName(); 
			 if(!sent) {
				 msg += " can't send " + "WASMetricTable" + " to "; 
				 msg +=rtvAgent.getConnectionString(); 
			 }
			 else{
				 msg += " sending " + "WASMetricTable" + " to "; 
				 msg +=rtvAgent.getConnectionString(); 
				 msg +=rtviewObj.toString();
			 }	
			 System.out.println("rtview table sent "+msg);
			 WasRtviewAgent.setRow(row+1);
			 System.out.println("====> "+WasRtviewAgent.getRow());
			 
		} catch (Exception e) {
			//logger.error(e);
			e.printStackTrace();
		} 
		finally {
			//WasMetricTable.removeAllRows();
			//WasMetricTable.clearRemovedRows();
		}

	}
	
	

}

