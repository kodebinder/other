package uatcloudwas;

import java.io.IOException;


import java.net.MalformedURLException;
import java.util.Hashtable;
import java.util.Set;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;
import javax.naming.Context;

import org.osgi.framework.BundleContext;

public class WasWorkerThread implements Runnable {
	private static final String COM_IBM_WEBSPHERE_NAMING_NAME_SYNTAX = "com.ibm.websphere.naming.name.syntax";
	private static final String WEBSPHERE_PROTOCOL_PROVIDER_PACKAGES = "com.ibm.websphere.management.remote";
	private static final String WEBSPHERE_INITIAL_CONTEXT_FACTORY = "com.ibm.websphere.naming.WsnInitialContextFactory";
	private static final String WAS_JMX_SERVICE_URL_PREFIX = "service:jmx:iiops://";
	private static final String WAS_JMX_SERVICE_URL_SUFFIX = "/jndi/JMXConnector";
	private static BundleContext context = null ;
	String host=null;
	String port=null;

	public WasWorkerThread(String host, String port){

		this.host=host;
		this.port=port;

	}

	public void run () {

		/*System.setProperty("com.ibm.CORBA.ConfigURL", "file:I:/rtview_6.2.1/rtview_6.2.1.0/WAS_DS/SASSecure/sas.client.props");
		System.setProperty("com.ibm.SSL.ConfigURL", "file:I:/rtview_6.2.1/rtview_6.2.1.0/WAS_DS/SASSecure/ssl.client.props");
		System.setProperty("javax.net.ssl.trustStore", "file:I:/rtview_6.2.1/rtview_6.2.1.0/WAS_DS/SASSecure/newstore.p12"); 
		System.setProperty("javax.net.ssl.keyStore", "file:I:/rtview_6.2.1/rtview_6.2.1.0/WAS_DS/SASSecure/newstore.p12"); 
		System.setProperty("javax.net.ssl.trustStorePassword", "password"); 
		System.setProperty("javax.net.ssl.keyStorePassword", "password"); 
		System.setProperty("com.ibm.ssl.trustStoreType", "PKCS12");
*/
		Thread.currentThread().setContextClassLoader(WasWorkerThread.class.getClassLoader());
		String address = host+":"+port;
		JMXConnector conn = null;
		JMXServiceURL jmxurl = null;


		try {
			jmxurl = new JMXServiceURL(WAS_JMX_SERVICE_URL_PREFIX + address + WAS_JMX_SERVICE_URL_SUFFIX);
			
		} catch (MalformedURLException e1) {
			System.out.println("Failed ==> Malformed Url = "+jmxurl);
			return;
		}


		Hashtable<String, Object>   parameters = new Hashtable<String, Object>  ();
		//String[] credentials = new String[] {"RTViewMonitor" , "welcome1" }; 
		String[] credentials = new String[] {"RTViewUser" , "nemesis$" }; 
		parameters.put("jmx.remote.credentials", credentials);
		parameters.put(Context.INITIAL_CONTEXT_FACTORY, WEBSPHERE_INITIAL_CONTEXT_FACTORY);
		parameters.put(javax.management.remote.JMXConnectorFactory.PROTOCOL_PROVIDER_PACKAGES,
				WEBSPHERE_PROTOCOL_PROVIDER_PACKAGES);

		String providerUrl = "corbaloc:iiops:" + address + "/WsnAdminNameService";
		parameters.put(Context.PROVIDER_URL, providerUrl);
		parameters.put("osgi.service.jndi.bundleContext", Context.INITIAL_CONTEXT_FACTORY);
		parameters.put(COM_IBM_WEBSPHERE_NAMING_NAME_SYNTAX, "ins");
		parameters.put("com.ibm.SOAP.requestTimeout", "2");


		try{
			conn = JMXConnectorFactory.connect(jmxurl, parameters); 
			//System.out.println("Connection id is "+conn.getConnectionId());
			System.out.println("Success ==> Connected = "+address);
		}
		catch(Exception e){
			e.printStackTrace();
			System.out.println("Failed ==> Not connected = "+jmxurl);
		}
		


		if(conn != null){

			String types[]={ "JVM" ,"Server","ThreadPool","JDBCProvider","Application", "SessionManager"};
			
			MBeanServerConnection mbsconn=null;
			String mbeanType=null;
			try {
				mbsconn = conn.getMBeanServerConnection();
				for( String type : types){
					mbeanType=type;
					System.out.println("=====================================================================");
					System.out.println("Processing "+host+"_"+port+" MBEAN TYPE "+mbeanType);
					System.out.println("=====================================================================");
					String query = "WebSphere:type="+mbeanType+",*";
					ObjectName queryName = new ObjectName(query);
					Set s = mbsconn.queryNames(queryName, null);
					if (!s.isEmpty()) {
						Object nodeAgent = (ObjectName)s.iterator().next();
						//System.out.println("Success ==> Url = "+jmxurl+" Mbean Type = "+type+" Mbean value = "+ nodeAgent.toString());
						ObjectName pattern=new ObjectName(query);
						final JVMMBeanDataDisplay display = new JVMMBeanDataDisplay(mbsconn);
						for (ObjectName mbean : mbsconn.queryNames(pattern,null)) {
							System.out.println(display.toString(mbean, jmxurl));
						}
					} else {
						System.out.println("Failed ==> Connection  "+host+"_"+port+" Mbean Type  "+mbeanType+" was not found");
					}/*
					System.out.println("=====================================================================");
					System.out.println("Completed "+host+"_"+port+" MBEAN TYPE "+mbeanType);
					System.out.println("=====================================================================");*/					
				}
				
			} catch (Exception e) {
				//e.printStackTrace();
				System.out.println("Failed ==> while fetching data from mbean for connection "+host+"_"+port);
			}
			finally{
				try { 
					
					conn.close();
					
					//System.out.println("Connection "+host+"_"+port+" closed successfully. ");
				} catch (IOException e) {
					
					e.printStackTrace();
				}

			}

		}

	}

	public static void setContext(BundleContext context) {
		context = context;
	}
	public static BundleContext getContext() {
		return context;
	}
}