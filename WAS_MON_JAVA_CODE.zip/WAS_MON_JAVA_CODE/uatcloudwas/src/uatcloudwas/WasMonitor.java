package uatcloudwas;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import uatcloudwas.*;

public class WasMonitor {

	public static void main(String[] args) {
	
		
		ExecutorService executor = Executors.newFixedThreadPool(100);
		//WasRtviewAgent.getInstance();
		if(args.length > 0){
		for (String url : args) {
			String hostport[]=url.split("_");
            String host=hostport[0];
            String port=hostport[1];
            
			Runnable poller = new WasWorkerThread(host, port);
			
			executor.execute(poller);
			
			//System.out.println("Start polling for WAS metrics - " + url);
			
		}
		}
		/*try {
			Thread.sleep(600000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		executor.shutdown();
		while (!executor.isTerminated()) {
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
			
				e.printStackTrace();
			}
		}
		System.out.println("Finished all threads");

	}

}
