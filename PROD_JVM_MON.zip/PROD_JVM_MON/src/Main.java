import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.net.MalformedURLException;
import java.util.logging.Logger;

import javax.management.JMException;
import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;


public class Main {
    
    
    private static final Logger LOG =
            Logger.getLogger(Main.class.getName());
    public final static String separator = 
            "\\n\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\*\\n";
    
    public static void displayAll(MBeanServerConnection conn,
            ObjectName pattern) throws IOException, JMException {
        final JVMMBeanDataDisplay display = new JVMMBeanDataDisplay(conn);
        System.out.println(separator);
        for (ObjectName mbean : conn.queryNames(pattern,null)) {
            System.out.println(display.toString(mbean));
            System.out.println(separator);
        }
    }
    
    
    public Main() {
    }
    
  
    public static void main(String[] args) throws Exception {
        /*final MBeanServerConnection conn = 
                ManagementFactory.getPlatformMBeanServer();*/
    	
    	String address = "rtvdsgt1p:3155";
		JMXConnector conn = null;
		JMXServiceURL jmxurl = null;

		String WAS_JMX_SERVICE_URL_PREFIX = "service:jmx:iiop://";
		String WAS_JMX_SERVICE_URL_SUFFIX = "/jndi/JMXConnector";
		try {
			jmxurl = new JMXServiceURL(WAS_JMX_SERVICE_URL_PREFIX + address + WAS_JMX_SERVICE_URL_SUFFIX);
			
		} catch (MalformedURLException e1) {
			System.out.println("Failed ==> Malformed Url = "+jmxurl);
			return;
		}
    	
    	  conn = JMXConnectorFactory.connect(jmxurl); 
    	  MBeanServerConnection mbsconn=null;
    	  mbsconn = conn.getMBeanServerConnection();
    	 // mbsconn=conn.queryNames(queryName, null);
        displayAll(mbsconn,new ObjectName("java.lang:*"));
    }
    
}