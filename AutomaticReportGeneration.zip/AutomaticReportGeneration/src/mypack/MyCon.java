package mypack;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
public class MyCon 
{   
public static Connection con;
    static {
        
try {
            
	Class.forName("oracle.jdbc.driver.OracleDriver");
        
} 
catch (ClassNotFoundException ex) 
{
            ex.printStackTrace();
        
}
    }
    
    
    
public static Statement getStatement() throws SQLException 
{
        Statement st;
     
   if(con==null || con.isClosed())
            
con = DriverManager.getConnection("jdbc:oracle:thin:@rtvhistdbgt1p:1550:rtvdb","CLOUDRTVDB","test123");
       
 return con.createStatement();
    
}

    
}
