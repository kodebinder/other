package mypack2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
public class MyCon2 
{   
public static Connection con2;
    static {
        
try {
            
	Class.forName("oracle.jdbc.driver.OracleDriver");
        
} 
catch (ClassNotFoundException ex) 
{
            ex.printStackTrace();
        
}
    }
    
    
    
public static Statement getStatement() throws SQLException 
{
        Statement st;
     
   if(con2==null || con2.isClosed())
            
con2 = DriverManager.getConnection("jdbc:oracle:thin:@mstdbswdc01p.nam.nsroot.net:1526:clddb","sratread","mstapp123");
       
 return con2.createStatement();
    
}

    
}
