package org.example.javabrains.messenger.resources;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.example.javabrains.messenger.model.Message;
import org.example.javabrains.messenger.service.MessageService;

//url maps to class
@Path("/messages")
public class MessageResource {

	MessageService messageService = new MessageService();
	
	//http method maps to class method
	@GET
	// what is return format to send response in plaintext format
	@Produces(MediaType.APPLICATION_XML)
	/*public String getMessages(){
		return "Hello World!!";
	}*/
	public List<Message> getMessages(){
		return messageService.getAllMessages();
	}
}
