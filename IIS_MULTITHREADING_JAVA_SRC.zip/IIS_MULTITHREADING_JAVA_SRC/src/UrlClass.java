


public class UrlClass {
	String hostname="";
	String urls="";
	long update_period;
	int counturls=0;
	String tmp="";
	String xmlUrls[];
	int counter=1;
	public UrlClass(){
		
	}
	public String urlList(String[] splitArray) throws ArrayIndexOutOfBoundsException{
	//	hostname = splitArray[1];
		for(int i=0;i<splitArray.length-1;i++){
			urls = splitArray[3];
		}
	//	System.out.print(urls.toString() + " ");
	//	counturls++;
		return urls.toString();
	}
	public long updatePeriod(String[] splitArray) throws ArrayIndexOutOfBoundsException{
		//	hostname = splitArray[1];
			for(int i=0;i<splitArray.length-1;i++){
				update_period = Long.parseLong(splitArray[1]);
			}
		//	System.out.print(urls.toString() + " ");
		//	counturls++;
			return update_period;
		}
	public String[] splitStringBuilderUrlsToArray(StringBuilder xmlUrlString) {
		xmlUrls = xmlUrlString.toString().split(" ");
		return xmlUrls;
	}
	/*public void printArrayOfUrls(String[] xmlUrls){
		for(String x: xmlUrls){
			//System.out.println("URL COUNT= " + (counter++) + " " + x);
			System.out.println(x);
		}
	}*/
	
}
