import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import com.sl.gmsjagent.RtvAgent;
import com.sl.gmsjrt.GmsTabularData;

public class IISRTViewAgent {

	private static RtvAgent rtvAgentApps;
	private static RtvAgent rtvAgentMonitor;
	private static String agentClass = "IIS Metric Collector";
	private static IISRTViewAgent iisrtViewAgent = null;

	private IISRTViewAgent() {
		createAppsAgent();
		createMonitorAgent();
	}

	public static synchronized IISRTViewAgent getInstance() {
		if (iisrtViewAgent == null) {
			iisrtViewAgent = new IISRTViewAgent();
		}
		return iisrtViewAgent;
	}

	public static synchronized void createAppsAgent() {

		if (rtvAgentApps == null) {
			try {

				// final String connectString = "GCOTDVMSW786268:5665";//santosh
				// machine
				// final String connectString = "GCOTDVMSW786194:5665";
				// //pushkar machine
				final String connectString = "localhost:5665"; // local machine

				final String agentNameApps = "appsUrlData";

				rtvAgentApps = new RtvAgent(agentNameApps, agentClass);

				rtvAgentApps.connect(connectString);

			} catch (Exception e) {

			}

		}

	}

	public void createMonitorAgent() {

		if (rtvAgentMonitor == null) {
			try {

				// final String connectString = "GCOTDVMSW786268:5665";
				// final String connectString = "GCOTDVMSW786194:5665";
				// //pushkar machine
				final String connectString = "localhost:5665"; // local machine
				final String agentNameMonitor = "monitorUrlData";

				rtvAgentMonitor = new RtvAgent(agentNameMonitor, agentClass);

				rtvAgentMonitor.connect(connectString);
			} catch (Exception e) {

			}
		}

	}

	public void sendToAppsAgent(GmsTabularData appsData) {

		try {
			//System.out.println("Sending apps xml data " + appsData.toString());
		//	System.out.println("Sending apps xml data " + appsData.getNumRows());
			rtvAgentApps.sendTable("appsUrlData", appsData, true);

		} catch (Exception e) {

		} finally {
			// iisAppsData.removeAllRows();
			// iisAppsData.clearRemovedRows();
		}

	}

	public void sendToMonitorAgent(GmsTabularData monitorData) {

		try {
			/*System.out.println("Sending monitor xml data "
					+ monitorData.toString());*/
			
		//	System.out.println("Sending apps xml data " + monitorData.getNumRows());

			rtvAgentMonitor.sendTable("monitorUrlData", monitorData, true);

		} catch (Exception e) {

		} finally {
			// iisMonitorData.removeAllRows();
			// iisMonitorData.clearRemovedRows();
		}

	}

}
