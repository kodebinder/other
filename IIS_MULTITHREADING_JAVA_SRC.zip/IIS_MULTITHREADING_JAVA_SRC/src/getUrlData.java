import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class getUrlData implements Runnable {

	String xmlUrls[];
	FileReaderClass filereadobj = new FileReaderClass();
 String iisOptionsIni = "/opt/eam/UAT_CLOUD/IIS_DS/OPTIONS.ini"; 
																
	//String filename1 = "OPTIONS.ini"; //working in local
	long update_refresh_period = filereadobj.readFileforUpdatePeriod(iisOptionsIni);

	// StatsIIS statsIIS = new StatsIIS();

	public getUrlData(String xmlInputUrls[]) {
		xmlUrls = xmlInputUrls;
	}

	@Override
	public void run() {

		while (true) {
			ExecutorService executor = Executors.newFixedThreadPool(50);
			for (String url : xmlUrls) {
				Runnable poller = new CopyOfIISStatsPoller(url);
				executor.execute(poller);
			//	System.out.println("Start polling for metrics - " + url);

			}
			executor.shutdown();
			while (!executor.isTerminated()) {
				try {
					Thread.sleep(5);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			IISRTViewAgent.getInstance().sendToMonitorAgent(CopyOfIISStatsPoller.monitorDataTable);
			IISRTViewAgent.getInstance().sendToAppsAgent(CopyOfIISStatsPoller.appsDataTable);
			System.out.println("Apps Table length is " + CopyOfIISStatsPoller.appsDataTable.getNumRows());
			System.out.println("Monitor Table length is " + CopyOfIISStatsPoller.monitorDataTable.getNumRows());
			CopyOfIISStatsPoller.appsDataTable.removeAllRows();
			CopyOfIISStatsPoller.monitorDataTable.removeAllRows();
			System.out.println(" ================================================================== ");

			try {
				Thread.sleep(update_refresh_period); // refreshing data
																

			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

}
