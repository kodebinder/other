
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.lang.Exception;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

 


import com.sl.gmsjrt.GmsTabularData;



public class StatsIIS {
	

	public static boolean getIISDataRunCount = false;
	
	
	public  static void getIISData(){

		
		StringBuilder listOfXmlUrls = new StringBuilder();
		String xmlUrls[];
		UrlClass urlclassobj = new UrlClass();
		String iisOptionsIni = "/opt/eam/UAT_CLOUD/IIS_DS/OPTIONS.ini"; 
		//String filename1 = "OPTIONS.ini"; //working in local
		FileReaderClass filereadobj = new FileReaderClass();
				
		System.out.println("========== Started Reading Options INI File =====================");
		listOfXmlUrls =  filereadobj.readFile(iisOptionsIni);
		System.out.println("========== Ended Reading Options INI File =====================");
		
		xmlUrls = urlclassobj.splitStringBuilderUrlsToArray(listOfXmlUrls);
		
		Runnable getUrlDataRunnable = new getUrlData(xmlUrls);
		Thread getUrlDataThread = new Thread(getUrlDataRunnable);
		getUrlDataThread.setDaemon(true);
		getUrlDataThread.start();
		getIISDataRunCount = true;
		
		
			
	}
}