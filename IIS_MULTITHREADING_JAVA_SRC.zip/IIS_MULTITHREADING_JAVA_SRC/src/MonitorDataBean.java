import com.sl.gmsjrt.GmsTabularData;

public class MonitorDataBean {

	private long TimestampMonitored;
	private String LastUpdate;
	private String HostName;
	private String OS;
	private String Version;
	private String UpTime;
	private String TotalAccesses;
	private String TotalTraffic;
	private String RequestPool;
	private String WaitForConnection;
	private String UsagePerc;
	private String BytesPerSec;
	private String LoadRequestPerSec;
	private String BusyWorkers;
	private String WWWStatus;
	private String Url;

	public long getTimestampMonitored() {
		return TimestampMonitored;
	}

	public void setTimestampMonitored(long timestampMonitored) {
		TimestampMonitored = timestampMonitored;
	}

	public String getLastUpdate() {
		return LastUpdate;
	}

	public void setLastUpdate(String lastUpdate) {
		LastUpdate = lastUpdate;
	}

	public String getHostName() {
		return HostName;
	}

	public void setHostName(String hostName) {
		HostName = hostName;
	}

	public String getOS() {
		return OS;
	}

	public void setOS(String oS) {
		OS = oS;
	}

	public String getVersion() {
		return Version;
	}

	public void setVersion(String version) {
		Version = version;
	}

	public String getUpTime() {
		return UpTime;
	}

	public void setUpTime(String upTime) {
		UpTime = upTime;
	}

	public String getTotalAccesses() {
		return TotalAccesses;
	}

	public void setTotalAccesses(String totalAccesses) {
		TotalAccesses = totalAccesses;
	}

	public String getTotalTraffic() {
		return TotalTraffic;
	}

	public void setTotalTraffic(String totalTraffic) {
		TotalTraffic = totalTraffic;
	}

	public String getRequestPool() {
		return RequestPool;
	}

	public void setRequestPool(String requestPool) {
		RequestPool = requestPool;
	}

	public String getWaitForConnection() {
		return WaitForConnection;
	}

	public void setWaitForConnection(String waitForConnection) {
		WaitForConnection = waitForConnection;
	}

	public String getUsagePerc() {
		return UsagePerc;
	}

	public void setUsagePerc(String usagePerc) {
		UsagePerc = usagePerc;
	}

	public String getBytesPerSec() {
		return BytesPerSec;
	}

	public void setBytesPerSec(String bytesPerSec) {
		BytesPerSec = bytesPerSec;
	}

	public String getLoadRequestPerSec() {
		return LoadRequestPerSec;
	}

	public void setLoadRequestPerSec(String loadRequestPerSec) {
		LoadRequestPerSec = loadRequestPerSec;
	}

	public String getBusyWorkers() {
		return BusyWorkers;
	}

	public void setBusyWorkers(String busyWorkers) {
		BusyWorkers = busyWorkers;
	}

	public String getWWWStatus() {
		return WWWStatus;
	}

	public void setWWWStatus(String wWWStatus) {
		WWWStatus = wWWStatus;
	}

	public String getUrl() {
		return Url;
	}

	public void setUrl(String url) {
		Url = url;
	}

}
