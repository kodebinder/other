

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

import com.sl.gmsjrt.GMS;
import com.sl.gmsjrt.GmsModelVariables;
import com.sl.gmsjrt.GmsTabularData;
import com.sl.gmsjrtview.GmsRtViewCustomFunctionHandler;
import com.sl.gmsjrtview.GmsRtViewFunctionArgument;
import com.sl.gmsjrtview.GmsRtViewFunctionDescriptor;

public class iis extends GmsRtViewCustomFunctionHandler {
	private final static String PARSE_IIS_URS = "parseiisurls";
	
	
	
	public Vector getFunctionDescriptors()
    {
        Vector vector = new Vector();
        addFunctionDescriptors(vector);
        return vector;
    }
	
	public static void addFunctionDescriptors(Vector v)
	{
		if(v == null)
        {
            return;
        } 
		else
        {
			
			{
				
				GmsRtViewFunctionArgument args[] = {
				
				new GmsRtViewFunctionArgument("Program Name:", GMS.G_STRING) 
				
				
				};
			
				v.addElement(new GmsRtViewFunctionDescriptor(PARSE_IIS_URS, args, GMS.G_TABLE, null," "," " ,false));
			}
			
		}
		
	}
	
	
	
	public GmsTabularData getTabularResult(String functionName, GmsRtViewFunctionDescriptor gmsrtviewfunctiondescriptor, GmsModelVariables gmsmodelvariables)
    {
        GmsTabularData gmstabulardata = null;
        if(functionName.equals(PARSE_IIS_URS))
        {
        	gmstabulardata = getIISData(gmsrtviewfunctiondescriptor, gmsmodelvariables);
        }
       
		

		return gmstabulardata;
    }
	
	public boolean contains(String s)
	 {
        if(s.equals(PARSE_IIS_URS))
        {
            return true;
        }
        
        
        return false;
	 }
	 
	public GmsTabularData getIISData (GmsRtViewFunctionDescriptor fDesc,	GmsModelVariables fIcon)
	{
		//System.out.println("\n \n");
		String pgmName;
		GmsTabularData resultIIStblIn = new GmsTabularData() ;
		try {
			
			pgmName = fDesc.getArgStringValue("Program Name:", fIcon);
			

			if(pgmName!=null || pgmName!="" )
			{
				System.out.println(" =================================================================  ");
				System.out.println(" Calling thread through RTV file function    ");
				System.out.println(" =================================================================  ");
				
				if(!StatsIIS.getIISDataRunCount)
				 StatsIIS.getIISData();
				else
					System.out.println("Thread already running");
			}
				
		} catch (Exception e) {
			
			e.printStackTrace();
			return null;
		}
		
		
		return resultIIStblIn;
	}
	

   

}
