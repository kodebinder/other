import com.sl.gmsjrt.GmsTabularData;


public class AppsDataBean {
	private long TimestampMonitored;
	private String Hostname;
	private String Application;
	private String WebSiteId;
	private String Status;
	private String Url;
	
	public String getHostname() {
		return Hostname;
	}
	public void setHostname(String hostname) {
		Hostname = hostname;
	}
	public String getApplication() {
		return Application;
	}
	public void setApplication(String application) {
		Application = application;
	}
	public String getWebSiteId() {
		return WebSiteId;
	}
	public void setWebSiteId(String webSiteId) {
		WebSiteId = webSiteId;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getUrl() {
		return Url;
	}
	public void setUrl(String url) {
		Url = url;
	}
	public long getTimestampMonitored() {
		return TimestampMonitored;
	}
	public void setTimestampMonitored(long timestampMonitored) {
		TimestampMonitored = timestampMonitored;
	}
}
