//*******************************************************************
// SL-GMS Enterprise RtView Examples
// MyFunctionHandler: Custom Function Handler
// Copyright (c) 2010 Sherrill-Lubinski Corporation. All Rights Reserved.
// 3 June 2010
//********************************************************************

//package com.sl.gmsjrtvutils;

import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import org.apache.log4j.Logger;



import com.sl.gmsjrt.GmsModelVariables;
import com.sl.gmsjrt.GmsTabularData;
import com.sl.gmsjrtview.GmsRtViewCustomFunctionHandler;
import com.sl.gmsjrtview.GmsRtViewFunctionDescriptor;
import com.sl.gmsjrtvutils.RtvUtilFunctions;

/* This class contains a sample Custom Function Handler.
 */

public class MyFunctionHandler extends GmsRtViewCustomFunctionHandler {
	RtvUtilFunctions utilFunctions = new RtvUtilFunctions();

	
	
	iis iisObj = new iis();

	// **************************************************************
	// FUNCTION TABLE

	public Vector<GmsRtViewFunctionDescriptor> getFunctionDescriptors() {

		// vector of function descriptors
		Vector<GmsRtViewFunctionDescriptor> v = new Vector<GmsRtViewFunctionDescriptor>();

		utilFunctions.addFunctionDescriptors(v);
		iisObj.addFunctionDescriptors(v);
		return v;
	}

	// **************************************************************
	// FUNCTION RESULT METHODS

	

	

	public GmsTabularData getTabularResult(String functionName,
			GmsRtViewFunctionDescriptor functionDesc,
			GmsModelVariables functionIcon) {
		GmsTabularData resultTable = null;

		if (iisObj.contains(functionName))
			return iisObj.getTabularResult(functionName, functionDesc,
					functionIcon);

		

		return resultTable;
	}
}
