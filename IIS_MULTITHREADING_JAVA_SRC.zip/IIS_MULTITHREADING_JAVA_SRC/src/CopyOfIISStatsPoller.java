import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.sl.gmsjrt.GmsTabularData;


public class CopyOfIISStatsPoller implements Runnable {
	

	
	private static final String HTTP = "http:";
	private String url;
	
	static GmsTabularData appsDataTable =  new GmsTabularData();
	 static GmsTabularData monitorDataTable =  new GmsTabularData();
	
	public CopyOfIISStatsPoller(String url) {
		this.url = url;
	}

	static{
		IISRTViewAgent.getInstance();
		System.out.println("Creating apps table with headers ");
		
		appsDataTable.addColumn("Hostname", GmsTabularData.STRING);
		appsDataTable.addColumn("Application", GmsTabularData.STRING);
		appsDataTable.addColumn("WebSiteId", GmsTabularData.STRING);
		appsDataTable.addColumn("Status", GmsTabularData.STRING);
		appsDataTable.addColumn("Timestamp", GmsTabularData.LONG);
		appsDataTable.addColumn("Url", GmsTabularData.STRING);
		
		System.out.println("Creating monitor table with headers ");
	
		
		monitorDataTable.addColumn("LastUpdate", GmsTabularData.STRING);
		monitorDataTable.addColumn("HostName", GmsTabularData.STRING);
		monitorDataTable.addColumn("OS", GmsTabularData.STRING);
		monitorDataTable.addColumn("Version", GmsTabularData.STRING);
		monitorDataTable.addColumn("UpTime", GmsTabularData.STRING);
		monitorDataTable.addColumn("TotalAccesses", GmsTabularData.STRING);
		monitorDataTable.addColumn("TotalTraffic", GmsTabularData.STRING);
		monitorDataTable.addColumn("RequestPool", GmsTabularData.STRING);
		monitorDataTable.addColumn("WaitForConnection", GmsTabularData.STRING);
		monitorDataTable.addColumn("UsagePerc", GmsTabularData.STRING);
		monitorDataTable.addColumn("BytesPerSec", GmsTabularData.STRING);
		monitorDataTable.addColumn("LoadRequestPerSec", GmsTabularData.STRING);
		monitorDataTable.addColumn("BusyWorkers", GmsTabularData.STRING);
		monitorDataTable.addColumn("WWWStatus", GmsTabularData.STRING);
		monitorDataTable.addColumn("Timestamp", GmsTabularData.LONG);
		monitorDataTable.addColumn("Url", GmsTabularData.STRING);
	}
	@Override
	public  void run() {
		
		if (!url.startsWith(HTTP)){
				System.out.println("malformed url "+url);
		}
		else if(url.startsWith(HTTP) && url.endsWith("apps.xml")) 
			{
					appsXmlHandler(url);
			
			}
		
		else if(url.startsWith(HTTP) && url.endsWith("monitor.xml")) 
		{
				monitorXmlhandler(url);
		}
		else {
			System.out.println("No urls found");
		}
	}
	
public static synchronized void addRowToAppsDatatable(AppsDataBean adb){
	
	int appTableRowCount=appsDataTable.getNumRows();
	int appTableColCount=0;
	
	appsDataTable.addRow("");
	
	if(adb != null){
		
		appsDataTable.setCellValue(adb.getHostname(), appTableRowCount, appTableColCount);
		appTableColCount++;
		appsDataTable.setCellValue(adb.getApplication(), appTableRowCount, appTableColCount);
		appTableColCount++;
		appsDataTable.setCellValue(adb.getWebSiteId(), appTableRowCount, appTableColCount);
		appTableColCount++;
		appsDataTable.setCellValue(adb.getStatus(), appTableRowCount, appTableColCount);
		appTableColCount++;
		appsDataTable.setCellValue(adb.getTimestampMonitored(), appTableRowCount, appTableColCount);
		appTableColCount++;
		appsDataTable.setCellValue(adb.getUrl(), appTableRowCount, appTableColCount);
		appTableColCount++;
	}
	
	
	//System.out.println(" APPS DATA IS "+ appsDataTable.toString());
//	IISRTViewAgent.getInstance().sendToAppsAgent(appsDataTable);
	
	
}

public static synchronized void addRowToMonitorDatatable(MonitorDataBean mdb){
	int monitorTableRowCount=monitorDataTable.getNumRows();
	int monitorTableColCount=0;
	
	monitorDataTable.addRow("");
	
	if (mdb != null){
		
		monitorDataTable.setCellValue(mdb.getLastUpdate(), monitorTableRowCount, monitorTableColCount);
		monitorTableColCount++;
		monitorDataTable.setCellValue(mdb.getHostName(), monitorTableRowCount, monitorTableColCount);
		monitorTableColCount++;
		monitorDataTable.setCellValue(mdb.getOS(), monitorTableRowCount, monitorTableColCount);
		monitorTableColCount++;
		monitorDataTable.setCellValue(mdb.getVersion(), monitorTableRowCount, monitorTableColCount);
		monitorTableColCount++;
		monitorDataTable.setCellValue(mdb.getUpTime(), monitorTableRowCount, monitorTableColCount);
		monitorTableColCount++;
		monitorDataTable.setCellValue(mdb.getTotalAccesses(), monitorTableRowCount, monitorTableColCount);
		monitorTableColCount++;
		monitorDataTable.setCellValue(mdb.getTotalTraffic(), monitorTableRowCount, monitorTableColCount);
		monitorTableColCount++;
		monitorDataTable.setCellValue(mdb.getRequestPool(), monitorTableRowCount, monitorTableColCount);
		monitorTableColCount++;
		monitorDataTable.setCellValue(mdb.getWaitForConnection(), monitorTableRowCount, monitorTableColCount);
		monitorTableColCount++;
		monitorDataTable.setCellValue(mdb.getUsagePerc(), monitorTableRowCount, monitorTableColCount);
		monitorTableColCount++;
		monitorDataTable.setCellValue(mdb.getBytesPerSec(), monitorTableRowCount, monitorTableColCount);
		monitorTableColCount++;
		monitorDataTable.setCellValue(mdb.getLoadRequestPerSec(), monitorTableRowCount, monitorTableColCount);
		monitorTableColCount++;
		monitorDataTable.setCellValue(mdb.getBusyWorkers(), monitorTableRowCount, monitorTableColCount);
		monitorTableColCount++;
		monitorDataTable.setCellValue(mdb.getWWWStatus(), monitorTableRowCount, monitorTableColCount);
		monitorTableColCount++;
		
		monitorDataTable.setCellValue(mdb.getTimestampMonitored(), monitorTableRowCount, monitorTableColCount);
		monitorTableColCount++;
		monitorDataTable.setCellValue(mdb.getUrl(), monitorTableRowCount, monitorTableColCount);
		monitorTableColCount++;
		
	}
	
	
	
	//IISRTViewAgent.getInstance().sendToMonitorAgent(monitorDataTable);
	
	
}

public static void monitorXmlhandler(String url){
	

	
	//System.out.println("... get data from <" + url + ">");
		long startTime = System.currentTimeMillis();
		// appending start time for each url
		DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
		Calendar calobj = Calendar.getInstance();
		
		URL u = null;
		  int temp = 0;
		URLConnection urlc = null;
		// appending start time for each url
	//	System.out.println(startTime +"  "+ "for urls"+ "  " + url); //return long value
	//	System.out.println(df.format(calobj.getTime()) +"  "+ "is start time" + " " + "for urls"+ "  " + url);
		try {
					u = new URL(url);
					try {
						urlc = u.openConnection();
					} catch (Exception e) {
						System.out.println("ERROR: CopyOfIISStatsPoller ==> monitorXmlHandler cannot() ==> cannot open connection  for url "+ url);
						e.printStackTrace();
						addExceptionMonitorDataRow(url);
						return;
					} 
			} catch (Exception e) {
				System.out.println("ERROR: CopyOfIISStatsPoller ==> monitorXmlHandler cannot() ==> cannot build url class object for url "+ url);
				e.printStackTrace();
				addExceptionMonitorDataRow(url);
				return;
			}
				
			InputStream is = null;
			try {
				is = urlc.getInputStream();
			} catch (Exception e) {
				System.out.println("ERROR: CopyOfIISStatsPoller ==> monitorXmlHandler cannot() ==> cannot get input stream for url connection  "+ url);
				e.printStackTrace();
				try {
					is.close();
				} catch (Exception e1) {
					System.out.println("ERROR: CopyOfIISStatsPoller ==> monitorXmlHandler() ==> urlc.getInputStream() ==> Failed while closing input stream for url "+url);
					e1.printStackTrace();
				}
				addExceptionMonitorDataRow(url);
				return;
			}
			
			  
	    	  DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	    	  DocumentBuilder dBuilder = null;
			try {
				dBuilder = dbFactory.newDocumentBuilder();
			} catch (Exception e) {
				System.out.println("ERROR: CopyOfIISStatsPoller ==> monitorXmlHandler() ==> cannot create doc builder using doc factory for url "+ url);
				e.printStackTrace();
				try {
					is.close();
				} catch (Exception e1) {
					System.out.println("ERROR: CopyOfIISStatsPoller ==> monitorXmlHandler() ==> dbFactory.newDocumentBuilder() ==> Failed while closing input stream for url "+url);
					e1.printStackTrace();
				}
				addExceptionMonitorDataRow(url);
				return;
			}
	    	  Document doc = null;
			try {
				doc = dBuilder.parse(is);
			} catch (Exception e) {
				System.out.println("ERROR: CopyOfIISStatsPoller ==> monitorXmlHandler() ==> cannot parse input stream data using doc builder for url "+ url);
				e.printStackTrace();
				try {
					is.close();
				} catch (Exception e1) {
					System.out.println("ERROR: CopyOfIISStatsPoller ==> monitorXmlHandler() ==> dBuilder.parse(is) ==> Failed while closing input stream for url "+url);
					e1.printStackTrace();
				}
				addExceptionMonitorDataRow(url);
				return;
			}
	  
	    	  NodeList nList = doc.getElementsByTagName("table");
	    	  Node tableNode = nList.item(temp);
		      Element tableElement = (Element) tableNode;
	          NodeList columnList = tableElement.getElementsByTagName("tc");
	    	  
	    	      for (int j = 0; j < columnList.getLength(); j++) 
	    	      { 
	    	          Node columnNode = columnList.item(j); 
	    	          Element columnElement = (Element) columnNode; 
	    	         //System.out.println("Header name: " + columnElement.getAttribute("name"));                
	    	      }
	    	      
	    	      //System.out.println("=========================================================="); 
	    	      
	    	   NodeList valueList = tableElement.getElementsByTagName("tr");
	    	       for (int k = 0; k < valueList.getLength(); k++) 
	    	       {
	    	    	  
	    	    	   	ArrayList<String> rowMonitorValues =new ArrayList<String>();
	    	    	//   	rowMonitorValues.add(url);
		                  //System.out.println(" Row  "+k);
		                  Node rowNode = valueList.item(k);
		                  Element rowDataElement1 = (Element) rowNode;
		                  //monitorDataTable.addRow("");
		                  
		                  NodeList rowData = rowDataElement1.getElementsByTagName("td");
		                  int r=0;
		                  MonitorDataBean mdb = new MonitorDataBean();
		                  
			    	       for ( r = 0; r < rowData.getLength(); r++) 
			    	       {

				    	    	  Node dataNode1 = rowData.item(r);
				                  Element dataElement1 = (Element) dataNode1;
				                 
				                 
				                  if (r == 0 ){
				                	  mdb.setLastUpdate(dataElement1.getAttribute("value"));
				                	}else if (r == 1 ) {
				                		mdb.setHostName(dataElement1.getAttribute("value"));
									}
				                  	else if (r == 2 ) {
				                  		mdb.setOS(dataElement1.getAttribute("value"));
									}else if (r == 3 ) {
										mdb.setVersion(dataElement1.getAttribute("value"));
									}
									else if (r == 4 ) {
				                		mdb.setUpTime(dataElement1.getAttribute("value"));
									}
				                  	else if (r == 5 ) {
				                  		mdb.setTotalAccesses(dataElement1.getAttribute("value"));
									}else if (r == 6 ) {
										mdb.setTotalTraffic(dataElement1.getAttribute("value"));
									}else if (r == 7 ) {
				                		mdb.setRequestPool(dataElement1.getAttribute("value"));
									}
				                  	else if (r == 8 ) {
				                  		mdb.setWaitForConnection(dataElement1.getAttribute("value"));
									}else if (r == 9 ) {
										mdb.setUsagePerc(dataElement1.getAttribute("value"));
									}else if (r == 10 ) {
				                		mdb.setBytesPerSec(dataElement1.getAttribute("value"));
									}
				                  	else if (r == 11 ) {
				                  		mdb.setLoadRequestPerSec(dataElement1.getAttribute("value"));
									}else if (r == 12 ) {
										mdb.setBusyWorkers(dataElement1.getAttribute("value"));
									}else if (r == 13 ) {
										mdb.setWWWStatus(dataElement1.getAttribute("value"));
									}
				                  

				    	      
			    	    	   
			    	       }
			    	       /*adb.setUrl(url);
			    	       long appsMonitoredTimeStamp = System.currentTimeMillis();
			    	       adb.setTimestampMonitored(appsMonitoredTimeStamp);*/
			    	      // rowMonitorValues.add(url);
			    	       mdb.setUrl(url);
			    	       long monitorMonitoredTimeStamp = System.currentTimeMillis();
			    	       mdb.setTimestampMonitored(monitorMonitoredTimeStamp);
			    	       addRowToMonitorDatatable(mdb);  
			    	       
	               }
	    	       
	    	  
	    	       try {
						is.close();
					} catch (Exception e) {
						System.out.println("ERROR: CopyOfIISStatsPoller ==> monitorXmlHandler cannot() ==> cannot close input stream after reading for url "+ url);
						e.printStackTrace();						
						return;
					}
			
			
	    	      
	    	      
			//long endTime = System.currentTimeMillis();
			// appending end time for each url
			//System.out.println(endTime +"  "+ "for urls"+ "  " + url); //returns long value
		//	System.out.println(df.format(calobj.getTime()) +"  "+ "is end time" + "for urls"+ "  " + url);
		//	IISRTViewAgent.getInstance().sendToMonitorAgent(monitorDataTable);
			

}
public static void appsXmlHandler(String url){

	
	//System.out.println("... get data from <" + url + ">");
	long startTime = System.currentTimeMillis();
	// appending start time for each url
	DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
	Calendar calobj = Calendar.getInstance();
		URL u = null;
		  int temp = 0;
		URLConnection urlc = null;
		// appending start time for each url
		//	System.out.println(startTime +"  "+ "for urls"+ "  " + url); //return long value
		//	System.out.println(df.format(calobj.getTime()) +"  "+ "is start time" + " " + "for urls"+ "  " + url);
		try {
					u = new URL(url);
					
					try {
						urlc = u.openConnection();
					} catch (Exception e) {
						System.out.println("ERROR: CopyOfIISStatsPoller ==> appsXmlHandler() ==>  cannot open connection for url "+ url);
						e.printStackTrace();
						
						addExceptionAppsDataRow(url);
						return;
					}
			} catch (Exception e) {
				System.out.println("ERROR: CopyOfIISStatsPoller ==> appsXmlHandler() ==>  build url class object  for url "+ url);
				e.printStackTrace();
				addExceptionAppsDataRow(url);
				return;
			}
				
			InputStream is = null;
			
			
				try {
					is = urlc.getInputStream();
				} catch (Exception e) {
					System.out.println("ERROR: CopyOfIISStatsPoller ==> appsXmlHandler() ==>  cannot get input stream for url connection "+ url);
					e.printStackTrace();

					try {
						is.close();
					} catch (Exception e1) {
						System.out.println("ERROR: CopyOfIISStatsPoller ==> appsXmlHandler() ==> urlc.getInputStream() ==> Failed while closing input stream for url "+url);
						e1.printStackTrace();
					}
					addExceptionAppsDataRow(url);
					return;
				}
			
			  
	    	  DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	    	  DocumentBuilder dBuilder = null;
			try {
				dBuilder = dbFactory.newDocumentBuilder();
			} catch (Exception e) {
				System.out.println("ERROR: CopyOfIISStatsPoller ==> appsXmlHandler() ==> cannot create doc builder from doc factory for  "+ url);
				e.printStackTrace();
				try {
					is.close();
				} catch (Exception e1) {
					System.out.println("ERROR: CopyOfIISStatsPoller ==> appsXmlHandler() ==> dbFactory.newDocumentBuilder() ==> Failed while closing input stream for url "+url);
					e1.printStackTrace();
				}
				addExceptionAppsDataRow(url);
				return;
				
			}
	    	  Document doc = null;
			try {
				doc = dBuilder.parse(is);
			} catch (Exception e) {
				System.out.println("ERROR: CopyOfIISStatsPoller ==> appsXmlHandler() ==> cannot parse input stream data using doc builder for url  "+ url);
				e.printStackTrace();
				try {
					is.close();
				} catch (Exception e1) {
					System.out.println("ERROR: CopyOfIISStatsPoller ==> appsXmlHandler() ==> dBuilder.parse(is) ==> Failed while closing input stream for url "+url);
					e1.printStackTrace();
				}
				addExceptionAppsDataRow(url);
				return;
			} 
	    	
	    	  NodeList nList = doc.getElementsByTagName("table");
	    	  Node tableNode = nList.item(temp);
		      Element tableElement = (Element) tableNode;
	          NodeList columnList = tableElement.getElementsByTagName("tc");
	    	  
	    	      for (int j = 0; j < columnList.getLength(); j++) 
	    	      { 
	    	          Node columnNode = columnList.item(j); 
	    	          Element columnElement = (Element) columnNode; 
	    	         //System.out.println("Header name: " + columnElement.getAttribute("name"));                
	    	      }
	    	      
	    	     
	    	      
	    	   NodeList valueList = tableElement.getElementsByTagName("tr");
	    	       for (int k = 0; k < valueList.getLength(); k++) 
	    	       {
	    	    	  
	    	    	   ArrayList<String> rowValues =new ArrayList<String>();
	    	    	 //  rowValues.add(url);
		                 // System.out.println(" Row  "+k);
		                  Node rowNode = valueList.item(k);
		                  Element rowDataElement1 = (Element) rowNode;
		                  
		                  AppsDataBean adb = new AppsDataBean();
		                  NodeList rowData = rowDataElement1.getElementsByTagName("td");
		                  int r=0;
			    	       for ( r = 0; r < rowData.getLength(); r++) 
			    	       {
			    	    	  Node dataNode1 = rowData.item(r);
			                  Element dataElement1 = (Element) dataNode1;
			                 
			                 
			                  if (r == 0 ){
			                	  adb.setHostname(dataElement1.getAttribute("value"));
			                	}else if (r == 1 ) {
			                		adb.setApplication(dataElement1.getAttribute("value"));
								}
			                  	else if (r == 2 ) {
			                  		adb.setWebSiteId(dataElement1.getAttribute("value"));
								}else if (r == 3 ) {
									adb.setStatus(dataElement1.getAttribute("value"));
								}
			                  

			    	      }
			    	       adb.setUrl(url);
			    	       long appsMonitoredTimeStamp = System.currentTimeMillis();
			    	       adb.setTimestampMonitored(appsMonitoredTimeStamp);
			    	       addRowToAppsDatatable(adb);
			    	       //rowValues.add(dataElement1.getAttribute("value"));
			    	       
	               }
	    	  
	    	       try {
						is.close();
					} catch (Exception e) {
						System.out.println("ERROR: CopyOfIISStatsPoller ==> appsXmlHandler() ==> cannot close input stream for url  after reading for url "+ url);
						e.printStackTrace();						
						return;
					}
			
			
	    	      
	    	      
			long endTime = System.currentTimeMillis();
			// appending end time for each url
			//System.out.println(endTime +"  "+ "for urls"+ "  " + url); //returns long value
		//	System.out.println(df.format(calobj.getTime()) +"  "+ " is end time " + " " + "for urls"+ "  " + url);
		//	IISRTViewAgent.getInstance().sendToAppsAgent(appsDataTable);
		
	
}

public static void addExceptionAppsDataRow(String url){
	
	
	URL aURL = null;
	try {
		aURL = new URL(url);
	} catch (MalformedURLException e) {
		e.printStackTrace();
	}

System.out.println("protocol = " + aURL.getProtocol()); 
System.out.println("authority = " + aURL.getAuthority());
System.out.println("host = " + aURL.getHost()); 
System.out.println("port = " + aURL.getPort());
System.out.println("path = " + aURL.getPath()); 
System.out.println("query = " + aURL.getQuery());
System.out.println("filename = " + aURL.getFile());
System.out.println("ref = " + aURL.getRef()); 
	
	AppsDataBean adb = new AppsDataBean();
	adb.setUrl(url);
	adb.setHostname(aURL.getHost());
    long appsMonitoredTimeStamp = System.currentTimeMillis();
    adb.setTimestampMonitored(appsMonitoredTimeStamp);
    addRowToAppsDatatable(adb);
 	
}

public static void addExceptionMonitorDataRow(String url){
	
	URL aURL = null;
	try {
		aURL = new URL(url);
	} catch (MalformedURLException e) {
		e.printStackTrace();
	}

System.out.println("protocol = " + aURL.getProtocol()); 
System.out.println("authority = " + aURL.getAuthority());
System.out.println("host = " + aURL.getHost()); 
System.out.println("port = " + aURL.getPort());
System.out.println("path = " + aURL.getPath()); 
System.out.println("query = " + aURL.getQuery());
System.out.println("filename = " + aURL.getFile());
System.out.println("ref = " + aURL.getRef()); 

	MonitorDataBean mdb = new MonitorDataBean();
	mdb.setUrl(url);
	mdb.setHostName(aURL.getHost());
    long monitorMonitoredTimeStamp = System.currentTimeMillis();
    mdb.setTimestampMonitored(monitorMonitoredTimeStamp);
    addRowToMonitorDatatable(mdb);
  
}

}
