

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class FileReaderClass {

	UrlClass fileprinterobj = new UrlClass();
	int counter=0;
	String splitArray[];
	String result=" ";
	long update_refresh_period=0;
	StringBuilder str = new StringBuilder();
	
	public StringBuilder readFile(String f){
		try{
			
			
		File filereadobj = new File(f);
		FileReader filereaderobj = new FileReader(filereadobj);
		BufferedReader br = new BufferedReader(filereaderobj);
		String line=" ";
		while ((line = br.readLine()) != null){
			
			if(line.length() > 0 && line.startsWith("xmlsource") && line.contains("http"))
			{ 
				
				splitArray = line.split(" ");
				result=fileprinterobj.urlList(splitArray);
				str.append(result+" ");
			}
			
		}
		}catch(Exception e){
			e.printStackTrace();			
		}
		return str;
	}
	
	public long readFileforUpdatePeriod(String f){
		try{
			
			//update_period=0;
		File filereadobj = new File(f);
		FileReader filereaderobj = new FileReader(filereadobj);
		BufferedReader br = new BufferedReader(filereaderobj);
		String line=" ";
		while ((line = br.readLine()) != null){
			
			if(line.length() > 0 && line.startsWith("update_refresh_period"))
			{ 
				
				splitArray = line.split(" ");
				//result=fileprinterobj.urlList(splitArray);
				update_refresh_period=fileprinterobj.updatePeriod(splitArray);
				//str.append(result+" ");
			}
			
		}
		}catch(Exception e){
			e.printStackTrace();			
		}
		
		return update_refresh_period;
	}
	
	
}
