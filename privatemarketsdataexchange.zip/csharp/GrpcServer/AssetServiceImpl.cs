﻿using System;
using Google.Protobuf.WellKnownTypes;
using Grpc.Core;
using System.Threading;
using System.Threading.Tasks;
using Bfm.Aap.Pmdx.Services;
using Bfm.Aap.Pmdx.Model;
using System.Collections.Generic;


namespace GrpcServer
{
    class AssetServiceImpl : AssetService.AssetServiceBase
    {

        private static List<FundAsset> getAssets()
        {
            List<FundAsset> list = new List<FundAsset>();
            Random random = new Random();
            int count = random.Next(1, 9);
            for (int i = 0; i < count; i++)
            {
                FundAsset tempAsset = new FundAsset();
                tempAsset.Cusip = "AB123456" + i;
                tempAsset.Description = "Dummy asset-" + i;
                tempAsset.AssetId = "AB123456" + i;
                tempAsset.AssetType = "Fund";
                tempAsset.Currency = "USD";
                tempAsset.FundSize = 1345000.00;
                tempAsset.VintageYear = 2005;
                list.Add(tempAsset);
            }
            return list;
        }

        public override Task<FundAsset> GetFundAsset(AssetRequest request, ServerCallContext context)
        {

            return Task.FromResult(AssetServiceImpl.getAssets().ToArray()[0]);
        }
        
        public override Task GetFundAssetsSince(AssetsSinceRequest request, IServerStreamWriter<FundAsset> responseStream, ServerCallContext context)
        {
            Utils.Log("Handling asset request for timestamp:" + request);
            foreach (FundAsset asset in AssetServiceImpl.getAssets())
            {
                responseStream.WriteAsync(asset);
                Utils.WaitDelay(300, new CancellationToken()).Wait();
            }
            return Task.CompletedTask;
        }
    }
}
