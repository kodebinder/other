﻿using System;
using Google.Protobuf.WellKnownTypes;
using Grpc.Core;
using System.Threading;
using System.Threading.Tasks;
using Bfm.Aap.Pmdx.Services;
using Bfm.Aap.Pmdx.Model;
using System.Collections.Generic;

namespace GrpcServer
{
    class PortfolioServiceImpl :  PortfolioService.PortfolioServiceBase
    {
        private static List<Portfolio> getPortfolios()
        {
            List<Portfolio> list = new List<Portfolio>();
            Random random = new Random();
            int count = random.Next(1, 9);
            for( int i = 0; i< count; i++)
            {
                Portfolio portfolio = new Portfolio();
                portfolio.PortfolioCode = 28470+i;
                portfolio.PortfolioId = "SPV000068"+i;
                portfolio.Ticker = "SPV000068" + i;
                portfolio.PortfolioName = "River Direct Investment-"+i;
                list.Add(portfolio);
            }
            return list;
        }

        public override Task<Portfolio> GetPortfolio(PortfolioRequest request, ServerCallContext context)
        {
            Portfolio portfolio = PortfolioServiceImpl.getPortfolios().ToArray()[0];
            portfolio.PortfolioId = request.Guid;
            return Task.FromResult(portfolio);
        }

        public override Task GetPortfoliosSince(PortfoliosSinceRequest request, IServerStreamWriter<Portfolio> responseStream, ServerCallContext context)
        {
            Utils.Log("Handling portfolio request for timestamp:" + request);
            foreach (Portfolio portfolio in PortfolioServiceImpl.getPortfolios())
            {
                responseStream.WriteAsync(portfolio);
                Utils.WaitDelay(300, new CancellationToken()).Wait();
            }
            return Task.CompletedTask;
        }
    }


}
