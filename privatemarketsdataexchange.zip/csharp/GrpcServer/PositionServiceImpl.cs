﻿using System;
using Google.Protobuf.WellKnownTypes;
using Grpc.Core;
using System.Threading;
using System.Threading.Tasks;
using Bfm.Aap.Pmdx.Services;
using Bfm.Aap.Pmdx.Model;
using System.Collections.Generic;

namespace GrpcServer
{
    class PositionServiceImpl : PositionService.PositionServiceBase
    {
        private static List<Position> getPositions()
        {
            List<Position> list = new List<Position>();
            Random random = new Random();
            int count = random.Next(1, 9);
            for (int i = 0; i < count; i++)
            {
                Position position = new Position();
                position.AssetId = "AB123456" + i;
                position.ClientId = "1234";
                position.Cusip = "AB123456" + i;
                position.PortfolioCode = 28470 + i;
                position.PortfolioId = "SPV000068" + i;
                position.PortfolioName = "River Direct Investment-" + i;
                list.Add(position);
            }
            return list;
        }

        public override Task<Position> GetPosition(PositionRequest request, ServerCallContext context)
        {
            Position position = PositionServiceImpl.getPositions().ToArray()[0];
            position.PortfolioId = request.Guid;
            return Task.FromResult(position);
        }

        public override Task GetPositionsSince(PositionsSinceRequest request, IServerStreamWriter<Position> responseStream, ServerCallContext context)
        {
            Utils.Log("Handling position request for timestamp:" + request);
            foreach (Position position in PositionServiceImpl.getPositions())
            {
                responseStream.WriteAsync(position);
                Utils.WaitDelay(300, new CancellationToken()).Wait();
            }
            return Task.CompletedTask;
        }
    }
}
