﻿using System;
using Grpc.Core;
using Bfm.Aap.Pmdx.Services;


namespace GrpcServer
{
    class Program
    {
        private Server edxServer;

        public Program(string host, int port)
        {
            this.edxServer = new Server
            {
                Services = { AssetService.BindService(new AssetServiceImpl()),
                              PortfolioService.BindService(new PortfolioServiceImpl()),
                PositionService.BindService(new PositionServiceImpl())},
                Ports = { new ServerPort(host, port, ServerCredentials.Insecure) }
            };
        }

        public void Start()
        {
            this.edxServer.Start();
            Utils.Log("EDXServer started....");
        }

        public void Stop()
        {
            this.edxServer.ShutdownAsync().Wait();
            Utils.Log("EDX shutdown complete....");
        }
          public static void Main(string[] args)
        {
            Utils.Log("Starting EDX server...");
            int port = 50555;
            Program server = new Program("localhost", port);
            server.Start();
            Utils.Log("EDX Server listening on port " + port);
            Utils.Log("Press any key to stop the server...");
            Console.ReadKey();
            server.Stop();
        }
    }
}
