﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GrpcServer
{
    class Utils
    {

        public static void Log(string content)
        {
            Console.WriteLine(content);
        }

        public static async Task WaitDelay(int sleepInMillis, CancellationToken token)
        {
            await Task.Delay(sleepInMillis, token);
        }
    }
}
