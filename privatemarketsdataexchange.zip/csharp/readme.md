#  C# EDX Server

Mock C# server for Asset, Portfolio and Positions

  - Import the solution in visual studio
  - Build the solution.
  - Start the server. Client also if needed