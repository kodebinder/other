﻿using System;
using Google.Protobuf.WellKnownTypes;
using Grpc.Core;
using System.Threading;
using System.Threading.Tasks;

namespace GrpcClient
{
    class Program
    {
        private AssetServiceClientImpl assetClient;
        private Channel channel;
        private Thread listenerThread;

        public Program(string host, int port)
        {
            this.channel = new Channel(host, port, ChannelCredentials.Insecure);
            this.assetClient = new AssetServiceClientImpl(channel);
        }


        public void Shutdown()
        {
            listenerThread.Abort();
            channel.ShutdownAsync();
            Log("Client shutdown complete....");
        }

        public void Start()
        {
            Log("Starting client for assets...");
            listenerThread = new Thread(new ThreadStart(recursiveCall));
            listenerThread.Start();
        }

        private void recursiveCall()
        {
            while (true)
            {
                assetClient.getAssetsSince(Timestamp.FromDateTime(DateTime.UtcNow)).Wait();
                waitDelay(20000, new CancellationToken()).Wait();
            }
        }

        private static void Log(string s)
        {
            Console.WriteLine(s);
        }
        public async Task waitDelay(int sleepInMillis, CancellationToken token)
        {
            await Task.Delay(sleepInMillis, token);
        }

        static void Main(string[] args)
        {
            int port = 50555;
            Program client = new Program("localhost", port);
            client.Start();
            Log("EDX Client listening on port " + port);
            Log("Press any key to stop the client...");
            Console.ReadKey();
            client.Shutdown();

        }


    }
}
