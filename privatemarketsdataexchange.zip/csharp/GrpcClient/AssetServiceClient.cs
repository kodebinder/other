﻿using System;
using Google.Protobuf.WellKnownTypes;
using Grpc.Core;
using System.Threading;
using System.Threading.Tasks;
using Bfm.Aap.Dx.Services;
using Bfm.Aap.Dx.Model;
using System.Collections.Generic;

namespace GrpcClient
{
    class AssetServiceClientImpl
    {
        private Channel channel;
        private AssetService.AssetServiceClient assetClient;

        public AssetServiceClientImpl(Channel channel)
        {
            this.channel = channel;
            this.assetClient = new AssetService.AssetServiceClient(channel);
        }
        public FundAsset getFundAsset(AssetRequest assetRequest)
        {
            try
            {
                return this.assetClient.GetFundAsset(assetRequest);
            }
            catch (Exception ex)
            {
                Log("RPC failed for getFundAsset: " + ex);
                throw;
            }
        }

        public async Task getAssetsSince(Timestamp timestampSince)
        {
            try
            {
                using (var call = assetClient.GetFundAssetsSince(timestampSince))
                {
                    var responseStream = call.ResponseStream;
                    Log("fetching assets since: " + timestampSince.ToString());
                    List<FundAsset> funds = new List<FundAsset>();
                    while (await responseStream.MoveNext(new CancellationToken()))
                    {
                        funds.Add(responseStream.Current);
                    }
                    Log("fetched " + funds.Count + " assets for time since: " + timestampSince);
                }
            }
            catch (Exception ex)
            {
                Log("RPC failed for getAssetsSince: " + ex);
            }

        }

        private void Log(string s)
        {
            Console.WriteLine(s);
        }
    }
}
