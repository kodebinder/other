package com.bfm.aap.pmdx.provider.service;

import com.bfm.aap.pmdx.model.Performance;
import com.bfm.aap.pmdx.provider.util.AppConstants;
import com.bfm.aap.pmdx.services.PerformanceRequest;
import com.bfm.aap.pmdx.services.PerformanceServiceGrpc;
import com.bfm.aap.pmdx.services.PerformanceSinceRequest;
import com.google.protobuf.util.Timestamps;
import io.grpc.stub.StreamObserver;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.function.Function;

@Service
public class PerformanceServiceImpl extends PerformanceServiceGrpc.PerformanceServiceImplBase {

     private static final Logger LOGGER = LoggerFactory.getLogger(PerformanceServiceImpl.class);

    @Autowired
    private EntityReaderService entityReaderService;

    @Value("${performance-streaming-delay-millis:30000}")
    private long performanceStreamDelay;

     public void getPerformanceSince(PerformanceSinceRequest request, StreamObserver<Performance> responseObserver) {
            LOGGER.info("received getPerformanceSince request for {}", request);
        List<Performance> performanceList = entityReaderService.getEntities(Performance.class);
        LOGGER.info("responding streaming request with {} messages", performanceList!=null? performanceList.size(): 0);
        if(CollectionUtils.isNotEmpty(performanceList)){
            performanceList.stream()
                    .map(updateEntityWithTimestamp())
                    .forEach(responseObserver::onNext);
        }
        try {
            Thread.sleep(performanceStreamDelay);
        } catch (InterruptedException e) {
            LOGGER.info("streaming sleep delay interrupted", e);
        }
        responseObserver.onCompleted();
        }

     public void getPerformance(PerformanceRequest request, StreamObserver<Performance> responseObserver) {
        LOGGER.info("received getPerformance request for {}", request);
        String guid = request.getGuid();
        List<Performance> fundAssetList = entityReaderService.getEntities(Performance.class);
        Performance performance = null;
        if (CollectionUtils.isNotEmpty(fundAssetList)) {
            performance = fundAssetList.stream().filter(fa -> fa.getPerformanceId().equals(guid)).findFirst().orElse(null);
        }
        if (performance == null)
            responseObserver.onError(new Exception("Performance not found for guid:" + guid));
        else
            responseObserver.onNext(updateEntityWithTimestamp().apply(performance));
        responseObserver.onCompleted();
     }

     private Function<Performance, Performance> updateEntityWithTimestamp() {
        return fa -> {
            Performance.Builder builder = Performance.newBuilder(fa);
            builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
            return builder.build();
        };
    }
}
