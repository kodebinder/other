package com.bfm.aap.pmdx.provider.service;

import java.util.List;
import java.util.function.Function;

import com.google.protobuf.util.Timestamps;
import io.grpc.stub.StreamObserver;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.provider.util.AppConstants;
import com.bfm.aap.pmdx.services.InvestorRequest;
import com.bfm.aap.pmdx.services.InvestorServiceGrpc;

@Service
public class InvestorServiceImpl extends InvestorServiceGrpc.InvestorServiceImplBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(InvestorServiceImpl.class);

    @Autowired
    private EntityReaderService entityReaderService;

    @Value("${investor-streaming-delay-millis:30000}")
    private long investorStreamDelay;


    @Override
    public void getInvestorSince(InvestorRequest request, StreamObserver<Investor> responseObserver) {
        LOGGER.info("received getInvestorSince request for {}", request);
        List<Investor> investorList = entityReaderService.getEntities(Investor.class);

        LOGGER.info("responding streaming request with {} messages", investorList!=null? investorList.size(): 0);
        if(CollectionUtils.isNotEmpty(investorList)){
            investorList.stream().map(updateEntityWithTimestamp()).forEach(responseObserver::onNext);
        } else
            responseObserver.onError(new Exception("No investor found!"));
        try {
            Thread.sleep(investorStreamDelay);
        } catch (InterruptedException e) {
            LOGGER.info("streaming sleep delay interrupted", e);
        }
        responseObserver.onCompleted();
    }

    private Function<Investor, Investor> updateEntityWithTimestamp() {
        return fa -> {
            Investor.Builder builder = Investor.newBuilder(fa);
            builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
            return builder.build();
        };
    }
}