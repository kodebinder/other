package com.bfm.aap.pmdx.provider.service;

import java.util.List;

import com.bfm.aap.pmdx.provider.util.AppConstants;
import com.google.protobuf.Message;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bfm.aap.pmdx.model.Asset;
import com.bfm.aap.pmdx.model.BankAccount;
import com.bfm.aap.pmdx.model.BankOperation;
import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.Fundamentals;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.Performance;
import com.bfm.aap.pmdx.model.Portfolio;
import com.bfm.aap.pmdx.model.Position;
import com.bfm.aap.pmdx.model.ShareClass;
import com.bfm.aap.pmdx.model.Transaction;
import com.bfm.aap.pmdx.model.User;
import com.bfm.aap.pmdx.model.util.CompanyUtil;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.FundamentalsUtil;
import com.bfm.aap.pmdx.model.util.InvestorUtil;
import com.bfm.aap.pmdx.model.util.ModelVersion;
import com.bfm.aap.pmdx.model.util.PerformanceUtil;
import com.bfm.aap.pmdx.model.util.PositionUtil;
import com.bfm.aap.pmdx.model.util.TransactionsUtil;
import com.bfm.aap.pmdx.model.util.UserUtil;
import com.bfm.aap.pmdx.utils.adl.ADLRetryUtil;
import com.bfm.adl.ADLException;
import com.bfm.adl.ADLObject;
import com.bfm.adl.ADLRepositoryFactory;
import com.bfm.util.BFMTimestamp;

@Component
public class ADLRepository {


        private static final Logger LOGGER = LoggerFactory.getLogger(ADLRepository.class);
    public static final String UNDEFINED = "UNDEFINED";
    public static final String EFRONT = "EFRONT";
    public static final String SUCCESSFULLY_PERSISTED_ENTITY_WITH_GUID = "successfully persisted entity with guid: {}";
    private com.bfm.adl.ADLRepository dataRepo;

    public static final String VERSION = "version";
    public static final String REPO_NAME = "AlternativesDataWorkspace";
    public static final String APP_NAME = "A4A";
    public static final String GUID = "gUID";
    public static final String NETWORK_MODE = "networkMode";
    public static final String DATA_PRIMARY_INDEX = "idxPrimary";
    public static final String LAST_MODIFIED_TIME = "lastModifiedTime";
    public static final String EDX_DATA = "edxData";
    public static final String CLIENT = "client";
    public static final String ENTITY_TYPE = "entityType";
    public static final String VERSION_1 = "1.0";
    public static final byte[] EMPTY_BYTES = new byte[0];
    public static final String SOURCE = "source";
    public static final String ENTITY_ID = "entityID";
    public static final String NETWORK_MODE_VALUE = AppConstants.NETWORK_MODE.name();



    public  com.bfm.adl.ADLRepository getADLRepository() {
         try {
            return ADLRepositoryFactory.init(REPO_NAME, APP_NAME);
        } catch (ADLException e) {
            LOGGER.error("Failed to initialize ADL Repository:" + e.getMessage(), e);
        }
        return null;
    }

    public <T extends Message> String insertRecord(T entity) throws ADLException {
        ADLObject adlObject = getAdlObject(entity);
        ADLRetryUtil.runWithRetries(1, () -> dataRepo.put(adlObject));
        String guid = adlObject.getString(GUID);
        LOGGER.info(SUCCESSFULLY_PERSISTED_ENTITY_WITH_GUID, guid);
        return guid;
    }

        private <T extends Message> ADLObject getAdlObject(T message) {
        ADLObject adlObject = dataRepo.createObject();
        adlObject.set(NETWORK_MODE,NETWORK_MODE_VALUE);
        adlObject.set(LAST_MODIFIED_TIME, new BFMTimestamp());
        adlObject.set(EDX_DATA, message.toByteArray());
        adlObject.set(SOURCE,EFRONT);
        String guid = "";

        if (message instanceof Asset) {
            guid = ((Asset) message).getAssetId();
            setEntityInfo(((Asset) message).getEntityInfo(), EntityType.ASSET, adlObject);
        } else if (message instanceof Portfolio) {
            guid = ((Portfolio) message).getPortfolioId();
            setEntityInfo(((Portfolio) message).getEntityInfo(), EntityType.PORTFOLIO, adlObject);
        } else if (message instanceof Position) {
            guid = PositionUtil.getPositionGuid((Position) message);
            setEntityInfo(((Position) message).getEntityInfo(), EntityType.POSITION, adlObject);
        } else if (message instanceof Performance) {
            guid = PerformanceUtil.getPerformanceGuid((Performance) message);
            setEntityInfo(((Performance) message).getEntityInfo(), EntityType.PERFORMANCE, adlObject);
        } /*else if (message instanceof Issuer) {
            guid = ((Issuer) message).getIssuerId();
            setEntityInfo(((Issuer) message).getEntityInfo(), EntityType.ISSUER, adlObject);
        }*/ else if (message instanceof Fundamentals) {
            guid = FundamentalsUtil.getFundamentalsGuid((Fundamentals) message);
            setEntityInfo(((Fundamentals) message).getEntityInfo(), EntityType.FUNDAMENTALS, adlObject);
        } else if (message instanceof Transaction) {
            guid = TransactionsUtil.getTransactionGuid((Transaction) message);
            setEntityInfo(((Transaction) message).getEntityInfo(), EntityType.TRANSACTION, adlObject);
        } /*else if (message instanceof Instrument) {
       	    guid = ((Instrument) message).getAssetId();
            setEntityInfo(((Instrument) message).getEntityInfo(), EntityType.INSTRUMENT, adlObject);
        }*/ else if (message instanceof BankAccount) {
       	    guid = ((BankAccount) message).getEntityBankAccountId();
            setEntityInfo(((BankAccount) message).getEntityInfo(), EntityType.BANK_ACCOUNT, adlObject);
        } else if (message instanceof BankOperation) {
       	    guid = ((BankOperation) message).getBankOperationId();
            setEntityInfo(((BankOperation) message).getEntityInfo(), EntityType.BANK_OPERATION, adlObject);
        } else if (message instanceof User) {
            guid = UserUtil.getUserGuid((User) message);
            setEntityInfo(((User) message).getEntityInfo(), EntityType.USER, adlObject);
        }/* else if (message instanceof Contact) {
            guid = ContactUtil.getContactGuid((Contact) message);
            setEntityInfo(((Contact) message).getEntityInfo(), EntityType.CONTACT, adlObject);
        } */else if (message instanceof Company) {
            guid = CompanyUtil.getCompanyGuid((Company) message);
            setEntityInfo(((Company) message).getEntityInfo(), EntityType.COMPANY, adlObject);
        } else if (message instanceof Investor) {
            guid = InvestorUtil.getInvestorGuid((Investor) message);
            setEntityInfo(((Investor) message).getEntityInfo(), EntityType.INVESTOR, adlObject);
        } else if (message instanceof ShareClass) {
            guid = ((ShareClass) message).getShareclassId();
            setEntityInfo(((ShareClass) message).getEntityInfo(), EntityType.SHARECLASS, adlObject);
        } else
            throw new IllegalArgumentException("Invalid entity type!");

        adlObject.set(GUID, guid);
        return adlObject;
    }

    private <T extends Message> void setEntityInfo(EntityInfo entityInfo, EntityType entityType, ADLObject adlObject) {
        adlObject.set(CLIENT, entityInfo.getClientName());
        adlObject.set(ENTITY_TYPE, entityType.name());
        String version = entityInfo.getModelVersion();
        version = (version.equals(UNDEFINED) || StringUtils.isEmpty(version)) ? ModelVersion.getVersion() : version;
        adlObject.set(VERSION, version);
    }


    public <T extends Message> String insertRecord(T entity, String source, String clientName) throws ADLException {
        ADLObject adlObject = getAdlObject(entity);
        adlObject.set(SOURCE, source);
        adlObject.set(CLIENT, clientName);
        ADLRetryUtil.runWithRetries(1, () -> dataRepo.put(adlObject));
        String guid = adlObject.getString(GUID);
        LOGGER.info(SUCCESSFULLY_PERSISTED_ENTITY_WITH_GUID, guid);
        return guid;
    }


    @Autowired
    EntityReaderService entityReaderService;


    public void insertManualRecords(){
        dataRepo = getADLRepository();
        try{

        List<BankAccount> fundBankAccountList = entityReaderService.getEntities(BankAccount.class);
        List<Portfolio> portfolioList = entityReaderService.getEntities(Portfolio.class);
        List<Investor> investors = entityReaderService.getEntities(Investor.class);

            List<ShareClass> shareClassList = entityReaderService.getEntities(ShareClass.class);
            List<BankOperation> bankOperations = entityReaderService.getEntities(BankOperation.class);

            investors.forEach(investor -> {
                try {
                    LOGGER.info("Investor id {}", investor.getInvestorId());

                    insertRecord(investor);
                } catch (ADLException e) {
                    e.printStackTrace();
                }
            });

            shareClassList.forEach(shareClass -> {
                try {
                    LOGGER.info("shareClass id {}", shareClass.getShareclassId());
                    insertRecord(shareClass);
                } catch (ADLException e) {
                    e.printStackTrace();
                }
            });

            bankOperations.forEach(bankOperation -> {
                try {
                    LOGGER.info("bankOperation id {}", bankOperation.getBankOperationId());
                    insertRecord(bankOperation);
                } catch (ADLException e) {
                    e.printStackTrace();
                }
            });

        }catch (Exception ex){
            ex.printStackTrace();
        }

    }



}
