package com.bfm.aap.pmdx.provider.service;

import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.provider.util.AppConstants;
import com.bfm.aap.pmdx.services.ContactRequest;
import com.bfm.aap.pmdx.services.ContactServiceGrpc.ContactServiceImplBase;
import com.google.protobuf.util.Timestamps;
import io.grpc.stub.StreamObserver;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.function.Function;

@Service
public class ContactServiceImpl extends ContactServiceImplBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(ContactServiceImpl.class);

    @Autowired
    private EntityReaderService entityReaderService;

    @Value("${contact-streaming-delay-millis:30000}")
    private long contactsStreamDelay;

    @Override
    public void getContactSince(ContactRequest request, StreamObserver<Contact> responseObserver) {
        LOGGER.info("received getContactSince request for {}", request);
        List<Contact> contactList = this.entityReaderService.getEntities(Contact.class);
        LOGGER.info("responding streaming request with {} messages", contactList != null ? contactList.size() : 0);
        if (CollectionUtils.isNotEmpty(contactList)) {
            contactList.stream()
                .map(this.updateEntityWithTimestamp())
                .forEach(responseObserver::onNext);
        }
        try {
            Thread.sleep(this.contactsStreamDelay);
        } catch (InterruptedException e) {
            LOGGER.info("streaming sleep delay interrupted", e);
        }
        responseObserver.onCompleted();
    }

    private Function<Contact, Contact> updateEntityWithTimestamp() {
        return fu -> {
            Contact.Builder builder = Contact.newBuilder(fu);
            builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
            return builder.build();
        };
    }
}
