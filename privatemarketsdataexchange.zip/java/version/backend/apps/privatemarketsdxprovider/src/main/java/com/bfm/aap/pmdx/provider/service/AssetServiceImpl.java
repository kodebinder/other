package com.bfm.aap.pmdx.provider.service;

import com.bfm.aap.pmdx.model.Asset;
import com.bfm.aap.pmdx.provider.util.AppConstants;
import com.bfm.aap.pmdx.services.AssetRequest;
import com.bfm.aap.pmdx.services.AssetServiceGrpc;
import com.bfm.aap.pmdx.services.AssetsSinceRequest;
import com.google.protobuf.util.Timestamps;
import io.grpc.stub.StreamObserver;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.function.Function;

@Service
public class AssetServiceImpl extends AssetServiceGrpc.AssetServiceImplBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(AssetServiceImpl.class);

    @Autowired
    private EntityReaderService entityReaderService;

    @Value("${asset-streaming-delay-millis:30000}")
    private long assetsStreamDelay;

    @Override
    public void getAssetsSince(AssetsSinceRequest request, StreamObserver<Asset> responseObserver) {
        LOGGER.info("received getAssetsSince request for {}", request);
        List<Asset> fundAssetList = entityReaderService.getEntities(Asset.class);
        LOGGER.info("responding streaming request with {} messages", fundAssetList!=null? fundAssetList.size(): 0);
        if(CollectionUtils.isNotEmpty(fundAssetList)){
            fundAssetList.stream()
                    .map(updateEntityWithTimestamp())
                    .forEach(responseObserver::onNext);
        }
        try {
            Thread.sleep(assetsStreamDelay);
        } catch (InterruptedException e) {
            LOGGER.info("streaming sleep delay interrupted", e);
        }
        responseObserver.onCompleted();
    }

    @Override
    public void getAsset(AssetRequest request, StreamObserver<Asset> responseObserver) {
        LOGGER.info("received getFundAsset request for {}", request);
        String guid = request.getGuid();
        List<Asset> fundAssetList = entityReaderService.getEntities(Asset.class);
        Asset asset = null;
        if (CollectionUtils.isNotEmpty(fundAssetList)) {
            asset = fundAssetList.stream().filter(fa -> fa.getAssetId().equals(guid)).findFirst().orElse(null);
        }
        if (asset == null)
            responseObserver.onError(new Exception("Asset not found for guid:" + guid));
        else
            responseObserver.onNext(updateEntityWithTimestamp().apply(asset));
        responseObserver.onCompleted();
    }

    private Function<Asset, Asset> updateEntityWithTimestamp() {
        return fa -> {
            Asset.Builder builder = Asset.newBuilder(fa);
            builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
            return builder.build();
        };
    }

}
