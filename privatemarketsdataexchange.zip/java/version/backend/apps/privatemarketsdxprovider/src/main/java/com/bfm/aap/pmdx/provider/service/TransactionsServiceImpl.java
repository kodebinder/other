package com.bfm.aap.pmdx.provider.service;

import com.bfm.aap.pmdx.model.Transaction;
import com.bfm.aap.pmdx.provider.util.AppConstants;
import com.bfm.aap.pmdx.services.TransactionRequest;
import com.bfm.aap.pmdx.services.TransactionServiceGrpc;
import com.bfm.aap.pmdx.services.TransactionsSinceRequest;
import com.google.protobuf.util.Timestamps;
import io.grpc.stub.StreamObserver;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.util.List;
import java.util.function.Function;

@Service
public class TransactionsServiceImpl extends TransactionServiceGrpc.TransactionServiceImplBase{

    private static final Logger LOGGER = LoggerFactory.getLogger(TransactionsServiceImpl.class);

    @Autowired
    private EntityReaderService entityReaderService;

    @Value("${transactions-streaming-delay-millis:30000}")
    private long transactionsStreamDelay;

    @Override
    public void getTransactionsSince(TransactionsSinceRequest request, StreamObserver<Transaction> responseObserver) {
        LOGGER.info("received getTransactionsSince request for {}", request);
        List<Transaction> transactionList = entityReaderService.getEntities(Transaction.class);
        LOGGER.info("responding streaming request with {} messages", CollectionUtils.isNotEmpty(transactionList)? transactionList.size(): 0);
        if(CollectionUtils.isNotEmpty(transactionList)){
            transactionList.stream()
                    .map(updateEntityWithTimestamp())
                    .forEach(responseObserver::onNext);
        }
        try {
            Thread.sleep(transactionsStreamDelay);
        } catch (InterruptedException e) {
            LOGGER.info("streaming sleep delay interrupted", e);
        }
        responseObserver.onCompleted();
    }

    @Override
    public void getTransaction(TransactionRequest request, StreamObserver<Transaction> responseObserver) {
        LOGGER.info("received getTransaction request for {}", request);
        String guid = request.getGuid();
        List<Transaction> transactionList = entityReaderService.getEntities(Transaction.class);
        Transaction transaction = null;
        if (CollectionUtils.isNotEmpty(transactionList)) {
            transaction = transactionList.stream().filter(fa -> fa.getGuid().equals(guid)).findFirst().orElse(null);
        }
        if (ObjectUtils.isEmpty(transaction))
            responseObserver.onError(new Exception("Transactions not found for guid:" + guid));
        else
            responseObserver.onNext(updateEntityWithTimestamp().apply(transaction));
        responseObserver.onCompleted();
    }

    private Function<Transaction, Transaction> updateEntityWithTimestamp() {
        return fa -> {
            Transaction.Builder builder = Transaction.newBuilder(fa);
            builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
            return builder.build();
        };
    }

}
