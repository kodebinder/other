package com.bfm.aap.pmdx.provider.util;

import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.model.util.NetworkModeHelper;
import org.apache.commons.lang3.StringUtils;

public final class AppConstants {

    public static final String SERVER_MODE = StringUtils.defaultIfEmpty(System.getProperty("mode"),"blue");
    public static final NetworkMode NETWORK_MODE = NetworkModeHelper.getNetworkModeFromString(SERVER_MODE);

    private AppConstants() {}
}
