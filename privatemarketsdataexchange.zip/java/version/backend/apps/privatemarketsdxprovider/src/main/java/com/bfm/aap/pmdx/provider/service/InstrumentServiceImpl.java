package com.bfm.aap.pmdx.provider.service;

import java.util.List;
import java.util.function.UnaryOperator;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.bfm.aap.pmdx.model.Instrument;
import com.bfm.aap.pmdx.provider.util.AppConstants;
import com.bfm.aap.pmdx.services.InstrumentRequest;
import com.bfm.aap.pmdx.services.InstrumentServiceGrpc;
import com.bfm.aap.pmdx.services.InstrumentsSinceRequest;
import com.google.protobuf.util.Timestamps;

import io.grpc.stub.StreamObserver;

@Service
public class InstrumentServiceImpl extends InstrumentServiceGrpc.InstrumentServiceImplBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(InstrumentServiceImpl.class);

    @Autowired
    private EntityReaderService entityReaderService;

    @Value("${instrument-streaming-delay-millis:30000}")
    private long instrumentsStreamDelay;

    @Override
    public void getInstrumentsSince(InstrumentsSinceRequest request, StreamObserver<Instrument> responseObserver) {
        LOGGER.info("received getInstrumentsSince request for {}", request);
        List<Instrument> instrumentList = entityReaderService.getEntities(Instrument.class);
        LOGGER.info("responding streaming request with {} messages", instrumentList!=null? instrumentList.size(): 0);
        if(CollectionUtils.isNotEmpty(instrumentList)){
            instrumentList.stream()
                    .map(updateEntityWithTimestamp())
                    .forEach(responseObserver::onNext);
        }
        try {
            Thread.sleep(instrumentsStreamDelay);
        } catch (InterruptedException e) {
            LOGGER.info("streaming sleep delay interrupted", e);
        }
        responseObserver.onCompleted();
    }

    @Override
    public void getInstrument(InstrumentRequest request, StreamObserver<Instrument> responseObserver) {
        LOGGER.info("received getinstrument request for {}", request);
        String guid = request.getGuid();
        List<Instrument> instrumentList = entityReaderService.getEntities(Instrument.class);
        Instrument instrument = null;
        if (CollectionUtils.isNotEmpty(instrumentList)) {
            instrument = instrumentList.stream().filter(fa -> fa.getAssetId().equals(guid)).findFirst().orElse(null);
        }
        if (ObjectUtils.isEmpty(instrument)	)
            responseObserver.onError(new Exception("Instrument not found for guid:" + guid));
        else
            responseObserver.onNext(updateEntityWithTimestamp().apply(instrument));
        responseObserver.onCompleted();
    }

    private UnaryOperator<Instrument> updateEntityWithTimestamp() {
        return fa -> {
            Instrument.Builder builder = Instrument.newBuilder(fa);
            builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
            return builder.build();
        };
    }

}
