package com.bfm.aap.pmdx.provider.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.google.protobuf.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bfm.aap.pmdx.model.Asset;
import com.bfm.aap.pmdx.model.BankAccount;
import com.bfm.aap.pmdx.model.BankOperation;
import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.Fundamentals;
import com.bfm.aap.pmdx.model.Instrument;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.Performance;
import com.bfm.aap.pmdx.model.Portfolio;
import com.bfm.aap.pmdx.model.Position;
import com.bfm.aap.pmdx.model.ShareClass;
import com.bfm.aap.pmdx.model.Transaction;
import com.bfm.aap.pmdx.model.User;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.bfm.aap.pmdx.utils.gson.ProtoAdapter;

@Service
public class EntityReaderService {

    private static final Logger LOGGER = LoggerFactory.getLogger(EntityReaderService.class);
    public final Map<Class, List<? extends Message>> messageMap = new ConcurrentHashMap<>();
    private final Gson gson;

    @Value("${asset-file-path}")
    private String assetsFilePath;

    @Value("${portfolio-file-path}")
    private String portfolioFilePath;

    @Value("${position-file-path}")
    private String positionFilePath;

    @Value("${performance-file-path}")
    private String performanceFilePath;

    @Value("${issuer-file-path}")
    private String issuerFilePath;

    @Value("${fundamentals-file-path}")
    private String fundamentalsFilePath;

    @Value("${user-file-path}")
    private String userFilePath;

    @Value("${contact-file-path}")
    private String contactFilePath;

    @Value("${company-file-path}")
    private String companyFilePath;

    @Value("${transaction-file-path}")
    private String transactionFilePath;
    
    @Value("${instrument-file-path}")
    private String instrumentFilePath;

    @Value("${bankAccount-file-path}")
    private String bankAccountFilePath;

    @Value("${bankOperation-file-path}")
    private String bankOperationFilePath;

    @Value("${investor-file-path}")
    private String investorFilePath;

    @Value("${shareClass-file-path}")
    private String shareClassFilePath;

    public EntityReaderService() {
        GsonBuilder gsonBuilder = new GsonBuilder();
        ProtoAdapter.addTypeRegistry(EntityInfo.class);
        gson = gsonBuilder.registerTypeAdapter(Asset.class, new ProtoAdapter(Asset.class))
            .registerTypeAdapter(Portfolio.class, new ProtoAdapter(Portfolio.class))
            .registerTypeAdapter(Performance.class, new ProtoAdapter(Performance.class))
            .registerTypeAdapter(Fundamentals.class, new ProtoAdapter(Fundamentals.class))
            .registerTypeAdapter(Position.class, new ProtoAdapter(Position.class))
            .registerTypeAdapter(User.class, new ProtoAdapter(User.class))
            .registerTypeAdapter(Contact.class, new ProtoAdapter(Contact.class))
            .registerTypeAdapter(Company.class, new ProtoAdapter(Company.class))
            .registerTypeAdapter(Transaction.class, new ProtoAdapter(Transaction.class))
            .registerTypeAdapter(Instrument.class, new ProtoAdapter(Instrument.class))
            .registerTypeAdapter(Investor.class, new ProtoAdapter(Investor.class))
            .registerTypeAdapter(BankAccount.class, new ProtoAdapter(BankAccount.class))
            .registerTypeAdapter(BankOperation.class, new ProtoAdapter(BankOperation.class))
            .registerTypeAdapter(ShareClass.class, new ProtoAdapter(ShareClass.class))
            .create();
    }

    @PostConstruct
    public void init() throws IOException {
        LOGGER.info("Reading assets file: {}, portfolio file: {}, positions file: {}, performance file: {}, issuer file: {}, fundamentals file: {}, user file: {}, contact file: {}, company file: {}, transactions file:{}, instrument file:{}, bankAccount file:{}, bankOperation file:{}, shareClass file:{}",
            assetsFilePath, portfolioFilePath, positionFilePath, performanceFilePath, issuerFilePath, fundamentalsFilePath, userFilePath, contactFilePath, companyFilePath, transactionFilePath, instrumentFilePath, bankAccountFilePath, bankOperationFilePath, shareClassFilePath);

        List<Asset> fundAssets = parseEntities(Asset.class);
        List<Portfolio> portfolios = parseEntities(Portfolio.class);
        List<Performance> performance = parseEntities(Performance.class);
        List<Position> positions = parseEntities(Position.class);
        List<Fundamentals> fundamentals = parseEntities(Fundamentals.class);
        List<User> users = parseEntities(User.class);
        List<Contact> contacts = parseEntities(Contact.class);
        List<Company> companies = parseEntities(Company.class);
        List<Transaction> transactions = parseEntities(Transaction.class);
        List<Instrument> instrument = parseEntities(Instrument.class);
        List<BankAccount> bankAccounts = parseEntities(BankAccount.class);
        List<BankOperation> bankOperations = parseEntities(BankOperation.class);
        List<Investor> investors = parseEntities(Investor.class);
        List<ShareClass> shareClasses = parseEntities(ShareClass.class);

        messageMap.put(Asset.class, fundAssets);
        messageMap.put(Portfolio.class, portfolios);
        messageMap.put(Performance.class, performance);
        messageMap.put(Position.class, positions);
        messageMap.put(Fundamentals.class, fundamentals);
        messageMap.put(User.class, users);
        messageMap.put(Contact.class, contacts);
        messageMap.put(Company.class, companies);
        messageMap.put(Transaction.class, transactions);
        messageMap.put(Instrument.class, instrument);
        messageMap.put(BankAccount.class, bankAccounts);
        messageMap.put(BankOperation.class, bankOperations);
        messageMap.put(Investor.class, investors);
        messageMap.put(ShareClass.class, shareClasses);

        LOGGER.info("Read: {}", messageMap.entrySet().stream().map(entry -> String.format("%s - %s results", entry.getKey().getSimpleName(), entry.getValue().size())).collect(Collectors.joining(", ")));
    }

    @SuppressWarnings("unchecked")
    public <T extends Message> List<T> getEntities(Class<T> clazz) {
        return (List<T>) messageMap.get(clazz);
    }

    private <T extends Message> List<T> parseEntities(Class<T> clazz) throws IOException {
        if (clazz.isAssignableFrom(Asset.class)) {
            String content = getFileContentFromResources(assetsFilePath);
            Type listType = new TypeToken<List<Asset>>() {}.getType();
            return gson.fromJson(content, listType);
        } else if (clazz.isAssignableFrom(Portfolio.class)) {
            String content = getFileContentFromResources(portfolioFilePath);
            Type listType = new TypeToken<List<Portfolio>>() {}.getType();
            return gson.fromJson(content, listType);
        } else if (clazz.isAssignableFrom(Position.class)) {
            String content = getFileContentFromResources(positionFilePath);
            Type listType = new TypeToken<List<Position>>() {}.getType();
            return gson.fromJson(content, listType);
        } else if (clazz.isAssignableFrom(Performance.class)) {
            String content = getFileContentFromResources(performanceFilePath);
            Type listType = new TypeToken<List<Performance>>() {}.getType();
            return gson.fromJson(content, listType);
        } else if (clazz.isAssignableFrom(Fundamentals.class)) {
            String content = getFileContentFromResources(fundamentalsFilePath);
            Type listType = new TypeToken<List<Fundamentals>>() {}.getType();
            return gson.fromJson(content, listType);
        } else if (clazz.isAssignableFrom(User.class)) {
            String content = getFileContentFromResources(userFilePath);
            Type listType = new TypeToken<List<User>>() {}.getType();
            return gson.fromJson(content, listType);
        } else if (clazz.isAssignableFrom(Contact.class)) {
            String content = getFileContentFromResources(contactFilePath);
            Type listType = new TypeToken<List<Contact>>() {}.getType();
            return gson.fromJson(content, listType);
        } else if (clazz.isAssignableFrom(Company.class)) {
            String content = getFileContentFromResources(companyFilePath);
            Type listType = new TypeToken<List<Company>>() {}.getType();
            return gson.fromJson(content, listType);
        } else if (clazz.isAssignableFrom(Transaction.class)) {
            String content = getFileContentFromResources(transactionFilePath);
            Type listType = new TypeToken<List<Transaction>>() {}.getType();
            return gson.fromJson(content, listType);
        } else if (clazz.isAssignableFrom(Instrument.class)) {
            String content = getFileContentFromResources(instrumentFilePath);
            Type listType = new TypeToken<List<Instrument>>() {}.getType();
            return gson.fromJson(content, listType);
        } else if (clazz.isAssignableFrom(BankAccount.class)) {
            String content = getFileContentFromResources(bankAccountFilePath);
            Type listType = new TypeToken<List<BankAccount>>() {}.getType();
            return gson.fromJson(content, listType);
        } else if (clazz.isAssignableFrom(BankOperation.class)) {
            String content = getFileContentFromResources(bankOperationFilePath);
            Type listType = new TypeToken<List<BankOperation>>() {}.getType();
            return gson.fromJson(content, listType);
        }else if (clazz.isAssignableFrom(Investor.class)) {
            String content = getFileContentFromResources(investorFilePath);
            Type listType = new TypeToken<List<Investor>>() {}.getType();
            return gson.fromJson(content, listType);
        } else if (clazz.isAssignableFrom(ShareClass.class)) {
            String content = getFileContentFromResources(shareClassFilePath);
            Type listType = new TypeToken<List<ShareClass>>() {}.getType();
            return gson.fromJson(content, listType);
        } else
            return Collections.emptyList();
    }

    private String getFileContentFromResources(String fileName) {
        try (InputStream inputStream = getClass().getResourceAsStream(fileName)) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            return reader.lines().collect(Collectors.joining(System.lineSeparator()));
        } catch (Exception e) {
            LOGGER.error("Failed to read file {}", fileName, e);
            throw new RuntimeException(e.getMessage());
        }
    }
}
