package com.bfm.aap.pmdx.provider;

import com.bfm.aap.pmdx.provider.service.ADLRepository;
import com.bfm.aap.pmdx.provider.service.GRPCServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.event.EventListener;

import java.io.IOException;

import static com.bfm.aap.pmdx.provider.util.AppConstants.NETWORK_MODE;


@SpringBootConfiguration
@ComponentScan
@PropertySources({ @PropertySource(value = "classpath:PrivateMarketsDxProvider.properties", ignoreResourceNotFound = true) })
public class PrivateMarketsDXProvider {
    private static final Logger LOGGER = LoggerFactory.getLogger(PrivateMarketsDXProvider.class);

    @Autowired
    private GRPCServer grpcServer;

    @Autowired
    private ADLRepository adlRepository;


    public static void main(String[] args) throws InterruptedException {
        LOGGER.info("Starting PrivateMarketsDXProvider.. NetworkMode:{}", NETWORK_MODE);
        ConfigurableApplicationContext applicationContext = SpringApplication.run(PrivateMarketsDXProvider.class, args);
        applicationContext.registerShutdownHook();



        //Keep the main thread awake until the grpc server shutsdown
        Thread.sleep(10000);
        GRPCServer grpcServer = applicationContext.getBean(GRPCServer.class);
        grpcServer.getTerminatedLatch().await();
    }

    @EventListener(ApplicationReadyEvent.class)
    public void onApplicationStartup() throws IOException {
        grpcServer.startServer();
        adlRepository.insertManualRecords();
        LOGGER.info("PrivateMarketsDXProvider started... Started {} services...", grpcServer.getServices().size());
        addShutDownHook();
    }

    /**
     * Add graceful shut down hook to deregister services.
     */
    private void addShutDownHook() {
        //Register shutdown hook for channel and listeners
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            LOGGER.info("Private markets DX provider Server shutting down...");
            grpcServer.stopServer();
        }));
        LOGGER.info("Graceful shutdown deregistration hook is installed.");
    }

}
