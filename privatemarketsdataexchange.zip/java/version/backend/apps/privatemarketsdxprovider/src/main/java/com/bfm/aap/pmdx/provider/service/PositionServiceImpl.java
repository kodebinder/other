package com.bfm.aap.pmdx.provider.service;

import com.bfm.aap.pmdx.model.Position;
import com.bfm.aap.pmdx.model.util.PositionUtil;
import com.bfm.aap.pmdx.provider.util.AppConstants;
import com.bfm.aap.pmdx.services.PositionRequest;
import com.bfm.aap.pmdx.services.PositionServiceGrpc;
import com.bfm.aap.pmdx.services.PositionsSinceRequest;
import com.google.protobuf.util.Timestamps;
import io.grpc.stub.StreamObserver;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.function.Function;

@Service
public class PositionServiceImpl extends PositionServiceGrpc.PositionServiceImplBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(PositionServiceImpl.class);

    @Autowired
    private EntityReaderService entityReaderService;

    @Value("${position-streaming-delay-millis:30000}")
    private long positionsStreamDelay;

    @Override
    public void getPositionsSince(PositionsSinceRequest request, StreamObserver<Position> responseObserver) {
        LOGGER.info("received getPositionsSince request for {}", request);
        List<Position> positionList = entityReaderService.getEntities(Position.class);
        LOGGER.info("responding streaming request with {} messages", positionList!=null? positionList.size(): 0);
        if(CollectionUtils.isNotEmpty(positionList)){
            positionList.stream().map(updateEntityWithTimestamp()).forEach(responseObserver::onNext);
        }
        try {
            Thread.sleep(positionsStreamDelay);
        } catch (InterruptedException e) {
            LOGGER.info("streaming sleep delay interrupted", e);
        }
        responseObserver.onCompleted();
    }

    @Override
    public void getPosition(PositionRequest request, StreamObserver<Position> responseObserver) {
        LOGGER.info("received getPosition request for {}", request);
        String guid = request.getGuid();
        List<Position> positionList = entityReaderService.getEntities(Position.class);
        Position position = null;
        if (CollectionUtils.isNotEmpty(positionList)) {
            position = positionList.stream().filter(pos -> PositionUtil.getPositionGuid(pos).equals(guid)).findFirst().orElse(null);
        }
        if (position == null)
            responseObserver.onError(new Exception("Position not found for guid:" + guid));
        else
            responseObserver.onNext(updateEntityWithTimestamp().apply(position));
        responseObserver.onCompleted();
    }

    private Function<Position, Position> updateEntityWithTimestamp() {
        return fa -> {
            Position.Builder builder = Position.newBuilder(fa);
            builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
            return builder.build();
        };
    }
}
