package com.bfm.aap.pmdx.provider.service;

import com.bfm.aap.pmdx.model.BankAccount;
import com.bfm.aap.pmdx.provider.util.AppConstants;
import com.bfm.aap.pmdx.services.BankAccountRequest;
import com.bfm.aap.pmdx.services.BankAccountServiceGrpc;
import com.bfm.aap.pmdx.services.BankAccountsSinceRequest;
import com.google.protobuf.util.Timestamps;
import io.grpc.stub.StreamObserver;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.function.Function;

@Service
public class BankAccountServiceImpl extends BankAccountServiceGrpc.BankAccountServiceImplBase {
    
   private static final Logger LOGGER = LoggerFactory.getLogger(BankAccountServiceImpl.class);

    @Autowired
    private EntityReaderService entityReaderService;

    
    @Value("${bankAccount-streaming-delay-millis:30000}")
    private long bankAccountsStreamDelay;
    

    @Override
    public void getBankAccountsSince(BankAccountsSinceRequest request, StreamObserver<BankAccount> responseObserver) {
        LOGGER.info("received getBankAccountsSince request for {}", request);
        List<BankAccount> bankAccountList = entityReaderService.getEntities(BankAccount.class);
        LOGGER.info("responding streaming request with {} messages", bankAccountList!=null? bankAccountList.size(): 0);
        if(CollectionUtils.isNotEmpty(bankAccountList)){
            bankAccountList.stream()
                    .map(updateEntityWithTimestamp())
                    .forEach(responseObserver::onNext);
        }
        try {
            Thread.sleep(bankAccountsStreamDelay);
        } catch (InterruptedException e) {
            LOGGER.info("streaming sleep delay interrupted", e);
        }
        responseObserver.onCompleted();
    }

    @Override
    public void getBankAccount(BankAccountRequest request, StreamObserver<BankAccount> responseObserver) {
        LOGGER.info("received getBankAccount request for {}", request);
        String guid = request.getGuid();
        List<BankAccount> fundBankAccountList = entityReaderService.getEntities(BankAccount.class);
        BankAccount bankAccount = null;
        if (CollectionUtils.isNotEmpty(fundBankAccountList)) {
            bankAccount = fundBankAccountList.stream().filter(fa -> fa.getEntityBankAccountId().equals(guid)).findFirst().orElse(null);
        }
        if (bankAccount == null)
            responseObserver.onError(new Exception("BankAccount not found for guid:" + guid));
        else
            responseObserver.onNext(updateEntityWithTimestamp().apply(bankAccount));
        responseObserver.onCompleted();
    }

    private Function<BankAccount, BankAccount> updateEntityWithTimestamp() {
        return fa -> {
            BankAccount.Builder builder = BankAccount.newBuilder(fa);
            builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
            return builder.build();
        };
    }

}
