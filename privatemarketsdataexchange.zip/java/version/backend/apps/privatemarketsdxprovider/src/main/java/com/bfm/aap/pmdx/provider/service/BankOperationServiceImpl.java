package com.bfm.aap.pmdx.provider.service;

import com.bfm.aap.pmdx.model.BankOperation;
import com.bfm.aap.pmdx.provider.util.AppConstants;
import com.bfm.aap.pmdx.services.BankOperationRequest;
import com.bfm.aap.pmdx.services.BankOperationServiceGrpc;
import com.bfm.aap.pmdx.services.BankOperationsSinceRequest;
import com.google.protobuf.util.Timestamps;
import io.grpc.stub.StreamObserver;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.function.Function;

@Service
public class BankOperationServiceImpl extends BankOperationServiceGrpc.BankOperationServiceImplBase {
       private static final Logger LOGGER = LoggerFactory.getLogger(BankOperationServiceImpl.class);

    @Autowired
    private EntityReaderService entityReaderService;

    
    @Value("${bankOperation-streaming-delay-millis:30000}")
    private long bankOperationsStreamDelay;
    

    @Override
    public void getBankOperationsSince(BankOperationsSinceRequest request, StreamObserver<BankOperation> responseObserver) {
        LOGGER.info("received getBankOperationsSince request for {}", request);
        List<BankOperation> bankOperationList = entityReaderService.getEntities(BankOperation.class);
        LOGGER.info("responding streaming request with {} messages", bankOperationList!=null? bankOperationList.size(): 0);
        if(CollectionUtils.isNotEmpty(bankOperationList)){
            bankOperationList.stream()
                    .map(updateEntityWithTimestamp())
                    .forEach(responseObserver::onNext);
        }
        try {
            Thread.sleep(bankOperationsStreamDelay);
        } catch (InterruptedException e) {
            LOGGER.info("streaming sleep delay interrupted", e);
        }
        responseObserver.onCompleted();
    }

    @Override
    public void getBankOperation(BankOperationRequest request, StreamObserver<BankOperation> responseObserver) {
        LOGGER.info("received getBankOperation request for {}", request);
        String guid = request.getGuid();
        List<BankOperation> fundBankOperationList = entityReaderService.getEntities(BankOperation.class);
        BankOperation bankOperation = null;
        if (CollectionUtils.isNotEmpty(fundBankOperationList)) {
            bankOperation = fundBankOperationList.stream().filter(fa -> fa.getBankOperationId().equals(guid)).findFirst().orElse(null);
        }
        if (bankOperation == null)
            responseObserver.onError(new Exception("BankOperation not found for guid:" + guid));
        else
            responseObserver.onNext(updateEntityWithTimestamp().apply(bankOperation));
        responseObserver.onCompleted();
    }

    private Function<BankOperation, BankOperation> updateEntityWithTimestamp() {
        return fa -> {
            BankOperation.Builder builder = BankOperation.newBuilder(fa);
            builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
            return builder.build();
        };
    }

}
