package com.bfm.aap.pmdx.provider.service;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import javax.annotation.PostConstruct;

import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.ServerInterceptors;
import io.grpc.ServerServiceDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bfm.aap.pmdx.model.Asset;
import com.bfm.aap.pmdx.model.BankAccount;
import com.bfm.aap.pmdx.model.BankOperation;
import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.Fundamentals;
import com.bfm.aap.pmdx.model.Instrument;
import com.bfm.aap.pmdx.model.Performance;
import com.bfm.aap.pmdx.model.Portfolio;
import com.bfm.aap.pmdx.model.Position;
import com.bfm.aap.pmdx.model.ShareClass;
import com.bfm.aap.pmdx.model.User;

@Service
public class GRPCServer {

    private static final Logger LOGGER = LoggerFactory.getLogger(GRPCServer.class);
    private Server server;
    private final CountDownLatch terminatedLatch = new CountDownLatch(1);

    @Value("${connection.port}")
    private int port;

    @Autowired
    private AssetServiceImpl assetService;

    @Autowired
    private PortfolioServiceImpl portfolioService;

    @Autowired
    private PositionServiceImpl positionService;

    @Autowired
    private PerformanceServiceImpl performanceService;

    @Autowired
    private FundamentalsServiceImpl fundamentalsService;

    @Autowired
    private UserServiceImpl userService;

    @Autowired
    private ContactServiceImpl contactService;

    @Autowired
    private CompanyServiceImpl companyService;

    @Autowired
    private InstrumentServiceImpl instrumentService;

    @Autowired
    private BankAccountServiceImpl bankAccountService;

    @Autowired
    private BankOperationServiceImpl bankOperationService;

    @Autowired
    private ShareClassServiceImpl shareClassService;

    
    @PostConstruct
    public void initServer() {
        this.server = ServerBuilder.forPort(port)
            .addService(ServerInterceptors.intercept(assetService, new BasicAuthenticationInterceptor(Asset.class.getSimpleName())))
            .addService(ServerInterceptors.intercept(portfolioService, new BasicAuthenticationInterceptor(Portfolio.class.getSimpleName())))
            .addService(ServerInterceptors.intercept(performanceService, new BasicAuthenticationInterceptor(Performance.class.getSimpleName())))
            .addService(ServerInterceptors.intercept(fundamentalsService, new BasicAuthenticationInterceptor(Fundamentals.class.getSimpleName())))
            .addService(ServerInterceptors.intercept(positionService, new BasicAuthenticationInterceptor(Position.class.getSimpleName())))
            .addService(ServerInterceptors.intercept(userService, new BasicAuthenticationInterceptor(User.class.getSimpleName())))
            .addService(ServerInterceptors.intercept(contactService, new BasicAuthenticationInterceptor(Contact.class.getSimpleName())))
            .addService(ServerInterceptors.intercept(companyService, new BasicAuthenticationInterceptor(Company.class.getSimpleName())))
            .addService(ServerInterceptors.intercept(instrumentService, new BasicAuthenticationInterceptor(Instrument.class.getSimpleName())))
            .addService(ServerInterceptors.intercept(bankAccountService, new BasicAuthenticationInterceptor(BankAccount.class.getSimpleName())))
            .addService(ServerInterceptors.intercept(bankOperationService, new BasicAuthenticationInterceptor(BankOperation.class.getSimpleName())))
            .addService(ServerInterceptors.intercept(shareClassService, new BasicAuthenticationInterceptor(ShareClass.class.getSimpleName())))
            .build();
    }

    public List<ServerServiceDefinition> getServices() {
        return server.getServices();
    }

    public void startServer() throws IOException {
        LOGGER.info("Starting grpc server on port: {}", port);
        this.server.start();
        LOGGER.info("Grpc server started...");
    }

    public void stopServer() {
        LOGGER.info("Stopping grpc server...");
        server.shutdownNow();
        terminatedLatch.countDown();
    }

    public CountDownLatch getTerminatedLatch() {
        return terminatedLatch;
    }
}
