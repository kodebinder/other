package com.bfm.aap.pmdx.provider.service;

import com.bfm.aap.pmdx.model.Portfolio;
import com.bfm.aap.pmdx.provider.util.AppConstants;
import com.bfm.aap.pmdx.services.PortfolioRequest;
import com.bfm.aap.pmdx.services.PortfolioServiceGrpc;
import com.bfm.aap.pmdx.services.PortfoliosSinceRequest;
import com.google.protobuf.util.Timestamps;
import io.grpc.stub.StreamObserver;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.function.Function;

@Service
public class PortfolioServiceImpl extends PortfolioServiceGrpc.PortfolioServiceImplBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(PortfolioServiceImpl.class);

    @Autowired
    private EntityReaderService entityReaderService;

    @Value("${portfolio-streaming-delay-millis:30000}")
    private long portfolioStreamDelay;


    @Override
    public void getPortfoliosSince(PortfoliosSinceRequest request, StreamObserver<Portfolio> responseObserver) {
        LOGGER.info("received getPortfoliosSince request for {}", request);
        List<Portfolio> portfolioList = entityReaderService.getEntities(Portfolio.class);
        LOGGER.info("responding streaming request with {} messages", portfolioList!=null? portfolioList.size(): 0);
        if(CollectionUtils.isNotEmpty(portfolioList)){
            portfolioList.stream().map(updateEntityWithTimestamp()).forEach(responseObserver::onNext);
        }
        try {
            Thread.sleep(portfolioStreamDelay);
        } catch (InterruptedException e) {
            LOGGER.info("streaming sleep delay interrupted", e);
        }
        responseObserver.onCompleted();
    }

    @Override
    public void getPortfolio(PortfolioRequest request, StreamObserver<Portfolio> responseObserver) {
        LOGGER.info("received getPortfolio request for {}", request);
        String guid = request.getGuid();
        List<Portfolio> portfolioList = entityReaderService.getEntities(Portfolio.class);
        Portfolio portfolio = null;
        if (CollectionUtils.isNotEmpty(portfolioList)) {
            portfolio = portfolioList.stream().filter(fa -> fa.getPortfolioId().equals(guid)).findFirst().orElse(null);
        }
        if (portfolio == null)
            responseObserver.onError(new Exception("Portfolio not found for guid:" + guid));
        else
            responseObserver.onNext(updateEntityWithTimestamp().apply(portfolio));
        responseObserver.onCompleted();
    }

    private Function<Portfolio, Portfolio> updateEntityWithTimestamp() {
        return fa -> {
            Portfolio.Builder builder = Portfolio.newBuilder(fa);
            builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
            return builder.build();
        };
    }
}
