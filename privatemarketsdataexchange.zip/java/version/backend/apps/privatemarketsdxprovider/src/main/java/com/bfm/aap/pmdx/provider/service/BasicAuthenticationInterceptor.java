package com.bfm.aap.pmdx.provider.service;

import io.grpc.Metadata;
import io.grpc.ServerCall;
import io.grpc.ServerCallHandler;
import io.grpc.ServerInterceptor;
import io.grpc.Status;
import io.grpc.StatusRuntimeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.security.sasl.AuthenticationException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class BasicAuthenticationInterceptor implements ServerInterceptor {

    private static final Logger LOGGER = LoggerFactory.getLogger(BasicAuthenticationInterceptor.class);
    private String entityType;

    public BasicAuthenticationInterceptor(String entityType) {
        this.entityType = entityType;
    }

    @Override
    public <ReqT, RespT> ServerCall.Listener<ReqT> interceptCall(
            ServerCall<ReqT, RespT> call,
            Metadata headers,
            ServerCallHandler<ReqT, RespT> next) {

        String authHeader = headers.get(Metadata.Key.of("Authorization", Metadata.ASCII_STRING_MARSHALLER));
        if (!authHeader.startsWith("Basic ")) {
            throw new StatusRuntimeException(Status.PERMISSION_DENIED);
        }

        try {
            String[] tokens = decodeBasicAuth(authHeader);
            LOGGER.info("received {} grpc request from user: {}, dummy pwd: {}", entityType, tokens[0], tokens[1]);
        } catch (AuthenticationException e) {
            throw Status.UNAUTHENTICATED.withDescription(e.getMessage()).withCause(e).asRuntimeException();
        }
        return next.startCall(call, headers);
    }

    private String[] decodeBasicAuth(String authHeader) throws AuthenticationException {
        String basicAuth;
        try {
            basicAuth = new String(Base64.getDecoder().decode(authHeader.substring(6).getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);

            int delim = basicAuth.indexOf(":");
            if (delim == -1) {
                throw new AuthenticationException("Failed to decode basic authentication token");
            }

            return new String[]{basicAuth.substring(0, delim), basicAuth.substring(delim + 1)};
        } catch (IllegalArgumentException | IndexOutOfBoundsException e) {
            throw new AuthenticationException("Failed to decode basic authentication token");
        }
    }
}