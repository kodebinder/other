package com.bfm.aap.pmdx.provider.service;

import com.bfm.aap.pmdx.model.ShareClass;
import com.bfm.aap.pmdx.provider.util.AppConstants;
import com.bfm.aap.pmdx.services.ShareClassRequest;
import com.bfm.aap.pmdx.services.ShareClassServiceGrpc;
import com.bfm.aap.pmdx.services.ShareClassSinceRequest;
import com.google.protobuf.util.Timestamps;
import io.grpc.stub.StreamObserver;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.function.Function;

@Service
public class ShareClassServiceImpl extends ShareClassServiceGrpc.ShareClassServiceImplBase {
    private static final Logger LOGGER = LoggerFactory.getLogger(ShareClassServiceImpl.class);

    @Autowired
    private EntityReaderService entityReaderService;

    @Value("${shareClass-streaming-delay-millis:30000}")
    private long shareClassStreamDelay;

    @Override
    public void getShareClassSince(ShareClassSinceRequest request, StreamObserver<ShareClass> responseObserver) {
        LOGGER.info("received getShareClasssSince request for {}", request);
        List<ShareClass> shareClassList = entityReaderService.getEntities(ShareClass.class);
        LOGGER.info("responding streaming request with {} messages", shareClassList != null ? shareClassList.size() : 0);
        if (CollectionUtils.isNotEmpty(shareClassList)) {
            shareClassList.stream().map(updateEntityWithTimestamp()).forEach(responseObserver::onNext);
        }
        try {
            Thread.sleep(shareClassStreamDelay);
        } catch (InterruptedException e) {
            LOGGER.info("streaming sleep delay interrupted", e);
        }
        responseObserver.onCompleted();
    }

    @Override
    public void getShareClass(ShareClassRequest request, StreamObserver<ShareClass> responseObserver) {
        LOGGER.info("received getShareClass request for {}", request);
        String guid = request.getGuid();
        List<ShareClass> shareClassList = entityReaderService.getEntities(ShareClass.class);
        ShareClass shareClass = null;
        if (CollectionUtils.isNotEmpty(shareClassList)) {
            shareClass = shareClassList.stream().filter(fa -> fa.getShareclassId().equals(guid)).findFirst().orElse(null);
        }
        if (shareClass == null)
            responseObserver.onError(new Exception("ShareClass not found for guid:" + guid));
        else
            responseObserver.onNext(updateEntityWithTimestamp().apply(shareClass));
        responseObserver.onCompleted();
    }

    private Function<ShareClass, ShareClass> updateEntityWithTimestamp() {
        return fa -> {
            ShareClass.Builder builder = ShareClass.newBuilder(fa);
            builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
            return builder.build();
        };
    }
}
