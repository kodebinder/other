package com.bfm.aap.pmdx.provider.service;

import com.bfm.aap.pmdx.model.User;
import com.bfm.aap.pmdx.provider.util.AppConstants;
import com.bfm.aap.pmdx.services.UserServiceGrpc.UserServiceImplBase;
import com.bfm.aap.pmdx.services.UserSinceRequest;
import com.google.protobuf.util.Timestamps;
import io.grpc.stub.StreamObserver;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.function.Function;

@Service
public class UserServiceImpl extends UserServiceImplBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private EntityReaderService entityReaderService;

    @Value("${user-streaming-delay-millis:30000}")
    private long usersStreamDelay;

    @Override
    public void getUserSince(UserSinceRequest request, StreamObserver<User> responseObserver) {
        LOGGER.info("received getUserSince request for {}", request);
        List<User> userList = this.entityReaderService.getEntities(User.class);
        LOGGER.info("responding streaming request with {} messages", userList != null ? userList.size() : 0);
        if (CollectionUtils.isNotEmpty(userList)) {
            userList.stream()
                .map(this.updateEntityWithTimestamp())
                .forEach(responseObserver::onNext);
        }
        try {
            Thread.sleep(this.usersStreamDelay);
        } catch (InterruptedException e) {
            LOGGER.info("streaming sleep delay interrupted", e);
        }
        responseObserver.onCompleted();
    }

    private Function<User, User> updateEntityWithTimestamp() {
        return fu -> {
            User.Builder builder = User.newBuilder(fu);
            builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
            return builder.build();
        };
    }
}
