package com.bfm.aap.pmdx.manager.util;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import com.bfm.aap.pmdx.manager.config.PrivateMarketsDXManagerConfigService;
import com.bfm.aap.pmdx.manager.constant.PrivateMarketsDXManagerConstants;

@ExtendWith(MockitoExtension.class)
class PrivateMarketsDXManagerUtilTest {
	@InjectMocks
	private PrivateMarketsDXManagerUtil privateMarketsDXManagerUtil;

	@Mock
	private PrivateMarketsDXManagerConfigService privateMarketsDXManagerConfigService;

	@Test
	void test_getFileLocation() {
		when(privateMarketsDXManagerConfigService.getProperties()).thenReturn(mockProperties());
		String actualResponse = privateMarketsDXManagerUtil.getFileLocation("encryptedCredentials");
		assertEquals("/proj/publish/alts/efront/config/encrypted/", actualResponse);
	}

	private Properties mockProperties() {
		Properties properties = new Properties();
		properties.setProperty("encryptedCredentials", "/proj/publish/alts/efront/config/encrypted/");
		return properties;
	}

	@Test
	void test_getHubConfigFilePath() {
		assertNotNull(privateMarketsDXManagerUtil.getHubConfigFilePath("/proj/publish/alts/efront/config/hubConfig/", "RED"));
	}
	
	@Test
	void test_createBackup() throws IOException {
		Path path = Paths.get(
				privateMarketsDXManagerUtil.getHubConfigFilePath("/proj/publish/alts/efront/config/", "RED"));
		Assertions.assertThrows(IOException.class, () -> {
			privateMarketsDXManagerUtil.createBackup(path,
					PrivateMarketsDXManagerConstants.HUB_CONFIG_FILENAME_EXTENSION);
		});
	}

}
