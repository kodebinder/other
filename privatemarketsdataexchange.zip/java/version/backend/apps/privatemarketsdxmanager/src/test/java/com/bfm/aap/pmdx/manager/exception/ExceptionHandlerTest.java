package com.bfm.aap.pmdx.manager.exception;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bfm.aap.pmdx.notification.model.EmailParams;
import com.bfm.aap.pmdx.notification.model.NotificationEnums;
import com.bfm.aap.pmdx.notification.model.NotificationParams;
import com.bfm.aap.pmdx.notification.service.Notification;
import com.bfm.util.BFMUtil;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore("javax.net.ssl.*")
@PrepareForTest({Notification.class})
public class ExceptionHandlerTest {
    @InjectMocks
    private ExceptionHandler exceptionHandler;

    @Before
    public void setUp() {
        mockStatic(Notification.class);
    }

    @Test
    public void handleExceptionTest() throws Exception {
        Exception e = new Exception("Testing Exception Handler");
        PowerMockito.doNothing().when(Notification.class, "sendNotification", Mockito.any(NotificationParams.class));
        exceptionHandler.handleException(e);
        PowerMockito.verifyStatic(Notification.class, Mockito.times(1));
        Notification.sendNotification(mockNotificationParams(e));
    }

    @Test
    public void createNotificationParamsTest() {
        Exception e = new RuntimeException("Testing Exception Handler");
        NotificationParams expected = mockNotificationParams(e);
        NotificationParams result = exceptionHandler.createNotificationParams(e);
        assertNotNull(result);
        assertEquals(expected.getSeverity(), result.getSeverity());
        assertEquals(expected.getEmailParams().getSubject(), expected.getEmailParams().getSubject());
        assertEquals(expected.getEmailParams().getException(), expected.getEmailParams().getException());
        assertEquals(expected.getEmailParams().getUserName(), expected.getEmailParams().getUserName());
    }

    private NotificationParams mockNotificationParams(Exception e) {
        return new NotificationParams.Builder(
                NotificationEnums.NotificationSeverity.PURPLE, "PMDXManager")
                .setEmailBuilder(new EmailParams.Builder()
                        .setSubject(e.getMessage())
                        .setException(e)
                        .setUserName(BFMUtil.getUser()))
                .build();
    }
}