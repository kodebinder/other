/**
 * 
 */
package com.bfm.aap.pmdx.manager.service.preprodsetup;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.bfm.aap.pmdx.manager.exception.ExceptionHandler;
import com.bfm.aap.privatemarkets.dao.AcctInfoDao;
import com.bfm.aap.privatemarkets.dao.CountersDao;
import com.bfm.aap.privatemarkets.dao.DaoFactory;
import com.bfm.aap.privatemarkets.dao.PriceHierarchyDao;
import com.bfm.aap.privatemarkets.dao.model.AcctInfo;
import com.bfm.aap.privatemarkets.dao.model.Counters;
import com.bfm.aap.privatemarkets.dao.model.PriceHierarchy;
import com.bfm.aap.privatemarkets.dao.model.PriceHierarchyPK;
import com.bfm.portgroup.api.beam2.PortGroupAPIService;
import com.google.common.collect.Lists;

/**
 * @author hthakkar
 *
 */
@ExtendWith(MockitoExtension.class)
class PreProdSetupPostRefreshServiceImplTest {

	@InjectMocks
	private PreProdSetupPostRefreshServiceImpl preProdSetupPostRefreshServiceImpl;
	
	@Mock
	private DaoFactory daoFactory;
	@Mock
	private ExceptionHandler exceptionHandler;
	@Mock
	private PortGroupAPIService portGroupAPIService;
	@Mock
	private CountersDao countersDao;
	@Mock
	private PriceHierarchyDao priceHierarchyDao;
	@Mock
	private AcctInfoDao acctInfoDao;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
		System.setProperty("defaultWebServer", "https://dev.blackrock.com");
	}

	@Test
	void testRunPreProdDBQueries_create() {
		System.setProperty("acctNames", "INV1A,DEV");
		when(daoFactory.getDao(AcctInfoDao.class, true)).thenReturn(acctInfoDao);
		when(daoFactory.getDao(CountersDao.class, true)).thenReturn(countersDao);
		when(daoFactory.getDao(PriceHierarchyDao.class, true)).thenReturn(priceHierarchyDao);
		when(acctInfoDao.getAcctInfo(anyString(),anyString())).thenReturn(Collections.emptyList());
		when(priceHierarchyDao.load(anyString(),anyString())).thenReturn(Optional.empty());
		when(countersDao.load(anyString())).thenReturn(Optional.empty());
		preProdSetupPostRefreshServiceImpl.runPreProdDBQueries();
		verify(acctInfoDao, Mockito.times(2)).insertAcctInfo(any(AcctInfo.class));
		verify(priceHierarchyDao, Mockito.times(1)).create(any(PriceHierarchy.class));
		verify(countersDao, Mockito.times(3)).create(any(Counters.class));
	}

	@Test
	void testRunPreProdDBQueries_fetch() {
		System.setProperty("acctNames", "INVTST,TST");
		when(daoFactory.getDao(AcctInfoDao.class, true)).thenReturn(acctInfoDao);
		when(daoFactory.getDao(CountersDao.class, true)).thenReturn(countersDao);
		when(daoFactory.getDao(PriceHierarchyDao.class, true)).thenReturn(priceHierarchyDao);
		AcctInfo acctInfo = getAcctInfo("INVTST", "Invest TST", 8787687);
		when(acctInfoDao.getAcctInfo(anyString(),anyString())).thenReturn(Lists.newArrayList(acctInfo));
		when(priceHierarchyDao.load(anyString(),anyString())).thenReturn(
				Optional.ofNullable(getPriceHierarchy("NAV", "ZZZ", "EFRO")));
		when(countersDao.load(anyString())).thenReturn(Optional.ofNullable(getCounters("PRIV_ID", null, 1)));
		preProdSetupPostRefreshServiceImpl.runPreProdDBQueries();
		verify(acctInfoDao, Mockito.times(0)).insertAcctInfo(any(AcctInfo.class));
		verify(priceHierarchyDao, Mockito.times(0)).create(any(PriceHierarchy.class));
		verify(countersDao, Mockito.times(0)).create(any(Counters.class));
	}
	
	private AcctInfo getAcctInfo(String shortName, String fullName, Integer acctCode){
	    AcctInfo acctInfo = new AcctInfo();
		acctInfo.setAcctCode(acctCode);
		acctInfo.setShortname(shortName);
		acctInfo.setFullName(fullName);
		acctInfo.setAcctType("U");
		return acctInfo;
    }
	
	private PriceHierarchy getPriceHierarchy(String priceGroup, String groupOrder, String purpose){
		PriceHierarchy newPriceHierarchy = new PriceHierarchy();
		PriceHierarchyPK newPriceHierarchyPK = new PriceHierarchyPK();
		newPriceHierarchyPK.setPriceGroup(priceGroup);
		newPriceHierarchyPK.setGroupOrder(groupOrder);
		newPriceHierarchy.setKey(newPriceHierarchyPK);
		newPriceHierarchy.setPurpose(purpose);
		return newPriceHierarchy;
    }
	
	private Counters getCounters(String type, String signature, Integer counter){
		Counters newCounter = new Counters();
		newCounter.setType(type);
		newCounter.setCounter(counter);
		newCounter.setSignature(signature);
		return newCounter;
    }
	
	@Test
	void testCreatePreProdPortfolioGroup_fetchFromAPI() {
		System.setProperty("portGroupNames", "INV1A_ALT,DEV_IN_ALT");
		when(portGroupAPIService.getPortfolioCode(anyString())).thenReturn(123456);
		preProdSetupPostRefreshServiceImpl.createPreProdPortfolioGroup();
		verify(portGroupAPIService, Mockito.times(0)).createPortGroup(anyString());
	}
	
	@Test
	void testCreatePreProdPortfolioGroup_createFromAPI() {
		System.setProperty("portGroupNames", "INV1A_ALT,DEV_IN_ALT");
		when(portGroupAPIService.getPortfolioCode(anyString())).thenReturn(null);
		when(portGroupAPIService.createPortGroup(anyString())).thenReturn("PortGroup successfully created");
		preProdSetupPostRefreshServiceImpl.createPreProdPortfolioGroup();
		verify(portGroupAPIService, Mockito.times(2)).createPortGroup(anyString());
	}
	
	@Test
	void testCreatePreProdPortfolioGroup_fetchFromAPI_failure() {
		doNothing().when(exceptionHandler).handleException(any());
		System.setProperty("portGroupNames", "INV1A_ALT,DEV_IN_ALT");
		Mockito.doThrow(new RuntimeException("Beam2 Exception")).when(portGroupAPIService).getPortfolioCode(anyString());
		preProdSetupPostRefreshServiceImpl.createPreProdPortfolioGroup();
		verify(exceptionHandler, Mockito.times(2)).handleException(any());
	}
	
	@Test
	void testCreatePreProdPortfolioGroup_createFromAPI_failure() {
		doNothing().when(exceptionHandler).handleException(any());
		System.setProperty("portGroupNames", "INV1A_ALT,DEV_IN_ALT");
		when(portGroupAPIService.getPortfolioCode(anyString())).thenReturn(null);
		Mockito.doThrow(new RuntimeException("Beam2 Exception")).when(portGroupAPIService).createPortGroup(anyString());
		preProdSetupPostRefreshServiceImpl.createPreProdPortfolioGroup();
		verify(exceptionHandler, Mockito.times(2)).handleException(any());
	}
}
