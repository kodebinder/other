package com.bfm.aap.pmdx.manager.service.hubconfig;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.SystemUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bfm.aap.pmdx.manager.constant.PrivateMarketsDXManagerConstants;
import com.bfm.aap.pmdx.manager.exception.ExceptionHandler;
import com.bfm.aap.pmdx.manager.util.PrivateMarketsDXManagerHubFileReadUtil;
import com.bfm.aap.pmdx.manager.util.PrivateMarketsDXManagerHubFileWriteUtil;
import com.bfm.aap.pmdx.manager.util.PrivateMarketsDXManagerUtil;
import com.bfm.aap.privatemarkets.common.util.StringUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ StringUtil.class })
public class DeployHubConfigServiceImplTest {

	@InjectMocks
	private DeployHubConfigServiceImpl deployHubConfigServiceImpl;

	@Mock
	private PrivateMarketsDXManagerUtil privateMarketsDXManagerUtil;

	@Mock
	private ExceptionHandler exceptionHandler;

	@Mock
	private PrivateMarketsDXManagerHubFileReadUtil privateMarketsDXManagerHubFileReadUtil;

	@Mock
	private PrivateMarketsDXManagerHubFileWriteUtil privateMarketsDXManagerHubFileWriteUtil;

	private static final String EFRONT_CLIENTS_TEMPLATE_JSON_STR = "{\"clientName\":\"template\",\"clientId\":\"template\",\"credentialsFileName\":\"template\",\"dataSource\":\"template\",\"orgCode\":\"template\"}";
	private static final String SERVICES_DEFINITION_TEMPLATE_JSON_STR = "{\"serviceName\":\"template\",\"entityTypes\":[\"template\"],\"requiredEntityTypes\":[\"template\"],\"clientNames\":[\"template\"]}";
	private static final String INVESTMENTS_ENTITY_TYPES = "ASSET" + "," + "PORTFOLIO" + "," + "POSITION" + ","
			+ "PERFORMANCE" + "," + "ISSUER" + "," + "FUNDAMENTALS" + "," + "BANK_ACCOUNT" + "," + "TRANSACTION" + ","
			+ "INSTRUMENT";
	private static final String INVESTMENTS_REQUIRED_ENTITY_TYPES = "PORTFOLIO" + "," + "POSITION" + "," + "PERFORMANCE"
			+ "," + "FUNDAMENTALS" + "," + "TRANSACTION";
	private static final String CRM_ENTITY_TYPES = "USER" + "," + "CONTACT" + "," + "COMPANY" + "," + "INVESTOR";
	private static final String CRM_REQUIRED_ENTITY_TYPES = "USER" + "," + "CONTACT" + "," + "COMPANY" + ","
			+ "INVESTOR";

	private static final String HUB_CONFIGURATION_JSON_STR = "{\"eFrontClients\":[{\"clientName\":\"WRBERKLEY\",\"clientId\":\"ALADDIN.WRB\",\"credentialsFileName\":\"ALADDIN.WRB-PMDXHub.pwd\",\"dataSource\":\"INSIGHT\",\"orgCode\":\"WRB\"}],\"servicesDefinition\":[{\"serviceName\":\"Investments\",\"entityTypes\":[\"USER\",\"CONTACT\",\"COMPANY\",\"INVESTOR\"],\"requiredEntityTypes\":[\"USER\",\"CONTACT\",\"COMPANY\",\"INVESTOR\"],\"clientNames\":[\"WRBERKLEY\"]}]}";

	@Before
	public void before() {

	}

	public void settings_CreateHubConfig_readHubConfig_failed() {
		System.setProperty("username", "ALADDIN.WRB");
		System.setProperty("clientName", "WRBERKLEY");
		System.setProperty("dataSource", "INSIGHT");
		System.setProperty("orgCode", "WRB");

		mockStatic(StringUtil.class);
	}

	@Test
	public void testCreateHubConfig_readHubConfig_failed() throws IOException {
		settings_CreateHubConfig_readHubConfig_failed();
		when(privateMarketsDXManagerHubFileReadUtil.readHubConfigJson()).thenReturn(new LinkedList<>());
		assertEquals(Optional.empty(), deployHubConfigServiceImpl.createHubConfig());
	}

	public void settings_deployHubConfig_redAndBlue() {
		System.setProperty("username", "ALADDIN.WRB");
		System.setProperty("clientName", "WRBERKLEY");
		System.setProperty("dataSource", "INSIGHT");
		System.setProperty("orgCode", "WRB");

		System.setProperty("color", "");

		mockStatic(StringUtil.class);
	}

	@Test
	public void testDeployHubConfig_redAndBlue() throws IOException {
		settings_deployHubConfig_redAndBlue();
		String baseDir = "/tmp";
		if (SystemUtils.IS_OS_WINDOWS) {
			baseDir = "c:/Temp";
		}
		Path path = Paths.get(baseDir + "/hubConfig");
		if (Files.notExists(path, LinkOption.NOFOLLOW_LINKS)) {
			Files.createDirectory(path);
		}
		when(privateMarketsDXManagerUtil.getFileLocation(PrivateMarketsDXManagerConstants.HUB_CONFIG))
				.thenReturn(baseDir + "/hubConfig/");
		when(StringUtil.convertToUTF8(anyString())).thenReturn(mockPrettyJsonString());
		deployHubConfigServiceImpl.deployHubConfig(mockJsonObject());
		assertNotNull(path);
	}

	public void settings_deployHubConfig_red() {
		System.setProperty("username", "ALADDIN.WRB");
		System.setProperty("clientName", "WRBERKLEY");
		System.setProperty("dataSource", "INSIGHT");
		System.setProperty("orgCode", "WRB");

		System.setProperty("color", "RED");

		mockStatic(StringUtil.class);
	}

	@Test
	public void testDeployHubConfig_red() throws IOException {
		settings_deployHubConfig_red();
		String baseDir = "/tmp";
		if (SystemUtils.IS_OS_WINDOWS) {
			baseDir = "c:/Temp";
		}
		Path path = Paths.get(baseDir + "/hubConfig");
		if (Files.notExists(path, LinkOption.NOFOLLOW_LINKS)) {
			Files.createDirectory(path);
		}
		when(privateMarketsDXManagerUtil.getFileLocation(PrivateMarketsDXManagerConstants.HUB_CONFIG))
				.thenReturn(baseDir + "/hubConfig/");
		when(StringUtil.convertToUTF8(anyString())).thenReturn(mockPrettyJsonString());
		deployHubConfigServiceImpl.deployHubConfig(mockJsonObject());
		assertNotNull(path);
	}

	private String mockPrettyJsonString() {
		Gson gson = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().disableInnerClassSerialization()
				.create();
		return gson.toJson(HUB_CONFIGURATION_JSON_STR);
	}

	private Optional<JsonObject> mockJsonObject() {
		JsonObject jsonObject = new JsonParser().parse(HUB_CONFIGURATION_JSON_STR).getAsJsonObject();
		return Optional.ofNullable(jsonObject);
	}

	public void positiveScenarioSettingCase1() {
		System.setProperty("username", "ALADDIN.WRB");
		System.setProperty("clientName", "WRBERKLEY");
		System.setProperty("dataSource", "INSIGHT");
		System.setProperty("orgCode", "WRB");
		System.setProperty("serviceName", "Investments");
		System.setProperty("entityTypes", INVESTMENTS_ENTITY_TYPES);
		System.setProperty("requiredEntityTypes", INVESTMENTS_REQUIRED_ENTITY_TYPES);
		System.setProperty("clientNames", "WRBERKLEY");
	}

	@Test
	public void testCreateHubConfig_multipleInvestmentsEntityTypes_multipleRequiredEntityTypes_positive()
			throws IOException {
		positiveScenarioSettingCase1();
		String baseDir = "/tmp";
		if (SystemUtils.IS_OS_WINDOWS) {
			baseDir = "c:/Temp";
		}
		Path path = Paths.get(baseDir + "/hubConfig");
		if (Files.notExists(path, LinkOption.NOFOLLOW_LINKS)) {
			Files.createDirectory(path);
		}
		when(privateMarketsDXManagerUtil.getFileLocation(PrivateMarketsDXManagerConstants.HUB_CONFIG))
				.thenReturn(baseDir + "/hubConfig/");
		List<String> hubConfigList = new LinkedList<>();
		hubConfigList.add(EFRONT_CLIENTS_TEMPLATE_JSON_STR);
		hubConfigList.add(SERVICES_DEFINITION_TEMPLATE_JSON_STR);
		when(privateMarketsDXManagerHubFileReadUtil.readHubConfigJson()).thenReturn(hubConfigList);
		String json = "{\"eFrontClients\":[{\"clientName\":\"WRBERKLEY\",\"clientId\":\"ALADDIN.WRB\",\"credentialsFileName\":\"ALADDIN.WRB-PMDXHub.pwd\",\"dataSource\":\"INSIGHT\",\"orgCode\":\"WRB\"}],\"servicesDefinition\":[{\"serviceName\":\"Investments\",\"entityTypes\":[\"ASSET\",\"PORTFOLIO\",\"POSITION\",\"PERFORMANCE\",\"ISSUER\",\"FUNDAMENTALS\",\"BANK_ACCOUNT\",\"TRANSACTION\",\"INSTRUMENT\"],\"requiredEntityTypes\":[\"PORTFOLIO\",\"POSITION\",\"PERFORMANCE\",\"FUNDAMENTALS\",\"TRANSACTION\"],\"clientNames\":[\"WRBERKLEY\"]}]}";
		JsonObject jsonObject = new JsonParser().parse(json).getAsJsonObject();
		assertEquals(Optional.ofNullable(jsonObject), deployHubConfigServiceImpl.createHubConfig());
	}

	public void positiveScenarioSettingCase2() {
		System.setProperty("username", "ALADDIN.WRB");
		System.setProperty("clientName", "WRBERKLEY");
		System.setProperty("dataSource", "INSIGHT");
		System.setProperty("orgCode", "WRB");
		System.setProperty("serviceName", "CRM");
		System.setProperty("entityTypes", CRM_ENTITY_TYPES);
		System.setProperty("requiredEntityTypes", CRM_REQUIRED_ENTITY_TYPES);
		System.setProperty("clientNames", "WRBERKLEY");
	}

	@Test
	public void testCreateHubConfig_multipleCRMEntityTypes_multipleRequiredEntityTypes_positive() throws IOException {
		positiveScenarioSettingCase2();
		String baseDir = "/tmp";
		if (SystemUtils.IS_OS_WINDOWS) {
			baseDir = "c:/Temp";
		}
		Path path = Paths.get(baseDir + "/hubConfig");
		if (Files.notExists(path, LinkOption.NOFOLLOW_LINKS)) {
			Files.createDirectory(path);
		}
		when(privateMarketsDXManagerUtil.getFileLocation(PrivateMarketsDXManagerConstants.HUB_CONFIG))
				.thenReturn(baseDir + "/hubConfig/");
		List<String> hubConfigList = new LinkedList<>();
		hubConfigList.add(EFRONT_CLIENTS_TEMPLATE_JSON_STR);
		hubConfigList.add(SERVICES_DEFINITION_TEMPLATE_JSON_STR);
		when(privateMarketsDXManagerHubFileReadUtil.readHubConfigJson()).thenReturn(hubConfigList);
		String json = "{\"eFrontClients\":[{\"clientName\":\"WRBERKLEY\",\"clientId\":\"ALADDIN.WRB\",\"credentialsFileName\":\"ALADDIN.WRB-PMDXHub.pwd\",\"dataSource\":\"INSIGHT\",\"orgCode\":\"WRB\"}],\"servicesDefinition\":[{\"serviceName\":\"CRM\",\"entityTypes\":[\"USER\",\"CONTACT\",\"COMPANY\",\"INVESTOR\"],\"requiredEntityTypes\":[\"USER\",\"CONTACT\",\"COMPANY\",\"INVESTOR\"],\"clientNames\":[\"WRBERKLEY\"]}]}";
		JsonObject jsonObject = new JsonParser().parse(json).getAsJsonObject();
		assertEquals(Optional.ofNullable(jsonObject), deployHubConfigServiceImpl.createHubConfig());
	}

	public void positiveScenarioSettingCase3() {
		System.setProperty("username", "ALADDIN.WRB");
		System.setProperty("clientName", "WRBERKLEY");
		System.setProperty("dataSource", "INSIGHT");
		System.setProperty("orgCode", "WRB");
		System.setProperty("serviceName", "CRM");
		System.setProperty("entityTypes", "USER");
		System.setProperty("requiredEntityTypes", "USER");
		System.setProperty("clientNames", "WRBERKLEY");
	}

	@Test
	public void testCreateHubConfig_oneClientName_oneEntityTypes_oneRequiredEntityTypes_positive() throws IOException {
		positiveScenarioSettingCase3();
		String baseDir = "/tmp";
		if (SystemUtils.IS_OS_WINDOWS) {
			baseDir = "c:/Temp";
		}
		Path path = Paths.get(baseDir + "/hubConfig");
		if (Files.notExists(path, LinkOption.NOFOLLOW_LINKS)) {
			Files.createDirectory(path);
		}
		when(privateMarketsDXManagerUtil.getFileLocation(PrivateMarketsDXManagerConstants.HUB_CONFIG))
				.thenReturn(baseDir + "/hubConfig/");
		List<String> hubConfigList = new LinkedList<>();
		hubConfigList.add(EFRONT_CLIENTS_TEMPLATE_JSON_STR);
		hubConfigList.add(SERVICES_DEFINITION_TEMPLATE_JSON_STR);
		when(privateMarketsDXManagerHubFileReadUtil.readHubConfigJson()).thenReturn(hubConfigList);
		String json = "{\"eFrontClients\":[{\"clientName\":\"WRBERKLEY\",\"clientId\":\"ALADDIN.WRB\",\"credentialsFileName\":\"ALADDIN.WRB-PMDXHub.pwd\",\"dataSource\":\"INSIGHT\",\"orgCode\":\"WRB\"}],\"servicesDefinition\":[{\"serviceName\":\"CRM\",\"entityTypes\":[\"USER\"],\"requiredEntityTypes\":[\"USER\"],\"clientNames\":[\"WRBERKLEY\"]}]}";
		JsonObject jsonObject = new JsonParser().parse(json).getAsJsonObject();
		assertEquals(Optional.ofNullable(jsonObject), deployHubConfigServiceImpl.createHubConfig());
	}

	public void negativeScenarioSettingCase4() {
		System.setProperty("username", "ALADDIN.WRB");
		System.setProperty("clientName", "");
		System.setProperty("dataSource", "INSIGHT");
		System.setProperty("orgCode", "WRB");
		System.setProperty("serviceName", "CRM");
		System.setProperty("entityTypes", "");
		System.setProperty("requiredEntityTypes", "");
		System.setProperty("clientNames", "");
	}

	@Test
	public void testCreateHubConfig_emptyClientName_emptyEntityTypes_emptyRequiredEntityTypes_negative()
			throws IOException {
		negativeScenarioSettingCase4();
		String baseDir = "/tmp";
		if (SystemUtils.IS_OS_WINDOWS) {
			baseDir = "c:/Temp";
		}
		Path path = Paths.get(baseDir + "/hubConfig");
		if (Files.notExists(path, LinkOption.NOFOLLOW_LINKS)) {
			Files.createDirectory(path);
		}
		when(privateMarketsDXManagerUtil.getFileLocation(PrivateMarketsDXManagerConstants.HUB_CONFIG))
				.thenReturn(baseDir + "/hubConfig/");
		List<String> hubConfigList = new LinkedList<>();
		hubConfigList.add(EFRONT_CLIENTS_TEMPLATE_JSON_STR);
		hubConfigList.add(SERVICES_DEFINITION_TEMPLATE_JSON_STR);
		when(privateMarketsDXManagerHubFileReadUtil.readHubConfigJson()).thenReturn(hubConfigList);
		String json = "{\"eFrontClients\":[{\"clientName\":\"\",\"clientId\":\"ALADDIN.WRB\",\"credentialsFileName\":\"ALADDIN.WRB-PMDXHub.pwd\",\"dataSource\":\"INSIGHT\",\"orgCode\":\"WRB\"}],\"servicesDefinition\":[{\"serviceName\":\"CRM\",\"entityTypes\":[],\"requiredEntityTypes\":[],\"clientNames\":[\"\"]}]}";
		JsonObject jsonObject = new JsonParser().parse(json).getAsJsonObject();
		assertEquals(Optional.ofNullable(jsonObject), deployHubConfigServiceImpl.createHubConfig());
	}

	@After
	public void teardown() {
		System.setProperty("username", "");
		System.setProperty("clientName", "");
		System.setProperty("dataSource", "");
		System.setProperty("orgCode", "");
		System.setProperty("serviceName", "");
		System.setProperty("entityTypes", "");
		System.setProperty("requiredEntityTypes", "");
		System.setProperty("clientNames", "");
	}

}