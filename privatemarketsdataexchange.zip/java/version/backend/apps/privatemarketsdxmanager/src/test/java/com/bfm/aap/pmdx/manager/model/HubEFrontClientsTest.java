package com.bfm.aap.pmdx.manager.model;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class HubEFrontClientsTest {

	@Test
	public void testEquals_builder() {
		HubEFrontClients hubEFrontClients1 = HubEFrontClientsTestHelper.mock_1();
		HubEFrontClients hubEFrontClients2 = HubEFrontClientsTestHelper.mock_2();
		boolean flag = hubEFrontClients1.equals(hubEFrontClients2);
		assertTrue(flag);
	}

	@Test
	public void testHashCode() {
		HubEFrontClients hubEFrontClients1 = HubEFrontClientsTestHelper.mock_1();
		HubEFrontClients hubEFrontClients2 = HubEFrontClientsTestHelper.mock_2();
		boolean flag = hubEFrontClients1.hashCode() == hubEFrontClients2.hashCode();
		assertTrue(flag);
	}

	@Test
	public void testToString() {
		HubEFrontClients hubEFrontClients1 = HubEFrontClientsTestHelper.mock_1();
		HubEFrontClients hubEFrontClients2 = HubEFrontClientsTestHelper.mock_2();
		assertNotNull(hubEFrontClients1.toString());
		assertNotNull(hubEFrontClients2.toString());
	}

	@Test
	public void testGetClientId() {
		HubEFrontClients hubEFrontClients = HubEFrontClientsTestHelper.mock_1();
		assertNotNull(hubEFrontClients.getClientId());
	}

	@Test
	public void testGetClientName() {
		HubEFrontClients hubEFrontClients = HubEFrontClientsTestHelper.mock_1();
		assertNotNull(hubEFrontClients.getClientName());
	}

	@Test
	public void testGetCredentialsFileName() {
		HubEFrontClients hubEFrontClients = HubEFrontClientsTestHelper.mock_1();
		assertNotNull(hubEFrontClients.getCredentialsFileName());
	}

	@Test
	public void testGetDataSource() {
		HubEFrontClients hubEFrontClients = HubEFrontClientsTestHelper.mock_1();
		assertNotNull(hubEFrontClients.getDataSource());
	}

	@Test
	public void testGetOrgCode() {
		HubEFrontClients hubEFrontClients = HubEFrontClientsTestHelper.mock_1();
		assertNotNull(hubEFrontClients.getOrgCode());
	}

}