package com.bfm.aap.pmdx.manager.model;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class HubServicesDefinitionTest {

	@Test
	public void testEquals_builder() {
		HubServicesDefinition hubServicesDefinition1 = HubServicesDefinitionTestHelper.mock_1();
		HubServicesDefinition hubServicesDefinition2 = HubServicesDefinitionTestHelper.mock_2();
		boolean flag = hubServicesDefinition1.equals(hubServicesDefinition2);
		assertTrue(flag);
	}

	@Test
	public void testHashCode() {
		HubServicesDefinition hubServicesDefinition1 = HubServicesDefinitionTestHelper.mock_1();
		HubServicesDefinition hubServicesDefinition2 = HubServicesDefinitionTestHelper.mock_2();
		boolean flag = hubServicesDefinition1.hashCode() == hubServicesDefinition2.hashCode();
		assertTrue(flag);
	}

	@Test
	public void testToString() {
		HubServicesDefinition hubServicesDefinition1 = HubServicesDefinitionTestHelper.mock_1();
		HubServicesDefinition hubServicesDefinition2 = HubServicesDefinitionTestHelper.mock_2();
		assertNotNull(hubServicesDefinition1.toString());
		assertNotNull(hubServicesDefinition2.toString());
	}

	@Test
	public void testGetServiceName() {
		HubServicesDefinition hubServicesDefinition = HubServicesDefinitionTestHelper.mock_1();
		assertNotNull(hubServicesDefinition.getServiceName());
	}

	@Test
	public void testGetEntityTypes() {
		HubServicesDefinition hubServicesDefinition = HubServicesDefinitionTestHelper.mock_1();
		assertNotNull(hubServicesDefinition.getEntityTypes());
	}

	@Test
	public void testGetRequiredEntityTypes() {
		HubServicesDefinition hubServicesDefinition = HubServicesDefinitionTestHelper.mock_1();
		assertNotNull(hubServicesDefinition.getRequiredEntityTypes());
	}

	@Test
	public void testGetClientNames() {
		HubServicesDefinition hubServicesDefinition = HubServicesDefinitionTestHelper.mock_1();
		assertNotNull(hubServicesDefinition.getClientNames());
	}

}