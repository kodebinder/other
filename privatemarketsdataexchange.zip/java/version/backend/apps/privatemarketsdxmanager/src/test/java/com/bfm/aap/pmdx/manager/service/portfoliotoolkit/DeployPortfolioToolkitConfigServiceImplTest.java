package com.bfm.aap.pmdx.manager.service.portfoliotoolkit;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;

import org.apache.commons.lang.SystemUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import com.bfm.aap.pmdx.manager.constant.PrivateMarketsDXManagerConstants;
import com.bfm.aap.pmdx.manager.exception.ExceptionHandler;
import com.bfm.aap.pmdx.manager.util.PrivateMarketsDXManagerUtil;
import com.bfm.aap.privatemarkets.common.util.StringUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

@RunWith(PowerMockRunner.class)
@PrepareForTest({StringUtil.class})
public class DeployPortfolioToolkitConfigServiceImplTest {

	@InjectMocks
	private DeployPortfolioToolkitConfigServiceImpl deployPortfolioToolkitConfigServiceImpl;

	@Mock
	private PrivateMarketsDXManagerUtil privateMarketsDXManagerUtil;

	@Mock
	private ExceptionHandler exceptionHandler;

	@Before
	public void before() {
		Whitebox.setInternalState(DeployPortfolioToolkitConfigServiceImpl.class, "paramPortgroup",
				"dummy_portfolio_group_name");
		Whitebox.setInternalState(DeployPortfolioToolkitConfigServiceImpl.class, "paramAccountCode", "123456");
		mockStatic(StringUtil.class);
	}

	@Test
	public void testCreatePortfolioToolkitConfig() {
		assertNotNull(deployPortfolioToolkitConfigServiceImpl.createPortfolioToolkitConfig());
	}

	private Optional<JsonObject> mockJsonObject() {
		String json = "{ \"PUT-PORTFOLIO-GROUP-NAME-HERE\": \"WRB\", \"9999999999999999\": \"9756\" }";
		JsonObject jsonObject = new JsonParser().parse(json).getAsJsonObject();
		return Optional.ofNullable(jsonObject);
	}

	private String mockPrettyJsonString() {
		Gson gson = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().disableInnerClassSerialization()
				.create();
		return gson.toJson("{ \"PUT-PORTFOLIO-GROUP-NAME-HERE\": \"WRB\", \"9999999999999999\": \"9756\" }");
	}

	@Test
	public void testDeployPortfolioToolkitConfig() throws IOException {
		System.setProperty("clientShortname", "WRB");
		String baseDir = "/tmp";
		if (SystemUtils.IS_OS_WINDOWS) {
			baseDir = "c:/Temp";
		}
		Path path = Paths.get(baseDir + "/portfolioToolkit");
		if (Files.notExists(path, LinkOption.NOFOLLOW_LINKS)) {
			Files.createDirectory(path);
		}
		when(privateMarketsDXManagerUtil.getFileLocation(PrivateMarketsDXManagerConstants.PORTFOLIOTOOLKIT_CONFIG))
				.thenReturn(baseDir + "/portfolioToolkit/");
		when(StringUtil.convertToUTF8(anyString())).thenReturn(mockPrettyJsonString());
		deployPortfolioToolkitConfigServiceImpl.deployPortfolioToolkitConfig(mockJsonObject());
		assertNotNull(path);
	}

	@Test
	public void testDeployPortfolioToolkitConfig_failure() throws IOException {
		doNothing().when(exceptionHandler).handleException(any());
		when(privateMarketsDXManagerUtil.getFileLocation(PrivateMarketsDXManagerConstants.PORTFOLIOTOOLKIT_CONFIG))
				.thenReturn("/portfolioToolkit/");
		when(StringUtil.convertToUTF8(anyString())).thenReturn(mockPrettyJsonString());
		deployPortfolioToolkitConfigServiceImpl.deployPortfolioToolkitConfig(mockJsonObject());
		verify(exceptionHandler, Mockito.times(1)).handleException(any());
	}

}