package com.bfm.aap.pmdx.manager.validator;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
public class PrivateMarketsDXManagerBasicValidatorTest {

	@InjectMocks
	private PrivateMarketsDXManagerBasicValidator validator;

	@Before
	public void setup() {
		System.setProperty("username", "ALADDIN.WRB");
	}

	public void successScenarioSetting() {
		System.setProperty("username", "ALADDIN.WRB");
		System.setProperty("clientShortname", "WRB");
		System.setProperty("portGroup", "WRBINSIGHT");
		System.setProperty("accountCode", "9756");
		System.setProperty("clientName", "WRBERKLEY");
		System.setProperty("dataSource", "INSIGHT");
		System.setProperty("serviceName", "Investments");
		System.setProperty("orgCode", "WRB");
		System.setProperty("color", "RED");
		System.setProperty("entityTypes", "ASSET,PORTFOLIO,POSITION,PERFORMANCE,ISSUER,FUNDAMENTALS,HOLDING");
		System.setProperty("requiredEntityTypes", "ASSET,PORTFOLIO,POSITION");
		System.setProperty("acctNames", "INV1A,DEV");
		System.setProperty("portGroupNames", "INV1A_ALT,DEV_IN_ALT");
	}

	@Test
	public void testValidateEncryptedCredentialsInputParameters_success() {
		successScenarioSetting();
		assertEquals(true, validator.validateEncryptedCredentialsInputParameters());
	}

	@Test
	public void testValidatePortfolioToolkitConfigInputParameters_success() {
		successScenarioSetting();
		assertEquals(true, validator.validatePortfolioToolkitConfigInputParameters());
	}

	@Test
	public void testValidateHubConfigInputParameters_success() {
		successScenarioSetting();
		assertEquals(true, validator.validateHubConfigInputParameters());
	}
	
	@Test
	public void testValidatePreProdSetupPostRefreshInputParameters_success() {
		successScenarioSetting();
		assertEquals(true, validator.validatePreProdSetupPostRefreshInputParameters());
	}
	
	@Test
	public void testValidateHubConfigInputParameters_whenSingleRequired_success() {
		successScenarioSetting();
		System.setProperty("entityTypes", "ASSET");
		System.setProperty("requiredEntityTypes", "PORTFOLIO");
		assertEquals(true, validator.validateHubConfigInputParameters());
	}

	public void failureScenarioSetting() {
		System.setProperty("username", "dummyUsername-ALADDIN.WRB-100");
		System.setProperty("clientShortname", "123");
		System.setProperty("portGroup", "");
		System.setProperty("accountCode", "dummyAccountCode");
		System.setProperty("clientName", "123");
		System.setProperty("dataSource", "123");
		System.setProperty("serviceName", "DummyService1");
		System.setProperty("orgCode", "");
		System.setProperty("color", "YELLOW");
		System.setProperty("entityTypes", "ASSET,PORTFOLIO,POSITION,PERFORMANCE,ISSUER,FUNDAMENTALS,DUMMYHOLDING");
		System.setProperty("requiredEntityTypes", "ASSET,PORTFOLIO,DUMMYPOSITION");
	}
	
	@Test
	public void testValidateEncryptedCredentialsInputParameters_failure() {
		failureScenarioSetting();
		assertEquals(false, validator.validateEncryptedCredentialsInputParameters());
	}

	@Test
	public void testValidatePortfolioToolkitConfigInputParameters_failure() {
		failureScenarioSetting();
		assertEquals(false, validator.validatePortfolioToolkitConfigInputParameters());
	}

	@Test
	public void testValidateHubConfigInputParameters_failure() {
		failureScenarioSetting();
		assertEquals(false, validator.validateHubConfigInputParameters());
	}
	
	@Test
	public void testValidateHubConfigInputParameters_whenSingleRequired_failure() {
		failureScenarioSetting();
		System.setProperty("entityTypes", "DUMMYASSET");
		System.setProperty("requiredEntityTypes", "DUMMYPORTFOLIO");
		assertEquals(false, validator.validateHubConfigInputParameters());
	}


	public void failureScenarioSetting_Empty() {
		System.setProperty("username", "");
		System.setProperty("clientShortname", "");
		System.setProperty("portGroup", "");
		System.setProperty("accountCode", "");
		System.setProperty("clientName", "");
		System.setProperty("dataSource", "");
		System.setProperty("serviceName", "");
		System.setProperty("orgCode", "");
		System.setProperty("color", "");
		System.setProperty("entityTypes", "");
		System.setProperty("requiredEntityTypes", "");
		System.setProperty("acctNames", "");
		System.setProperty("portGroupNames", "");
	}
	
	@Test
	public void testValidateEncryptedCredentialsInputParameters_empty_failure() {
		failureScenarioSetting_Empty();
		assertEquals(false, validator.validateEncryptedCredentialsInputParameters());
	}

	@Test
	public void testValidatePortfolioToolkitConfigInputParameters_empty_failure() {
		failureScenarioSetting_Empty();
		assertEquals(false, validator.validatePortfolioToolkitConfigInputParameters());
	}

	@Test
	public void testValidateHubConfigInputParameters_empty_failure() {
		failureScenarioSetting_Empty();
		assertEquals(false, validator.validateHubConfigInputParameters());
	}
	
	@Test
	public void testValidatePreProdSetupPostRefreshInputParameters_empty_failure() {
		failureScenarioSetting_Empty();
		assertEquals(false, validator.validatePreProdSetupPostRefreshInputParameters());
	}

}
