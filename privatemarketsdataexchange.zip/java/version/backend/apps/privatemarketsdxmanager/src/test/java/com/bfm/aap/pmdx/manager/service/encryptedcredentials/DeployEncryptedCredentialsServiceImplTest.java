package com.bfm.aap.pmdx.manager.service.encryptedcredentials;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.SystemUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import com.bfm.aap.pmdx.manager.constant.PrivateMarketsDXManagerConstants;
import com.bfm.aap.pmdx.manager.exception.ExceptionHandler;
import com.bfm.aap.pmdx.manager.util.PrivateMarketsDXManagerUtil;

@RunWith(MockitoJUnitRunner.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class DeployEncryptedCredentialsServiceImplTest {
	@Spy
	@InjectMocks
	private DeployEncryptedCredentialsServiceImpl deployEncryptedCredentialsServiceImpl;

	@Mock
	private PrivateMarketsDXManagerUtil privateMarketsDXManagerUtil;

	@Mock
	private ExceptionHandler exceptionHandler;

	@BeforeEach
	public void before() {
		System.setProperty("username", "ALADDIN.WRB");
	}

	@Test
	void testCreateEncryptedCredentials() throws IOException, InterruptedException {
		List<String> perlScriptPassword = new ArrayList<>();
		String tempDir = SystemUtils.IS_OS_WINDOWS ? "c:/temp" : "/tmp";
		String cmdStr = SystemUtils.IS_OS_WINDOWS ? "cmd /c dir " : "ls ";
		perlScriptPassword.add(cmdStr + tempDir);
		Process dummyProcess = Runtime.getRuntime().exec(cmdStr + tempDir);
		
		Mockito.doReturn("Test").when(deployEncryptedCredentialsServiceImpl).readPassword(anyString());
		Mockito.doReturn(dummyProcess).when(deployEncryptedCredentialsServiceImpl)
				.createRSAPublicKeyProcess();
		Mockito.doReturn(perlScriptPassword).when(deployEncryptedCredentialsServiceImpl)
				.createEncryptPerlScriptCommand(anyString(), any());
		Mockito.doReturn(Optional.ofNullable("EncryptedPassword")).when(deployEncryptedCredentialsServiceImpl)
				.readCommandOutput(any());
		Mockito.doReturn(Optional.ofNullable("EncryptedPassword")).when(deployEncryptedCredentialsServiceImpl)
				.runEncryptPerlScriptCommand(any());
		assertEquals(Optional.ofNullable("EncryptedPassword"), deployEncryptedCredentialsServiceImpl.createEncryptedCredentials());
	}
	
	@Test
	void testCreateEncryptedCredentials_emptyPassword() throws IOException, InterruptedException {
		Mockito.doReturn("").when(deployEncryptedCredentialsServiceImpl).readPassword(anyString());
		assertEquals(Optional.empty(), deployEncryptedCredentialsServiceImpl.createEncryptedCredentials());
	}

	@Test
	void testCreateEncryptPerlScriptCommand() {
		assertNotNull(deployEncryptedCredentialsServiceImpl.createEncryptPerlScriptCommand("Test", Optional.ofNullable("/u1/tsgops/.bfmCrypt/preprod.private")));
	}

	@Test
	void testCreateEncryptedCredentials_failure() throws IOException, InterruptedException {
		doNothing().when(exceptionHandler).handleException(any());
		Mockito.doReturn("Test").when(deployEncryptedCredentialsServiceImpl).readPassword(anyString());
		String tempDir = SystemUtils.IS_OS_WINDOWS ? "c:/temp" : "/tmp";
		String cmdStr = SystemUtils.IS_OS_WINDOWS ? "cmd /c dir " : "ls ";
		Process dummyProcess = Runtime.getRuntime().exec(cmdStr + tempDir);
		Mockito.doReturn(dummyProcess).when(deployEncryptedCredentialsServiceImpl)
				.createRSAPublicKeyProcess();
		Mockito.doThrow(IOException.class).when(deployEncryptedCredentialsServiceImpl).runEncryptPerlScriptCommand(any());
		deployEncryptedCredentialsServiceImpl.createEncryptedCredentials();
		verify(exceptionHandler, Mockito.times(1)).handleException(any());
	}
	
	@Test
	void testCreateEncryptedCredentials_cmd_failure() throws IOException, InterruptedException {
		doNothing().when(exceptionHandler).handleException(any());
		String tempDir = SystemUtils.IS_OS_WINDOWS ? "c:/temp" : "/tmp";
		String cmdStr = SystemUtils.IS_OS_WINDOWS ? "cmd /c dir " : "ls ";
		Process dummyProcess = Runtime.getRuntime().exec(cmdStr + tempDir);
		Mockito.doReturn(dummyProcess).when(deployEncryptedCredentialsServiceImpl)
				.createRSAPublicKeyProcess();
		Mockito.doReturn("Test").when(deployEncryptedCredentialsServiceImpl).readPassword(anyString());
		deployEncryptedCredentialsServiceImpl.createEncryptedCredentials();
		verify(deployEncryptedCredentialsServiceImpl, Mockito.times(1)).runEncryptPerlScriptCommand(any());
	}

	@Test
	void testDeployEncryptedCredentials() throws IOException {
		String baseDir = "/tmp";
		if (SystemUtils.IS_OS_WINDOWS) {
			baseDir = "c:/Temp";
		}
		Path path = Paths.get(baseDir + "/encrypted");
		if (Files.notExists(path, LinkOption.NOFOLLOW_LINKS)) {
			Files.createDirectory(path);
		}
		when(privateMarketsDXManagerUtil.getFileLocation(PrivateMarketsDXManagerConstants.ENCRYPTED_CREDENTIALS))
				.thenReturn(baseDir + "/encrypted/");
		deployEncryptedCredentialsServiceImpl.deployEncryptedCredentials(Optional.ofNullable("EncryptedPassword"));
		assertNotNull(path);
	}

	@Test
	void testDeployEncryptedCredentials_failure() throws IOException {
		doNothing().when(exceptionHandler).handleException(any());
		when(privateMarketsDXManagerUtil.getFileLocation(PrivateMarketsDXManagerConstants.ENCRYPTED_CREDENTIALS))
				.thenReturn("/encrypted/");
		deployEncryptedCredentialsServiceImpl.deployEncryptedCredentials(Optional.ofNullable("EncryptedPassword"));
		verify(exceptionHandler, Mockito.times(1)).handleException(any());
	}
	
	@Test
	void testDeployEncryptedCredentials_failureAtBackup() throws IOException {
		String baseDir = "/tmp";
		if (SystemUtils.IS_OS_WINDOWS) {
			baseDir = "c:/Temp";
		}
		Path path = Paths.get(baseDir + "/encrypted");
		if (Files.notExists(path, LinkOption.NOFOLLOW_LINKS)) {
			Files.createDirectory(path);
		}
		when(privateMarketsDXManagerUtil.getFileLocation(PrivateMarketsDXManagerConstants.ENCRYPTED_CREDENTIALS))
		.thenReturn(baseDir + "/encrypted/");
		doThrow(new IOException()).when(privateMarketsDXManagerUtil).createBackup(any(), anyString());
		deployEncryptedCredentialsServiceImpl.deployEncryptedCredentials(Optional.ofNullable("EncryptedPassword"));
		Mockito.verify(exceptionHandler, Mockito.times(1)).handleException(any());
	}

}