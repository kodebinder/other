package com.bfm.aap.pmdx.manager.util;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.io.IOException;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bfm.aap.pmdx.manager.constant.PrivateMarketsDXManagerConstants;
import com.bfm.aap.pmdx.manager.exception.ExceptionHandler;
import com.bfm.aap.privatemarkets.common.util.StringUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ StringUtil.class })
public class PrivateMarketsDXManagerHubFileWriteUtilTest {

	@InjectMocks
	private PrivateMarketsDXManagerHubFileWriteUtil privateMarketsDXManagerHubFileWriteUtil;

	@Mock
	private StringUtil stringUtil;

	@Mock
	private PrivateMarketsDXManagerUtil privateMarketsDXManagerUtil;

	@Mock
	private ExceptionHandler exceptionHandler;

	@Rule
	public TemporaryFolder testFolder = new TemporaryFolder();

	private static final String templateEFrontClientsJsonStr = "{\"eFrontClients\":[{\"clientName\":\"WRBERKLEY\",\"clientId\":\"ALADDIN.WRB\",\"credentialsFileName\":\"ALADDIN.WRB-PMDXHub.pwd\",\"dataSource\":\"INSIGHT\",\"orgCode\":\"WRB\"}]}";
	private static final String templateServicesDefinitionJsonStr = "{\"servicesDefinition\":[{\"serviceName\":\"CRM\",\"entityTypes\":[\"USER\",\"CONTACT\",\"COMPANY\",\"INVESTOR\"],\"requiredEntityTypes\":[\"USER\",\"CONTACT\",\"COMPANY\",\"INVESTOR\"],\"clientNames\":[\"WRBERKLEY\"]}]}";
	private static final String templateJsonStr = "{\"eFrontClients\":[{\"clientName\":\"WRBERKLEY\",\"clientId\":\"ALADDIN.WRB\",\"credentialsFileName\":\"ALADDIN.WRB-PMDXHub.pwd\",\"dataSource\":\"INSIGHT\",\"orgCode\":\"WRB\"}],\"servicesDefinition\":[{\"serviceName\":\"CRM\",\"entityTypes\":[\"USER\",\"CONTACT\",\"COMPANY\",\"INVESTOR\"],\"requiredEntityTypes\":[\"USER\",\"CONTACT\",\"COMPANY\",\"INVESTOR\"],\"clientNames\":[\"WRBERKLEY\"]}]}";
	
	
	@Before
	public void before() {
		mockStatic(StringUtil.class);
	}

	@Test
	public void testWriteFileBasedOnColor() throws IOException {
		JsonElement jsonElementEFrontClients = new JsonParser().parse(templateEFrontClientsJsonStr);
		JsonElement jsonElementServicesDefinition = new JsonParser().parse(templateServicesDefinitionJsonStr);
		when(privateMarketsDXManagerUtil.getHubConfigFilePath(anyString(), anyString())).thenReturn(testFolder.getRoot().getPath() + PrivateMarketsDXManagerConstants.FILENAME_PREFIX
				+ PrivateMarketsDXManagerConstants.ENVIRONMENT + PrivateMarketsDXManagerConstants.UNDERSCORE
				+ PrivateMarketsDXManagerConstants.COLOR_RED + PrivateMarketsDXManagerConstants.HUB_CONFIG_FILENAME_EXTENSION);
		when(StringUtil.convertToUTF8(anyString())).thenReturn(mockPrettyJsonString());
		privateMarketsDXManagerHubFileWriteUtil.writeFileBasedOnColor(testFolder.getRoot().getPath(), jsonElementEFrontClients, jsonElementServicesDefinition,
				"RED");
		PowerMockito.verifyStatic(StringUtil.class, Mockito.atLeast(1));
	}

	private String mockPrettyJsonString() {
		Gson gson = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().disableInnerClassSerialization()
				.create();
		return gson.toJson(templateJsonStr);
	}

	@Test
	public void testGetHashedComments() {
		assertNotNull(privateMarketsDXManagerHubFileWriteUtil.getHashedComments());
	}

}