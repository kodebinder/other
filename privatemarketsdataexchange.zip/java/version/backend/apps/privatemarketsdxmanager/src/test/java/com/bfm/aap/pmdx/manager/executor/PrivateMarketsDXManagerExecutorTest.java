/**
 * 
 */
package com.bfm.aap.pmdx.manager.executor;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bfm.aap.pmdx.manager.constant.PrivateMarketsDXManagerConstants;
import com.bfm.aap.pmdx.manager.exception.ExceptionHandler;
import com.bfm.aap.pmdx.manager.service.encryptedcredentials.DeployEncryptedCredentialsService;
import com.bfm.aap.pmdx.manager.service.hubconfig.DeployHubConfigService;
import com.bfm.aap.pmdx.manager.service.portfoliotoolkit.DeployPortfolioToolkitConfigService;
import com.bfm.aap.pmdx.manager.service.preprodsetup.PreProdSetupPostRefreshService;
import com.bfm.aap.pmdx.manager.validator.PrivateMarketsDXManagerValidator;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;

/**
 * @author hthakkar
 *
 */
@RunWith(PowerMockRunner.class)
public class PrivateMarketsDXManagerExecutorTest {

	@InjectMocks
	private PrivateMarketsDXManagerExecutor privateMarketsDXManagerExecutor;

	@Mock
	private DeployHubConfigService deployHubConfigService;

	@Mock
	private DeployPortfolioToolkitConfigService deployPortfolioToolkitConfigService;

	@Mock
	private DeployEncryptedCredentialsService deployEncryptedCredentialsService;

	@Mock
	private PrivateMarketsDXManagerValidator privateMarketsDXManagerValidator;
	
	@Mock
	private PreProdSetupPostRefreshService preProdSetupPostRefreshService;

	@Mock
	private ExceptionHandler exceptionHandler;

	@Test(expected = RuntimeException.class)
	public void execute_configTypeNotPassed() {
		System.setProperty("configType", null);
		privateMarketsDXManagerExecutor.execute();
	}

	@Test(expected = RuntimeException.class)
	public void execute_incorrectConfigTypePassed() {
		System.setProperty("configType", "TestConfigType");
		privateMarketsDXManagerExecutor.execute();
	}

	@Test
	public void execute_hubConfigDeployment_validParameters() {
		System.setProperty("configType", PrivateMarketsDXManagerConstants.HUB_CONFIG);
		when(privateMarketsDXManagerValidator.validateHubConfigInputParameters()).thenReturn(Boolean.TRUE);
		when(deployHubConfigService.createHubConfig()).thenReturn(mockHubConfigJsonObject());
		doNothing().when(deployHubConfigService).deployHubConfig(mockHubConfigJsonObject());
		privateMarketsDXManagerExecutor.execute();
		verify(deployHubConfigService, Mockito.times(1)).createHubConfig();
		verify(deployHubConfigService, Mockito.times(1)).deployHubConfig(mockHubConfigJsonObject());
	}

	@Test
	public void execute_hubConfigDeployment_invalidParameters() {
		System.setProperty("configType", PrivateMarketsDXManagerConstants.HUB_CONFIG);
		when(privateMarketsDXManagerValidator.validateHubConfigInputParameters()).thenReturn(Boolean.FALSE);
		when(deployHubConfigService.createHubConfig()).thenReturn(mockHubConfigJsonObject());
		doNothing().when(deployHubConfigService).deployHubConfig(mockHubConfigJsonObject());
		privateMarketsDXManagerExecutor.execute();
		verify(deployHubConfigService, Mockito.times(0)).createHubConfig();
		verify(deployHubConfigService, Mockito.times(0)).deployHubConfig(mockHubConfigJsonObject());
	}

	@Test
	public void execute_hubConfigCreationFailed() {
		System.setProperty("configType", PrivateMarketsDXManagerConstants.HUB_CONFIG);
		when(privateMarketsDXManagerValidator.validateHubConfigInputParameters()).thenReturn(Boolean.TRUE);
		when(deployHubConfigService.createHubConfig()).thenReturn(Optional.empty());
		doNothing().when(deployHubConfigService).deployHubConfig(mockHubConfigJsonObject());
		privateMarketsDXManagerExecutor.execute();
		verify(deployHubConfigService, Mockito.times(1)).createHubConfig();
		verify(deployHubConfigService, Mockito.times(0)).deployHubConfig(mockHubConfigJsonObject());
	}

	private Optional<JsonObject> mockHubConfigJsonObject() {
		JsonObject jsonObj = new JsonObject();
		jsonObj.add("eFrontClients", JsonNull.INSTANCE);
		return Optional.ofNullable(jsonObj);
	}

	@Test
	public void execute_portfolioToolkitConfigDeployment_validParameters() {
		System.setProperty("configType", PrivateMarketsDXManagerConstants.PORTFOLIOTOOLKIT_CONFIG);
		when(privateMarketsDXManagerValidator.validatePortfolioToolkitConfigInputParameters()).thenReturn(Boolean.TRUE);
		when(deployPortfolioToolkitConfigService.createPortfolioToolkitConfig())
				.thenReturn(mockPortfolioToolkitConfigJsonObject());
		doNothing().when(deployPortfolioToolkitConfigService)
				.deployPortfolioToolkitConfig(mockPortfolioToolkitConfigJsonObject());
		privateMarketsDXManagerExecutor.execute();
		verify(deployPortfolioToolkitConfigService, Mockito.times(1)).createPortfolioToolkitConfig();
		verify(deployPortfolioToolkitConfigService, Mockito.times(1))
				.deployPortfolioToolkitConfig(mockPortfolioToolkitConfigJsonObject());
	}

	@Test
	public void execute_portfolioToolkitConfigDeployment_invalidParameters() {
		System.setProperty("configType", PrivateMarketsDXManagerConstants.PORTFOLIOTOOLKIT_CONFIG);
		when(privateMarketsDXManagerValidator.validatePortfolioToolkitConfigInputParameters())
				.thenReturn(Boolean.FALSE);
		when(deployPortfolioToolkitConfigService.createPortfolioToolkitConfig())
				.thenReturn(mockPortfolioToolkitConfigJsonObject());
		doNothing().when(deployPortfolioToolkitConfigService)
				.deployPortfolioToolkitConfig(mockPortfolioToolkitConfigJsonObject());
		privateMarketsDXManagerExecutor.execute();
		verify(deployPortfolioToolkitConfigService, Mockito.times(0)).createPortfolioToolkitConfig();
		verify(deployPortfolioToolkitConfigService, Mockito.times(0))
				.deployPortfolioToolkitConfig(mockPortfolioToolkitConfigJsonObject());
	}

	@Test
	public void execute_portfolioToolkitConfigCreationFailed() {
		System.setProperty("configType", PrivateMarketsDXManagerConstants.PORTFOLIOTOOLKIT_CONFIG);
		when(privateMarketsDXManagerValidator.validatePortfolioToolkitConfigInputParameters()).thenReturn(Boolean.TRUE);
		when(deployPortfolioToolkitConfigService.createPortfolioToolkitConfig()).thenReturn(Optional.empty());
		doNothing().when(deployPortfolioToolkitConfigService)
				.deployPortfolioToolkitConfig(mockPortfolioToolkitConfigJsonObject());
		privateMarketsDXManagerExecutor.execute();
		verify(deployPortfolioToolkitConfigService, Mockito.times(1)).createPortfolioToolkitConfig();
		verify(deployPortfolioToolkitConfigService, Mockito.times(0))
				.deployPortfolioToolkitConfig(mockPortfolioToolkitConfigJsonObject());
	}

	private Optional<JsonObject> mockPortfolioToolkitConfigJsonObject() {
		JsonObject jsonObj = new JsonObject();
		jsonObj.add("clientProperties", JsonNull.INSTANCE);
		return Optional.ofNullable(jsonObj);
	}

	@Test
	public void execute_encryptedCredentialsDeployment_validParameters() {
		System.setProperty("configType", PrivateMarketsDXManagerConstants.ENCRYPTED_CREDENTIALS);
		when(privateMarketsDXManagerValidator.validateEncryptedCredentialsInputParameters()).thenReturn(Boolean.TRUE);
		when(deployEncryptedCredentialsService.createEncryptedCredentials())
				.thenReturn(mockEncryptedCredentialsString());
		doNothing().when(deployEncryptedCredentialsService)
				.deployEncryptedCredentials(mockEncryptedCredentialsString());
		privateMarketsDXManagerExecutor.execute();
		verify(deployEncryptedCredentialsService, Mockito.times(1)).createEncryptedCredentials();
		verify(deployEncryptedCredentialsService, Mockito.times(1))
				.deployEncryptedCredentials(mockEncryptedCredentialsString());
	}

	@Test
	public void execute_encryptedCredentialsDeployment_invalidParameters() {
		System.setProperty("configType", PrivateMarketsDXManagerConstants.ENCRYPTED_CREDENTIALS);
		when(privateMarketsDXManagerValidator.validateEncryptedCredentialsInputParameters()).thenReturn(Boolean.FALSE);
		when(deployEncryptedCredentialsService.createEncryptedCredentials())
				.thenReturn(mockEncryptedCredentialsString());
		doNothing().when(deployEncryptedCredentialsService)
				.deployEncryptedCredentials(mockEncryptedCredentialsString());
		privateMarketsDXManagerExecutor.execute();
		verify(deployEncryptedCredentialsService, Mockito.times(0)).createEncryptedCredentials();
		verify(deployEncryptedCredentialsService, Mockito.times(0))
				.deployEncryptedCredentials(mockEncryptedCredentialsString());
	}

	@Test
	public void execute_encryptedCredentialsCreationFailed() {
		System.setProperty("configType", PrivateMarketsDXManagerConstants.ENCRYPTED_CREDENTIALS);
		when(privateMarketsDXManagerValidator.validateEncryptedCredentialsInputParameters()).thenReturn(Boolean.TRUE);
		when(deployEncryptedCredentialsService.createEncryptedCredentials()).thenReturn(Optional.empty());
		doNothing().when(deployEncryptedCredentialsService)
				.deployEncryptedCredentials(mockEncryptedCredentialsString());
		privateMarketsDXManagerExecutor.execute();
		verify(deployEncryptedCredentialsService, Mockito.times(1)).createEncryptedCredentials();
		verify(deployEncryptedCredentialsService, Mockito.times(0))
				.deployEncryptedCredentials(mockEncryptedCredentialsString());
	}

	private Optional<String> mockEncryptedCredentialsString() {
		String encryptedPssword = "Encrypted Password in this String";
		return Optional.of(encryptedPssword);
	}
	
	@Test
	public void execute_setupPreProdPostRefresh_validParameters() {
		System.setProperty("configType", PrivateMarketsDXManagerConstants.DEV_TST_POST_REFRESH_SETUP);
		when(privateMarketsDXManagerValidator.validatePreProdSetupPostRefreshInputParameters()).thenReturn(Boolean.TRUE);
		privateMarketsDXManagerExecutor.execute();
		verify(preProdSetupPostRefreshService, Mockito.times(1)).runPreProdDBQueries();
		verify(preProdSetupPostRefreshService, Mockito.times(1)).createPreProdPortfolioGroup();
	}

	@Test
	public void execute_setupPreProdPostRefresh_invalidParameters() {
		System.setProperty("configType", PrivateMarketsDXManagerConstants.DEV_TST_POST_REFRESH_SETUP);
		when(privateMarketsDXManagerValidator.validatePreProdSetupPostRefreshInputParameters()).thenReturn(Boolean.FALSE);
		privateMarketsDXManagerExecutor.execute();
		verify(preProdSetupPostRefreshService, Mockito.times(0)).runPreProdDBQueries();
		verify(preProdSetupPostRefreshService, Mockito.times(0)).createPreProdPortfolioGroup();
	}
}
