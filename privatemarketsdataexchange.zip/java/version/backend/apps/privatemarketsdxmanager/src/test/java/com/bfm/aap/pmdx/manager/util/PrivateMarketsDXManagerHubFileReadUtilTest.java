package com.bfm.aap.pmdx.manager.util;

import com.bfm.aap.pmdx.manager.constant.PrivateMarketsDXManagerConstants;
import com.bfm.aap.pmdx.manager.exception.ExceptionHandler;

import org.apache.commons.lang.SystemUtils;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedList;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@PrepareForTest({PrivateMarketsDXManagerConstants.class})
public class PrivateMarketsDXManagerHubFileReadUtilTest {

	@Mock
	private PrivateMarketsDXManagerUtil privateMarketsDXManagerUtil;

	@Mock
	private ExceptionHandler exceptionHandler;

	@Mock
	private PrivateMarketsDXManagerHubFileWriteUtil privateMarketsDXManagerHubFileWriteUtil;

    private PrivateMarketsDXManagerHubFileReadUtil privateMarketsDXManagerHubFileReadUtil;
	
	@Rule
	public TemporaryFolder testFolder = new TemporaryFolder();

	@Before
    public void init() {
	    MockitoAnnotations.initMocks(this);
        privateMarketsDXManagerHubFileReadUtil = new PrivateMarketsDXManagerHubFileReadUtil(privateMarketsDXManagerUtil, privateMarketsDXManagerHubFileWriteUtil, exceptionHandler);
    }

	@Test
	public void testReadHubConfigJson() throws IOException {
		System.setProperty("color", "");
		when(privateMarketsDXManagerUtil.getFileLocation(PrivateMarketsDXManagerConstants.HUB_CONFIG))
				.thenReturn(testFolder.getRoot().getPath());
		when(privateMarketsDXManagerUtil.getHubConfigFilePath(anyString(), anyString())).thenReturn(testFolder.getRoot().getPath() + PrivateMarketsDXManagerConstants.FILENAME_PREFIX
				+ PrivateMarketsDXManagerConstants.ENVIRONMENT + PrivateMarketsDXManagerConstants.UNDERSCORE
				+ PrivateMarketsDXManagerConstants.COLOR_RED + PrivateMarketsDXManagerConstants.HUB_CONFIG_FILENAME_EXTENSION);
		doNothing().when(privateMarketsDXManagerHubFileWriteUtil).writeToHubConfigFile(anyString(),anyString(), any());
		assertNotNull(privateMarketsDXManagerHubFileReadUtil.readHubConfigJson());
	}

	@Test
	public void testReadHubConfigJson_redColorPassed() throws IOException {
		System.setProperty("color", "RED");
		when(privateMarketsDXManagerUtil.getFileLocation(PrivateMarketsDXManagerConstants.HUB_CONFIG))
				.thenReturn(testFolder.getRoot().getPath());
		when(privateMarketsDXManagerUtil.getHubConfigFilePath(anyString(), anyString())).thenReturn(testFolder.getRoot().getPath() + PrivateMarketsDXManagerConstants.FILENAME_PREFIX
				+ PrivateMarketsDXManagerConstants.ENVIRONMENT + PrivateMarketsDXManagerConstants.UNDERSCORE
				+ PrivateMarketsDXManagerConstants.COLOR_RED + PrivateMarketsDXManagerConstants.HUB_CONFIG_FILENAME_EXTENSION);
		doNothing().when(privateMarketsDXManagerHubFileWriteUtil).writeToHubConfigFile(anyString(),anyString(), any());
		assertNotNull(privateMarketsDXManagerHubFileReadUtil.readHubConfigJson());
	}
	
	@Test
	public void testReadHubConfigJson_blueColorPassed() throws IOException {
		System.setProperty("color", "BLUE");
		when(privateMarketsDXManagerUtil.getFileLocation(PrivateMarketsDXManagerConstants.HUB_CONFIG))
				.thenReturn(testFolder.getRoot().getPath());
		when(privateMarketsDXManagerUtil.getHubConfigFilePath(anyString(), anyString())).thenReturn(testFolder.getRoot().getPath() + PrivateMarketsDXManagerConstants.FILENAME_PREFIX
				+ PrivateMarketsDXManagerConstants.ENVIRONMENT + PrivateMarketsDXManagerConstants.UNDERSCORE
				+ PrivateMarketsDXManagerConstants.COLOR_RED + PrivateMarketsDXManagerConstants.HUB_CONFIG_FILENAME_EXTENSION);
		doNothing().when(privateMarketsDXManagerHubFileWriteUtil).writeToHubConfigFile(anyString(),anyString(), any());
		assertNotNull(privateMarketsDXManagerHubFileReadUtil.readHubConfigJson());
	}
	
	@Test
	public void testReadHubConfigJson_failed() throws IOException {
		when(privateMarketsDXManagerUtil.getFileLocation(PrivateMarketsDXManagerConstants.HUB_CONFIG))
				.thenReturn(testFolder.getRoot().getPath());
		when(privateMarketsDXManagerUtil.getHubConfigFilePath(anyString(), anyString()))
				.thenReturn(testFolder.getRoot().getPath() + PrivateMarketsDXManagerConstants.FILENAME_PREFIX
						+ PrivateMarketsDXManagerConstants.ENVIRONMENT + PrivateMarketsDXManagerConstants.UNDERSCORE
						+ PrivateMarketsDXManagerConstants.COLOR_RED
						+ PrivateMarketsDXManagerConstants.HUB_CONFIG_FILENAME_EXTENSION);
		Mockito.doThrow(IOException.class).when(privateMarketsDXManagerHubFileWriteUtil)
				.writeToHubConfigFile(anyString(), anyString(), any());
		assertEquals(new LinkedList<>(), privateMarketsDXManagerHubFileReadUtil.readHubConfigJson());
	}

	@Test
	public void testInitializeHubConfigFileBenClient_pathAlreadyExists() throws IOException {
        PrivateMarketsDXManagerHubFileReadUtil spiedManagerHubFileReadUtil = Mockito.spy(privateMarketsDXManagerHubFileReadUtil);
		PowerMockito.mockStatic(Path.class);
		PowerMockito.mockStatic(File.class);
		Path mockPath = PowerMockito.mock(Path.class);
		File mockFile = PowerMockito.mock(File.class);
		Mockito.doReturn(testFolder.getRoot().toPath()).when(spiedManagerHubFileReadUtil).getHubConfigFilePath(anyString());
		PowerMockito.when(mockPath.toFile()).thenReturn(mockFile);
		PowerMockito.when(mockFile.exists()).thenReturn(true);
		PowerMockito.when(mockFile.isFile()).thenReturn(true);

		System.setProperty("color", "");
		when(privateMarketsDXManagerUtil.getFileLocation(PrivateMarketsDXManagerConstants.HUB_CONFIG))
				.thenReturn(testFolder.getRoot().getPath());
		when(privateMarketsDXManagerUtil.getHubConfigFilePath(anyString(), anyString())).thenReturn(testFolder.getRoot().getPath() + PrivateMarketsDXManagerConstants.FILENAME_PREFIX
				+ PrivateMarketsDXManagerConstants.ENVIRONMENT + PrivateMarketsDXManagerConstants.UNDERSCORE
				+ PrivateMarketsDXManagerConstants.COLOR_RED + PrivateMarketsDXManagerConstants.HUB_CONFIG_FILENAME_EXTENSION);
		doNothing().when(privateMarketsDXManagerHubFileWriteUtil).writeToHubConfigFile(anyString(),anyString(), any());
		assertTrue(spiedManagerHubFileReadUtil.initializeHubConfigFile());
	}

    @Test
    public void testInitializeHubConfigFileBenClient_filePathDoesNotExist() throws IOException {
        PrivateMarketsDXManagerHubFileReadUtil spiedManagerHubFileReadUtil = Mockito.spy(privateMarketsDXManagerHubFileReadUtil);
        PowerMockito.mockStatic(Path.class);
        PowerMockito.mockStatic(File.class);
        Path mockPath = PowerMockito.mock(Path.class);
        File mockFile = PowerMockito.mock(File.class);
        Mockito.doReturn(mockPath).when(spiedManagerHubFileReadUtil).getHubConfigFilePath(anyString());
        PowerMockito.when(mockPath.toFile()).thenReturn(mockFile);
        PowerMockito.when(mockFile.exists()).thenReturn(false);

       System.setProperty("color", "");
        when(privateMarketsDXManagerUtil.getFileLocation(PrivateMarketsDXManagerConstants.HUB_CONFIG))
                .thenReturn(testFolder.getRoot().getPath());
        when(privateMarketsDXManagerUtil.getHubConfigFilePath(anyString(), anyString())).thenReturn(testFolder.getRoot().getPath() + PrivateMarketsDXManagerConstants.FILENAME_PREFIX
                + PrivateMarketsDXManagerConstants.ENVIRONMENT + PrivateMarketsDXManagerConstants.UNDERSCORE
                + PrivateMarketsDXManagerConstants.COLOR_RED + PrivateMarketsDXManagerConstants.HUB_CONFIG_FILENAME_EXTENSION);
        doNothing().when(privateMarketsDXManagerHubFileWriteUtil).writeToHubConfigFile(anyString(),anyString(), any());
        assertTrue(spiedManagerHubFileReadUtil.initializeHubConfigFile());
    }

    @Test
    public void testInitializeHubConfigFileBenClient_filePathExistButNotFile() throws IOException {
        PrivateMarketsDXManagerHubFileReadUtil spiedManagerHubFileReadUtil = Mockito.spy(privateMarketsDXManagerHubFileReadUtil);
        PowerMockito.mockStatic(Path.class);
        PowerMockito.mockStatic(File.class);
        Path mockPath = PowerMockito.mock(Path.class);
        File mockFile = PowerMockito.mock(File.class);
        Mockito.doReturn(mockPath).when(spiedManagerHubFileReadUtil).getHubConfigFilePath(anyString());
        PowerMockito.when(mockPath.toFile()).thenReturn(mockFile);
        PowerMockito.when(mockFile.exists()).thenReturn(true);
        PowerMockito.when(mockFile.isFile()).thenReturn(false);

        System.setProperty("color", "");
        when(privateMarketsDXManagerUtil.getFileLocation(PrivateMarketsDXManagerConstants.HUB_CONFIG))
                .thenReturn(testFolder.getRoot().getPath());
        when(privateMarketsDXManagerUtil.getHubConfigFilePath(anyString(), anyString())).thenReturn(testFolder.getRoot().getPath() + PrivateMarketsDXManagerConstants.FILENAME_PREFIX
                + PrivateMarketsDXManagerConstants.ENVIRONMENT + PrivateMarketsDXManagerConstants.UNDERSCORE
                + PrivateMarketsDXManagerConstants.COLOR_RED + PrivateMarketsDXManagerConstants.HUB_CONFIG_FILENAME_EXTENSION);
        doNothing().when(privateMarketsDXManagerHubFileWriteUtil).writeToHubConfigFile(anyString(),anyString(), any());
        assertTrue(spiedManagerHubFileReadUtil.initializeHubConfigFile());
    }

    @Test
    public void testInitializeHubConfigFileBenClient_emptyTemplate() throws IOException {
        PrivateMarketsDXManagerHubFileReadUtil spiedManagerHubFileReadUtil = Mockito.spy(privateMarketsDXManagerHubFileReadUtil);
        PowerMockito.mockStatic(Path.class);
        PowerMockito.mockStatic(File.class);
        Path mockPath = PowerMockito.mock(Path.class);
        File mockFile = PowerMockito.mock(File.class);
        Mockito.doReturn(mockPath).when(spiedManagerHubFileReadUtil).getHubConfigFilePath(anyString());
        Mockito.doReturn(null).when(spiedManagerHubFileReadUtil).readHubTemplatePropertiesFile();
        PowerMockito.when(mockPath.toFile()).thenReturn(mockFile);
        PowerMockito.when(mockFile.exists()).thenReturn(false);

        System.setProperty("color", "");
        when(privateMarketsDXManagerUtil.getFileLocation(PrivateMarketsDXManagerConstants.HUB_CONFIG))
                .thenReturn(testFolder.getRoot().getPath());
        when(privateMarketsDXManagerUtil.getHubConfigFilePath(anyString(), anyString())).thenReturn(testFolder.getRoot().getPath() + PrivateMarketsDXManagerConstants.FILENAME_PREFIX
                + PrivateMarketsDXManagerConstants.ENVIRONMENT + PrivateMarketsDXManagerConstants.UNDERSCORE
                + PrivateMarketsDXManagerConstants.COLOR_RED + PrivateMarketsDXManagerConstants.HUB_CONFIG_FILENAME_EXTENSION);
        doNothing().when(privateMarketsDXManagerHubFileWriteUtil).writeToHubConfigFile(anyString(),anyString(), any());
        assertFalse(spiedManagerHubFileReadUtil.initializeHubConfigFile());
    }
    
	@Test
	public void testInitializeHubConfigFile_backupFailed() throws IOException {
		String baseDir = "/tmp";
		if (SystemUtils.IS_OS_WINDOWS) {
			baseDir = "c:/Temp";
		}
		Path path = Paths.get(baseDir + "/hubConfig");
		if (Files.notExists(path, LinkOption.NOFOLLOW_LINKS)) {
			Files.createDirectory(path);
		}
		Mockito.doThrow(IOException.class).when(privateMarketsDXManagerUtil).createBackup(any(), anyString());
		when(privateMarketsDXManagerUtil.getFileLocation(PrivateMarketsDXManagerConstants.HUB_CONFIG))
				.thenReturn(baseDir + "/hubConfig/");
		when(privateMarketsDXManagerUtil.getHubConfigFilePath(anyString(), anyString())).thenReturn(path.toString()
				+ PrivateMarketsDXManagerConstants.FILENAME_PREFIX + PrivateMarketsDXManagerConstants.ENVIRONMENT
				+ PrivateMarketsDXManagerConstants.UNDERSCORE + PrivateMarketsDXManagerConstants.COLOR_RED
				+ PrivateMarketsDXManagerConstants.HUB_CONFIG_FILENAME_EXTENSION);
		assertTrue(privateMarketsDXManagerHubFileReadUtil.initializeHubConfigFile());
	}
	
	@Test
	public void testInitializeHubConfigFile_backupPassed() throws IOException {
		String baseDir = "/tmp";
		if (SystemUtils.IS_OS_WINDOWS) {
			baseDir = "c:/Temp";
		}
		Path path = Paths.get(baseDir + "/hubConfig");
		if (Files.notExists(path, LinkOption.NOFOLLOW_LINKS)) {
			Files.createDirectory(path);
		}
		when(privateMarketsDXManagerUtil.getFileLocation(PrivateMarketsDXManagerConstants.HUB_CONFIG))
				.thenReturn(path + "/hubConfig/");
		when(privateMarketsDXManagerUtil.getHubConfigFilePath(anyString(), anyString())).thenReturn(path.toString()
				+ PrivateMarketsDXManagerConstants.FILENAME_PREFIX + PrivateMarketsDXManagerConstants.ENVIRONMENT
				+ PrivateMarketsDXManagerConstants.UNDERSCORE + PrivateMarketsDXManagerConstants.COLOR_RED
				+ PrivateMarketsDXManagerConstants.HUB_CONFIG_FILENAME_EXTENSION);
		assertTrue(privateMarketsDXManagerHubFileReadUtil.initializeHubConfigFile());
	}

}