package com.bfm.aap.pmdx.manager.model;

public class HubEFrontClientsTestHelper {

	public static HubEFrontClients mock_1() {
		return HubEFrontClients.builder().clientId("WRBERKLEY").clientName("ALADDIN.WRB")
				.credentialsFileName("ALADDIN.WRB-PMDXHub.pwd").dataSource("INSIGHT").orgCode("WRB").build();
	}

	public static HubEFrontClients mock_2() {
		return HubEFrontClients.builder().clientId("WRBERKLEY").clientName("ALADDIN.WRB")
				.credentialsFileName("ALADDIN.WRB-PMDXHub.pwd").dataSource("INSIGHT").orgCode("WRB").build();
	}

}
