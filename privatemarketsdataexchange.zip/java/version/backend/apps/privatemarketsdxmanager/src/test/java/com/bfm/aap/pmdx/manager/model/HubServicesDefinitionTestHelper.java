package com.bfm.aap.pmdx.manager.model;

public class HubServicesDefinitionTestHelper {

	public static HubServicesDefinition mock_1() {
		String serviceName = "CRM";
		String[] entityTypes = { "USER", "CONTACT", "COMPANY", "INVESTOR" };
		String[] requiredEntityTypes = { "USER", "CONTACT", "COMPANY", "INVESTOR" };
		String[] clientNames = { "WRBERKLEY" };
		return HubServicesDefinition.builder().serviceName(serviceName).entityTypes(entityTypes)
				.requiredEntityTypes(requiredEntityTypes).clientNames(clientNames).build();
	}

	public static HubServicesDefinition mock_2() {
		String serviceName = "CRM";
		String[] entityTypes = { "USER", "CONTACT", "COMPANY", "INVESTOR" };
		String[] requiredEntityTypes = { "USER", "CONTACT", "COMPANY", "INVESTOR" };
		String[] clientNames = { "WRBERKLEY" };
		return HubServicesDefinition.builder().serviceName(serviceName).entityTypes(entityTypes)
				.requiredEntityTypes(requiredEntityTypes).clientNames(clientNames).build();
	}

}
