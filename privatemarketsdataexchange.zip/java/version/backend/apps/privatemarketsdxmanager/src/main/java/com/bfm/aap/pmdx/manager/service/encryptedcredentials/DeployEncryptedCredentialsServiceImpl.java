/**
 * 
 */
package com.bfm.aap.pmdx.manager.service.encryptedcredentials;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.bfm.aap.pmdx.manager.constant.PrivateMarketsDXManagerConstants;
import com.bfm.aap.pmdx.manager.exception.ExceptionHandler;
import com.bfm.aap.pmdx.manager.util.PrivateMarketsDXManagerUtil;
import com.google.common.annotations.VisibleForTesting;

/**
 * @author hthakkar
 *
 */
@Service
public class DeployEncryptedCredentialsServiceImpl implements DeployEncryptedCredentialsService {
	private static final Logger LOGGER = LoggerFactory.getLogger(DeployEncryptedCredentialsServiceImpl.class);

	private final PrivateMarketsDXManagerUtil privateMarketsDXManagerUtil;
	private final ExceptionHandler exceptionHandler;

	@Autowired
	public DeployEncryptedCredentialsServiceImpl(
			@Qualifier("privateMarketsDXManagerUtil") PrivateMarketsDXManagerUtil privateMarketsDXManagerUtil,
			@Qualifier("exceptionHandler") ExceptionHandler exceptionHandler) {
		this.privateMarketsDXManagerUtil = privateMarketsDXManagerUtil;
		this.exceptionHandler = exceptionHandler;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bfm.aap.pmdx.manager.service.DeployEncryptedCredentialsService#
	 */
	@Override
	public Optional<String> createEncryptedCredentials() {
		LOGGER.info("UserName for Encryption : {} ", PrivateMarketsDXManagerConstants.PARAM_USERNAME);

		final String PASSWORD = readPassword("Password:");
		final String CONFIRM_PASSWORD = readPassword("Confirm Password:");
		
		if (StringUtils.isEmpty(PASSWORD) || StringUtils.isEmpty(CONFIRM_PASSWORD)) {
			LOGGER.error("Both Password and/or Confirm Password for creating Encrypted Credentials cannot be empty");
			return Optional.empty();
		}
		if (!PASSWORD.equals(CONFIRM_PASSWORD)) {
			LOGGER.error("Both Password and Confirm Password for creating Encrypted Credentials does not match");
			return Optional.empty();
		}

		try {
			return runEncryptPerlScriptCommand(createEncryptPerlScriptCommand(PASSWORD, 
					readCommandOutput(createRSAPublicKeyProcess())));
		} catch (Exception e) {
			LOGGER.info("Exception occurred while creating Encrypted Credentials : {} ",
					PrivateMarketsDXManagerConstants.PARAM_USERNAME + " and input password");
			exceptionHandler.handleException(e);
		}
		return Optional.empty();
	}

	/**
	 * @return
	 * @throws IOException
	 */
	@VisibleForTesting
	Process createRSAPublicKeyProcess() throws IOException {
		return Runtime.getRuntime().exec("/usr/local/bfm/etc/getfile RSAPublicKey");
	}

	/**
	 * @param perlScriptPassword
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	@VisibleForTesting
	Optional<String> runEncryptPerlScriptCommand(List<String> perlScriptCommand)
			throws IOException, InterruptedException {
		ProcessBuilder builder = new ProcessBuilder(perlScriptCommand);
		builder.redirectOutput();
		Process process = builder.start();
		return readCommandOutput(process);
	}

	/**
	 * @param process
	 * @return
	 * @throws InterruptedException
	 * @throws IOException
	 */
	@VisibleForTesting
	Optional<String> readCommandOutput(Process process) throws InterruptedException, IOException {
		process.waitFor();
		/* Reading the output from command */
		try (BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
			if (process.exitValue() == 0) {
				LOGGER.info("SUCCESS: End of Command execution");
				return Optional.of(br.lines().collect(Collectors.joining("\n")));
			} else {
				LOGGER.error("FAILURE: End of Command Execution");
				return Optional.empty();
			}
		}
	}

	/**
	 * @return
	 */
	@VisibleForTesting
	String readPassword(final String promptName) {
		return String.valueOf(System.console().readPassword(promptName));
	}

	/**
	 * @param optional 
	 * @param PASSWORD
	 * @return
	 * @throws InterruptedException 
	 * @throws IOException 
	 */
	@VisibleForTesting
	List<String> createEncryptPerlScriptCommand(final String password, Optional<String> rsaPublicKey) {
		
		String passowrdForEncryption = PrivateMarketsDXManagerConstants.PARAM_DATASOURCE + "\\"
				+ PrivateMarketsDXManagerConstants.PARAM_USERNAME + ":" + password;
		String encodedPassword = 
				  Base64.getEncoder().encodeToString(passowrdForEncryption.getBytes());
		List<String> perlScriptCommand = Arrays.asList("perl5.8", "/usr/local/bfm/etc/encrypt.pl",
				"-method RSA", encodedPassword);
		if(rsaPublicKey.isPresent()) {
			perlScriptCommand = Arrays.asList("perl5.8", "/usr/local/bfm/etc/encrypt.pl",
					"-method RSA -key " + rsaPublicKey.get(), encodedPassword);
		}
		perlScriptCommand = Collections.unmodifiableList(perlScriptCommand);
		return perlScriptCommand;
	}

	/**
	 * (non-Javadoc)
	 * 
	 * @see com.bfm.aap.pmdx.manager.service.DeployEncryptedCredentialsService#
	 *      deployEncryptedCredentials(java.lang.String)
	 */
	@Override
	public void deployEncryptedCredentials(Optional<String> encryptedPassword) {
		String encryptedCredentialsFileLocation = privateMarketsDXManagerUtil
				.getFileLocation(PrivateMarketsDXManagerConstants.ENCRYPTED_CREDENTIALS);
		LOGGER.info("encryptedCredentialsFileLocation: {}", encryptedCredentialsFileLocation);

		/* create object of Path */
		Path path = Paths.get(encryptedCredentialsFileLocation + PrivateMarketsDXManagerConstants.PARAM_USERNAME
				+ PrivateMarketsDXManagerConstants.CONFIG_FILE_SUFFIX);

		try {
			/* backing up the file if already exists */
			if (Files.exists(path)) {
				backupCredentialsFile(path);
			}
			/* Writing the file to the UNIX location */
			try (BufferedWriter writer = Files.newBufferedWriter(path)) {
				if (encryptedPassword.isPresent()) {
					writer.write(encryptedPassword.get());
					LOGGER.info("Deployment of Encrypted Credentials succesfully completed");
				}
			}
		} catch (IOException e) {
			LOGGER.info("Exception occurred while deploying file to encryptedCredentialsFileLocation: {} ",
					path.toUri());
			exceptionHandler.handleException(e);
		}

	}
	
	private void backupCredentialsFile(Path path) {
		try {
			privateMarketsDXManagerUtil.createBackup(path,PrivateMarketsDXManagerConstants.CREDENTIALS_FILENAME_EXTENSION);
		} catch (IOException e) {
			LOGGER.error(PrivateMarketsDXManagerConstants.LOG_CREDENTIALS_BACKUP_EXCEPTION_COMMENT);
			exceptionHandler.handleException(e);
		}
		LOGGER.info("Backing up old Encrypted Credentials file successfully completed");
	}
}