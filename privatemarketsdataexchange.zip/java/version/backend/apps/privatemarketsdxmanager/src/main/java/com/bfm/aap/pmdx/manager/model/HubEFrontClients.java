package com.bfm.aap.pmdx.manager.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HubEFrontClients {

	private String clientName;
	private String clientId;
	private String credentialsFileName;
	private String dataSource;
	private String orgCode;

}