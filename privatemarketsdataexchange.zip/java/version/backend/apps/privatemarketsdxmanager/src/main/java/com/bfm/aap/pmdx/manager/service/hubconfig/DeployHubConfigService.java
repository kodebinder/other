package com.bfm.aap.pmdx.manager.service.hubconfig;

import java.util.Optional;

import com.google.gson.JsonObject;

/**
 * Create and Deploy Hub Configs
 */
public interface DeployHubConfigService {
    
	Optional<JsonObject> createHubConfig();
	void deployHubConfig(Optional<JsonObject> hubConfig);   
}
