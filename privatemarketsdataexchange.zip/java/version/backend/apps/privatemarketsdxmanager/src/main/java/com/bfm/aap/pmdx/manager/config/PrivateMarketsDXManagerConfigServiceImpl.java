package com.bfm.aap.pmdx.manager.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class PrivateMarketsDXManagerConfigServiceImpl implements PrivateMarketsDXManagerConfigService {
    private static final Logger LOGGER = LoggerFactory.getLogger(PrivateMarketsDXManagerConfigServiceImpl.class);

    @Override
    public Properties getProperties() {
        final Properties properties = new Properties();
        loadProperties(properties, "PrivateMarketsDXManager.properties");
        return properties;
    }

    private void loadProperties(final Properties properties, final String resourceName) {
        try(final InputStream inputStream = PrivateMarketsDXManagerConfigServiceImpl.class
                .getClassLoader()
                .getResourceAsStream(resourceName)) {
            properties.load(inputStream);
        } catch (IOException e) {
            final String message = String.format("Error loading properties file at %s", resourceName);
            LOGGER.error(message);
            throw new IllegalArgumentException(message, e);
        }
    }
}
