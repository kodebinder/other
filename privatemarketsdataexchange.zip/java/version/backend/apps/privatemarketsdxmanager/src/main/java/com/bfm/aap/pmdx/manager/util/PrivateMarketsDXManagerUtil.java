/**
 * 
 */
package com.bfm.aap.pmdx.manager.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bfm.aap.pmdx.manager.config.PrivateMarketsDXManagerConfigService;
import com.bfm.aap.pmdx.manager.constant.PrivateMarketsDXManagerConstants;

/**
 * @author hthakkar
 *
 */
@Service
public class PrivateMarketsDXManagerUtil {

	private final PrivateMarketsDXManagerConfigService privateMarketsDXManagerConfigService;

	@Autowired
	public PrivateMarketsDXManagerUtil(final PrivateMarketsDXManagerConfigService privateMarketsDXManagerConfigService) {
		this.privateMarketsDXManagerConfigService = privateMarketsDXManagerConfigService;
	}

	/**
	 * Fetches the file location of Client Box where the configs are stored
	 * 
	 * @param configType
	 * @return UnixLocation
	 */
	public String getFileLocation(final String configType) {
		Properties properties = privateMarketsDXManagerConfigService.getProperties();
		return properties.getProperty(configType);
	}

	/**
	 * Return Hub Configuration File Path for properties file
	 * 
	 * @param hubConfigFileLocation
	 * @param color
	 * @return String
	 */
	public String getHubConfigFilePath(String hubConfigFileLocation, String color) {
		return hubConfigFileLocation + PrivateMarketsDXManagerConstants.FILENAME_PREFIX
				+ PrivateMarketsDXManagerConstants.ENVIRONMENT + PrivateMarketsDXManagerConstants.UNDERSCORE + color
				+ PrivateMarketsDXManagerConstants.HUB_CONFIG_FILENAME_EXTENSION;
	}
	
	public static String getBackupSuffix() {
		String date = LocalDate.now()
				.format(DateTimeFormatter.ofPattern(PrivateMarketsDXManagerConstants.BACKUP_DATE_FORMAT_PATTERN));
		String time = LocalTime.now()
				.format(DateTimeFormatter.ofPattern(PrivateMarketsDXManagerConstants.BACKUP_TIME_FORMAT_PATTERN));
		return PrivateMarketsDXManagerConstants.BACKUP_FILE_SUFFIX + date + PrivateMarketsDXManagerConstants.UNDERSCORE
				+ time;
	}
	
	/**
	 * Create Backup for the existing file
	 * 
	 * @param path
	 * @param fileExtension
	 */
	public void createBackup(Path path, String fileExtension) throws IOException {
		String existingFilePath = path.toString();
		String backupFileName = existingFilePath.substring(0, existingFilePath.lastIndexOf('.')) + getBackupSuffix()
				+ fileExtension;
		File backup = new File(backupFileName);
		FileUtils.copyFile(path.toFile(), backup, false);
	}
}
