/**
 * 
 */
package com.bfm.aap.pmdx.manager.service.hubconfig;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.bfm.aap.pmdx.manager.constant.PrivateMarketsDXManagerConstants;
import com.bfm.aap.pmdx.manager.model.HubEFrontClients;
import com.bfm.aap.pmdx.manager.model.HubServicesDefinition;
import com.bfm.aap.pmdx.manager.util.PrivateMarketsDXManagerHubFileReadUtil;
import com.bfm.aap.pmdx.manager.util.PrivateMarketsDXManagerHubFileWriteUtil;
import com.bfm.aap.pmdx.manager.util.PrivateMarketsDXManagerUtil;
import com.bfm.aap.privatemarkets.common.util.JsonUtil;
import com.google.common.annotations.VisibleForTesting;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * @author hthakkar
 *
 */
@Service
public class DeployHubConfigServiceImpl implements DeployHubConfigService {
	private static final Logger LOGGER = LoggerFactory.getLogger(DeployHubConfigServiceImpl.class);
	private static final String TEMPLATE = "template";
	private static final String COLOR = "color";

	private static final String USERNAME = "username";
	private static final String CLIENT_NAME = "clientName";
	private static final String CLIENT_ID = "clientId";
	private static final String CREDENTIALS_FILE_NAME = "credentialsFileName";
	private static final String DATASOURCE = "dataSource";
	private static final String ORG_CODE = "orgCode";
	private static final String CONFIG_FILE_SUFFIX = "-PMDXHub.pwd";

	private static final String SERVICE_NAME = "serviceName";
	private static final String ENTITY_TYPES = "entityTypes";
	private static final String REQUIRED_ENTITY_TYPES = "requiredEntityTypes";
	private static final String CLIENT_NAMES = "clientNames";

	private final PrivateMarketsDXManagerUtil privateMarketsDXManagerUtil;
	private final PrivateMarketsDXManagerHubFileReadUtil privateMarketsDXManagerHubFileReadUtil;
	private final PrivateMarketsDXManagerHubFileWriteUtil privateMarketsDXManagerHubFileWriteUtil;

	@Autowired
	public DeployHubConfigServiceImpl(
			@Qualifier("privateMarketsDXManagerUtil") PrivateMarketsDXManagerUtil privateMarketsDXManagerUtil,
			@Qualifier("privateMarketsDXManagerHubFileReadUtil") PrivateMarketsDXManagerHubFileReadUtil privateMarketsDXManagerHubFileReadUtil,
			@Qualifier("privateMarketsDXManagerHubFileWriteUtil") PrivateMarketsDXManagerHubFileWriteUtil privateMarketsDXManagerHubFileWriteUtil) {
		this.privateMarketsDXManagerUtil = privateMarketsDXManagerUtil;
		this.privateMarketsDXManagerHubFileReadUtil = privateMarketsDXManagerHubFileReadUtil;
		this.privateMarketsDXManagerHubFileWriteUtil = privateMarketsDXManagerHubFileWriteUtil;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bfm.aap.pmdx.manager.service.DeployHubConfigService#createHubConfig()
	 */
	@Override
	public Optional<JsonObject> createHubConfig() {

		LOGGER.info("Credentials File name : {}", System.getProperty(USERNAME) + CONFIG_FILE_SUFFIX);

		// 1. For Multiple Tenant Client + Stand Alone Client
		// Read Existing Properties File
		List<String> hubConfigList = privateMarketsDXManagerHubFileReadUtil.readHubConfigJson();
		if (hubConfigList.isEmpty()) {
			LOGGER.error("Cannot read Hub Config file");
			return Optional.empty();
		} else {
			privateMarketsDXManagerHubFileWriteUtil
					.setHashedComments(JsonUtil.collectHashedCommentsFromJsonFile(hubConfigList));
			// Removed Hashed Comments from JSON
			hubConfigList.removeIf(e -> e.startsWith("#"));
			LOGGER.info("Removed Comments : {} ", privateMarketsDXManagerHubFileWriteUtil.getHashedComments());

			Map<String, HubEFrontClients> eFrontClientsCache = new ConcurrentHashMap<>();
			Map<String, HubServicesDefinition> servicesDefinitionCache = new ConcurrentHashMap<>();

			for (String line : hubConfigList) {
				LOGGER.info("Line Value : {} ", line);
				String jsonStr = line.substring(line.indexOf(PrivateMarketsDXManagerConstants.OPENING_CURLYBRACKET) + 1,
						line.indexOf(PrivateMarketsDXManagerConstants.CLOSING_CURLYBRACKET));
				jsonStr = PrivateMarketsDXManagerConstants.OPENING_CURLYBRACKET + jsonStr
						+ PrivateMarketsDXManagerConstants.CLOSING_CURLYBRACKET;

				LOGGER.info("jsonStr : {} ", jsonStr);

				// For eFrontClients
				if (validateEFrontClientsJsonStr(jsonStr)) {
					setEFrontClients(eFrontClientsCache, jsonStr);
				}
				// For servicesDefinition
				else if (validateServicesDefinitionJsonStr(jsonStr)) {
					setServicesDefinition(servicesDefinitionCache, jsonStr);
				}
			}
			return Optional.ofNullable(populateHubConfigJsonObject(eFrontClientsCache, servicesDefinitionCache));
		}
	}

	/**
	 * @param eFrontClientsCache
	 * @param jsonStr
	 * @return void
	 */
	private void setEFrontClients(Map<String, HubEFrontClients> eFrontClientsCache, String jsonStr) {
		HubEFrontClients hubEFrontClients = new Gson().fromJson(jsonStr, HubEFrontClients.class);
		String eFrontClientsCustomkey = hubEFrontClients.getOrgCode();
		eFrontClientsCache.put(eFrontClientsCustomkey, hubEFrontClients);
		eFrontClientsCache.forEach((key, existingHubEFrontClients) -> parseEFrontClientsCache(eFrontClientsCache,
				existingHubEFrontClients));
	}

	/**
	 * @param eFrontClientsCache
	 * @param existingHubEFrontClients
	 * @return void
	 */
	private void parseEFrontClientsCache(Map<String, HubEFrontClients> eFrontClientsCache,
			HubEFrontClients existingHubEFrontClients) {
		HubEFrontClients newHubEFrontClients = HubEFrontClients.builder().build();
		// Update Existing eFrontClients
		if (System.getProperty(ORG_CODE).equalsIgnoreCase(existingHubEFrontClients.getOrgCode())) {
			// Match existing configuration in file with configuration passed as argument
			createOrUpdateEFrontClientsConfig(eFrontClientsCache, existingHubEFrontClients);
		}
		// Create new eFrontClients
		else {
			createOrUpdateEFrontClientsConfig(eFrontClientsCache, newHubEFrontClients);
		}
	}

	/**
	 * @param servicesDefinitionCache
	 * @param jsonStr
	 * @return void
	 */
	private void setServicesDefinition(Map<String, HubServicesDefinition> servicesDefinitionCache, String jsonStr) {
		HubServicesDefinition hubServicesDefinition = new Gson().fromJson(jsonStr, HubServicesDefinition.class);
		String servicesDefinitionCustomkey = hubServicesDefinition.getServiceName() + "+"
				+ hubServicesDefinition.getClientNames()[0];
		servicesDefinitionCache.put(servicesDefinitionCustomkey, hubServicesDefinition);
		servicesDefinitionCache
				.forEach((key, existingServicesDefinition) -> parseServicesDefinitionCache(servicesDefinitionCache,
						existingServicesDefinition));
	}

	/**
	 * @param servicesDefinitionCache
	 * @param existingServicesDefinition
	 * @return void
	 */
	private void parseServicesDefinitionCache(Map<String, HubServicesDefinition> servicesDefinitionCache,
			HubServicesDefinition existingServicesDefinition) {
		HubServicesDefinition newHubServicesDefinition = HubServicesDefinition.builder().build();
		// Update Existing servicesDefinition
		if (getServicesDefinitionCustomKeyUsingRuntimeAttributes()
				.equalsIgnoreCase(existingServicesDefinition.getServiceName() + "+"
						+ existingServicesDefinition.getClientNames()[0].toUpperCase())) {
			// Match existing configuration in file with configuration passed as argument
			createOrUpdateServicesDefinitionConfig(servicesDefinitionCache, existingServicesDefinition);
		}
		// Create new servicesDefinition
		else {
			createOrUpdateServicesDefinitionConfig(servicesDefinitionCache, newHubServicesDefinition);
		}
	}

	/**
	 * @param eFrontClientsCache
	 * @param hubEFrontClients
	 * @return void
	 */
	private void createOrUpdateEFrontClientsConfig(Map<String, HubEFrontClients> eFrontClientsCache,
			HubEFrontClients hubEFrontClients) {
		hubEFrontClients.setClientName(System.getProperty(CLIENT_NAME));
		hubEFrontClients.setClientId(System.getProperty(USERNAME));
		hubEFrontClients.setCredentialsFileName(System.getProperty(USERNAME) + CONFIG_FILE_SUFFIX);
		hubEFrontClients.setDataSource(System.getProperty(DATASOURCE));
		hubEFrontClients.setOrgCode(System.getProperty(ORG_CODE));

		if (!ObjectUtils.isEmpty(hubEFrontClients.getOrgCode())) {
			String customKey = hubEFrontClients.getOrgCode();
			eFrontClientsCache.put(customKey, hubEFrontClients);
		}

		// Remove Template Object as this was only meant for first time while
		// initializing Hub Config
		eFrontClientsCache.keySet().removeIf(entry -> entry.contains(TEMPLATE));
	}

	/**
	 * @param servicesDefinitionCache
	 * @param hubServicesDefinition
	 * @return void
	 */
	private void createOrUpdateServicesDefinitionConfig(Map<String, HubServicesDefinition> servicesDefinitionCache,
			HubServicesDefinition hubServicesDefinition) {
		hubServicesDefinition.setServiceName(System.getProperty(SERVICE_NAME));

		if (StringUtils.isBlank(System.getProperty(ENTITY_TYPES))) {
			String[] entityTypes = {};
			hubServicesDefinition.setEntityTypes(entityTypes);
		} else if (System.getProperty(ENTITY_TYPES).contains(",")) {
			String[] entityTypes = System.getProperty(ENTITY_TYPES).split(",");
			hubServicesDefinition.setEntityTypes(entityTypes);
		} else {
			String[] entityTypes = new String[1];
			entityTypes[0] = System.getProperty(ENTITY_TYPES);
			hubServicesDefinition.setEntityTypes(entityTypes);
		}

		if (StringUtils.isBlank(System.getProperty(REQUIRED_ENTITY_TYPES))) {
			String[] requiredEntityTypes = {};
			hubServicesDefinition.setRequiredEntityTypes(requiredEntityTypes);
		} else if (System.getProperty(REQUIRED_ENTITY_TYPES).contains(",")) {
			String[] requiredEntityTypes = System.getProperty(REQUIRED_ENTITY_TYPES).split(",");
			hubServicesDefinition.setRequiredEntityTypes(requiredEntityTypes);
		} else {
			String[] requiredEntityTypes = new String[1];
			requiredEntityTypes[0] = System.getProperty(REQUIRED_ENTITY_TYPES);
			hubServicesDefinition.setRequiredEntityTypes(requiredEntityTypes);
		}

		String[] clientName = new String[1];
		clientName[0] = System.getProperty(CLIENT_NAME);
		hubServicesDefinition.setClientNames(clientName);

		if (!ObjectUtils.isEmpty(hubServicesDefinition.getClientNames())) {
			String customKey = hubServicesDefinition.getServiceName() + "+" + hubServicesDefinition.getClientNames()[0];
			servicesDefinitionCache.put(customKey, hubServicesDefinition);
		}

		// Remove Template Object as this was only meant for first time while
		// initializing Hub Config
		servicesDefinitionCache.keySet().removeIf(entry -> entry.contains(TEMPLATE));
	}

	/**
	 * @param eFrontClientsCache
	 * @param servicesDefinitionCache
	 * @return JsonObject
	 */
	@VisibleForTesting
	JsonObject populateHubConfigJsonObject(Map<String, HubEFrontClients> eFrontClientsCache,
			Map<String, HubServicesDefinition> servicesDefinitionCache) {
		LOGGER.info("eFrontClientsCache : {} and servicesDefinitionCache : {}", eFrontClientsCache,
				servicesDefinitionCache);

		Collection<HubEFrontClients> eFrontClientsValues = eFrontClientsCache.values();
		Collection<HubServicesDefinition> servicesDefinitionValues = servicesDefinitionCache.values();

		String uglyJSONStringHubEFrontClientsValues = new Gson().toJson(eFrontClientsValues);
		String uglyJSONStringHubServicesDefinition = new Gson().toJson(servicesDefinitionValues);

		LOGGER.info("uglyJSONStringHubEFrontClientsValues : {} ", uglyJSONStringHubEFrontClientsValues);
		LOGGER.info("uglyJSONStringHubServicesDefinition : {} ", uglyJSONStringHubServicesDefinition);

		JsonParser jp = new JsonParser();
		JsonElement jeEFrontClients = jp.parse(uglyJSONStringHubEFrontClientsValues);
		JsonElement jeServicesDefinition = jp.parse(uglyJSONStringHubServicesDefinition);

		JsonObject jsonObj = new JsonObject();
		jsonObj.add(PrivateMarketsDXManagerConstants.EFRONT_CLIENTS, jeEFrontClients);
		jsonObj.add(PrivateMarketsDXManagerConstants.SERVICES_DEFINITION, jeServicesDefinition);

		LOGGER.info("JsonObject : {} ", jsonObj);

		return jsonObj;
	}

	/**
	 * Method to deploy hub config files
	 * 
	 * @param hubConfig
	 * @return void
	 */
	@Override
	public void deployHubConfig(Optional<JsonObject> hubConfig) {
		String hubConfigFileLocation = privateMarketsDXManagerUtil
				.getFileLocation(PrivateMarketsDXManagerConstants.HUB_CONFIG);
		LOGGER.info("hubConfigFileLocation: {}", hubConfigFileLocation);

		if (hubConfig.isPresent()) {
			JsonElement jsonElementEFrontClients = hubConfig.get().get(PrivateMarketsDXManagerConstants.EFRONT_CLIENTS);
			JsonElement jsonElementServicesDefinition = hubConfig.get()
					.get(PrivateMarketsDXManagerConstants.SERVICES_DEFINITION);

			// If no color passed then both Red and Blue otherwise that specific color
			if (StringUtils.isNotEmpty(System.getProperty(COLOR))) {
				LOGGER.info(PrivateMarketsDXManagerConstants.LOG_COLOR_COMMENT, "NOT NULL");
				privateMarketsDXManagerHubFileWriteUtil.writeFileBasedOnColor(hubConfigFileLocation,
						jsonElementEFrontClients, jsonElementServicesDefinition, System.getProperty(COLOR));
			}
			// Both red and blue
			else {
				redAndBlueColor(hubConfigFileLocation, jsonElementEFrontClients, jsonElementServicesDefinition);
			}
		}
	}

	/**
	 * @param hubConfigFileLocation
	 * @param jsonElementEFrontClients
	 * @param jsonElementServicesDefinition
	 * @return void
	 */
	private void redAndBlueColor(String hubConfigFileLocation, JsonElement jsonElementEFrontClients,
			JsonElement jsonElementServicesDefinition) {
		LOGGER.info(PrivateMarketsDXManagerConstants.LOG_COLOR_COMMENT, "RED + BLUE");
		privateMarketsDXManagerHubFileWriteUtil.writeFileBasedOnColor(hubConfigFileLocation, jsonElementEFrontClients,
				jsonElementServicesDefinition, PrivateMarketsDXManagerConstants.COLOR_RED);

		privateMarketsDXManagerHubFileWriteUtil.writeFileBasedOnColor(hubConfigFileLocation, jsonElementEFrontClients,
				jsonElementServicesDefinition, PrivateMarketsDXManagerConstants.COLOR_BLUE);
	}

	/**
	 * @param jsonStr
	 * @return boolean
	 */
	private boolean validateEFrontClientsJsonStr(String jsonStr) {
		return jsonStr.contains(CLIENT_NAME) && jsonStr.contains(CLIENT_ID) && jsonStr.contains(CREDENTIALS_FILE_NAME)
				&& jsonStr.contains(DATASOURCE) && jsonStr.contains(ORG_CODE);
	}

	/**
	 * @param jsonStr
	 * @return boolean
	 */
	private boolean validateServicesDefinitionJsonStr(String jsonStr) {
		return jsonStr.contains(SERVICE_NAME) && jsonStr.contains(ENTITY_TYPES)
				&& jsonStr.contains(REQUIRED_ENTITY_TYPES) && jsonStr.contains(CLIENT_NAMES);
	}

	/**
	 * @return String
	 */
	private String getServicesDefinitionCustomKeyUsingRuntimeAttributes() {
		return System.getProperty(SERVICE_NAME) + "+" + System.getProperty(CLIENT_NAME).toUpperCase();
	}

}