package com.bfm.aap.pmdx.manager.validator;

import com.bfm.aap.pmdx.manager.constant.PrivateMarketsDXManagerConstants;
import com.bfm.aap.pmdx.model.util.EntityType;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author hthakkar
 */
@Component
public class PrivateMarketsDXManagerBasicValidator implements PrivateMarketsDXManagerValidator {
    private static final Logger LOGGER = LoggerFactory.getLogger(PrivateMarketsDXManagerBasicValidator.class);
    private static final String CLIENT_NAME = "clientName";
    private static final String USER_NAME = "username";
    private static final String DATA_SOURCE = "dataSource";
    private static final String ORG_CODE = "orgCode";
    private static final String COLOR = "color";
    private static final String CLIENT_SHORT_NAME = "clientShortname";
    private static final String PORT_GROUP = "portGroup";
    private static final String ACCOUNT_CODE = "accountCode";
    private static final String ENTITY_TYPES = "entityTypes";
    private static final String REQUIRED_ENTITY_TYPES = "requiredEntityTypes";
	private static final String ACCT_NAMES = "acctNames";
	private static final String PORT_GROUP_NAMES = "portGroupNames";

    /*
     * (non-Javadoc)
     *
     * @see com.bfm.aap.pmdx.manager.validator.PrivateMarketsDXManagerValidator#
     * validateHubConfigInputParameters()
     */
    @Override
    public boolean validateHubConfigInputParameters() {
        LOGGER.info("Validate Hub Config Input Parameters");
        boolean isValidUser = validateUsername();
        boolean isValidOrgCode = validateOrgCode();
        boolean isValidateColor = validateColor();

        boolean isValid = isValidUser && isValidOrgCode && isValidateColor;

        if (validateClientName()) {
            LOGGER.info("Client Name passed: {} ", System.getProperty(CLIENT_NAME));
            LOGGER.info("Validation of field clientName <<<< pass >>>> in method : {}",
                    Thread.currentThread().getStackTrace()[1].getMethodName());
        } else {
            isValid = false;
        }

        if (validateDataSource()) {
            LOGGER.info("Data Source passed: {} ", System.getProperty(DATA_SOURCE));
            LOGGER.info("Validation of field dataSource <<<< pass >>>> in method : {}",
                    Thread.currentThread().getStackTrace()[1].getMethodName());
        } else {
            isValid = false;
            LOGGER.info("Validation of field dataSource <<<< fail >>>> in method : {}",
                    Thread.currentThread().getStackTrace()[1].getMethodName());
        }

        if (validateEntityTypes()) {
            LOGGER.info("Entity Types passed: {} ", System.getProperty(ENTITY_TYPES));
            LOGGER.info("Validation of field EntityTypes <<<< pass >>>> in method : {}",
                    Thread.currentThread().getStackTrace()[1].getMethodName());
        } else {
            isValid = false;
        }

        if (validateRequiredEntityTypes()) {
            LOGGER.info("Required Entity Types passed: {} ", System.getProperty(REQUIRED_ENTITY_TYPES));
            LOGGER.info("Validation of field Required EntityTypes <<<< pass >>>> in method : {}",
                    Thread.currentThread().getStackTrace()[1].getMethodName());
        } else {
            isValid = false;
        }


        return isValid;
    }

    /*
     * (non-Javadoc)
     *
     * @see com.bfm.aap.pmdx.manager.validator.PrivateMarketsDXManagerValidator#
     * validatePortfolioToolkitConfigInputParameters()
     */
    @Override
    public boolean validatePortfolioToolkitConfigInputParameters() {
        LOGGER.info("Validate PortfolioToolkit Config Input Parameters");

        boolean isValid = true;
        if (validateClientShortname()) {
            LOGGER.info("Client Short Name passed: {} ", System.getProperty(CLIENT_SHORT_NAME));
            LOGGER.info("Validation of field clientShortname <<<< pass >>>> in method : {}",
                    Thread.currentThread().getStackTrace()[1].getMethodName());
        } else {
            isValid = false;
        }

        if (validatePortfolioGroup()) {
            LOGGER.info("Portfolio Group passed: {} ", System.getProperty(PORT_GROUP));
            LOGGER.info("Validation of field portGroup <<<< pass >>>> in method : {}",
                    Thread.currentThread().getStackTrace()[1].getMethodName());
        } else {
            isValid = false;
        }

        if (validateAccountCode()) {
            LOGGER.info("Account Code passed: {} ", System.getProperty(ACCOUNT_CODE));
            LOGGER.info("Validation of field accountCode <<<< pass >>>> in method : {}",
                    Thread.currentThread().getStackTrace()[1].getMethodName());
        } else {
            isValid = false;
        }

        return isValid;
    }

    /*
     * (non-Javadoc)
     *
     * @see com.bfm.aap.pmdx.manager.validator.PrivateMarketsDXManagerValidator#
     * validateEncryptedCredentialsInputParameters()
     */
    @Override
    public boolean validateEncryptedCredentialsInputParameters() {
        LOGGER.info("Validate Encrypted Credentials Input Parameters");
        boolean isValid = validateUsername();
        if (validateDataSource()) {
            LOGGER.info("Data Source passed: {} ", System.getProperty(DATA_SOURCE));
            LOGGER.info("Validation of field dataSource <<<< pass >>>> in method : {}",
                    Thread.currentThread().getStackTrace()[1].getMethodName());
        } else {
            isValid = false;
        }

        // Password, Portfolio Group Validation Not required as per
        // https://webster.bfm.com/Wiki/display/AFA/PMDX+Manager+-+Automating+and+Validating+Client+Implementation+Steps+Whitepaper

        return isValid;
    }

    /**
     * Validates the Username parameter
     *
     * @return boolean
     */
    private boolean validateUsername() {
        if (StringUtils.isBlank(System.getProperty(USER_NAME))) {
            LOGGER.info("Validation of field username <<<< fail >>>> in method : {}",
                    Thread.currentThread().getStackTrace()[1].getMethodName());
            return false;
        } else {
            LOGGER.info("Username passed: {} ", System.getProperty(USER_NAME));
            LOGGER.info("Validation of field username <<<< pass >>>> in method : {}",
                    Thread.currentThread().getStackTrace()[1].getMethodName());
            return true;
        }
    }

    /**
     * Validates the ClientShortName parameter which accepts only alpha numeric
     *
     * @return boolean
     */
    private boolean validateClientShortname() {
        String clientShortName = System.getProperty(CLIENT_SHORT_NAME);
        if (StringUtils.isBlank(clientShortName)) {
            LOGGER.info("Null check validation for parameter 'clientShortname'  <<<< fail >>>> in method : {}",
                    Thread.currentThread().getStackTrace()[1].getMethodName());
            return false;
        } else if (!clientShortName.chars().allMatch(Character::isLetterOrDigit)) {
            LOGGER.info("Validation of field clientShortname  <<<< fail >>>> should be only alpha numeric : {}",
                    clientShortName);
            return false;
        } else {
            return true;
        }
    }

    /**
     * Validates the PortfolioGroup parameter
     *
     * @return boolean
     */
    private boolean validatePortfolioGroup() {
        if (StringUtils.isBlank(System.getProperty(PORT_GROUP))) {
            LOGGER.info("Null check validation for parameter 'portGroup'  <<<< fail >>>> in method : {}",
                    Thread.currentThread().getStackTrace()[1].getMethodName());
            return false;
        }
        return true;
    }

    /**
     * Validates the AccountCode parameter which should be numeric
     *
     * @return boolean
     */
    private boolean validateAccountCode() {
        String accountCode = System.getProperty(ACCOUNT_CODE);
        if (StringUtils.isBlank(accountCode)) {
            LOGGER.info("Null check validation for parameter 'accountCode'  <<<< fail >>>> in method : {}",
                    Thread.currentThread().getStackTrace()[1].getMethodName());
            return false;
        } else if (!accountCode.chars().allMatch(Character::isDigit)) {
            LOGGER.info("Validation of field accountCode  <<<< fail >>>> should be numeric : {}",
                    accountCode);
            return false;
        } else {
            return true;
        }
    }

    /**
     * Validates the ClientName parameter which should have only characters
     *
     * @return boolean
     */
    private boolean validateClientName() {
        String clientName = System.getProperty(CLIENT_NAME);
        if (StringUtils.isBlank(clientName)) {
            LOGGER.info("Null check validation for parameter 'clientName'  <<<< fail >>>> in method : {}",
                    Thread.currentThread().getStackTrace()[1].getMethodName());
            return false;
        } else if (!clientName.chars().allMatch(Character::isLetter)) {
            LOGGER.info("Validation of field clientName  <<<< fail >>>> should be only characters : {}",
                    clientName);
            return false;
        } else {
            return true;
        }
    }

    /**
     * Validates the Datasource parameter
     *
     * @return boolean
     */
    private boolean validateDataSource() {
        String passedDataSource = System.getProperty(DATA_SOURCE);
        if (StringUtils.isBlank(passedDataSource)) {
            LOGGER.info("Null check validation for parameter 'dataSource'  <<<< fail >>>> in method : {}",
                    Thread.currentThread().getStackTrace()[1].getMethodName());
            return false;
        } else if (!(passedDataSource.equals(PrivateMarketsDXManagerConstants.SOURCE_INSIGHT)
                || passedDataSource.equals(PrivateMarketsDXManagerConstants.SOURCE_INVEST))) {
            LOGGER.info("Validation of field dataSource  <<<< fail >>>> should be either {} or {} : {}",
                    PrivateMarketsDXManagerConstants.SOURCE_INSIGHT, PrivateMarketsDXManagerConstants.SOURCE_INVEST,
                    passedDataSource);
            return false;
        } else {
            return true;
        }
    }

    /**
     * Validates the Orgcode parameter
     *
     * @return boolean
     */
    private boolean validateOrgCode() {
        if (StringUtils.isBlank(System.getProperty(ORG_CODE))) {
            LOGGER.info("Null check validation for parameter 'orgCode'  <<<< fail >>>> in method : {}",
                    Thread.currentThread().getStackTrace()[1].getMethodName());
            return false;
        } else {
            LOGGER.info("Org Code passed: {} ", System.getProperty(ORG_CODE));
            LOGGER.info("Validation of field orgCode <<<< pass >>>> in method : {}",
                    Thread.currentThread().getStackTrace()[1].getMethodName());
            return true;
        }
    }

    /**
     * Validates the color parameter
     *
     * @return boolean
     */
    private boolean validateColor() {
        String passedColor = System.getProperty(COLOR);
        if (StringUtils.isNotBlank(passedColor)
                && !(passedColor.equals(PrivateMarketsDXManagerConstants.COLOR_RED)
                || passedColor.equals(PrivateMarketsDXManagerConstants.COLOR_BLUE))) {
            LOGGER.info("Validation of field color  <<<< fail >>>> should be either {} or {} : {}",
                    PrivateMarketsDXManagerConstants.COLOR_RED, PrivateMarketsDXManagerConstants.COLOR_BLUE,
                    passedColor);
            return false;
        } else {
            LOGGER.info("Color passed: {} ", passedColor);
            LOGGER.info("Validation of field color <<<< pass >>>> in method : {}",
                    Thread.currentThread().getStackTrace()[1].getMethodName());
            return true;
        }
    }

    /**
     * Validates the Entity Types of Hub Config
     *
     * @return boolean
     */
    private boolean validateEntityTypes() {
        String passedEntityTypes = System.getProperty(ENTITY_TYPES);
        LOGGER.info("EntityTypes passed: {} ", passedEntityTypes);
        if (StringUtils.isNotBlank(passedEntityTypes)) {
            if (passedEntityTypes.contains(",")) {
                List<String> entityTypes = Arrays.asList(passedEntityTypes.split(","));
                List<String> mappedEntiyTypes = entityTypes.stream()
                        .filter(entityType -> ObjectUtils.containsConstant(EntityType.values(), entityType))
                        .collect(Collectors.toList());
                if (entityTypes.size() != mappedEntiyTypes.size()) {
                    LOGGER.info("Validation of field entityTypes  <<<< fail >>>> should have all valid entityTypes from : {}",
                            Arrays.asList(EntityType.values()));
                    return false;
                }
            } else {
                if (!ObjectUtils.containsConstant(EntityType.values(), passedEntityTypes)) {
                    LOGGER.info("Validation of field entityTypes  <<<< fail >>>> should have valid entityTypes from : {}",
                            Arrays.asList(EntityType.values()));
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Validates the Required Entity Types of Hub Config
     *
     * @return boolean
     */
    private boolean validateRequiredEntityTypes() {
        String passedRequiredEntityTypes = System.getProperty(REQUIRED_ENTITY_TYPES);
        LOGGER.info("Required EntityTypes passed: {} ", passedRequiredEntityTypes);
        if (StringUtils.isNotBlank(passedRequiredEntityTypes)) {
            if (passedRequiredEntityTypes.contains(",")) {
                List<String> requiredEntityTypes = Arrays.asList(passedRequiredEntityTypes.split(","));
                List<String> mappedRequiredEntiyTypes = requiredEntityTypes.stream()
                        .filter(requiredEntityType -> ObjectUtils.containsConstant(EntityType.values(), requiredEntityType))
                        .collect(Collectors.toList());
                if (requiredEntityTypes.size() != mappedRequiredEntiyTypes.size()) {
                    LOGGER.info("Validation of field requiredEntityTypes  <<<< fail >>>> should have all valid Required entityTypes from : {}",
                            Arrays.asList(EntityType.values()));
                    return false;
                }
            } else {
                if (!ObjectUtils.containsConstant(EntityType.values(), passedRequiredEntityTypes)) {
                    LOGGER.info("Validation of field requiredEntityTypes  <<<< fail >>>> should have valid Required entityTypes from : {}",
                            Arrays.asList(EntityType.values()));
                    return false;
                }
            }
        }
        return true;
    }
    
    /**
     * Validates the PortGroupNames
     *
     * @return boolean
     */
    private boolean validatePortGroupNames() {
    	String passedPortGroupNames = System.getProperty(PORT_GROUP_NAMES);
        if (StringUtils.isBlank(passedPortGroupNames)) {
            LOGGER.info("Null check validation for parameter 'portGroupNames'  <<<< fail >>>> in method : {}",
                    Thread.currentThread().getStackTrace()[1].getMethodName());
            return false;
        } else {
            LOGGER.info("PortGroupNames passed: {} ", passedPortGroupNames);
            LOGGER.info("Validation of field portGroupNames <<<< pass >>>> in method : {}",
                    Thread.currentThread().getStackTrace()[1].getMethodName());
            return true;
        }
    }
    
    
    /**
     * Validates the AcctNames parameter
     *
     * @return boolean
     */
    private boolean validateAcctNames() {
    	String passedAcctNames = System.getProperty(ACCT_NAMES);
        if (StringUtils.isBlank(passedAcctNames)) {
            LOGGER.info("Null check validation for parameter 'acctNames'  <<<< fail >>>> in method : {}",
                    Thread.currentThread().getStackTrace()[1].getMethodName());
            return false;
        } else {
            LOGGER.info("AcctNames passed: {} ", passedAcctNames);
            LOGGER.info("Validation of field acctNames <<<< pass >>>> in method : {}",
                    Thread.currentThread().getStackTrace()[1].getMethodName());
            return true;
        }
    }
    
	/* (non-Javadoc)
	 * @see com.bfm.aap.pmdx.manager.validator.PrivateMarketsDXManagerValidator#validatePreProdSetupPostRefreshInputParameters()
	 */
	@Override
	public boolean validatePreProdSetupPostRefreshInputParameters() {
		LOGGER.info("Validate PreProd Setup Post Refresh Input Parameters");
        boolean isValidPortGroupNames = validatePortGroupNames();
        boolean isValidAcctNames = validateAcctNames();
        
		return isValidPortGroupNames && isValidAcctNames;
	}
}