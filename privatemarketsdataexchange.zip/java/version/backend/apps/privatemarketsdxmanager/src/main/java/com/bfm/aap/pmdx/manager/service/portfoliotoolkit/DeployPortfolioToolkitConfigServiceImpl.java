/**
 * 
 */
package com.bfm.aap.pmdx.manager.service.portfoliotoolkit;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.bfm.aap.pmdx.manager.constant.PrivateMarketsDXManagerConstants;
import com.bfm.aap.pmdx.manager.exception.ExceptionHandler;
import com.bfm.aap.pmdx.manager.util.PrivateMarketsDXManagerUtil;
import com.bfm.aap.privatemarkets.common.util.StringUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * @author hthakkar
 *
 */
@Service
public class DeployPortfolioToolkitConfigServiceImpl implements DeployPortfolioToolkitConfigService {
	private static final Logger LOGGER = LoggerFactory.getLogger(DeployPortfolioToolkitConfigServiceImpl.class);
	private static final String FILENAME_PREFIX = "TEMPLATE";
	private static final String FILENAME_SUFFIX = "ToolKitConfig";
	private static final String FILENAME_EXTENSION = ".json";
	private static final String PORT_GROUP_PLACEMENT = "PUT-PORTFOLIO-GROUP-NAME-HERE";
	private static final String DEFAULT_ACC_CODE = "9999999999999999";
	private static String paramPortgroup = System.getProperty("portGroup");
	private static String paramAccountCode = System.getProperty("accountCode");

	private final PrivateMarketsDXManagerUtil privateMarketsDXManagerUtil;
	private final ExceptionHandler exceptionHandler;

	@Autowired
	public DeployPortfolioToolkitConfigServiceImpl(
			@Qualifier("privateMarketsDXManagerUtil") PrivateMarketsDXManagerUtil privateMarketsDXManagerUtil,
			@Qualifier("exceptionHandler") ExceptionHandler exceptionHandler) {
		this.privateMarketsDXManagerUtil = privateMarketsDXManagerUtil;
		this.exceptionHandler = exceptionHandler;
	}

	/**
	 * (non-Javadoc)
	 * 
	 * @see com.bfm.aap.pmdx.manager.service.DeployPortfolioToolkitConfigService#createPortfolioToolkitConfig()
	 */
	@Override
	public Optional<JsonObject> createPortfolioToolkitConfig() {
		List<String> toolkitConfigList = readTemplateToolkitConfigJson();

		if (toolkitConfigList.isEmpty()) {
			LOGGER.error("TEMPLATEToolkitConfig file is empty");
			return Optional.empty();
		} else {
			// Replace Dynamic JSON Parameters
			List<String> toolkitConfigLists = toolkitConfigList.stream()
					.map(result -> result.replace(PORT_GROUP_PLACEMENT, paramPortgroup))
					.map(result -> result.replace(DEFAULT_ACC_CODE, paramAccountCode)).collect(Collectors.toList());
			// Remove Comments From JSON File
			toolkitConfigLists.forEach(data -> {
				if (data.contains("<!--") || data.contains("-->")) {
					toolkitConfigLists.set(toolkitConfigLists.indexOf(data), data.replaceAll("<!--.*?-->", ""));
				}
			});

			StringBuilder stringBuilder = new StringBuilder();
			for (String jsonStr : toolkitConfigLists) {
				stringBuilder.append(jsonStr);
			}

			String json = stringBuilder.toString();
			JsonObject jsonObject = new JsonParser().parse(json).getAsJsonObject();
			String uglyJSONString = new Gson().toJson(jsonObject);

			Gson gson = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
			JsonParser jp = new JsonParser();
			JsonElement je = jp.parse(uglyJSONString);

			String prettyJsonString = gson.toJson(je).replace(PORT_GROUP_PLACEMENT, paramPortgroup)
					.replace(DEFAULT_ACC_CODE, paramAccountCode);

			jsonObject = new JsonParser().parse(prettyJsonString).getAsJsonObject();

			return Optional.ofNullable(jsonObject);
		}
	}

	/**
	 * Method deploy portflioToolkit config files
	 * 
	 * @return void
	 */
	@Override
	public void deployPortfolioToolkitConfig(Optional<JsonObject> portfolioToolkitConfig) {
		String portfolioToolkitConfigFileLocation = privateMarketsDXManagerUtil
				.getFileLocation(PrivateMarketsDXManagerConstants.PORTFOLIOTOOLKIT_CONFIG);
		LOGGER.info("portfolioToolkitConfigFileLocation: {}", portfolioToolkitConfigFileLocation);

		String portfolioToolkitConfigTemplateFilePath = portfolioToolkitConfigFileLocation
				+ System.getProperty("clientShortname") + FILENAME_SUFFIX + FILENAME_EXTENSION;

		Gson gson = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().disableInnerClassSerialization()
				.create();

		if (portfolioToolkitConfig.isPresent()) {
			String prettyJsonString = gson.toJson(portfolioToolkitConfig.get());

			String convertedJSONUTF8 = StringUtil.convertToUTF8(prettyJsonString);

			try {
				Files.deleteIfExists(Paths.get(portfolioToolkitConfigTemplateFilePath));
				try (FileWriter writer = new FileWriter(new File(portfolioToolkitConfigTemplateFilePath))) {
					writer.write(convertedJSONUTF8);
					writer.flush();
					LOGGER.info("Deployment of PortfolioToolkit Config successfully completed to location : {} ",
							portfolioToolkitConfigFileLocation);
				}
			} catch (IOException e) {
				LOGGER.error("Exception occurred while deploying TEMPLATEToolkitConfig file from location : {} ",
						portfolioToolkitConfigFileLocation);
				exceptionHandler.handleException(e);
			}
		}

	}

	/**
	 * Method to read Portfolio ToolKit Config From src/main/resources Location
	 * 
	 * @return List<String>
	 */
	private List<String> readTemplateToolkitConfigJson() {
		LOGGER.info("Reading TEMPLATE ToolKit Config Json File");

		String portfolioToolkitConfig = FILENAME_PREFIX + FILENAME_SUFFIX + FILENAME_EXTENSION;
		List<String> configList = new LinkedList<>();

		try (InputStream inputStream = getClass().getResourceAsStream("/" + portfolioToolkitConfig)) {
			try (BufferedReader br = new BufferedReader(new InputStreamReader(inputStream))) {
				configList = br.lines().collect(Collectors.toList());
			}
		} catch (IOException e) {
			LOGGER.error("Exception occurred while reading TEMPLATEToolkitConfig file from resources folder");
			exceptionHandler.handleException(e);
		}

		return configList;
	}

}