/**
 * 
 */
package com.bfm.aap.pmdx.manager.constant;

import org.apache.commons.lang3.StringUtils;

import com.bfm.util.BFMUtil;

/**
 * @author hthakkar
 *
 */
public final class PrivateMarketsDXManagerConstants {

	private PrivateMarketsDXManagerConstants() {

	}

	public static final String HUB_CONFIG = "hubConfig";
	public static final String ENCRYPTED_CREDENTIALS = "encryptedCredentials";
	public static final String PORTFOLIOTOOLKIT_CONFIG = "portfolioToolkitConfig";
	public static final String DEV_TST_POST_REFRESH_SETUP = "preProdPostRefreshSetup";

	public static final String ENV_NAME = System.getProperty("env.name");
	public static final String CLIENT_ABBREV = "ClientAbbrev";
	public static final String ENVIRONMENT = StringUtils.defaultString(BFMUtil.getBfmToken(CLIENT_ABBREV), ENV_NAME);

	public static final String SOURCE_INSIGHT = "INSIGHT";
	public static final String SOURCE_INVEST = "INVEST";

	public static final String SERVICE_INVESTMENTS = "Investments";
	public static final String SERVICE_CRM = "CRM";

	public static final String NEW_LINE_SEPARATOR = System.getProperty("line.separator");
	public static final String UNDERSCORE = "_";
	public static final String PARAM_USERNAME = System.getProperty("username");
	public static final String PARAM_DATASOURCE = System.getProperty("dataSource");
	public static final String COLOR_RED = "RED";
	public static final String COLOR_BLUE = "BLUE";
	public static final String EFRONT_CLIENTS = "eFrontClients";
	public static final String SERVICES_DEFINITION = "servicesDefinition";
	public static final String HUB_CONFIG_FILENAME_EXTENSION = ".properties";
	public static final String CREDENTIALS_FILENAME_EXTENSION = ".pwd";
	public static final String FILENAME_PREFIX = "PrivateMarketsDxHub_";
	public static final String BACKUP_FILE_SUFFIX = "_BK_";
	public static final String BACKUP_DATE_FORMAT_PATTERN = "MMdduuuu";
	public static final String BACKUP_TIME_FORMAT_PATTERN = "hh:mm:ss";
	public static final String CONFIG_FILE_SUFFIX = "-PMDXHub.pwd";
	public static final String CREDENTIALS_FILENAME = PrivateMarketsDXManagerConstants.PARAM_USERNAME + CONFIG_FILE_SUFFIX;
	
	public static final String LOG_COLOR_COMMENT = "<<<<<<< Inside color : {}   <<<<<<<<";
	public static final String LOG_HUB_CONFIG_DEPLOY_EXCEPTION_COMMENT = "Exception occurred while deploying HubConfig file from location : {} ";
	public static final String LOG_HUB_CONFIG_READ_EXCEPTION_COMMENT = "Exception occurred while reading HubConfig file from location : {}";
	public static final String LOG_HUB_BACKUP_EXCEPTION_COMMENT = "Exception occurred while backing up the old hub config file ";
	public static final String LOG_CREDENTIALS_BACKUP_EXCEPTION_COMMENT = "Exception occurred while backing up the encrypted credential file ";
	public static final String LOG_HUB_CONFIG_UNABLE_TO_FIND_FILE_EXCEPTION_COMMENT = "Unable to find hubConfig File at location : {}";

	public static final String OPENING_CURLYBRACKET = "{";
	public static final String CLOSING_CURLYBRACKET = "}";

}
