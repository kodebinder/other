package com.bfm.aap.pmdx.manager.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.bfm.aap.pmdx.manager.constant.PrivateMarketsDXManagerConstants;
import com.bfm.aap.pmdx.manager.exception.ExceptionHandler;
import com.bfm.aap.privatemarkets.common.util.StringUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;

@Component
public class PrivateMarketsDXManagerHubFileWriteUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(PrivateMarketsDXManagerHubFileWriteUtil.class);

	private List<String> hashedComments = new LinkedList<>();

	private final PrivateMarketsDXManagerUtil privateMarketsDXManagerUtil;
	private final ExceptionHandler exceptionHandler;

	@Autowired
	public PrivateMarketsDXManagerHubFileWriteUtil(
			@Qualifier("privateMarketsDXManagerUtil") PrivateMarketsDXManagerUtil privateMarketsDXManagerUtil,
			@Qualifier("exceptionHandler") ExceptionHandler exceptionHandler) {
		this.privateMarketsDXManagerUtil = privateMarketsDXManagerUtil;
		this.exceptionHandler = exceptionHandler;
	}

	/**
	 * Method check if Stand alone or Multi Tenant Client For Stand alone client
	 * Drop Existing File and Create a fresh file For BEN Client keep updating same
	 * file
	 * 
	 * @param path
	 * @param convertedJSONUTF8
	 * @return void
	 */
	private void createConfig(String path, String convertedJSONUTF8EFrontClients,
			String convertedJSONUTF8ServicesDefinition) {
		try {
			try (FileWriter writer = new FileWriter(new File(path))) {
				writeToHubConfigFile(convertedJSONUTF8EFrontClients, convertedJSONUTF8ServicesDefinition, writer);
				LOGGER.info("Deployment of Hub Config successfully completed to location : {} ", path);
			}
		} catch (IOException e) {
			LOGGER.info(PrivateMarketsDXManagerConstants.LOG_HUB_CONFIG_DEPLOY_EXCEPTION_COMMENT, path);
			exceptionHandler.handleException(e);
		}
	}

	/**
	 * Method to write the convertedJSONUTF8 to Hub config file
	 * 
	 * @param convertedJSONUTF8
	 * @param writer
	 * @throws IOException
	 */
	public void writeToHubConfigFile(String convertedJSONUTF8EFrontClients, String convertedJSONUTF8ServicesDefinition,
			FileWriter writer) throws IOException {
		String prefixEFrontClients = PrivateMarketsDXManagerConstants.EFRONT_CLIENTS + "=";
		String prefixServicesDefinition = PrivateMarketsDXManagerConstants.SERVICES_DEFINITION + "=";
		String delimiter = "\\";
		convertedJSONUTF8EFrontClients = prefixEFrontClients + convertedJSONUTF8EFrontClients.replace("},",
				"}," + delimiter + PrivateMarketsDXManagerConstants.NEW_LINE_SEPARATOR);
		convertedJSONUTF8ServicesDefinition = prefixServicesDefinition + convertedJSONUTF8ServicesDefinition
				.replace("},", "}," + delimiter + PrivateMarketsDXManagerConstants.NEW_LINE_SEPARATOR);
		List<String> commentsList = getHashedComments().stream().map(Object::toString).collect(Collectors.toList());
		for (String comment : commentsList) {
			writer.write(comment);
			writer.write(PrivateMarketsDXManagerConstants.NEW_LINE_SEPARATOR);
		}
		writer.write(convertedJSONUTF8EFrontClients);
		writer.write(PrivateMarketsDXManagerConstants.NEW_LINE_SEPARATOR);
		writer.write(convertedJSONUTF8ServicesDefinition);
		writer.flush();
	}

	/**
	 * @param hubConfigFileLocation
	 * @param jsonElement
	 * @param color
	 * @return void
	 */
	public void writeFileBasedOnColor(String hubConfigFileLocation, JsonElement jsonElementEFrontClients,
			JsonElement jsonElementServicesDefinition, String color) {
		LOGGER.info(PrivateMarketsDXManagerConstants.LOG_COLOR_COMMENT, color);

		String hubConfigFilePath = privateMarketsDXManagerUtil.getHubConfigFilePath(hubConfigFileLocation, color);

		Gson gson = new GsonBuilder().disableHtmlEscaping().disableInnerClassSerialization().create();

		String prettyJsonStringEFrontClients = gson.toJson(jsonElementEFrontClients);
		String prettyJsonStringServicesDefinition = gson.toJson(jsonElementServicesDefinition);

		String convertedJSONUTF8EFrontClients = StringUtil.convertToUTF8(prettyJsonStringEFrontClients);
		String convertedJSONUTF8ServicesDefinition = StringUtil.convertToUTF8(prettyJsonStringServicesDefinition);

		createConfig(hubConfigFilePath, convertedJSONUTF8EFrontClients, convertedJSONUTF8ServicesDefinition);
	}

	/**
	 * Fetch the hashed comments
	 * 
	 * @return
	 */
	public List<String> getHashedComments() {
		return hashedComments;
	}

	/**
	 * Set the hashed comments
	 * 
	 * @param hashedComments
	 * @return void
	 */
	public void setHashedComments(List<String> hashedComments) {
		this.hashedComments = hashedComments;
	}
}
