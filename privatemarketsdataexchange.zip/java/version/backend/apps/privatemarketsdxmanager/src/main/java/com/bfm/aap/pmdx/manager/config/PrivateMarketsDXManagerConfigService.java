package com.bfm.aap.pmdx.manager.config;

import java.util.Properties;

public interface PrivateMarketsDXManagerConfigService {
    Properties getProperties();
}
