/**
 * 
 */
package com.bfm.aap.pmdx.manager.service.preprodsetup;

import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.bfm.aap.pmdx.manager.constant.PrivateMarketsDXManagerConstants;
import com.bfm.aap.pmdx.manager.exception.ExceptionHandler;
import com.bfm.aap.privatemarkets.dao.AcctInfoDao;
import com.bfm.aap.privatemarkets.dao.CountersDao;
import com.bfm.aap.privatemarkets.dao.DaoFactory;
import com.bfm.aap.privatemarkets.dao.PriceHierarchyDao;
import com.bfm.aap.privatemarkets.dao.model.AcctInfo;
import com.bfm.aap.privatemarkets.dao.model.Counters;
import com.bfm.aap.privatemarkets.dao.model.PriceHierarchy;
import com.bfm.aap.privatemarkets.dao.model.PriceHierarchyPK;
import com.bfm.port.logical.portfolio.MutablePortfolio;
import com.bfm.port.logical.portfolio.PortfolioImpl;
import com.bfm.portgroup.api.beam2.PortGroupAPIService;

/**
 * @author hthakkar
 *
 */
@Service
public class PreProdSetupPostRefreshServiceImpl implements PreProdSetupPostRefreshService {
	private static final Logger LOGGER = LoggerFactory.getLogger(PreProdSetupPostRefreshServiceImpl.class);

	private MutablePortfolio portfolio;
	private final ExceptionHandler exceptionHandler;
	private final PortGroupAPIService portGroupAPIService;
	private final DaoFactory daoFactory;
	private static final String RISK_POS_TABLE = "risk_pos";
	private static final String PORTFOLIO_TYPE = "ANALYTICAL";
	private static final String ACCT_NAMES = "acctNames";
	private static final String PORT_GROUP_NAMES = "portGroupNames";
	
	@Autowired
	public PreProdSetupPostRefreshServiceImpl(
			@Qualifier("portGroupAPIService") PortGroupAPIService portGroupAPIService,
			DaoFactory daoFactory,
			@Qualifier("exceptionHandler") ExceptionHandler exceptionHandler) {
		this.portGroupAPIService = portGroupAPIService;
		this.daoFactory = daoFactory;
		this.exceptionHandler = exceptionHandler;
		portfolio = new PortfolioImpl();
	}

	/* (non-Javadoc)
	 * @see com.bfm.aap.pmdx.manager.service.preprodsetup.PreProdSetupPostRefreshService#runPreProdDBQueries()
	 */
	@Override
	public void runPreProdDBQueries() {
		LOGGER.info("{} Running DB Insert Queries started", PrivateMarketsDXManagerConstants.ENVIRONMENT);
		setupAccountInfo();
		setupPriceHierarchy();
		setupCounters();
	}
	
	private void setupCounters() {
		String signature = "Y";
		String privIDType = "PRIV_ID";
		String pmdxBrokerType = "PMDXBROKER";
		String pmdxInvstr = "PMDXINVSTR";
		loadCounter(signature, privIDType);
		loadCounter(null, pmdxBrokerType);
		loadCounter(null, pmdxInvstr);
	}

	/**
	 * @param counter
	 * @param privIDType
	 */
	private void loadCounter(String signature, String type) {
		CountersDao countersDao = this.daoFactory.getDao(CountersDao.class, true);
		Optional<Counters> existing = countersDao.load(type);
		if(!existing.isPresent()) {
			LOGGER.info("{} Counter not available and will be created", type);
			Counters newCounter = new Counters();
			newCounter.setType(type);
			newCounter.setCounter(1);
			newCounter.setSignature(signature);
			countersDao.create(newCounter);
			LOGGER.info("{} Counter successfully created from Stored Procedure get_batch_counter", type);
		} else {
			LOGGER.info("{} Counter successfully fetched", type);
		}
	}

	private void setupPriceHierarchy() {
		String priceGroup = "NAV";
		String groupOrder = "ZZZ";
		String purpose = "EFRO";
		PriceHierarchyDao priceHierarchyDao = this.daoFactory.getDao(PriceHierarchyDao.class, true);
		Optional<PriceHierarchy> existing = priceHierarchyDao.load(priceGroup, purpose);
		if (!existing.isPresent()) {
			LOGGER.info("{} Price Hierarchy not available and will be created", priceGroup);
			PriceHierarchy newPriceHierarchy = new PriceHierarchy();
			PriceHierarchyPK newPriceHierarchyPK = new PriceHierarchyPK();
			newPriceHierarchyPK.setPriceGroup(priceGroup);
			newPriceHierarchyPK.setGroupOrder(groupOrder);
			newPriceHierarchy.setKey(newPriceHierarchyPK);
			newPriceHierarchy.setPurpose(purpose);
			priceHierarchyDao.create(newPriceHierarchy);
		} else {
			LOGGER.info("{} Price Hierarchy successfully fetched", priceGroup);
		}
	}

	/**
	 * 
	 */
	private void setupAccountInfo() {
		Integer acctCode = 8787687;
		String acctType = "U";
		
		String passedAcctNames = System.getProperty(ACCT_NAMES);
		String[] acctNames;
		if (passedAcctNames.contains(",")) {
			acctNames = passedAcctNames.split(",");
		} else {
			acctNames = new String[1];
			acctNames[0] = passedAcctNames;
		}
		
		for(String acctName : acctNames) {
			loadAccountInfo(acctCode++, acctName, acctName, acctType);
		}
	}

	/**
	 * @param acctCodeInvest
	 * @param acctNameInvest
	 * @param fullAcctNameInvest
	 * @param acctType
	 */
	private void loadAccountInfo(Integer acctCode, String acctName, String fullAcctName, String acctType) {
		AcctInfoDao acctInfoDao = this.daoFactory.getDao(AcctInfoDao.class, true);
		List<AcctInfo> acctInfoList = acctInfoDao.getAcctInfo(acctName, acctType);
		if (CollectionUtils.isEmpty(acctInfoList)) {
			LOGGER.info("{} Client Name not available and will be created", acctName);
			AcctInfo newAcctInfo = new AcctInfo();
			newAcctInfo.setAcctType(acctType);
			newAcctInfo.setShortname(acctName);
			newAcctInfo.setFullName(fullAcctName);
			newAcctInfo.setAcctCode(acctCode);
			acctInfoDao.insertAcctInfo(newAcctInfo);
		} else {
			LOGGER.info("{} Client Name successfully fetched", acctName);
		}
	}

	/* (non-Javadoc)
	 * @see com.bfm.aap.pmdx.manager.service.preprodsetup.PreProdSetupPostRefreshService#createPreProdPortfolioGroup()
	 */
	@Override
	public void createPreProdPortfolioGroup() {
		String currency = "USD";
		LOGGER.info("{} Port Group Setup started", PrivateMarketsDXManagerConstants.ENVIRONMENT);
		
		String passedPortGroupNames = System.getProperty(PORT_GROUP_NAMES);
		String[] portGroupNames;
		if (passedPortGroupNames.contains(",")) {
			portGroupNames = passedPortGroupNames.split(",");
			
		} else {
			portGroupNames = new String[1];
			portGroupNames[0] = passedPortGroupNames;
		}
		for(String portGroupName : portGroupNames) {
			if(!fetchPortGroupFromAPI(portGroupName)) {
				createPortGroupFromAPI(portGroupName, currency);
			}
		}
	}

	/**
	 * @throws IOException
	 */
	private boolean fetchPortGroupFromAPI(String portGroup) {
		try {
			Integer portCode = this.portGroupAPIService.getPortfolioCode(portGroup);
			LOGGER.info("Response of {} from Port Group API : {}", portGroup, portCode);
	        if(Objects.nonNull(portCode)) {
	        	LOGGER.info("{} Port Group successfully fetched", portGroup);
	        	return true;
	        } else {
	        	LOGGER.info("{} Port Group not available and will be created", portGroup);
	        	return false;
	        }
		} catch (Exception e) {
			LOGGER.error("Exception occurred while fetching {} Port Group", portGroup);
			exceptionHandler.handleException(e);
		}
		return false;
	}

	/**
	 * @param portRequest
	 * @param currency
	 */
	private void createPortGroupFromAPI(String portGroupName, String currency) {
		createPortfolioGroup(portGroupName, currency);
		try {
			String portGroupResponse = this.portGroupAPIService.createPortGroup(portfolio.convertToJSON());
			LOGGER.info("Response from Port Group API : {}", portGroupResponse);
			LOGGER.info("{} Port Group successfully created", portGroupName);
			
		} catch (Exception e) {
			LOGGER.error("Exception occurred while creating {} Port Group ", portGroupName);
			exceptionHandler.handleException(e);
		}
	}

	private void createPortfolioGroup(String portfolioName, String currency) {
    	portfolio.setPortfolioTicker(portfolioName);
        portfolio.setPortfolioName(portfolioName);
        portfolio.setLegalName(portfolioName);
        portfolio.setPositionTable(RISK_POS_TABLE);
        portfolio.setCurrency(currency);
        portfolio.setNote(portfolioName);
        portfolio.setPortfolioPerms(PORTFOLIO_TYPE);
        portfolio.setPortfolioType(PORTFOLIO_TYPE);
        portfolio.setTestPortfolio(Boolean.FALSE);
    }
	
}
