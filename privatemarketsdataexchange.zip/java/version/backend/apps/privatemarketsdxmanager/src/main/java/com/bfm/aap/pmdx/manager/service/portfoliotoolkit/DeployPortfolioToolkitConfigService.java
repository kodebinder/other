package com.bfm.aap.pmdx.manager.service.portfoliotoolkit;

import java.util.Optional;

import com.google.gson.JsonObject;

/**
 * Create and Deploy Portfolio Toolkit Config
 */
public interface DeployPortfolioToolkitConfigService {
    
	Optional<JsonObject> createPortfolioToolkitConfig();
	void deployPortfolioToolkitConfig(Optional<JsonObject> portfolioToolkitConfig);   
}
