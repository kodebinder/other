/**
 * 
 */
package com.bfm.aap.pmdx.manager.validator;

/**
 * @author hthakkar
 *
 */
public interface PrivateMarketsDXManagerValidator {
	
	/**
	 * Validates Hub Config Input Parameters
	 * @return
	 */
	boolean validateHubConfigInputParameters();
	
	/**
	 * Validates PortfolioToolkit Config Input Parameters
	 * @return
	 */
	boolean validatePortfolioToolkitConfigInputParameters();
	
	/**
	 * Validates Encrypted Credentials Input Parameters
	 * @return
	 */
	boolean validateEncryptedCredentialsInputParameters();
	
	/**
	 * Validates PreProd Setup Post Refresh Input Parameters
	 * @return
	 */
	boolean validatePreProdSetupPostRefreshInputParameters();
	
}
