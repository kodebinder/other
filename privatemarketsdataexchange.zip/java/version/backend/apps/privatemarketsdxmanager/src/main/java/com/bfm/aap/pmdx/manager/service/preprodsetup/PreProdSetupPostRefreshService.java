/**
 * 
 */
package com.bfm.aap.pmdx.manager.service.preprodsetup;

/**
 * @author hthakkar
 *
 * Run INSERT Queries and create Portfolio Group for Pre-Prod Setup post refresh
 */
public interface PreProdSetupPostRefreshService {
	void runPreProdDBQueries();
	void createPreProdPortfolioGroup();
}
