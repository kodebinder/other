package com.bfm.aap.pmdx.manager.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HubServicesDefinition {

	private String serviceName;
	private String[] entityTypes;
	private String[] requiredEntityTypes;
	private String[] clientNames;
}