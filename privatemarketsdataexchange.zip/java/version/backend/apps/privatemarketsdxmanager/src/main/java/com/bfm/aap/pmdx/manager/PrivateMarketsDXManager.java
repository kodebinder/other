package com.bfm.aap.pmdx.manager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.cassandra.CassandraAutoConfiguration;
import org.springframework.boot.autoconfigure.freemarker.FreeMarkerAutoConfiguration;
import org.springframework.context.ConfigurableApplicationContext;

import com.bfm.aap.pmdx.manager.exception.ExceptionHandler;
import com.bfm.aap.pmdx.manager.executor.PrivateMarketsDXManagerExecutor;

@SpringBootApplication
@EnableAutoConfiguration(exclude = {
        CassandraAutoConfiguration.class,
		FreeMarkerAutoConfiguration.class})
public class PrivateMarketsDXManager {
	private static final Logger LOGGER = LoggerFactory.getLogger(PrivateMarketsDXManager.class);
	
	private static ExceptionHandler exceptionHandler;

	public static void main(String[] args) {
		try {
			LOGGER.info("Starting PMDX Manager Application...");
			ConfigurableApplicationContext applicationContext = SpringApplication.run(PrivateMarketsDXManager.class, args);
			PrivateMarketsDXManagerExecutor pmdxManager = applicationContext.getBean(PrivateMarketsDXManagerExecutor.class);
			exceptionHandler = applicationContext.getBean(ExceptionHandler.class);
			LOGGER.info("PMDX Manager Application started.");
			pmdxManager.execute();
	        exit(applicationContext);
			
		} catch (Exception e) {
			exceptionHandler.handleException(e);
			System.exit(-1);
		}
	}
	
	/**
	 * @param applicationContext
	 */
	private static void exit(ConfigurableApplicationContext applicationContext) {
        int exitCode = SpringApplication.exit(applicationContext, () -> 0);
        LOGGER.info("PMDX Manager Application exited gracefully");
        System.exit(exitCode);

    }
}
