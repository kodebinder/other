package com.bfm.aap.pmdx.manager.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.bfm.aap.pmdx.manager.constant.PrivateMarketsDXManagerConstants;
import com.bfm.aap.pmdx.manager.exception.ExceptionHandler;
import com.google.common.annotations.VisibleForTesting;

@Component
public class PrivateMarketsDXManagerHubFileReadUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(PrivateMarketsDXManagerHubFileReadUtil.class);
	private static final String COLOR = "color";

	private final PrivateMarketsDXManagerUtil privateMarketsDXManagerUtil;
	private final PrivateMarketsDXManagerHubFileWriteUtil privateMarketsDXManagerHubFileWriteUtil;
	private final ExceptionHandler exceptionHandler;

	@Autowired
	public PrivateMarketsDXManagerHubFileReadUtil(
			@Qualifier("privateMarketsDXManagerUtil") PrivateMarketsDXManagerUtil privateMarketsDXManagerUtil,
			@Qualifier("privateMarketsDXManagerHubFileWriteUtil") PrivateMarketsDXManagerHubFileWriteUtil privateMarketsDXManagerHubFileWriteUtil,
			@Qualifier("exceptionHandler") ExceptionHandler exceptionHandler) {
		this.privateMarketsDXManagerUtil = privateMarketsDXManagerUtil;
		this.privateMarketsDXManagerHubFileWriteUtil = privateMarketsDXManagerHubFileWriteUtil;
		this.exceptionHandler = exceptionHandler;
	}

	/**
	 * Method to read Hub Template Properties From src/main/resources Location
	 * 
	 * @return List<String>
	 */
	List<String> readHubTemplatePropertiesFile() {
		LOGGER.info("Reading Hub Config Json File");
		String hubConfig = "PrivateMarketsDxHub_TEMPLATE.properties";
		List<String> configList = new LinkedList<>();

		try (InputStream inputStream = getClass().getResourceAsStream("/" + hubConfig);
				BufferedReader br = new BufferedReader(new InputStreamReader(inputStream))) {
			configList = br.lines().collect(Collectors.toList());
		} catch (IOException e) {
			LOGGER.error("Exception occurred while reading HubConfig file from resources folder");
			exceptionHandler.handleException(e);
		}

		return configList;
	}

	/**
	 * Method to read Hub Config JSON from src/main/resources Location
	 * 
	 * @return List<String>
	 */
	public List<String> readHubConfigJson() {
		// Initializing a Hub Config File in Unix Location
		if (!initializeHubConfigFile()) {
			LOGGER.error("Cannot initialize Hub Config file");
			return new LinkedList<>();
		} else {
			String hubConfigFileLocation = privateMarketsDXManagerUtil
					.getFileLocation(PrivateMarketsDXManagerConstants.HUB_CONFIG);
			
			String color = System.getProperty(COLOR);
			
			String hubConfigFilePath = privateMarketsDXManagerUtil.getHubConfigFilePath(hubConfigFileLocation,
					PrivateMarketsDXManagerConstants.COLOR_RED);
			if (StringUtils.isNotBlank(color)) {
				hubConfigFilePath = privateMarketsDXManagerUtil.getHubConfigFilePath(hubConfigFileLocation,
						color);
			}
			
			List<String> configList = new LinkedList<>();

			try (BufferedReader br = Files.newBufferedReader(Paths.get(hubConfigFilePath))) {
				configList = br.lines().collect(Collectors.toList());

			} catch (IOException e) {
				LOGGER.info(PrivateMarketsDXManagerConstants.LOG_HUB_CONFIG_READ_EXCEPTION_COMMENT,
						hubConfigFileLocation);
				exceptionHandler.handleException(e);
			}

			return configList;
		}
	}

	/**
	 * Method initialize hub config file if not available at location
	 * 
	 * @return boolean
	 */
	@VisibleForTesting
	boolean initializeHubConfigFile() {
		String hubConfigFileLocation = privateMarketsDXManagerUtil
				.getFileLocation(PrivateMarketsDXManagerConstants.HUB_CONFIG);
		String hubConfigFilePathRed = privateMarketsDXManagerUtil.getHubConfigFilePath(hubConfigFileLocation,
				PrivateMarketsDXManagerConstants.COLOR_RED);
		String hubConfigFilePathBlue = privateMarketsDXManagerUtil.getHubConfigFilePath(hubConfigFileLocation,
				PrivateMarketsDXManagerConstants.COLOR_BLUE);

		List<String> hubConfigFiles = initializeHubConfigFilesBasedOnColor(hubConfigFilePathRed, hubConfigFilePathBlue);
		for (String hubConfigFilePath : hubConfigFiles) {
			Path path = getHubConfigFilePath(hubConfigFilePath);
			if (path.toFile().exists() && path.toFile().isFile()) {
				LOGGER.info("Hub File exists for processing : {}", true);
				try {
					privateMarketsDXManagerUtil.createBackup(path,PrivateMarketsDXManagerConstants.HUB_CONFIG_FILENAME_EXTENSION);
				} catch (IOException e) {
					LOGGER.error(PrivateMarketsDXManagerConstants.LOG_HUB_BACKUP_EXCEPTION_COMMENT);
					exceptionHandler.handleException(e);
				}
				LOGGER.info("Backing up old Hub config file successfully completed");
				return true;
			}
			try (FileWriter writer = new FileWriter(new File(hubConfigFilePath))) {
				// Creating a template object
				List<String> template = readHubTemplatePropertiesFile();
				if (!ObjectUtils.isEmpty(template)) {
					privateMarketsDXManagerHubFileWriteUtil.writeToHubConfigFile(template.toString(),
							template.toString(), writer);
					return true;
				}
			} catch (IOException e) {
				LOGGER.info(PrivateMarketsDXManagerConstants.LOG_HUB_CONFIG_DEPLOY_EXCEPTION_COMMENT, path);
				exceptionHandler.handleException(e);
			}
		}
		return false;
	}

	Path getHubConfigFilePath(String hubConfigFilePath) {
		return Paths.get(hubConfigFilePath);
	}

	/**
	 * Method to decide how many files to create based on color param Hub Config
	 * Json From src/main/resources Location
	 * 
	 * @return List<String>
	 */
	private List<String> initializeHubConfigFilesBasedOnColor(String hubConfigFilePathRed,
			String hubConfigFilePathBlue) {

		List<String> hubConfigFiles = new LinkedList<>();

		// Based on Color Passed as an argument we will create a first template file
		if (StringUtils.isNotEmpty(System.getProperty(COLOR))) {
			if (PrivateMarketsDXManagerConstants.COLOR_RED.equalsIgnoreCase(System.getProperty(COLOR))) {
				hubConfigFiles.add(hubConfigFilePathRed);
			} else if (PrivateMarketsDXManagerConstants.COLOR_BLUE.equalsIgnoreCase(System.getProperty(COLOR))) {
				hubConfigFiles.add(hubConfigFilePathBlue);
			}
		} else {
			hubConfigFiles.add(hubConfigFilePathRed);
			hubConfigFiles.add(hubConfigFilePathBlue);
		}

		return hubConfigFiles;
	}

}