/**
 * 
 */
package com.bfm.aap.pmdx.manager.service.encryptedcredentials;

import java.util.Optional;

/**
 * Create and Deploy Encrypted Credentials for PrivateMarketsDXHub
 *
 */
public interface DeployEncryptedCredentialsService {
	Optional<String> createEncryptedCredentials();
	void deployEncryptedCredentials(Optional<String> encryptedPassword);

}
