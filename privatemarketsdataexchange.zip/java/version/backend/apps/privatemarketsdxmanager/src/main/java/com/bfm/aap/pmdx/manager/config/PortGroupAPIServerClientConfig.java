/**
 * 
 */
package com.bfm.aap.pmdx.manager.config;

import java.util.concurrent.TimeUnit;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.bfm.aap.privatemarkets.dao.config.DatabaseConfiguration;
import com.bfm.beam2.Configs;
import com.bfm.beam2.ServiceProxyFactories;
import com.bfm.beam2.ServiceProxyFactory;
import com.bfm.portgroup.api.beam2.PortGroupAPIService;
import com.bfm.portgroup.api.beam2.PortGroupJsonMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author hthakkar
 *
 */
@Configuration
@PropertySource("classpath:database.properties")
@EnableJpaRepositories(basePackages = {"com.bfm.aap.privatemarkets.dao"})
@ComponentScan({"com.bfm.aap.privatemarkets.dao"})
@Import({DatabaseConfiguration.class})
public class PortGroupAPIServerClientConfig {
	
	@Bean
    public ServiceProxyFactory proxyFactory() {
        return ServiceProxyFactories.bmsServiceProxyFactory("PMDXManager");
    }

    @Bean
    public PortGroupAPIService portGroupAPIService() {
        return proxyFactory().getServiceProxy(PortGroupAPIService.class,
                Configs.builder().setTimeout(20, TimeUnit.SECONDS).build());
    }

    @Bean
    public ObjectMapper jsonMapper() {
        return new ObjectMapper();
    }

    @Bean
    public PortGroupJsonMapper portGroupJsonMapper() {
        return new PortGroupJsonMapper();
    }
}
