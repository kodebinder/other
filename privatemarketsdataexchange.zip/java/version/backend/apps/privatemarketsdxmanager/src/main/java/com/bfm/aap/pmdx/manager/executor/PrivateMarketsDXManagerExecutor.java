/**
 * 
 */
package com.bfm.aap.pmdx.manager.executor;

import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bfm.aap.pmdx.manager.constant.PrivateMarketsDXManagerConstants;
import com.bfm.aap.pmdx.manager.service.encryptedcredentials.DeployEncryptedCredentialsService;
import com.bfm.aap.pmdx.manager.service.hubconfig.DeployHubConfigService;
import com.bfm.aap.pmdx.manager.service.portfoliotoolkit.DeployPortfolioToolkitConfigService;
import com.bfm.aap.pmdx.manager.service.preprodsetup.PreProdSetupPostRefreshService;
import com.bfm.aap.pmdx.manager.validator.PrivateMarketsDXManagerValidator;
import com.google.gson.JsonObject;

/**
 * @author hthakkar 
 * PrivateMarketsDXManager Executor class for creating and deploying Configurations based on Config Type passed
 */
@Service
public class PrivateMarketsDXManagerExecutor {
	private static final Logger LOGGER = LoggerFactory.getLogger(PrivateMarketsDXManagerExecutor.class);
	private static final String CONFIG_TYPE = "configType";

	private final DeployHubConfigService deployHubConfigService;
	private final DeployPortfolioToolkitConfigService deployPortfolioToolkitConfigService;
	private final DeployEncryptedCredentialsService deployEncryptedCredentialsService;
	private final PrivateMarketsDXManagerValidator privateMarketsDXManagerValidator;
	private final PreProdSetupPostRefreshService preProdSetupPostRefreshService;

	@Autowired
	public PrivateMarketsDXManagerExecutor(final DeployHubConfigService deployHubConfigService,
			final DeployPortfolioToolkitConfigService deployPortfolioToolkitConfigService,
			final DeployEncryptedCredentialsService deployEncryptedCredentialsService,
			final PrivateMarketsDXManagerValidator privateMarketsDXManagerValidator,
			final PreProdSetupPostRefreshService preProdSetupPostRefreshService) {
		this.deployHubConfigService = deployHubConfigService;
		this.deployPortfolioToolkitConfigService = deployPortfolioToolkitConfigService;
		this.deployEncryptedCredentialsService = deployEncryptedCredentialsService;
		this.privateMarketsDXManagerValidator = privateMarketsDXManagerValidator;
		this.preProdSetupPostRefreshService = preProdSetupPostRefreshService;
	}

	/**
	 * Method execute which requires mandatory config type
	 * 
	 * @return void
	 */
	public void execute() {
		if (StringUtils.isEmpty(System.getProperty(CONFIG_TYPE))) {
			throw new RuntimeException("PMDX Manager Application requires mandatory config type for processing");
		}

		switch (System.getProperty(CONFIG_TYPE)) {
		case PrivateMarketsDXManagerConstants.HUB_CONFIG:
			createDeployHubConfig();
			break;

		case PrivateMarketsDXManagerConstants.PORTFOLIOTOOLKIT_CONFIG:
			createDeployPortfolioToolkitConfig();
			break;

		case PrivateMarketsDXManagerConstants.ENCRYPTED_CREDENTIALS:
			createDeployEncryptedCredentials();
			break;
			
		case PrivateMarketsDXManagerConstants.DEV_TST_POST_REFRESH_SETUP:
			setupPreProdPostRefresh();
			break;	

		default:
			throw new RuntimeException(
					"Value of config type " + System.getProperty(CONFIG_TYPE) + " passed is incorrect for processing");
		}
	}
	
	/**
	 * PreProd Setup post Refresh
	 * 
	 * @return void
	 */
	private void setupPreProdPostRefresh() {
		if (privateMarketsDXManagerValidator.validatePreProdSetupPostRefreshInputParameters()) {
			preProdSetupPostRefreshService.runPreProdDBQueries();
			preProdSetupPostRefreshService.createPreProdPortfolioGroup();
		}
	}

	/**
	 * Create and Deploy Encrypted Credentials for PrivateMarketsDXHub
	 * 
	 * @return void
	 */
	private void createDeployEncryptedCredentials() {
		if (privateMarketsDXManagerValidator.validateEncryptedCredentialsInputParameters()) {
			LOGGER.info("Deployment of Encrypted Credentials started");
			Optional<String> encryptedPassword = deployEncryptedCredentialsService.createEncryptedCredentials();
			if (encryptedPassword.isPresent())
				deployEncryptedCredentialsService.deployEncryptedCredentials(encryptedPassword);
		}
	}

	/**
	 * Create and Deploy PortfolioToolkit Config
	 * 
	 * @return void
	 */
	private void createDeployPortfolioToolkitConfig() {
		if (privateMarketsDXManagerValidator.validatePortfolioToolkitConfigInputParameters()) {
			LOGGER.info("Deployment of PortfolioToolkit Config started");
			Optional<JsonObject> portfolioToolkitConfig = deployPortfolioToolkitConfigService
					.createPortfolioToolkitConfig();
			if (portfolioToolkitConfig.isPresent())
				deployPortfolioToolkitConfigService.deployPortfolioToolkitConfig(portfolioToolkitConfig);
		}
	}

	/**
	 * Create and Deploy Hub Config
	 * 
	 * @return void
	 */
	private void createDeployHubConfig() {
		if (privateMarketsDXManagerValidator.validateHubConfigInputParameters()) {
			LOGGER.info("Deployment of Hub Config started");
			Optional<JsonObject> hubConfig = deployHubConfigService.createHubConfig();
			if (hubConfig.isPresent())
				deployHubConfigService.deployHubConfig(hubConfig);
		}
	}

}
