package com.bfm.aap.pmdx.manager.exception;

import com.bfm.aap.pmdx.notification.model.EmailParams;
import com.bfm.aap.pmdx.notification.model.NotificationEnums;
import com.bfm.aap.pmdx.notification.model.NotificationParams;
import com.bfm.aap.pmdx.notification.service.Notification;
import com.bfm.util.BFMUtil;
import com.google.common.annotations.VisibleForTesting;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class ExceptionHandler {
    private static final String APP_NAME = "PMDXManager";
    private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionHandler.class);

    public void handleException(Exception e) {
        LOGGER.error(e.getMessage(), e);
        final NotificationParams notificationParams = createNotificationParams(e);
        Notification.sendNotification(notificationParams);
    }

    @VisibleForTesting
    NotificationParams createNotificationParams(Exception e) {
        return new NotificationParams.Builder(
                NotificationEnums.NotificationSeverity.PURPLE, APP_NAME)
                .setEmailBuilder(new EmailParams.Builder()
                        .setSubject(e.getMessage())
                        .setException(e)
                        .setUserName(BFMUtil.getUser()))
                .build();
    }
}
