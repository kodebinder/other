package com.bfm.aap.privatemarkets.asset.reader;

import com.bfm.aap.privatemarkets.asset.reader.exception.AssetReaderException;
import com.bfm.beam2.error.Beam2Exception;
import com.bfm.beam2.server.internal.ExceptionMapper;

public class AssetReaderExceptionMapper implements ExceptionMapper<AssetReaderException> {

    @Override
    public Beam2Exception toBeam2Exception(AssetReaderException exception) {
        return new Beam2Exception.ProcessingError("Issue in request processing - " + exception.getMessage());
    }
}
