package com.bfm.aap.privatemarkets.asset.reader.api;

import com.bfm.aap.pmdx.redblue.util.Beam2APIService;
import com.bfm.aap.privatemarkets.asset.reader.exception.AssetReaderException;
import com.bfm.aap.privatemarkets.asset.reader.service.AssetService;
import com.bfm.aap.privatemarkets.common.util.AssetCommonConstant;
import com.bfm.beam2.RequestContext;
import com.bfm.beam2.annotation.Beam2Method;
import com.bfm.beam2.annotation.Beam2Service;
import com.bfm.beam2.annotation.Param;
import com.bfm.beam2.stream.Observable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
@Beam2Service
public class AssetReaderService implements Beam2APIService {

    private final AssetService assetService;

    @Autowired
    public AssetReaderService(final AssetService assetService) {
        this.assetService = assetService;
    }

    /**
     * Method used to read Asset related to a given cusip.
     *
     * @param cusip identifier.
     * @return Alternative asset as JSON String.
     */
    @Beam2Method(command = AssetCommonConstant.GET_ASSET)
    public Map<String, Object> getAsset(RequestContext requestContext, @Param("cusip") String cusip) throws AssetReaderException {
        return assetService.getAsset(cusip, requestContext.user());
    }

    /**
     * Method used to read Assets related to given cusips.
     *
     * @param cusips for which alternative assets are required.
     * @return Alternative asset list as JSON String.
     */
    @Beam2Method(command = AssetCommonConstant.GET_ASSETS)
    public Map<String, Object> getAssets(RequestContext requestContext, @Param("cusips") List<String> cusips) throws AssetReaderException {
        return assetService.getAssets(cusips, requestContext.user());

    }

    @Beam2Method(command = AssetCommonConstant.GET_ASSETS_ASYNC)
    public Observable<Map<String, Object>> getAssetsAsync(RequestContext requestContext, @Param("cusips") List<String> cusips) throws AssetReaderException {
        return assetService.getAssetsAsync(cusips, requestContext.user());

    }

    /**
     * This method returns attributes for a given cusip in a json format
     *
     * @param requestContext
     * @param cusip
     * @return
     */
    @Beam2Method(command = AssetCommonConstant.GET_ASSET_ATTRIBUTES)
    public String getAssetAttributes(RequestContext requestContext, @Param("cusip") String cusip) throws AssetReaderException {
        return assetService.getAssetAttributes(cusip, requestContext.user());
    }

    /**
     * This method returns attributes for a given list of cusips in a json format
     *
     * @param requestContext
     * @param cusips
     * @return
     */
    @Beam2Method(command = AssetCommonConstant.GET_ASSETS_ATTRIBUTES)
    public String getAssetsAttributes(RequestContext requestContext, @Param("cusips") List<String> cusips) throws AssetReaderException {
        return assetService.getAssetsAttributes(cusips, requestContext.user());
    }

    /**
     * @param requestContext
     * @param cusips
     * @return
     * @throws AssetReaderException
     */
    @Beam2Method(command = AssetCommonConstant.GET_ASSETS_ATTRIBUTES_ASYNC)
    public Observable<String> getAssetsAttributesAsync(RequestContext requestContext, @Param("cusips") List<String> cusips) throws AssetReaderException {
        return assetService.getAssetsAttributesAsync(cusips, requestContext.user());
    }

    /**
     * This method returns the underlying cusips for a given FUND cusip
     *
     * @param requestContext
     * @param cusip
     * @return
     */
    @Beam2Method(command = AssetCommonConstant.GET_ASSET_BREAKDOWN)
    public String getAssetBreakdown(RequestContext requestContext, @Param("cusip") String cusip) throws AssetReaderException {
        return assetService.getAssetBreakdown(cusip, requestContext.user());
    }

    /**
     * This method returns the underlying cusips for a given list of FUND cusips
     *
     * @param requestContext
     * @param cusips
     * @return
     */
    @Beam2Method(command = AssetCommonConstant.GET_ASSETS_BREAKDOWN)
    public String getAssetsBreakdown(RequestContext requestContext, @Param("cusips") List<String> cusips) throws AssetReaderException {
        return assetService.getAssetsBreakdown(cusips, requestContext.user());
    }

    /**
     * This method returns the underlying cusips for a given list of FUND cusips
     *
     * @param requestContext
     * @param cusips
     * @return
     */
    @Beam2Method(command = AssetCommonConstant.GET_ASSETS_BREAKDOWN_ASYNC)
    public Observable<String> getAssetsBreakdownAsync(RequestContext requestContext, @Param("cusips") List<String> cusips) throws AssetReaderException {
        return assetService.getAssetsBreakdownAsync(cusips, requestContext.user());
    }

}
