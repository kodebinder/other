package com.bfm.aap.privatemarkets.asset.reader;

import com.bfm.aap.pmdx.notification.model.EmailParams;
import com.bfm.aap.pmdx.notification.model.NotificationEnums;
import com.bfm.aap.pmdx.notification.model.NotificationParams;
import com.bfm.aap.pmdx.notification.service.Notification;
import com.bfm.aap.pmdx.redblue.PmdxServiceType;
import com.bfm.aap.pmdx.redblue.util.Beam2APIService;
import com.bfm.aap.pmdx.redblue.util.BmsHelper;
import com.bfm.aap.privatemarkets.asset.reader.api.AssetReaderService;
import com.bfm.aap.privatemarkets.common.constant.CommonConstants;
import com.bfm.aap.privatemarkets.common.util.AssetCommonConstant;
import com.bfm.aap.privatemarkets.decode.service.DecodeServiceImpl;
import com.bfm.beam2.server.ServiceGateway;
import com.bfm.util.BFMUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableScheduling
@EnableAspectJAutoProxy
@ComponentScan({"com.bfm.aap.pmdx.logmetrics", "com.bfm.aap.privatemarkets.asset.reader",
        "com.bfm.aap.privatemarkets.datadictionary", "com.bfm.aap.privatemarkets.common",
        "com.bfm.aap.privatemarkets.dao", "com.bfm.aap.privatemarkets.decode"})
@PropertySource(name = "properties", value = "${spring.config.location}")
public class PrivateMarketsAssetReader {
    private static final Logger LOGGER = LoggerFactory.getLogger(PrivateMarketsAssetReader.class);

    public static void main(String[] args) {
        try {
            LOGGER.debug("Starting Private Markets Asset Reader Server...");
            new PrivateMarketsAssetReader().startReader();
            LOGGER.debug("Private Markets Asset Reader Server started");
        } catch (Exception e) {
            LOGGER.error("Error starting server", e);
            final NotificationParams notificationParams = new NotificationParams.Builder(
                    NotificationEnums.NotificationSeverity.PURPLE, AssetCommonConstant.READER_SERVER_SHORT_NAME)
                    .setEmailBuilder(new EmailParams.Builder().setSubject("Error starting server")
                            .setUserRequest(null).setException(e).setUserName(BFMUtil.getUser())
                            .setMode(AssetCommonConstant.NETWORK_MODE.name()))
                    .build();

            Notification.sendNotification(notificationParams);
            System.exit(-1);
        }

    }

    private void startReader() throws InterruptedException {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(
                PrivateMarketsAssetReader.class);
        context.getBean(DecodeServiceImpl.class).waitForDecodeCacheInit();
        ServiceGateway serviceGateway = context.getBean(ServiceGateway.class);
        Beam2APIService service = context.getBean(AssetReaderService.class);
        BmsHelper.registerBMS(serviceGateway, service, PmdxServiceType.PRIVATEMARKETS_ASSET_READER,
                CommonConstants.DX_ASSET_READER_SOURCE_ID_OVERRIDE);
        context.registerShutdownHook();
    }

}