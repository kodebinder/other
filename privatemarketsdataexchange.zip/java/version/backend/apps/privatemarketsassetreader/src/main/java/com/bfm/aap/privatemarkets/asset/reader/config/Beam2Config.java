package com.bfm.aap.privatemarkets.asset.reader.config;

import com.bfm.aap.privatemarkets.asset.reader.AssetReaderExceptionMapper;
import com.bfm.aap.privatemarkets.common.util.AssetCommonConstant;
import com.bfm.beam2.server.ServiceGateway;
import com.bfm.beam2.server.ServiceGateways;
import com.bfm.beam2.server.bmsintegration.BmsServiceGateways;
import com.bfm.beam2.permission.PermissionStores;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Beam2Config {

    @Value("${worker.thread.count:10}")
    private int workerThreadCount;

    @Bean
    public ServiceGateway serviceGateway() {
        BmsServiceGateways.BmsServiceGatewayConfig config = (new BmsServiceGateways.BmsServiceGatewayConfig())
                .name(AssetCommonConstant.READER_SERVER_NAME).numberOfWorkers(workerThreadCount)
                .permissionStore(PermissionStores.bfmPermissionsSetStore()).addExceptionMapper(new AssetReaderExceptionMapper());
        return ServiceGateways.bmsGateway(config);
    }
}
