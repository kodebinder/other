package com.bfm.aap.privatemarkets.asset.reader.api;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import com.bfm.aap.privatemarkets.asset.reader.exception.AssetReaderException;
import com.bfm.aap.privatemarkets.asset.reader.service.AssetServiceImpl;

import com.bfm.beam2.stream.Observable;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import com.bfm.beam2.RequestContext;
import com.bfm.util.BFMDate;

@MockitoSettings(strictness = Strictness.LENIENT)
@ExtendWith(MockitoExtension.class)
public class AssetReaderServiceTest {

	@InjectMocks
	private AssetReaderService assetReaderService;
	@Mock
	AssetServiceImpl assetService;
	@Mock
	RequestContext requestContext;

	private final String testCusip = "BRSFU54D0";
	private List<String> cusips;

	@BeforeAll
	public static void setUpBeforeClass() {
		System.setProperty("defaultWebServer", "https://dev.blackrock.com");
		System.setProperty("AUTH_METHOD", "SERVER");
		System.setProperty("bms.port", "5000");
		System.setProperty("mode","BLUE");
		System.setProperty("BRS." + "AladdinAltsURL", "red");
	}

	@BeforeEach
	void setUp() {
		cusips = new ArrayList<>();
		cusips.add(testCusip);
		when(requestContext.user()).thenReturn("tsgops");
		
	}

	@Test
	public void getAsset_Success() throws AssetReaderException, ParseException {
		when(assetService.getAsset(anyString(), anyString())).thenReturn(getMockAsset());
		assertFalse(assetReaderService.getAsset(requestContext, testCusip).isEmpty());
	}

	@Test
	public void getAssets_Success() throws AssetReaderException, ParseException, InterruptedException, ExecutionException, TimeoutException {
		when(assetService.getAssets(anyList(), anyString())).thenReturn(getMockAsset());
		assertFalse(assetReaderService.getAssets(requestContext, cusips).isEmpty());
	}

	private Map<String, Object> getMockAsset() throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
		Date startDateOne = dateFormat.parse("01-DEC-2014");
		Date stopDateOne = dateFormat.parse("22-DEC-2022");
		Date startDateTwo = dateFormat.parse("03-DEC-2014");
		Date stopDateTwo = dateFormat.parse("28-DEC-2022");
		BFMDate startDateFirst = new BFMDate(startDateOne);
		BFMDate stopDateFirst = new BFMDate(stopDateOne);
		BFMDate startDateSecond = new BFMDate(startDateTwo);
		BFMDate stopDateSecond = new BFMDate(stopDateTwo);
		Double secAttrDefnIdOne = (double) 106990;
		Double secAttrDefnIdTwo = (double) 104761;

		Map<String, Object> first = new HashMap<>();
		first.put("source", "BRS");
		first.put("cusip", "BRTNZDTL5");
		first.put("start_date", startDateFirst);
		first.put("sec_attribute_defn_id", secAttrDefnIdOne);
		first.put("stop_date", stopDateFirst);
		first.put("sec_attribute_value_id", 9150491.0);
		first.put("value_char", "2016");

		Map<String, Object> second = new HashMap<>();
		second.put("source", "BRS");
		second.put("cusip", "RDDPLNND8");
		second.put("start_date", startDateSecond);
		second.put("sec_attribute_defn_id", secAttrDefnIdTwo);
		second.put("stop_date", stopDateSecond);
		second.put("sec_attribute_value_id", 9150492.0);
		second.put("value_num", 23);

		Map<String, Object> third = new HashMap<>();
		third.put("MTN", 'N');
		third.put("reviewed_by", "miqbal");
		third.put("wi_flag", 'N');
		third.put("settle_cal", "US_BMA");
		third.put("currency", "USD");
		third.put("sec_desc1", "21st Century Comm Partners LP");
		third.put("cusip", "RDDPLRDU2");
		third.put("sec_attribute_id", 12345);

		Map<String, Object> map = new HashMap<>();
		map.put(first.get("cusip") + "", first);
		map.put(second.get("cusip") + "", second);
		map.put(third.get("cusip") + "", third);

		return map;

	}
}
