package com.bfm.aap.privatemarkets.asset.reader.service;

import com.bfm.aap.privatemarkets.asset.reader.BaseIT;

import cucumber.api.java.Before;

@SuppressWarnings("deprecation")
public class CucumberConfiguration extends BaseIT {

	@Before
	public void setup_cucumber_spring_context() {
		// Dummy method so cucumber will recognize this class as glue and use its
		// context configuration.
	}

}