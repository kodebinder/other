package com.bfm.aap.privatemarkets.asset.reader.util;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.builder.RecursiveToStringStyle;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bfm.aap.pmdx.reader.service.PrivateMarketsAssetReaderService;
import com.bfm.aap.pmdx.redblue.PmdxServiceSource;
import com.bfm.aap.pmdx.redblue.PmdxServiceType;
import com.bfm.aap.pmdx.redblue.RedBlueNetworkChecker;
import com.bfm.aap.privatemarkets.common.util.DateUtil;
import com.bfm.aap.privatemarkets.dao.CusipAliasesDao;
import com.bfm.aap.privatemarkets.dao.IssuerSectorDao;
import com.bfm.aap.privatemarkets.dao.NewIssueInfoDao;
import com.bfm.aap.privatemarkets.dao.SecAttributeValueDao;
import com.bfm.aap.privatemarkets.dao.SecurityMasterDao;
import com.bfm.aap.privatemarkets.dao.model.IssuerSector;
import com.bfm.aap.privatemarkets.dao.model.NewIssueInfo;
import com.bfm.aap.privatemarkets.dao.model.SecAttributeValue;
import com.bfm.aap.privatemarkets.dao.model.SecMaster;
import com.bfm.beam2.BRElemConverter;
import com.bfm.beam2.Configs;
import com.bfm.beam2.ServiceProxyFactories;
import com.bfm.beam2.ServiceProxyFactory;
import com.bfm.privatemarkets.beam2.util.Proto3JsonConverter;

public class TestHelper {
	private static final String ASSET_SOURCE = "ALTS";
	private static final Logger LOGGER = LoggerFactory.getLogger(TestHelper.class);
	
    public static PrivateMarketsAssetReaderService getAssetReaderBeam2Service() {
        ServiceProxyFactories.SPFConfig config = new ServiceProxyFactories.SPFConfig()
                .setAppName("privateMarketsAssetReaderService")
                .setTimeout(120, TimeUnit.SECONDS);
        config.setBrElemConverterFactories(Collections.<BRElemConverter.Factory<?>>singletonList(Proto3JsonConverter.factory()));
        ServiceProxyFactory factory = ServiceProxyFactories.bmsServiceProxyFactory(config);
		return factory.getServiceProxy(PrivateMarketsAssetReaderService.class,
				Configs.builder().setSourceId(getSourceId()).setTimeout(120, TimeUnit.SECONDS).build());
    }

    public static int getAssetReaderSourceId(String color) {
        if (color.equalsIgnoreCase("RED")) {
            return PmdxServiceSource.PRIVATEMARKETS_ASSET_READER_RED.getSourceID();
        } else if (color.equalsIgnoreCase("BLUE")) {
            return PmdxServiceSource.PRIVATEMARKETS_ASSET_READER_BLUE.getSourceID();
        }
        return -1;
    }

    public static void checkSecMaster(String cusip, Map<String, String> attributes, SecurityMasterDao securityMasterDao, 
    		boolean isAttributeReq) {
        SecMaster secMaster = securityMasterDao.getSecurity(cusip);
        LOGGER.info("secMaster : {}", ReflectionToStringBuilder.toString(secMaster, new RecursiveToStringStyle()));
        LOGGER.info("attributes Cache : {}",ReflectionToStringBuilder.toString(attributes, new RecursiveToStringStyle()));
    }

    public static void checkCusipAlias(String cusip, Map<String, String> attributes, CusipAliasesDao cusipAliasesDao) {
        assertEquals(cusipAliasesDao.getCusipByEFrontId(attributes.get("assetId")), cusip);
    }

    public static void checkSecAttributeValue(String cusip, Map<String, String> attributes, SecAttributeValueDao secAttributeValueDao) {
        List<SecAttributeValue> secAttributeValues = secAttributeValueDao.getSecAttributeValuePerCusip(cusip);
        Map<Long, SecAttributeValue> existingValues = getCurrentActiveAttributes(secAttributeValues);
        
        if (existingValues.containsKey(131572L)) {
        	assertSecAttributeValue(existingValues.get(131572L).getSource(), attributes.get("clientName"), existingValues.get(131572L).getValueChar());
        }
        if (existingValues.containsKey(122471L)) {
        	assertSecAttributeValue(existingValues.get(122471L).getSource(), "EQ", existingValues.get(122471L).getValueChar());
        }
        if (existingValues.containsKey(129325L)) {
        	assertSecAttributeValue(existingValues.get(129325L).getSource(), "Ara Strategic Fund IV LP", existingValues.get(129325L).getValueChar());
        }
        if (existingValues.containsKey(129324L)) {
        	assertSecAttributeValue(existingValues.get(129324L).getSource(), "EUROPE", existingValues.get(129324L).getValueChar());
        }
        if (existingValues.containsKey(129326L)) {
        	assertSecAttributeValue(existingValues.get(129326L).getSource(), "GBP", existingValues.get(129326L).getValueChar());
        }
        if (existingValues.containsKey(106990L)) {
        	assertSecAttributeValue(existingValues.get(106990L).getSource(), "2012", existingValues.get(106990L).getValueChar());
        }
    }
    
    private static void assertSecAttributeValue(String source, String expectedValueChar, String actualValueChar) {
    	assertEquals(ASSET_SOURCE, source);
    	assertEquals(expectedValueChar, actualValueChar);
    }

    public static void checkNewIssueInfo(String cusip, Map<String, String> attributes, NewIssueInfoDao newIssueInfoDao) {
    	NewIssueInfo loadNewIssueInfo = newIssueInfoDao.loadNewIssueInfo(cusip);
    	assertNotNull(loadNewIssueInfo);
        assertEquals(cusip, loadNewIssueInfo.getCusip());
    }

    public static void checkIssuerSector(String cusip, Map<String, String> attributes, IssuerSectorDao issuerSectorDao) {
        Optional<IssuerSector> issuerSector = issuerSectorDao.load(cusip, "ASTTYP", (short) 1);
        issuerSector.ifPresent(sector -> assertNotNull(sector));
    }

    private static Map<Long, SecAttributeValue> getCurrentActiveAttributes(List<SecAttributeValue> existingValues) {
        if (CollectionUtils.isEmpty(existingValues)) {
            return new HashMap<>();
        }
        return existingValues.stream()
                .filter(value -> (value.getStopDate() == null) || (value.getStopDate().gt(DateUtil.todayBFMDateTime())))
                .collect(Collectors.toMap(SecAttributeValue::getSecAttributeDefnId, Function.identity()));
    }
    
    @SuppressWarnings("unchecked")
	public static Map<String, String> convertAttributesObject(String attribute, String cusip) throws ParseException {
    	JSONParser parser = new JSONParser();  
		JSONObject json = (JSONObject) parser.parse(attribute); 
		return (Map<String, String>) json.get(cusip);
    }
    
    public static String getCusip(String cusipType, Map<String, String> cusips) {
    	if("FUND".equalsIgnoreCase(cusipType))
        	return cusips.get("cusip_fund");
        else if("FUND_COMPANY".equalsIgnoreCase(cusipType))
        	return cusips.get("cusip_fund_company");
        else if("COMPANY".equalsIgnoreCase(cusipType))
        	return cusips.get("cusip_company");
        else if("REAL_ESTATE".equalsIgnoreCase(cusipType))
        	return cusips.get("cusip_real_estate");
        else if("FUND_REAL_ESTATE".equalsIgnoreCase(cusipType))
        	return cusips.get("cusip_fund_real_estate");
        else return null;
    }
    
    public static int getSourceId() {
		// Initialize RedBlueNetworkChecker with its own DataSource
		RedBlueNetworkChecker.initDataSource();
		return RedBlueNetworkChecker.getSourceIdByTypeAndColor(PmdxServiceType.PRIVATEMARKETS_ASSET_READER,
				getPrimaryNetwork());
	}

	public static com.bfm.aap.pmdx.redblue.NetworkMode getPrimaryNetwork() {
		try {
			return RedBlueNetworkChecker.getPrimaryNetworkPredicate().getPrimaryNetwork();
		} catch (Exception e) {
			throw new RuntimeException("Error while getting primary network:" + e.getMessage(), e);
		}
	}
	
}
