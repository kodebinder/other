package com.bfm.aap.privatemarkets.asset.reader.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.bfm.aap.pmdx.reader.service.PrivateMarketsAssetReaderService;
import com.bfm.aap.privatemarkets.asset.reader.util.TestHelper;
import com.bfm.aap.privatemarkets.dao.CusipAliasesDao;
import com.bfm.aap.privatemarkets.dao.IssuerSectorDao;
import com.bfm.aap.privatemarkets.dao.NewIssueInfoDao;
import com.bfm.aap.privatemarkets.dao.SecAttributeValueDao;
import com.bfm.aap.privatemarkets.dao.SecurityMasterDao;

import cucumber.api.java8.En;
import io.cucumber.datatable.DataTable;

@SuppressWarnings("deprecation")
public class AssetReaderAttributesStepDefinition implements En {
    @Autowired
    @Qualifier("securityMasterDaoImpl")
    private SecurityMasterDao securityMasterDao;

    @Autowired
    @Qualifier("cusipAliasesDaoImpl")
    private CusipAliasesDao cusipAliasesDao;

    @Autowired
    @Qualifier("secAttributeValueDaoImpl")
    private SecAttributeValueDao secAttributeValueDao;

    @Autowired
    @Qualifier("newIssueInfoDaoImpl")
    private NewIssueInfoDao newIssueInfoDao;

    @Autowired
    @Qualifier("issuerSectorDaoImpl")
    private IssuerSectorDao issuerSectorDao;

    private PrivateMarketsAssetReaderService privateMarketsAssetReaderService;
    private Map<String, String> cusips;
    private Map<String, String> attributes;
    private String cusip;
    private String attribute;

	public AssetReaderAttributesStepDefinition(){
		Given("the following cusips are available for fetching the Attributes:", (DataTable dataTable) -> {
			cusips = dataTable.asMap(String.class, String.class);
        });
		
		When("user sends request with CUSIPs for {string}", (String cusipType) -> {
            privateMarketsAssetReaderService = TestHelper.getAssetReaderBeam2Service();
            cusip = TestHelper.getCusip(cusipType, cusips);
            attribute = privateMarketsAssetReaderService.getAssetAttributes(cusip);
            attributes = TestHelper.convertAttributesObject(attribute, cusip);
        });
		
		Then("attrubutes should be available for sec_master", () -> {
            TestHelper.checkSecMaster(cusip, attributes, securityMasterDao, true);
        });
		
		Then("attrubutes should be available for sec_attribute_value", () -> {
			TestHelper.checkSecAttributeValue(cusip, attributes, secAttributeValueDao);
        });
		
        Then("attrubutes should be available for new_issue_info", () -> {
        	TestHelper.checkNewIssueInfo(cusip, attributes, newIssueInfoDao);
        });
        
        Then("attrubutes should be available for issuer_sector", () -> {
        	TestHelper.checkIssuerSector(cusip, attributes, issuerSectorDao);
        });
        
    }
}
