package com.bfm.aap.privatemarkets.asset.reader.runner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(features = "classpath:features", 
				 glue = "com.bfm.aap.privatemarkets.asset.reader.service",
				 plugin = { "html:src/integration-test/resources/cucumber",
						    "json:src/integration-test/resources/cucumber/cucumber-privatemarketsassetreader.json",
						    "junit:src/integration-test/resources/cucumber/cucumber.xml",
						    "pretty:src/integration-test/resources/cucumber/cucumber-pretty.txt" },
				 tags = "not @ignore")
public class PrivateMarketsAssetReaderTestSuiteIT {
	
}