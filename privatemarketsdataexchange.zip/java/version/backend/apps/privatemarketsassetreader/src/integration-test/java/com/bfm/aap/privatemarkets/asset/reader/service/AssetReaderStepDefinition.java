package com.bfm.aap.privatemarkets.asset.reader.service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.bfm.aap.pmdx.reader.service.PrivateMarketsAssetReaderService;
import com.bfm.aap.privatemarkets.asset.reader.util.TestHelper;
import com.bfm.aap.privatemarkets.dao.CusipAliasesDao;
import com.bfm.aap.privatemarkets.dao.IssuerSectorDao;
import com.bfm.aap.privatemarkets.dao.NewIssueInfoDao;
import com.bfm.aap.privatemarkets.dao.SecAttributeValueDao;
import com.bfm.aap.privatemarkets.dao.SecurityMasterDao;

import cucumber.api.java8.En;
import io.cucumber.datatable.DataTable;

@SuppressWarnings("deprecation")
public class AssetReaderStepDefinition implements En {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AssetReaderStepDefinition.class);
	
    @Autowired
    @Qualifier("securityMasterDaoImpl")
    private SecurityMasterDao securityMasterDao;

    @Autowired
    @Qualifier("cusipAliasesDaoImpl")
    private CusipAliasesDao cusipAliasesDao;

    @Autowired
    @Qualifier("secAttributeValueDaoImpl")
    private SecAttributeValueDao secAttributeValueDao;

    @Autowired
    @Qualifier("newIssueInfoDaoImpl")
    private NewIssueInfoDao newIssueInfoDao;

    @Autowired
    @Qualifier("issuerSectorDaoImpl")
    private IssuerSectorDao issuerSectorDao;

    private PrivateMarketsAssetReaderService privateMarketsAssetReaderService;
    private Map<String, Object> asset;
    private Map<String, String> cusips;
    private Map<String, String> attributes;
    private List<String> cusipsList;
    private String cusip;

	@SuppressWarnings("unchecked")
	public AssetReaderStepDefinition(){
		Given("the following cusips are available for fetching the Assets:", (DataTable dataTable) -> {
			cusips = dataTable.asMap(String.class, String.class);
        });
		
		When("user sends request for {string}", (String type) -> {
            privateMarketsAssetReaderService = TestHelper.getAssetReaderBeam2Service();
            cusip = TestHelper.getCusip(type, cusips);
            asset = privateMarketsAssetReaderService.getAsset(cusip);
            attributes = (Map<String, String>) asset.get(cusip);
            LOGGER.info("attributes cache : {}", attributes);
        });
		
		Then("the value of attributes equals the value in sec_master", () -> {
            TestHelper.checkSecMaster(cusip, attributes, securityMasterDao, false);
        });
		
		Then("the value of attributes equals the value in sec_attribute_value", () -> {
			TestHelper.checkSecAttributeValue(cusip, attributes, secAttributeValueDao);
        });
		
        Then("the value of attributes equals the value in new_issue_info", () -> {
        	TestHelper.checkNewIssueInfo(cusip, attributes, newIssueInfoDao);
        });
        
        Then("the value of attributes equals the value in issuer_sector", () -> {
        	TestHelper.checkIssuerSector(cusip, attributes, issuerSectorDao);
        });
        
        When("user sends request", () -> {
            privateMarketsAssetReaderService = TestHelper.getAssetReaderBeam2Service();
            cusipsList = cusips.values()
            		.stream()
            		.filter(cusip -> !cusip.equals("value"))
            		.distinct()
            		.collect(Collectors.toList());
            asset = privateMarketsAssetReaderService.getAssets(cusipsList);
        });
		
		Then("the value of attributes equals the value in sec_master for multiple cusips", () -> {
			for (String cusip : cusipsList) {
                attributes = (Map<String, String>) asset.get(cusip);
                TestHelper.checkSecMaster(cusip, attributes, securityMasterDao, false);
            }
        });
		
		Then("the value of attributes equals the value in sec_attribute_value for multiple cusips", () -> {
			for (String cusip : cusipsList) {
                attributes = (Map<String, String>) asset.get(cusip);
                TestHelper.checkSecAttributeValue(cusip, attributes, secAttributeValueDao);
            }
        });
		
        Then("the value of attributes equals the value in new_issue_info for multiple cusips", () -> {
        	for (String cusip : cusipsList) {
                attributes = (Map<String, String>) asset.get(cusip);
                TestHelper.checkNewIssueInfo(cusip, attributes, newIssueInfoDao);
            }
        });
        
        Then("the value of attributes equals the value in issuer_sector for multiple cusips", () -> {
        	for (String cusip : cusipsList) {
                attributes = (Map<String, String>) asset.get(cusip);
                TestHelper.checkIssuerSector(cusip, attributes, issuerSectorDao);
            }
        });
    }
}
