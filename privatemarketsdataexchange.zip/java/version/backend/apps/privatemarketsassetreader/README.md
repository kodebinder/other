# PrivateMarketAssetLoader

# Table of Contents
- [Description](README.md##Description)
- [Overview](README.md##Overview)
- [External Dependency](README.md##ExternalDependency)
- [Factors to Consider](README.md##FactorsToConsider)
- [Quick Start](README.md##QuickStart)
- [EndPoints](README.md##EndPoints)
- [Running in Development](README.md##RunningInDevelopment)
- [Build -> Release -> Deploy](README.md##BuildReleaseDeploy)

--------------------------------------------------------------------------------------------------------------------------------
## Description
The Private Market Asset Reader is a Distributed Enterprise Java(8) application server (the 'PrivateMarketAssetReader') built on micro-services architecture.
The server facilitates alternative investment security retrival for Efront Securities in Blackrock

## Overview
A distributed enterprise data server (the 'PrivateMarketAssetReader') that services Alternative investments and business processes on Aladdin.  The server acts as an abstraction over the many disparate data sources.

## ExternalDependency
---- Decode Server
---- Security Server


## FactorsToConsider
- Architecture will support frictionless development across a globally distributed team
- Maintain a low-level of complexity
    - Architecture is simple to understand
    - Easy to modify, reduce, and/or augment
    - Stay as DRY as possible
- Documentation is well defined and done in concert with development, not after
    - Every change is a pull request to force code reviews
- New contributors must be able to quickly become productive
- Leverage git and the open software development standards
- Scale through separation of concern, isolation, and functional decoupling
- Segment data in functional areas to facilitate functional decoupling and isolation
- Avoid service coupling
- Multi-tenancy and distributed across multiple data-centers
- Able to run multiple instances to satisfy scalability and availability requirements
- Eliminate BMS boilerplate by leveraging BEAM 2
- Is divided into following modules:
> - PrivateMarket Asset Reader Core - Has API for asset retrieval.

------------------------------------------------------------------------------------------------------------------------

## QuickStart
1. Check out the project from git repository (ssh://git@git.blackrock.com/aap/privatemarketsdataexchange.git). Checkout Java directory as Maven Project. Build the whole suit or individual services as per requirement
2. Run As maven build... -> clean install [skip test] alts-investment-systems-backend-parent OR
3.  Run As maven build... -> clean install [skip test] alts-investment-systems-apps-parent > alts-investment-systems-libs-parent OR
4.  Run As maven build... -> clean install [skip test] privatemarketsassetreader
5.  Run PrivateMarketAssetLoader with  arguments marked in RunnningInDevelopment section.
------------------------------------------------------------------------------------------------------------------------
## RunningInDevelopment
VM Args to be used while running via an IDE:

```
-DdefaultWebServer=https://dev.blackrock.com
-DAUTH_METHOD=SERVER
-Dbms.port=5000
-Dmode=Blue
-DBRS.STAT_COLLECTOR_BASE_URL=http://devcxsl001:60026/
-DapplicationName=PrivateMarketAssetReader
-DoverrideDXAssetReaderSourceId=373737
-Dspring.config.location=file:C:/schema_files/PrivateMarketsReader.properties
 ```

 --------------------------------------------------------------------------------------------------
## EndPoints
```
- Command: getAsset
  Request : SingleAssetRequest
  Response : SingleAssetResponse

- Command: getAssets
  Request : MultipleAssetRequest
  Response : MultipleAssetResponse
 ```
--------------------------------------------------------------------------------------------------
## BuildReleaseDeploy
1. Building the project locally
    - The Project uses Maven build system .
    - If you are new to Maven go through the following setup links:
    - https://webster.bfm.com/Wiki/display/rm/Maven+-+Getting+Started
    - https://webster.bfm.com/Wiki/display/rm/IntelliJ+Setup
    - https://webster.bfm.com/Wiki/display/rm/Create+settings.xml+and+toolchains.xml
    - https://webster.bfm.com/Wiki/display/rm/How+To%3A+Set+up+Maven+in+local

2. Use "mvn clean install -DskipTests" to build your project locally.The sequence of build needs to be privatemarketsassetloader > privatemarkets-dao > privatemarkets-datadictionary > privatemarkets-common .
(Alternatively complete suite can be build as well -> alts-investment-systems-apps-parent > alts-investment-systems-libs-parent to be even more precise just build alts-investment-systems-backend-parent and that should suffice)

3. Building the project on [4D](https://dev.blackrock.com/apps/4d/#/openProject/aap/a4a-backend)

4. **Release element**: [privatemarketsassetreader.jar (Blue)](https://webster.bfm.com/weblications/perms/summary.epl?elemId=691354) OR [privatemarketsassetreader.jar (Red)](https://webster.bfm.com/weblications/perms/summary.epl?elemId=691350)

5. **Appserver element** : [PrivateMarketsAssetReader_BLUE](https://webster.bfm.com/weblications/perms/summary.epl?elemId=691196) OR [PrivateMarketsAssetReader_RED](https://webster.bfm.com/weblications/perms/summary.epl?elemId=691195)

6. **Directory element** :  [/usr/local/bfm/apps/privatemarketsdataexchange/blue](https://webster.bfm.com/weblications/perms/summary.epl?elemId=690292) OR [ /usr/local/bfm/apps/privatemarketsdataexchange/red](https://webster.bfm.com/weblications/perms/summary.epl?elemId=690289)

7. **Source Ids** : [PRIVATEMARKETS_ASSET_READER_BLUE](https://webster.bfm.com/weblications/perms/summary.epl?elemId=691199) OR [PRIVATEMARKETS_ASSET_READER_RED](https://webster.bfm.com/weblications/perms/summary.epl?elemId=691198)

8. **Property file** : [/usr/local/bfm/apps/privatemarketsdataexchange/blue/PrivateMarketsReader.properties](https://webster.bfm.com/weblications/perms/summary.epl?elemId=691640) OR [/usr/local/bfm/apps/privatemarketsdataexchange/red/PrivateMarketsReader.properties](https://webster.bfm.com/weblications/perms/summary.epl?elemId=691641)
------------------------------------------------------------------------------------------------------------------------
