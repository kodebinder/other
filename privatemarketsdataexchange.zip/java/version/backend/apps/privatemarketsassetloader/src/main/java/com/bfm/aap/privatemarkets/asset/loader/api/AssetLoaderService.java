package com.bfm.aap.privatemarkets.asset.loader.api;

import com.bfm.aap.pmdx.model.Asset;
import com.bfm.aap.pmdx.model.Instrument;
import com.bfm.aap.pmdx.model.Performance;
import com.bfm.aap.pmdx.model.ShareClass;
import com.bfm.aap.pmdx.redblue.util.Beam2APIService;
import com.bfm.aap.privatemarkets.asset.loader.service.AssetService;
import com.bfm.aap.privatemarkets.asset.loader.util.AssetUtil;
import com.bfm.aap.privatemarkets.common.model.LoaderResponse;
import com.bfm.aap.privatemarkets.common.model.MultipleLoaderResponse;
import com.bfm.aap.privatemarkets.common.model.SingleLoaderResponse;
import com.bfm.aap.privatemarkets.common.util.AssetCommonConstant;
import com.bfm.beam2.RequestContext;
import com.bfm.beam2.annotation.AllowByPerm;
import com.bfm.beam2.annotation.Beam2Method;
import com.bfm.beam2.annotation.Beam2Service;
import com.bfm.beam2.annotation.Param;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Beam2Service
public class AssetLoaderService implements Beam2APIService {

	private static final Logger logger = LoggerFactory.getLogger(AssetLoaderService.class);
	private final AssetService assetService;
	private static final String LOG_MSG = "{} request received";

	@Autowired
	public AssetLoaderService(AssetService assetService) {
		this.assetService = assetService;
	}

	/**
	 * An API which accepts a proto object Asset and create/update an asset This
	 * method returns SingleLoaderResponse<Map<String, Object>> which is a wrapper
	 * around LoaderResponse. Using SingleLoaderResponse<T>, "message", "success" and
	 * "data" can be retrieved. "message" contains the reason if asset create/update
	 * failed or "Operation Successful" if asset create/update passed. "success"
	 * contains either true or false. A method isSuccess() can be used to retrieve
	 * value of success. "data" is the Type parameter and is a Map<String, Object>,
	 * it contains request data and other details based on the request if it is
	 * update or create.
	 *
	 * @param requestContext request
	 * @param asset asset
	 * @return SingleLoaderResponse<Map < String, Object>>
	 */
	@Beam2Method(command = AssetCommonConstant.UPSERT_ASSET)
	public SingleLoaderResponse upsertAltsAsset(RequestContext requestContext, @Param("request") Asset asset) {
		logger.info(LOG_MSG, AssetCommonConstant.UPSERT_ASSET);
		SingleLoaderResponse singleProtoResponse = new SingleLoaderResponse();
		singleProtoResponse.setLoaderResponse(assetService.upsertAltsAsset(requestContext.user(), asset));
		logSuccessOrFailure(singleProtoResponse.getLoaderResponse().isSuccess(), "asset");
		return singleProtoResponse;
	}

	/**
	 * An API which accepts a list of proto objects Asset and create/update the
	 * assets This method returns MultipleLoaderResponse<Map<String, Object>> which
	 * is a wrapper around List<LoaderResponse> Using MultipleLoaderResponse<T>,
	 * "message", "success" and "data" can be retrieved. "message" contains
	 * "Operation Successful" if all asset create/update passed or "Operation
	 * Failed" if all the asset create/update request failed. It also contains
	 * number of failed request and number of success request if atleast one request
	 * failed. "success" contains either true or false. A method isSuccess() can be
	 * used to retrieve value of success. "data" is the Type parameter and is a
	 * Map<String, Object>, it contains request data and other details based on the
	 * request if it is update or create.
	 *
	 * @param requestContext request
	 * @param assets asset
	 * @return MultipleLoaderResponse
	 */
	@Beam2Method(command = AssetCommonConstant.UPSERT_ASSETS)
	public MultipleLoaderResponse upsertAltsAssets(RequestContext requestContext,
			@Param("request") List<Asset> assets) {
		logger.info(LOG_MSG, AssetCommonConstant.UPSERT_ASSETS);
		List<LoaderResponse> responses = assetService.upsertAltsAssets(requestContext.user(), assets);
		MultipleLoaderResponse multipleLoaderResponse = new MultipleLoaderResponse();
		setLoaderResponse(multipleLoaderResponse, responses);
		logSuccessOrFailure(multipleLoaderResponse.isSuccess(), "asset");
		return multipleLoaderResponse;
	}

	
	/**
	 * An API which accepts a proto object Instrument and create/update an asset This
	 * method returns SingleLoaderResponse<Map<String, Object>> which is a wrapper
	 * around LoaderResponse. Using SingleLoaderResponse<T>, "message", "success" and
	 * "data" can be retrieved. "message" contains the reason if asset create/update
	 * failed or "Operation Successful" if instrument create/update passed. "success"
	 * contains either true or false. A method isSuccess() can be used to retrieve
	 * value of success. "data" is the Type parameter and is a Map<String, Object>,
	 * it contains request data and other details based on the request if it is
	 * update or create.
	 *
	 * @param requestContext request
	 * @param instrument instrument
	 * @return SingleLoaderResponse<Map < String, Object>>
	 */
	@Beam2Method(command = AssetCommonConstant.UPSERT_INSTRUMENT)
	public MultipleLoaderResponse upsertAltsInstrument(RequestContext requestContext, @Param("request") Instrument instrument) {
		logger.info(LOG_MSG, AssetCommonConstant.UPSERT_INSTRUMENT);
		MultipleLoaderResponse multipleLoaderResponse = new MultipleLoaderResponse();
		List<LoaderResponse> responses = assetService.upsertInstrument(requestContext.user(), instrument);
		setLoaderResponse(multipleLoaderResponse, responses);
		logSuccessOrFailure(multipleLoaderResponse.isSuccess(), "instrument");
		return multipleLoaderResponse;
	}
	
	/**
	 * An API which accepts a list of Performance proto objects and creates or updates
	 * the performance items. This method returns LoaderResponse, whereby
	 * "message", "isSuccess", and "data" can be retrieved. "message" contains
	 * "Operation Successful" if all performance create/update passed or "Operation
	 * Failed" if all the performance create/update request failed. It also contains the
	 * number of failed requests and number of successful requests if at least one request
	 * failed. "isSuccess" contains either true or false. A method isSuccess() can be
	 * used to retrieve value of success. "data" is a Map<String, Object>, it contains
	 * request data and other details based on the request, like whether it is
	 * update or create.
	 *
	 * @param requestContext context
	 * @param request request
	 * @return SingleLoaderResponse
	 */
	@Beam2Method(command = AssetCommonConstant.UPSERT_STATIC_PERFORMANCE)
	public SingleLoaderResponse upsertStaticPerformance(RequestContext requestContext,
														  @Param("request") Performance request) {
		logger.info(LOG_MSG, AssetCommonConstant.UPSERT_STATIC_PERFORMANCE);
		SingleLoaderResponse response = new SingleLoaderResponse();
		response.setLoaderResponse(assetService.upsertStaticPerformance(requestContext.user(), request));
		logSuccessOrFailure(response.getLoaderResponse().isSuccess(), "performance");
		return response;
	}

	/**
	 * An API which accepts a list of Performance proto objects and creates or updates
	 * the performance items. This method returns LoaderResponse, whereby
	 * "message", "isSuccess", and "data" can be retrieved. "message" contains
	 * "Operation Successful" if all performance create/update passed or "Operation
	 * Failed" if all the performance create/update request failed. It also contains the
	 * number of failed requests and number of successful requests if at least one request
	 * failed. "isSuccess" contains either true or false. A method isSuccess() can be
	 * used to retrieve value of success. "data" is a Map<String, Object>, it contains
	 * request data and other details based on the request, like whether it is
	 * update or create.
	 *
	 * @param requestContext context
	 * @param requests request
	 * @return SingleLoaderResponse
	 */
	@Beam2Method(command = AssetCommonConstant.UPSERT_STATIC_PERFORMANCE_LIST)
	@AllowByPerm(type="VIEW")
	public MultipleLoaderResponse upsertStaticPerformanceList(RequestContext requestContext,
															 @Param("request") List<Performance> requests) {
		logger.info(LOG_MSG, AssetCommonConstant.UPSERT_STATIC_PERFORMANCE_LIST);
		List<LoaderResponse> responses = assetService.upsertStaticPerformanceList(requestContext.user(), requests);
		MultipleLoaderResponse finalResponse = new MultipleLoaderResponse();
		setLoaderResponse(finalResponse, responses);
		logSuccessOrFailure(finalResponse.isSuccess(), "performance");

		return finalResponse;
	}
	

	/**
	 * An API which accepts a proto object ShareClass and create/update an ShareClass This
	 * method returns MultipeLoaderResponse<Map<String, Object>> which is a wrapper
	 *  around List<LoaderResponse> Using MultipleLoaderResponse<T>,
	 * "message", "success" and "data" can be retrieved. "message" contains
	 * "Operation Successful" if all ShareClass create/update passed or "Operation
	 * Failed" if all the ShareClass create/update request failed. . A method isSuccess() can be used to retrieve
	 * value of success. "data" is the Type parameter and is a Map<String, Object>,
	 * it contains request data and other details based on the request if it is
	 * update or create.
	 *
	 * @param requestContext context
	 * @param shareClass share class
	 * @return MultipleLoaderResponse<Map < String, Object>>
	 */
	@Beam2Method(command = AssetCommonConstant.UPSERT_SHARECLASS)
	public MultipleLoaderResponse upsertAltsShareClass(RequestContext requestContext, @Param("request") ShareClass shareClass) {
		logger.info(LOG_MSG, AssetCommonConstant.UPSERT_SHARECLASS);
		MultipleLoaderResponse multipleLoaderResponse = new MultipleLoaderResponse();
		List<LoaderResponse> responses = assetService.upsertShareClass(requestContext.user(), shareClass);
		setLoaderResponse(multipleLoaderResponse, responses);
		logSuccessOrFailure(multipleLoaderResponse.isSuccess(), "shareClass");
		return multipleLoaderResponse;
	}

	private void logSuccessOrFailure(boolean bool, String entityType) {
		if (bool) {
			logger.info("assetLoaderEntityType = {}", entityType);
		} else {
			logger.info("assetLoaderEntityErr = {}", entityType);
		}
	}

	private void setLoaderResponse(MultipleLoaderResponse finalResponse, List<LoaderResponse> responses) {
		long numOfFailedRequests = responses.stream().filter(response -> !response.isSuccess()).count();

		if (numOfFailedRequests != 0) {
			setLoaderFailureResponse(finalResponse, responses, numOfFailedRequests);
		} else {
			AssetUtil.setMultipleLoaderResponse(finalResponse, responses, AssetCommonConstant.SUCCESS_MESSAGE, true);
		}
	}

	private void setLoaderFailureResponse(MultipleLoaderResponse finalResponse, List<LoaderResponse> responses,
										 long numOfFailedRequests) {
		String message;
		if (numOfFailedRequests == responses.size()) {
			message = "All of the requests failed";
		} else {
			message = "Failed requests: " + numOfFailedRequests + "\n" +
					"Successful requests: " + (responses.size() - numOfFailedRequests);
		}

		AssetUtil.setMultipleLoaderResponse(finalResponse, responses, message, false);
	}
}
