package com.bfm.aap.privatemarkets.asset.loader;

import com.bfm.aap.pmdx.notification.model.EmailParams;
import com.bfm.aap.pmdx.notification.model.NotificationEnums;
import com.bfm.aap.pmdx.notification.model.NotificationParams;
import com.bfm.aap.pmdx.notification.service.Notification;
import com.bfm.aap.pmdx.redblue.PmdxServiceType;
import com.bfm.aap.pmdx.redblue.util.Beam2APIService;
import com.bfm.aap.pmdx.redblue.util.BmsHelper;
import com.bfm.aap.privatemarkets.asset.loader.api.AssetLoaderService;
import com.bfm.aap.privatemarkets.common.constant.CommonConstants;
import com.bfm.aap.privatemarkets.common.util.AssetCommonConstant;
import com.bfm.aap.privatemarkets.decode.service.DecodeServiceImpl;
import com.bfm.beam2.server.ServiceGateway;
import com.bfm.util.BFMUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableScheduling
@EnableAspectJAutoProxy
@ComponentScan({"com.bfm.aap.pmdx.logmetrics", "com.bfm.aap.privatemarkets.asset.loader",
        "com.bfm.aap.privatemarkets.dao", "com.bfm.aap.pmdx.validate", "com.bfm.aap.privatemarkets.datadictionary",
        "com.bfm.aap.privatemarkets.common", "com.bfm.aap.privatemarkets.permission.core",
        "com.bfm.aap.privatemarkets.permission.config", "com.bfm.aap.privatemarkets.decode",
        "com.bfm.aap.privatemarkets.broker"})
@PropertySource(name = "properties", value = "${spring.config.location}")
public class PrivateMarketsAssetLoader {

    private static final Logger LOGGER = LoggerFactory.getLogger(PrivateMarketsAssetLoader.class);

    public static void main(String[] args) {
        try {
            LOGGER.debug("Starting Private Markets Asset Loader Server...");
            new PrivateMarketsAssetLoader().startLoader();
            LOGGER.debug("Private Markets Asset Loader Server started");
        } catch (InterruptedException e) {
            LOGGER.error("Error starting server thread interrupted", e);
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            LOGGER.error("Error starting server", e);
            final NotificationParams notificationParams = new NotificationParams.Builder(
                    NotificationEnums.NotificationSeverity.PURPLE, AssetCommonConstant.LOADER_SERVER_SHORT_NAME)
                    .setEmailBuilder(new EmailParams.Builder().setSubject("Error starting server")
                            .setUserRequest(null).setException(e).setUserName(BFMUtil.getUser())
                            .setMode(CommonConstants.NETWORK_MODE.name()))
                    .build();

            Notification.sendNotification(notificationParams);

            System.exit(-1);
        }
    }

    private void startLoader() throws InterruptedException {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(
                PrivateMarketsAssetLoader.class);
        context.getBean(DecodeServiceImpl.class).waitForDecodeCacheInit();
        ServiceGateway serviceGateway = context.getBean(ServiceGateway.class);
        Beam2APIService service = context.getBean(AssetLoaderService.class);
        BmsHelper.registerBMS(serviceGateway, service, PmdxServiceType.PRIVATEMARKETS_ASSET_LOADER, "sourceId");
        context.registerShutdownHook();
    }

}