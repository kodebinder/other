package com.bfm.aap.privatemarkets.asset.loader.service;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.util.ObjectUtils;

import com.bfm.aap.pmdx.loader.service.PrivateMarketsAssetLoaderService;
import com.bfm.aap.pmdx.model.Instrument;
import com.bfm.aap.pmdx.model.InstrumentDetails;
import com.bfm.aap.pmdx.model.InstrumentSource;
import com.bfm.aap.privatemarkets.asset.loader.util.AssertionUtility;
import com.bfm.aap.privatemarkets.asset.loader.util.DetailsUtility;
import com.bfm.aap.privatemarkets.asset.loader.util.TestHelper;
import com.bfm.aap.privatemarkets.common.model.LoaderResponse;
import com.bfm.aap.privatemarkets.common.model.MultipleLoaderResponse;
import com.bfm.aap.privatemarkets.dao.FloaterDaoImpl;
import com.bfm.aap.privatemarkets.dao.IssuerSectorDaoImpl;
import com.bfm.aap.privatemarkets.dao.ReMasterDaoImpl;
import com.bfm.aap.privatemarkets.dao.SecAttributeValueDaoImpl;
import com.bfm.aap.privatemarkets.dao.SecurityMasterDao;
import com.bfm.aap.privatemarkets.dao.SmVectorDataDaoImpl;
import com.bfm.aap.privatemarkets.dao.TrancheFactorsDaoImpl;

import cucumber.api.java8.En;
import io.cucumber.datatable.DataTable;

@SuppressWarnings("deprecation")
public class AssetLoaderCreateInstrumentStepDefinition implements En {

	private Instrument.Builder instrumentBuilder;

	@Autowired
	@Qualifier("securityMasterDaoImpl")
	private SecurityMasterDao securityMasterDao;

	@Autowired
	@Qualifier("secAttributeValueDaoImpl")
	private SecAttributeValueDaoImpl secAttributeValueDao;

	@Autowired
	@Qualifier("issuerSectorDaoImpl")
	private IssuerSectorDaoImpl issuerSectorDao;

	@Autowired
	@Qualifier("smVectorDataDaoImpl")
	private SmVectorDataDaoImpl smVectorDataDao;

	@Autowired
	@Qualifier("reMasterDaoImpl")
	private ReMasterDaoImpl reMasterDao;

	@Autowired
	@Qualifier("trancheFactorsDaoImpl")
	private TrancheFactorsDaoImpl trancheFactorsDao;

	@Autowired
	@Qualifier("floaterDaoImpl")
	private FloaterDaoImpl floatersDao;

	private MultipleLoaderResponse multipleProtoResponse;
	private PrivateMarketsAssetLoaderService assetLoaderClient;
	private Map<String, String> mandatoryArgs;

	public AssetLoaderCreateInstrumentStepDefinition() {

		Given("the following attributes are available for creating the instrument:", (DataTable dataTable) -> {
			mandatoryArgs = dataTable.asMap(String.class, String.class);
		});

		When("create request contains all the mandatory fields for instrument and Company details", () -> {
			instrumentBuilder = DetailsUtility.getInstrument(mandatoryArgs, false, true, true, InstrumentSource.COMPANY,
					false, null);
		});

		When("create request contains all the mandatory fields for instrument and RealEstate Details", () -> {
			instrumentBuilder = DetailsUtility.getInstrument(mandatoryArgs, true, false, true, InstrumentSource.DEAL,
					false, null);
		});

		When("create request does not contains all the mandatory fields for Instrument and Company details", () -> {
			instrumentBuilder = DetailsUtility.getInstrument(mandatoryArgs, false, true, false,
					InstrumentSource.COMPANY, false, null);
			getMultipleProtoResponse();
		});

		When("create request does not contains all the mandatory fields for Instrument and RealEstate details", () -> {
			instrumentBuilder = DetailsUtility.getInstrument(mandatoryArgs, true, false, false, InstrumentSource.DEAL,
					false, null);
			getMultipleProtoResponse();
		});

		When("user sends request for instrument to PMAL", () -> {
			instrumentBuilder.setEntityInfo(DetailsUtility.getEntityInfo(TestHelper.NETWORK_MODE));
			getMultipleProtoResponse();
		});

		When("instrument contains mandatory flag", () -> {
			List<InstrumentDetails> instrumentDetailsList = instrumentBuilder.getInstrumentDetailsBuilderList().stream()
					.map(instrumentDetail -> (instrumentDetail.setNotionalFlag("N").setNotionalFlag("N").build()))
					.collect(Collectors.toList());
			instrumentBuilder.clearInstrumentDetails();
			instrumentBuilder.addAllInstrumentDetails(instrumentDetailsList);
		});

		Then("instrument should be created for COMPANY", () -> {
			assertAssetLoaderResponse(122471, "ASTTYP", (short) 1, false, null, false);
		});

		Then("instrument should be created for REAL ESTATE", () -> {
			assertAssetLoaderResponse(122471, "ASTTYP", (short) 1, true, null, false);
		});

		Then("instrument should not be created", () -> {
			List<LoaderResponse> loaderResponseList = multipleProtoResponse.getLoaderResponseList();
			for (LoaderResponse loaderResponse : loaderResponseList) {
				assertEquals(false, loaderResponse.isSuccess());
			}
		});

		When("create request, having instrument source as COMPANY, does not contains IntrumentId", () -> {
			instrumentBuilder = Instrument.newBuilder().setAssetId(mandatoryArgs.get("asset_id"))
					.setAssetName(mandatoryArgs.get("asset_name")).setAssetType(mandatoryArgs.get("asset_type"))
					.setDomicile(mandatoryArgs.get("domicile")).setCurrency(mandatoryArgs.get("currency"))
					.setManagementCompany(mandatoryArgs.get("management_company"))
					.setInvestmentStructure(mandatoryArgs.get("investment_structure")).setFlag144A("P").build()
					.toBuilder();
			InstrumentDetails instrumentDetails = InstrumentDetails.newBuilder().setInstrumentId("XX")
					.setInstrumentName(mandatoryArgs.get("instrument_name"))
					.setInstrumentType(mandatoryArgs.get("instrument_type"))
					.setInstrumentCurrency(mandatoryArgs.get("instrument_currency"))
					.setInstrumentDomicile(mandatoryArgs.get("domicile")).setSecGroup(mandatoryArgs.get("sec_group"))
					.setSecType(mandatoryArgs.get("sec_type"))
					.setCapitalStructure(mandatoryArgs.get("capital_structure"))
					.setInstrumentMarket(mandatoryArgs.get("domicile")).setInstrumentSource(InstrumentSource.COMPANY)
					.build();
			instrumentBuilder.addInstrumentDetails(instrumentDetails);
			instrumentBuilder.setCompanyDetails(DetailsUtility.getCompanyDetails());

			getMultipleProtoResponse();
		});

		When("create request, having instrument source as DEALS, does not contains dealStructuringId", () -> {
			instrumentBuilder = Instrument.newBuilder().setAssetId(mandatoryArgs.get("asset_id"))
					.setAssetName(mandatoryArgs.get("asset_name")).setAssetType(mandatoryArgs.get("asset_type"))
					.setDomicile(mandatoryArgs.get("domicile")).setCurrency(mandatoryArgs.get("currency"))
					.setManagementCompany(mandatoryArgs.get("management_company"))
					.setInvestmentStructure(mandatoryArgs.get("investment_structure")).setFlag144A("P").build()
					.toBuilder();
			InstrumentDetails instrumentDetails = InstrumentDetails.newBuilder()
					.setInstrumentId(mandatoryArgs.get("instrument_id"))
					.setInstrumentName(mandatoryArgs.get("instrument_name"))
					.setInstrumentType(mandatoryArgs.get("instrument_type"))
					.setInstrumentCurrency(mandatoryArgs.get("instrument_currency"))
					.setInstrumentDomicile(mandatoryArgs.get("domicile")).setSecGroup(mandatoryArgs.get("sec_group"))
					.setSecType(mandatoryArgs.get("sec_type"))
					.setCapitalStructure(mandatoryArgs.get("capital_structure"))
					.setInstrumentMarket(mandatoryArgs.get("domicile")).setInstrumentSource(InstrumentSource.DEAL)
					.setDealStructuringId("XX").build();
			instrumentBuilder.addInstrumentDetails(instrumentDetails);
			instrumentBuilder.setCompanyDetails(DetailsUtility.getCompanyDetails());

			getMultipleProtoResponse();
		});

		When("create deals instrument request contains all the mandatory fields for instrument details and fixed coupon",
				() -> {
					instrumentBuilder = DetailsUtility.getInstrument(mandatoryArgs, false, false, true,
							InstrumentSource.DEAL, false, true);
				});

		Then("fixed coupon type deals instrument should be created for DEALS", () -> {
			assertAssetLoaderResponse(122471, "ASTTYP", (short) 1, false, true, false);
		});

		When("create deals instrument request contains all the mandatory fields for instrument details and float coupon",
				() -> {
					instrumentBuilder = DetailsUtility.getInstrument(mandatoryArgs, false, false, true,
							InstrumentSource.DEAL, false, false);
				});

		Then("float coupon type deals instrument should be created for DEALS", () -> {
			assertAssetLoaderResponse(122471, "ASTTYP", (short) 1, false, false, false);
		});

		When("create debt deals instrument request contains all the mandatory fields for instrument details", () -> {
			instrumentBuilder = DetailsUtility.getInstrument(mandatoryArgs, false, false, true, InstrumentSource.DEAL,
					true, false);
		});

		Then("debt deals instrument should be created", () -> {
			assertAssetLoaderResponse(122471, "ASTTYP", (short) 1, false, false, true);
		});

	}

	public void getMultipleProtoResponse() {
		assetLoaderClient = TestHelper.getAssetLoaderBeam2Service();
		multipleProtoResponse = assetLoaderClient.upsertAltsInstrument(instrumentBuilder.build());
		TestHelper.printMultipleResponse(multipleProtoResponse);
	}

	public void assertAssetLoaderResponse(int secAttributeDefnId, String sectorSet, short sectorLevel,
			boolean isRealState, Boolean isFixed, boolean isDebtDeals) {
		String cusip = AssertionUtility.getCusipForMultiLoaderRes(multipleProtoResponse).get(0);
		Map<String, String> fieldDescriptor = DetailsUtility.getFieldDescriptorInstrument(cusip, instrumentBuilder,
				isRealState);

		AssertionUtility.assertSecurityMaster(securityMasterDao, fieldDescriptor, isFixed);
		AssertionUtility.assertSecAttributeValue(secAttributeValueDao, fieldDescriptor, secAttributeDefnId);
		AssertionUtility.assertIssuerSector(issuerSectorDao, fieldDescriptor, sectorSet, sectorLevel);
		if (!ObjectUtils.isEmpty(isFixed) && !isFixed) {
			if (isDebtDeals)
				AssertionUtility.assertFloater(floatersDao, fieldDescriptor.get("cusip"),
						fieldDescriptor.get("coupon"));
			else
				AssertionUtility.assertTrancheFactors(trancheFactorsDao, fieldDescriptor.get("cusip"),
						fieldDescriptor.get("issue_date"), fieldDescriptor.get("coupon"));
		}
		if (isRealState) {
			AssertionUtility.assertSmVectorData(smVectorDataDao, fieldDescriptor, cusip, "RE_AUM");
			AssertionUtility.assertReMaster(reMasterDao, fieldDescriptor);
		}

	}

}