package com.bfm.aap.privatemarkets.asset.loader.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.bfm.aap.pmdx.loader.service.PrivateMarketsAssetLoaderService;
import com.bfm.aap.pmdx.model.Performance;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.privatemarkets.asset.loader.util.AssertionUtility;
import com.bfm.aap.privatemarkets.asset.loader.util.DetailsUtility;
import com.bfm.aap.privatemarkets.asset.loader.util.TestHelper;
import com.bfm.aap.privatemarkets.common.model.LoaderResponse;
import com.bfm.aap.privatemarkets.common.model.MultipleLoaderResponse;
import com.bfm.aap.privatemarkets.common.model.SingleLoaderResponse;
import com.bfm.aap.privatemarkets.dao.IssuerSectorDaoImpl;
import com.bfm.aap.privatemarkets.dao.SecAttributeValueDaoImpl;
import com.bfm.aap.privatemarkets.dao.SecurityMasterDao;

import cucumber.api.java8.En;
import io.cucumber.datatable.DataTable;

@SuppressWarnings("deprecation")
public class AssetLoaderCreatePerformanceStepDefinition implements En {

	private Performance.Builder performanceBuilder;

	@Autowired
	@Qualifier("securityMasterDaoImpl")
	private SecurityMasterDao securityMasterDao;

	@Autowired
	@Qualifier("secAttributeValueDaoImpl")
	private SecAttributeValueDaoImpl secAttributeValueDao;

	@Autowired
	@Qualifier("issuerSectorDaoImpl")
	private IssuerSectorDaoImpl issuerSectorDao;

	private SingleLoaderResponse singleProtoResponse;
	private MultipleLoaderResponse multiProtoResponse;
	private PrivateMarketsAssetLoaderService assetLoaderClient;
	private Map<String, String> mandatoryArgs;
	private List<Performance> performanceList;

	public AssetLoaderCreatePerformanceStepDefinition() {

		Given("the following attributes are available for creating the performance:", (DataTable dataTable) -> {
			mandatoryArgs = dataTable.asMap(String.class, String.class);
		});

		When("create request contains all the mandatory fields for performance", () -> {
			performanceBuilder = DetailsUtility.getPerformance(mandatoryArgs);
		});

		When("create request not contains all the mandatory fields for performance", () -> {
			performanceBuilder = Performance.newBuilder();
		});

		When("request contains incorrect cusip name", () -> {
			performanceBuilder.setCusip("TESTCUSIP");
		});

		When("create request contains all the mandatory fields for multiple performance", (DataTable dataTable) -> {
			Map<String, String> mandatoryArgument = dataTable.asMap(String.class, String.class);
			performanceList = new ArrayList<>();

			getPerformanceObject(mandatoryArgs, mandatoryArgument, TestHelper.NETWORK_MODE);
			assetLoaderClient = TestHelper.getAssetLoaderBeam2Service();
			multiProtoResponse = assetLoaderClient.upsertStaticPerformanceList(performanceList);
			TestHelper.printMultipleResponse(multiProtoResponse);
		});

		When("user sends request for performance", () -> {
			performanceBuilder.setEntityInfo(DetailsUtility.getEntityInfo(TestHelper.NETWORK_MODE));
			getSingleProtoResponse();
		});

		When("user sends request for creating performance", () -> {
			getSingleProtoResponse();
		});

		Then("performance should be created", () -> {
			AssertionUtility.assertProtoResponsePerformance(singleProtoResponse.getLoaderResponse(),
					performanceBuilder.build());
		});

		Then("performance should be created sucessfully", () -> {
			int index = 0;
			for (LoaderResponse loaderResponse : multiProtoResponse.getLoaderResponseList()) {
				AssertionUtility.assertProtoResponsePerformance(loaderResponse, performanceList.get(index++));
			}
		});

		Then("performance should not be created", () -> {
			assertEquals(false, singleProtoResponse.getLoaderResponse().isSuccess());
		});
	}

	private void getPerformanceObject(Map<String, String> mandatoryArgs, Map<String, String> mandatoryArgument,
			NetworkMode networkMode) {
		performanceList.add(DetailsUtility.getPerformance(mandatoryArgs)
				.setEntityInfo(DetailsUtility.getEntityInfo(networkMode)).build());
		performanceList.add(DetailsUtility.getPerformance(mandatoryArgument)
				.setEntityInfo(DetailsUtility.getEntityInfo(networkMode)).build());
	}

	private void getSingleProtoResponse() {
		assetLoaderClient = TestHelper.getAssetLoaderBeam2Service();
		singleProtoResponse = assetLoaderClient.upsertStaticPerformance(performanceBuilder.build());
		TestHelper.printResponse(singleProtoResponse);
	}

}