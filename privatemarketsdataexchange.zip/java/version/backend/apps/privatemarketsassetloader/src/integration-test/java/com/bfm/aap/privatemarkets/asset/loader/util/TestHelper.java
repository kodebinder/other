package com.bfm.aap.privatemarkets.asset.loader.util;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;

import com.bfm.aap.pmdx.loader.service.PrivateMarketsAssetLoaderService;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.model.util.NetworkModeHelper;
import com.bfm.aap.pmdx.redblue.PmdxServiceSource;
import com.bfm.aap.pmdx.redblue.PmdxServiceType;
import com.bfm.aap.pmdx.redblue.RedBlueNetworkChecker;
import com.bfm.aap.privatemarkets.common.model.MultipleLoaderResponse;
import com.bfm.aap.privatemarkets.common.model.SingleLoaderResponse;
import com.bfm.aap.privatemarkets.common.util.DateUtil;
import com.bfm.aap.privatemarkets.dao.model.SecAttributeValue;
import com.bfm.beam2.BRElemConverter;
import com.bfm.beam2.Configs;
import com.bfm.beam2.ServiceProxyFactories;
import com.bfm.beam2.ServiceProxyFactory;
import com.bfm.privatemarkets.beam2.util.Proto3JsonConverter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class TestHelper {

	public static final String SERVER_MODE = System.getProperty("mode");
	public static final NetworkMode NETWORK_MODE = NetworkModeHelper.getNetworkModeFromString(SERVER_MODE);

	public static PrivateMarketsAssetLoaderService getAssetLoaderBeam2Service() {
		ServiceProxyFactories.SPFConfig config = new ServiceProxyFactories.SPFConfig()
				.setAppName("privateMarketsAssetLoaderService").setTimeout(120, TimeUnit.SECONDS);
		config.setBrElemConverterFactories(
				Collections.<BRElemConverter.Factory<?>>singletonList(Proto3JsonConverter.factory()));
		ServiceProxyFactory factory = ServiceProxyFactories.bmsServiceProxyFactory(config);
		return factory.getServiceProxy(PrivateMarketsAssetLoaderService.class,
				Configs.builder().setSourceId(getSourceId()).setTimeout(120, TimeUnit.SECONDS).build());
	}

	public static int getAssetLoaderSourceId(String color) {
		if (color.equalsIgnoreCase("RED")) {
			return PmdxServiceSource.PRIVATEMARKETS_ASSET_LOADER_RED.getSourceID();
		} else if (color.equalsIgnoreCase("BLUE")) {
			return PmdxServiceSource.PRIVATEMARKETS_ASSET_LOADER_BLUE.getSourceID();
		}
		return -1;
	}

	public static void printResponse(SingleLoaderResponse singleProtoResponse) {
		Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().create();
		System.out.println(gson.toJson(singleProtoResponse));
	}

	public static void printMultipleResponse(MultipleLoaderResponse singleProtoResponse) {
		Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().create();
		System.out.println(gson.toJson(singleProtoResponse));
	}

	public static Map<Long, SecAttributeValue> getCurrentActiveAttributes(List<SecAttributeValue> existingValues) {
		if (CollectionUtils.isEmpty(existingValues)) {
			return new HashMap<>();
		}
		return existingValues.stream()
				.filter(value -> (value.getStopDate() == null) || (value.getStopDate().gt(DateUtil.todayBFMDateTime())))
				.collect(Collectors.toMap(SecAttributeValue::getSecAttributeDefnId, Function.identity()));
	}

	public static int getSourceId() {
		// Initialize RedBlueNetworkChecker with its own DataSource
		RedBlueNetworkChecker.initDataSource();
		return RedBlueNetworkChecker.getSourceIdByTypeAndColor(PmdxServiceType.PRIVATEMARKETS_ASSET_LOADER,
				getPrimaryNetwork());
	}

	public static com.bfm.aap.pmdx.redblue.NetworkMode getPrimaryNetwork() {
		try {
			return RedBlueNetworkChecker.getPrimaryNetworkPredicate().getPrimaryNetwork();
		} catch (Exception e) {
			throw new RuntimeException("Error while getting primary network:" + e.getMessage(), e);
		}
	}

}
