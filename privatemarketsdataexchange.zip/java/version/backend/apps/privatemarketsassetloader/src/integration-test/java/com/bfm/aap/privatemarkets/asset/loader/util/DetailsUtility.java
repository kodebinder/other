/**
 * 
 */
package com.bfm.aap.privatemarkets.asset.loader.util;

import com.bfm.aap.pmdx.model.Asset;
import com.bfm.aap.pmdx.model.Asset.Builder;
import com.bfm.aap.pmdx.model.CompanyDetails;
import com.bfm.aap.pmdx.model.DebtDetails;
import com.bfm.aap.pmdx.model.FundDetails;
import com.bfm.aap.pmdx.model.Instrument;
import com.bfm.aap.pmdx.model.InstrumentDetails;
import com.bfm.aap.pmdx.model.InstrumentSource;
import com.bfm.aap.pmdx.model.Performance;
import com.bfm.aap.pmdx.model.PrivateEquityFund;
import com.bfm.aap.pmdx.model.RealEstateDetails;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.model.util.ReferenceLevel;
import com.bfm.aap.pmdx.model.util.Source;
import com.bfm.aap.privatemarkets.dao.util.SecGroupType;
import com.google.common.collect.Maps;
import com.google.protobuf.Timestamp;
import java.util.Map;

import org.springframework.util.ObjectUtils;

/**
 * @author vivekkum
 *
 */
public class DetailsUtility {

	private static long millis = System.currentTimeMillis();
	private static final double FUND_SIZE = 850000000;
	private static final String CLIENT_NAME = "DEV";
	private static final String MODEL_VERSION = "7.1.1";
	private static final String FUND_NAME = "Ara Strategic Fund IV LP";
	private static final String VINTAGE_YEAR = "2012";
	private static final String FLAG144A_VALUE = "P";
	private static final String CUSIP = "cusip";
	private static final String CURRENCY = "currency";
	private static final String DOMICILE = "domicile";
	private static final String ASSET_NAME = "assetName";
	private static final String ASSET_TYPE = "assetType";
	private static final String NOTIONAL_FLAG = "notionalFlag";
	private static final String FLAG144A = "flag144A";
	private static final String CAPITAL_STRUCTURE = "capitalStructure";
	private static final String REAL_ESTATE_LTV = "realEstateLTV";
	private static final String MSA = "MSA";
	private static final String NCREIF_REGION = "ncreifRegion";
	private static final String CITY = "city";
	private static final String STATE = "state";
	private static final String ASSET_INVESTMENT_STYLE = "assetInvestmentStyle";
	private static final String ZIP_CODE = "zipCode";
	private static final String STREET_ADDRESS = "streetAddress";
	private static final String RE_CLASS = "reClass";
	private static final String ASSET_STRATEGY = "assetStrategy";
	private static final String COUPON = "coupon";
	private static final String ISSUE_DATE = "issue_date";
	private static final String XX = "XX";

	public static EntityInfo getEntityInfo(NetworkMode networkMode) {
		return EntityInfo.newBuilder().setPrimaryData(Boolean.TRUE).setClientName(CLIENT_NAME)
				.setModelVersion(MODEL_VERSION).setNetworkMode(networkMode).setSource(Source.INVEST)
				.setReferenceLevel(ReferenceLevel.FUND_ASSET_LEVEL)
				.setOriginTimestamp(Timestamp.newBuilder().setSeconds(millis / 1000).build()).build();
	}

	public static FundDetails getFundDetails() {
		return FundDetails.newBuilder().setFundName(FUND_NAME).setVintageYear(VINTAGE_YEAR).setFundSize(FUND_SIZE)
				.setFundCurrency("GBP").setGeographyFocus("EUROPE")
				.setFundInceptionDate(Timestamp.newBuilder().setSeconds(millis / 1000).build())
				.setPrivateEquityFund(
						PrivateEquityFund.newBuilder().setPeSectorFocus("10000000").setPeStageFocus("FUND").build())
				.build();
	}

	public static RealEstateDetails getRealEstateDetails() {
		return RealEstateDetails.newBuilder().setCity("NY").setState("ALASKA")
				.setAssetInvestmentStyle("ALTS_RE_INV_TYP").setZipCode("460068").setStreetAddress("Dahisar east")
				.setReClass("ALTS_RE_CLASS").setNcreifRegion("PACIFIC").setLTV(5.12).setMSA("NANOTINMSA")
				.setSector("RE_SECTOR").setSectorPropertyType("RE_PROPTYPE").setAssetStrategy("ALTS_RE_STRAT").build();
	}

	public static CompanyDetails getCompanyDetails() {
		return CompanyDetails.newBuilder().setCompanyType("COM").build();
	}

	public static Builder getAssetBuilder(Map<String, String> mandatoryArgs, String assetType,
			boolean isFundDetailsRequired, boolean isRealEstateDetailsRequired, boolean isCompanyDetailsRequired,
			boolean isMandatoryFlagRequired) {
		Asset.Builder assetBuilder = Asset.newBuilder().setAssetName(mandatoryArgs.get("asset_name"))
				.setAssetType(assetType).setDomicile(mandatoryArgs.get("domicile"))
				.setCurrency(mandatoryArgs.get("currency")).setCapitalStructure(mandatoryArgs.get("capital_structure"))
				.setFlag144A(FLAG144A_VALUE).setMarket("market").setEntityInfo(getEntityInfo(NetworkMode.BLUE)).build()
				.toBuilder();

		if (isFundDetailsRequired)
			assetBuilder.setFundDetails(getFundDetails());
		if (isRealEstateDetailsRequired)
			assetBuilder.setRealEstateDetails(getRealEstateDetails());
		if (isCompanyDetailsRequired)
			assetBuilder.setCompanyDetails(getCompanyDetails());
		if (isMandatoryFlagRequired)
			assetBuilder.setNotionalFlag("N").setMTN("N");

		return assetBuilder;
	}

	public static InstrumentDetails getInstrumentDetails(Map<String, String> mandatoryArgs,
			InstrumentSource instrumentSource, boolean isDebtDeals, Boolean isFixed) {
		InstrumentDetails.Builder instrumentDetails = InstrumentDetails.newBuilder()
				.setInstrumentName(mandatoryArgs.get("instrument_name"))
				.setInstrumentType(mandatoryArgs.get("instrument_type"))
				.setInstrumentCurrency(mandatoryArgs.get("instrument_currency"))
				.setInstrumentDomicile(mandatoryArgs.get("domicile"))
				.setCapitalStructure(mandatoryArgs.get("capital_structure"))
				.setInstrumentMarket(mandatoryArgs.get("domicile"))
				.setIssueDate(
						Timestamp.newBuilder().setSeconds(Long.parseLong(mandatoryArgs.get("issue_date"))).build())
				.setInstrumentSource(instrumentSource);
		if (instrumentSource.equals(InstrumentSource.COMPANY)) {
			instrumentDetails.setInstrumentId(mandatoryArgs.get("instrument_id"));
			instrumentDetails.setDealStructuringId(XX);
		} else if (instrumentSource.equals(InstrumentSource.DEAL)) {
			instrumentDetails.setDealStructuringId(mandatoryArgs.get("dealstructuring_id"));
			instrumentDetails.setInstrumentId(XX);
		}
		if (isDebtDeals) {
			instrumentDetails.setSecGroup(SecGroupType.PRIVATE_FUND.secGroup())
					.setSecType(SecGroupType.PRIVATE_FUND.secType());
		} else {
			instrumentDetails.setSecGroup(mandatoryArgs.get("sec_group")).setSecType(mandatoryArgs.get("sec_type"));
			if (!ObjectUtils.isEmpty(isFixed)) {
				instrumentDetails.setDebtDetails(getDebtDetails(isFixed));
			}
		}

		return instrumentDetails.build();
	}

	public static DebtDetails getDebtDetails(Boolean isFixed) {
		if (isFixed)
			return DebtDetails.newBuilder().setCouponType("FIXED").setCoupon(1.5).build();
		else
			return DebtDetails.newBuilder().setCouponType("FLOAT").setCoupon(1.5).build();

	}

	public static Instrument.Builder getInstrument(Map<String, String> mandatoryArgs,
			boolean isRealEstateDetailsRequired, boolean isCompanyDetailsRequired, boolean isInstrumentDetailsRequired,
			InstrumentSource instrumentSource, boolean isDebtDeals, Boolean isFixed) {
		Instrument.Builder instrumentBuilder = Instrument.newBuilder().setAssetId(mandatoryArgs.get("asset_id"))
				.setAssetName(mandatoryArgs.get("asset_name")).setAssetType(mandatoryArgs.get("asset_type"))
				.setDomicile(mandatoryArgs.get("domicile")).setCurrency(mandatoryArgs.get("currency"))
				.setManagementCompany(mandatoryArgs.get("management_company"))
				.setInvestmentStructure(mandatoryArgs.get("investment_structure")).setFlag144A(FLAG144A_VALUE).build()
				.toBuilder();
		if (isInstrumentDetailsRequired)
			instrumentBuilder
					.addInstrumentDetails(getInstrumentDetails(mandatoryArgs, instrumentSource, isDebtDeals, isFixed));
		if (isRealEstateDetailsRequired)
			instrumentBuilder.setRealEstateDetails(getRealEstateDetails());
		if (isCompanyDetailsRequired)
			instrumentBuilder.setCompanyDetails(getCompanyDetails());
		return instrumentBuilder;
	}

	public static Performance.Builder getPerformance(Map<String, String> mandatoryArgs) {
		return Performance.newBuilder().setAsOfDate(Timestamp.newBuilder().setSeconds(millis / 1000).build())
				.setCusip(mandatoryArgs.get("cusip")).setNetIrr(Double.valueOf(mandatoryArgs.get("net_irr")))
				.setNetIrr10Yr(Double.valueOf(mandatoryArgs.get("net_irr")))
				.setNetIrr1Yr(Double.valueOf(mandatoryArgs.get("net_irr")))
				.setNetIrr3Yr(Double.valueOf(mandatoryArgs.get("net_irr")))
				.setNetIrr5Yr(Double.valueOf(mandatoryArgs.get("net_irr")))
				.setNetIrr7Yr(Double.valueOf(mandatoryArgs.get("net_irr")))
				.setNetTvpi(Double.valueOf(mandatoryArgs.get("net_tvpi"))).setObjectId(mandatoryArgs.get("object_id"))
				.setPerformanceId(mandatoryArgs.get("performance_id"));
	}

	public static Map<String, String> getFieldDescriptorAsset(String cusip, Asset.Builder assetBuilder,
			boolean isRealState) {
		Map<String, String> fieldsDescriptor = Maps.newHashMap();
		fieldsDescriptor.put(CUSIP, cusip);
		fieldsDescriptor.put(CURRENCY, assetBuilder.getCurrency());
		fieldsDescriptor.put(DOMICILE, assetBuilder.getDomicile());
		fieldsDescriptor.put(ASSET_NAME, assetBuilder.getAssetName());
		fieldsDescriptor.put(ASSET_TYPE, assetBuilder.getAssetType());
		fieldsDescriptor.put(NOTIONAL_FLAG, assetBuilder.getNotionalFlag());
		fieldsDescriptor.put(FLAG144A, assetBuilder.getFlag144A());
		fieldsDescriptor.put(CAPITAL_STRUCTURE, assetBuilder.getCapitalStructure());

		if (isRealState) {
			fieldsDescriptor.put(REAL_ESTATE_LTV, String.valueOf(assetBuilder.getRealEstateDetails().getLTV()));
			fieldsDescriptor.put(MSA, String.valueOf(assetBuilder.getRealEstateDetails().getMSA()));
			fieldsDescriptor.put(NCREIF_REGION, String.valueOf(assetBuilder.getRealEstateDetails().getNcreifRegion()));
			fieldsDescriptor.put(CITY, String.valueOf(assetBuilder.getRealEstateDetails().getCity()));
			fieldsDescriptor.put(STATE, String.valueOf(assetBuilder.getRealEstateDetails().getState()));
			fieldsDescriptor.put(ASSET_INVESTMENT_STYLE,
					String.valueOf(assetBuilder.getRealEstateDetails().getAssetInvestmentStyle()));
			fieldsDescriptor.put(ZIP_CODE, String.valueOf(assetBuilder.getRealEstateDetails().getZipCode()));
			fieldsDescriptor.put(STREET_ADDRESS,
					String.valueOf(assetBuilder.getRealEstateDetails().getStreetAddress()));
			fieldsDescriptor.put(RE_CLASS, String.valueOf(assetBuilder.getRealEstateDetails().getReClass()));
			fieldsDescriptor.put(ASSET_STRATEGY,
					String.valueOf(assetBuilder.getRealEstateDetails().getAssetStrategy()));
		}
		return fieldsDescriptor;
	}

	public static Map<String, String> getFieldDescriptorInstrument(String cusip, Instrument.Builder instrumentBuilder,
			boolean isRealState) {
		Map<String, String> fieldsDescriptor = Maps.newHashMap();
		fieldsDescriptor.put(CUSIP, cusip);
		fieldsDescriptor.put(CURRENCY, instrumentBuilder.getCurrency());
		fieldsDescriptor.put(DOMICILE, instrumentBuilder.getDomicile());
		fieldsDescriptor.put(ASSET_NAME, instrumentBuilder.getAssetName());
		fieldsDescriptor.put(ASSET_TYPE, instrumentBuilder.getAssetType());
		fieldsDescriptor.put(NOTIONAL_FLAG, instrumentBuilder.getInstrumentDetails(0).getNotionalFlag());
		fieldsDescriptor.put(CAPITAL_STRUCTURE, instrumentBuilder.getInstrumentDetails(0).getCapitalStructure());
		fieldsDescriptor.put(FLAG144A, instrumentBuilder.getFlag144A());
		fieldsDescriptor.put(COUPON,
				String.valueOf(instrumentBuilder.getInstrumentDetails(0).getDebtDetails().getCoupon()));
		fieldsDescriptor.put(ISSUE_DATE,
				String.valueOf(instrumentBuilder.getInstrumentDetails(0).getIssueDate().getSeconds()));

		if (isRealState) {
			fieldsDescriptor.put(REAL_ESTATE_LTV, String.valueOf(instrumentBuilder.getRealEstateDetails().getLTV()));
			fieldsDescriptor.put(MSA, String.valueOf(instrumentBuilder.getRealEstateDetails().getMSA()));
			fieldsDescriptor.put(NCREIF_REGION,
					String.valueOf(instrumentBuilder.getRealEstateDetails().getNcreifRegion()));
			fieldsDescriptor.put(CITY, String.valueOf(instrumentBuilder.getRealEstateDetails().getCity()));
			fieldsDescriptor.put(STATE, String.valueOf(instrumentBuilder.getRealEstateDetails().getState()));
			fieldsDescriptor.put(ASSET_INVESTMENT_STYLE,
					String.valueOf(instrumentBuilder.getRealEstateDetails().getAssetInvestmentStyle()));
			fieldsDescriptor.put(ZIP_CODE, String.valueOf(instrumentBuilder.getRealEstateDetails().getZipCode()));
			fieldsDescriptor.put(STREET_ADDRESS,
					String.valueOf(instrumentBuilder.getRealEstateDetails().getStreetAddress()));
			fieldsDescriptor.put(RE_CLASS, String.valueOf(instrumentBuilder.getRealEstateDetails().getReClass()));
			fieldsDescriptor.put(ASSET_STRATEGY,
					String.valueOf(instrumentBuilder.getRealEstateDetails().getAssetStrategy()));
		}

		return fieldsDescriptor;
	}

}
