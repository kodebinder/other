package com.bfm.aap.privatemarkets.asset.loader.service;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.bfm.aap.pmdx.loader.service.PrivateMarketsAssetLoaderService;
import com.bfm.aap.pmdx.model.Asset;
import com.bfm.aap.privatemarkets.asset.loader.util.AssertionUtility;
import com.bfm.aap.privatemarkets.asset.loader.util.DetailsUtility;
import com.bfm.aap.privatemarkets.asset.loader.util.TestHelper;
import com.bfm.aap.privatemarkets.common.model.SingleLoaderResponse;
import com.bfm.aap.privatemarkets.common.util.AssetCommonConstant;
import com.bfm.aap.privatemarkets.dao.CusipAliasesDaoImpl;
import com.bfm.aap.privatemarkets.dao.IssuerSectorDaoImpl;
import com.bfm.aap.privatemarkets.dao.NewIssueInfoDaoImpl;
import com.bfm.aap.privatemarkets.dao.ReMasterDaoImpl;
import com.bfm.aap.privatemarkets.dao.SecAttributeValueDaoImpl;
import com.bfm.aap.privatemarkets.dao.SecurityMasterDao;
import com.bfm.aap.privatemarkets.dao.SmVectorDataDaoImpl;

import cucumber.api.java8.En;
import io.cucumber.datatable.DataTable;

@SuppressWarnings("deprecation")
public class AssetLoaderUpdateAssetStepDefinition implements En {

	private Asset.Builder assetBuilder;
	@Autowired
	@Qualifier("securityMasterDaoImpl")
	private SecurityMasterDao securityMasterDao;

	@Autowired
	@Qualifier("secAttributeValueDaoImpl")
	private SecAttributeValueDaoImpl secAttributeValueDao;

	@Autowired
	@Qualifier("issuerSectorDaoImpl")
	private IssuerSectorDaoImpl issuerSectorDao;

	@Autowired
	@Qualifier("reMasterDaoImpl")
	private ReMasterDaoImpl reMasterDao;

	@Autowired
	@Qualifier("smVectorDataDaoImpl")
	private SmVectorDataDaoImpl smVectorDataDao;

	@Autowired
	@Qualifier("cusipAliasesDaoImpl")
	private CusipAliasesDaoImpl cusipAliasesDao;

	@Autowired
	@Qualifier("newIssueInfoDaoImpl")
	private NewIssueInfoDaoImpl newIssueInfoDao;

	private SingleLoaderResponse singleProtoResponse;
	private PrivateMarketsAssetLoaderService assetLoaderClient;
	private Map<String, String> updateArgs;

	public AssetLoaderUpdateAssetStepDefinition() {

		Given("the following attributes are available for updating the asset:", (DataTable dataTable) -> {
			updateArgs = dataTable.asMap(String.class, String.class);
		});

		When("update request contains all the mandatory fields for FUND", (DataTable dataTable) -> {
			getSingleProtoResponse(dataTable.asMap(String.class, String.class), AssetCommonConstant.FUND, true, false,
					false, true);
		});

		Then("asset updation successful for FUND", () -> {
			assertAssetLoaderResponse(122471, "ASTTYP", (short) 1, true, false);
		});

		When("update request contains all the mandatory fields for FUND_COMPANY", (DataTable dataTable) -> {
			getSingleProtoResponse(dataTable.asMap(String.class, String.class), AssetCommonConstant.FUND, true, false,
					true, true);
		});

		Then("asset updation successful for FUND_COMPANY", () -> {
			assertAssetLoaderResponse(122471, "ASTTYP", (short) 1, false, false);
		});

		When("update request contains all the mandatory fields for COMPANY", (DataTable dataTable) -> {
			getSingleProtoResponse(dataTable.asMap(String.class, String.class), AssetCommonConstant.COMPANY, true,
					false, true, true);
		});

		Then("asset updation successful for COMPANY", () -> {
			assertAssetLoaderResponse(122471, "ASTTYP", (short) 1, false, false);
		});

		When("update request contains all the mandatory fields for REAL_ESTATE", (DataTable dataTable) -> {
			getSingleProtoResponse(dataTable.asMap(String.class, String.class), AssetCommonConstant.REAL_ASSET, false,
					true, false, true);
		});

		Then("asset updation successful for REAL_ESTATE", () -> {
			assertAssetLoaderResponse(122471, "ASTTYP", (short) 1, false, true);
		});

		When("update request contains all the mandatory fields for FUND_REAL_ESTATE", (DataTable dataTable) -> {
			getSingleProtoResponse(dataTable.asMap(String.class, String.class), AssetCommonConstant.REAL_ESTATE_FUND,
					true, true, false, true);
		});

		Then("asset updation successful for FUND_REAL_ESTATE", () -> {
			assertAssetLoaderResponse(122471, "ASTTYP", (short) 1, false, true);
		});

		When("update request not contains mandatory fields for FUND", (DataTable dataTable) -> {
			getSingleProtoResponse(dataTable.asMap(String.class, String.class), AssetCommonConstant.FUND, true, false,
					false, false);
		});

		Then("asset updation unsuccessful for FUND", () -> {
			assertAssetLoaderResponseFailure();
		});

		When("update request not contains mandatory fields for FUND_COMPANY", (DataTable dataTable) -> {
			getSingleProtoResponse(dataTable.asMap(String.class, String.class), AssetCommonConstant.FUND, true, false,
					true, false);
		});

		Then("asset updation unsuccessful for FUND_COMPANY", () -> {
			assertAssetLoaderResponseFailure();
		});

		When("update request not contains mandatory fields for COMPANY", (DataTable dataTable) -> {
			getSingleProtoResponse(dataTable.asMap(String.class, String.class), AssetCommonConstant.COMPANY, true,
					false, true, false);
		});

		Then("asset updation unsuccessful for COMPANY", () -> {
			assertAssetLoaderResponseFailure();
		});

		When("update request not contains mandatory fields for REAL_ESTATE", (DataTable dataTable) -> {
			getSingleProtoResponse(dataTable.asMap(String.class, String.class), AssetCommonConstant.REAL_ASSET, false,
					true, false, false);
		});

		Then("asset updation unsuccessful for REAL_ESTATE", () -> {
			assertAssetLoaderResponseFailure();
		});

		When("update request not contains mandatory fields for FUND_REAL_ESTATE", (DataTable dataTable) -> {
			getSingleProtoResponse(dataTable.asMap(String.class, String.class), AssetCommonConstant.REAL_ESTATE_FUND,
					true, true, false, false);
		});

		Then("asset updation unsuccessful for FUND_REAL_ESTATE", () -> {
			assertAssetLoaderResponseFailure();
		});

		When("update request not contains fund details", (DataTable dataTable) -> {
			getSingleProtoResponse(dataTable.asMap(String.class, String.class), AssetCommonConstant.FUND, false, false,
					false, false);
		});

		When("update request not contains company details", (DataTable dataTable) -> {
			getSingleProtoResponse(dataTable.asMap(String.class, String.class), AssetCommonConstant.FUND, true, false,
					false, false);
		});

		When("update request not contains fund & company details", (DataTable dataTable) -> {
			getSingleProtoResponse(dataTable.asMap(String.class, String.class), AssetCommonConstant.FUND, false, false,
					false, false);
		});

		When("update request not contains company details for assetType COMPANY", (DataTable dataTable) -> {
			getSingleProtoResponse(dataTable.asMap(String.class, String.class), AssetCommonConstant.COMPANY, true,
					false, false, false);
		});

		When("update request not contains real estate details", (DataTable dataTable) -> {
			getSingleProtoResponse(dataTable.asMap(String.class, String.class), AssetCommonConstant.REAL_ASSET, false,
					false, false, false);
		});

		When("update request not contains fund details for asset type FUND_REAL_ESTATE", (DataTable dataTable) -> {
			getSingleProtoResponse(dataTable.asMap(String.class, String.class), AssetCommonConstant.REAL_ESTATE_FUND,
					false, true, false, false);
		});

		When("update request not contains real estate details for asset type FUND_REAL_ESTATE",
				(DataTable dataTable) -> {
					getSingleProtoResponse(dataTable.asMap(String.class, String.class),
							AssetCommonConstant.REAL_ESTATE_FUND, true, false, false, false);
				});

		When("update request not contains fund & real estate details for asset type FUND_REAL_ESTATE",
				(DataTable dataTable) -> {
					getSingleProtoResponse(dataTable.asMap(String.class, String.class),
							AssetCommonConstant.REAL_ESTATE_FUND, false, false, false, false);
				});

	}

	public void assertAssetLoaderResponse(int secAttributeDefnId, String sectorSet, short sectorLevel,
			boolean isNewIssueInfoAssertionRequired, boolean isRealState) {
		String cusip = AssertionUtility.getCusip(singleProtoResponse);
		Map<String, String> fieldDescriptor = DetailsUtility.getFieldDescriptorAsset(cusip, assetBuilder, isRealState);

		AssertionUtility.assertSecurityMaster(securityMasterDao, fieldDescriptor, null);
		AssertionUtility.assertSecAttributeValue(secAttributeValueDao, fieldDescriptor, secAttributeDefnId);
		AssertionUtility.assertIssuerSector(issuerSectorDao, fieldDescriptor, sectorSet, sectorLevel);

		if (isNewIssueInfoAssertionRequired)
			AssertionUtility.assertNewIssueInfo(newIssueInfoDao, assetBuilder, cusip);
		if (isRealState) {
			AssertionUtility.assertSmVectorData(smVectorDataDao, fieldDescriptor, cusip, "RE_AUM");
			AssertionUtility.assertReMaster(reMasterDao, fieldDescriptor);
		}
	}

	public void assertAssetLoaderResponseFailure() {
		assertEquals(false, singleProtoResponse.getLoaderResponse().isSuccess());
		String cusip = (String) singleProtoResponse.getLoaderResponse().getData().get("AladdinId");
		assertNull(cusip);
	}

	private void getSingleProtoResponse(Map<String, String> mandatoryFields, String assetType,
			boolean isFundDetailsRequired, boolean isRealEstateDetailsRequired, boolean isCompanyDetailsRequired,
			boolean isMandatoryFlagRequired) {
		assetLoaderClient = TestHelper.getAssetLoaderBeam2Service();

		assetBuilder = DetailsUtility
				.getAssetBuilder(updateArgs, assetType, isFundDetailsRequired, isRealEstateDetailsRequired,
						isCompanyDetailsRequired, isMandatoryFlagRequired)
				.setAssetId(mandatoryFields.get("asset_id")).setAssetName(mandatoryFields.get("asset_name"));
		singleProtoResponse = assetLoaderClient.upsertAltsAsset(assetBuilder.build());
		TestHelper.printResponse(singleProtoResponse);
	}

}
