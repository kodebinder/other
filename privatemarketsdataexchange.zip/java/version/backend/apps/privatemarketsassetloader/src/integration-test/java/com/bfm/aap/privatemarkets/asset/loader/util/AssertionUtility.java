/**
 * 
 */
package com.bfm.aap.privatemarkets.asset.loader.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

import org.assertj.core.util.Lists;
import org.springframework.util.ObjectUtils;

import com.bfm.aap.pmdx.model.Asset.Builder;
import com.bfm.aap.pmdx.model.Performance;
import com.bfm.aap.privatemarkets.common.model.LoaderResponse;
import com.bfm.aap.privatemarkets.common.model.MultipleLoaderResponse;
import com.bfm.aap.privatemarkets.common.model.SingleLoaderResponse;
import com.bfm.aap.privatemarkets.dao.CusipAliasesDaoImpl;
import com.bfm.aap.privatemarkets.dao.FloaterDaoImpl;
import com.bfm.aap.privatemarkets.dao.IssuerSectorDaoImpl;
import com.bfm.aap.privatemarkets.dao.NewIssueInfoDaoImpl;
import com.bfm.aap.privatemarkets.dao.ReMasterDaoImpl;
import com.bfm.aap.privatemarkets.dao.SecAttributeValueDaoImpl;
import com.bfm.aap.privatemarkets.dao.SecurityMasterDao;
import com.bfm.aap.privatemarkets.dao.SmVectorDataDaoImpl;
import com.bfm.aap.privatemarkets.dao.TrancheFactorsDaoImpl;
import com.bfm.aap.privatemarkets.dao.model.CusipAliases;
import com.bfm.aap.privatemarkets.dao.model.Floater;
import com.bfm.aap.privatemarkets.dao.model.IssuerSector;
import com.bfm.aap.privatemarkets.dao.model.NewIssueInfo;
import com.bfm.aap.privatemarkets.dao.model.ReMaster;
import com.bfm.aap.privatemarkets.dao.model.SecAttributeValue;
import com.bfm.aap.privatemarkets.dao.model.SecMaster;
import com.bfm.aap.privatemarkets.dao.model.SmVectorData;
import com.bfm.aap.privatemarkets.dao.model.TrancheFactors;
import com.bfm.aap.privatemarkets.dao.util.DateUtil;
import com.google.protobuf.util.Timestamps;

/**
 * @author vivekkum
 *
 */
public class AssertionUtility {

	public static void assertSecurityMaster(SecurityMasterDao securityMasterDao, Map<String, String> fieldsDescriptor,
			Boolean isFixedCoupon) {
		SecMaster securityMaster = securityMasterDao.getSecurity(fieldsDescriptor.get("cusip"));
		assertNotNull(securityMaster);
		assertEquals(fieldsDescriptor.get("cusip"), securityMaster.getCusip());
		assertEquals(fieldsDescriptor.get("currency"), securityMaster.getCurrency());
		assertEquals(fieldsDescriptor.get("domicile"), securityMaster.getCountry());
		assertEquals(fieldsDescriptor.get("assetName"), securityMaster.getSecLongName());
		assertEquals(fieldsDescriptor.get("notionalFlag"), securityMaster.getNotionalFlag());
		assertEquals(fieldsDescriptor.get("flag144A"), securityMaster.getFlag144a());
		if (!ObjectUtils.isEmpty(isFixedCoupon) && isFixedCoupon) {
			assertEquals(Double.valueOf(fieldsDescriptor.get("coupon")), securityMaster.getCoupon());
		}
	}

	public static void assertSecAttributeValue(SecAttributeValueDaoImpl secAttributeValueDao,
			Map<String, String> fieldsDescriptor, int secAttributeDefnId) {
		List<SecAttributeValue> secAttributeValues = secAttributeValueDao
				.getSecAttributeValue(fieldsDescriptor.get("cusip"), secAttributeDefnId);
		for (SecAttributeValue secAttributeValue : secAttributeValues) {
			assertEquals(fieldsDescriptor.get("capitalStructure"), secAttributeValue.getValueChar());
		}
	}

	public static void assertSmVectorData(SmVectorDataDaoImpl smVectorDataDao, Map<String, String> fieldDescriptor,
			String cusip, String attributeType) {
		List<SmVectorData> smVectorDataList = smVectorDataDao.getSmVectorData(fieldDescriptor.get("cusip"),
				attributeType);
		assertTrue(!smVectorDataList.isEmpty());
		for (SmVectorData smVectorData : smVectorDataList) {
			assertEquals(cusip, smVectorData.getId().getAladdinId());
			assertEquals(attributeType, smVectorData.getId().getAttrType());
			assertEquals("RE_ASSET_LTV", smVectorData.getId().getAttrName());
			assertEquals(Double.valueOf(fieldDescriptor.get("realEstateLTV")),
					Double.valueOf(smVectorData.getAttrPct()));
		}
	}

	public static void assertNewIssueInfo(NewIssueInfoDaoImpl newIssueInfoDao, Builder assetBuilder, String cusip) {
		NewIssueInfo newIssueInfo = newIssueInfoDao.loadNewIssueInfo(cusip);
		assertNotNull(newIssueInfo);
		assertEquals(cusip, newIssueInfo.getCusip());
		assertEquals(Double.valueOf(assetBuilder.getFundDetails().getFundSize()), newIssueInfo.getAmtIssued());
	}

	public static void assertTrancheFactors(TrancheFactorsDaoImpl trancheFactorsDao, String cusip, String issueDate,
			String coupon) {
		com.google.protobuf.Timestamp pfts = com.google.protobuf.Timestamp.newBuilder()
				.setSeconds(Long.parseLong(issueDate)).build();

		Timestamp effectiveDate = DateUtil.getUTCDateTimestamp(Timestamps.toMillis(pfts));
		Optional<TrancheFactors> trancheFactors = trancheFactorsDao.loadTrancheFactors(cusip, effectiveDate);
		assertTrue(trancheFactors.isPresent());
		assertEquals(cusip, trancheFactors.get().getTrancheFactorsPK().getCusip());
		assertEquals(Double.valueOf(coupon), trancheFactors.get().getCoupon());
	}

	public static void assertFloater(FloaterDaoImpl floaterDao, String cusip, String coupon) {
		Floater floater = floaterDao.loadFloater(cusip);
		assertNotNull(floater);
		assertEquals(cusip, floater.getCusip());
	}

	public static void assertIssuerSector(IssuerSectorDaoImpl issuerSectorDao, Map<String, String> fieldsDescriptor,
			String sectorSet, short sectorLevel) {
		Optional<IssuerSector> issuerSector = issuerSectorDao.load(fieldsDescriptor.get("cusip"), sectorSet,
				sectorLevel);
		assertTrue(issuerSector.isPresent());
		assertEquals(fieldsDescriptor.get("cusip"), issuerSector.get().getId().getIssuer());
		assertEquals(sectorSet, issuerSector.get().getId().getSectorSet());
		assertEquals(sectorLevel, issuerSector.get().getId().getSectorLevel());
		assertEquals(fieldsDescriptor.get("assetType"), issuerSector.get().getSectorCode());
	}

	public static void assertCusipAliases(CusipAliasesDaoImpl cusipAliasesDao, Builder assetBuilder, String cusip,
			int aliasCode, String purpose) {
		Optional<CusipAliases> cusipAliases = cusipAliasesDao.loadCusipAliases(cusip, aliasCode, purpose);
		assertTrue(cusipAliases.isPresent());
	}

	public static void assertReMaster(ReMasterDaoImpl reMasterDao, Map<String, String> fieldsDescriptor) {
		ReMaster reMaster = reMasterDao.fetch(fieldsDescriptor.get("cusip"));
		assertNotNull(reMaster);
		assertEquals(fieldsDescriptor.get("cusip"), reMaster.getCusip());
		assertEquals(fieldsDescriptor.get("MSA"), reMaster.getMetro());
		assertEquals(fieldsDescriptor.get("ncreifRegion"), reMaster.getDivision());
		assertEquals(fieldsDescriptor.get("city"), reMaster.getCity());
		assertEquals(fieldsDescriptor.get("state"), reMaster.getState());
		assertEquals(fieldsDescriptor.get("assetInvestmentStyle"), reMaster.getPropInvStrat());
		assertEquals(fieldsDescriptor.get("zipCode"), reMaster.getZipCode());
		assertEquals(fieldsDescriptor.get("streetAddress"), reMaster.getAddress());
		assertEquals(fieldsDescriptor.get("reClass"), reMaster.getOfficeClass());
		assertEquals(fieldsDescriptor.get("assetStrategy"), reMaster.getAssetStrategy());
	}

	public static String getCusip(SingleLoaderResponse singleProtoResponse) {
		assertEquals(true, singleProtoResponse.getLoaderResponse().isSuccess());
		String cusip = (String) singleProtoResponse.getLoaderResponse().getData().get("AladdinId");
		assertNotNull(cusip);
		return cusip;
	}

	public static List<String> getCusipForMultiLoaderRes(MultipleLoaderResponse multipleProtoResponse) {
		List<String> cusips = Lists.newArrayList();
		List<LoaderResponse> loaderResponseList = multipleProtoResponse.getLoaderResponseList();
		for (LoaderResponse loaderResponse : loaderResponseList) {
			if (loaderResponse.isSuccess()) {
				cusips.add((String) loaderResponseList.get(0).getData().get("AladdinId"));
			}
		}
		return cusips;
	}

	@SuppressWarnings("unchecked")
	public static void assertProtoResponsePerformance(LoaderResponse loaderResponse, Performance performance) {
		assertEquals(Boolean.TRUE, loaderResponse.isSuccess());
		Map<String, Object> dataMap = loaderResponse.getData();

		for (Entry<String, Object> entry : dataMap.entrySet()) {
			Map<String, Object> values = (Map<String, Object>) entry.getValue();
			assertEquals(Double.valueOf((String) values.get("net_irr")), Double.valueOf(performance.getNetIrr()));
			assertEquals(Double.valueOf((String) values.get("net_irr_1yr")),
					Double.valueOf(performance.getNetIrr1Yr()));
			assertEquals(Double.valueOf((String) values.get("net_irr_3yr")),
					Double.valueOf(performance.getNetIrr3Yr()));
			assertEquals(Double.valueOf((String) values.get("net_irr_5yr")),
					Double.valueOf(performance.getNetIrr5Yr()));
			assertEquals(Double.valueOf((String) values.get("net_irr_7yr")),
					Double.valueOf(performance.getNetIrr7Yr()));
			assertEquals(Double.valueOf((String) values.get("net_irr_10yr")),
					Double.valueOf(performance.getNetIrr10Yr()));
			assertEquals((String) values.get("cusip"), performance.getCusip());
			assertEquals((String) values.get("object_id"), performance.getObjectId());
			assertEquals(Double.valueOf((String) values.get("net_tvpi")), Double.valueOf(performance.getNetTvpi()));
			assertEquals((String) values.get("performance_id"), performance.getPerformanceId());
		}
	}

}
