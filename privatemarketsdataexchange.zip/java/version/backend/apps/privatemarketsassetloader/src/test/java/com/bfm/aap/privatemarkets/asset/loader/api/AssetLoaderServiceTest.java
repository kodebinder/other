package com.bfm.aap.privatemarkets.asset.loader.api;

import com.bfm.aap.pmdx.model.Asset;
import com.bfm.aap.pmdx.model.CompanyDetails;
import com.bfm.aap.pmdx.model.FundDetails;
import com.bfm.aap.pmdx.model.Instrument;
import com.bfm.aap.pmdx.model.InstrumentDetails;
import com.bfm.aap.pmdx.model.Performance;
import com.bfm.aap.pmdx.model.ShareClass;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.model.util.Source;
import com.bfm.aap.privatemarkets.asset.loader.exception.AssetExceptionEnum;
import com.bfm.aap.privatemarkets.asset.loader.service.AssetService;
import com.bfm.aap.privatemarkets.common.model.LoaderResponse;
import com.bfm.aap.privatemarkets.common.model.MultipleLoaderResponse;
import com.bfm.aap.privatemarkets.common.model.SingleLoaderResponse;
import com.bfm.aap.privatemarkets.common.util.AssetCommonConstant;
import com.bfm.beam2.RequestContext;
import com.google.protobuf.Timestamp;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AssetLoaderServiceTest {

	@InjectMocks
	private AssetLoaderService assetLoaderService;

	@Mock
	private AssetService assetService;

	@Mock
	private RequestContext requestContext;

	private Performance performanceRequest;

	@BeforeEach
	void setUp() {
		when(requestContext.user()).thenReturn("tsgops");
		performanceRequest = Performance.newBuilder().build();
	}
	
	@Test
	public void upsertAltsInstrument_WhenInstrumentCreationFails() {
		Instrument instrumentRequest = Instrument.newBuilder().setDomicile("US")
		.setCompanyDetails(CompanyDetails.newBuilder().setCompanyType("COM").build())
		.setAssetName("A4a-Demo Test-2").setCurrency("USD").setAssetId("257C8636BC884DD899132B24BFF-Different")
		.addInstrumentDetails(InstrumentDetails.newBuilder().setSecGroup("EQUITY").setSecType("PRIVATE").
				setInstrumentName("INstrument name").setInstrumentCurrency("USD")
				.setCapitalStructure("EQ").build())
		.build();
		
		LoaderResponse protoResponse = new LoaderResponse();
		protoResponse.setSuccess(false);
		protoResponse.setMessage(AssetExceptionEnum.CREATE_INSTRUMENT_EXCEPTION.getMessage());
		Map<String, Object> data = new HashMap<>();
		data.put("aladdinID", "RDDULKPU3");
		protoResponse.setData(data);

		when(assetService.upsertInstrument(any(), any())).thenReturn(Arrays.asList(protoResponse));

		MultipleLoaderResponse multiProtoResponse  = assetLoaderService.upsertAltsInstrument(requestContext, instrumentRequest);
		assertEquals(AssetExceptionEnum.CREATE_INSTRUMENT_EXCEPTION.getMessage(), multiProtoResponse.getLoaderResponseList().get(0).getMessage());
	}

	
	@Test
	public void upsertAltsInstrument() {
		Instrument instrumentRequest = Instrument.newBuilder().setDomicile("US")
		.setCompanyDetails(CompanyDetails.newBuilder().setCompanyType("COM").build())
		.setAssetName("A4a-Demo Test-2").setCurrency("USD").setAssetId("257C8636BC884DD899132B24BFF-Different")
		.addInstrumentDetails(InstrumentDetails.newBuilder().setSecGroup("EQUITY").setSecType("PRIVATE").
				setInstrumentName("INstrument name").setInstrumentCurrency("USD")
				.setCapitalStructure("EQ").build())
		.build();
		
		LoaderResponse protoResponse = new LoaderResponse();
		protoResponse.setSuccess(true);
		protoResponse.setMessage(AssetCommonConstant.SUCCESS_MESSAGE);
		Map<String, Object> data = new HashMap<>();
		data.put("aladdinID", "RDDULKPU3");
		protoResponse.setData(data);

		when(assetService.upsertInstrument(any(), any())).thenReturn(Arrays.asList(protoResponse));

		MultipleLoaderResponse multiProtoResponse  = assetLoaderService.upsertAltsInstrument(requestContext, instrumentRequest);
		assertEquals(AssetCommonConstant.SUCCESS_MESSAGE, multiProtoResponse.getLoaderResponseList().get(0).getMessage());
	}
	
	@Test
	public void upsertAltsAsset() {
		Asset asset = Asset.newBuilder().setAssetName("test-asset")
				.setFundDetails(FundDetails.newBuilder().setVintageYear("2018").build())
				.build();

		LoaderResponse protoResponse = new LoaderResponse();
		protoResponse.setSuccess(true);
		protoResponse.setMessage(AssetCommonConstant.SUCCESS_MESSAGE);
		Map<String, Object> data = new HashMap<>();
		data.put("aladdinID", "RDDULKPU3");
		protoResponse.setData(data);

		when(assetService.upsertAltsAsset(any(), any())).thenReturn(protoResponse);

		SingleLoaderResponse singleProtoResponse = assetLoaderService
				.upsertAltsAsset(requestContext, asset);
		assertEquals(AssetCommonConstant.SUCCESS_MESSAGE, singleProtoResponse.getLoaderResponse().getMessage());
	}

	@Test
	public void upsertAltsAssets_WhenOneResponseIsFailure() {
		Asset asset = Asset.newBuilder().setAssetName("test-asset")
				.setFundDetails(FundDetails.newBuilder().setVintageYear("2018").build())
				.build();
		List<Asset> assetRequests = Arrays.asList(asset);

		LoaderResponse protoResponse1 = new LoaderResponse();
		protoResponse1.setSuccess(true);
		protoResponse1.setMessage(AssetCommonConstant.SUCCESS_MESSAGE);
		Map<String, Object> data = new HashMap<>();
		data.put("aladdinID", "RDDULKPU3");
		protoResponse1.setData(data);

		LoaderResponse protoResponse2 = new LoaderResponse();
		protoResponse2.setSuccess(false);
		protoResponse2.setMessage("Unable to create an asset");
		Map<String, Object> data1 = new HashMap<>();
		data.put("aladdinID", "RDDULKPU4");
		protoResponse2.setData(data1);

		List<LoaderResponse> protoResponses = Arrays.asList(protoResponse1, protoResponse2);

		when(assetService.upsertAltsAssets(any(), any())).thenReturn(protoResponses);

		MultipleLoaderResponse multipleProtoResponse = assetLoaderService
				.upsertAltsAssets(requestContext, assetRequests);
		assertEquals("Failed requests: " + "1" + "\n" +"Successful requests: " + "1",
				multipleProtoResponse.getMessage());
		assertFalse(multipleProtoResponse.isSuccess());
	}

	@Test
	public void upsertAltsAssets_WhenAllTheResponsesAreSucess() {
		Asset asset = Asset.newBuilder().setAssetName("test-asset")
				.setFundDetails(FundDetails.newBuilder().setVintageYear("2018").build())
				.build();
		List<Asset> assetRequests = Arrays.asList(asset);

		LoaderResponse protoResponse = new LoaderResponse();
		protoResponse.setSuccess(true);
		protoResponse.setMessage(AssetCommonConstant.SUCCESS_MESSAGE);
		Map<String, Object> data = new HashMap<>();
		data.put("aladdinID", "RDDULKPU3");
		protoResponse.setData(data);

		List<LoaderResponse> protoResponses = Arrays.asList(protoResponse);

		when(assetService.upsertAltsAssets(any(), any())).thenReturn(protoResponses);

		MultipleLoaderResponse multipleProtoResponse = assetLoaderService
				.upsertAltsAssets(requestContext, assetRequests);
		assertEquals(AssetCommonConstant.SUCCESS_MESSAGE, multipleProtoResponse.getMessage());
	}

	@Test
	void upsertStaticPerformance_Success() {
		LoaderResponse protoResponse = new LoaderResponse();
		protoResponse.setData(new HashMap<>());
		protoResponse.setMessage(AssetCommonConstant.SUCCESS_MESSAGE);
		protoResponse.setSuccess(true);

		when(assetService.upsertStaticPerformance(any(), any())).thenReturn(protoResponse);

		SingleLoaderResponse singleProtoResponse =
				assetLoaderService.upsertStaticPerformance(requestContext, performanceRequest);
		assertEquals(new HashMap<>(), singleProtoResponse.getLoaderResponse().getData());
		assertEquals(AssetCommonConstant.SUCCESS_MESSAGE, singleProtoResponse.getLoaderResponse().getMessage());
		assertTrue(singleProtoResponse.getLoaderResponse().isSuccess());
	}

	@Test
	void upsertStaticPerformance_Failure() {
		LoaderResponse protoResponse = new LoaderResponse();
		protoResponse.setData(null);
		protoResponse.setMessage("Failed to persist the static performance record");
		protoResponse.setSuccess(false);

		when(assetService.upsertStaticPerformance(any(), any())).thenReturn(protoResponse);

		SingleLoaderResponse singleProtoResponse =
				assetLoaderService.upsertStaticPerformance(requestContext, performanceRequest);
		assertNull(singleProtoResponse.getLoaderResponse().getData());
		assertEquals("Failed to persist the static performance record", singleProtoResponse.getLoaderResponse().getMessage());
		assertFalse(singleProtoResponse.getLoaderResponse().isSuccess());
	}

	@Test
	void upsertStaticPerformanceList_Success() {
		List<Performance> requests = Collections.singletonList(performanceRequest);

		LoaderResponse protoResponse = new LoaderResponse();
		protoResponse.setData(new HashMap<>());
		protoResponse.setMessage(AssetCommonConstant.SUCCESS_MESSAGE);
		protoResponse.setSuccess(true);
		List<LoaderResponse> protoResponses = Collections.singletonList(protoResponse);

		when(assetService.upsertStaticPerformanceList(any(), any())).thenReturn(protoResponses);

		MultipleLoaderResponse manyProtoResponse =
				assetLoaderService.upsertStaticPerformanceList(requestContext, requests);
		assertEquals(AssetCommonConstant.SUCCESS_MESSAGE, manyProtoResponse.getMessage());
		assertTrue(manyProtoResponse.isSuccess());
	}

	@Test
	void upsertStaticPerformanceList_OneFailure() {
		List<Performance> requests = Collections.singletonList(performanceRequest);

		LoaderResponse protoResponse1 = new LoaderResponse();
		protoResponse1.setData(new HashMap<>());
		protoResponse1.setMessage(AssetCommonConstant.SUCCESS_MESSAGE);
		protoResponse1.setSuccess(true);

		LoaderResponse protoResponse2 = new LoaderResponse();
		protoResponse2.setData(null);
		protoResponse2.setMessage("The attempt to upsert a static performance record timed out");
		protoResponse2.setSuccess(false);

		List<LoaderResponse> protoResponses = Arrays.asList(protoResponse1, protoResponse2);

		when(assetService.upsertStaticPerformanceList(any(), any())).thenReturn(protoResponses);

		MultipleLoaderResponse manyProtoResponse =
				assetLoaderService.upsertStaticPerformanceList(requestContext, requests);
		String expectedMessage = "Failed requests: " + 1 + "\n" +
				"Successful requests: " + (protoResponses.size() - 1);
		assertEquals(expectedMessage, manyProtoResponse.getMessage());
		assertFalse(manyProtoResponse.isSuccess());
	}
	
	@Test
	void testUpsertShareclass() {
		ShareClass shareclassRequest = ShareClass.newBuilder().setPortfolioId("ED5FF3D09A7D40A08BE3E3B5DB921D35")
        		.setPortfolioCusip("E2E_AP1")
        		.setPortfolioName("End 2 End Test Aladdin Portfolio 1")
				.setPortfolioInvestibleCusip("")
        		.setCurrency("USD")
        		.setCusip("")
				.setInceptionDate(Timestamp.newBuilder()
						.setSeconds(1565898996)
						.setNanos(0)
						.build())
        		.setDomicile("")
        		.setGeographyFocus("")
        		.setPeSectorFocus("")
        		.setPeStageFocus("")
        		.setPortfolioCode(123)
        		.setShareclassId("")
        		.setShareclassIndex(123)
        		.setShareclassShortname("")
        		.setVintageYear("")
        		.setEntityInfo(EntityInfo.newBuilder()
        				.setNetworkMode(NetworkMode.BLUE)
        				.setClientName("DEV")
        				.setPrimaryData(true)
        				.setSource(Source.INVEST))
        		.build();
		
		LoaderResponse protoResponse = new LoaderResponse();
		protoResponse.setSuccess(true);
		protoResponse.setMessage(AssetCommonConstant.SUCCESS_MESSAGE);
		Map<String, Object> data = new HashMap<>();
		data.put("aladdinID", "RDDULKPU3");
		protoResponse.setData(data);

		when(assetService.upsertShareClass(any(), any())).thenReturn(Arrays.asList(protoResponse));

		MultipleLoaderResponse multiProtoResponse  = assetLoaderService.upsertAltsShareClass(requestContext, shareclassRequest);
		assertEquals(AssetCommonConstant.SUCCESS_MESSAGE, multiProtoResponse.getLoaderResponseList().get(0).getMessage());
	}
}
