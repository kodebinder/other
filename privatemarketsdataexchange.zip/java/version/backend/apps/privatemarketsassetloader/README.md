# PrivateMarketAssetLoader

# Table of Contents
- [Description](README.md##Description)
- [Overview](README.md##Overview)
- [External Dependency](README.md##ExternalDependency)
- [Factors to Consider](README.md##FactorsToConsider)
- [Quick Start](README.md##QuickStart)
- [EndPoints](README.md##EndPoints)
- [Running in Development](README.md##RunningInDevelopment)
- [Build -> Release -> Deploy](README.md##BuildReleaseDeploy)

--------------------------------------------------------------------------------------------------------------------------------
## Description
The Private Market Asset Loader is a Distributed Enterprise Java(8) application server (the 'PrivateMarketAssetLoader') built on micro-services architecture.  
The server facilitates alternative investment security creation for Efront Securities in Blackrock
It liaises with PortfolioServer to create Portfolio cusip representing the Alternative asset in Aladdin.
It also reads definitions from Security.Json to read Alternative Asset Attributes for Asset Creation 

## Overview
A distributed enterprise data server (the 'PrivateMarketAssetLoader') that services Alternative investments and business processes on Aladdin.  The server acts as an abstraction over the many disparate data sources.

## ExternalDependency
- PortfolioServer for portfolio creation.


## FactorsToConsider
- Architecture will support frictionless development across a globally distributed team
- Maintain a low-level of complexity
    - Architecture is simple to understand
    - Easy to modify, reduce, and/or augment
    - Stay as DRY as possible
- Documentation is well defined and done in concert with development, not after
    - Every change is a pull request to force code reviews
- New contributors must be able to quickly become productive
- Leverage git and the open software development standards
- Scale through separation of concern, isolation, and functional decoupling
- Segment data in functional areas to facilitate functional decoupling and isolation
- Avoid service coupling
- Multi-tenancy and distributed across multiple data-centers
- Able to run multiple instances to satisfy scalability and availability requirements
- Eliminate BMS boilerplate by leveraging BEAM 2
- Is divided into following modules:
> - PrivateMarket Asset Loader Core - Has API for asset creation, updation and retrieval.
> - PrivateMarkets Asset DAO - Has DAO And Models 
> - PrivateMarkets Asset Dictionary - Reads the file and creates cache for asset attributes
> - PrivateMarkets Permission - Has permission checks for Asset Creation

------------------------------------------------------------------------------------------------------------------------

## QuickStart
1. Check out the project from git repository (ssh://git@git.blackrock.com/aap/alternativeinvestmentsystems.git OR https://airaj@git.blackrock.com/scm/aap/alternativeinvestmentsystems.git). Checkout Java directory as Mavel Project. Build the whole suit or individual services as per requirement
2. Run As maven build... -> clean install [skip test] alts-investment-systems-backend-parent OR
3.  Run As maven build... -> clean install [skip test] alts-investment-systems-apps-parent > alts-investment-systems-libs-parent OR
4.  Run As maven build... -> clean install [skip test] privatemarketsassetloader > privatemarkets-dao > privatemarkets-datadictionary > privatemarkets-asset-common 
5.  Run PrivateMarketAssetLoader with  arguments marked in RunnningInDevelopment section.
------------------------------------------------------------------------------------------------------------------------
## RunningInDevelopment
VM Args to be used while running via an IDE:

```
-DdefaultWebServer=https://dev.blackrock.com
-DAUTH_METHOD=SERVER
-Dbms.port=5000
-Dmode=Red
-DBRS.STAT_COLLECTOR_BASE_URL=http://devcxsl001:60026/
-DapplicationName=PrivateMarketsAssetLoader
-DsourceId=<yourSourceId>
-DwriteAccess=true
-DBRS.PMDX_BASE_DIR_BLUE=<yourLocalPathToPMDX>privatemarketsdataexchange\java\version\backend\libs\privatemarkets-datadictionary\src\main\resources\schema-dir
-DBRS.PMDX_BASE_DIR_RED=<yourLocalPathToPMDX>privatemarketsdataexchange\java\version\backend\libs\privatemarkets-datadictionary\src\main\resources\schema-dir
-DBRS.ADL_DEFAULT_LOCATION_ON_FAILURE=EWD
-DBRS.ADL_CONFIG_DIR=X:/build/dev/std/adl
-DBRS.ADL_TOPOLOGY_CONFIG=X:/build/dev/std/adl/adlClusterTopology.cfg
-DBRS.brs_root=X:/brs_root
-DBRS.brs_uat=X:/brs_uat
-DBRS.brs_std=X:/brs_std
-DBRS.build=X:/build
-Dspring.config.location=file:C:/schema_files/PrivateMarketsLoader.properties
 ```
 
 --------------------------------------------------------------------------------------------------
## EndPoints
```
- Command: upsertAsset
  Request : SingleAssetRequest
  Response : SingleAssetResponse
  
- Command: upsertAssets
  Request : MultipleAssetRequest
  Response : MultipleAssetResponse
 ```
--------------------------------------------------------------------------------------------------
## BuildReleaseDeploy
1. Building the project locally
    - The Project uses Maven build system . 
    - If you are new to Maven go through the following setup links:    
    - https://webster.bfm.com/Wiki/display/rm/Maven+-+Getting+Started 
    - https://webster.bfm.com/Wiki/display/rm/IntelliJ+Setup 
    - https://webster.bfm.com/Wiki/display/rm/Create+settings.xml+and+toolchains.xml 
    - https://webster.bfm.com/Wiki/display/rm/How+To%3A+Set+up+Maven+in+local 

2. Use "mvn clean install -DskipTests" to build your project locally.The sequence of build needs to be privatemarketsassetloader > privatemarkets-dao > privatemarkets-datadictionary > privatemarkets-common .
(Alternatively complete suite can be build as well -> alts-investment-systems-apps-parent > alts-investment-systems-libs-parent to be even more precise just build alts-investment-systems-backend-parent and that should suffice) 

3. Building the project on [4D](https://dev.blackrock.com/apps/4d/#/openProject/aap/a4a-backend)

4. **Release element**: [privatemarketsassetloader.jar (Blue)](https://webster.bfm.com/weblications/perms/summary.epl?elemId=689582) OR [privatemarketsassetloader.jar (Red)](https://webster.bfm.com/weblications/perms/summary.epl?elemId=689578) 

5. **Appserver element** : [PrivateMarketsAssetLoader_BLUE](https://webster.bfm.com/weblications/perms/summary.epl?elemId=689586) OR [PrivateMarketsAssetLoader_RED](https://webster.bfm.com/weblications/perms/summary.epl?elemId=689585) 

6. **Directory element** :  [/usr/local/bfm/apps/alternativeinvestmentsystems/blue](https://webster.bfm.com/weblications/perms/summary.epl?elemId=689446) OR [/usr/local/bfm/apps/alternativeinvestmentsystems/red](https://webster.bfm.com/weblications/perms/summary.epl?elemId=689443)

7. **Source Ids** : [PRIVATEMARKETS_ASSET_LOADER_BLUE](https://webster.bfm.com/weblications/perms/summary.epl?elemId=689460) OR [PRIVATEMARKETS_ASSET_LOADER_RED](https://webster.bfm.com/weblications/perms/summary.epl?elemId=689459)

8. **Files.dat Tokens** : [PMAssetLoaderDir_BLUE](https://webster.bfm.com/weblications/perms/summary.epl?elemId=689575) OR [PMAssetLoaderDir_RED](https://webster.bfm.com/weblications/perms/summary.epl?elemId=689574)
------------------------------------------------------------------------------------------------------------------------
