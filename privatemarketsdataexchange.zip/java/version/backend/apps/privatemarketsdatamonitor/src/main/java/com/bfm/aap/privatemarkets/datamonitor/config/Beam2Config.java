package com.bfm.aap.privatemarkets.datamonitor.config;

import com.bfm.beam2.permission.PermissionStores;
import com.bfm.beam2.server.ServiceGateway;
import com.bfm.beam2.server.ServiceGateways;
import com.bfm.beam2.server.bmsintegration.BmsServiceGateways;
import com.bfm.privatemarkets.beam2.util.Proto3JsonConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Beam2Config {
    private static final String APPLICATION_NAME = "PrivateMarketsDataMonitor";
    private static final int NUM_WORKER_THREADS = 10;

    @Bean
    public ServiceGateway serviceGateway() {
        BmsServiceGateways.BmsServiceGatewayConfig config = (new BmsServiceGateways.BmsServiceGatewayConfig())
                .name(APPLICATION_NAME).numberOfWorkers(NUM_WORKER_THREADS)
                .permissionStore(PermissionStores.bfmPermissionsSetStore());
        config.addConverterFactory(Proto3JsonConverter.factory());
        return ServiceGateways.bmsGateway(config);
    }
}
