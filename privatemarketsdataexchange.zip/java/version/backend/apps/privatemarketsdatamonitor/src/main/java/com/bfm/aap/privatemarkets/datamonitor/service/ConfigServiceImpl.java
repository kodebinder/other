package com.bfm.aap.privatemarkets.datamonitor.service;

import com.google.common.annotations.VisibleForTesting;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public final class ConfigServiceImpl implements ConfigService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ConfigServiceImpl.class);

    @Override
    public Properties getProperties() {
        final Properties properties = new Properties();
        loadProperties(properties, "PrivateMarketsDataMonitor.properties");
        return properties;
    }

    @VisibleForTesting
    static void loadProperties(final Properties properties, final String resourceName) {
        try(final InputStream inputStream = ConfigServiceImpl.class
                .getClassLoader()
                .getResourceAsStream(resourceName)) {
            properties.load(inputStream);
        } catch (IOException | NullPointerException e) {
            final String message = String.format("Error loading properties file at %s", resourceName);
            LOGGER.error(message);
            throw new IllegalArgumentException(message, e);
        }
    }
}
