package com.bfm.aap.privatemarkets.datamonitor;

import com.bfm.aap.pmdx.logmetrics.logger.EDXBeam2MetricListener;
import com.bfm.aap.privatemarkets.datamonitor.service.ConfigServiceImpl;
import com.bfm.aap.privatemarkets.datamonitor.service.DataMonitorService;
import com.bfm.aap.privatemarkets.datamonitor.service.DataMonitorServiceImpl;
import com.bfm.beam2.Configs;
import com.bfm.beam2.server.ServiceGateway;
import com.bfm.metric.beam2.Beam2MetricListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;

import java.util.Properties;

@ComponentScan("com.bfm.aap.privatemarkets.datamonitor")
public class PrivateMarketsDataMonitor {
    private static final Logger LOGGER = LoggerFactory.getLogger(PrivateMarketsDataMonitor.class);
    private static String SOURCE_ID;

    public static void main(String[] args) {
        LOGGER.info("Starting Private Markets Data Monitor Server...");
        getConfiguration();
        new PrivateMarketsDataMonitor().startMonitor();
        LOGGER.info("Private Markets Data Monitor Server started.");
    }

    private static void getConfiguration() {
        Properties properties = new ConfigServiceImpl().getProperties();

        SOURCE_ID = properties.getProperty("source-id");
    }

    private void startMonitor() {
        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(PrivateMarketsDataMonitor.class);
        context.registerShutdownHook();
        ServiceGateway serviceGateway = context.getBean(ServiceGateway.class);
        DataMonitorService dataMonitorService = DataMonitorServiceImpl.createMonitorService();
        serviceGateway.register(dataMonitorService, Configs.builder().setSourceId(Integer.parseInt(SOURCE_ID)).build());
        serviceGateway.addStatusListener(statusEvent -> LOGGER.info("ServiceGateway Event: {}", statusEvent));
        serviceGateway.addRequestEventListener(requestEvent -> LOGGER.info("Request Event: {}", requestEvent));
        final boolean enableTelemetry = Boolean.parseBoolean(System.getProperty("telemetry", "true"));
        if(enableTelemetry) {
            Beam2MetricListener.addListenerToGateway(serviceGateway, new EDXBeam2MetricListener(true));
        }
    }
}
