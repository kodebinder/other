package com.bfm.aap.privatemarkets.datamonitor.service;

import com.bfm.aap.pmdx.model.*;
import com.bfm.beam2.RequestContext;
import com.bfm.beam2.annotation.Beam2Method;
import com.bfm.beam2.annotation.Beam2Service;
import com.bfm.beam2.annotation.Param;

import java.util.List;

@Beam2Service
public interface DataMonitorService {
    @Beam2Method(command = "GET_ASSETS")
    List<Asset> getAssets(RequestContext requestContext, @Param("guid") String guid);

    @Beam2Method(command = "GET_PORTFOLIOS")
    List<Portfolio> getPortfolios(RequestContext requestContext, @Param("guid") String guid);

    @Beam2Method(command = "GET_POSITIONS")
    List<Position> getPositions(RequestContext requestContext, @Param("guid") String guid);

    @Beam2Method(command = "GET_PERFORMANCES")
    List<Performance> getPerformances(RequestContext requestContext, @Param("guid") String guid);

    @Beam2Method(command = "GET_FUNDAMENTALS")
    List<Fundamentals> getFundamentals(RequestContext requestContext, @Param("guid") String guid);

    @Beam2Method(command = "GET_USERS")
    List<User> getUsers(RequestContext requestContext, @Param("guid") String guid);

    @Beam2Method(command = "GET_CONTACTS")
    List<Contact> getContacts(RequestContext requestContext, @Param("guid") String guid);

    @Beam2Method(command = "GET_COMPANIES")
    List<Company> getCompanies(RequestContext requestContext, @Param("guid") String guid);

    @Beam2Method(command = "GET_INVESTORS")
    List<Investor> getInvestors(RequestContext requestContext, @Param("guid") String guid);

    @Beam2Method(command = "GET_TRANSACTIONS")
    List<Transaction> getTransactions(RequestContext requestContext, @Param("guid") String guid);

    @Beam2Method(command = "GET_INVESTOR_ACCOUNTS")
    List<InvestorAccount> getInvestorAccounts(RequestContext requestContext, @Param("guid") String guid);

    @Beam2Method(command = "GET_INSTRUMENTS")
    List<Instrument> getInstruments(RequestContext requestContext, @Param("guid") String guid);

    @Beam2Method(command = "GET_BANK_ACCOUNTS")
    List<BankAccount> getBankAccounts(RequestContext requestContext, @Param("guid") String guid);

    @Beam2Method(command = "GET_BANK_OPERATIONS")
    List<BankOperation> getBankOperations(RequestContext requestContext, @Param("guid") String guid);

    @Beam2Method(command = "GET_SHARE_CLASSES")
    List<ShareClass> getShareClasses(RequestContext requestContext, @Param("guid") String guid);
}
