package com.bfm.aap.privatemarkets.datamonitor.service;

import com.bfm.aap.pmdx.adl.api.PmdxADLWorkspace;
import com.bfm.aap.pmdx.adl.workspace.PmdxADLWorkspaceFactory;
import com.bfm.aap.pmdx.async.util.FutureUtil;
import com.bfm.aap.pmdx.model.*;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.beam2.RequestContext;
import com.bfm.beam2.annotation.AllowByPerm;
import com.google.common.annotations.VisibleForTesting;
import com.google.protobuf.Message;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiFunction;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public final class DataMonitorServiceImpl implements DataMonitorService {
    private static final String PERM_TYPE = "VIEW_PrivateMktData";
    private static final String ERROR_MESSAGE = "There is no %s with the guid %s.";
    private final List<PmdxADLWorkspace> adlWorkspaces;

    DataMonitorServiceImpl(final PmdxADLWorkspace blueAdlWorkspace, final PmdxADLWorkspace redAdlWorkspace) {
        adlWorkspaces = Arrays.asList(blueAdlWorkspace, redAdlWorkspace);
    }

    public static DataMonitorServiceImpl createMonitorService() {
        final PmdxADLWorkspace blueAdlWorkspace = PmdxADLWorkspaceFactory.withNetworkMode(NetworkMode.BLUE).newPmdxADLWorkspace();
        final PmdxADLWorkspace redAdlWorkspace = PmdxADLWorkspaceFactory.withNetworkMode(NetworkMode.RED).newPmdxADLWorkspace();

        return new DataMonitorServiceImpl(blueAdlWorkspace, redAdlWorkspace);
    }

    @Override
    @AllowByPerm(type=PERM_TYPE)
    public List<Asset> getAssets(final RequestContext requestContext, final String guid) {
        return getValidObjects(PmdxADLWorkspace::getAssetByGuid, guid)
                .orElseThrow(withIllegalArgumentFactory(Asset.class, guid));
    }

    @Override
    @AllowByPerm(type=PERM_TYPE)
    public List<Portfolio> getPortfolios(final RequestContext requestContext, final String guid) {
        return getValidObjects(PmdxADLWorkspace::getPortfolioByGuid, guid)
                .orElseThrow(withIllegalArgumentFactory(Portfolio.class, guid));
    }

    @Override
    @AllowByPerm(type=PERM_TYPE)
    public List<Position> getPositions(final RequestContext requestContext, final String guid) {
        return getValidObjects(PmdxADLWorkspace::getPositionByGuid, guid)
                .orElseThrow(withIllegalArgumentFactory(Position.class, guid));
    }

    @Override
    @AllowByPerm(type=PERM_TYPE)
    public List<Performance> getPerformances(final RequestContext requestContext, final String guid) {
        return getValidObjects(PmdxADLWorkspace::getPerformanceByGuid, guid)
                .orElseThrow(withIllegalArgumentFactory(Performance.class, guid));
    }

    @Override
    @AllowByPerm(type=PERM_TYPE)
    public List<Fundamentals> getFundamentals(final RequestContext requestContext, final String guid) {
        return getValidObjects(PmdxADLWorkspace::getFundamentalsByGuid, guid)
                .orElseThrow(withIllegalArgumentFactory(Fundamentals.class, guid));
    }

    @Override
    @AllowByPerm(type=PERM_TYPE)
    public List<User> getUsers(final RequestContext requestContext, final String guid) {
        return getValidObjects(PmdxADLWorkspace::getUserByGuid, guid)
                .orElseThrow(withIllegalArgumentFactory(User.class, guid));
    }

    @Override
    @AllowByPerm(type=PERM_TYPE)
    public List<Contact> getContacts(final RequestContext requestContext, final String guid) {
        return getValidObjects(PmdxADLWorkspace::getContactByGuid, guid)
                .orElseThrow(withIllegalArgumentFactory(Contact.class, guid));
    }

    @Override
    @AllowByPerm(type=PERM_TYPE)
    public List<Company> getCompanies(final RequestContext requestContext, final String guid) {
        return getValidObjects(PmdxADLWorkspace::getCompanyByGuid, guid)
                .orElseThrow(withIllegalArgumentFactory(Company.class, guid));
    }

    @Override
    @AllowByPerm(type=PERM_TYPE)
    public List<Investor> getInvestors(final RequestContext requestContext, final String guid) {
        return getValidObjects(PmdxADLWorkspace::getInvestorByGuid, guid)
                .orElseThrow(withIllegalArgumentFactory(Investor.class, guid));
    }

    @Override
    @AllowByPerm(type=PERM_TYPE)
    public List<Transaction> getTransactions(final RequestContext requestContext, final String guid) {
        return getValidObjects(PmdxADLWorkspace::getTransactionByGuid, guid)
                .orElseThrow(withIllegalArgumentFactory(Transaction.class, guid));
    }

    @Override
    @AllowByPerm(type=PERM_TYPE)
    public List<InvestorAccount> getInvestorAccounts(final RequestContext requestContext, final String guid) {
        return getValidObjects(PmdxADLWorkspace::getInvestorAccountByGuid, guid)
                .orElseThrow(withIllegalArgumentFactory(InvestorAccount.class, guid));
    }

    @Override
    @AllowByPerm(type=PERM_TYPE)
    public List<Instrument> getInstruments(final RequestContext requestContext, final String guid) {
        return getValidObjects(PmdxADLWorkspace::getInstrumentByGuid, guid)
                .orElseThrow(withIllegalArgumentFactory(Instrument.class, guid));
    }

    @Override
    @AllowByPerm(type=PERM_TYPE)
    public List<BankAccount> getBankAccounts(final RequestContext requestContext, final String guid) {
        return getValidObjects(PmdxADLWorkspace::getBankAccountByGuid, guid)
                .orElseThrow(withIllegalArgumentFactory(BankAccount.class, guid));
    }

    @Override
    @AllowByPerm(type=PERM_TYPE)
    public List<BankOperation> getBankOperations(RequestContext requestContext, String guid) {
        return getValidObjects(PmdxADLWorkspace::getBankOperationByGuid,guid)
                .orElseThrow(withIllegalArgumentFactory(BankOperation.class,guid));
    }

    @Override
    @AllowByPerm(type = PERM_TYPE)
    public List<ShareClass> getShareClasses(RequestContext requestContext, String guid) {
        return getValidObjects(PmdxADLWorkspace::getShareClassByGuid,guid)
                .orElseThrow(withIllegalArgumentFactory(ShareClass.class,guid));
    }

    @VisibleForTesting
    <T extends Message> Optional<List<T>> getValidObjects(
            final BiFunction<PmdxADLWorkspace, String, CompletableFuture<T>> getAdlObject,
            final String guid) {
        final List<CompletableFuture<T>> futures = adlWorkspaces.stream()
                .map(adlWorkspace -> getAdlObject.apply(adlWorkspace, guid))
                .collect(Collectors.toList());
        final CompletableFuture<List<T>> futureOfList = FutureUtil.allAsList(futures);
        final List<T> filteredList = FutureUtil.getResultUnchecked(futureOfList).stream()
                .filter(DataMonitorServiceImpl::isResultNonEmpty)
                .collect(Collectors.toList());

        return filteredList.isEmpty() ? Optional.empty() : Optional.of(filteredList);
    }

    private static <T extends Message> boolean isResultNonEmpty(final T result) {
        return !result.equals(result.getDefaultInstanceForType());
    }

    private static <T extends Message> Supplier<IllegalArgumentException> withIllegalArgumentFactory(
            final Class<T> entityClazz,
            final String guid) {
        return () -> {
            final String entityName = entityClazz.getSimpleName();
            return new IllegalArgumentException((String.format(ERROR_MESSAGE, entityName, guid)));
        };
    }
}
