package com.bfm.aap.privatemarkets.datamonitor.service;

import java.util.Properties;

public interface ConfigService {
    Properties getProperties();
}
