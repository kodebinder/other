package com.bfm.aap.privatemarkets.datamonitor.service;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import static org.junit.jupiter.api.Assertions.*;

public final class U_ConfigServiceImplTest {
    @Test
    public void testGetPropertiesOk() {
        final ConfigServiceImpl service = new ConfigServiceImpl();
        final Properties properties = service.getProperties();
        assertEquals("79650", properties.getProperty("source-id"));
    }

    @Test
    public void testGetPropertiesException() throws IOException {
        final Properties properties = Mockito.spy(Properties.class);
        Mockito.doThrow(IOException.class).when(properties).load(Mockito.any(InputStream.class));
        assertThrows(IllegalArgumentException.class, () ->
                ConfigServiceImpl.loadProperties(properties, "bad resource")
        );
    }
}
