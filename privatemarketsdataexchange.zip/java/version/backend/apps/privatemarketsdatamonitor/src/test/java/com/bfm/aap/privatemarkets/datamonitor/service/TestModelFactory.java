package com.bfm.aap.privatemarkets.datamonitor.service;

import com.bfm.aap.pmdx.model.*;
import com.bfm.aap.pmdx.model.util.EntityInfo;

final class TestModelFactory {
    private TestModelFactory() {}

    static Asset newValidAsset() {
        return Asset.newBuilder()
                .setAssetId("ASSET_ID")
                .setEntityInfo(getTestEntityInfo())
                .build();
    }

    static Asset newEmptyAsset() {
        return Asset.newBuilder().build();
    }

    static Portfolio newValidPortfolio() {
        return Portfolio.newBuilder()
                .setPortfolioId("PORTFOLIO_ID")
                .setEntityInfo(getTestEntityInfo())
                .build();
    }

    static Portfolio newEmptyPortfolio() {
        return Portfolio.newBuilder().build();
    }

    static Position newValidPosition() {
        return Position.newBuilder()
                .setAssetId("ASSET_ID")
                .setEntityInfo(getTestEntityInfo())
                .build();
    }

    static Position newEmptyPosition() {
        return Position.newBuilder().build();
    }

    static Performance newValidPerformance() {
        return Performance.newBuilder()
                .setPerformanceId("PERFORMANCE_ID")
                .setEntityInfo(getTestEntityInfo())
                .build();
    }

    static Performance newEmptyPerformance() {
        return Performance.newBuilder().build();
    }

    static Fundamentals newValidFundamentals() {
        return Fundamentals.newBuilder()
                .setCompanyId("COMPANY_ID")
                .setEntityInfo(getTestEntityInfo())
                .build();
    }

    static Fundamentals newEmptyFundamentals() {
        return Fundamentals.newBuilder().build();
    }

    static User newValidUser() {
        return User.newBuilder()
                .setUserId("USER_ID")
                .setEntityInfo(getTestEntityInfo())
                .build();
    }

    static User newEmptyUser() {
        return User.newBuilder().build();
    }

    static Contact newValidContact() {
        return Contact.newBuilder()
                .setContactId("CONTACT_ID")
                .setEntityInfo(getTestEntityInfo())
                .build();
    }

    static Contact newEmptyContact() {
        return Contact.newBuilder().build();
    }

    static Company newValidCompany() {
        return Company.newBuilder()
                .setCompanyId("COMPANY_ID")
                .setEntityInfo(getTestEntityInfo())
                .build();
    }

    static Company newEmptyCompany() {
        return Company.newBuilder().build();
    }

    static Transaction newValidTransaction() {
        return Transaction.newBuilder()
                .setGuid("TRANSACTION_ID")
                .setEntityInfo(getTestEntityInfo())
                .build();
    }

    static Transaction newEmptyTransaction() { return Transaction.newBuilder().build(); }

    static Investor newValidInvestor() {
        return Investor.newBuilder()
                .setInvestorId("INVESTOR_ID")
                .setEntityInfo(getTestEntityInfo())
                .build();
    }

    static Investor newEmptyInvestor() {
        return Investor.newBuilder().build();
    }

    static InvestorAccount newValidInvestorAccount() {
        return InvestorAccount.newBuilder()
                .setInvestorAccountId("INVESTOR_ACCOUNT_ID")
                .setEntityInfo(getTestEntityInfo())
                .build();
    }

    static InvestorAccount newEmptyInvestorAccount() {
        return InvestorAccount.newBuilder().build();
    }

    static Instrument newValidInstrument() {
        return Instrument.newBuilder()
                .setAssetId("INSTRUMENT_ID")
                .setEntityInfo(getTestEntityInfo())
                .build();
    }

    static Instrument newEmptyInstrument() {
        return Instrument.newBuilder().build();
    }

    static BankAccount newValidBankAccount() {
        return BankAccount.newBuilder()
                .setBankAccountId("BANK_ACCOUNT_ID")
                .setEntityInfo(getTestEntityInfo())
                .build();
    }

    static BankAccount newEmptyBankAccount() { return BankAccount.newBuilder().build(); }

    static BankOperation newValidBankOperation(){
        return BankOperation.newBuilder()
                .setBankOperationId("BANK_OPERATION_ID")
                .setEntityInfo(getTestEntityInfo())
                .build();
    }

    static BankOperation newEmptyBankOperation(){
        return BankOperation.newBuilder().build();
    }
 static ShareClass newValidShareClass(){
        return ShareClass.newBuilder()
                .setShareclassId("SHARE_CLASS_ID")
                .setEntityInfo(getTestEntityInfo())
                .build();
    }

    static ShareClass newEmptyShareClass(){
        return ShareClass.newBuilder().build();
    }

    private static EntityInfo getTestEntityInfo() {
        return EntityInfo.newBuilder().build();
    }
}
