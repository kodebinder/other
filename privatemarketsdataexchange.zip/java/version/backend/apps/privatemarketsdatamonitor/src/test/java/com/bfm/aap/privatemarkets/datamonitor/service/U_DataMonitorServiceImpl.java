package com.bfm.aap.privatemarkets.datamonitor.service;

import com.bfm.aap.pmdx.adl.api.PmdxADLWorkspace;
import com.bfm.aap.pmdx.model.*;
import com.bfm.beam2.RequestContext;
import com.google.common.collect.Lists;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public final class U_DataMonitorServiceImpl {
    private PmdxADLWorkspace mockBlueAdlWorkspace;
    private PmdxADLWorkspace mockRedAdlWorkspace;
    private DataMonitorServiceImpl service;
    private RequestContext mockContext;

    @BeforeAll
    public static void setUpBeforeClass() {
        System.setProperty("mode", "blue");
    }

    @BeforeEach
    public void setUpBeforeTest() {
        mockBlueAdlWorkspace = mock(PmdxADLWorkspace.class);
        mockRedAdlWorkspace = mock(PmdxADLWorkspace.class);
        service = new DataMonitorServiceImpl(mockBlueAdlWorkspace, mockRedAdlWorkspace);
        mockContext = mock(RequestContext.class);
    }

    @Test
    public void testGetAssetsOk() {
        final Asset validAsset = TestModelFactory.newValidAsset();
        final Asset emptyAsset = TestModelFactory.newEmptyAsset();
        when(mockBlueAdlWorkspace.getAssetByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(validAsset));
        when(mockRedAdlWorkspace.getAssetByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyAsset));
        final List<Asset> result = service.getAssets(mockContext, "testGuid");
        assertEquals(Lists.newArrayList(validAsset), result);
    }

    @Test
    public void testGetAssetsEmptyException() {
        try {
            final Asset emptyAsset = TestModelFactory.newEmptyAsset();
            when(mockBlueAdlWorkspace.getAssetByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyAsset));
            when(mockRedAdlWorkspace.getAssetByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyAsset));
            service.getAssets(mockContext, "testGuid");
            fail("Should have thrown an exception");
        } catch (IllegalArgumentException e) {
            assertEquals("There is no Asset with the guid testGuid.", e.getMessage());
        }
    }

    @Test
    public void testGetPortfoliosOk() {
        final Portfolio validPortfolio = TestModelFactory.newValidPortfolio();
        final Portfolio emptyPortfolio = TestModelFactory.newEmptyPortfolio();
        when(mockBlueAdlWorkspace.getPortfolioByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(validPortfolio));
        when(mockRedAdlWorkspace.getPortfolioByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyPortfolio));
        final List<Portfolio> result = service.getPortfolios(mockContext, "testGuid");
        assertEquals(Lists.newArrayList(validPortfolio), result);
    }

    @Test
    public void testGetPortfoliosEmptyException() {
        try {
            final Portfolio emptyPortfolio = TestModelFactory.newEmptyPortfolio();
            when(mockBlueAdlWorkspace.getPortfolioByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyPortfolio));
            when(mockRedAdlWorkspace.getPortfolioByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyPortfolio));
            service.getPortfolios(mockContext, "testGuid");
            fail("Should have thrown an exception");
        } catch (IllegalArgumentException e) {
            assertEquals("There is no Portfolio with the guid testGuid.", e.getMessage());
        }
    }

    @Test
    public void testGetPositionsOk() {
        final Position validPosition = TestModelFactory.newValidPosition();
        final Position emptyPosition = TestModelFactory.newEmptyPosition();
        when(mockBlueAdlWorkspace.getPositionByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(validPosition));
        when(mockRedAdlWorkspace.getPositionByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyPosition));
        final List<Position> result = service.getPositions(mockContext, "testGuid");
        assertEquals(Lists.newArrayList(validPosition), result);
    }

    @Test
    public void testGetPositionsEmptyException() {
        try {
            final Position emptyPosition = TestModelFactory.newEmptyPosition();
            when(mockBlueAdlWorkspace.getPositionByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyPosition));
            when(mockRedAdlWorkspace.getPositionByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyPosition));
            service.getPositions(mockContext, "testGuid");
            fail("Should have thrown an exception");
        } catch (IllegalArgumentException e) {
            assertEquals("There is no Position with the guid testGuid.", e.getMessage());
        }
    }

    @Test
    public void testGetPerformancesOk() {
        final Performance validPerformance = TestModelFactory.newValidPerformance();
        final Performance emptyPerformance = TestModelFactory.newEmptyPerformance();
        when(mockBlueAdlWorkspace.getPerformanceByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(validPerformance));
        when(mockRedAdlWorkspace.getPerformanceByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyPerformance));
        final List<Performance> result = service.getPerformances(mockContext, "testGuid");
        assertEquals(Lists.newArrayList(validPerformance), result);
    }

    @Test
    public void testGetPerformancesEmptyException() {
        try {
            final Performance emptyPerformance = TestModelFactory.newEmptyPerformance();
            when(mockBlueAdlWorkspace.getPerformanceByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyPerformance));
            when(mockRedAdlWorkspace.getPerformanceByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyPerformance));
            service.getPerformances(mockContext, "testGuid");
            fail("Should have thrown an exception");
        } catch (IllegalArgumentException e) {
            assertEquals("There is no Performance with the guid testGuid.", e.getMessage());
        }
    }

    @Test
    public void testGetFundamentalsOk() {
        final Fundamentals validFundamentals = TestModelFactory.newValidFundamentals();
        final Fundamentals emptyFundamentals = TestModelFactory.newEmptyFundamentals();
        when(mockBlueAdlWorkspace.getFundamentalsByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(validFundamentals));
        when(mockRedAdlWorkspace.getFundamentalsByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyFundamentals));
        final List<Fundamentals> result = service.getFundamentals(mockContext, "testGuid");
        assertEquals(Lists.newArrayList(validFundamentals), result);
    }

    @Test
    public void testGetFundamentalsEmptyException() {
        try {
            final Fundamentals emptyFundamentals = TestModelFactory.newEmptyFundamentals();
            when(mockBlueAdlWorkspace.getFundamentalsByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyFundamentals));
            when(mockRedAdlWorkspace.getFundamentalsByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyFundamentals));
            service.getFundamentals(mockContext, "testGuid");
            fail("Should have thrown an exception");
        } catch (IllegalArgumentException e) {
            assertEquals("There is no Fundamentals with the guid testGuid.", e.getMessage());
        }
    }

    @Test
    public void testGetUsersOk() {
        final User validUser = TestModelFactory.newValidUser();
        final User emptyUser = TestModelFactory.newEmptyUser();
        when(mockBlueAdlWorkspace.getUserByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(validUser));
        when(mockRedAdlWorkspace.getUserByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyUser));
        final List<User> result = service.getUsers(mockContext, "testGuid");
        assertEquals(Lists.newArrayList(validUser), result);
    }

    @Test
    public void testGetUsersEmptyException() {
        try {
            final User emptyUser = TestModelFactory.newEmptyUser();
            when(mockBlueAdlWorkspace.getUserByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyUser));
            when(mockRedAdlWorkspace.getUserByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyUser));
            service.getUsers(mockContext, "testGuid");
            fail("Should have thrown an exception");
        } catch (IllegalArgumentException e) {
            assertEquals("There is no User with the guid testGuid.", e.getMessage());
        }
    }

    @Test
    public void testGetContactsOk() {
        final Contact validContact = TestModelFactory.newValidContact();
        final Contact emptyContact = TestModelFactory.newEmptyContact();
        when(mockBlueAdlWorkspace.getContactByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(validContact));
        when(mockRedAdlWorkspace.getContactByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyContact));
        final List<Contact> result = service.getContacts(mockContext, "testGuid");
        assertEquals(Lists.newArrayList(validContact), result);
    }

    @Test
    public void testGetContactsEmptyException() {
        try {
            final Contact emptyContact = TestModelFactory.newEmptyContact();
            when(mockBlueAdlWorkspace.getContactByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyContact));
            when(mockRedAdlWorkspace.getContactByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyContact));
            service.getContacts(mockContext, "testGuid");
            fail("Should have thrown an exception");
        } catch (IllegalArgumentException e) {
            assertEquals("There is no Contact with the guid testGuid.", e.getMessage());
        }
    }

    @Test
    public void testGetCompaniesOk() {
        final Company validCompany = TestModelFactory.newValidCompany();
        final Company emptyCompany = TestModelFactory.newEmptyCompany();
        when(mockBlueAdlWorkspace.getCompanyByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(validCompany));
        when(mockRedAdlWorkspace.getCompanyByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyCompany));
        final List<Company> result = service.getCompanies(mockContext, "testGuid");
        assertEquals(Lists.newArrayList(validCompany), result);
    }

    @Test
    public void testGetCompaniesEmptyException() {
        try {
            final Company emptyCompany = TestModelFactory.newEmptyCompany();
            when(mockBlueAdlWorkspace.getCompanyByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyCompany));
            when(mockRedAdlWorkspace.getCompanyByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyCompany));
            service.getCompanies(mockContext, "testGuid");
            fail("Should have thrown an exception");
        } catch (IllegalArgumentException e) {
            assertEquals("There is no Company with the guid testGuid.", e.getMessage());
        }
    }

    @Test
    public void testGetInvestorsOk() {
        final Investor validInvestor = TestModelFactory.newValidInvestor();
        final Investor emptyInvestor = TestModelFactory.newEmptyInvestor();
        when(mockBlueAdlWorkspace.getInvestorByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(validInvestor));
        when(mockRedAdlWorkspace.getInvestorByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyInvestor));
        final List<Investor> result = service.getInvestors(mockContext, "testGuid");
        assertEquals(Lists.newArrayList(validInvestor), result);
    }

    @Test
    public void testGetInvestorsEmptyException() {
        try {
            final Investor emptyInvestor = TestModelFactory.newEmptyInvestor();
            when(mockBlueAdlWorkspace.getInvestorByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyInvestor));
            when(mockRedAdlWorkspace.getInvestorByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyInvestor));
            service.getInvestors(mockContext, "testGuid");
            fail("Should have thrown an exception");
        } catch (IllegalArgumentException e) {
            assertEquals("There is no Investor with the guid testGuid.", e.getMessage());
        }
    }

    @Test
    void testGetTransactionsOk() {
        final Transaction validTransaction = TestModelFactory.newValidTransaction();
        final Transaction emptyTransaction = TestModelFactory.newEmptyTransaction();
        when(mockBlueAdlWorkspace.getTransactionByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(validTransaction));
        when(mockRedAdlWorkspace.getTransactionByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyTransaction));
        final List<Transaction> result = service.getTransactions(mockContext, "testGuid");
        assertEquals(Lists.newArrayList(validTransaction), result);
    }

    @Test
    void testGetTransactionEmptyException() {
        final Transaction emptyTransaction = TestModelFactory.newEmptyTransaction();
        when(mockBlueAdlWorkspace.getTransactionByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyTransaction));
        when(mockRedAdlWorkspace.getTransactionByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyTransaction));
        Exception exception = assertThrows(IllegalArgumentException.class,() -> service.getTransactions(mockContext,"testGuid"));
        assertEquals("There is no Transaction with the guid testGuid.",exception.getMessage());
    }

    @Test
    void testGetInvestorAccountsOk() {
        final InvestorAccount validInvestorAccount = TestModelFactory.newValidInvestorAccount();
        final InvestorAccount emptyInvestorAccount = TestModelFactory.newEmptyInvestorAccount();
        when(mockBlueAdlWorkspace.getInvestorAccountByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(validInvestorAccount));
        when(mockRedAdlWorkspace.getInvestorAccountByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyInvestorAccount));
        final List<InvestorAccount> result = service.getInvestorAccounts(mockContext, "testGuid");
        assertEquals(Lists.newArrayList(validInvestorAccount), result);
    }

    @Test
    void testGetInvestorAccountEmptyException() {
        final InvestorAccount emptyInvestorAccount = TestModelFactory.newEmptyInvestorAccount();
        when(mockBlueAdlWorkspace.getInvestorAccountByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyInvestorAccount));
        when(mockRedAdlWorkspace.getInvestorAccountByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyInvestorAccount));
        Exception exception = assertThrows(IllegalArgumentException.class,() -> service.getInvestorAccounts(mockContext,"testGuid"));
        assertEquals("There is no InvestorAccount with the guid testGuid.",exception.getMessage());
    }

    @Test
    void testGetInstrumentOk() {
        final Instrument validInstrument = TestModelFactory.newValidInstrument();
        final Instrument emptyInstrument = TestModelFactory.newEmptyInstrument();
        when(mockBlueAdlWorkspace.getInstrumentByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(validInstrument));
        when(mockRedAdlWorkspace.getInstrumentByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyInstrument));
        final List<Instrument> result = service.getInstruments(mockContext, "testGuid");
        assertEquals(Lists.newArrayList(validInstrument), result);
    }

    @Test
    void testGetInstrumentEmptyException(){
        final Instrument emptyInstrument = TestModelFactory.newEmptyInstrument();
        when(mockBlueAdlWorkspace.getInstrumentByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyInstrument));
        when(mockRedAdlWorkspace.getInstrumentByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyInstrument));
        Exception exception = assertThrows(IllegalArgumentException.class,() -> service.getInstruments(mockContext,"testGuid"));
        assertEquals("There is no Instrument with the guid testGuid.",exception.getMessage());
    }
    @Test
    void testGetBankAccountOk() {
        final BankAccount validBankAccount = TestModelFactory.newValidBankAccount();
        final BankAccount emptyBankAccount = TestModelFactory.newEmptyBankAccount();
        when(mockBlueAdlWorkspace.getBankAccountByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(validBankAccount));
        when(mockRedAdlWorkspace.getBankAccountByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyBankAccount));
        final List<BankAccount> result = service.getBankAccounts(mockContext, "testGuid");
        assertEquals(Lists.newArrayList(validBankAccount), result);
    }

    @Test
    void testGetBankAccountEmptyException() {
        final BankAccount emptyBankAccount = TestModelFactory.newEmptyBankAccount();
        when(mockBlueAdlWorkspace.getBankAccountByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyBankAccount));
        when(mockRedAdlWorkspace.getBankAccountByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyBankAccount));
        Exception exception = assertThrows(IllegalArgumentException.class,() -> service.getBankAccounts(mockContext,"testGuid"));
        assertEquals("There is no BankAccount with the guid testGuid.",exception.getMessage());
    }

    @Test
    void testGetBankOperationOk(){
        final BankOperation validBankOperation = TestModelFactory.newValidBankOperation();
        final BankOperation emptyBankOperation = TestModelFactory.newEmptyBankOperation();
        when(mockBlueAdlWorkspace.getBankOperationByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(validBankOperation));
        when(mockRedAdlWorkspace.getBankOperationByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyBankOperation));
        final List<BankOperation> result = service.getBankOperations(mockContext,"testGuid");
        assertEquals(Lists.newArrayList(validBankOperation),result);
    }

    @Test
    void testGetBankOperationEmptyException(){
        final BankOperation emptyBankOperation = TestModelFactory.newEmptyBankOperation();
        when(mockBlueAdlWorkspace.getBankOperationByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyBankOperation));
        when(mockRedAdlWorkspace.getBankOperationByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyBankOperation));
        Exception exception = assertThrows(IllegalArgumentException.class,() -> service.getBankOperations(mockContext,"testGuid"));
        assertEquals("There is no BankOperation with the guid testGuid.",exception.getMessage());
    }

    @Test
    void  testGetShareClassOk(){
        final ShareClass validShareClass = TestModelFactory.newValidShareClass();
        final ShareClass emptyShareClass = TestModelFactory.newEmptyShareClass();
        when(mockBlueAdlWorkspace.getShareClassByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(validShareClass));
        when(mockRedAdlWorkspace.getShareClassByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyShareClass));
        final List<ShareClass> result = service.getShareClasses(mockContext,"testGuid");
        assertEquals(Lists.newArrayList(validShareClass),result);
    }

    @Test
    void testGetShareClassEmptyException(){
        final ShareClass emptyShareClass = TestModelFactory.newEmptyShareClass();
        when(mockBlueAdlWorkspace.getShareClassByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyShareClass));
        when(mockRedAdlWorkspace.getShareClassByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyShareClass));
        Exception exception = assertThrows(IllegalArgumentException.class,()-> service.getShareClasses(mockContext,"testGuid"));
        assertEquals("There is no ShareClass with the guid testGuid.",exception.getMessage());
    }

    @Test
    public void testGetValidObjectsFirst() {
        final Asset validAsset = TestModelFactory.newValidAsset();
        final Asset emptyAsset = TestModelFactory.newEmptyAsset();
        when(mockBlueAdlWorkspace.getAssetByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(validAsset));
        when(mockRedAdlWorkspace.getAssetByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyAsset));
        final List<Asset> assetList = Lists.newArrayList(validAsset);

        assertEquals(Optional.of(assetList), service.getValidObjects(PmdxADLWorkspace::getAssetByGuid, "testGuid"));
    }

    @Test
    public void testGetValidObjectsSecond() {
        final Asset validAsset = TestModelFactory.newValidAsset();
        final Asset emptyAsset = TestModelFactory.newEmptyAsset();
        when(mockBlueAdlWorkspace.getAssetByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyAsset));
        when(mockRedAdlWorkspace.getAssetByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(validAsset));
        final List<Asset> assetList = Lists.newArrayList(validAsset);

        assertEquals(Optional.of(assetList), service.getValidObjects(PmdxADLWorkspace::getAssetByGuid, "testGuid"));
    }

    @Test
    public void testGetValidObjectsNeither() {
        final Asset emptyAsset1 = TestModelFactory.newEmptyAsset();
        final Asset emptyAsset2 = TestModelFactory.newEmptyAsset();
        when(mockBlueAdlWorkspace.getAssetByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyAsset1));
        when(mockRedAdlWorkspace.getAssetByGuid(anyString())).thenReturn(CompletableFuture.completedFuture(emptyAsset2));

        assertEquals(Optional.empty(), service.getValidObjects(PmdxADLWorkspace::getAssetByGuid, "testGuid"));
    }
}
