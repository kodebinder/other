CRM Batch has three tasks. 
1. Load all entities by their linkage to ALT tickers.
2. Load the entities as provided in the input to the batch.
3. Load all the entities based on the portfolios in the port_group provided in the VM args.__


VM Args:
`
-DdefaultWebServer=https://dev.blackrock.com
-DapplicationName=CRMLoaderBatch
-DAUTH_METHOD=SERVER
-Dbms.port=5000
-Dmode=Blue
-Dspring.profiles.active=CRMLoadEntitiesByPortGroup
-DBRS.PMDX_BASE_DIR_BLUE=C:\BLKDeveloper\code\privatemarketsdataexchange\java\version\backend\libs\privatemarkets-datadictionary\src\main\resources\schema-dir\
-DoverrideDXTransformerSourceId=58777
-Dportgroup=CRM-PMDX`
-Dspring.config.location=file:C:/schema_files/PrivateMarketsCRMBatch.properties