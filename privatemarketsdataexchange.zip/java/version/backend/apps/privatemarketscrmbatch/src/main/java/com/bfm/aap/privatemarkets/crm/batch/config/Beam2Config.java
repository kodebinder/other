package com.bfm.aap.privatemarkets.crm.batch.config;

import java.util.Collections;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bfm.aap.pmdx.loader.service.PrivateMarketsCRMLoaderService;
import com.bfm.aap.pmdx.model.util.LibRedBlueProxy;
import com.bfm.aap.pmdx.redblue.PmdxServiceType;
import com.bfm.aap.privatemarkets.common.constant.CommonConstants;
import com.bfm.beam2.Configs;
import com.bfm.beam2.ServiceProxyFactories;
import com.bfm.beam2.ServiceProxyFactory;
import com.bfm.privatemarkets.beam2.util.Proto3JsonConverter;

@Configuration
public class Beam2Config {

    private static final String DX_CRM_LOADER_CLIENT = "PrivateMarketsCRMLoader_client";

    @Bean(name = "privateMarketsCRMLoaderService")
    public PrivateMarketsCRMLoaderService getPrivateMarketsCRMLoaderServiceClient() {
        int sourceId = LibRedBlueProxy.getSourceIdByTypeAndColor(PmdxServiceType.PRIVATEMARKETS_CRM_LOADER, CommonConstants.NETWORK_MODE);
        if (System.getProperty(CommonConstants.DX_CRM_LOADER_SOURCE_ID_OVERRIDE) != null) {
            sourceId = Integer.parseInt(System.getProperty(CommonConstants.DX_CRM_LOADER_SOURCE_ID_OVERRIDE));
        }
        ServiceProxyFactories.SPFConfig config = new ServiceProxyFactories.SPFConfig().setAppName(DX_CRM_LOADER_CLIENT);
        config.setBrElemConverterFactories(Collections.singletonList(Proto3JsonConverter.factory()));
        ServiceProxyFactory factory = ServiceProxyFactories.bmsServiceProxyFactory(config);
        return factory.getServiceProxy(PrivateMarketsCRMLoaderService.class, Configs.builder().setSourceId(sourceId).build());
    }
}
