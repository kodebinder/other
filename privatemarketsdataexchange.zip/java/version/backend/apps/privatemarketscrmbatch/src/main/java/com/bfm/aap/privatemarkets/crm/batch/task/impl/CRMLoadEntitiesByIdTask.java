package com.bfm.aap.privatemarkets.crm.batch.task.impl;

import com.bfm.aap.privatemarkets.crm.batch.service.CRMLoaderProcess;
import com.bfm.aap.privatemarkets.crm.batch.task.BatchTask;
import com.google.common.primitives.Ints;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;


public class CRMLoadEntitiesByIdTask implements BatchTask {

    @Autowired
    private CRMLoaderProcess loaderProcess;

    @Override
    public boolean runTask() {
        String entityIdString = System.getProperty("entityId");
        if (StringUtils.isNotBlank(entityIdString)) {
            return loaderProcess.loadEntityByEntityId(Ints.asList(Arrays.stream(entityIdString.split(","))
                    .mapToInt(Integer::parseInt).toArray()));
        }
        return false;
    }
}
