package com.bfm.aap.privatemarkets.crm.batch.service.impl;


import com.bfm.aap.privatemarkets.crm.batch.service.PortGroupService;
import com.bfm.portgroup.api.beam2.PortGroupAPIService;
import com.bfm.portgroup.api.beam2.PortGroupJsonMapper;
import com.bfm.portgroup.api.rest.PortGroupNode;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class PortGroupServiceImpl implements PortGroupService {

    @Autowired
    private PortGroupAPIService portGroupAPIService;

    @Autowired
    private PortGroupJsonMapper portGroupJsonMapper;

    @Override
    public List<Integer> getPortGroupData(String portGroup) throws IOException {
        String json = this.portGroupAPIService.getPortGroupData(portGroup);
        List<PortGroupNode> portGroupNodes = this.portGroupJsonMapper.mapJsonToPortGroupNodeList(json);

        return portGroupNodes.stream()
                .filter(portGroupNode -> CollectionUtils.isEmpty(portGroupNode.getChildrenArray()))
                .map(PortGroupNode::getPortfolioCode).collect(Collectors.toList());
    }

}