package com.bfm.aap.privatemarkets.crm.batch.task;

public interface BatchTask {
    boolean runTask();
}