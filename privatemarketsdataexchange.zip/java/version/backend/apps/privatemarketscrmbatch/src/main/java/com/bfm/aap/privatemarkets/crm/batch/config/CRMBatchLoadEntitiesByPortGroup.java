package com.bfm.aap.privatemarkets.crm.batch.config;

import com.bfm.aap.privatemarkets.crm.batch.task.BatchTask;
import com.bfm.aap.privatemarkets.crm.batch.task.impl.CRMLoadEntitiesByPortGroup;
import com.bfm.beam2.Configs;
import com.bfm.beam2.ServiceProxyFactories;
import com.bfm.beam2.ServiceProxyFactory;
import com.bfm.portgroup.api.beam2.PortGroupAPIService;
import com.bfm.portgroup.api.beam2.PortGroupJsonMapper;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import java.util.concurrent.TimeUnit;

import static com.bfm.aap.privatemarkets.common.constant.CommonConstants.PROFILE_CRM_BATCH_LOAD_BY_PORTGROUP;

@Configuration
@Profile(PROFILE_CRM_BATCH_LOAD_BY_PORTGROUP)
public class CRMBatchLoadEntitiesByPortGroup {

    @Bean
    BatchTask getBatchTask() {
        return new CRMLoadEntitiesByPortGroup();
    }

    @Bean
    public ServiceProxyFactory proxyFactory() {
        return ServiceProxyFactories.bmsServiceProxyFactory(System.getProperty("applicationName"));
    }

    @Bean
    public PortGroupAPIService portGroupAPIService() {
        return proxyFactory().getServiceProxy(PortGroupAPIService.class,
                Configs.builder().setTimeout(20, TimeUnit.SECONDS).build());
    }

    @Bean
    public ObjectMapper jsonMapper() {
        return new ObjectMapper();
    }

    @Bean
    public PortGroupJsonMapper portGroupJsonMapper() {
        return new PortGroupJsonMapper();
    }
}
