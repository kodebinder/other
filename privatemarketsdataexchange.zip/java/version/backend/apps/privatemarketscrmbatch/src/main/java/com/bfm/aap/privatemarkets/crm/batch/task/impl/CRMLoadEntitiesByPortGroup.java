package com.bfm.aap.privatemarkets.crm.batch.task.impl;

import com.bfm.aap.privatemarkets.crm.batch.service.CRMLoaderProcess;
import com.bfm.aap.privatemarkets.crm.batch.task.BatchTask;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class CRMLoadEntitiesByPortGroup implements BatchTask {
    private static final Logger LOGGER = LoggerFactory.getLogger(CRMLoadEntitiesByPortGroup.class);

    @Autowired
    private CRMLoaderProcess loaderProcess;

    @Override
    public boolean runTask() {
        String portgroup = System.getProperty("portgroup");
        if (StringUtils.isNotBlank(portgroup)) {
            return loaderProcess.loadEntityByPortgroup(portgroup);
        }
        return false;
    }
}
