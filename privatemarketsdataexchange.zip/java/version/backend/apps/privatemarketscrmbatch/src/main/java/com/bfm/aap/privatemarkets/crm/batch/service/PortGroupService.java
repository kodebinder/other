package com.bfm.aap.privatemarkets.crm.batch.service;

import java.io.IOException;
import java.util.List;

public interface PortGroupService {
    List<Integer> getPortGroupData(String portGroup) throws IOException;
}
