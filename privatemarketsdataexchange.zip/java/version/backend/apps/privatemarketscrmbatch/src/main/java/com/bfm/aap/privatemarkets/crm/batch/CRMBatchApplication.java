package com.bfm.aap.privatemarkets.crm.batch;

import com.bfm.aap.privatemarkets.crm.batch.task.BatchTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.kafka.KafkaAutoConfiguration;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;


@SpringBootApplication(exclude = {KafkaAutoConfiguration.class})
@ComponentScan(basePackages = {"com.bfm.aap.privatemarkets.crm.batch", "com.bfm.aap.privatemarkets.dao.crm", "com.bfm.aap.privatemarkets.dao.config",
        "com.bfm.aap.privatemarkets.crm.thirdparty",
        "com.bfm.aap.privatemarkets.crm.loader.service"})
@PropertySource(name = "properties", value = "${spring.config.location}")
public class CRMBatchApplication implements CommandLineRunner {

    private static final Logger LOGGER = LoggerFactory.getLogger(CRMBatchApplication.class);
    private final BatchTask batchTask;
    private final ConfigurableApplicationContext context;

    @Autowired
    public CRMBatchApplication(final BatchTask batchTask, final ConfigurableApplicationContext context) {
        this.batchTask = batchTask;
        this.context = context;
    }

    public static void main(String[] args) {
        SpringApplication.run(CRMBatchApplication.class, args);
    }

    @Override
    public void run(String... args) {
        try {
            batchTask.runTask();
        } catch (Exception ex) {
            LOGGER.error("Error while running {}", batchTask.getClass().getSimpleName(), ex);
        }
        System.exit(SpringApplication.exit(context));
    }
}
