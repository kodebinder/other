package com.bfm.aap.privatemarkets.crm.batch.config;

import com.bfm.aap.privatemarkets.crm.batch.task.BatchTask;
import com.bfm.aap.privatemarkets.crm.batch.task.impl.CRMLoadEntitiesByIdTask;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import static com.bfm.aap.privatemarkets.common.constant.CommonConstants.PROFILE_CRM_BATCH_LOAD_BY_ID;

@Configuration
@Profile(PROFILE_CRM_BATCH_LOAD_BY_ID)
public class CRMBatchLoadEntitiesByIdTask {
    @Bean
    BatchTask getBatchTask() {
        return new CRMLoadEntitiesByIdTask();
    }
}
