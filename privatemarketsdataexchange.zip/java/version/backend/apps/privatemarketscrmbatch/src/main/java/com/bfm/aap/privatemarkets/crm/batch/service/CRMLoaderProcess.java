package com.bfm.aap.privatemarkets.crm.batch.service;

import java.util.List;

public interface CRMLoaderProcess {
    boolean loadEntityByEntityId(List<Integer> entityIds);

    boolean loadAllEntities();

    boolean loadEntityByPortgroup(String portgroup);
}

