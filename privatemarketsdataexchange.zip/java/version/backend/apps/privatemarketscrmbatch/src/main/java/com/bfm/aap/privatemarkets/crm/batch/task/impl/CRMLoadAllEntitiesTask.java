package com.bfm.aap.privatemarkets.crm.batch.task.impl;

import com.bfm.aap.privatemarkets.crm.batch.service.CRMLoaderProcess;
import com.bfm.aap.privatemarkets.crm.batch.task.BatchTask;
import org.springframework.beans.factory.annotation.Autowired;


public class CRMLoadAllEntitiesTask implements BatchTask {

    @Autowired
    private CRMLoaderProcess loaderProcess;

    @Override
    public boolean runTask() {
        return loaderProcess.loadAllEntities();
    }
}
