package com.bfm.aap.privatemarkets.crm.batch.service.impl;

import java.util.Arrays;
import java.util.Collection;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import org.apache.commons.collections.CollectionUtils;
import org.apache.ignite.resources.SpringResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.bfm.aap.pmdx.loader.service.PrivateMarketsCRMLoaderService;
import com.bfm.aap.pmdx.notification.model.BusinessNotificationTypes;
import com.bfm.aap.pmdx.notification.model.EmailParams;
import com.bfm.aap.pmdx.notification.model.NotificationEnums;
import com.bfm.aap.pmdx.notification.model.NotificationParams;
import com.bfm.aap.pmdx.notification.service.Notification;
import com.bfm.aap.privatemarkets.common.constant.CommonConstants;
import com.bfm.aap.privatemarkets.common.crm.model.CRMBatchEntity;
import com.bfm.aap.privatemarkets.common.crm.model.CRMCoreEntityTypes;
import com.bfm.aap.privatemarkets.crm.batch.helper.OrganizationProcessor;
import com.bfm.aap.privatemarkets.crm.batch.service.CRMLoaderProcess;
import com.bfm.aap.privatemarkets.crm.batch.service.PortGroupService;
import com.bfm.aap.privatemarkets.crm.loader.service.CRMLoaderCoreService;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.aap.privatemarkets.dao.crm.CRMBatchDao;
import com.bfm.aap.privatemarkets.dao.model.AltInvestorEntity;
import com.bfm.entitymaster.dto.entityportfolio.ClientDetail;
import com.bfm.entitymaster.dto.entityrelationship.Employment;

@Service
public class CRMLoaderProcessImpl implements CRMLoaderProcess {
    private static final Logger LOGGER = LoggerFactory.getLogger(CRMLoaderProcessImpl.class);

    private final CRMBatchDao crmBatchDao;
    private final PrivateMarketsCRMLoaderService privateMarketsCRMLoaderService;
    private final CRMThirdPartyMapperService thirdPartyMapperService;
    private final CRMLoaderCoreService crmLoaderCoreService;
    private final PortGroupService portGroupService;

    @SpringResource(resourceClass = ObjectMapper.class)
    private ObjectMapper mapper;

    private static final String TSG_OPS = "tsgops";
    private String APPLICATION_NAME_CRMBatch = "CRMBatch";

    @Autowired
    public CRMLoaderProcessImpl(@Qualifier("crmBatchDaoImpl") CRMBatchDao crmBatchDao, PrivateMarketsCRMLoaderService privateMarketsCRMLoaderService,
                                CRMThirdPartyMapperService thirdPartyMapperService, CRMLoaderCoreService crmLoaderCoreService,
                                PortGroupService portGroupService, ObjectMapper mapper) {
        this.crmBatchDao = crmBatchDao;
        this.privateMarketsCRMLoaderService = privateMarketsCRMLoaderService;
        this.thirdPartyMapperService = thirdPartyMapperService;
        this.crmLoaderCoreService = crmLoaderCoreService;
        this.portGroupService = portGroupService;
        this.mapper = mapper;
    }

    @Override
    public boolean loadEntityByEntityId(List<Integer> entityIds) {
        LOGGER.info("loadEntityByEntityId - {}", entityIds);
        return this.processEntity(entityIds);
    }

    @Override
    public boolean loadAllEntities() {
        Optional<List<AltInvestorEntity>> investorEntities = this.crmBatchDao.loadAltInvestorEntityList();
        if (investorEntities.isPresent()) {
            Multimap<Integer, Integer> map = ArrayListMultimap.create();
            investorEntities.ifPresent(list -> list.stream().forEach(e -> map.put(e.getMasterEntityId(), e.getEntityId())));
            Set<Integer> masterEntitySet = investorEntities.get().stream().map(e -> e.getMasterEntityId()).collect(Collectors.toSet());
            return Optional.ofNullable(masterEntitySet)
                    .map(Collection::stream)
                    .orElseGet(Stream::empty)
                    .map(e -> this.loadEntityByEntityId((List<Integer>) map.get(e)))
                    .collect(Collectors.toList()).stream().filter(e -> !e).findAny().isPresent() ? Boolean.FALSE : Boolean.TRUE;
        } else {
            return false;
        }
    }

    @Override
    public boolean loadEntityByPortgroup(String portgroup) {
        try {
            List<Integer> portfolioCodeList = this.portGroupService.getPortGroupData(portgroup);
            if (CollectionUtils.isNotEmpty(portfolioCodeList)) {
                Map<Integer, ClientDetail> investorEntities = this.crmLoaderCoreService.getClientDetailByPortfolioList(portfolioCodeList);
                Map<String, ClientDetail> interimConversionResult = new HashMap<>();
                LOGGER.debug("RESULTS: {}", investorEntities);
                investorEntities
                        .entrySet()
                        .stream()
                        .forEach((kv -> interimConversionResult.put(this.mapper.convertValue(kv.getKey(), String.class), this.mapper.convertValue(kv.getValue(), ClientDetail.class))));
                Multimap<Integer, Integer> masterEntityMap = ArrayListMultimap.create();
                interimConversionResult.entrySet().stream().map(Map.Entry::getValue).collect(Collectors.toList())
                        .forEach(c -> masterEntityMap.put(c.getMasterEntity().getEntityId(), c.getClient().getEntityId()));
                return masterEntityMap.keySet().stream().map(k -> this.loadEntityByEntityId((List<Integer>) masterEntityMap.get(k)))
                        .collect(Collectors.toList()).stream().anyMatch(e -> !e) ? Boolean.FALSE : Boolean.TRUE;
            }
            return false;
        } catch (Exception e) {
            LOGGER.error("Exception in loadEntityByPortgroup", e);
            return false;
        }
    }

    private boolean processEntity(List<Integer> entityIds) {
        LOGGER.info("Started : processEntity - {}", entityIds);
        OrganizationProcessor processor = new OrganizationProcessor(this.crmLoaderCoreService.getEntityHierarchy(entityIds.get(0)), entityIds);
        Deque<CRMBatchEntity> orgStack = processor.buildStack();
        while (!orgStack.isEmpty()) {
            LOGGER.info("Started processing orgStack top {}", orgStack.peek());
            CRMBatchEntity crmEntity = orgStack.pop();
            ThirdPartyMappingEnum orgType = orgStack.isEmpty() ? ThirdPartyMappingEnum.INVESTOR_INVEST : ThirdPartyMappingEnum.COMPANY_INVEST;
            if (!this.isThirdPartyMappingPresent(crmEntity.getEntityId(), orgType)) {
                this.sendCreateRequest(crmEntity);
                this.processLinkedContacts(crmEntity, ThirdPartyMappingEnum.CONTACT_INVEST);
            }
        }
        return true;
    }

    /**
     * Get All employees.
     * Check if TPM exist.
     * Not present then call create contact with linked entity.
     *
     * @param entity
     */
    private void processLinkedContacts(CRMBatchEntity entity, ThirdPartyMappingEnum entityType) {
        List<Employment> employments = this.crmLoaderCoreService.getEmployeesByEntityId(entity.getEntityId(), TSG_OPS);
        if (CollectionUtils.isNotEmpty(employments)) {
            this.sendNotification(CRMCoreEntityTypes.CONTACT.name(),
                this.privateMarketsCRMLoaderService.loadContactsToEfront(
                    employments.stream()
                        .filter(Objects::nonNull)
                        .filter(e -> !this.isThirdPartyMappingPresent(e.getEmployeeEntityId(), entityType))
                        .map(e -> e.getEmployeeEntityId()).collect(Collectors.toList())
                    , TSG_OPS));
        }
    }

    private boolean isThirdPartyMappingPresent(int entityId, ThirdPartyMappingEnum entityType) {
        return Objects.nonNull(this.thirdPartyMapperService.lookupThirdPartMapping(entityId, entityType));
    }

    /**
     * if not present then call create BMS endpoint.
     *
     * @param entity
     */
    private void sendCreateRequest(CRMBatchEntity entity) {
        if (entity.getEntityType().name().equals(CRMCoreEntityTypes.COMPANY.name())) {
            this.sendNotification(CRMCoreEntityTypes.COMPANY.name(),
                this.privateMarketsCRMLoaderService.loadCompaniesToEfront(Arrays.asList(entity.getEntityId()), TSG_OPS));
        } else if (entity.getEntityType().name().equals(CRMCoreEntityTypes.INVESTOR.name())) {
            this.sendNotification(CRMCoreEntityTypes.INVESTOR.name(),
                this.privateMarketsCRMLoaderService.loadInvestorsToEfront(Arrays.asList(entity.getEntityId()), TSG_OPS));
        }
    }

    private void sendNotification(String entityType, List<Integer> failedEntityList) {
        if (CollectionUtils.isNotEmpty(failedEntityList) && failedEntityList.size() > 0) {
            LOGGER.info("CRM Batch processing failed for : {} with {} Ids", entityType, failedEntityList);
            final NotificationParams notificationParams = new NotificationParams.Builder(NotificationEnums.NotificationSeverity.YELLOW,
                this.APPLICATION_NAME_CRMBatch)
                    .setEmailBuilder(new EmailParams.Builder()
                            .setSubject("CRM Batch process failures")
                            .setBusinessNotificationType(BusinessNotificationTypes.CRM)
                            .setException(new RuntimeException("CRM Batch process failed to create: " + entityType + ", EntityCount: " + failedEntityList.size()))
                            .setUserRequest(null)
                            .setMode(CommonConstants.NETWORK_MODE.name()))
                    .build();
            Notification.sendNotification(notificationParams);
        }
    }
}
