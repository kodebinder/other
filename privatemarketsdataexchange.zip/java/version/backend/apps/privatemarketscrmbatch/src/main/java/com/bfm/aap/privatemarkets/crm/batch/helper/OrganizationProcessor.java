package com.bfm.aap.privatemarkets.crm.batch.helper;

import java.util.ArrayDeque;
import java.util.Collection;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.Queue;
import java.util.Set;
import java.util.stream.Stream;

import com.google.common.graph.GraphBuilder;
import com.google.common.graph.MutableGraph;

import com.bfm.aap.privatemarkets.common.crm.model.CRMBatchEntity;
import com.bfm.aap.privatemarkets.common.crm.model.CRMCoreEntityTypes;
import com.bfm.entitymaster.dto.entityhierarchy.EntityHierarchy;

public class OrganizationProcessor {
    private EntityHierarchy entityHierarchy;
    private List<Integer> leafENTITY_ID_LIST;

    public OrganizationProcessor(EntityHierarchy entityHierarchy, List<Integer> leafENTITY_ID_LIST) {
        this.entityHierarchy = entityHierarchy;
        this.leafENTITY_ID_LIST = leafENTITY_ID_LIST;
    }

    public Deque<CRMBatchEntity> buildStack() {
        if (entityHierarchy == null) {
            return null;
        }
        MutableGraph<Integer> entityHierarchyGraph = createGraph(entityHierarchy);
        return createStack(entityHierarchyGraph);
    }

    private Deque<CRMBatchEntity> createStack(MutableGraph<Integer> entityHierarchyGraph) {
        Deque<CRMBatchEntity> entityStack = new ArrayDeque<>();
        leafENTITY_ID_LIST.stream().forEach(e -> entityStack.addAll(populateStack(entityHierarchyGraph, e)));
        return entityStack;
    }

    private Deque<CRMBatchEntity> populateStack(MutableGraph<Integer> entityHierarchyGraph, Integer e) {
        Deque<CRMBatchEntity> entityStack = new ArrayDeque<>();
        Queue<Integer> parentQueue = new LinkedList<>();
        parentQueue.add(e);
        entityStack.push(createBatchEntity(e, CRMCoreEntityTypes.INVESTOR));
        while (!parentQueue.isEmpty()) {
            Integer current = parentQueue.poll();
            Set<Integer> predecessorSet = entityHierarchyGraph.predecessors(current);
            predecessorSet.stream().forEach(p -> entityStack.push(createBatchEntity(p, CRMCoreEntityTypes.COMPANY)));
            parentQueue.addAll(predecessorSet);
        }
        return entityStack;
    }

    /**
     * Generates the entityGraph from the provided EntityHierarchy
     *
     * @param entityHierarchy
     * @return
     */
    private MutableGraph createGraph(EntityHierarchy entityHierarchy) {
        MutableGraph<Integer> entityGraph = GraphBuilder.directed().build();
        Queue<EntityHierarchy> entityHierarchyQueue = new LinkedList<>();
        entityHierarchyQueue.add(entityHierarchy);
        entityGraph.addNode(entityHierarchy.getEntity().getEntityId());
        while (!entityHierarchyQueue.isEmpty()) {
            EntityHierarchy currentEntity = entityHierarchyQueue.poll();
            Optional.ofNullable(currentEntity.getChildEntities())
                    .map(Collection::stream)
                    .orElseGet(Stream::empty).forEach(e -> {
                entityHierarchyQueue.add(e);
                entityGraph.addNode(e.getEntity().getEntityId());
                entityGraph.putEdge(currentEntity.getEntity().getEntityId(), e.getEntity().getEntityId());
            });
        }
        return entityGraph;
    }

    private CRMBatchEntity createBatchEntity(int entityId, CRMCoreEntityTypes entityType) {
        return CRMBatchEntity.newBuilder().setEntityId(entityId).setEntityTypeValue(entityType.getNumber()).build();
    }
}
