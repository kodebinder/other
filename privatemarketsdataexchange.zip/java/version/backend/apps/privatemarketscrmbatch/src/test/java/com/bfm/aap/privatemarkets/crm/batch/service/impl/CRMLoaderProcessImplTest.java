package com.bfm.aap.privatemarkets.crm.batch.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import com.bfm.aap.pmdx.loader.service.PrivateMarketsCRMLoaderService;
import com.bfm.aap.pmdx.notification.model.NotificationParams;
import com.bfm.aap.pmdx.notification.service.Notification;
import com.bfm.aap.privatemarkets.crm.batch.service.PortGroupService;
import com.bfm.aap.privatemarkets.crm.loader.service.CRMLoaderCoreService;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.aap.privatemarkets.dao.crm.CRMBatchDao;
import com.bfm.aap.privatemarkets.dao.model.AltInvestorEntity;
import com.bfm.entitymaster.dto.common.Entity;
import com.bfm.entitymaster.dto.entityhierarchy.EntityHierarchy;
import com.bfm.entitymaster.dto.entityportfolio.ClientDetail;
import com.bfm.entitymaster.dto.entityrelationship.Employment;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.doNothing;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

@RunWith(PowerMockRunner.class)
@PrepareForTest({Notification.class})
public class CRMLoaderProcessImplTest {

    @InjectMocks
    private CRMLoaderProcessImpl crmLoaderProcess;
    @Mock
    private CRMBatchDao crmBatchDao;
    @Mock
    private PrivateMarketsCRMLoaderService privateMarketsCRMLoaderService;
    @Mock
    private CRMThirdPartyMapperService thirdPartyMapperService;
    @Mock
    private CRMLoaderCoreService crmLoaderCoreService;
    @Mock
    private PortGroupService portGroupService;

    @Before
    public void setup() throws Exception {
        mockStatic(Notification.class);
        doNothing().when(Notification.class, "sendNotification", Mockito.any(NotificationParams.class));

        Whitebox.setInternalState(this.crmLoaderProcess, "mapper", new ObjectMapper());
    }

    @Test
    public void loadEntityByEntityId() {
        when(this.thirdPartyMapperService.lookupThirdPartMapping(anyInt(), any(ThirdPartyMappingEnum.class))).thenReturn(null);
        when(this.crmLoaderCoreService.getEntityHierarchy(anyInt())).thenReturn(this.getEntityHierarchy());
        when(this.crmLoaderCoreService.getEmployeesByEntityId(9, "tsgops")).thenReturn(this.getEmployment(Arrays.asList(123, 124)));
        when(this.crmLoaderCoreService.getEmployeesByEntityId(4, "tsgops")).thenReturn(this.getEmployment(Arrays.asList(125, 126)));
        when(this.crmLoaderCoreService.getEmployeesByEntityId(2, "tsgops")).thenReturn(this.getEmployment(Arrays.asList(127, 128)));
        when(this.crmLoaderCoreService.getEmployeesByEntityId(1, "tsgops")).thenReturn(this.getEmployment(Arrays.asList(129, 130)));
        when(this.privateMarketsCRMLoaderService.loadContactsToEfront(any(List.class), anyString())).thenReturn(null);
        when(this.privateMarketsCRMLoaderService.loadCompaniesToEfront(any(List.class), anyString())).thenReturn(null);
        when(this.privateMarketsCRMLoaderService.loadInvestorsToEfront(any(List.class), anyString())).thenReturn(null);
        assertTrue(this.crmLoaderProcess.loadEntityByEntityId(Arrays.asList(9)));
    }

    @Test
    public void loadEntityByEntityId_TransformerFailure() {
        System.setProperty("mode", "Blue");
        when(this.thirdPartyMapperService.lookupThirdPartMapping(anyInt(), any(ThirdPartyMappingEnum.class))).thenReturn(null);
        when(this.crmLoaderCoreService.getEntityHierarchy(anyInt())).thenReturn(this.getEntityHierarchy());
        when(this.crmLoaderCoreService.getEmployeesByEntityId(9, "tsgops")).thenReturn(this.getEmployment(Arrays.asList(123, 124)));
        when(this.crmLoaderCoreService.getEmployeesByEntityId(4, "tsgops")).thenReturn(this.getEmployment(Arrays.asList(125, 126)));
        when(this.crmLoaderCoreService.getEmployeesByEntityId(2, "tsgops")).thenReturn(this.getEmployment(Arrays.asList(127, 128)));
        when(this.crmLoaderCoreService.getEmployeesByEntityId(1, "tsgops")).thenReturn(this.getEmployment(Arrays.asList(129, 130)));
        when(this.privateMarketsCRMLoaderService.loadContactsToEfront(any(List.class), anyString())).thenReturn(Arrays.asList(1, 2));
        when(this.privateMarketsCRMLoaderService.loadCompaniesToEfront(any(List.class), anyString())).thenReturn(Arrays.asList(3, 4));
        when(this.privateMarketsCRMLoaderService.loadInvestorsToEfront(any(List.class), anyString())).thenReturn(Arrays.asList(5, 6));
        assertTrue(this.crmLoaderProcess.loadEntityByEntityId(Arrays.asList(9)));
    }

    @Test
    public void loadAllEntitiesTest() {
        when(this.crmBatchDao.loadAltInvestorEntityList()).thenReturn(this.getInvestorEntities());
        when(this.thirdPartyMapperService.lookupThirdPartMapping(anyInt(), any(ThirdPartyMappingEnum.class))).thenReturn(null);
        when(this.crmLoaderCoreService.getEntityHierarchy(anyInt())).thenReturn(this.getEntityHierarchy());
        when(this.crmLoaderCoreService.getEmployeesByEntityId(9, "tsgops")).thenReturn(this.getEmployment(Arrays.asList(123, 124)));
        when(this.crmLoaderCoreService.getEmployeesByEntityId(4, "tsgops")).thenReturn(this.getEmployment(Arrays.asList(125, 126)));
        when(this.crmLoaderCoreService.getEmployeesByEntityId(2, "tsgops")).thenReturn(this.getEmployment(Arrays.asList(127, 128)));
        when(this.crmLoaderCoreService.getEmployeesByEntityId(1, "tsgops")).thenReturn(this.getEmployment(Arrays.asList(129, 130)));
        when(this.privateMarketsCRMLoaderService.loadContactsToEfront(any(List.class), anyString())).thenReturn(null);
        when(this.privateMarketsCRMLoaderService.loadCompaniesToEfront(any(List.class), anyString())).thenReturn(null);
        when(this.privateMarketsCRMLoaderService.loadInvestorsToEfront(any(List.class), anyString())).thenReturn(null);
        assertTrue(this.crmLoaderProcess.loadAllEntities());
    }

    @Test
    public void loadEntityByPortgroupTest() throws IOException {
        when(this.portGroupService.getPortGroupData(anyString())).thenReturn(Arrays.asList(900));
        when(this.crmLoaderCoreService.getClientDetailByPortfolioList(any(List.class))).thenReturn(this.getClientDataMap(900));

        when(this.thirdPartyMapperService.lookupThirdPartMapping(anyInt(), any(ThirdPartyMappingEnum.class))).thenReturn(null);
        when(this.crmLoaderCoreService.getEntityHierarchy(anyInt())).thenReturn(this.getEntityHierarchy());
        when(this.crmLoaderCoreService.getEmployeesByEntityId(9, "tsgops")).thenReturn(this.getEmployment(Arrays.asList(123, 124)));
        when(this.crmLoaderCoreService.getEmployeesByEntityId(4, "tsgops")).thenReturn(this.getEmployment(Arrays.asList(125, 126)));
        when(this.crmLoaderCoreService.getEmployeesByEntityId(2, "tsgops")).thenReturn(this.getEmployment(Arrays.asList(127, 128)));
        when(this.crmLoaderCoreService.getEmployeesByEntityId(1, "tsgops")).thenReturn(this.getEmployment(Arrays.asList(129, 130)));
        when(this.privateMarketsCRMLoaderService.loadContactsToEfront(any(List.class), anyString())).thenReturn(null);
        when(this.privateMarketsCRMLoaderService.loadCompaniesToEfront(any(List.class), anyString())).thenReturn(null);
        when(this.privateMarketsCRMLoaderService.loadInvestorsToEfront(any(List.class), anyString())).thenReturn(null);
        assertTrue(this.crmLoaderProcess.loadEntityByPortgroup("TEST"));
    }

    @Test
    public void loadEntityByPortgroupTest_NoClientEntity() throws IOException {
        when(this.portGroupService.getPortGroupData(anyString())).thenReturn(null);
        assertTrue(!this.crmLoaderProcess.loadEntityByPortgroup("TEST"));
    }

    @Test
    public void loadEntityByPortgroupTest_Exception() throws IOException {
        when(this.portGroupService.getPortGroupData(anyString())).thenThrow(new RuntimeException("Error in portgroup service"));
        assertTrue(!this.crmLoaderProcess.loadEntityByPortgroup("TEST"));
    }

    private Map getClientDataMap(int i) {
        Map<Integer, ClientDetail> investorEntities = new HashMap<>();
        ClientDetail clientDetail = new ClientDetail();
        clientDetail.setMasterEntity(this.getEntity(1));
        clientDetail.setClient(this.getEntity(9));
        investorEntities.put(1, clientDetail);
        return investorEntities;
    }

    private Entity getEntity(int i) {
        Entity entity = new Entity();
        entity.setEntityId(i);
        return entity;
    }

    private Optional<List<AltInvestorEntity>> getInvestorEntities() {
        AltInvestorEntity e = new AltInvestorEntity(9, 1, "O", "Test Org");
        return Optional.ofNullable(Arrays.asList(e));
    }

    private List<Employment> getEmployment(List<Integer> contactEntityIds) {
        List<Employment> empl = new ArrayList<>();
        contactEntityIds.stream().forEach(id -> empl.add(this.getEmployment(id)));
        return empl;
    }

    Employment getEmployment(int entityId) {
        Employment e = new Employment();
        e.setEmployeeEntityId(entityId);
        return e;
    }

    private EntityHierarchy getEntityHierarchy() {
        com.bfm.entitymaster.dto.entityhierarchy.EntityHierarchy e5 = this.createEntityHierarchy(5, null);
        com.bfm.entitymaster.dto.entityhierarchy.EntityHierarchy e8 = this.createEntityHierarchy(8, null);
        com.bfm.entitymaster.dto.entityhierarchy.EntityHierarchy e9 = this.createEntityHierarchy(9, null);
        com.bfm.entitymaster.dto.entityhierarchy.EntityHierarchy e10 = this.createEntityHierarchy(10, null);
        com.bfm.entitymaster.dto.entityhierarchy.EntityHierarchy e11 = this.createEntityHierarchy(11, null);

        com.bfm.entitymaster.dto.entityhierarchy.EntityHierarchy e4 = this.createEntityHierarchy(4, Arrays.asList(e8, e9));
        com.bfm.entitymaster.dto.entityhierarchy.EntityHierarchy e2 = this.createEntityHierarchy(2, Arrays.asList(e4, e5));
        com.bfm.entitymaster.dto.entityhierarchy.EntityHierarchy e6 = this.createEntityHierarchy(6, Arrays.asList(e10));
        com.bfm.entitymaster.dto.entityhierarchy.EntityHierarchy e7 = this.createEntityHierarchy(7, Arrays.asList(e11));
        com.bfm.entitymaster.dto.entityhierarchy.EntityHierarchy e3 = this.createEntityHierarchy(3, Arrays.asList(e6, e7));
        com.bfm.entitymaster.dto.entityhierarchy.EntityHierarchy e1 = this.createEntityHierarchy(1, Arrays.asList(e2, e3));

        return e1;
    }

    private com.bfm.entitymaster.dto.entityhierarchy.EntityHierarchy createEntityHierarchy(Integer entityId, List<com.bfm.entitymaster.dto.entityhierarchy.EntityHierarchy> hierarchyList) {
        com.bfm.entitymaster.dto.entityhierarchy.EntityHierarchy e = new com.bfm.entitymaster.dto.entityhierarchy.EntityHierarchy();
        Entity entity = new Entity();
        entity.setEntityId(entityId);
        e.setEntity(entity);
        e.setChildEntities(hierarchyList);
        return e;
    }


}
