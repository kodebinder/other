package com.bfm.aap.privatemarkets.crm.batch.task.impl;

import com.bfm.aap.privatemarkets.crm.batch.service.CRMLoaderProcess;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CRMLoadEntitiesByIdTaskTest {

    @InjectMocks
    private CRMLoadEntitiesByIdTask crmLoadEntitiesByIdTask;
    @Mock
    private CRMLoaderProcess loaderProcess;

    @Test
    public void runTaskTest() {
        System.setProperty("entityId", "12311,12312,12313");
        when(loaderProcess.loadEntityByEntityId(any(List.class))).thenReturn(true);
        assertTrue(crmLoadEntitiesByIdTask.runTask());
    }

    @Test
    public void runTaskTest_NoEntity() {
        System.setProperty("entityId", "");
        assertTrue(!crmLoadEntitiesByIdTask.runTask());
    }
}
