package com.bfm.aap.privatemarkets.crm.batch.task.impl;

import com.bfm.aap.privatemarkets.crm.batch.service.CRMLoaderProcess;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CRMLoadEntitiesByPortGroupTest {
    @InjectMocks
    private CRMLoadEntitiesByPortGroup crmLoadEntitiesByPortGroup;
    @Mock
    private CRMLoaderProcess loaderProcess;

    @Test
    public void runTaskTest() {
        System.setProperty("portgroup", "CRM_PORT_GROUP");
        when(loaderProcess.loadEntityByPortgroup(anyString())).thenReturn(true);
        assertTrue(crmLoadEntitiesByPortGroup.runTask());
    }

    @Test
    public void runTaskTest_NoEntity() {
        System.setProperty("portgroup", "");
        assertTrue(!crmLoadEntitiesByPortGroup.runTask());
    }
}
