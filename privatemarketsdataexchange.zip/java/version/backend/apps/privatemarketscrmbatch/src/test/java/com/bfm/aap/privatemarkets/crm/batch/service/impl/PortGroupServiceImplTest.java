package com.bfm.aap.privatemarkets.crm.batch.service.impl;

import com.bfm.portgroup.api.beam2.PortGroupAPIService;
import com.bfm.portgroup.api.beam2.PortGroupJsonMapper;
import com.bfm.portgroup.api.rest.PortGroupNode;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.Silent.class)
public class PortGroupServiceImplTest {

    @InjectMocks
    private PortGroupServiceImpl portGroupService;
    @Mock
    private PortGroupAPIService portGroupAPIService;

    @Mock
    private PortGroupJsonMapper portGroupJsonMapper;

    @Test
    public void getPortGroupDataTest() throws IOException {
        when(portGroupAPIService.getPortGroupData(anyString())).thenReturn("");
        when(portGroupJsonMapper.mapJsonToPortGroupNodeList(anyString())).thenReturn(getPortGrouNodes());
        assertTrue(portGroupService.getPortGroupData("TEST").size()==2);
    }

    @Test
    public void getPortGroupDataTest_Skipping_Nested() throws IOException {
        when(portGroupAPIService.getPortGroupData(anyString())).thenReturn("");
        when(portGroupJsonMapper.mapJsonToPortGroupNodeList(anyString())).thenReturn(getPortGrouNodes_Nested());
        assertTrue(portGroupService.getPortGroupData("TEST").size()==1);
    }

    private List<PortGroupNode> getPortGrouNodes() {
        PortGroupNode portGroupNode = new PortGroupNode();
        portGroupNode.setPortfolioCode(123);
        PortGroupNode portGroupNode2 = new PortGroupNode();
        portGroupNode2.setPortfolioCode(234);
        return Arrays.asList(portGroupNode,portGroupNode2);
    }
    private List<PortGroupNode> getPortGrouNodes_Nested() {
        PortGroupNode portGroupNode = new PortGroupNode();
        portGroupNode.setPortfolioCode(123);
        PortGroupNode portGroupNode2 = new PortGroupNode();
        portGroupNode2.setPortfolioCode(234);
        portGroupNode2.setChildrenArray(Arrays.asList(236,456));
        return Arrays.asList(portGroupNode,portGroupNode2);
    }
}
