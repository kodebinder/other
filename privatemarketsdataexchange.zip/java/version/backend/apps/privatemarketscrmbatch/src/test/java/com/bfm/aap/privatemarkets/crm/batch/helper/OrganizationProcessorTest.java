package com.bfm.aap.privatemarkets.crm.batch.helper;

import com.bfm.aap.privatemarkets.common.crm.model.CRMBatchEntity;
import com.bfm.entitymaster.dto.common.Entity;
import com.bfm.entitymaster.dto.entityhierarchy.EntityHierarchy;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.Deque;
import java.util.List;

import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.Silent.class)
public class OrganizationProcessorTest {

    @Test
    public void buildStack() {
        OrganizationProcessor processor = new OrganizationProcessor(getEntityHierarchy(), Arrays.asList(9, 10, 11));
        Deque<CRMBatchEntity> orgStack = processor.buildStack();
        assertNotNull(orgStack);
        assertTrue(orgStack.size() == 12);
    }

    @Test
    public void buildStack_DataIssue_NoData() {
        OrganizationProcessor processor = new OrganizationProcessor(null, Arrays.asList(9, 10, 11));
        Deque<CRMBatchEntity> orgStack = processor.buildStack();
        assertNull(orgStack);
    }

    private EntityHierarchy getEntityHierarchy() {
        EntityHierarchy e5 = createEntityHierarchy(5, null);
        EntityHierarchy e8 = createEntityHierarchy(8, null);
        EntityHierarchy e9 = createEntityHierarchy(9, null);
        EntityHierarchy e10 = createEntityHierarchy(10, null);
        EntityHierarchy e11 = createEntityHierarchy(11, null);

        EntityHierarchy e4 = createEntityHierarchy(4, Arrays.asList(e8, e9));
        EntityHierarchy e2 = createEntityHierarchy(2, Arrays.asList(e4, e5));
        EntityHierarchy e6 = createEntityHierarchy(6, Arrays.asList(e10));
        EntityHierarchy e7 = createEntityHierarchy(7, Arrays.asList(e11));
        EntityHierarchy e3 = createEntityHierarchy(3, Arrays.asList(e6, e7));
        EntityHierarchy e1 = createEntityHierarchy(1, Arrays.asList(e2, e3));

        return e1;
    }

    private EntityHierarchy createEntityHierarchy(Integer entityId, List<EntityHierarchy> hierarchyList) {
        EntityHierarchy e = new EntityHierarchy();
        Entity entity = new Entity();
        entity.setEntityId(entityId);
        e.setEntity(entity);
        e.setChildEntities(hierarchyList);
        return e;
    }
}

