package com.bfm.aap.privatemarkets.crm.batch.task.impl;

import com.bfm.aap.privatemarkets.crm.batch.service.CRMLoaderProcess;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CRMLoadAllEntitiesTaskTest {
    @InjectMocks
    private CRMLoadAllEntitiesTask crmLoadAllEntitiesTask;

    @Mock
    private CRMLoaderProcess loaderProcess;

    @Test
    public void runTaskTest() {
        when(loaderProcess.loadAllEntities()).thenReturn(true);
        assertTrue(crmLoadAllEntitiesTask.runTask());
    }
}
