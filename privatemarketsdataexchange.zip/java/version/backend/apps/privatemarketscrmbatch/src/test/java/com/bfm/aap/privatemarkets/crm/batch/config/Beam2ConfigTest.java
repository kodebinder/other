package com.bfm.aap.privatemarkets.crm.batch.config;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bfm.aap.pmdx.loader.service.PrivateMarketsCRMLoaderService;
import com.bfm.aap.pmdx.model.util.LibRedBlueProxy;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.redblue.PmdxServiceType;
import com.bfm.beam2.ServiceProxyFactories;
import com.bfm.beam2.ServiceProxyFactory;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ServiceProxyFactories.class, LibRedBlueProxy.class})
public class Beam2ConfigTest {

    @InjectMocks
    private Beam2Config beam2Config;

    @Mock
    private PrivateMarketsCRMLoaderService privateMarketsCRMLoaderService;

    @Mock
    private ServiceProxyFactory serviceProxyFactory;

    @Before
    public void setup() {
        System.setProperty("mode", "Blue");
        mockStatic(ServiceProxyFactories.class);
        mockStatic(LibRedBlueProxy.class);

        when(ServiceProxyFactories.bmsServiceProxyFactory(any(ServiceProxyFactories.SPFConfig.class))).thenReturn(this.serviceProxyFactory);
        when(LibRedBlueProxy.getSourceIdByTypeAndColor(any(PmdxServiceType.class), any(NetworkMode.class))).thenReturn(1234);
        when(this.serviceProxyFactory.getServiceProxy(any(), any())).thenReturn(this.privateMarketsCRMLoaderService);
    }

    @Test
    public void getPrivateMarketsDXTransformerClientTest() {
        assertNotNull(this.beam2Config.getPrivateMarketsCRMLoaderServiceClient());
    }
}