package com.bfm.aap.pmdx.exposurecoordinator.util;

/**
 * @author - Amulya Sindhura Pulijala
 * @date - 3/9/2020-10:54 AM
 */
public class ExposureCoordinatorConstants {


    private ExposureCoordinatorConstants() {
    }

    public static final int MAX_TIME_TO_WAIT = 120;

    public static final int MAX_PMCS_BATCH_SIZE = 12; // 1 calendar year worth of month-end dates

    /*
    Calculation Server Constants
     */
    public static final String PMCS_APP_NAME = "PrivateMarketsCalculationServer";

    /*
    Position Reader Server Constants
     */
    public static final String POS_READER_APP_NAME = "PrivateMarketsPositionReader";

    public static final String INCOMING_FILE_LOCATION = "/proj/publish/alts/pms/incoming/";
    public static final String ARCHIVE_FILE_LOCATION = "/proj/publish/alts/pms/archive/";

    public static final int WAIT_TIME_MULTIPLIER = 3;
}
