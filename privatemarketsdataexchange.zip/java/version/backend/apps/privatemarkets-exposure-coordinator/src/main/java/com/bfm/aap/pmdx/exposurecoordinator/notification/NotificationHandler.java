package com.bfm.aap.pmdx.exposurecoordinator.notification;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.bfm.aap.pmdx.notification.model.EmailParams;
import com.bfm.aap.pmdx.notification.model.NotificationEnums;
import com.bfm.aap.pmdx.notification.model.NotificationParams;
import com.bfm.aap.pmdx.notification.service.Notification;
import com.bfm.util.BFMUtil;
import com.google.common.annotations.VisibleForTesting;

import lombok.extern.slf4j.Slf4j;

/**
 * @author - Rahul Dev Mishra
 * @date - 6/1/2020-3:17 PM
 */
@Service
@Slf4j
public class NotificationHandler {
    private static final String APP_NAME = "Exposure-Coordinator";

    public void handleException(Exception e) {
        log.error(e.getMessage(), e);
        final NotificationParams notificationParams = createNotificationParams(e);
        log.info("sending error notification");
        Notification.sendNotification(notificationParams);
    }

    @VisibleForTesting
    NotificationParams createNotificationParams(Exception e) {
        return new NotificationParams.Builder(
                NotificationEnums.NotificationSeverity.PURPLE, APP_NAME)
                .setEmailBuilder(new EmailParams.Builder()
                        .setSubject(e.getMessage())
                        .setException(e)
                        .setUserName(BFMUtil.getUser()))
                .build();
    }
    
    public void notifySuccess(String subject) {
        final NotificationParams notificationParams = createSuccessNotification(subject);
        log.info("sending success notification");
        Notification.sendNotification(notificationParams);
    }

    private NotificationParams createSuccessNotification(String subject) {
        return new NotificationParams.Builder(
                NotificationEnums.NotificationSeverity.YELLOW, APP_NAME)
                .setEmailBuilder(new EmailParams.Builder()
                        .setSubject(subject)
                        .setUserName(BFMUtil.getUser()))
                .build();
    }

}
