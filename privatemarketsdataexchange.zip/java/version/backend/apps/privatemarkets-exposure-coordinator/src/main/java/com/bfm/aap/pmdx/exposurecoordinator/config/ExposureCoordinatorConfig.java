package com.bfm.aap.pmdx.exposurecoordinator.config;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.freemarker.FreeMarkerAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.bfm.aap.privatemarkets.dao.config.DatabaseConfiguration;

/**
 * @author - Rahul Dev Mishra
 * @date - 5/5/2020-3:48 PM
 */

@Configuration
@PropertySource("classpath:properties/database.properties")
@EnableJpaRepositories(basePackages = {"com.bfm.aap.privatemarkets.dao"})
@ComponentScan({"com.bfm.aap.privatemarkets.dao"})
@Import({DatabaseConfiguration.class})
@EnableAutoConfiguration(exclude = { FreeMarkerAutoConfiguration.class })
public class ExposureCoordinatorConfig {
}
