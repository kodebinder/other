package com.bfm.aap.pmdx.exposurecoordinator.model;

import com.bfm.util.BFMDate;
import lombok.Builder;
import lombok.Data;

/**
 * @author - Rahul Dev Mishra
 * @date - 6/2/2020-10:40 AM
 */

@Data
@Builder
public class PMSFileRequest {
    private BFMDate bfmDate;
    private String fileName;
    private String absoluteFileName;
    private int fileSize;
    private int pmsSleepTime;
    private int priority;
}
