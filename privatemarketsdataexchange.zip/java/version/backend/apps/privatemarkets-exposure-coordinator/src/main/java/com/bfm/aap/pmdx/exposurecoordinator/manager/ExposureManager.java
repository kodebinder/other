package com.bfm.aap.pmdx.exposurecoordinator.manager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bfm.aap.pmdx.exposurecoordinator.calculationserver.service.CalculationServerService;
import com.bfm.aap.pmdx.exposurecoordinator.model.PMSFileRequest;
import com.bfm.aap.pmdx.exposurecoordinator.model.RerunRequest;
import com.bfm.aap.pmdx.exposurecoordinator.notification.NotificationHandler;
import com.bfm.aap.pmdx.exposurecoordinator.pms.service.PmsService;
import com.bfm.aap.pmdx.exposurecoordinator.pms.service.writer.PMSFileGenerator;
import com.bfm.aap.pmdx.exposurecoordinator.positionreader.service.PositionReaderService;
import com.bfm.aap.pmdx.exposurecoordinator.price.PriceLoadService;
import com.bfm.aap.pmdx.exposurecoordinator.rollforwardpositions.RollForwardPositionService;
import com.bfm.aap.pmdx.exposurecoordinator.util.DateUtil;
import com.bfm.aap.pmdx.model.Position;
import com.bfm.aap.pmdx.model.PositionReaderResponse;
import com.bfm.util.BFMDate;
import com.bfm.util.HolidayCalendar;
import com.google.common.annotations.VisibleForTesting;

import lombok.extern.slf4j.Slf4j;

/**
 * @author - Rahul Dev Mishra
 * @date - 2/20/2020-1:26 PM
 */

@Service
@Slf4j
public class ExposureManager {

	private static final String SKIP_PMCS = "skipPMCS";
	private static final String SKIP_PRICE_LOAD = "skipPriceLoad";
	private static final String SKIP_PMS_FOR_BACK_DATES = "skipPMS";
	private static final String SKIP_PMS_FOR_TODAY = "skipPMSPortGroup";

	@Autowired
	private PositionReaderService positionReaderService;

	@Autowired
	private CalculationServerService calculationServerService;

	@Autowired
	private PmsService pmsService;

	@Autowired
	private RollForwardPositionService rollForwardPositionService;

	@Autowired
	private PMSFileGenerator pmsFileGenerator;

	@Autowired
	private NotificationHandler exceptionHandler;

	@Autowired
	private PriceLoadService priceLoader;

	public void execute() {
		CompletableFuture<?> result = null;
		if (!skipPriceLoad()) {
			result = CompletableFuture.runAsync(() -> priceLoader.loadPrice(), Executors.newFixedThreadPool(1));
		}
		executeAllForToday();
		executeAllForBackDates();
		if (Objects.nonNull(result)) {
			try {
				result.get();
			} catch (InterruptedException | ExecutionException e) {
				log.error("Price Load thread interrupted", e);
				Thread.currentThread().interrupt();
			}
		}
	}

	/**
	 * Calls Position Reader to get backdated information.
	 */
	private List<Position> executePositionReader() {
		String today = getTodaysDate();
		String portGroup = System.getProperty("portGroup");
		PositionReaderResponse backDatedPositions = positionReaderService.fetchPositions(portGroup, today);
		List<Position> positionList = backDatedPositions.getPositionList();
		log.info("Found {} back dated positions for portGroup: {} and date: {}", positionList.size(), portGroup, today);
		return positionList;
	}

	/**
	 * Execute all the things for T Date 1) Calls PMCS with Port Group and T Date 2)
	 * Calls PMS command for Port Group and T Date
	 */
	private void executeAllForToday() {
		String portGroup = System.getProperty("portGroup");
		String tDate = getTodaysDate();
		log.info("Executing for today's date - portGroup: {}, date: {}", portGroup, tDate);
		rollForwardPositions(portGroup, tDate);
		if (!shouldSkipPMCS()) {
			try {
				log.info("Calling PMCS with the following arguments - PortGroup: {}, Today's Date: {}", portGroup,
						tDate);
				calculationServerService.sendDataToPMCSForCalculationsForPortGroup(portGroup, tDate);
			} catch (Exception e) {
				log.error("Error while executing PMCS: {}", e.getMessage());
			}
		}

		if (!shouldSkipPMSForToday()) {
			pmsService.runPMSCommandForPortGroup(portGroup, tDate);
		} else {
			log.info("Running in SkipPMSPortGroup mode. Skipping call to PMS at portgroup level");
		}
	}

	/**
	 * Execute all the things for Back Dates 1) Gets BackDated Position Information
	 * 2) Calculate the last business day of the months required for rerun 3) Call
	 * PMCS with Portfolio and Back Date(s) 4) Calls PMS command for Portfolio and
	 * Back Date(s)
	 */
	private void executeAllForBackDates() {
		List<Position> positions = executePositionReader();
		HolidayCalendar holidayCalendar = DateUtil.getHolidayCalendar(System.getProperty("holidayCalendar"));
		String endDate = getTodaysDate();
		positions.forEach(position -> executePMCSForBackDates(holidayCalendar, endDate, position));
		try {
			executePMSForBackDates(positions);
		} catch (Exception e) {
			exceptionHandler.handleException(e);
		}
	}

	private void executePMCSForBackDates(HolidayCalendar holidayCalendar, String endDate, Position position) {
		String posDate = DateUtil.convertProtoTimeStampToString(position.getLastReferenceDate());
		try {
			List<String> monthEndDates = DateUtil.calculateMonthEndDates(posDate, endDate, holidayCalendar);
			log.info(
					"Executing for back dates - Month end dates for the posDate {}, endDate {} and holidayCalendar {}: [{}]",
					posDate, endDate, holidayCalendar, monthEndDates);
			monthEndDates.forEach(monthEndDate -> rollForwardPositions(position.getPortfolioName(), monthEndDate));
			if (!shouldSkipPMCS()) {
				log.info(
						"Calling PMCS with the following arguments - Portfolio Name: {}, Cusip: {}, Month End Dates: {}",
						position.getPortfolioName(), position.getCusip(), monthEndDates);
				calculationServerService.sendDataToPMCSForCalculationsForPortfolio(position.getPortfolioName(),
						position.getCusip(), monthEndDates);
			}
		} catch (Exception e) {
			exceptionHandler.handleException(e);
		}
	}

	private void rollForwardPositions(String portfolioName, String date) {
		try {
			rollForwardPositionService.rollForwardPosExtension(portfolioName, date);
		} catch (Exception e) {
			exceptionHandler.handleException(e);
			throw e;
		}
	}

	/**
	 * Get T Date from vm args
	 */

	private void executePMSForBackDates(List<Position> positions) {
		if (shouldSkipPMSForBackDates()) {
			log.info("Skipping PMS as the flag is set to true.");
			return;
		}

		Set<RerunRequest> rerunRequests = positions.stream()
				.map(position -> RerunRequest.builder().portfolioName(position.getPortfolioName())
						.portfolioCusip(position.getCusip()).posDate(position.getLastReferenceDate()).build())
				.collect(Collectors.toSet());
		Map<BFMDate, List<RerunRequest>> monthEndDateMap = mapPositionsToMonthEndDates(rerunRequests);
		List<PMSFileRequest> pmsFileRequests = pmsFileGenerator.generateFile(monthEndDateMap);
		pmsFileRequests.forEach(pmsFileRequest -> {
			try {
				pmsService.runPMSCommandForFile(pmsFileRequest);
			} catch (Exception e) {
				exceptionHandler.handleException(e);
			}
		});
	}

	private Map<BFMDate, List<RerunRequest>> mapPositionsToMonthEndDates(Set<RerunRequest> rerunRequests) {
		HolidayCalendar holidayCalendar = DateUtil.getHolidayCalendar(System.getProperty("holidayCalendar"));
		String endDate = getTodaysDate();
		Map<BFMDate, List<RerunRequest>> monthEndDateMap = new TreeMap<>(Collections.reverseOrder(BFMDate::compareTo));

		for (RerunRequest rerunRequest : rerunRequests) {
			String posDate = DateUtil.convertProtoTimeStampToString(rerunRequest.getPosDate());
			try {
				List<BFMDate> monthEndDates = DateUtil.calculateMonthEndDates(posDate, endDate, holidayCalendar)
						.stream().map(BFMDate::new).collect(Collectors.toList());

				for (BFMDate date : monthEndDates) {
					monthEndDateMap.putIfAbsent(date, new ArrayList<>());
					monthEndDateMap.get(date).add(rerunRequest);
				}
			} catch (Exception ex) {
				log.error(
						"Error encountered fetching monthEnd Dates. "
								+ "RerunRequest :[{}], HolidayCalendar: [{}], endDate: [{}]. ERROR: [{}] ",
						rerunRequest, holidayCalendar, endDate, ex.getMessage());
			}
		}
		return monthEndDateMap;
	}

	private String getTodaysDate() {
		return System.getProperty("tDate");
	}

	@VisibleForTesting
	boolean shouldSkipPMCS() {
		String value = System.getProperty(SKIP_PMCS);
		if (StringUtils.isEmpty(value)) {
			return false;
		}
		return Boolean.parseBoolean(value);
	}

	@VisibleForTesting
	boolean shouldSkipPMSForBackDates() {
		String value = System.getProperty(SKIP_PMS_FOR_BACK_DATES);
		if (StringUtils.isEmpty(value)) {
			return false;
		}
		return Boolean.parseBoolean(value);
	}

	@VisibleForTesting
	boolean shouldSkipPMSForToday() {
		String value = System.getProperty(SKIP_PMS_FOR_TODAY);
		if (StringUtils.isEmpty(value)) {
			return false;
		}
		return Boolean.parseBoolean(value);
	}

	@VisibleForTesting
	boolean skipPriceLoad() {
		String value = System.getProperty(SKIP_PRICE_LOAD);
		if (StringUtils.isEmpty(value)) { // default is false.
			return false;
		}
		return Boolean.parseBoolean(value);
	}

}
