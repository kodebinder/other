package com.bfm.aap.pmdx.exposurecoordinator;

import com.bfm.aap.pmdx.exposurecoordinator.manager.ExposureManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

/**
 * @author - Rahul Dev Mishra
 * @date - 2/14/2020-12:14 PM
 */

@SpringBootApplication
@Slf4j
public class ExposureCoordinator {

	public static void main(String[] args) {
		ConfigurableApplicationContext applicationContext = SpringApplication.run(ExposureCoordinator.class, args);
		log.info("Starting Exposure Coordinator...");
		ExposureManager exposureManager = applicationContext.getBean(ExposureManager.class);
		try {
			exposureManager.execute();
			log.info("Exposure Coordinator run completed successfully");
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		} finally {
			int exitCode = SpringApplication.exit(applicationContext, () -> 0);
			System.exit(exitCode);
		}
	}
}
