package com.bfm.aap.pmdx.exposurecoordinator.positionreader.service;

import com.bfm.aap.pmdx.model.PositionReaderResponse;

/**
 * Get Back Dated Positions
 */
public interface PositionReaderService {
    PositionReaderResponse fetchPositions(String portGroup, String date);
}
