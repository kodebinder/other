package com.bfm.aap.pmdx.exposurecoordinator.calculationserver.service.impl;

import com.bfm.aap.pmcs.beam.client.PMCSBeamClient;
import com.bfm.aap.pmdx.exposurecoordinator.calculationserver.service.CalculationServerService;
import com.bfm.aap.pmdx.exposurecoordinator.util.RunTimeUtil;
import com.google.common.collect.Lists;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class CalculationServerServiceImpl implements CalculationServerService {
    private static final Logger LOGGER = LoggerFactory.getLogger(CalculationServerServiceImpl.class);

    private PMCSBeamClient privateMarketsCalculationServer;

    @Autowired
    public CalculationServerServiceImpl(PMCSBeamClient privateMarketsCalculationServer) {
        this.privateMarketsCalculationServer = privateMarketsCalculationServer;
    }

    @Override
    public boolean sendDataToPMCSForCalculationsForPortfolio(String portfolio, String portfolioInvestibleCusip, List<String> dates) {
        if (RunTimeUtil.isWhatIfModeOn()) {
            LOGGER.info("Running in What-If mode. Skipping call to PMCS");
            return false;
        }

        int batchSize = RunTimeUtil.getPMCSBatchSize();
        List<List<String>> datesBatches = Lists.partition(dates, batchSize);
        LOGGER.info("Have {} requests to send to PMCS, broken into {} batches", dates.size(), datesBatches.size());

        int failures = 0;
        for (int i = 0; i < datesBatches.size(); i++) {
            List<String> datesBatch = datesBatches.get(i);
            int batchNumber = i + 1;
            long startTime = System.currentTimeMillis();
            boolean result = privateMarketsCalculationServer.calculateExposuresForMultipleDatesFund(portfolio, portfolioInvestibleCusip, datesBatch);
            long duration = System.currentTimeMillis() - startTime;
            LOGGER.info("Sending batch #{} of {} to PMCS with portfolio={}, cusip={}, dates={}, took {}ms",
                    batchNumber, datesBatches.size(), portfolio, portfolioInvestibleCusip, datesBatch, duration);
            if (!result) {
                LOGGER.warn("Batch #{} of {} to PMCS failed!!!", batchNumber, datesBatches.size());
                failures++;
            }
        }

        return failures == 0;
    }

    @Override
    public  boolean sendDataToPMCSForCalculationsForPortGroup(String portGroup, String date) {
        if (RunTimeUtil.isWhatIfModeOn()) {
            LOGGER.info("Running in What-If mode. Skipping call to PMCS");
            return false;
        }
        return privateMarketsCalculationServer.calculateExposuresForMultipleDatesPortfolio(portGroup, Collections.singletonList(date));
    }
}
