package com.bfm.aap.pmdx.exposurecoordinator.model;

import com.google.protobuf.Timestamp;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.Objects;

/**
 * @author Bharat Saraswat
 * @date - 5/28/2020-12:47 PM
 */

@Data
@AllArgsConstructor
@Builder
public class RerunRequest {
    private String portfolioName;
    private String portfolioCusip;
    private Timestamp posDate;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RerunRequest that = (RerunRequest) o;
        return Objects.equals(portfolioName, that.portfolioName) &&
                Objects.equals(portfolioCusip, that.portfolioCusip) &&
                Objects.equals(posDate, that.posDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(portfolioName, portfolioCusip, posDate);
    }
}
