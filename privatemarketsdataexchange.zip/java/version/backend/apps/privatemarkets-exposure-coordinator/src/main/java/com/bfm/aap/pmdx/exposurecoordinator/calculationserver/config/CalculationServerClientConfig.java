package com.bfm.aap.pmdx.exposurecoordinator.calculationserver.config;

import com.bfm.aap.pmcs.beam.client.PMCSBeamClient;
import com.bfm.aap.pmdx.redblue.NetworkMode;
import com.bfm.aap.pmdx.redblue.PmdxServiceType;
import com.bfm.aap.pmdx.redblue.RedBlueNetworkChecker;
import com.bfm.beam2.Configs;
import com.bfm.beam2.ServiceProxyFactories;
import com.bfm.beam2.ServiceProxyFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.TimeUnit;

import static com.bfm.aap.pmdx.exposurecoordinator.util.RunTimeUtil.getPMCSTimeout;


@Configuration
public class CalculationServerClientConfig {

    @Bean(name = "privateMarketsCalculationServerClient")
    public PMCSBeamClient getPrivateMarketsCalculationServerClient() {
        ServiceProxyFactory factory = ServiceProxyFactories.bmsServiceProxyFactory();
        return factory.getServiceProxy(PMCSBeamClient.class, Configs.builder()
                .setSourceId(getSourceId())
                .setTimeout(getPMCSTimeout(), TimeUnit.SECONDS).build());
    }

    private int getSourceId() {
        // Initialize RedBlueNetworkChecker with its own DataSource
        RedBlueNetworkChecker.initDataSource();
        return RedBlueNetworkChecker.getSourceIdByTypeAndColor(PmdxServiceType.PRIVATEMARKETS_CALCULATION_SERVER, getPrimaryNetwork());
    }

    private NetworkMode getPrimaryNetwork() {
        try {
            return RedBlueNetworkChecker.getPrimaryNetworkPredicate().getPrimaryNetwork();
        } catch (Exception e) {
            throw new RuntimeException("Error while getting primary network:" + e.getMessage(), e);
        }
    }
}
