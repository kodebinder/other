package com.bfm.aap.pmdx.exposurecoordinator.price;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.validation.constraints.NotNull;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import com.bfm.aap.pmdx.exposurecoordinator.util.DateUtil;
import com.bfm.aap.privatemarkets.common.constant.CommonConstants;
import com.bfm.util.BFMDate;
import com.bfm.util.BFMUtil;
import com.bfm.util.HolidayCalendar;
import com.bfm.util.Pair;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class FileReaderServiceImpl implements FileReadService {

	private static final String CSV_FILES = ".csv";
	private static final String COMMA = ",";
	private static final String POS_DATE = "POS_DATE";
	private static final String CUSIP = "CUSIP";
	private static final String POSITION_FILE_DIR = "positionLoader";
	private static final String STAGING_DIR = "staging";
	private static final String POS_FILE_PREFIX = "efront_positions_";
	private static final String CLIENT_CODE = "clientOrgCode";

	@Override
	public List<Pair<String, String>> getCusipsWithPositionDate() throws IOException {
		List<Path> files = getCSVFiles();
		List<Pair<String, String>> cusipWithPositionDatePair = new ArrayList<>();
		for (Path file : files) {
			List<Pair<String, String>> newPairs = getCusipsFromFile(file);
			if (CollectionUtils.isNotEmpty(newPairs)) {
				log.info("Cusip pairs with position date:{}", newPairs);
				cusipWithPositionDatePair.addAll(newPairs);
			}
		}
		return cusipWithPositionDatePair;
	}

	private List<Pair<String, String>> getCusipsFromFile(Path path) throws IOException {
		List<Pair<String, String>> cusipPairList = new ArrayList<>();
		try (Stream<String> lines = Files.lines(path)) {
			List<String> fileLines = lines.collect(Collectors.toList());
			Map<String, Integer> colMap = getHeaderMap(fileLines.remove(0));
			fileLines.stream().forEach(line -> {
				String[] vals = line.split(COMMA);
				Pair<String, String> pair = Pair.of(vals[colMap.get(CUSIP)], vals[colMap.get(POS_DATE)]);
				cusipPairList.add(pair);
			});
		} catch (Exception e) {
			log.error("Error reading price cusips from file:{}", path, e);
		}
		return cusipPairList;

	}

	private List<Path> getCSVFiles() throws IOException {
		@SuppressWarnings("deprecation")
		Path filePathDir = Paths.get(BFMUtil.getBfmSystemToken(CommonConstants.PRIVATE_MARKETS_FILE_BASE_DIR), STAGING_DIR, POSITION_FILE_DIR); 
		HolidayCalendar holidayCalendar = HolidayCalendar.get_calendar(System.getProperty("holidayCalendar"));
		BFMDate today = new BFMDate(System.currentTimeMillis());
		BFMDate previousDay = DateUtil.getPreviousBusinessDay(today, holidayCalendar);
		List<Path> files = new ArrayList<>();
		String clientCode = System.getProperty(CLIENT_CODE);
		String positionFilePrefix = POS_FILE_PREFIX.concat(clientCode);
		log.info("Client code is:{} and position file prefix is:{}", clientCode, positionFilePrefix);
		try (DirectoryStream<Path> fileStream = Files.newDirectoryStream(filePathDir, Files::isRegularFile)) {
			for (Path path : fileStream) {
				if (isPositionCSVFile(path, positionFilePrefix) && conciderFileForLoad(path, today, previousDay)) {
					log.info("Position CSV file considered for price load:{}", path);
					files.add(path);
				}
			}
		}
		return files;
	}

	private boolean isPositionCSVFile(Path filePath, String positionFilePrefix) {
		String fileName = filePath.getFileName().toString();
		return fileName.startsWith(positionFilePrefix) && fileName.endsWith(CSV_FILES);
	}

	private boolean conciderFileForLoad(Path filePath, @NotNull BFMDate today, BFMDate previousDay) throws IOException {
		FileTime fileTime = Files.getLastModifiedTime(filePath);
		BFMDate fileDate = new BFMDate(fileTime.toMillis());
		return (today.eq(fileDate) || previousDay.eq(fileDate)) ? true : false;
	}

	private Map<String, Integer> getHeaderMap(String header) {
		String[] cols = header.split(COMMA);
		Map<String, Integer> headerColMap = new HashMap<>();
		for (int index = 0; index < cols.length; index++) {
			headerColMap.put(cols[index], index);
		}
		log.info("CSV file header map:{}", headerColMap);
		return headerColMap;
	}

}
