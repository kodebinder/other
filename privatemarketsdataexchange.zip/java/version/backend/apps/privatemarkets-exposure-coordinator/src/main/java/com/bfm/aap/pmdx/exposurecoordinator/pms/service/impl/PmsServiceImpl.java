package com.bfm.aap.pmdx.exposurecoordinator.pms.service.impl;

import com.bfm.aap.pmdx.exposurecoordinator.model.PMSFileRequest;
import com.bfm.aap.pmdx.exposurecoordinator.pms.service.PmsService;
import com.bfm.aap.pmdx.exposurecoordinator.util.ExposureCoordinatorConstants;
import com.bfm.aap.pmdx.exposurecoordinator.util.RunTimeUtil;
import com.bfm.aap.privatemarkets.common.constant.CommonConstants;
import com.bfm.aap.privatemarkets.common.io.Directory;
import com.bfm.util.StringUtil;
import com.google.common.annotations.VisibleForTesting;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;


@Service
@PropertySource("classpath:properties/pmsCommands.properties")
public class PmsServiceImpl implements PmsService {

    private static final Logger LOGGER = LoggerFactory.getLogger(PmsServiceImpl.class);

    public static final String PMS_PORTFOLIO_SETTINGS_VM_ARG = "pms_portfolio_settings";
    public static final String PMS_PORTFOLIO_SETTINGS = System.getProperty(PMS_PORTFOLIO_SETTINGS_VM_ARG);
    private static final String PMS_PORTFOLIO_DIRECTORY = System.getProperty("pms_portfolio_directory");
    private static final String PMS_PORTFOLIO_GROUP_DIRECTORY = System.getProperty("pms_portfolio_group_directory");
    private static final String DELIMITER = "&";

    @Value("${PMS_COMMAND_FOR_PORT_GROUP}")
    private String pmsCommandForPortfolioGroup;

    @Value("${PMS_COMMAND_FOR_FILE}")
    private String pmsCommandForFile;

    @Autowired
    private RunTimeUtil runTimeUtil;

    /**
     * Run PMS Command for all the funds in a file and given Date
     */
    @Override
    public void runPMSCommandForFile(PMSFileRequest pmsFileRequest) {
        final String command = pmsCommandForFile.replace("@filePath", pmsFileRequest.getAbsoluteFileName())
                .replace("@date", pmsFileRequest.getBfmDate().toString())
                .replace("@pmsPortfolioSettings", getPortfolioSettings())
                .replace("@pmsPortfolioDirectory", getPortfolioDirectory())
                .replace("@priority", String.valueOf(pmsFileRequest.getPriority()));

        LOGGER.info("Executing PMS Command: {} for the PMS file request: {}", command, pmsFileRequest);
        if (RunTimeUtil.isWhatIfModeOn()) {
            LOGGER.info("Running in What-If mode. Skipping PMS for portfolios in file : [{}]", command);
        } else {
            runTimeUtil.execute(command);
            try {
                sleep(pmsFileRequest);
                Directory.moveFile(pmsFileRequest.getAbsoluteFileName(), getDestinationPath(pmsFileRequest.getFileName()));
            } catch (IOException e) {
                LOGGER.error(e.getMessage(), e);
            }
        }
        LOGGER.info("Completed running PMS command for file {} and date {}", pmsFileRequest.getAbsoluteFileName(), pmsFileRequest.getBfmDate());
    }

    private void sleep(PMSFileRequest pmsFileRequest) {
        LOGGER.info("runPMSCommandForFile is sleeping for {} seconds", pmsFileRequest.getPmsSleepTime());
        try {
            TimeUnit.SECONDS.sleep(pmsFileRequest.getPmsSleepTime());
        } catch (InterruptedException e) {
            LOGGER.error(e.getMessage(), e);
            Thread.currentThread().interrupt();
        }
    }

    private String getDestinationPath(String fileName) {
        return Paths.get(ExposureCoordinatorConstants.ARCHIVE_FILE_LOCATION, fileName).toString();
    }

    private String replaceQuotes(String str) {
        return str.replaceAll("'", "");
    }

    /**
     * Run PMS Command For Portfolio Group and Date
     */
    @Override
    public void runPMSCommandForPortGroup(String portGroup, String date) {
        final String command = pmsCommandForPortfolioGroup.replace("@portGroup", portGroup)
                .replace("@date", date)
                .replace("@pmsPortfolioSettings", getPortfolioSettings())
                .replace("@pmsPortfolioGroupDirectory", getPortfolioGroupDirectory());
        LOGGER.info("PMS Command: {}", command);
        if (RunTimeUtil.isWhatIfModeOn()) {
            LOGGER.info("Running in What-If mode. Skipping PMS for portGroup: [{}]", command);
        } else {
            runTimeUtil.execute(command);
        }
        LOGGER.info("Completed running PMS command for portGroup {} and date {}", portGroup, date);
    }

    @VisibleForTesting
    String getPortfolioSettings() {
        if (StringUtil.isEffectivelyEmpty(PMS_PORTFOLIO_SETTINGS)) {
            return StringUtils.EMPTY;
        } else {
            String pmsPortfolioSettings = replaceQuotes(PMS_PORTFOLIO_SETTINGS);
            return StringUtils.replace(pmsPortfolioSettings, DELIMITER, CommonConstants.SPACE);
        }
    }

    @VisibleForTesting
    String getPortfolioDirectory() {
        return StringUtil.isEffectivelyEmpty(PMS_PORTFOLIO_DIRECTORY) ? StringUtils.EMPTY : PMS_PORTFOLIO_DIRECTORY;
    }

    @VisibleForTesting
    String getPortfolioGroupDirectory() {
        return StringUtil.isEffectivelyEmpty(PMS_PORTFOLIO_GROUP_DIRECTORY) ? StringUtils.EMPTY : PMS_PORTFOLIO_GROUP_DIRECTORY;
    }

}
