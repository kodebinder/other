package com.bfm.aap.pmdx.exposurecoordinator.pms.service;

import com.bfm.aap.pmdx.exposurecoordinator.model.PMSFileRequest;

/**
 * @author - Rahul Dev Mishra
 * @date - 2/11/2020-5:17 PM
 */

public interface PmsService {
    /**
     * Run PMS Command For Portfolio Group and Date
     */
    void runPMSCommandForPortGroup(String portGroup, String date);

    /**
     * Run PMS Command for all the funds in a file and given Date
     */
    void runPMSCommandForFile(PMSFileRequest pmsFileRequest);
}
