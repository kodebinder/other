package com.bfm.aap.pmdx.exposurecoordinator.price;

public interface PriceLoadService {

	/**
	 * will be used to load the price data based on position files present at
	 * location /proj/publish/alts/efront/staging/positionLoader in respective
	 * environment.
	 */
	void loadPrice();

}
