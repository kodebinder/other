package com.bfm.aap.pmdx.exposurecoordinator.positionreader.service.impl;

import com.bfm.aap.pmdx.exposurecoordinator.positionreader.service.PositionReaderService;
import com.bfm.aap.pmdx.model.PositionReaderResponse;
import com.bfm.aap.pmdx.position.reader.PrivateMarketsPositionReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author - Rahul Dev Mishra
 * @date - 2/11/2020-5:16 PM
 */

@Service
public class PositionReaderServiceImpl implements PositionReaderService {
    private PrivateMarketsPositionReader privateMarketsPositionReader;

    @Autowired
    public PositionReaderServiceImpl(PrivateMarketsPositionReader privateMarketsPositionReader) {
        this.privateMarketsPositionReader = privateMarketsPositionReader;
    }

    @Override
    public PositionReaderResponse fetchPositions(String portGroup, String date) {
        return privateMarketsPositionReader.getBackDatedPositionsForGivenDate(portGroup,date);
    }
}
