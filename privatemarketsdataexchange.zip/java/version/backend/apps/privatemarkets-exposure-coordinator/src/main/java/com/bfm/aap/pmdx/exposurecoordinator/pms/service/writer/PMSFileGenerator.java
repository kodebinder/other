package com.bfm.aap.pmdx.exposurecoordinator.pms.service.writer;

import com.bfm.aap.pmdx.exposurecoordinator.model.PMSFileRequest;
import com.bfm.aap.pmdx.exposurecoordinator.model.RerunRequest;
import com.bfm.aap.pmdx.exposurecoordinator.util.ExposureCoordinatorConstants;
import com.bfm.util.BFMDate;
import com.bfm.util.BFMDateConstants;
import com.google.common.annotations.VisibleForTesting;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class PMSFileGenerator {
    private static final Logger LOGGER = LoggerFactory.getLogger(PMSFileGenerator.class);
    private static final String FILE_PREFIX = "PMDX_PMS_RERUN_REQUEST";
    private static final String FILE_TYPE = ".txt";
    private static final String FILE_NAME_SEPARATOR = "_";
    private static final String COLON = ":";
    private static final String DOT = ".";
    static final String WAIT_TIME = "waitTime";
    static final String LOAD_FACTOR = "loadFactor";
    private static final int DEFAULT_WAIT_TIME = 10;
    private static final int DEFAULT_LOAD_FACTOR = 5;
    private static final int MAX_PMS_BATCH_PRIORTY = 9000;
    private static final int MIN_PMS_BATCH_PRIORTY = 500;
    private static final int DIMINISHING_FACTOR = 100;

    public List<PMSFileRequest> generateFile(Map<BFMDate, List<RerunRequest>> monthEndMap) {
        final int[] priAdj = {1};
        return monthEndMap.keySet().stream()
                .map(bfmDate -> createFileForEachDate(bfmDate, monthEndMap.get(bfmDate), priAdj[0]++))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    private PMSFileRequest createFileForEachDate(BFMDate bfmDate, List<RerunRequest> rerunRequests, int priAdj) {
        if (CollectionUtils.isEmpty(rerunRequests)) {
            LOGGER.warn("There are no rerun requests for the date: {}", bfmDate);
            return null;
        }

        LOGGER.info("Creating a PMS rerun request file for the date: {} with {} requests: {}", bfmDate, rerunRequests.size(), rerunRequests);
        String fileName = getFileName(bfmDate);
        Path absoluteFileName = getAbsoluteFileName(fileName);
        return write(bfmDate, rerunRequests, fileName, absoluteFileName, priAdj);
    }

    @VisibleForTesting
    PMSFileRequest write(BFMDate bfmDate, List<RerunRequest> rerunRequests, String fileName, Path absoluteFileName, int priAdj) {
        try {
            Files.write(absoluteFileName, rerunRequests.stream()
                    .map(RerunRequest::getPortfolioName)
                    .collect(Collectors.toList()));
            return createPMSRequest(bfmDate, rerunRequests, fileName, absoluteFileName.toString(), calculatePriority(priAdj));
        } catch (IOException e) {
            LOGGER.error("Error while writing to file for the date {}: {}", bfmDate, e.getMessage(), e);
        }
        return null;
    }

    /**
     * This method calculates the priority of the PMS batch to be fired.
     * This is to ensure batches for latest date gets max
     * priority and earliest gets lowest priority
     * @param priAdj
     * @return
     */
    @VisibleForTesting
    int calculatePriority (int priAdj) {
        int priority = MAX_PMS_BATCH_PRIORTY - DIMINISHING_FACTOR * priAdj;
        return priority < MIN_PMS_BATCH_PRIORTY ? MIN_PMS_BATCH_PRIORTY : priority;
    }

    private Path getAbsoluteFileName(String fileName) {
        return Paths.get(getFileLocation(), fileName);
    }

    @VisibleForTesting
    String getFileLocation() {
        return ExposureCoordinatorConstants.INCOMING_FILE_LOCATION;
    }

    private PMSFileRequest createPMSRequest(BFMDate bfmDate, List<RerunRequest> rerunRequests,
                                            String fileName, String absoluteFileName, int priority) {
        return PMSFileRequest.builder()
                .bfmDate(bfmDate)
                .fileName(fileName)
                .absoluteFileName(absoluteFileName)
                .fileSize(rerunRequests.size())
                .pmsSleepTime(calculatePMSSleepTime(rerunRequests.size()))
                .priority(priority)
                .build();
    }

    @VisibleForTesting
    int calculatePMSSleepTime(int rerunRequestSize) {
        int totalSleepTime = getWaitTime() + getLoadFactor() * rerunRequestSize;
        int sleepTimeThreshold = ExposureCoordinatorConstants.WAIT_TIME_MULTIPLIER * getWaitTime();
        return Math.min(totalSleepTime, sleepTimeThreshold);
    }

    @VisibleForTesting
    Integer getLoadFactor() {
        return StringUtils.isEmpty(System.getProperty(LOAD_FACTOR)) ? DEFAULT_LOAD_FACTOR : Integer.parseInt(System.getProperty(LOAD_FACTOR));
    }

    @VisibleForTesting
    Integer getWaitTime() {
        return StringUtils.isEmpty(System.getProperty(WAIT_TIME)) ? DEFAULT_WAIT_TIME : Integer.parseInt(System.getProperty(WAIT_TIME));
    }

    // Ex: PMDX_PMS_RERUN_REQUEST_20201231_0b557783-7423-4d67-a0a4-ca05350bb697_2020-05-29T07_40_32_773.txt
    private String getFileName(BFMDate bfmDate) {
        return String.join(FILE_NAME_SEPARATOR,
                FILE_PREFIX,
                bfmDate.fmt(BFMDateConstants.FMT_YYYYMMDD),
                UUID.randomUUID().toString(),
                getLocalDateTime())
                + FILE_TYPE;

    }

    private String getLocalDateTime() {
        return LocalDateTime.now().toString()
                .replace(COLON, FILE_NAME_SEPARATOR)
                .replace(DOT, FILE_NAME_SEPARATOR);
    }
}
