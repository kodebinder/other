package com.bfm.aap.pmdx.exposurecoordinator.util;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;

import static com.bfm.aap.pmdx.exposurecoordinator.util.ExposureCoordinatorConstants.MAX_PMCS_BATCH_SIZE;
import static com.bfm.aap.pmdx.exposurecoordinator.util.ExposureCoordinatorConstants.MAX_TIME_TO_WAIT;

import com.google.common.annotations.VisibleForTesting;

/**
 * @author - Amulya Sindhura Pulijala
 * @date - 3/6/2020-2:09 PM
 */

@Service
public class RunTimeUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(RunTimeUtil.class);
    private static final String WHAT_IF = "whatIf";
    private static final String PMCS_TIMEOUT = "pmcsTimeout";
    private static final String PMCS_BATCH_SIZE = "pmcsBatchSize";
    private static final String POSITION_READER_TIMEOUT = "positionReaderTimeout";
    private static final Runtime RUNTIME = Runtime.getRuntime();

    public void execute(String command) {
        try {
            RUNTIME.exec(command);
        } catch (IOException e) {
            LOGGER.info(e.getMessage(), e);
        }
    }

    public static boolean isWhatIfModeOn () {
        String value = System.getProperty(WHAT_IF);
        if (StringUtils.isEmpty(value)) {
            return false;
        }
        return Boolean.parseBoolean(value);
    }

    public static int getPMCSTimeout() {
        return getProperty(PMCS_TIMEOUT);
    }

    public static int getPMCSBatchSize() {
        return getProperty(PMCS_BATCH_SIZE);
    }

    public static int getPositionReaderTimeout() {
        return getProperty(POSITION_READER_TIMEOUT);
    }

    @VisibleForTesting
    static int getProperty(String key) {
        String value = System.getProperty(key);
        LOGGER.info("System Property: [{}] - Value: [{}]", key, value);
        if (StringUtils.isEmpty(value)) {
            if (PMCS_TIMEOUT.equals(key) || POSITION_READER_TIMEOUT.equals(key)) {
                LOGGER.info("No System Property found for: [{}]. Defaulting to {}", key, MAX_TIME_TO_WAIT);
                return MAX_TIME_TO_WAIT;
            } else if (PMCS_BATCH_SIZE.equals(key)){
                LOGGER.info("No System Property found for: [{}]. Defaulting to {}", key, MAX_PMCS_BATCH_SIZE);
                return MAX_PMCS_BATCH_SIZE;
            } else {
                String msg = String.format("Unsupported System Property key specified: [%s]", key);
                throw new IllegalArgumentException(msg);
            }
        }
        return Integer.parseInt(value);
    }
}
