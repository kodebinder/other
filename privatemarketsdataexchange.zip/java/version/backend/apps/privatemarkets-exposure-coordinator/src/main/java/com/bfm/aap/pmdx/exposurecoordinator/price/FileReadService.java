package com.bfm.aap.pmdx.exposurecoordinator.price;

import java.io.IOException;
import java.util.List;

import com.bfm.util.Pair;

public interface FileReadService {

	/**
	 * Reads the list of cusips with position date from position files present at
	 * /proj/publish/alts/efront/staging/positionLoader. The read should happen for
	 * files from current date till yesterday in reverse order. Here yesterday can
	 * go to any other date in past that preceeds the current date in terms of
	 * position file presence.
	 * 
	 * @return
	 * @throws IOException 
	 */
	List<Pair<String, String>> getCusipsWithPositionDate() throws IOException;

}
