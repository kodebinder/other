package com.bfm.aap.pmdx.exposurecoordinator.util;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bfm.util.BFMDate;
import com.bfm.util.HolidayCalendar;
import com.google.protobuf.Timestamp;

public class DateUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(DateUtil.class);

    private DateUtil() {
    }

    /**
     * Convert Proto Time Stamp to a String
     *
     * @param timestamp
     * @return string
     */
    public static String convertProtoTimeStampToString(Timestamp timestamp) {
        Instant inst = Instant.ofEpochSecond(timestamp.getSeconds(), timestamp.getNanos());
        Date date = Date.from(inst);
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        return formatter.format(date);
    }

    /**
     * Calculate Month End Dates  given start date and end Date.
     *
     * @param startDate
     * @param endDate
     * @param holidayCalendar
     * @return Set of Strings.
     * @throws IOException
     */
    public static List<String> calculateMonthEndDates(final String startDate, final String endDate, HolidayCalendar hc) throws IOException {

    	if (hc == null) {
            String error = "Holiday Calendar not found for Holiday Calendar [" + hc + "]";
            LOGGER.error(error);
            throw new RuntimeException(error);
        }

    	BFMDate bfmEndDate = new BFMDate(endDate);
        BFMDate bfmStartDate = new BFMDate(startDate);
        final Set<BFMDate> bfmDates = new HashSet<>();
        final BFMDate stopDate = new BFMDate(bfmEndDate).addMonths(-1, 0);
        stopDate.endOfMonth();

        for (; bfmStartDate.le(stopDate); bfmStartDate.addMonths(1, 0)) {
            final BFMDate date = new BFMDate(bfmStartDate);
            date.endOfMonth();
            // skip if its a holiday or weekend
            while (isHoliday(hc, date)) {
                LOGGER.info("Skipping date: [{}] as it's either a weekend or a holiday as per Holiday Calendar: [{}]", date, hc.getCalendarCode());
                date.addDays(-1);
            }
            bfmDates.add(date);
        }

        return bfmDates.stream()
                .map(BFMDate::asLong)
                .sorted()
                .map(date -> new BFMDate(String.valueOf(date)))
                .map(BFMDate::toString)
                .collect(Collectors.toList());
    }

    public static boolean isHoliday(HolidayCalendar hc, BFMDate date) {
        return hc.is_holiday(date)
                || "Saturday".equalsIgnoreCase(date.getDayName(BFMDate.FMT_Long))
                || "Sunday".equalsIgnoreCase(date.getDayName(BFMDate.FMT_Long));
    }

    /**
     * A utility method to check if two dates are equal or not
     *
     * @param date1 -  a non null String date
     * @param date2 -  a non null String date
     * @return
     */
    public static boolean checkIfDatesAreEqual(String date1, String date2) {
        BFMDate bfmDate1 = new BFMDate(date1);
        BFMDate bfmDate2 = new BFMDate(date2);
        return bfmDate1.eq(bfmDate2);
    }

    public static String getPreviousDate(String date) {
        BFMDate bfmDate = new BFMDate(date);
        return bfmDate.addDays(-1).toString();
    }
    
    /**
     * Get client holiday calendar for given calendar code.
     * If calendar is not found it will be defaulted to US holiday calendar.
     * @param clientCalendarCode
     * @return
     */
    public static HolidayCalendar getHolidayCalendar(@NotNull String clientCalendarCode) {
    	return HolidayCalendar.get_calendar(clientCalendarCode, "US");
    }
    
    /**
     * Get previous working day from current date based on given holiday calendar.
     * @param currentDate
     * @param calendar
     * @return
     */
    public static BFMDate getPreviousBusinessDay(@NotNull BFMDate currentDate, @NotNull HolidayCalendar calendar) {
    	BFMDate newDate = new BFMDate(currentDate);
    	newDate.addDays(-1);
    	while(isHoliday(calendar, newDate)) {
   			newDate.addDays(-1);
    	}
    	return newDate;
    }
    
}