package com.bfm.aap.pmdx.exposurecoordinator.positionreader.config;

import com.bfm.aap.pmdx.exposurecoordinator.util.RunTimeUtil;
import com.bfm.aap.pmdx.position.reader.PrivateMarketsPositionReader;
import com.bfm.aap.pmdx.redblue.NetworkMode;
import com.bfm.aap.pmdx.redblue.PmdxServiceType;
import com.bfm.aap.pmdx.redblue.RedBlueNetworkChecker;
import com.bfm.beam2.BRElemConverter;
import com.bfm.beam2.Configs;
import com.bfm.beam2.ServiceProxyFactories;
import com.bfm.beam2.ServiceProxyFactory;
import com.bfm.privatemarkets.beam2.util.Proto3JsonConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Collections;
import java.util.concurrent.TimeUnit;

import static com.bfm.aap.pmdx.exposurecoordinator.util.ExposureCoordinatorConstants.POS_READER_APP_NAME;

/**
 * @author - Rahul Dev Mishra
 * @date - 2/14/2020-1:10 PM
 */

@Configuration
public class PositionReaderClientConfig {

    @Bean(name = "privateMarketsPositionReaderClient")
    public PrivateMarketsPositionReader getPrivateMarketsPositionReaderClient() {
        ServiceProxyFactory factory = ServiceProxyFactories.bmsServiceProxyFactory(getConfig(Proto3JsonConverter.factory()));
        return factory.getServiceProxy(PrivateMarketsPositionReader.class, Configs.builder()
                .setSourceId(getSourceId())
                .setTimeout(RunTimeUtil.getPositionReaderTimeout(), TimeUnit.SECONDS).build());
    }

    private int getSourceId() {
        // Initialize RedBlueNetworkChecker with its own DataSource
        RedBlueNetworkChecker.initDataSource();
        return RedBlueNetworkChecker.getSourceIdByTypeAndColor(PmdxServiceType.PRIVATEMARKETS_POSITION_READER, getPrimaryNetwork());
    }

    private ServiceProxyFactories.SPFConfig getConfig(BRElemConverter.Factory protoFactory) {
        return new ServiceProxyFactories.SPFConfig()
                .setAppName(POS_READER_APP_NAME)
                .setTimeout(RunTimeUtil.getPositionReaderTimeout(), TimeUnit.SECONDS)
                .setBrElemConverterFactories(Collections.singletonList(protoFactory));
    }

    private NetworkMode getPrimaryNetwork() {
        try {
            return RedBlueNetworkChecker.getPrimaryNetworkPredicate().getPrimaryNetwork();
        } catch (Exception e) {
            throw new RuntimeException("Error while getting primary network:" + e.getMessage(), e);
        }
    }
}
