package com.bfm.aap.pmdx.exposurecoordinator.rollforwardpositions;

import com.bfm.aap.pmdx.exposurecoordinator.util.RunTimeUtil;
import com.bfm.aap.privatemarkets.dao.PosExtensionDao;
import com.bfm.aap.privatemarkets.dao.model.PosExtension;
import com.bfm.aap.privatemarkets.dao.util.DateUtil;
import com.bfm.util.BFMDate;
import com.bfm.util.BFMDateConstants;
import com.bfm.util.BFMDateTime;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author - Rahul Dev Mishra
 * @date - 5/5/2020-2:54 PM
 */

@Service
public class RollForwardPositionServiceImpl implements RollForwardPositionService {
    private static final Logger LOGGER = LoggerFactory.getLogger(RollForwardPositionServiceImpl.class);
    private static final String SKIP_ROLL_FORWARD_POS_EX = "skipRollForwardPosEx";
    private static final BFMDate END_DATE = new BFMDate("12/31/2222");
    private static final int MAX_ALLOWED_DESC_LENGTH = 34;

    @Autowired
    private PosExtensionDao posExtensionDao;

    @Override
    public void rollForwardPosExtension(String portfolioName, String loadDate) {
        if (shouldSkipRollForwardPosExtension()) {
            LOGGER.info("Skipping roll-forwarding of positions in pos_extension table: VM Arg {} is set to [{}]",
                    SKIP_ROLL_FORWARD_POS_EX, System.getProperty(SKIP_ROLL_FORWARD_POS_EX));
            return;
        }
        LOGGER.info("Executing roll forward positions for the portfolioName: {} and date: {}", portfolioName, loadDate);
        List<PosExtension> latestPositionsAsOfLoadDate = fetchLatestPositionsAsOfLoadDate(portfolioName, loadDate);
        persistPositions(loadDate, latestPositionsAsOfLoadDate);
    }

    private List<PosExtension> fetchLatestPositionsAsOfLoadDate(String portfolioName, String loadDate) {
        List<PosExtension> posExtensions = fetchLatestPositions(portfolioName, loadDate);
        LOGGER.info("Fetched {} latest positions for the load date {}: {}", posExtensions.size(), loadDate, posExtensions.stream()
                .map(PosExtension::getPosExtensionPK)
                .collect(Collectors.toList()));
        return posExtensions;
    }

    private List<PosExtension> fetchLatestPositions(String portfolioName, String loadDate) {
        return posExtensionDao.findPosExtensionRecordsToRollForward(portfolioName, loadDate);
    }

    private void persistPositions (String loadDate, List<PosExtension> expectedPosExtensions) {

        final List<PosExtension> recordsToInsert = new ArrayList<>();
        final List<PosExtension> recordsToUpdate = new ArrayList<>();

        for (PosExtension posExtension : expectedPosExtensions) {
            List<PosExtension> existingPosExRecords = posExtensionDao.findActivePosExtensionRecordsByFundAndCusipAndPosDate(
                    posExtension.getPosExtensionPK().getFund(),
                    posExtension.getPosExtensionPK().getCusip(),
                    loadDate,
                    posExtension.getPosExtensionPK().getInvnum());

            if (CollectionUtils.isEmpty(existingPosExRecords)) {
                LOGGER.info("No existing record with same (fund, cusip, invnum, pos_date) and different stop_date found.");
                recordsToInsert.add(posExtension);
            } else if (existingPosExRecords.size() > 1) {
                LOGGER.error("Possible duplicates found encountered in pos_extension. PosExtension : [{}]", existingPosExRecords);
                throw new RuntimeException("Possible duplicates encountered in pos_extension for load_date : "
                        + loadDate + " , posExtensions : " + existingPosExRecords);
            } else {
                LOGGER.info("Found one record for the loadDate: {} and PosExtensionPK: {} is - existing pos extension record: {}",
                        loadDate, posExtension.getPosExtensionPK(), existingPosExRecords.get(0).getPosExtensionPK());
                recordsToUpdate.add(existingPosExRecords.get(0));
            }
        }

        // update records
        updateExistingPositions(loadDate, recordsToUpdate);

        // save new records to database
        createNewPositionExtensions(loadDate, recordsToInsert);
    }

    private void updateExistingPositions(String loadDate, List<PosExtension> recordsToUpdate) {
        if (CollectionUtils.isEmpty(recordsToUpdate)) {
            LOGGER.info("No records to update found for date {}", loadDate);
            return;
        }
        recordsToUpdate.forEach(p -> updateExistingPosition(loadDate, p));
    }

    private void updateExistingPosition(String loadDate, PosExtension recordToUpdate) {
        if (recordToUpdate == null) {
            throw new RuntimeException("Null PosExtension entry received.");
        }
        LOGGER.info("Update stop date on the active position record for the load date: {} - Pos Extension record: {}", loadDate, recordToUpdate.getPosExtensionPK());

        if (RunTimeUtil.isWhatIfModeOn()) {
            LOGGER.info("Running in What-If mode. Skipping pos_extension updates");
        } else {
            posExtensionDao.updateExistingPosExtensionRecord(
                    recordToUpdate.getPosExtensionPK().getFund(),
                    recordToUpdate.getPosExtensionPK().getCusip(),
                    recordToUpdate.getPosExtensionPK().getPosDate().fmt(BFMDateConstants.FMT_YYYYMMDD),
                    recordToUpdate.getPosExtensionPK().getInvnum(),
                    recordToUpdate.getPosExtensionPK().getStopDate().fmt(BFMDateConstants.FMT_YYYYMMDD),
                    new BFMDateTime(System.currentTimeMillis()).toString(),
                    createDescription(recordToUpdate));
        }
    }

    private String createDescription(PosExtension recordToUpdate) {
        String description = "GPXR-UPD:old_stop_dt:" + recordToUpdate.getPosExtensionPK().getStopDate().toString();
        description = description.length() < MAX_ALLOWED_DESC_LENGTH ? description : description.substring(0,33);
        return description;
    }

    private void createNewPositionExtensions(String loadDate, List<PosExtension> recordsToInsert) {
        recordsToInsert.forEach(posExtension -> {
            posExtension.getPosExtensionPK().setPosDate(new BFMDate(loadDate));
            posExtension.setDescription("GPXR-INSERT");
            posExtension.getPosExtensionPK().setStopDate(END_DATE);
            posExtension.setModifyTime(new BFMDateTime(System.currentTimeMillis()));
        });

        if (CollectionUtils.isNotEmpty(recordsToInsert)) {
            LOGGER.info("Saving {} records into pos_extension table for the load date {}: {}", recordsToInsert.size(), loadDate, recordsToInsert.stream()
                    .map(PosExtension::getPosExtensionPK)
                    .collect(Collectors.toList()));
            if (RunTimeUtil.isWhatIfModeOn()) {
                LOGGER.info("Running in What-If mode. Skipping pos_extension inserts.");
            } else {
                saveAll(recordsToInsert);
            }
        }
    }

    private List<PosExtension> saveAll(List<PosExtension> posExtensionList) {
        return posExtensionDao.saveAll(posExtensionList);
    }

    private boolean shouldSkipRollForwardPosExtension() {
        String value = System.getProperty(SKIP_ROLL_FORWARD_POS_EX);
        if (StringUtils.isEmpty(value)) {
            return false;
        }
        return Boolean.parseBoolean(value);
    }
}
