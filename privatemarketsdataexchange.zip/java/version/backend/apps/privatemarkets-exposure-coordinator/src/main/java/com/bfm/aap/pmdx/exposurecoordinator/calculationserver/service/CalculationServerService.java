package com.bfm.aap.pmdx.exposurecoordinator.calculationserver.service;

import java.util.List;

/**
 * @author - Amulya Sindhura Pulijala
 * @date - 3/04/2020-10:12 AM
 */

/**
 * This is to send data to Private Market Calculations Server
 * to calculate risk exposures
 */
public interface CalculationServerService {
    boolean sendDataToPMCSForCalculationsForPortGroup(String portGroup, String date);

    boolean sendDataToPMCSForCalculationsForPortfolio(String portfolio, String portfolioInvestibleCusip, List<String> dates);
}
