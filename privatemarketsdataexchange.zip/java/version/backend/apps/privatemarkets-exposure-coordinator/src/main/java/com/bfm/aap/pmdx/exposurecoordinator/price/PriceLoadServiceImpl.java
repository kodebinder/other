package com.bfm.aap.pmdx.exposurecoordinator.price;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bfm.aap.pmdx.exposurecoordinator.notification.NotificationHandler;
import com.bfm.aap.pmdx.exposurecoordinator.util.DateUtil;
import com.bfm.aap.privatemarkets.dao.SpdbDao;
import com.bfm.aap.privatemarkets.dao.model.Spdb;
import com.bfm.aap.privatemarkets.dao.model.SpdbKey;
import com.bfm.util.BFMDate;
import com.bfm.util.BFMDateTime;
import com.bfm.util.BFMTime.BFMTimeException;
import com.bfm.util.HolidayCalendar;
import com.bfm.util.Pair;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PriceLoadServiceImpl implements PriceLoadService {

	private final FileReadService fileReadService;
	private final SpdbDao spdbDao;
	private static final String PURPOSE = "EFRO";
	private static final String SOURCE = "E";
	private final NotificationHandler notificationHandler;

	@Autowired
	public PriceLoadServiceImpl(final FileReadService fileReadService, final SpdbDao spdbDao, final NotificationHandler notificationHandler) {
		this.fileReadService = fileReadService;
		this.spdbDao = spdbDao;
		this.notificationHandler = notificationHandler;
	}

	@Override
	public void loadPrice() {
		try {
			List<Pair<String, String>> cusipsWithPosDate = fileReadService.getCusipsWithPositionDate();
			if(CollectionUtils.isNotEmpty(cusipsWithPosDate)) {
				loadPriceForPositionDate(cusipsWithPosDate);
				loadPriceForForwardDates(cusipsWithPosDate);
			}
			notificationHandler.notifySuccess("Price Load Completed");
		} catch (Exception e) {
			log.error("Error loading price please check stack trace: ", e);
			notificationHandler.handleException(e);
		}

	}

	private void loadPriceForForwardDates(List<Pair<String, String>> cusipsWithPosDate)
			throws IOException, NumberFormatException, BFMTimeException {
		log.info("Loading price for forward date...");
		HolidayCalendar holidayCalendar = DateUtil.getHolidayCalendar(System.getProperty("holidayCalendar"));
		BFMDate endBFMDate = new BFMDate(System.getProperty("tDate"));
		String endDate = DateUtil.getPreviousBusinessDay(endBFMDate, holidayCalendar).toString();
		for (Pair<String, String> pair : cusipsWithPosDate) {
			String startDate = pair.getSecondValue();
			List<String> monthEndDates = DateUtil.calculateMonthEndDates(startDate, endDate, holidayCalendar);
			log.info("Position date:{} \t forward dates:{}", startDate, monthEndDates);
			for (String monthEndDate : monthEndDates) {
				checkPriceAndLoad(pair.getFirstValue(), new BFMDateTime(monthEndDate));
			}
			log.info("Completed price load or forward date");
			log.info("Loading price for command date...");
			checkPriceAndLoad(pair.getFirstValue(), new BFMDateTime(endDate));
			log.info("Completed price load or command date");
		}
	}

	private void loadPriceForPositionDate(List<Pair<String, String>> cusipsWithPosDate) {
		log.info("Loading price for position date...");
		cusipsWithPosDate.forEach(pair -> {
			try {
				BFMDateTime dateTime = new BFMDateTime(pair.getSecondValue());
				String cusip = pair.getFirstValue();
				checkPriceAndLoad(cusip, dateTime);
			} catch (Exception e) {
				log.error("Error loading price for pair:{} => ", pair, e);
			}
		});
		log.info("Completed price load for position date");
	}

	private void checkPriceAndLoad(String cusip, BFMDateTime dateTime) {
		Optional<Spdb> existing = spdbDao.getByCusipDateAndPurpose(cusip, dateTime, PURPOSE);
		if (!existing.isPresent()) {
			Spdb data = initSpdbData(cusip, dateTime);
			log.info("Inserting price for cusip:{} \t mark date:{}", cusip, dateTime);
			spdbDao.insert(data);
		}
	}

	private Spdb initSpdbData(String cusip, BFMDateTime dateTime) {
		Spdb data = new Spdb();
		SpdbKey key = new SpdbKey();
		key.setCusip(cusip);
		key.setMarkDateTime(dateTime);
		key.setPurpose(PURPOSE);
		data.setKey(key);
		data.setSource(SOURCE);
		data.setPrice(1.0);
		return data;
	}

}
