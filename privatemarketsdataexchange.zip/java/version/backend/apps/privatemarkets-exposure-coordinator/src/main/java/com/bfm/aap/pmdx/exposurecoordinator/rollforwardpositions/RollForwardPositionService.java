package com.bfm.aap.pmdx.exposurecoordinator.rollforwardpositions;

public interface RollForwardPositionService {
    void rollForwardPosExtension(String portfolioName, String loadDate);
}
