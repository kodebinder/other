package com.bfm.aap.pmdx.exposurecoordinator.positionreader.service.impl;


import com.bfm.aap.pmdx.model.Position;
import com.bfm.aap.pmdx.model.PositionReaderResponse;
import com.bfm.aap.pmdx.position.reader.PrivateMarketsPositionReader;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@MockitoSettings(strictness = Strictness.LENIENT)
@ExtendWith(MockitoExtension.class)
public class PositionReaderServiceImplTest {
    @InjectMocks
    private PositionReaderServiceImpl positionReaderService;

    @Mock
    private PrivateMarketsPositionReader positionReader;

    private static PositionReaderResponse positionReaderResponse;
    private static final String mockListPositions = "[{\"portfolioId_\":\"\",\"assetId_\":\"\",\"portfolioCode_\":351370,\"cusip_\":\"\",\"invNum_\":\"\",\"contribution_\":0.0,\"positionMarketValue_\":0.0,\"originalCommitment_\":0.0,\"remainingCommitment_\":0.0,\"distribution_\":0.0,\"recallableDistribution_\":0.0,\"netNav_\":12201.0,\"clientId_\":\"\",\"investmentId_\":\"\",\"investment_\":0.0,\"investorCurrency_\":\"\",\"currentOwnership_\":0.0,\"possibleExtensionYears_\":0,\"managementFees_\":0.0,\"deleted_\":false,\"regionId_\":\"\",\"portfolioName_\":\"ALTSFUNDA\",\"memoizedIsInitialized\":1,\"unknownFields\":{\"fields\":{},\"fieldsDescending\":{}},\"memoizedSize\":-1,\"memoizedHashCode\":0},{\"portfolioId_\":\"\",\"assetId_\":\"\",\"portfolioCode_\":351370,\"cusip_\":\"\",\"invNum_\":\"\",\"contribution_\":0.0,\"positionMarketValue_\":0.0,\"originalCommitment_\":0.0,\"remainingCommitment_\":0.0,\"distribution_\":0.0,\"recallableDistribution_\":0.0,\"netNav_\":9996307.0,\"clientId_\":\"\",\"investmentId_\":\"\",\"investment_\":0.0,\"investorCurrency_\":\"\",\"currentOwnership_\":0.0,\"possibleExtensionYears_\":0,\"managementFees_\":0.0,\"deleted_\":false,\"regionId_\":\"\",\"portfolioName_\":\"ALTSFUNDA\",\"memoizedIsInitialized\":1,\"unknownFields\":{\"fields\":{},\"fieldsDescending\":{}},\"memoizedSize\":-1,\"memoizedHashCode\":0},{\"portfolioId_\":\"\",\"assetId_\":\"\",\"portfolioCode_\":351371,\"cusip_\":\"\",\"invNum_\":\"\",\"contribution_\":0.0,\"positionMarketValue_\":0.0,\"originalCommitment_\":0.0,\"remainingCommitment_\":0.0,\"distribution_\":0.0,\"recallableDistribution_\":0.0,\"netNav_\":9996307.0,\"clientId_\":\"\",\"investmentId_\":\"\",\"investment_\":0.0,\"investorCurrency_\":\"\",\"currentOwnership_\":0.0,\"possibleExtensionYears_\":0,\"managementFees_\":0.0,\"deleted_\":false,\"regionId_\":\"\",\"portfolioName_\":\"ALTSFUNDQ\",\"memoizedIsInitialized\":1,\"unknownFields\":{\"fields\":{},\"fieldsDescending\":{}},\"memoizedSize\":-1,\"memoizedHashCode\":0},{\"portfolioId_\":\"\",\"assetId_\":\"\",\"portfolioCode_\":351371,\"cusip_\":\"\",\"invNum_\":\"\",\"contribution_\":0.0,\"positionMarketValue_\":0.0,\"originalCommitment_\":0.0,\"remainingCommitment_\":0.0,\"distribution_\":0.0,\"recallableDistribution_\":0.0,\"netNav_\":9996307.0,\"clientId_\":\"\",\"investmentId_\":\"\",\"investment_\":0.0,\"investorCurrency_\":\"\",\"currentOwnership_\":0.0,\"possibleExtensionYears_\":0,\"managementFees_\":0.0,\"deleted_\":false,\"regionId_\":\"\",\"portfolioName_\":\"ALTSFUNDQ\",\"memoizedIsInitialized\":1,\"unknownFields\":{\"fields\":{},\"fieldsDescending\":{}},\"memoizedSize\":-1,\"memoizedHashCode\":0}]";


    @Test
    public void sendDataToPMCSForCalculations() {
        List<Position> positionsStub = new Gson().fromJson(mockListPositions, new TypeToken<List<Position>>() {
        }.getType());
        positionReaderResponse = PositionReaderResponse.newBuilder().addAllPosition(positionsStub).build();
        when(positionReader.getBackDatedPositionsForGivenDate(anyString(), anyString())).thenReturn(positionReaderResponse);
        PositionReaderResponse positions = positionReaderService.fetchPositions("lala", "09/26/2019");
        assertEquals("ALTSFUNDA", positions.getPosition(0).getPortfolioName());

    }
}