package com.bfm.aap.pmdx.exposurecoordinator.model;

import com.bfm.aap.pmdx.exposurecoordinator.helper.RerunRequestTestHelper;
import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class RerunRequestTest {

    @Test
    public void equalsTest_true_1() {
        RerunRequest rerunRequest_1 = RerunRequestTestHelper.mock_1();
        RerunRequest rerunRequest_2 = RerunRequestTestHelper.mock_1();
        assertTrue(rerunRequest_1.equals(rerunRequest_2));
    }

    @Test
    public void equalsTest_true_2() {
        RerunRequest rerunRequest_1 = RerunRequestTestHelper.mock_1();
        RerunRequest rerunRequest_2 = rerunRequest_1;
        assertTrue(rerunRequest_1.equals(rerunRequest_2));
    }

    @Test
    public void equalsTest_false() {
        RerunRequest rerunRequest_1 = RerunRequestTestHelper.mock_1();
        RerunRequest rerunRequest_2 = RerunRequestTestHelper.mock_2();
        assertFalse(rerunRequest_1.equals(rerunRequest_2));
    }

    @Test
    public void equalsTest_withNull() {
        RerunRequest rerunRequest_1 = RerunRequestTestHelper.mock_1();
        assertFalse(rerunRequest_1.equals(null));
    }

    @Test
    public void equalsTest_withDifferentObjectType() {
        RerunRequest rerunRequest_1 = RerunRequestTestHelper.mock_1();
        assertFalse(rerunRequest_1.equals(PMSFileRequest.builder().build()));
    }
}