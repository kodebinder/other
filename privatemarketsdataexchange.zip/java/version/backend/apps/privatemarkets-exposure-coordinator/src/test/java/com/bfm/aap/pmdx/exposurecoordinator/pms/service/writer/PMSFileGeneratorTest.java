package com.bfm.aap.pmdx.exposurecoordinator.pms.service.writer;

import com.bfm.aap.pmdx.exposurecoordinator.helper.RerunRequestTestHelper;
import com.bfm.aap.pmdx.exposurecoordinator.model.PMSFileRequest;
import com.bfm.aap.pmdx.exposurecoordinator.model.RerunRequest;
import com.bfm.util.BFMDate;
import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class PMSFileGeneratorTest {
    private String filePath;
    @Rule
    public TemporaryFolder testFolder = new TemporaryFolder();

    @Before
    public void init() {
        // Create a temporary file path.
        filePath = testFolder.getRoot().getPath();

        if (StringUtils.isNotEmpty(System.getProperty("loadFactor"))) {
            System.getProperties().remove("loadFactor");
        }

        if(StringUtils.isNotEmpty(System.getProperty("waitTime"))) {
            System.getProperties().remove("waitTime");
        }
    }

    @Test
    public void generateFile() {
        PMSFileGenerator pmsFileGeneratorSpy = Mockito.spy(new PMSFileGenerator());
        // Mock out expensive call to return dummy value.
        Mockito.when(pmsFileGeneratorSpy.getFileLocation()).thenReturn(filePath);

        Map<BFMDate, List<RerunRequest>> map = createRequestMap();
        List<PMSFileRequest> pmsFileRequests = pmsFileGeneratorSpy.generateFile(map);
        assertNotNull(pmsFileRequests);
//        assertEquals (8900, pmsFileRequests.get(0).getPriority());
//        assertEquals(2, pmsFileRequests.size());
//        assertTrue(map.containsKey(pmsFileRequests.get(0).getBfmDate()));
//        assertTrue(map.containsKey(pmsFileRequests.get(1).getBfmDate()));
    }

    @Test
    public void testCalculatePriority () {
        PMSFileGenerator p = new PMSFileGenerator();
        assertEquals(8900, p.calculatePriority(1));
        assertEquals(8000, p.calculatePriority(10));
        assertEquals(600, p.calculatePriority(84));
        assertEquals(500, p.calculatePriority(90));
    }

    @Test
    public void generateFile_emptyListForADate() {
        PMSFileGenerator pmsFileGeneratorSpy = Mockito.spy(new PMSFileGenerator());
        // Mock out expensive call to return dummy value.
        Mockito.when(pmsFileGeneratorSpy.getFileLocation()).thenReturn(filePath);

        Map<BFMDate, List<RerunRequest>> map = new TreeMap<>(BFMDate::compareTo);
        BFMDate bfmDate_1 = new BFMDate("2020-06-02");
        BFMDate bfmDate_2 = new BFMDate("2020-03-20");
        map.put(bfmDate_1, Arrays.asList(RerunRequestTestHelper.mock_1(), RerunRequestTestHelper.mock_2()));
        map.put(bfmDate_2, Collections.emptyList());
        List<PMSFileRequest> pmsFileRequests = pmsFileGeneratorSpy.generateFile(map);
        assertNotNull(pmsFileRequests);
//        assertEquals(1, pmsFileRequests.size());
//        assertTrue(map.containsKey(pmsFileRequests.get(0).getBfmDate()));
    }

    @Test
    public void writeTest_throwsIOException() {
        PMSFileGenerator pmsFileGenerator = new PMSFileGenerator();
        assertNull(pmsFileGenerator.write(new BFMDate("2020-06-03"),
                RerunRequestTestHelper.createMockrerunRequests(),
                "&#@*&@!",
                Paths.get("C:/sdsgdsjdhjh"), 1));
    }

    @Test
    public void getLoadFactorTest_withVMArg() {
        PMSFileGenerator pmsFileGenerator = new PMSFileGenerator();
        System.setProperty("loadFactor", "99");
        assertEquals(99, (int) pmsFileGenerator.getLoadFactor());
    }

    @Test
    public void getWaitTimeTest_withoutVMArg() {
        PMSFileGenerator pmsFileGenerator = new PMSFileGenerator();
        assertEquals(10, (int) pmsFileGenerator.getWaitTime());
    }

    @Test
    public void getWaitTimeTest_withVMArg() {
        PMSFileGenerator pmsFileGenerator = new PMSFileGenerator();
        System.setProperty("waitTime", "20");
        assertEquals(20, (int) pmsFileGenerator.getWaitTime());
    }

    @Test
    public void getLoadFactorTest_withoutVMArg() {
        PMSFileGenerator pmsFileGenerator = new PMSFileGenerator();
        assertEquals(5, (int) pmsFileGenerator.getLoadFactor());
    }

    @Test
    public void calculatePMSSleepTimeTest() {
        PMSFileGenerator pmsFileGenerator = new PMSFileGenerator();
        int actual = pmsFileGenerator.calculatePMSSleepTime(100);
        assertEquals(30, actual);
    }

    private Map<BFMDate, List<RerunRequest>> createRequestMap() {
        Map<BFMDate, List<RerunRequest>> map = new TreeMap<>(BFMDate::compareTo);
        BFMDate bfmDate_1 = new BFMDate("2020-06-02");
        BFMDate bfmDate_2 = new BFMDate("2020-03-20");
        map.put(bfmDate_1, Arrays.asList(RerunRequestTestHelper.mock_1(), RerunRequestTestHelper.mock_2()));
        map.put(bfmDate_2, Collections.singletonList(RerunRequestTestHelper.mock_3()));
        return map;
    }

}