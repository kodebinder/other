/**
 * 
 */
package com.bfm.aap.pmdx.exposurecoordinator.price;

import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.bfm.util.Pair;

/**
 * @author anisharm
 *
 */
@ExtendWith(MockitoExtension.class)
class FileReaderServiceImplTest {

	@InjectMocks
	private FileReaderServiceImpl fileReaderServiceImpl;

	private Path tempPath;
	private String file1 = "efront_positions_ALD-file1.csv";
	private String file2 = "efront_positions_ALD-file2.csv";
	private String file3 = "efront_positions_ALD-file3.txt";
	private Path filePath1;
	private Path filePath2;
	private Path filePath3;
	private static final String POSITION_FILE_DIR = "positionLoader";
	private static final String STAGING_DIR = "staging";
	private String header = "POS_DATE,PORTFOLIO,PORTFOLIO_CODE,CUSIP,POS_FACE,POS_CUR_PAR,MKT_VALUE_LOCAL,MKT_VALUE_BASE,TRD_CURRENCY,ORIGINAL_COMMITMENT,CURRENT_OWNERSHIP,REMAINING_COMMITMENT,TOTAL_CONTRIBUTION,TOTAL_DISTRIBUTION,TOTAL_RECALLABLE_DISTRIB,CUMULATIVE_MANAGEMENT_FEE,TOTAL_INVESTMENT_VALUE,ACCRUAL_DATE,INITIAL_COMMITMENT_DATE,CONTRIBUTION_LOCAL,DISTRIBUTION_LOCAL,COMMITMENT_LOCAL,MANAGEMENT_FEES_LOCAL";
	private List<String> data1 = Arrays.asList(header,
			"20191230,PRIV006211,827103,RTTAL20J7,3995867.245753353,3995867.245753353,3995867.245753353,3995867.245753353,USD,0.0,0.36956680054740815,0.0,0.0,0.0,0.0,0.0,0.0,19691231,19691231,0.0,0.0,0.0,0.0");
	private List<String> data2 = Arrays.asList(header,
			"20181230,PRIV006211,827103,RTTALH5R1,3995867.245753353,3995867.245753353,3995867.245753353,3995867.245753353,USD,0.0,0.36956680054740815,0.0,0.0,0.0,0.0,0.0,0.0,19691231,19691231,0.0,0.0,0.0,0.0");

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
		System.setProperty("defaultWebServer", "https://dev.blackrock.com");
		System.setProperty("clientOrgCode", "ALD");
		String defaultBaseDir = System.getProperty("java.io.tmpdir");
		System.setProperty("BRS.PrivateMarketsFileBaseDir", defaultBaseDir);
		System.setProperty("holidayCalendar", "US");
		tempPath = Paths.get(defaultBaseDir, STAGING_DIR, POSITION_FILE_DIR);
		Files.createDirectories(tempPath);
		filePath1 = tempPath.resolve(file1);
		filePath2 = tempPath.resolve(file2);
		filePath3 = tempPath.resolve(file3);
		Files.write(filePath1, data1);
		Files.write(filePath2, data2);
		Files.write(filePath3, data1);

	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterEach
	void tearDown() throws Exception {
		Files.delete(filePath1);
		Files.delete(filePath2);
		Files.delete(filePath3);
		Files.delete(tempPath);

	}

	/**
	 * Test method for
	 * {@link com.bfm.aap.pmdx.exposurecoordinator.price.FileReaderServiceImpl#getCusipsWithPositionDate()}.
	 * 
	 * @throws IOException
	 */
	@Test
	void testGetCusipsWithPositionDate() throws IOException {
		List<Pair<String, String>> data = fileReaderServiceImpl.getCusipsWithPositionDate();
		assertNotNull(data);
	}

}
