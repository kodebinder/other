package com.bfm.aap.pmdx.exposurecoordinator.helper;

import com.bfm.aap.privatemarkets.dao.model.PosExtension;
import com.bfm.aap.privatemarkets.dao.model.PosExtensionPK;
import com.bfm.util.BFMDate;

import java.util.ArrayList;
import java.util.List;

/**
 * @author - Rahul Dev Mishra
 * @date - 5/5/2020-8:24 PM
 */
public final class PosExtensionTestHelper {
    private PosExtensionTestHelper(){}

    public static List<PosExtension> mockPosExtensions() {
        List<PosExtension> list = new ArrayList<>();
        PosExtensionPK posExtensionPK = new PosExtensionPK();
        posExtensionPK.setCusip("WQ93GD");
        posExtensionPK.setFund(100);
        posExtensionPK.setPosDate(new BFMDate("2019-12-31"));
        posExtensionPK.setStopDate(new BFMDate("2020-12-31"));
        PosExtension posExtension = new PosExtension();
        posExtension.setPosExtensionPK(posExtensionPK);
        list.add(posExtension);
        return list;
    }

    public static PosExtension mockNewPosExtensions() {
        PosExtensionPK posExtensionPK = new PosExtensionPK();
        posExtensionPK.setCusip("WQ93GD");
        posExtensionPK.setFund(100);
        posExtensionPK.setPosDate(new BFMDate("2019-12-31"));
        posExtensionPK.setStopDate(new BFMDate("2222-12-31"));
        PosExtension posExtension = new PosExtension();
        posExtension.setPosExtensionPK(posExtensionPK);
        return posExtension;
    }

    public static List<PosExtension> mockExistingPosExDuplicate() {
        List<PosExtension> list = new ArrayList<>();
        list.addAll(mockPosExtensions());
        list.addAll(mockPosExtensions());
        return list;
    }

    public static List<PosExtension> mockExistingPosExUpdate() {
        List<PosExtension> list = new ArrayList<>();
        list.addAll(mockPosExtensions());
        list.get(0).getPosExtensionPK().setStopDate(new BFMDate("12/31/2019"));
        list.get(0).setDescription("GPXR-UPD:old_stop_dt:31-DEC-2019");
        return list;
    }
}
