package com.bfm.aap.pmdx.exposurecoordinator.rollforwardpositions;

import com.bfm.aap.pmdx.exposurecoordinator.helper.PosExtensionTestHelper;
import com.bfm.aap.privatemarkets.dao.PosExtensionDao;
import com.bfm.aap.privatemarkets.dao.model.PosExtension;
import com.bfm.util.BFMDateConstants;
import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class RollForwardPositionServiceImplTest {
    @Mock
    private PosExtensionDao posExtensionDao;
    @InjectMocks
    private RollForwardPositionServiceImpl rollForwardPositionService;

    @Before
    public void setup() {
        if(StringUtils.isNotEmpty(System.getProperty("skipRollForwardPosEx"))) {
            System.getProperties().remove("skipRollForwardPosEx");
        }
        if(StringUtils.isNotEmpty(System.getProperty("whatIf"))) {
            System.getProperties().remove("whatIf");
        }
    }

    @Test
    public void rollForwardPosExtensionTest() {
        String portfolioName = "ALT_ALL";
        String loadDate = "2020-01-31";
        List<PosExtension> posExtensions = PosExtensionTestHelper.mockPosExtensions();
        when(posExtensionDao.findPosExtensionRecordsToRollForward(portfolioName, loadDate)).thenReturn(posExtensions);
        rollForwardPositionService.rollForwardPosExtension(portfolioName, loadDate);
        verify(posExtensionDao, times(1)).saveAll(posExtensions);
    }

    @Test
    public void rollForwardPosExtensionTest_skipRollForward() {
        System.setProperty("skipRollForwardPosEx", "true");
        String portfolioName = "ALT_ALL";
        String loadDate = "2020-01-31";
        rollForwardPositionService.rollForwardPosExtension(portfolioName, loadDate);
        verify(posExtensionDao, times(0)).saveAll(any(List.class));
    }

    @Test
    public void rollForwardPosExtensionTest_skipRollForward_false() {
        System.setProperty("skipRollForwardPosEx", "false");
        System.setProperty("whatIf", "false");
        String portfolioName = "ALT_ALL";
        String loadDate = "2020-01-31";
        List<PosExtension> posExtensions = PosExtensionTestHelper.mockPosExtensions();
        posExtensions.add(PosExtensionTestHelper.mockNewPosExtensions());
        when(posExtensionDao.findPosExtensionRecordsToRollForward(portfolioName, loadDate)).thenReturn(posExtensions);
        rollForwardPositionService.rollForwardPosExtension(portfolioName, loadDate);
        verify(posExtensionDao, times(1)).saveAll(posExtensions);
    }

    @Test
    public void fetchLatestPositionsTest() {
        String portfolioName = "ALT_ALL";
        String loadDate = "2019-12-31";
        List<PosExtension> expected = PosExtensionTestHelper.mockPosExtensions();
        when(posExtensionDao.findPosExtensionRecordsToRollForward(portfolioName, loadDate)).thenReturn(expected);
        List<PosExtension> actual = posExtensionDao.findPosExtensionRecordsToRollForward(portfolioName, loadDate);
        assertNotNull(actual);
        assertEquals(expected, actual);
    }

    @Test
    public void saveAllTest() {
        List<PosExtension> expected = PosExtensionTestHelper.mockPosExtensions();
        when(posExtensionDao.saveAll(expected)).thenReturn(expected);
        List<PosExtension> actual = posExtensionDao.saveAll(expected);
        verify(posExtensionDao, times(1)).saveAll(expected);
        assertNotNull(actual);
        assertEquals(expected, actual);
    }

    @Test
    public void rollForwardPosExtensionTest_whatif_false() {
        System.setProperty("whatIf", "false");
        String portfolioName = "ALT_ALL";
        String loadDate = "2020-01-31";
        List<PosExtension> posExtensions = PosExtensionTestHelper.mockPosExtensions();
        posExtensions.add(PosExtensionTestHelper.mockNewPosExtensions());
        when(posExtensionDao.findPosExtensionRecordsToRollForward(portfolioName, loadDate)).thenReturn(posExtensions);
        rollForwardPositionService.rollForwardPosExtension(portfolioName, loadDate);
        verify(posExtensionDao, times(1)).saveAll(posExtensions);
    }

    @Test
    public void rollForwardPosExtensionTest_whatif_true() {
        System.setProperty("whatIf", "true");
        String portfolioName = "ALT_ALL";
        String loadDate = "2020-01-31";
        List<PosExtension> posExtensions = PosExtensionTestHelper.mockPosExtensions();
        posExtensions.add(PosExtensionTestHelper.mockNewPosExtensions());
        when(posExtensionDao.findPosExtensionRecordsToRollForward(portfolioName, loadDate)).thenReturn(posExtensions);
        rollForwardPositionService.rollForwardPosExtension(portfolioName, loadDate);
        verify(posExtensionDao, times(0)).saveAll(posExtensions);
        verify(posExtensionDao, times(0))
                .updateExistingPosExtensionRecord(1, "cusip", "12/31/2222",
                        1, "12/31/2222", "12/31/2222", "desc");
    }

    @Test (expected = RuntimeException.class)
    public void testUpdateExistingPosExDuplicates() {
        String portfolioName = "ALT_ALL";
        String loadDate = "2020-01-31";
        List<PosExtension> posExtensions = PosExtensionTestHelper.mockPosExtensions();
        List<PosExtension> activePosEx = PosExtensionTestHelper.mockExistingPosExDuplicate();
        when(posExtensionDao.findPosExtensionRecordsToRollForward(portfolioName, loadDate)).thenReturn(posExtensions);
        when(posExtensionDao.findActivePosExtensionRecordsByFundAndCusipAndPosDate(anyInt(), anyString(), anyString(), anyInt())
        ).thenReturn(activePosEx);
        rollForwardPositionService.rollForwardPosExtension(portfolioName, loadDate);
        fail("This should have be caught and treated as an exception");
    }

    @Test (expected = RuntimeException.class)
    public void testUpdateExistingPosExSuccess() {
        String portfolioName = "ALT_ALL";
        String loadDate = "2020-01-31";
        List<PosExtension> posExtensions = PosExtensionTestHelper.mockPosExtensions();
        List<PosExtension> activePosEx = PosExtensionTestHelper.mockExistingPosExUpdate();
        when(posExtensionDao.findPosExtensionRecordsToRollForward(portfolioName, loadDate)).thenReturn(posExtensions);
        when(posExtensionDao.findActivePosExtensionRecordsByFundAndCusipAndPosDate(anyInt(), anyString(), anyString(), anyInt())
        ).thenReturn(activePosEx);
        rollForwardPositionService.rollForwardPosExtension(portfolioName, loadDate);
        verify(posExtensionDao, times(1))
                .updateExistingPosExtensionRecord(
                        activePosEx.get(0).getPosExtensionPK().getFund(),
                        activePosEx.get(0).getPosExtensionPK().getCusip(),
                        activePosEx.get(0).getPosExtensionPK().getPosDate().fmt(BFMDateConstants.FMT_YYYYMMDD),
                        activePosEx.get(0).getPosExtensionPK().getInvnum(),
                        activePosEx.get(0).getPosExtensionPK().getStopDate().fmt(BFMDateConstants.FMT_YYYYMMDD),
                        anyString(), activePosEx.get(0).getDescription());
    }

    @Test
    public void testInsertNewPosExSuccess() {
        System.setProperty("whatIf", "false");
        String portfolioName = "ALT_ALL";
        String loadDate = "2020-01-31";
        List<PosExtension> posExtensions = PosExtensionTestHelper.mockPosExtensions();
        List<PosExtension> activePosEx = Collections.emptyList();
        when(posExtensionDao.findPosExtensionRecordsToRollForward(portfolioName, loadDate)).thenReturn(posExtensions);
        when(posExtensionDao.findActivePosExtensionRecordsByFundAndCusipAndPosDate(anyInt(), anyString(), anyString(), anyInt())
        ).thenReturn(activePosEx);
        rollForwardPositionService.rollForwardPosExtension(portfolioName, loadDate);
        verify(posExtensionDao, times(1))
                .saveAll(posExtensions);
    }
}