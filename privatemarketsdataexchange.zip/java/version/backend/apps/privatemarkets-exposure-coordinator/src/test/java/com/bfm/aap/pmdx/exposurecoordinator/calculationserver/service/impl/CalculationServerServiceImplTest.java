package com.bfm.aap.pmdx.exposurecoordinator.calculationserver.service.impl;

import com.bfm.aap.pmcs.beam.client.PMCSBeamClient;
import com.bfm.aap.pmdx.exposurecoordinator.calculationserver.service.CalculationServerService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@MockitoSettings(strictness = Strictness.LENIENT)
@ExtendWith(MockitoExtension.class)
class CalculationServerServiceImplTest {


    @InjectMocks
    private CalculationServerServiceImpl calculationServerService;

    @Mock
    private PMCSBeamClient privateMarketsCalculationServer;

    @Test
    void sendDataToPMCSForCalculationsForPortfolio() {
        System.setProperty("whatIf", "false");
        final List<String> dates = Arrays.asList("09/26/2019");
        when(privateMarketsCalculationServer.calculateExposuresForMultipleDatesFund(anyString(), Mockito.eq(null),any())).thenReturn(true);
        assertTrue(calculationServerService.sendDataToPMCSForCalculationsForPortfolio("lala", null, dates));
    }

    @Test
    void sendDataToPMCSForCalculationsForPortfolio_WithBatchesSuccess() {
        System.setProperty("whatIf", "false");
        int batchSize = 2;
        System.setProperty("pmcsBatchSize", Integer.toString(batchSize));
        final List<String> dates = Arrays.asList("09/26/2019", "09/27/2019", "09/28/2019","09/29/2020");
        when(privateMarketsCalculationServer.calculateExposuresForMultipleDatesFund(anyString(), Mockito.eq(null),any())).thenReturn(true);

        assertTrue(calculationServerService.sendDataToPMCSForCalculationsForPortfolio("lala", null, dates));
        int expectedTimes = dates.size() / batchSize;
        verify(privateMarketsCalculationServer, times(expectedTimes)).calculateExposuresForMultipleDatesFund(anyString(), Mockito.eq(null), any());
    }

    @Test
    void sendDataToPMCSForCalculationsForPortfolio_WithBatchesFailure() {
        System.setProperty("whatIf", "false");
        int batchSize = 2;
        System.setProperty("pmcsBatchSize", Integer.toString(batchSize));
        final List<String> dates = Arrays.asList("09/26/2019", "09/27/2019", "09/28/2019","09/29/2020");
        when(privateMarketsCalculationServer.calculateExposuresForMultipleDatesFund(anyString(), Mockito.eq(null),any())).thenReturn(true, false);

        assertFalse(calculationServerService.sendDataToPMCSForCalculationsForPortfolio("lala", null, dates));
        int expectedTimes = dates.size() / batchSize;
        verify(privateMarketsCalculationServer, times(expectedTimes)).calculateExposuresForMultipleDatesFund(anyString(), Mockito.eq(null), any());
    }

    @Test
    void sendDataToPMCSForCalculationsForPortGroup() {
        System.setProperty("whatIf", "false");
        when(privateMarketsCalculationServer.calculateExposuresForMultipleDatesPortfolio(anyString(),any())).thenReturn(true);
        assertTrue(calculationServerService.sendDataToPMCSForCalculationsForPortGroup("lala", "09/26/2019"));
    }

    @Test
    void testSendDataToPMCSForCalculationsForPortGroup_WhatIf_true() {
        System.setProperty("whatIf", "true");
        CalculationServerService calculationServerService = new CalculationServerServiceImpl(privateMarketsCalculationServer);
        assertFalse(calculationServerService.sendDataToPMCSForCalculationsForPortGroup("lala", "09/26/2019"));
    }

    @Test
    void testSendDataToPMCSForCalculationsForPortfolio_WhatIf_true() {
        System.setProperty("whatIf", "true");
        CalculationServerService calculationServerService = new CalculationServerServiceImpl(privateMarketsCalculationServer);
        assertFalse(calculationServerService.sendDataToPMCSForCalculationsForPortfolio("lala", "cusip", Arrays.asList("09/26/2019")));
    }
}