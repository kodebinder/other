package com.bfm.aap.pmdx.exposurecoordinator.helper;

import com.bfm.aap.pmdx.exposurecoordinator.model.RerunRequest;

import java.util.Arrays;
import java.util.List;

/**
 * @author - Rahul Dev Mishra
 * @date - 6/2/2020-11:03 AM
 */
public class RerunRequestTestHelper {

    public static List<RerunRequest> createMockrerunRequests() {
        return Arrays.asList(mock_1(), mock_2(), mock_3());
    }

    public  static RerunRequest mock_1() {
        return RerunRequest.builder()
                .portfolioName("LEH_TSY")
                .portfolioCusip("B02487567")
                .build();
    }

    public  static RerunRequest mock_2() {
        return RerunRequest.builder()
                .portfolioName("L-MUNIF")
                .portfolioCusip("09248U817")
                .build();
    }

    public  static RerunRequest mock_3() {
        return RerunRequest.builder()
                .portfolioName("GENFUND")
                .portfolioCusip("B00454775")
                .build();
    }
}
