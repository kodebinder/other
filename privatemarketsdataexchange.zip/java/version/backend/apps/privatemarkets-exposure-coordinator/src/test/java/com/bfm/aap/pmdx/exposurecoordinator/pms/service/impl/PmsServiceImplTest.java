package com.bfm.aap.pmdx.exposurecoordinator.pms.service.impl;

import com.bfm.aap.pmdx.exposurecoordinator.model.PMSFileRequest;
import com.bfm.aap.pmdx.exposurecoordinator.util.RunTimeUtil;
import com.bfm.aap.privatemarkets.common.io.Directory;
import com.bfm.util.BFMDate;
import com.bfm.util.BFMDateConstants;
import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

@RunWith(PowerMockRunner.class)
@PrepareForTest({Directory.class})
public class PmsServiceImplTest {

    @Rule
    public ExpectedException exception = ExpectedException.none();

    @InjectMocks
    private PmsServiceImpl pmsService;

    @Mock
    private RunTimeUtil runTimeUtil;

    @BeforeClass
    public static void beforeClass() {
    	System.setProperty("defaultWebServer", "https://dev.blackrock.com");
        System.setProperty("pms_portfolio_settings", "PMS_PORTFOLIO_SETTINGS");
        System.setProperty("pms_portfolio_directory", "PMS_PORTFOLIO_DIRECTORY");
        System.setProperty("pms_portfolio_group_settings", "PMS_PORTFOLIO_GROUP_SETTINGS");
        System.setProperty("pms_portfolio_group_directory", "PMS_PORTFOLIO_GROUP_DIRECTORY");
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        Whitebox.setInternalState(pmsService, "pmsCommandForFile", "pms_batch.pl -file @filePath " +
                "-cmd \"@date  @pmsPortfolioSettings\" " +
                "-dir @pmsPortfolioDirectory " +
                "-tag \"Run PMS command for @filePath @date\" " +
                "-pri @priority");
        Whitebox.setInternalState(pmsService, "pmsCommandForPortfolioGroup", "@pmsPortfolioGroupSettings - @pmsPortfolioGroupDirectory");
        Whitebox.setInternalState(pmsService, "runTimeUtil", runTimeUtil);
    }


    @Test
    public void testRunPMSCommandForPortfolio_IfSystemPropertyAreNotSet() throws ReflectiveOperationException {
        mockStatic(Directory.class);
        setFinalStaticField(PmsServiceImpl.class, "PMS_PORTFOLIO_SETTINGS", null);
        setFinalStaticField(PmsServiceImpl.class, "PMS_PORTFOLIO_DIRECTORY", null);
        Mockito.doNothing().when(runTimeUtil).execute(anyString());
        pmsService.runPMSCommandForFile(mockPMSFileRequests().get(0));
        Mockito.verify(runTimeUtil, Mockito.times(1)).execute(anyString());
    }

    @Test
    public void testRunPMSCommandForPortfolioGroup_Success() {
        Mockito.doNothing().when(runTimeUtil).execute(anyString());
        pmsService.runPMSCommandForPortGroup("lala", "11/25/2019");
        Mockito.verify(runTimeUtil, Mockito.times(1)).execute(anyString());
    }
    @Test
    public void testRunPMSCommandForPortfolioGroup_IfSystemPropertyAreNotSet() throws ReflectiveOperationException {
        setFinalStaticField(PmsServiceImpl.class, "PMS_PORTFOLIO_SETTINGS", null);
        setFinalStaticField(PmsServiceImpl.class, "PMS_PORTFOLIO_GROUP_DIRECTORY", null);
        Mockito.doNothing().when(runTimeUtil).execute(anyString());
        pmsService.runPMSCommandForPortGroup("lala", "11/25/2019");
        Mockito.verify(runTimeUtil, Mockito.times(1)).execute(anyString());
    }

    @Test
    public void getPortfolioSettingsTest_withVMArg() throws ReflectiveOperationException {
        setFinalStaticField(PmsServiceImpl.class, "PMS_PORTFOLIO_SETTINGS", "test_'portfolio'_settings");
        assertEquals("test_portfolio_settings", pmsService.getPortfolioSettings());
    }

    @Test
    public void getPortfolioSettingsTest_withEmptyVMArg() throws ReflectiveOperationException {
        setFinalStaticField(PmsServiceImpl.class, "PMS_PORTFOLIO_SETTINGS", "");
        assertEquals(StringUtils.EMPTY, pmsService.getPortfolioSettings());
    }

    @Test
    public void  getPortfolioDirectoryTest_withVMArg() throws ReflectiveOperationException {
        setFinalStaticField(PmsServiceImpl.class, "PMS_PORTFOLIO_DIRECTORY", "test_'portfolio'_directory");
        assertEquals("test_'portfolio'_directory", pmsService.getPortfolioDirectory());
    }

    @Test
    public void getPortfolioDirectoryTest_withEmptyVMArg() throws ReflectiveOperationException {
        setFinalStaticField(PmsServiceImpl.class, "PMS_PORTFOLIO_DIRECTORY", "");
        assertEquals(StringUtils.EMPTY, pmsService.getPortfolioDirectory());
    }

    @Test
    public void getPortfolioGroupDirectoryTest_withVMArg() throws ReflectiveOperationException {
        setFinalStaticField(PmsServiceImpl.class, "PMS_PORTFOLIO_GROUP_DIRECTORY", "test_'portfolio'_group_directory");
        assertEquals("test_'portfolio'_group_directory", pmsService.getPortfolioGroupDirectory());
    }

    @Test
    public void getPortfolioGroupDirectoryTest_withEmptyVMArg() throws ReflectiveOperationException {
        setFinalStaticField(PmsServiceImpl.class, "PMS_PORTFOLIO_GROUP_DIRECTORY", "");
        assertEquals(StringUtils.EMPTY, pmsService.getPortfolioGroupDirectory());
    }

    @Test
    public void testRunPMSCommandForPortfolioGroup_withSpecialCharacters() throws ReflectiveOperationException {
        String expected = "-gpsettings GP:DAILY -pkg VEL-DLY -ignorePublish -profiling -org_code VE2";
        setFinalStaticField(PmsServiceImpl.class, "PMS_PORTFOLIO_SETTINGS", "-gpsettings&GP:DAILY&-pkg&VEL-DLY&-ignorePublish&-profiling&-org_code&VE2");
        String result = pmsService.getPortfolioSettings();
        assertEquals(result, expected);
    }

    private static void setFinalStaticField(Class<?> clazz, String fieldName, Object value) throws ReflectiveOperationException {
        Field field = clazz.getDeclaredField(fieldName);
        field.setAccessible(true);
        Field modifiers = Field.class.getDeclaredField("modifiers");
        modifiers.setAccessible(true);
        modifiers.setInt(field, field.getModifiers() & ~Modifier.FINAL);
        field.set(null, value);
    }

    static List<PMSFileRequest> mockPMSFileRequests() {
        PMSFileRequest p1 = PMSFileRequest.builder()
                .bfmDate (new BFMDate("20200102", BFMDateConstants.FMT_YYYYMMDD))
                .fileName("f1")
                .absoluteFileName("/t/f1.txt")
                .fileSize(1)
                .priority(9000)
                .build();
        PMSFileRequest p2 = PMSFileRequest.builder()
                .bfmDate (new BFMDate("20200103", BFMDateConstants.FMT_YYYYMMDD))
                .fileName("f2")
                .absoluteFileName("/t/f1.txt")
                .fileSize(1)
                .priority(8000).build();
        return Arrays.asList(p1, p2);
    }
}