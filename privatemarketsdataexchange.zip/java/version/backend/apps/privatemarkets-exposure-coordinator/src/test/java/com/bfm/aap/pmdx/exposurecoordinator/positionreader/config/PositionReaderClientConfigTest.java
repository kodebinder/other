package com.bfm.aap.pmdx.exposurecoordinator.positionreader.config;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bfm.aap.pmdx.position.reader.PrivateMarketsPositionReader;
import com.bfm.aap.pmdx.redblue.NetworkMode;
import com.bfm.aap.pmdx.redblue.RedBlueNetworkChecker;
import com.bfm.beam2.ServiceProxyFactories;
import com.bfm.beam2.ServiceProxyFactory;
import com.bfm.predicate.RedBlueBQLPredicate;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ServiceProxyFactories.class, RedBlueNetworkChecker.class})
public class PositionReaderClientConfigTest {

    @InjectMocks
    private PositionReaderClientConfig positionReaderClientConfig;

    @Before
    public void init() {
        System.setProperty("mode", "BLUE");
    }

    @Test
    public void testGetPrivateMarketsPositionReaderClient() {
        mockStatic(ServiceProxyFactories.class);
        mockStatic(RedBlueNetworkChecker.class);

        ServiceProxyFactory mockServiceProxyFactory = PowerMockito.mock(ServiceProxyFactory.class);
        PrivateMarketsPositionReader positionReader = PowerMockito.mock(PrivateMarketsPositionReader.class);
        RedBlueBQLPredicate redBlueBQLPredicate = PowerMockito.mock(RedBlueBQLPredicate.class);

        when(ServiceProxyFactories.bmsServiceProxyFactory(any(ServiceProxyFactories.SPFConfig.class))).thenReturn(mockServiceProxyFactory);
        when(RedBlueNetworkChecker.initDataSource()).thenReturn(true);
        when(RedBlueNetworkChecker.getPrimaryNetworkPredicate()).thenReturn(redBlueBQLPredicate);
        when(redBlueBQLPredicate.getPrimaryNetwork()).thenReturn(NetworkMode.BLUE);
        when(RedBlueNetworkChecker.getSourceIdByTypeAndColor(any(), any())).thenReturn(100);
        when(mockServiceProxyFactory.getServiceProxy(any(), any())).thenReturn(positionReader);

        assertNotNull(positionReaderClientConfig.getPrivateMarketsPositionReaderClient());
    }
}