package com.bfm.aap.pmdx.exposurecoordinator.util;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;

@RunWith(PowerMockRunner.class)
@PrepareForTest(Runtime.class)
public class RunTimeUtilTest {

    @InjectMocks
    private RunTimeUtil runTimeUtil;

    @Mock
    private Runtime mockRuntime;

    @Test
    public void execute_success() throws IOException {
        Whitebox.setInternalState(RunTimeUtil.class, "RUNTIME", mockRuntime);
        runTimeUtil.execute("lala");
        Mockito.verify(mockRuntime, Mockito.times(1)).exec(anyString());
    }


    @Test
    public void getPMCSTimeOutTestEmpty() {
        System.setProperty("pmcsTimeout", "");
        assertEquals(ExposureCoordinatorConstants.MAX_TIME_TO_WAIT, RunTimeUtil.getPMCSTimeout());
    }

    @Test
    public void getPMCSTimeOutTest() {
        System.setProperty("pmcsTimeout", "240");
        assertEquals(240, RunTimeUtil.getPMCSTimeout());
    }

    @Test
    public void getPositionReaderTimeoutTest() {
        System.setProperty("positionReaderTimeout", "600");
        assertEquals(600, RunTimeUtil.getPositionReaderTimeout());
    }

    @Test
    public void getPositionReaderTimeoutUnset() {
        System.clearProperty("positionReaderTimeout");
        assertEquals(ExposureCoordinatorConstants.MAX_TIME_TO_WAIT, RunTimeUtil.getPositionReaderTimeout());
    }

    @Test
    public void getPositionReaderTimeoutEmpty() {
        System.setProperty("positionReaderTimeout", "");
        assertEquals(ExposureCoordinatorConstants.MAX_TIME_TO_WAIT, RunTimeUtil.getPositionReaderTimeout());
    }

    @Test
    public void getPMCSBatchSizeTest() {
        int expected = 123;
        System.setProperty("pmcsBatchSize", Integer.toString(expected));
        assertEquals(expected, RunTimeUtil.getPMCSBatchSize());
    }

    @Test
    public void getPMCSBatchSizeUnset() {
        System.clearProperty("pmcsBatchSize");
        assertEquals(ExposureCoordinatorConstants.MAX_PMCS_BATCH_SIZE, RunTimeUtil.getPMCSBatchSize());
    }

    @Test
    public void getPMCSBatchSizeEmpty() {
        System.setProperty("pmcsBatchSize", "");
        assertEquals(ExposureCoordinatorConstants.MAX_PMCS_BATCH_SIZE, RunTimeUtil.getPMCSBatchSize());
    }

    @Test(expected = IllegalArgumentException.class)
    public void getPropertyWithUnsupportedKeyShouldThrowException() {
        RunTimeUtil.getProperty("unsupported key123");
    }
}