package com.bfm.aap.pmdx.exposurecoordinator.manager;

import com.bfm.aap.pmdx.exposurecoordinator.calculationserver.service.CalculationServerService;
import com.bfm.aap.pmdx.exposurecoordinator.model.PMSFileRequest;
import com.bfm.aap.pmdx.exposurecoordinator.notification.NotificationHandler;
import com.bfm.aap.pmdx.exposurecoordinator.pms.service.PmsService;
import com.bfm.aap.pmdx.exposurecoordinator.pms.service.writer.PMSFileGenerator;
import com.bfm.aap.pmdx.exposurecoordinator.positionreader.service.PositionReaderService;
import com.bfm.aap.pmdx.exposurecoordinator.rollforwardpositions.RollForwardPositionService;
import com.bfm.aap.pmdx.exposurecoordinator.util.DateUtil;
import com.bfm.aap.pmdx.model.Position;
import com.bfm.aap.pmdx.model.PositionReaderResponse;
import com.bfm.util.BFMDate;
import com.bfm.util.BFMDateConstants;
import com.google.protobuf.util.Timestamps;
import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest(DateUtil.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class ExposureManagerTest {

    @InjectMocks
    private ExposureManager exposureManager;

    @Mock
    private CalculationServerService calculationServerService;

    @Mock
    private PositionReaderService positionReaderService;

    @Mock
    private RollForwardPositionService rollForwardPositionService;

    @Mock
    private PmsService pmsService;

    @Mock
    private PMSFileGenerator pmsFileGenerator;

    @Mock
    private NotificationHandler exceptionHandler;

    @Before
    public void setup() {
        if(StringUtils.isNotEmpty(System.getProperty("skipPMCS"))) {
            System.getProperties().remove("skipPMCS");
        }
        if(StringUtils.isNotEmpty(System.getProperty("skipPMS"))) {
            System.getProperties().remove("skipPMS");
        }
        if(StringUtils.isNotEmpty(System.getProperty("skipPMSPortGroup"))) {
            System.getProperties().remove("skipPMSPortGroup");
        }
        System.setProperty("portGroup", "lala");
        System.setProperty("tDate", "09/26/1991");
        System.setProperty("holidayCalendar", "DK");
    }

    @Test
    public void execute() {
        System.setProperty("skipPMCS", "false");
        when(calculationServerService.sendDataToPMCSForCalculationsForPortfolio(anyString(), any(), any())).thenReturn(true);
        //doNothing().when(pmsService).runPMSCommandForPortfolio(any(), any());
        doNothing().when(pmsService).runPMSCommandForPortGroup(any(), any());
        when(positionReaderService.fetchPositions(anyString(), any())).thenReturn(mockPositionResponse());
        PowerMockito.mockStatic(DateUtil.class);
        PowerMockito.when(DateUtil.convertProtoTimeStampToString(any())).thenReturn("");
        exposureManager.execute();
        verify(positionReaderService, Mockito.times(1)).fetchPositions(any(), any());
    }

    @Test
    public void execute_throwExceptionInExecuteAllForToday() throws IOException {
        System.setProperty("skipPMCS", "false");
        when(calculationServerService.sendDataToPMCSForCalculationsForPortGroup(anyString(), any())).thenThrow(new RuntimeException());
        doNothing().when(pmsService).runPMSCommandForFile(any(PMSFileRequest.class));
        doNothing().when(pmsService).runPMSCommandForPortGroup(any(), any());
        when(positionReaderService.fetchPositions(anyString(), any())).thenReturn(mockPositionResponse());
        PowerMockito.mockStatic(DateUtil.class);
        PowerMockito.when(DateUtil.convertProtoTimeStampToString(any())).thenReturn("");
        PowerMockito.when(DateUtil.calculateMonthEndDates(any(), any(), any()))
                .thenReturn(Arrays.asList("20200102", "20200103"));
        when(pmsFileGenerator.generateFile(any())).thenReturn(mockPMSFileRequests());
        exposureManager.execute();

        verify(positionReaderService, Mockito.times(1)).fetchPositions(any(), any());
        verify(pmsService, Mockito.times(1)).runPMSCommandForPortGroup(anyString(), anyString());
        verify(pmsService, Mockito.times(2)).runPMSCommandForFile(any(PMSFileRequest.class));
    }

    @Test
    public void execute_throwExceptionInExecuteAllForBackDates() throws IOException {
        System.setProperty("skipPMCS", "false");
        when(calculationServerService.sendDataToPMCSForCalculationsForPortfolio(anyString(), any(), any())).thenThrow(new RuntimeException());
        doNothing().when(pmsService).runPMSCommandForFile(mockPMSFileRequests().get(0));
        doNothing().when(pmsService).runPMSCommandForPortGroup(any(), any());
        when(positionReaderService.fetchPositions(anyString(), any())).thenReturn(mockPositionResponse());

        PowerMockito.mockStatic(DateUtil.class);
        PowerMockito.when(DateUtil.convertProtoTimeStampToString(any())).thenReturn("");
        PowerMockito.when(DateUtil.calculateMonthEndDates(any(), any(), any()))
                .thenReturn(Arrays.asList("20200102", "20200103"));
        when(pmsFileGenerator.generateFile(any())).thenReturn(mockPMSFileRequests());
        exposureManager.execute();

        verify(positionReaderService, Mockito.times(1)).fetchPositions(any(), any());
        verify(pmsService, Mockito.times(1)).runPMSCommandForPortGroup(any(), any());
        verify(pmsService, Mockito.times(2)).runPMSCommandForFile(any(PMSFileRequest.class));
    }

    @Test
    public void execute_skipPMCS_setFlagToTrue() {
        System.setProperty("skipPMCS", "true");
        when(calculationServerService.sendDataToPMCSForCalculationsForPortfolio(anyString(), any(), any())).thenReturn(true);
        doNothing().when(pmsService).runPMSCommandForFile(mockPMSFileRequests().get(0));
        doNothing().when(pmsService).runPMSCommandForPortGroup(any(), any());
        when(positionReaderService.fetchPositions(anyString(), any())).thenReturn(mockPositionResponse());
        PowerMockito.mockStatic(DateUtil.class);
        PowerMockito.when(DateUtil.convertProtoTimeStampToString(any())).thenReturn("");
        exposureManager.execute();
        verify(positionReaderService, Mockito.times(1)).fetchPositions(any(), any());

    }

    @Test
    public void execute_skipPMCS_setNoFlag() {
        when(calculationServerService.sendDataToPMCSForCalculationsForPortfolio(anyString(), any(), any())).thenReturn(true);
        doNothing().when(pmsService).runPMSCommandForFile(mockPMSFileRequests().get(0));
        doNothing().when(pmsService).runPMSCommandForPortGroup(any(), any());
        when(positionReaderService.fetchPositions(anyString(), any())).thenReturn(mockPositionResponse());
        PowerMockito.mockStatic(DateUtil.class);
        PowerMockito.when(DateUtil.convertProtoTimeStampToString(any())).thenReturn("");
        exposureManager.execute();
        verify(positionReaderService, Mockito.times(1)).fetchPositions(any(), any());
    }

    @Test
    public void shouldSkipPMCS_setFlagTrue() {
        System.setProperty("skipPMCS", "true");
        assertTrue(exposureManager.shouldSkipPMCS());
    }

    @Test
    public void shouldSkipPMCS_setFlagFalse() {
        System.setProperty("skipPMCS", "false");
        assertFalse(exposureManager.shouldSkipPMCS());
    }

    @Test
    public void shouldSkipPMCS_setNoFlag() {
        assertFalse(exposureManager.shouldSkipPMCS());
    }

    @Test
    public void shouldSkipPMSForBackDatesTest_vmArgNotSet() {
        assertFalse(exposureManager.shouldSkipPMSForBackDates());
    }

    @Test
    public void shouldSkipPMSForBackDatesTest_vmArgSetToTrue() {
        System.setProperty("skipPMS", "true");
        assertTrue(exposureManager.shouldSkipPMSForBackDates());
    }

    @Test
    public void shouldSkipPMSForBackDatesTest_vmArgSetToFalse() {
        System.setProperty("skipPMS", "false");
        assertFalse(exposureManager.shouldSkipPMSForBackDates());
    }

    @Test
    public void shouldSkipPMSForBackDatesTest_emptyVmArgSet() {
        System.setProperty("skipPMS", "");
        assertFalse(exposureManager.shouldSkipPMSForBackDates());
    }

    @Test
    public void shouldSkipPMSForTodayTest_vmArgNotSet() {
        assertFalse(exposureManager.shouldSkipPMSForToday());
    }

    @Test
    public void shouldSkipPMSForTodayTest_vmArgSetToTrue() {
        System.setProperty("skipPMSPortGroup", "true");
        assertTrue(exposureManager.shouldSkipPMSForToday());
    }

    @Test
    public void shouldSkipPMSForTodayTest_vmArgSetToFalse() {
        System.setProperty("skipPMSPortGroup", "false");
        assertFalse(exposureManager.shouldSkipPMSForToday());
    }

    @Test
    public void shouldSkipPMSForTodayTest_emptyVmArgSet() {
        System.setProperty("skipPMSPortGroup", "");
        assertFalse(exposureManager.shouldSkipPMSForToday());
    }

    public static Position.Builder mockPositionBuilder() {
        com.google.protobuf.Timestamp posDate = Timestamps.fromMillis(java.sql.Timestamp.valueOf("2019-09-26 00:00:00.0").getTime());
        return Position.newBuilder()
                .setPortfolioName("PEEXPTST2")
                .setLastReferenceDate(posDate)
                .setPortfolioCode(3686);
    }

    public static Position.Builder mockPositionBuilder1() {
        com.google.protobuf.Timestamp posDate = Timestamps.fromMillis(java.sql.Timestamp.valueOf("2018-03-29 00:00:00.0").getTime());
        return Position.newBuilder()
                .setPortfolioName("PRIV001936")
                .setLastReferenceDate(posDate)
                .setPortfolioCode(2606);
    }

    static PositionReaderResponse mockPositionResponse() {
        PositionReaderResponse builder = PositionReaderResponse.newBuilder().setMessage("true").addPosition(mockPositionBuilder()).addPosition(mockPositionBuilder1()).setSuccess(true).build();
        return builder;
    }

    static List<PMSFileRequest> mockPMSFileRequests() {
        PMSFileRequest p1 = PMSFileRequest.builder()
                .bfmDate (new BFMDate("20200102", BFMDateConstants.FMT_YYYYMMDD))
                .absoluteFileName("f1")
                .fileSize(1).build();
        PMSFileRequest p2 = PMSFileRequest.builder()
                .bfmDate (new BFMDate("20200103", BFMDateConstants.FMT_YYYYMMDD))
                .absoluteFileName("f2")
                .fileSize(1).build();
        return Arrays.asList(p1, p2);
    }
}