package com.bfm.aap.pmdx.exposurecoordinator.price;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.bfm.aap.pmdx.exposurecoordinator.notification.NotificationHandler;
import com.bfm.aap.privatemarkets.dao.SpdbDao;
import com.bfm.aap.privatemarkets.dao.model.Spdb;
import com.bfm.aap.privatemarkets.dao.model.SpdbKey;
import com.bfm.util.BFMDateTime;
import com.bfm.util.BFMTime.BFMTimeException;
import com.bfm.util.Pair;

@ExtendWith(MockitoExtension.class)
class PriceLoadServiceImplTest {

	@Mock
	private FileReadService fileReadService;
	@Mock
	private SpdbDao spdbDao;
	@Mock
	private NotificationHandler notificationHandler;
	@InjectMocks
	private PriceLoadServiceImpl priceLoadServiceImpl;
	private static final String CUSIP = "RTTAL20J7";
	private static final String MARK_DATE = "20201030";
	private static final String PURPOSE = "EFRO";
	private static final String SOURCE = "E";
	private static final String NON_EXISTING_CUSIP = "RTTAL20J0";

	@BeforeEach
	public void setUp() {
		System.setProperty("defaultWebServer", "https://dev.blackrock.com");
		System.setProperty("tDate", "20201230");
		System.setProperty("AUTH_METHOD", "SERVER");
	}

	@Test
	void testLoadPrice_ExistingData() throws IOException, NumberFormatException, BFMTimeException {
		doNothing().when(notificationHandler).notifySuccess(Mockito.anyString());
		Mockito.when(fileReadService.getCusipsWithPositionDate()).thenReturn(getCusipsWithPositionDate());
		Mockito.when(spdbDao.getByCusipDateAndPurpose(Mockito.anyString(), Mockito.any(BFMDateTime.class),
				Mockito.anyString())).thenReturn(getExistingData());
		priceLoadServiceImpl.loadPrice();
		verify(spdbDao, times(2)).getByCusipDateAndPurpose(CUSIP, new BFMDateTime(MARK_DATE), PURPOSE);
		verify(spdbDao, times(0)).insert(Mockito.any(Spdb.class));
	}

	@Test
	void testLoadPrice_NonExistingData() throws IOException, NumberFormatException, BFMTimeException {
		doNothing().when(notificationHandler).notifySuccess(Mockito.anyString());
		Mockito.when(fileReadService.getCusipsWithPositionDate()).thenReturn(getCusipsWithPositionDate());
		doNothing().when(spdbDao).insert(Mockito.any(Spdb.class));
		Mockito.when(spdbDao.getByCusipDateAndPurpose(Mockito.anyString(), Mockito.any(BFMDateTime.class),
				Mockito.anyString())).thenReturn(getEmptyData());
		priceLoadServiceImpl.loadPrice();
		verify(spdbDao, times(2)).getByCusipDateAndPurpose(CUSIP, new BFMDateTime(MARK_DATE), PURPOSE);
		verify(spdbDao, times(4)).insert(Mockito.any(Spdb.class));
	}

	private List<Pair<String, String>> getCusipsWithPositionDate() {
		List<Pair<String, String>> dataList = new ArrayList<>();
		Pair<String, String> pair = Pair.of(CUSIP, MARK_DATE);
		dataList.add(pair);
		return dataList;
	}

	private Optional<Spdb> getExistingData() throws NumberFormatException, BFMTimeException {
		Spdb data = new Spdb();
		SpdbKey key = new SpdbKey();
		key.setCusip(CUSIP);
		key.setMarkDateTime(new BFMDateTime(MARK_DATE));
		key.setPurpose(PURPOSE);
		data.setKey(key);
		data.setSource(SOURCE);
		return Optional.of(data);
	}

	private Optional<Spdb> getNotExistingData() throws NumberFormatException, BFMTimeException {
		Spdb data = new Spdb();
		SpdbKey key = new SpdbKey();
		key.setCusip(NON_EXISTING_CUSIP);
		key.setMarkDateTime(new BFMDateTime(MARK_DATE));
		key.setPurpose(PURPOSE);
		data.setKey(key);
		data.setSource(SOURCE);
		return Optional.of(data);
	}

	private Optional<Spdb> getEmptyData() {
		return Optional.empty();
	}

}
