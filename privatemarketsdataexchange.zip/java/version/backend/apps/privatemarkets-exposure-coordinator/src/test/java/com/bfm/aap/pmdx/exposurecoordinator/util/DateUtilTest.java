package com.bfm.aap.pmdx.exposurecoordinator.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bfm.util.BFMDate;
import com.bfm.util.HolidayCalendar;
import com.google.protobuf.util.Timestamps;

@RunWith(PowerMockRunner.class)
public class DateUtilTest {

	@Mock
	private BFMDate bfmDate;

	@Before
	public void init() {
		System.setProperty("defaultWebServer", "https://dev.blackrock.com");
		
	}
	
	@Test
	public void TestConvertProtoTimeStampToString() {
		com.google.protobuf.Timestamp posDate = Timestamps
				.fromMillis(java.sql.Timestamp.valueOf("2019-09-26 00:00:00.0").getTime());
		assertEquals(DateUtil.convertProtoTimeStampToString(posDate), "09/26/2019");
	}

	@Test
	public void calculateMonthEndDates() throws IOException {
		HolidayCalendar holidayCalendar = DateUtil.getHolidayCalendar("DK");
		assertNotNull(DateUtil.calculateMonthEndDates("10/25/2019", "3/6/2020", holidayCalendar));
	}

	@Test(expected = RuntimeException.class)
	public void calculateMonthEndDates_null_calendar() throws IOException {
		// ask if it needs to mock BFMDate?
		DateUtil.calculateMonthEndDates("10/25/2019", "3/6/2020", null);
	}

	@Test(expected = RuntimeException.class)
	public void calculateMonthEndDates_blank_calendar() throws IOException {
		// ask if it needs to mock BFMDate?
		DateUtil.calculateMonthEndDates("10/25/2019", "3/6/2020", null);
	}

	public void calculateMonthEndDates_gibberish_calendar() throws IOException {
		HolidayCalendar holidayCalendar = DateUtil.getHolidayCalendar("RANDOMABCD");
		List<String> dates = DateUtil.calculateMonthEndDates("5/25/2020", "6/6/2020", holidayCalendar);
		assertTrue(dates.size() > 0);
	}

	@Test
	public void calculateMonthEndDates_testWeekend() throws IOException {
		HolidayCalendar holidayCalendar = DateUtil.getHolidayCalendar("DK");
		List<String> dates = DateUtil.calculateMonthEndDates("5/25/2020", "6/6/2020", holidayCalendar);
		assertEquals(new BFMDate("05/29/2020"), new BFMDate(dates.get(0)));
	}

	@Test
	public void calculateMonthEndDates_testWeekdays() throws IOException {
		HolidayCalendar holidayCalendar = DateUtil.getHolidayCalendar("DK");
		List<String> dates = DateUtil.calculateMonthEndDates("8/25/2020", "9/6/2020", holidayCalendar);
		assertEquals(new BFMDate("08/31/2020"), new BFMDate(dates.get(0)));
	}

	@Test
	public void calculateMonthEndDates_testHolidayWeekendCombo() throws IOException {
		HolidayCalendar holidayCalendar = DateUtil.getHolidayCalendar("DK");
		List<String> dates = DateUtil.calculateMonthEndDates("12/24/2018", "1/6/2019", holidayCalendar);
		assertEquals(new BFMDate("12/28/2018"), new BFMDate(dates.get(0)));
	}
	
	@Test
	public void checkIfDatesAreEqual() {
		String date1 = "10/20/2020";
		String date2 = "10/20/2020";
		assertTrue(DateUtil.checkIfDatesAreEqual(date1, date2));
		date2 = DateUtil.getPreviousDate(date2);
		assertFalse(DateUtil.checkIfDatesAreEqual(date1, date2));
		HolidayCalendar holidayCalendar = DateUtil.getHolidayCalendar("DK");
		date2 = DateUtil.getPreviousBusinessDay(new BFMDate(date2), holidayCalendar).toString();
		assertFalse(DateUtil.checkIfDatesAreEqual(date1, date2));

	}
}