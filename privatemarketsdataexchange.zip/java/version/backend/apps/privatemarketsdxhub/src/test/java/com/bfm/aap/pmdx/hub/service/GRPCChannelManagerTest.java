package com.bfm.aap.pmdx.hub.service;


import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.util.lock.LockSupport;
import io.grpc.ConnectivityState;
import io.grpc.ManagedChannel;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import java.util.concurrent.CountDownLatch;

import static org.junit.Assert.assertEquals;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;


@RunWith(PowerMockRunner.class)
@PrepareForTest({ManagedChannel.class, AltsDataWorkspaceDAO.class})
public class GRPCChannelManagerTest extends BaseUnitTest {

    private ManagedChannel mockChannel;
    private GRPCChannelManager grpcChannelManager;
    private LockSupport lockSupport;
    private ServiceProvider serviceProvider;

    @Before
    public void init() {
        mockChannel = mock(ManagedChannel.class);
        serviceProvider = mock(ServiceProvider.class);
        grpcChannelManager = new GRPCChannelManager(mockChannel, serviceProvider);
        Whitebox.setInternalState(grpcChannelManager,"channelRetryInterval", 100);
        Whitebox.setInternalState(grpcChannelManager,"channelMonitorInterval", 50);
    }

    @Test
    public void monitorChannelStart() {
        //Arrange
        when(mockChannel.getState(false)).thenReturn(ConnectivityState.READY);

        //Act
        assertEquals(0, grpcChannelManager.getTerminatedLatch().getCount());
        grpcChannelManager.monitorChannel();

        //Verify
        assertEquals(1, grpcChannelManager.getTerminatedLatch().getCount());
    }

    @Test
    public void monitorChannelStop() {
        //Arrange
        when(mockChannel.getState(false)).thenReturn(ConnectivityState.SHUTDOWN);
        Whitebox.setInternalState(grpcChannelManager, "channelTerminatedLatch", new CountDownLatch(1));

        //Act
        assertEquals(1, grpcChannelManager.getTerminatedLatch().getCount());
        grpcChannelManager.monitorChannel();

        //Verify
        grpcChannelManager.getChannelRetryInterval();
        assertEquals(0, grpcChannelManager.getTerminatedLatch().getCount());
    }
}