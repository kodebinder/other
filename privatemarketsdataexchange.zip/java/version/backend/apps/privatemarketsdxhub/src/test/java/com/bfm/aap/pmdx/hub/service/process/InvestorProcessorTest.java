package com.bfm.aap.pmdx.hub.service.process;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.util.LibRedBlueProxy;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.model.util.NetworkModeHelper;
import com.bfm.aap.pmdx.notification.service.EmailNotification;
import com.google.protobuf.util.Timestamps;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.bfm.aap.pmdx.model.util.NetworkModeHelper.getCompliment;
import static org.junit.Assert.assertEquals;

@RunWith(PowerMockRunner.class)

@PrepareForTest({EmailNotification.class, LibRedBlueProxy.class})
public class InvestorProcessorTest extends BaseUnitTest {

    @InjectMocks
    InvestorProcessor investorProcessor;

    private final NetworkMode serverMode = NetworkModeHelper.getNetworkModeFromString(System.getProperty("mode"));

    @Before
    public void init() {
        investorProcessor.isPrimary = true;
    }

    @Test
    public void getLastSuccessfulTime() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        this.init(t1, t2, t3);
        List<Investor> poss = this.getInvestors(t1, t2, t3);
        //Act
        long lastSuccessfulTime = this.investorProcessor.getLastSuccessfulTime(poss);
        //Verify
        assertEquals(t3, lastSuccessfulTime);
    }

    @Test
    public void processEntity() throws Exception {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        this.init(t1, t2, t3);
        List<Investor> ports = this.getInvestors(t1, t2, t3);
        //invalid Performance
        ports.add(Investor.newBuilder().build());
        Investor.Builder pb = Investor.newBuilder(ports.get(0));
        pb.getEntityInfoBuilder().setNetworkMode(getCompliment(this.serverMode));
        ports.add(pb.build());

        //Act
        List<Investor> updatedPerformances = this.investorProcessor.processEntities(ports);

        //Verify
        assertEquals(ports.size() - 2, updatedPerformances.size());
        assertEquals(3, updatedPerformances.stream().filter(a -> a.getEntityInfo().getPrimaryData()).count());
        assertEquals(3, updatedPerformances.stream().filter(a -> a.getEntityInfo().getNetworkMode() == this.serverMode).count());
    }

    private List<Investor> getInvestors(long t1, long t2, long t3) {
        Investor.Builder fa1 = Investor.newBuilder();
        fa1.getEntityInfoBuilder().setNetworkMode(this.serverMode).setOriginTimestamp(Timestamps.fromMillis(t1));
        Investor.Builder fa2 = Investor.newBuilder();
        fa2.getEntityInfoBuilder().setNetworkMode(this.serverMode).setOriginTimestamp(Timestamps.fromMillis(t2));
        Investor.Builder fa3 = Investor.newBuilder();
        fa3.getEntityInfoBuilder().setNetworkMode(this.serverMode).setOriginTimestamp(Timestamps.fromMillis(t3));
        return new ArrayList<>(Arrays.asList(fa1.build(), fa2.build(), fa3.build()));
    }
}