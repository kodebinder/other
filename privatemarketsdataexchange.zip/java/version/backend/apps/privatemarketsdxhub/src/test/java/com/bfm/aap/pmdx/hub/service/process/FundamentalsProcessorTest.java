package com.bfm.aap.pmdx.hub.service.process;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.model.Fundamentals;
import com.bfm.aap.pmdx.model.util.LibRedBlueProxy;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.model.util.NetworkModeHelper;
import com.bfm.aap.pmdx.notification.service.EmailNotification;
import com.google.protobuf.util.Timestamps;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.bfm.aap.pmdx.model.util.NetworkModeHelper.getCompliment;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@RunWith(PowerMockRunner.class)

@PrepareForTest({EmailNotification.class, LibRedBlueProxy.class})
public class FundamentalsProcessorTest extends BaseUnitTest {

    @InjectMocks
    FundamentalsProcessor fundamentalsProcessor;

    private final NetworkMode serverMode = NetworkModeHelper.getNetworkModeFromString(System.getProperty("mode"));

    @Before
    public void init() {
        fundamentalsProcessor.isPrimary = true;
    }

    @Test
    public void getLastSuccessfulTime() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<Fundamentals> fundamentals = getFundamentals(t1, t2, t3);
        //Act
        long lastSuccessfulTime = fundamentalsProcessor.getLastSuccessfulTime(fundamentals);
        //Verify
        assertEquals(t3, lastSuccessfulTime);
    }

    @Test
    public void processEntities() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<Fundamentals> fundamentals = getFundamentals(t1, t2, t3);
        //invalid Fundamentals
        fundamentals.add(Fundamentals.newBuilder().setCompanyId("dummyID").setSource("Invalid fundamentals").build());
        Fundamentals.Builder fb= Fundamentals.newBuilder(fundamentals.get(0)).setCompanyId("id5");
        fb.getEntityInfoBuilder().setNetworkMode(getCompliment(serverMode));
        fundamentals.add(fb.build());

        //Act
        List<Fundamentals> updatedFundamentals = fundamentalsProcessor.processEntities(fundamentals);

        //Verify
        assertEquals(fundamentals.size() - 2, updatedFundamentals.size());
        assertEquals(3, updatedFundamentals.stream().filter(a -> a.getEntityInfo().getPrimaryData()).count());
        assertEquals(3, updatedFundamentals.stream().filter(a -> a.getEntityInfo().getNetworkMode() == serverMode).count());
    }

    @Test
    public void processEntities_PrimaryFlagTest() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<Fundamentals> fundamentals = getFundamentals(t1 + 1000, t2 + 1000, t3 + 1000);
        //invalid fundamentals
        fundamentals.add(Fundamentals.newBuilder().setCompanyId("dummyID").setSource("Invalid fundamentals").build());
        Fundamentals.Builder fb = Fundamentals.newBuilder(fundamentals.get(0)).setCompanyId("id5");
        fb.getEntityInfoBuilder().setOriginTimestamp(Timestamps.fromMillis(t1 - 1000));
        fundamentals.add(fb.build());

        //Act
        List<Fundamentals> updatedFundamentals = fundamentalsProcessor.processEntities(fundamentals);

        //Verify
        assertEquals(4, updatedFundamentals.size());
        assertEquals(4, updatedFundamentals.stream().filter(a -> a.getEntityInfo().getPrimaryData()).count());
        assertEquals(4, updatedFundamentals.stream().filter(a -> a.getEntityInfo().getNetworkMode() == serverMode).count());
    }

    @Test
    public void processEntity() throws Exception {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<Fundamentals> fundamentals = getFundamentals(t1 + 1000, t2 + 1000, t3 + 1000);

        //Act
        Fundamentals updatedFundamentals = fundamentalsProcessor.processEntity(fundamentals.get(0)
        );
        Fundamentals updatedFundamentals2 = fundamentalsProcessor.processEntity(fundamentals.get(1)
        );

        //Verify
        assertTrue(updatedFundamentals.getEntityInfo().getPrimaryData());
        assertTrue(updatedFundamentals2.getEntityInfo().getPrimaryData());
        assertEquals(serverMode, updatedFundamentals.getEntityInfo().getNetworkMode());
    }

    @Test
    public void processEntity_InvalidEntity() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<Fundamentals> fundamentals = getFundamentals(t1 + 1000, t2 + 1000, t3 + 1000);

        //Act
        try {
            fundamentalsProcessor.processEntity(fundamentals.get(0)
            );
//            fail();
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("Invalid entity info for"));
        }
    }

    private List<Fundamentals> getFundamentals(long t1, long t2, long t3) {
        Fundamentals.Builder fa1 = Fundamentals.newBuilder().setCompanyId("id1");
        fa1.getEntityInfoBuilder().setNetworkMode(serverMode).setOriginTimestamp(Timestamps.fromMillis(t1));
        Fundamentals.Builder fa2 = Fundamentals.newBuilder().setCompanyId("id2");
        fa2.getEntityInfoBuilder().setNetworkMode(serverMode).setOriginTimestamp(Timestamps.fromMillis(t2));
        Fundamentals.Builder fa3 = Fundamentals.newBuilder().setCompanyId("id3");
        fa3.getEntityInfoBuilder().setNetworkMode(serverMode).setOriginTimestamp(Timestamps.fromMillis(t3));
        return new ArrayList<>(Arrays.asList(fa1.build(), fa2.build(), fa3.build()));
    }
}
