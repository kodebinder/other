package com.bfm.aap.pmdx.hub.service.entity;

import io.grpc.ManagedChannel;
import io.grpc.stub.AbstractStub;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.CompanyResponse;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.aap.pmdx.services.CompanyRequest;
import com.bfm.aap.pmdx.services.CompanyServiceGrpc;
import com.bfm.service.ServiceException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.doThrow;

@RunWith(PowerMockRunner.class)
@PrepareForTest(CompanyServiceGrpc.CompanyServiceBlockingStub.class)
public class CompanyServiceClientTest extends BaseUnitTest {

    private CompanyServiceClient companyServiceClient;

    @Mock
    private RPCServiceClient rpcServiceClient;

    @Mock
    private EntityProcessor<Company> entityProcessor;

    @Mock
    private ManagedChannel channel;

    private ClientInfo clientInfo;

    private CompanyServiceGrpc.CompanyServiceBlockingStub companyServiceBlockingStub;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        companyServiceBlockingStub = PowerMockito.mock(CompanyServiceGrpc.CompanyServiceBlockingStub.class);
        this.companyServiceClient = new CompanyServiceClient(rpcServiceClient, channel, entityProcessor);
    }

    @Test
    public void fetchEntitiesSinceTest() {
        //Act
        this.companyServiceClient.fetchEntitiesSince(System.currentTimeMillis(), buildTestClientInfoWithAllEntityType("Dummy", "dummy"), InvestUtils.DataSource.FIA);

        //Verify
        verify(rpcServiceClient).doFetchSince(any(), any(), any(), any(), any(ClientInfo.class), anyLong());
    }

    @Test
    public void updateCompanyTest() {
        clientInfo = buildTestClientInfoWithAllEntityType("Dummy", "dummy");
        when(rpcServiceClient.getStubWithInterceptor(any(AbstractStub.class), any(ClientInfo.class))).thenReturn(companyServiceBlockingStub);

        CompanyResponse response = CompanyResponse.newBuilder().setIsUpdated(true).setData(Company.newBuilder().build()).build();
        when(companyServiceBlockingStub.updateCompany(any(CompanyRequest.class))).thenReturn(response);
        companyServiceClient.updateCompany(CompanyRequest.newBuilder().setCompany(Company.newBuilder().setCompanyId("123").build()).build(), clientInfo, 1234);
        verify(companyServiceBlockingStub).updateCompany(any(CompanyRequest.class));
        assertThat(response.getData().getCompanyId()).isEmpty();
    }

    @Test
    public void updateCompanyTest_without_response() {
        clientInfo = buildTestClientInfoWithAllEntityType("Dummy", "dummy");
        when(rpcServiceClient.getStubWithInterceptor(any(AbstractStub.class), any(ClientInfo.class))).thenReturn(companyServiceBlockingStub);

        CompanyResponse response = CompanyResponse.newBuilder().setIsUpdated(false).setData(Company.newBuilder().build()).build();
        when(companyServiceBlockingStub.updateCompany(any(CompanyRequest.class))).thenReturn(response);
        companyServiceClient.updateCompany(CompanyRequest.newBuilder().setCompany(Company.newBuilder().setCompanyId("123").build()).build(), clientInfo, 1234);
        verify(companyServiceBlockingStub).updateCompany(any(CompanyRequest.class));
        assertThat(response.getData().getCompanyId()).isEmpty();
    }

    @Test
    public void updateCompanyTest_Failure() {
        clientInfo = buildTestClientInfoWithAllEntityType("Dummy", "dummy");
        when(rpcServiceClient.getStubWithInterceptor(any(AbstractStub.class), any(ClientInfo.class))).thenReturn(companyServiceBlockingStub);
        doThrow(new RuntimeException("grpc failure")).when(companyServiceBlockingStub).updateCompany(any(CompanyRequest.class));
        try {
            companyServiceClient.updateCompany(CompanyRequest.getDefaultInstance(), clientInfo, 1234);
        } catch (ServiceException ex) {
            assertTrue(ex.getMessage().contains("gRPC request failed"));
        }
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testGetEntity() {
        companyServiceClient.getEntity(null);
    }

}