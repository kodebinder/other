package com.bfm.aap.pmdx.hub.model;

import java.nio.file.Path;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bfm.aap.pmdx.hub.BaseUnitTest;

import static org.junit.Assert.assertTrue;

@RunWith(PowerMockRunner.class)
public class CertHelperTest extends BaseUnitTest {

	@Test
	public void initAndTestPaths() {
		// Arrange
		Path expectedCert = CertHelper.getCertPath();
		Path expectedkey = CertHelper.getPrivateKeyPath();
		Path expectedCa = CertHelper.getCaPath();
		// Verify
		assertTrue(expectedCert.toString().contains("DEV-hub-blue.cer"));
		assertTrue(expectedkey.toString().contains("DEV-hub-blue.key"));
		assertTrue(expectedCa.toString().contains("HubParentChain.crt"));
	}

}
