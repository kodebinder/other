package com.bfm.aap.pmdx.hub.service;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.quartz.SchedulerException;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.hub.repository.ClientInfoDAO;
import com.bfm.aap.pmdx.hub.service.async.HeartBeatService;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.privatemarkets.common.scheduler.TaskScheduler;

@RunWith(PowerMockRunner.class)
@PrepareForTest({TaskScheduler.class, HeartBeatService.class})
public class ServiceProviderTest extends BaseUnitTest {

    private HeartBeatService heartBeatService;
    private ClientInfoDAO clientInfoDAO;
    private TaskScheduler taskScheduler;
    private ServiceProvider serviceProvider;

    @Before
    public void init() {
        heartBeatService = mock(HeartBeatService.class);
        clientInfoDAO = mock(ClientInfoDAO.class);
        taskScheduler = mock(TaskScheduler.class);
        serviceProvider = new ServiceProvider(heartBeatService, clientInfoDAO, taskScheduler);

        List<ClientInfo> crmClients = getAllTestClientInfo(Arrays.asList("TESTDEV", "AladdinInvestDemo"));
        List<ClientInfo> investmentClients = getAllTestClientInfo(Arrays.asList("TESTABC", "ALD-INV-DEMO"));
        when(this.clientInfoDAO.getCRMClients()).thenReturn(crmClients);
        when(this.clientInfoDAO.getInvestmentClients()).thenReturn(investmentClients);
    }

    @Test
    public void executeServices() {
        //Arrange

        //Act
        serviceProvider.execute();

        //Verify
        serviceProvider.stopExecutors();
        assertEquals(0, serviceProvider.getTerminatedLatch().getCount());
    }

    @Test
    public void executeServices_Exception() throws SchedulerException {
        //Arrange
        doThrow(new SchedulerException()).when(taskScheduler).scheduleRecurring(any(Runnable.class), anyString(), anyInt());

        //Act
        serviceProvider.execute();

        //Verify
        assertEquals(1, serviceProvider.getTerminatedLatch().getCount());
    }
}
