package com.bfm.aap.pmdx.hub.service.entity;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.model.InvestorAccount;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import io.grpc.ManagedChannel;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.modules.junit4.PowerMockRunner;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.verify;

@RunWith(PowerMockRunner.class)
public class InvestorAccountServiceClientTest extends BaseUnitTest {

    private InvestorAccountServiceClient investorAccountServiceClient;

    @Mock
    private RPCServiceClient rpcServiceClient;

    @Mock
    private EntityProcessor<InvestorAccount> entityProcessor;

    @Mock
    private ManagedChannel channel;

    @Before
    public void init() {
        this.investorAccountServiceClient = new InvestorAccountServiceClient(rpcServiceClient, channel, entityProcessor);
    }

    @Test
    public void fetchEntitiesSinceTest() {
        //Act
        this.investorAccountServiceClient.fetchEntitiesSince(System.currentTimeMillis(), buildTestClientInfoWithAllEntityType("Dummy", "dummy"), null);

        //Verify
        verify(rpcServiceClient).doFetchSince(any(), any(), any(), any(), any(ClientInfo.class), anyLong());
    }
}
