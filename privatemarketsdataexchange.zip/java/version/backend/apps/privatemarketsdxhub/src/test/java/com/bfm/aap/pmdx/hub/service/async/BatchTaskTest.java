package com.bfm.aap.pmdx.hub.service.async;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.hub.model.ExecutionStatus;
import com.bfm.aap.pmdx.hub.model.async.TaskResult;
import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.aap.pmdx.hub.repository.ClientInfoDAO;
import com.bfm.aap.pmdx.hub.service.entity.AssetServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.BankAccountServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.BankOperationServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.CompanyServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.ContactServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.FundamentalsServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.InstrumentServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.InvestorAccountServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.InvestorServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.PerformanceServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.PortfolioServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.PositionServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.ShareClassServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.TransactionsServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.UserServiceClient;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.aap.pmdx.transformer.util.TransformerClientServiceHelper;
import com.bfm.metric.StatCollectorMeterRegistry;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Maps;
import io.micrometer.core.instrument.Counter;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import static com.bfm.aap.pmdx.hub.util.AppConstants.NETWORK_MODE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.Mockito.anyDouble;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore("javax.net.ssl.*")
@PrepareForTest({StatCollectorMeterRegistry.class, LoggerFactory.class, ZookeeperHelper.class})
public class BatchTaskTest extends BaseUnitTest {

    @Mock
    AssetServiceClient assetServiceClient;
    @Mock
    PortfolioServiceClient portfolioServiceClient;
    @Mock
    PositionServiceClient positionServiceClient;
    @Mock
    PerformanceServiceClient performanceServiceClient;
    @Mock
    FundamentalsServiceClient fundamentalsServiceClient;
    @Mock
    TransactionsServiceClient transactionsServiceClient;
    @Mock
    ShareClassServiceClient shareClassServiceClient;
    @Mock
    UserServiceClient userServiceClient;
    @Mock
    ContactServiceClient contactServiceClient;
    @Mock
    CompanyServiceClient companyServiceClient;
    @Mock
    InvestorServiceClient investorServiceClient;
    @Mock
    InvestorAccountServiceClient investorAccountServiceClient;
    @Mock
    AltsDataWorkspaceDAO altsDataWorkspaceDAO;
    @Mock
    InstrumentServiceClient instrumentsServiceClient;
    @Mock
    BankAccountServiceClient bankAccountServiceClient;
    @Mock
    BankOperationServiceClient bankOperationServiceClient;
    @Mock
    TransformerClientServiceHelper transformerServiceHelper;
    @Mock
    ClientInfoDAO clientInfoDAO;
    @Mock
    Counter counter;
    @Mock
    Logger LOGGER;
    private ZookeeperHelper zookeeperHelper;
    private StatCollectorMeterRegistry registry;
    BatchTask batchTask;
    private ClientInfo client;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        mockStatic(StatCollectorMeterRegistry.class);
        zookeeperHelper = PowerMockito.mock(ZookeeperHelper.class);
        registry = PowerMockito.mock(StatCollectorMeterRegistry.class);
        when(StatCollectorMeterRegistry.getInstance()).thenReturn(registry);
        batchTask = Mockito.spy(new BatchTask(transformerServiceHelper, clientInfoDAO, assetServiceClient, portfolioServiceClient, positionServiceClient, performanceServiceClient,
                bankOperationServiceClient,
                fundamentalsServiceClient, transactionsServiceClient, shareClassServiceClient, instrumentsServiceClient, bankAccountServiceClient, userServiceClient, contactServiceClient, companyServiceClient, investorServiceClient, investorAccountServiceClient, zookeeperHelper));
        when(registry.counter(anyString(), anyString(), any())).thenReturn(counter);
        Whitebox.setInternalState(batchTask, "concurrentBatchCount", 5);
        Whitebox.setInternalState(batchTask, "metricRegistry", registry);
    }

    @Test
    public void processTaskAsyncAsset() throws Exception {

        client = buildTestClientInfoWithAssetBankAccountAndBankOperation("Dummy", "dummy");
        //Arrange
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Set<String> assSet = new HashSet<>();
        assSet.add("guid1");
        assSet.add("guid2");
        when(assetServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925689));

        Set<String> bankAccount = new HashSet<>();
        bankAccount.add("guid1");
        bankAccount.add("guid2");
        when(bankAccountServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(bankAccount, 1604925677));

        Set<String> bankOperation = new HashSet<>();
        bankOperation.add("guid1");
        bankOperation.add("guid2");
        when(bankOperationServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(bankOperation, 1604925677));

        when(clientInfoDAO.getClientByName(client.getClientName()))
                .thenReturn(client);
        when(altsDataWorkspaceDAO.fetchLastSuccessfulTime(NETWORK_MODE, "dummy-guid")).thenReturn(12345L);
        Map<String, ExecutionStatus> statusMap = new HashMap<>();
        AtomicInteger integer = new AtomicInteger(0);

        //Act
        batchTask.init();
        verify(batchTask, never()).submitTask(anyString(), anyLong(), any(AtomicInteger.class), anyMap(), any());
        batchTask.submitTask("Dummy", 1604925680, integer, statusMap, client);

        //Verify
        ArgumentCaptor<Long> argumentCaptor = ArgumentCaptor.forClass(Long.class);
        verify(zookeeperHelper, times(1))
                .updateChildNodeStatusToComplete(eq("Dummy"), any(), argumentCaptor.capture());
        assertThat(argumentCaptor.getValue()).isEqualTo(1604925680);
        verify(transformerServiceHelper, times(1)).loadReferenceEntities(any());
        verify(portfolioServiceClient, times(0)).fetchEntitiesSince(any(Long.class), any(ClientInfo.class), any(InvestUtils.DataSource.class));
        verify(positionServiceClient, times(0)).fetchEntitiesSince(any(Long.class), any(ClientInfo.class), any(InvestUtils.DataSource.class));
        assertThat(integer.get()).isZero();
        assertThat(statusMap).containsEntry("Dummy", ExecutionStatus.COMPLETED);

        executorService.shutdownNow();
    }

    @Test
    public void processTaskAsyncAsset_SuccessfulTimeNotUpdated() throws Exception {

        client = buildTestClientInfoWithAssetBankAccountAndBankOperation("Dummy", "dummy");
        //Arrange
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Set<String> assSet = new HashSet<>();
        assSet.add("guid1");
        assSet.add("guid2");
        when(assetServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925677));

        Set<String> bankAccount = new HashSet<>();
        bankAccount.add("guid1");
        bankAccount.add("guid2");
        when(bankAccountServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(bankAccount, 1604925677));

        Set<String> bankOperation = new HashSet<>();
        bankOperation.add("guid1");
        bankOperation.add("guid2");
        when(bankOperationServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(bankOperation, 1604925677));

        when(clientInfoDAO.getClientByName(client.getClientName()))
                .thenReturn(client);
        when(altsDataWorkspaceDAO.fetchLastSuccessfulTime(NETWORK_MODE, "dummy-guid")).thenReturn(12345L);
        Map<String, ExecutionStatus> statusMap = new HashMap<>();
        AtomicInteger integer = new AtomicInteger(0);

        //Act
        batchTask.init();
        batchTask.submitTask("Dummy", 1604925680, integer, statusMap, client);

        //Verify
        ArgumentCaptor<Long> argumentCaptor = ArgumentCaptor.forClass(Long.class);
        verify(zookeeperHelper, times(1))
                .updateChildNodeStatusToComplete(eq("Dummy"), any(), argumentCaptor.capture());
        assertThat(argumentCaptor.getValue()).isEqualTo(1604925680);
        // Transformer NOT called since last successful time not updated.
        verify(transformerServiceHelper, times(2)).extractTransformLoad(any(EntityType.class), any());
        verify(portfolioServiceClient, times(0)).fetchEntitiesSince(any(Long.class), any(ClientInfo.class), any(InvestUtils.DataSource.class));
        verify(positionServiceClient, times(0)).fetchEntitiesSince(any(Long.class), any(ClientInfo.class), any(InvestUtils.DataSource.class));
        assertThat(integer.get()).isZero();
        assertThat(statusMap).containsEntry("Dummy", ExecutionStatus.COMPLETED);
        executorService.shutdownNow();
    }

    @Test
    public void processNoClient() {
        client = buildTestClientInfoWithAllEntityType("Dummy", "dummy");
        //Arrange
        Set<String> assSet = new HashSet<>();
        assSet.add("guid1");
        assSet.add("guid2");

        Set<String> bankAccount = new HashSet<>();
        bankAccount.add("guid1");
        bankAccount.add("guid2");


        Set<String> bankOperation = new HashSet<>();
        bankOperation.add("guid1");
        bankOperation.add("guid2");


        when(assetServiceClient.fetchEntitiesSince(1604925680, client, null))
                .thenReturn(new TaskResult<>(assSet, 1604925688));
        when(portfolioServiceClient.fetchEntitiesSince(1604925680, client, null))
                .thenReturn(new TaskResult<>(assSet, 1604925689));
        when(positionServiceClient.fetchEntitiesSince(1604925680, client, null))
                .thenReturn(new TaskResult<>(assSet, 1604925690));
        when(performanceServiceClient.fetchEntitiesSince(1604925680, client, null))
                .thenReturn(new TaskResult<>(assSet, 1604925684));
        when(fundamentalsServiceClient.fetchEntitiesSince(1604925680, client, null))
                .thenReturn(new TaskResult<>(assSet, 1604925685));
        when(transactionsServiceClient.fetchEntitiesSince(1604925680, client, null))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(shareClassServiceClient.fetchEntitiesSince(1604925680, client, null))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(instrumentsServiceClient.fetchEntitiesSince(1604925680, client, null))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(bankAccountServiceClient.fetchEntitiesSince(1604925680, client, null))
                .thenReturn(new TaskResult<>(bankAccount, 1604925677));
        when(bankOperationServiceClient.fetchEntitiesSince(1604925680, client, null))
                .thenReturn(new TaskResult<>(bankOperation, 1604925677));
        when(clientInfoDAO.getClientByName(client.getClientName()))
                .thenThrow(new RuntimeException("Error"));
        Map<String, ExecutionStatus> statusMap = new HashMap<>();
        AtomicInteger integer = new AtomicInteger(0);
        //Act
        batchTask.init();
        batchTask.submitTask("Dummy", 1604925680, integer, statusMap, client);
        //Verify
        verify(clientInfoDAO, times(1))
                .getClientByName(anyString());
    }

    @Test
    public void processTaskAsyncWithAllInvestmentEntityType() throws Exception {

        client = buildTestClientInfoWithAllEntityType("Dummy", "dummy");
        //Arrange
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Set<String> assSet = new HashSet<>();
        assSet.add("guid1");
        assSet.add("guid2");
        when(assetServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925688));
        when(portfolioServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925689));
        when(positionServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925690));
        when(performanceServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925684));
        when(fundamentalsServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925685));
        when(transactionsServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(shareClassServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(instrumentsServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(bankAccountServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(bankOperationServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(clientInfoDAO.getClientByName(client.getClientName()))
                .thenReturn(client);
        when(altsDataWorkspaceDAO.fetchLastSuccessfulTime(NETWORK_MODE, "dummy-guid")).thenReturn(12345L);
        Map<String, ExecutionStatus> statusMap = new HashMap<>();
        AtomicInteger integer = new AtomicInteger(0);

        //Act
        batchTask.init();
        batchTask.submitTask("Dummy", 1604925680, integer, statusMap, client);
        //Verify
        ArgumentCaptor<Long> argumentCaptor = ArgumentCaptor.forClass(Long.class);
        verify(zookeeperHelper, times(1))
                .updateChildNodeStatusToComplete(eq("Dummy"), any(), argumentCaptor.capture());
        //oldest time from required entityType's API calls.
        assertThat(argumentCaptor.getValue()).isEqualTo(1604925680);
        verify(transformerServiceHelper, times(8)).extractTransformLoad(any(EntityType.class), any());
        verify(transformerServiceHelper).loadReferenceEntities(any());
        assertThat(integer.get()).isZero();
        assertThat(statusMap).containsEntry("Dummy", ExecutionStatus.COMPLETED);

        verify(registry, times(9)).counter(anyString(), anyString(), any());

        verify(counter, times(9)).increment(anyDouble());

        executorService.shutdownNow();
    }

    @Test
    public void processTaskAsyncWithAllInvestmentEntityTypeAndNoRequiredET() throws Exception {
        client = buildTestClientInfoWithNoRequiredEntityType("Dummy", "dummy");
        //Arrange
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Set<String> assSet = new HashSet<>();
        assSet.add("guid1");
        assSet.add("guid2");

        when(assetServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925688));
        when(portfolioServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925689));
        when(positionServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925690));
        when(performanceServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925684));
        when(fundamentalsServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925685));
        when(transactionsServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(shareClassServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(instrumentsServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(bankAccountServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(bankOperationServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(clientInfoDAO.getClientByName(client.getClientName()))
                .thenReturn(client);
        when(altsDataWorkspaceDAO.fetchLastSuccessfulTime(NETWORK_MODE, "dummy-guid")).thenReturn(12345L);
        Map<String, ExecutionStatus> statusMap = new HashMap<>();
        AtomicInteger integer = new AtomicInteger(0);

        //Act
        batchTask.init();
        batchTask.submitTask("Dummy", 1604925680, integer, statusMap, client);

        ArgumentCaptor<Long> argumentCaptor = ArgumentCaptor.forClass(Long.class);
        verify(zookeeperHelper, times(1))
                .updateChildNodeStatusToComplete(eq("Dummy"), any(), argumentCaptor.capture());
        //oldest time from required entityType's API calls.
        assertThat(argumentCaptor.getValue()).isEqualTo(1604925680);
        verify(transformerServiceHelper, times(8)).extractTransformLoad(any(EntityType.class), any());
        verify(transformerServiceHelper).loadReferenceEntities(any());
        assertThat(integer.get()).isZero();
        assertThat(statusMap).containsEntry("Dummy", ExecutionStatus.COMPLETED);
        executorService.shutdownNow();
    }

    @Test
    public void processTaskAsync_PositionAndPortfolioExceptionResponse() {

        client = buildTestClientInfoWithAllEntityType("Dummy", "dummy");
        //Arrange
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Set<String> assSet = new HashSet<>();
        assSet.add("guid1");
        assSet.add("guid2");
        when(assetServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925688));
        when(portfolioServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925689));
        when(positionServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925690));
        when(performanceServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925684));
        when(fundamentalsServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925685));
        when(transactionsServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(shareClassServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(instrumentsServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(bankAccountServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(bankOperationServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(clientInfoDAO.getClientByName(client.getClientName()))
                .thenReturn(client);
        Map<String, ExecutionStatus> statusMap = new HashMap<>();
        AtomicInteger integer = new AtomicInteger(0);

        //Act
        batchTask.init();
        batchTask.submitTask("Dummy", 12345L, integer, statusMap, client);
        //Verify
        verify(transformerServiceHelper, times(8)).extractTransformLoad(any(EntityType.class), any());
        assertThat(integer.get()).isZero();
        assertThat(statusMap).containsEntry("Dummy", ExecutionStatus.COMPLETED);
        executorService.shutdownNow();
    }

    @Test
    public void processTaskAsync_AssetExceptionResponse() {

        client = buildTestClientInfoWithAllEntityType("Dummy", "dummy");
        //Arrange
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Set<String> assSet = new HashSet<>();
        assSet.add("guid1");
        assSet.add("guid2");
        when(assetServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925688));
        when(portfolioServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925689));
        when(positionServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925690));
        when(performanceServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925684));
        when(fundamentalsServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925685));
        when(transactionsServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(shareClassServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(instrumentsServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(bankAccountServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(bankOperationServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(clientInfoDAO.getClientByName(client.getClientName()))
                .thenReturn(client);
        Map<String, ExecutionStatus> statusMap = new HashMap<>();
        AtomicInteger integer = new AtomicInteger(0);

        //Act
        batchTask.init();
        batchTask.submitTask("Dummy", 12345L, integer, statusMap, client);

        //Verify
        ArgumentCaptor<Long> argumentCaptor = ArgumentCaptor.forClass(Long.class);
        verify(zookeeperHelper, times(1))
                .updateChildNodeStatusToComplete(eq("Dummy"), any(), argumentCaptor.capture());
        verify(transformerServiceHelper, times(8)).extractTransformLoad(any(EntityType.class), any());
        assertThat(integer.get()).isZero();
        assertThat(statusMap).containsEntry("Dummy", ExecutionStatus.COMPLETED);
        executorService.shutdownNow();
    }

    @Test
    public void processTaskAsync_Failure() throws Exception {
        client = buildTestClientInfoWithAllEntityType("Dummy", "dummy");
        //Arrange
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Set<String> assSet = new HashSet<>();
        assSet.add("guid1");
        assSet.add("guid2");
        when(assetServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 123));
        when(portfolioServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 124));
        when(performanceServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 124));
        doThrow(new NullPointerException()).when(positionServiceClient).fetchEntitiesSince(12345L, client, null);
        when(clientInfoDAO.getClientByName(client.getClientName()))
                .thenReturn(client);
        when(altsDataWorkspaceDAO.fetchLastSuccessfulTime(NETWORK_MODE, "dummy-guid")).thenReturn(12345L);
        Map<String, ExecutionStatus> statusMap = new HashMap<>();
        AtomicInteger integer = new AtomicInteger(0);

        when(registry.counter(anyString(), anyString(), any())).thenReturn(null);
        //Act
        batchTask.init();
        batchTask.submitTask("Dummy", 12345L, integer, statusMap, client);

        //Verify
        ArgumentCaptor<Long> argumentCaptor = ArgumentCaptor.forClass(Long.class);
        verify(zookeeperHelper, times(1)).updateChildNodeStatusToComplete(eq("Dummy"), any(), argumentCaptor.capture());
        verify(transformerServiceHelper, times(0)).extractTransformLoad(any(EntityType.class), any());
        assertThat(integer.get()).isZero();
        assertThat(argumentCaptor.getValue()).isEqualTo(12345L);
        assertThat(statusMap).containsEntry("Dummy", ExecutionStatus.COMPLETED);

        executorService.shutdownNow();
    }

    @Test//(expected = Exception.class)
    // MC: TODO: If you want to test for an exception, test for it with assertThrows, or try { doSomething(); fail(); } catch (SpecificExceptionType ex) {}
    // This lazy annotation way is totally arbitrary. Without using Mockito.spy on the batchTask, it fails with an exception on this line:
    //   when(batchTask.logger()).thenReturn(LOGGER);
    // because Mockito will not let you override the return types on something that isn't a mock. This is not at all what this method
    // wants to test, but it appears to be a successful test because the annotation tells the mocking framework that any exception represents
    // the expected result.
    public void processTaskThrowIncrementException() throws Exception {

        client = buildTestClientInfoWithAllEntityType("Dummy", "dummy");
        //before
        when(registry.counter(anyString(), anyString(), any())).thenReturn(null);
        when(batchTask.logger()).thenReturn(LOGGER);

        //Arrange
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Set<String> assSet = new HashSet<>();
        assSet.add("guid1");
        assSet.add("guid2");
        when(assetServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925688));
        when(portfolioServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925689));
        when(positionServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925690));
        when(performanceServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925684));
        when(fundamentalsServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925685));
        when(transactionsServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(shareClassServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(instrumentsServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(bankAccountServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(bankOperationServiceClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any()))
                .thenReturn(new TaskResult<>(assSet, 1604925686));
        when(clientInfoDAO.getClientByName(client.getClientName()))
                .thenReturn(client);
        when(altsDataWorkspaceDAO.fetchLastSuccessfulTime(NETWORK_MODE, "guid")).thenReturn(12345L);
        Map<String, ExecutionStatus> statusMap = new HashMap<>();
        AtomicInteger integer = new AtomicInteger(0);

        //Act
        batchTask.init();
        batchTask.submitTask("Dummy", 12345L, integer, statusMap, client);

        //Verify
        verify(transformerServiceHelper, times(8)).extractTransformLoad(any(EntityType.class), any());
        verify(transformerServiceHelper).loadReferenceEntities(any());
        assertThat(integer.get()).isZero();
        assertThat(statusMap).containsEntry("Dummy", ExecutionStatus.COMPLETED);

        executorService.shutdownNow();
    }


    @Test
    public void triggerEtlBatch_NoResults() {
        final Set<String> emptyResults = ImmutableSet.of();

        HashMap<EntityType, Map<String, TaskResult<Set<String>>>> resultHashMap = Maps.newHashMap();
        resultHashMap.put(EntityType.ASSET, new HashMap<String, TaskResult<Set<String>>>() {{
            put("", new TaskResult<>(ExecutionStatus.COMPLETED, "", emptyResults));
        }});
        resultHashMap.put(EntityType.PORTFOLIO, new HashMap<String, TaskResult<Set<String>>>() {{
            put("", new TaskResult<>(ExecutionStatus.COMPLETED, "", emptyResults));
        }});
        resultHashMap.put(EntityType.POSITION, new HashMap<String, TaskResult<Set<String>>>() {{
            put("", new TaskResult<>(ExecutionStatus.COMPLETED, "", emptyResults));
        }});
        resultHashMap.put(EntityType.PERFORMANCE, new HashMap<String, TaskResult<Set<String>>>() {{
            put("", new TaskResult<>(ExecutionStatus.COMPLETED, "", emptyResults));
        }});
        resultHashMap.put(EntityType.FUNDAMENTALS, new HashMap<String, TaskResult<Set<String>>>() {{
            put("", new TaskResult<>(ExecutionStatus.COMPLETED, "", emptyResults));
        }});
        resultHashMap.put(EntityType.TRANSACTION, new HashMap<String, TaskResult<Set<String>>>() {{
            put("", new TaskResult<>(ExecutionStatus.COMPLETED, "", emptyResults));
        }});
        resultHashMap.put(EntityType.INSTRUMENT, new HashMap<String, TaskResult<Set<String>>>() {{
            put("", new TaskResult<>(ExecutionStatus.COMPLETED, "", emptyResults));
        }});
        resultHashMap.put(EntityType.BANK_ACCOUNT, new HashMap<String, TaskResult<Set<String>>>() {{
            put("", new TaskResult<>(ExecutionStatus.COMPLETED, "", emptyResults));
        }});
        resultHashMap.put(EntityType.BANK_OPERATION, new HashMap<String, TaskResult<Set<String>>>() {{
            put("", new TaskResult<>(ExecutionStatus.COMPLETED, "", emptyResults));
        }});
        resultHashMap.put(EntityType.SHARECLASS, new HashMap<String, TaskResult<Set<String>>>() {{
            put("", new TaskResult<>(ExecutionStatus.COMPLETED, "", emptyResults));
        }});
        resultHashMap.put(EntityType.HIST_TRANSACTION, new HashMap<String, TaskResult<Set<String>>>() {{
            put("", new TaskResult<>(ExecutionStatus.COMPLETED, "", emptyResults));
        }});

        batchTask.triggerEtlBatch(resultHashMap, "Test Client");
        try {
            // Verify that extractTransformLoadBatch was never called for empty results
            verify(transformerServiceHelper, times(10)).extractTransformLoad(any(EntityType.class), any());
            verify(transformerServiceHelper).loadReferenceEntities(any());
        } finally {
            Mockito.reset(transformerServiceHelper);
        }
    }

    @Test
    public void triggerEtlBatch_WithResults() {
        final Set<String> dummyResults = ImmutableSet.of("guid1", "guid2");

        HashMap<EntityType, Map<String, TaskResult<Set<String>>>> resultHashMap = Maps.newHashMap();
        resultHashMap.put(EntityType.ASSET, new HashMap<String, TaskResult<Set<String>>>() {{
            put("", new TaskResult<>(ExecutionStatus.COMPLETED, "", dummyResults));
        }});
        resultHashMap.put(EntityType.PORTFOLIO, new HashMap<String, TaskResult<Set<String>>>() {{
            put("", new TaskResult<>(ExecutionStatus.COMPLETED, "", dummyResults));
        }});
        resultHashMap.put(EntityType.POSITION, new HashMap<String, TaskResult<Set<String>>>() {{
            put("", new TaskResult<>(ExecutionStatus.COMPLETED, "", dummyResults));
        }});
        resultHashMap.put(EntityType.PERFORMANCE, new HashMap<String, TaskResult<Set<String>>>() {{
            put("", new TaskResult<>(ExecutionStatus.COMPLETED, "", dummyResults));
        }});
        resultHashMap.put(EntityType.FUNDAMENTALS, new HashMap<String, TaskResult<Set<String>>>() {{
            put("", new TaskResult<>(ExecutionStatus.COMPLETED, "", dummyResults));
        }});
        resultHashMap.put(EntityType.TRANSACTION, new HashMap<String, TaskResult<Set<String>>>() {{
            put("", new TaskResult<>(ExecutionStatus.COMPLETED, "", dummyResults));
        }});
        resultHashMap.put(EntityType.INSTRUMENT, new HashMap<String, TaskResult<Set<String>>>() {{
            put("", new TaskResult<>(ExecutionStatus.COMPLETED, "", dummyResults));
        }});
        resultHashMap.put(EntityType.BANK_ACCOUNT, new HashMap<String, TaskResult<Set<String>>>() {{
            put("", new TaskResult<>(ExecutionStatus.COMPLETED, "", dummyResults));
        }});
        resultHashMap.put(EntityType.BANK_OPERATION, new HashMap<String, TaskResult<Set<String>>>() {{
            put("", new TaskResult<>(ExecutionStatus.COMPLETED, "", dummyResults));
        }});
        resultHashMap.put(EntityType.SHARECLASS, new HashMap<String, TaskResult<Set<String>>>() {{
            put("", new TaskResult<>(ExecutionStatus.COMPLETED, "", dummyResults));
        }});
        resultHashMap.put(EntityType.HIST_TRANSACTION, new HashMap<String, TaskResult<Set<String>>>() {{
            put("", new TaskResult<>(ExecutionStatus.COMPLETED, "", dummyResults));
        }});

        batchTask.triggerEtlBatch(resultHashMap, "Test Client");
        try {
            // Verify that extractTransformLoadBatch was called once
            verify(transformerServiceHelper, times(10)).extractTransformLoad(any(EntityType.class), any());
            verify(transformerServiceHelper).loadReferenceEntities(any());
        } finally {
            Mockito.reset(transformerServiceHelper);
        }
    }


}
