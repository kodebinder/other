package com.bfm.aap.pmdx.hub.service.async;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.hub.model.ExecutionStatus;
import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.aap.pmdx.hub.repository.ClientInfoDAO;
import com.bfm.aap.pmdx.hub.service.entity.EfrontPingClient;
import com.bfm.aap.pmdx.hub.util.HubServiceUtil;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.ClientStatus;
import com.bfm.aap.pmdx.model.util.ServerContext;
import com.bfm.aap.pmdx.proto.util.ProtoJsonHelper;
import com.bfm.util.ProtocolSupport;
import com.bfm.util.ZooKeeperRetryOperations;
import com.google.protobuf.util.Timestamps;
import io.grpc.ConnectivityState;
import io.grpc.ManagedChannel;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.data.Stat;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import static com.bfm.aap.pmdx.hub.util.AppConstants.ZKPATH_PARENT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore({"javax.crypto.*"})
@PrepareForTest({ZookeeperHelper.class})
public class HeartBeatServiceTest extends BaseUnitTest {

    private AltsDataWorkspaceDAO altsDataWorkspaceDAO;
    private LockHelper lockHelper;
    private BatchProcessor batchProcessor;
    private ClientInfoDAO clientInfoDAO;
    private HeartBeatService heartBeatService;
    private ManagedChannel channel;
    private BatchTask batchTask;
    private EfrontPingClient efrontPingClient;
    private ZookeeperHelper zookeeperHelper;
    private ProtocolSupport protocolSupport;
    private ZooKeeper zooKeeper;
    private HubServiceUtil hubServiceUtil;
    private Stat stat;
    private ZooKeeperRetryOperations zooKeeperRetryOperations;

    @Before
    public void init() throws KeeperException, InterruptedException {
        MockitoAnnotations.initMocks(this);
        channel = mock(ManagedChannel.class);
        altsDataWorkspaceDAO = mock(AltsDataWorkspaceDAO.class);
        lockHelper = mock(LockHelper.class);
        batchTask = mock(BatchTask.class);
        channel = mock(ManagedChannel.class);
        efrontPingClient = mock(EfrontPingClient.class);
        protocolSupport = mock(ProtocolSupport.class);
        zooKeeper = mock(ZooKeeper.class);
        clientInfoDAO = mock(ClientInfoDAO.class);
        hubServiceUtil = mock(HubServiceUtil.class);
        zookeeperHelper = new ZookeeperHelper(protocolSupport, lockHelper, hubServiceUtil, clientInfoDAO);
        zooKeeperRetryOperations = mock(ZooKeeperRetryOperations.class);
        stat = mock(Stat.class);

        batchProcessor = new BatchProcessor(batchTask, efrontPingClient);
        heartBeatService = new HeartBeatService(batchProcessor, channel, clientInfoDAO, zookeeperHelper);
        Whitebox.setInternalState(heartBeatService, "heartBeatIntervalMillis", 2000);
        Whitebox.setInternalState(batchProcessor, "concurrentBatchCount", 5);
        Map clients = new ConcurrentHashMap<>();
        Map entityService = new ConcurrentHashMap();
        entityService.put("INVESTMENTS", "/PMDXHUB_DEV_RED/AladdinDemo");
        clients.put("AladdinDemo", entityService);
        Whitebox.setInternalState(heartBeatService, "clientToEntityServicePathMap", clients);
        Whitebox.setInternalState(heartBeatService, "zookeeperHelper", zookeeperHelper);
        Whitebox.setInternalState(zookeeperHelper, "protocolSupport", protocolSupport);
        Whitebox.setInternalState(zookeeperHelper, "lockHelper", lockHelper);
        Whitebox.setInternalState(zookeeperHelper, "zooKeeper", zooKeeper);
        Whitebox.setInternalState(zookeeperHelper, "zooKeeperRetryOperations", zooKeeperRetryOperations);

        when(lockHelper.acquireLockWithRetry(anyString())).thenReturn(true);
        when(lockHelper.releaseLock(anyString())).thenReturn(true);
        when(clientInfoDAO.getInvestmentClients()).thenReturn(getAllTestClientInfo(Arrays.asList("AladdinDemo", "ALD-DEMO", "dummy",
                "guid")));
        when(zooKeeper.exists(anyString(), anyBoolean())).thenReturn(stat);
        when(zooKeeper.getState()).thenReturn(ZooKeeper.States.CONNECTED);
        byte[] contextData = ProtoJsonHelper.convertToJson(ServerContext.getDefaultInstance())
                .getBytes();
        when(zooKeeper.getData(eq(ZKPATH_PARENT), anyBoolean(), any())).thenReturn(contextData);
        when(zooKeeperRetryOperations.ensurePathExists(anyString(), any(), any())).thenReturn(true);
    }

    @Test
    public void start() throws InterruptedException {
        //Arrange
        when(lockHelper.acquireLockWithRetry(anyString())).thenReturn(false);

        //Act
        heartBeatService.start(2000);

        //Verify
        Thread.sleep(200);
        heartBeatService.stop();
        heartBeatService.destroy();
        assertThat(heartBeatService.getTerminatedLatch().getCount()).isEqualTo(0);
    }

    @Test
    public void run_NewHubContext() {
        try {
            //Arrange
            when(channel.getState(false)).thenReturn(ConnectivityState.READY);
            byte[] data = ProtoJsonHelper.convertToJson(zookeeperHelper
                    .buildClientInfo("AladdinDemo", ClientStatus.INITIATED, Instant.EPOCH.toEpochMilli()))
                    .getBytes();
            when(zooKeeper.getData(anyString(), anyBoolean(), any())).thenReturn(data);

            //Act
            heartBeatService.run();

            //Verify
//            verify(lockHelper, times(1)).acquireLockWithRetry(anyString());
            verify(batchTask, never()).submitTask(anyString(), anyLong(), any(AtomicInteger.class), anyMap(), any());
        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void run_NewHubContext_ChannelNotReady() {
        try {
            //Arrange
            when(zooKeeper.getData(anyString(), anyBoolean(), any())).thenReturn(null);
            when(channel.getState(false)).thenReturn(ConnectivityState.CONNECTING);
            when(zooKeeperRetryOperations.ensurePathExists(anyString(), any(), any())).thenReturn(true);

            //Act
            heartBeatService.run();

            //Verify
            verify(batchTask, never()).submitTask(anyString(), anyLong(), any(AtomicInteger.class), anyMap(), any());

        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void run_ExistingHubContext() {
        try {
            //Arrange
            when(zooKeeper.exists(anyString(), anyBoolean())).thenReturn(stat);
            byte[] clientData = ProtoJsonHelper.convertToJson(zookeeperHelper
                    .buildClientInfo("AladdinDemo", ClientStatus.INITIATED, Instant.EPOCH.toEpochMilli()))
                    .getBytes();
            when(zooKeeper.getData(anyString(), anyBoolean(), any())).thenReturn(clientData);

            List<String> clients = Arrays.asList("Blackrock", "efront", "aladdin-r", "dummy-r", "akash-r", "test1");
            List<ClientInfo> clientInfos = getClients(clients);
            when(clientInfoDAO.getInvestmentClients()).thenReturn(clientInfos);
            ServerContext.Builder serverContextBuilder = ServerContext.newBuilder();
            serverContextBuilder.setServerInstance("server1").addAllClients(clients)
                    .addAllInProgressClients(clients.subList(2, 5))
                    .setStartHashRange(0).setEndHashRange(359).setIsIssuersScheduled(true)
                    .setHeartBeat(Timestamps.fromMillis(System.currentTimeMillis() + 1000));
            byte[] contextDataTest = ProtoJsonHelper.convertToJson(serverContextBuilder.build())
                    .getBytes();
            when(zooKeeper.getData(eq(ZKPATH_PARENT), anyBoolean(), any())).thenReturn(contextDataTest);
            when(channel.getState(false)).thenReturn(ConnectivityState.READY);

            //Act
            heartBeatService.run();

            //Verify
            verify(batchTask, never()).submitTask(anyString(), anyLong(), any(AtomicInteger.class), anyMap(), any());
            verify(zooKeeper, times(3)).getData(anyString(), anyBoolean(), any());

        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void run_ExistingHubContext_InterruptedError() {
        try {
            //Arrange
            byte[] data = ProtoJsonHelper.convertToJson(zookeeperHelper
                    .buildClientInfo("AladdinDemo", ClientStatus.INITIATED, Instant.EPOCH.toEpochMilli()))
                    .getBytes();
            when(zooKeeper.getData(eq("/PMDXHUB_DEV_RED/AladdinDemo"), anyBoolean(), any())).thenReturn(data);
            when(zooKeeper.exists(anyString(), anyBoolean())).thenReturn(stat);
            doThrow(new InterruptedException()).when(zooKeeper).getData(eq("/PMDXHUB_DEV_RED"), anyBoolean(), any());
            List<String> clients = Arrays.asList("Blackrock", "efront", "aladdin-r", "dummy-r", "akash-r", "test1");
            List<ClientInfo> clientInfos = getClients(clients);
            when(clientInfoDAO.getInvestmentClients()).thenReturn(clientInfos);
            ServerContext.Builder serverContextBuilder = ServerContext.newBuilder();
            serverContextBuilder.setServerInstance("server1").addAllClients(clients.subList(0, clients.size() - 1))
                    .addClients("extraClient")
                    .addAllInProgressClients(clients.subList(2, 5))
                    .setStartHashRange(0).setEndHashRange(359)
                    .setIsIssuersScheduled(false)
                    .setHeartBeat(Timestamps.fromMillis(System.currentTimeMillis() + 1000));
            when(channel.getState(false)).thenReturn(ConnectivityState.READY);

            //Act
            heartBeatService.run();

            //Verify
//            verify(batchTask, times(1)).processTaskAsync(anyString(), anyLong(), any(), any(AtomicInteger.class), anyMap());
            verify(zooKeeper, times(3)).getData(anyString(), anyBoolean(), any());

        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void run_ExistingHubContext_ZKNotConnected() {
        try {
            byte[] data = ProtoJsonHelper.convertToJson(zookeeperHelper
                    .buildClientInfo("AladdinDemo", ClientStatus.INITIATED, Instant.EPOCH.toEpochMilli()))
                    .getBytes();
            when(zooKeeper.getData(eq("/PMDXHUB_DEV_RED/AladdinDemo"), anyBoolean(), any())).thenReturn(data);
            when(zooKeeper.exists(anyString(), anyBoolean())).thenReturn(stat);
            doThrow(new InterruptedException()).when(zooKeeper).getData(eq("/PMDXHUB_DEV_RED"), anyBoolean(), any());
            //Arrange
            List<String> clients = Arrays.asList("Blackrock", "efront", "aladdin-r", "dummy-r", "akash-r", "test1");
            List<ClientInfo> clientInfos = getClients(clients);
            when(clientInfoDAO.getInvestmentClients()).thenReturn(clientInfos);
            when(channel.getState(false)).thenReturn(ConnectivityState.READY);

            //Act
            heartBeatService.run();

            //Verify
//            verify(batchTask, times(1)).processTaskAsync(anyString(), anyLong(), any(), any(AtomicInteger.class), anyMap());
            //verify(issuersScheduler, times(1)).schedule();//TODO even though it starts scheduler this is not being captured correctly.
            verify(zooKeeper, times(3)).getData(anyString(), anyBoolean(), any());

        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    private List<ClientInfo> getClients(List<String> clients) {
        List<ClientInfo> clientInfos = new ArrayList<>();
        clients.forEach(cl -> clientInfos.add(buildTestClientInfo(cl)));
        return clientInfos;
    }

    @Test
    public void run_ZooKeeperInterrupted() {
        //test scenario where one server is up, all clients have run once..should re run again
        try {
            when(zooKeeper.getData(eq("/PMDXHUB_DEV_RED/AladdinDemo"), anyBoolean(), any())).thenReturn(null);
            when(zooKeeper.exists(anyString(), anyBoolean())).thenReturn(stat);
            doThrow(new KeeperException.BadArgumentsException()).when(zooKeeper).getData(anyString(), anyBoolean(), any());
            //Arrange
            List<String> clients = Arrays.asList("Blackrock", "efront", "aladdin-r", "dummy-r", "akash-r", "test1");
            batchProcessor.getAllClients().clear();
            batchProcessor.getAllClients().addAll(clients);
            when(channel.getState(false)).thenReturn(ConnectivityState.READY);
            batchProcessor.getProcessedClients().put(clients.get(2), ExecutionStatus.IN_PROGRESS);
            batchProcessor.getProcessedClients().put(clients.get(3), ExecutionStatus.IN_PROGRESS);
            batchProcessor.getProcessedClients().put(clients.get(4), ExecutionStatus.IN_PROGRESS);
            batchProcessor.getProcessedClients().put(clients.get(0), ExecutionStatus.COMPLETED);
            batchProcessor.getProcessedClients().put(clients.get(1), ExecutionStatus.COMPLETED);
            batchProcessor.getProcessedClients().put(clients.get(5), ExecutionStatus.COMPLETED);
            Whitebox.setInternalState(batchProcessor, "currentRunningTasks", new AtomicInteger(3));

            //Act
            heartBeatService.run();

            //Verify
            verify(batchTask, never()).submitTask(anyString(), anyLong(), any(AtomicInteger.class), anyMap(), any());

        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void start_WhenNoIntervalProvided() {
        assertThrows(IllegalArgumentException.class, () -> {
            heartBeatService.start(0);
        });
    }

    @Test
    public void run_NPException() {
        Set clients = null;
        Whitebox.setInternalState(heartBeatService, "toBeProcessedClients", clients);

        heartBeatService.run();

        verify(batchTask, never()).submitTask(anyString(), anyLong(), any(AtomicInteger.class), anyMap(), any());
    }


    @After
    public void tearDownAfterClass() throws Exception {
        zooKeeper.close();
        protocolSupport.close();
        heartBeatService.stop();
    }
}