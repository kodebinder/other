package com.bfm.aap.pmdx.hub.repository;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.hub.util.AppConstants;
import com.bfm.aap.pmdx.model.Asset;
import com.bfm.aap.pmdx.model.BankAccount;
import com.bfm.aap.pmdx.model.BankOperation;
import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.Fundamentals;
import com.bfm.aap.pmdx.model.Instrument;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.Performance;
import com.bfm.aap.pmdx.model.Portfolio;
import com.bfm.aap.pmdx.model.Position;
import com.bfm.aap.pmdx.model.ShareClass;
import com.bfm.aap.pmdx.model.Transaction;
import com.bfm.aap.pmdx.model.User;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.adl.ADLException;
import com.bfm.adl.ADLObject;
import com.bfm.adl.ADLQuery;
import com.bfm.adl.ADLRepository;
import com.bfm.adl.ADLRepositoryFactory;
import com.bfm.adl.ADLResultSet;
import com.bfm.adl.exception.ADLErrorCodes;
import com.bfm.adl.exception.ADLExceptionImpl;
import com.bfm.adl.impl.ADLQueryImpl;
import com.bfm.adl.util.ADLResultSetUtil;
import com.bfm.util.BFMTimestamp;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import java.io.IOException;
import java.time.Instant;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.bfm.aap.pmdx.hub.repository.ADLConstants.DATA_SECONDARY_INDEX;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.doThrow;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ADLRepositoryFactory.class})
public class AltsDataWorkspaceDAOImplTest extends BaseUnitTest {

    private ADLRepository adlRepository;
    private AltsDataWorkspaceDAOImpl altsDataWorkspaceDAO;
    private ADLObject adlObject;
    private ADLQuery adlQuery;

    @Before
    public void init() throws ADLException {
        adlRepository = mock(ADLRepository.class);
        adlQuery = new ADLQueryImpl(ADLConstants.DATA_PRIMARY_INDEX);
        mockStatic(ADLRepositoryFactory.class);
        when(ADLRepositoryFactory.init(ADLConstants.REPO_NAME, ADLConstants.APP_NAME)).thenReturn(adlRepository);
        altsDataWorkspaceDAO = new AltsDataWorkspaceDAOImpl();
        Whitebox.setInternalState(altsDataWorkspaceDAO, "adlBatchSize", 50);
        Whitebox.setInternalState(altsDataWorkspaceDAO, "adlRetryCount", 1);
        adlObject = mock(ADLObject.class);
        when(adlRepository.createQuery(ADLConstants.DATA_PRIMARY_INDEX)).thenReturn(adlQuery);
        when(adlRepository.createObject()).thenReturn(adlObject);
    }

    @Test
    public void fetchLastSuccessfulTime() throws ADLException, IOException {
        //Arrange
        BFMTimestamp bfmTimestamp = new BFMTimestamp();
        long time = bfmTimestamp.getValue(TimeUnit.MILLISECONDS);
        ADLResultSet<ADLObject> resultSet = ADLResultSetUtil.singletonResultSet(adlObject);
        when(adlRepository.get(any(ADLQuery.class))).thenReturn(resultSet);
        when(adlObject.getTimestamp(anyString())).thenReturn(bfmTimestamp);

        //Act
        long expected = altsDataWorkspaceDAO.fetchLastSuccessfulTime(NetworkMode.BLUE, EntityType.ASSET);

        //Verify
        assertEquals(time, expected);
    }

    @Test
    public void fetchLastSuccessfulTime_Guid() throws ADLException {
        //Arrange
        BFMTimestamp bfmTimestamp = new BFMTimestamp();
        long time = bfmTimestamp.getValue(TimeUnit.MILLISECONDS);
        ADLResultSet<ADLObject> resultSet = ADLResultSetUtil.singletonResultSet(adlObject);
        when(adlRepository.get(any(ADLQuery.class))).thenReturn(resultSet);
        when(adlObject.getTimestamp(anyString())).thenReturn(bfmTimestamp);

        //Act
        long expected = altsDataWorkspaceDAO.fetchLastSuccessfulTime(NetworkMode.BLUE, "abcd");

        //Verify
        assertEquals(time, expected);
    }

    @Test
    public void fetchLastSuccessfulTimeADLFailure() throws ADLException {
        //Arrange
        ADLResultSet<ADLObject> resultSet = ADLResultSetUtil.emptyResultSet();
        when(adlRepository.get(any(ADLQuery.class))).thenReturn(resultSet);
        //Act
        long expected = altsDataWorkspaceDAO.fetchLastSuccessfulTime(NetworkMode.BLUE, "guid");

        assertEquals(Instant.EPOCH.toEpochMilli(), expected);
    }

    @Test
    public void fetchADLRecordInWindow() throws ADLException {
        //Arrange
        ADLResultSet<ADLObject> resultSet = ADLResultSetUtil.emptyResultSet();
        ADLQuery query = Mockito.mock(ADLQuery.class);
        when(adlRepository.createQuery(DATA_SECONDARY_INDEX)).thenReturn(query);
        when(query.addEqualsConstraint(anyString(), anyString())).thenReturn(query);
//        when(query.addRangeConstraint(LAST_MODIFIED_TIME, any(BFMTimestamp.class), any(BFMTimestamp.class))).thenReturn(query);
        when(adlRepository.get(query)).thenReturn(resultSet);
        //Act
        ADLResultSet<ADLObject> expected = altsDataWorkspaceDAO.fetchADLRecordInWindow("INVEST", "BLUE", EntityType.ASSET);
        assertNull(expected);
    }

    @Test
    public void updateLastSuccessfulTime() throws ADLException {
        //Arrange
        //Act
        altsDataWorkspaceDAO.updateLastSuccessfulTime(System.currentTimeMillis(), NetworkMode.BLUE, AppConstants.ENTITY_TYPE_ALL, "Demo", "abcd");
        //Verify
        verify(adlRepository, times(1)).put(adlObject);
    }

    @Test
    public void insertRecords() throws ADLException, IOException {
        //Arrange
        List<Asset> funds = Arrays.asList(Asset.getDefaultInstance(), Asset.getDefaultInstance());
        List<Position> positions = Arrays.asList(Position.getDefaultInstance());
        List<Portfolio> portfolios = Arrays.asList(Portfolio.getDefaultInstance());
        List<Performance> performance = Arrays.asList(Performance.getDefaultInstance());
        List<Fundamentals> fundamentals = Arrays.asList(Fundamentals.getDefaultInstance());
        List<User> user = Arrays.asList(User.getDefaultInstance());
        List<Contact> contact = Arrays.asList(Contact.getDefaultInstance());
        List<Company> company = Arrays.asList(Company.getDefaultInstance());
        List<Investor> investor = Arrays.asList(Investor.getDefaultInstance());
        List<Transaction> transaction = Arrays.asList(Transaction.getDefaultInstance());
        List<ShareClass> shareClass = Arrays.asList(ShareClass.getDefaultInstance());

        when(adlObject.getString(ADLConstants.GUID)).thenReturn("dummyGUID");

        //Act
        altsDataWorkspaceDAO.insertRecords(funds);
        altsDataWorkspaceDAO.insertRecords(portfolios);
        altsDataWorkspaceDAO.insertRecords(positions);
        altsDataWorkspaceDAO.insertRecords(performance);
        altsDataWorkspaceDAO.insertRecords(fundamentals);
        altsDataWorkspaceDAO.insertRecords(user);
        altsDataWorkspaceDAO.insertRecords(contact);
        altsDataWorkspaceDAO.insertRecords(company);
        altsDataWorkspaceDAO.insertRecords(investor);
        altsDataWorkspaceDAO.insertRecords(transaction);
        altsDataWorkspaceDAO.insertRecords(shareClass);

        //Verify
        verify(adlRepository, times(11)).put(anyList());

    }

    @Test
    public void insertRecordEmpty() throws IOException, ADLException {
        List<Asset> data = Collections.emptyList();
        altsDataWorkspaceDAO.insertRecords(data);
        verify(adlRepository, never()).put(anyList());
    }

    @Test
    public void insertRecord() throws ADLException, IOException {
        //Arrange
        when(adlObject.getString(ADLConstants.GUID)).thenReturn("dummyGUID");

        //Act
        altsDataWorkspaceDAO.insertRecord(Asset.getDefaultInstance());
        altsDataWorkspaceDAO.insertRecord(Position.getDefaultInstance());
        altsDataWorkspaceDAO.insertRecord(Portfolio.getDefaultInstance());
        altsDataWorkspaceDAO.insertRecord(Performance.getDefaultInstance());
        altsDataWorkspaceDAO.insertRecord(Fundamentals.getDefaultInstance());
        altsDataWorkspaceDAO.insertRecord(User.getDefaultInstance());
        altsDataWorkspaceDAO.insertRecord(Contact.getDefaultInstance());
        altsDataWorkspaceDAO.insertRecord(Company.getDefaultInstance());
        altsDataWorkspaceDAO.insertRecord(Investor.getDefaultInstance());
        altsDataWorkspaceDAO.insertRecord(Transaction.getDefaultInstance());
        altsDataWorkspaceDAO.insertRecord(ShareClass.getDefaultInstance());
        altsDataWorkspaceDAO.insertRecord(Instrument.getDefaultInstance());
        altsDataWorkspaceDAO.insertRecord(BankAccount.getDefaultInstance());
        altsDataWorkspaceDAO.insertRecord(BankOperation.getDefaultInstance());

        //Verify
        verify(adlRepository, times(14)).put(any(ADLObject.class));
    }

    @Test
    public void insertRecordWithSource() throws ADLException, IOException {
        //Arrange
        when(adlObject.getString(ADLConstants.GUID)).thenReturn("dummyGUID");

        //Act
        altsDataWorkspaceDAO.insertRecord(Asset.getDefaultInstance(), "CRM", "AladdinDemo");
        altsDataWorkspaceDAO.insertRecord(Position.getDefaultInstance(), "CRM", "AladdinDemo");
        altsDataWorkspaceDAO.insertRecord(Portfolio.getDefaultInstance(), "CRM", "AladdinDemo");
        altsDataWorkspaceDAO.insertRecord(Performance.getDefaultInstance(), "CRM", "AladdinDemo");
        altsDataWorkspaceDAO.insertRecord(Fundamentals.getDefaultInstance(), "CRM", "AladdinDemo");
        altsDataWorkspaceDAO.insertRecord(User.getDefaultInstance(), "CRM", "AladdinDemo");
        altsDataWorkspaceDAO.insertRecord(Contact.getDefaultInstance(), "CRM", "AladdinDemo");
        altsDataWorkspaceDAO.insertRecord(Company.getDefaultInstance(), "CRM", "AladdinDemo");
        altsDataWorkspaceDAO.insertRecord(Investor.getDefaultInstance(), "CRM", "AladdinDemo");
        altsDataWorkspaceDAO.insertRecord(Transaction.getDefaultInstance(), "CRM", "AladdinDemo");
        altsDataWorkspaceDAO.insertRecord(ShareClass.getDefaultInstance(), "CRM", "AladdinDemo");

        //Verify
        verify(adlRepository, times(11)).put(any(ADLObject.class));
    }

    @Test
    public void updateRecord() throws ADLException {
        when(adlObject.getString(ADLConstants.GUID)).thenReturn("dummyGUID");

        //Act
        altsDataWorkspaceDAO.updateRecord(Asset.getDefaultInstance(), "CRM", "AQ237GF5T67TY6Y7Y6UUU9101");
        altsDataWorkspaceDAO.updateRecord(Position.getDefaultInstance(), "CRM", "AQ237GF5T67TY6Y7Y6UUU9101");
        altsDataWorkspaceDAO.updateRecord(Portfolio.getDefaultInstance(), "CRM", "AQ237GF5T67TY6Y7Y6UUU9101");
        altsDataWorkspaceDAO.updateRecord(Performance.getDefaultInstance(), "CRM", "AQ237GF5T67TY6Y7Y6UUU9101");
        altsDataWorkspaceDAO.updateRecord(Fundamentals.getDefaultInstance(), "CRM", "AQ237GF5T67TY6Y7Y6UUU9101");
        altsDataWorkspaceDAO.updateRecord(User.getDefaultInstance(), "CRM", "AQ237GF5T67TY6Y7Y6UUU9101");
        altsDataWorkspaceDAO.updateRecord(Contact.getDefaultInstance(), "CRM", "AQ237GF5T67TY6Y7Y6UUU9101");
        altsDataWorkspaceDAO.updateRecord(Company.getDefaultInstance(), "CRM", "AQ237GF5T67TY6Y7Y6UUU9101");
        altsDataWorkspaceDAO.updateRecord(Investor.getDefaultInstance(), "CRM", "AQ237GF5T67TY6Y7Y6UUU9101");
        altsDataWorkspaceDAO.updateRecord(Transaction.getDefaultInstance(), "CRM", "AQ237GF5T67TY6Y7Y6UUU9101");
        altsDataWorkspaceDAO.updateRecord(ShareClass.getDefaultInstance(), "CRM", "AQ237GF5T67TY6Y7Y6UUU9101");

        //Verify
        verify(adlRepository, times(11)).put(any(ADLObject.class));
    }

    @Test
    public void insertRecord_Failure() throws ADLException {
        //Arrange
        when(adlObject.getString(ADLConstants.GUID)).thenReturn("dummyGUID");
        doThrow(new ADLExceptionImpl(ADLErrorCodes.UNRECOVERABLE_ERROR)).when(adlRepository).put(any(ADLObject.class));

        //Act
        try {
            altsDataWorkspaceDAO.insertRecord(Asset.getDefaultInstance());
        } catch (ADLException ex) {

            assertTrue(ex.getMessage().contains(ADLErrorCodes.UNRECOVERABLE_ERROR.getDescription()));
            //Verify
            verify(adlRepository, times(2)).put(any(ADLObject.class));
        }

    }

    @Test(expected = IOException.class)
    public void insertRecordsADLFailure() throws ADLException, IOException {
        //Arrange
        List<Asset> funds = Arrays.asList(Asset.getDefaultInstance(), Asset.getDefaultInstance());
        when(adlObject.getString(ADLConstants.GUID)).thenReturn("dummyGUID");
        doThrow(new RuntimeException("ADL update failed")).when(adlRepository).put(anyList());

        //Act
        List<String> failedList = altsDataWorkspaceDAO.insertRecords(funds);
    }

}