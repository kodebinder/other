package com.bfm.aap.pmdx.hub.service.async;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.util.lock.Lock;
import com.bfm.util.lock.LockSupport;
import com.bfm.util.lock.LockingException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import static com.bfm.aap.pmdx.hub.util.AppConstants.PMDX_HUB_ID;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@RunWith(PowerMockRunner.class)
@PrepareForTest({LockSupport.class, Lock.class})
public class LockHelperTest extends BaseUnitTest {

    @Mock
    LockSupport lockSupport;

    @Mock
    Lock<String> lock;

    @InjectMocks
    LockHelper lockHelper;

    @Before
    public void init(){
        MockitoAnnotations.initMocks(this);
        lockHelper = new LockHelper(lockSupport);
    }

    @Test
    public void acquireLock() {
        //Arrange
        when(lockSupport.mutex(PMDX_HUB_ID)).thenReturn(lock);
        when(lock.tryAcquire()).thenReturn(true);

        //Act
        assertThat(lockHelper.acquireLock(PMDX_HUB_ID)).isTrue();
        Mockito.reset(lock);
        doThrow(LockingException.extractOrWrap(new Exception(),"dummy")).when(lock).asyncAcquire();

        //Verify
        assertThat(lockHelper.acquireLock(PMDX_HUB_ID)).isFalse();
    }

    @Test
    public void acquireLockWithRetry() {
        //Arrange
        when(lockSupport.mutex(PMDX_HUB_ID)).thenReturn(lock);
        when(lock.tryAcquire()).thenReturn(false);

        //Act
        lockHelper.acquireLockWithRetry(PMDX_HUB_ID);

        //Verify
        verify(lockSupport, times(3)).mutex(PMDX_HUB_ID);
    }

    @Test
    public void releaseLock() {
        //Arrange
        when(lockSupport.mutex(PMDX_HUB_ID)).thenReturn(lock);
        doThrow(LockingException.extractOrWrap(new Exception(),"dummy")).when(lock).release();

        //Act
        assertThat(lockHelper.releaseLock(PMDX_HUB_ID)).isFalse();
    }
}