package com.bfm.aap.pmdx.hub;


import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

import java.nio.file.Path;
import java.nio.file.Paths;

import javax.net.ssl.SSLException;
import javax.net.ssl.TrustManagerFactory;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bfm.aap.pmdx.hub.model.CertHelper;
import com.bfm.aap.pmdx.security.PMDXTrustManagerFactory;

import io.grpc.ManagedChannel;
import io.grpc.netty.shaded.io.grpc.netty.GrpcSslContexts;
import io.grpc.netty.shaded.io.grpc.netty.NegotiationType;
import io.grpc.netty.shaded.io.grpc.netty.NettyChannelBuilder;
import io.grpc.netty.shaded.io.netty.handler.ssl.SslContext;
import io.grpc.netty.shaded.io.netty.handler.ssl.SslContextBuilder;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CertHelper.class, NettyChannelBuilder.class, GrpcSslContexts.class, SslContextBuilder.class})
public class PrivateMarketsDxHubTest extends BaseUnitTest {

    private PrivateMarketsDxHub privateMarketsDxHub;


    @Before
    public void initMocks() throws Exception {
        privateMarketsDxHub = new PrivateMarketsDxHub();
        mockStatic(CertHelper.class);
        mockStatic(NettyChannelBuilder.class);
        mockStatic(GrpcSslContexts.class);
        mockStatic(SslContextBuilder.class);
        SslContextBuilder sslContextBuilderMock = mock(SslContextBuilder.class);
        NettyChannelBuilder nettyChannelBuilder = mock(NettyChannelBuilder.class);
        Path certPath = Paths.get("/web/ssl", "cert.cer");
        Path certKey = Paths.get("/web/ssl", "cert.key");
        Path certCa = Paths.get("/web/ssl", "cert.crt");
        SslContext sslContext = mock(SslContext.class);
        PMDXTrustManagerFactory mockTrustManagerFactory = mock(PMDXTrustManagerFactory.class);

        when(CertHelper.getCertPath()).thenReturn(certPath);
        when(CertHelper.getPrivateKeyPath()).thenReturn(certKey);
        when(CertHelper.getCaPath()).thenReturn(certCa);
        when(GrpcSslContexts.forClient()).thenReturn(sslContextBuilderMock);
        when(sslContextBuilderMock.trustManager(certCa.toFile())).thenReturn(sslContextBuilderMock);
        when(sslContextBuilderMock.trustManager(any(TrustManagerFactory.class))).thenReturn(sslContextBuilderMock);
        when(sslContextBuilderMock.protocols(Matchers.<String>anyVararg())).thenReturn(sslContextBuilderMock);
        when(sslContextBuilderMock.keyManager(certPath.toFile(), certKey.toFile())).thenReturn(sslContextBuilderMock);
        when(sslContextBuilderMock.keyManager(certPath.toFile(), certKey.toFile()).build()).thenReturn(sslContext);
        when(NettyChannelBuilder.forAddress(anyString(), anyInt())).thenReturn(nettyChannelBuilder);
        when(nettyChannelBuilder.usePlaintext()).thenReturn(nettyChannelBuilder);
        when(nettyChannelBuilder.negotiationType(NegotiationType.TLS)).thenReturn(nettyChannelBuilder);
        when(nettyChannelBuilder.sslContext(sslContext)).thenReturn(nettyChannelBuilder);
        when(nettyChannelBuilder.enableRetry()).thenReturn(nettyChannelBuilder);
        when(nettyChannelBuilder.build()).thenReturn(null);

        PowerMockito.whenNew(PMDXTrustManagerFactory.class).withAnyArguments().thenReturn(mockTrustManagerFactory);
    }

    @Test
    public void channel() throws SSLException {
        //Arrange
        ManagedChannel mockChannel = privateMarketsDxHub.channel();

        //Verify
        assertNull(mockChannel);
    }
    
}