package com.bfm.aap.pmdx.hub.service.process;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.model.Asset;
import com.bfm.aap.pmdx.model.util.LibRedBlueProxy;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.model.util.NetworkModeHelper;
import com.bfm.aap.pmdx.redblue.RedBlueNetworkChecker;
import com.google.protobuf.util.Timestamps;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.bfm.aap.pmdx.model.util.NetworkModeHelper.getCompliment;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
public class AssetProcessorTest extends BaseUnitTest {

    @InjectMocks
    AssetProcessor assetProcessor;

    private final NetworkMode serverMode = NetworkModeHelper.getNetworkModeFromString(System.getProperty("mode"));

    @Before
    public void init() {
        assetProcessor.isPrimary = true;
    }

    @Test
    public void getLastSuccessfulTime() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<Asset> assets = getFundAssets(t1, t2, t3);
        //Act
        long lastSuccessfulTime = assetProcessor.getLastSuccessfulTime(assets);
        //Verify
        assertEquals(t3, lastSuccessfulTime);
    }

    @Test
    public void testInit(){
        PowerMockito.mockStatic(RedBlueNetworkChecker.class);
        assetProcessor.init();
    }


    @Test
    public void processEntities() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<Asset> assets = getFundAssets(t1, t2, t3);
        //invalid fundAsset
        assets.add(Asset.newBuilder().setAssetId("dummyID").setAssetName("Invalid asset").build());
        Asset.Builder fb = Asset.newBuilder(assets.get(0)).setAssetId("id5");
        fb.getEntityInfoBuilder().setNetworkMode(getCompliment(serverMode));
        assets.add(fb.build());

        //Act
        List<Asset> updatedAssets = assetProcessor.processEntities(assets);

        //Verify
        assertEquals(assets.size() - 2, updatedAssets.size());
        assertEquals(3, updatedAssets.stream().filter(a -> a.getEntityInfo().getPrimaryData()).count());
        assertEquals(3, updatedAssets.stream().filter(a -> a.getEntityInfo().getNetworkMode() == serverMode).count());
    }

    @Test
    public void processEntities_PrimaryFlagTest() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<Asset> assets = getFundAssets(t1 + 1000, t2 + 1000, t3 + 1000);
        //invalid fundAsset
        assets.add(Asset.newBuilder().setAssetId("dummyID").setAssetName("Invalid asset").build());
        Asset.Builder fb = Asset.newBuilder(assets.get(0)).setAssetId("id5");
        fb.getEntityInfoBuilder().setOriginTimestamp(Timestamps.fromMillis(t1 - 1000));
        assets.add(fb.build());

        //Act
        List<Asset> updatedAssets = assetProcessor.processEntities(assets);

        //Verify
        assertEquals(4, updatedAssets.size());
        assertEquals(4, updatedAssets.stream().filter(a -> a.getEntityInfo().getPrimaryData()).count());
        assertEquals(4, updatedAssets.stream().filter(a -> a.getEntityInfo().getNetworkMode() == serverMode).count());
    }

    @Test
    public void processEntity() throws Exception {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<Asset> assets = getFundAssets(t1 + 1000, t2 + 1000, t3 + 1000);
        when(LibRedBlueProxy.getNetworkPredicatesByColor(NetworkMode.RED)).thenReturn(getBQLHistoryResponse());
        //Act
        Asset updatedAsset = assetProcessor.processEntity(assets.get(0));
        Asset updatedAsset2 = assetProcessor.processEntity(assets.get(1));

        //Verify
        assertTrue(updatedAsset.getEntityInfo().getPrimaryData());
        assertTrue(updatedAsset2.getEntityInfo().getPrimaryData());
        assertEquals(serverMode, updatedAsset.getEntityInfo().getNetworkMode());
    }

    @Test
    public void processEntity_InvalidEntity() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<Asset> assets = getFundAssets(t1 + 1000, t2 + 1000, t3 + 1000);

        //Act
        try {
            assetProcessor.processEntity(assets.get(0));
//            fail();
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("Invalid entity info for"));
        }
    }

    private List<Asset> getFundAssets(long t1, long t2, long t3) {
        Asset.Builder fa1 = Asset.newBuilder().setAssetId("id1");
        fa1.getEntityInfoBuilder().setNetworkMode(serverMode).setOriginTimestamp(Timestamps.fromMillis(t1));
        Asset.Builder fa2 = Asset.newBuilder().setAssetId("id2");
        fa2.getEntityInfoBuilder().setNetworkMode(serverMode).setOriginTimestamp(Timestamps.fromMillis(t2));
        Asset.Builder fa3 = Asset.newBuilder().setAssetId("id3");
        fa3.getEntityInfoBuilder().setNetworkMode(serverMode).setOriginTimestamp(Timestamps.fromMillis(t3));
        return new ArrayList<>(Arrays.asList(fa1.build(), fa2.build(), fa3.build()));
    }
}