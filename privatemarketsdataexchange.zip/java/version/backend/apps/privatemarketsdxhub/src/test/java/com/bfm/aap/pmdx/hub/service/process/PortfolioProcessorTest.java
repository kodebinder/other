package com.bfm.aap.pmdx.hub.service.process;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.model.Portfolio;
import com.bfm.aap.pmdx.model.util.LibRedBlueProxy;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.model.util.NetworkModeHelper;
import com.bfm.aap.pmdx.notification.service.EmailNotification;
import com.google.protobuf.util.Timestamps;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.bfm.aap.pmdx.model.util.NetworkModeHelper.getCompliment;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@RunWith(PowerMockRunner.class)

@PrepareForTest({EmailNotification.class, LibRedBlueProxy.class})
public class PortfolioProcessorTest extends BaseUnitTest {

    @InjectMocks
    PortfolioProcessor portfolioProcessor;

    private final NetworkMode serverMode = NetworkModeHelper.getNetworkModeFromString(System.getProperty("mode"));

    @Before
    public void init() {
        portfolioProcessor.isPrimary = true;
    }

    @Test
    public void getLastSuccessfulTime() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<Portfolio> assets = getPortfolios(t1, t2, t3);
        //Act
        long lastSuccessfulTime = portfolioProcessor.getLastSuccessfulTime(assets);
        //Verify
        assertEquals(t3, lastSuccessfulTime);
    }

    @Test
    public void processEntities() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<Portfolio> ports = getPortfolios(t1, t2, t3);
        //invalid fundAsset
        ports.add(Portfolio.newBuilder().setPortfolioCode(1234).setPortfolioName("Invalid port").build());
        Portfolio.Builder pb = Portfolio.newBuilder(ports.get(0));
        pb.getEntityInfoBuilder().setNetworkMode(getCompliment(serverMode));
        ports.add(pb.build());

        //Act
        List<Portfolio> updatedPortfolios = portfolioProcessor.processEntities(ports);

        //Verify
        assertEquals(ports.size() - 2, updatedPortfolios.size());
        assertEquals(3, updatedPortfolios.stream().filter(a -> a.getEntityInfo().getPrimaryData()).count());
        assertEquals(3, updatedPortfolios.stream().filter(a -> a.getEntityInfo().getNetworkMode() == serverMode).count());
    }

    @Test
    public void processEntity_FuturePrimary() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<Portfolio> ports = getPortfolios(t1, t2, t3);
        //Act
        Portfolio updatedPortfolio = portfolioProcessor.processEntity(ports.get(0));

        //Verify
        assertTrue(updatedPortfolio.getEntityInfo().getPrimaryData());
        assertEquals(serverMode, updatedPortfolio.getEntityInfo().getNetworkMode());
    }

    private List<Portfolio> getPortfolios(long t1, long t2, long t3) {
        Portfolio.Builder fa1 = Portfolio.newBuilder();
        fa1.getEntityInfoBuilder().setNetworkMode(serverMode).setOriginTimestamp(Timestamps.fromMillis(t1));
        Portfolio.Builder fa2 = Portfolio.newBuilder();
        fa2.getEntityInfoBuilder().setNetworkMode(serverMode).setOriginTimestamp(Timestamps.fromMillis(t2));
        Portfolio.Builder fa3 = Portfolio.newBuilder();
        fa3.getEntityInfoBuilder().setNetworkMode(serverMode).setOriginTimestamp(Timestamps.fromMillis(t3));
        return new ArrayList<>(Arrays.asList(fa1.build(), fa2.build(), fa3.build()));
    }
}