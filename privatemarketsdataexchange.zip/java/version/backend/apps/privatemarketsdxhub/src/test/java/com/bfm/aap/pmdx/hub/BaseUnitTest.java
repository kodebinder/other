package com.bfm.aap.pmdx.hub;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.google.protobuf.util.Timestamps;
import org.junit.BeforeClass;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;

import com.bfm.aap.pmdx.hub.util.ServiceEnum;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.EntityService;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.LibRedBlueProxy;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.model.util.NetworkModeMapping;
import com.bfm.aap.pmdx.notification.service.EmailNotification;
import com.bfm.bql.BQLExpression;
import com.bfm.predicate.JqlMappingDAO;
import com.bfm.predicate.JqlMappingID;
import com.bfm.predicate.RedBlueBQLPredicate;
import com.bfm.predicate.RedBlueBQLPredicateImpl;
import com.bfm.util.BFMDateTime;
import com.bfm.util.BFMTime;

import static com.bfm.util.BFMTime.INIT_now;
import static org.mockito.Mockito.mock;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

@SuppressStaticInitializationFor({"com.bfm.aap.pmdx.redblue.RedBlueNetworkChecker", "com.bfm.metric.StatCollectorMeterRegistry"})
@PowerMockIgnore("javax.crypto.*")
@PrepareForTest({EmailNotification.class, LibRedBlueProxy.class})
public abstract class BaseUnitTest {

    protected static NetworkMode networkMode = NetworkMode.BLUE;
    protected static BFMDateTime bfmDateTime = new BFMDateTime(INIT_now);
    protected static final String TEST_PURPOSE = "RED_BLUE";
    protected static JqlMappingDAO jqlMappingDao =  mock(JqlMappingDAO .class);

    @BeforeClass
    public static void initClass() {
        System.setProperty("mode", "BLUE");
        System.setProperty("env.name", "DEV");
        System.setProperty("defaultWebServer", "https://dev.blackrock.com");
    }


    protected void init(long t1, long t2, long t3) {
        mockStatic(EmailNotification.class);
        mockStatic(LibRedBlueProxy.class);
        PowerMockito.when(LibRedBlueProxy.getNetworkPredicatesByColor(NetworkMode.BLUE)).thenReturn(getBQLHistoryResponse(t1, t2, t3));
    }

    protected static List<RedBlueBQLPredicate> getBQLHistoryResponse(long time1, long time2, long time3) {
        RedBlueBQLPredicateImpl p1 = getRedBlueBQLPredicate(10, NetworkMode.BLUE);
        p1.setStartTime(new BFMDateTime(time1));
        p1.setEndTime(new BFMDateTime(time2));
        RedBlueBQLPredicateImpl p3 = getRedBlueBQLPredicate(30, NetworkMode.BLUE);
        p3.setStartTime(new BFMDateTime(time3));
        return Arrays.asList(p1, p3);
    }
    public List<RedBlueBQLPredicate> getBQLHistoryResponse() throws BFMTime.BFMTimeException {
        final RedBlueBQLPredicateImpl p1 = getRedBlueBQLPredicate(10, NetworkMode.BLUE);
        p1.setStartTime(new BFMDateTime("1970-01-01"));
        p1.setEndTime(new BFMDateTime("1980-01-01"));
        final RedBlueBQLPredicateImpl p2 = getRedBlueBQLPredicate(20, NetworkMode.BLUE);
        p2.setStartTime(new BFMDateTime("1980-01-01"));
        p2.setEndTime(new BFMDateTime("1990-01-01"));
        final RedBlueBQLPredicateImpl p3 = getRedBlueBQLPredicate(30, NetworkMode.RED);
        p3.setStartTime(new BFMDateTime("1990-01-01"));
        return Arrays.asList(p1, p2, p3);
    }

    protected static RedBlueBQLPredicateImpl getRedBlueBQLPredicate(int i, NetworkMode networkMode) {
        JqlMappingID id1 = new JqlMappingID();
        id1.setEvalOrder(i);
        RedBlueBQLPredicateImpl p1 = new RedBlueBQLPredicateImpl();
        p1.setJqlMappingID(id1);
        p1.setExpression(new BQLExpression("1=1"));
        p1.setPrimaryNetwork(NetworkModeMapping.convertToRedBlue(networkMode));
        p1.setLastModifiedTime(new BFMDateTime(0));
        return p1;
    }

    public ClientInfo buildTestClientInfo(String clientName, String clientId, String serviceName, EntityType... entityTypes) {
        EntityService.Builder esBuilder = EntityService.newBuilder().setServiceName(serviceName);
        Arrays.asList(entityTypes).stream().forEach(esBuilder::addEntityType);

        return ClientInfo.newBuilder().setClientName(clientName).setClientId(clientId).setAuthMetadata("dummy")
                .addEntityService(esBuilder.build())
                .build();
    }

    public ClientInfo buildTestClientInfoWithAsset(String clientName, String clientId) {
        return ClientInfo.newBuilder().setClientName(clientName)
                .setClientId(clientId).setAuthMetadata("dummy")
                .addEntityService(EntityService.newBuilder().setServiceName(ServiceEnum.INVESTMENTS.getServiceName())
                        .addEntityType(EntityType.ASSET).addRequiredEntityType(EntityType.ASSET).build()).build();
    }

    public ClientInfo buildTestClientInfoWithAssetBankAccountAndBankOperation(String clientName, String clientId) {
        return ClientInfo.newBuilder().setClientName(clientName)
                .setClientId(clientId).setAuthMetadata("dummy")
                .addEntityService(EntityService.newBuilder().setServiceName(ServiceEnum.INVESTMENTS.getServiceName())
                        .addEntityType(EntityType.ASSET)
                        .addEntityType(EntityType.BANK_ACCOUNT)
                        .addEntityType(EntityType.BANK_OPERATION)
                        .addRequiredEntityType(EntityType.ASSET).build()).build();
    }


    public ClientInfo buildTestClientInfoWithAllEntityType(String clientName, String clientId) {
        return ClientInfo.newBuilder().setClientName(clientName)
                .setClientId(clientId).setAuthMetadata("dummy")
                .addEntityService(EntityService.newBuilder().setServiceName(ServiceEnum.INVESTMENTS.getServiceName())
                        .addAllEntityType(Arrays.asList(EntityType.ASSET,EntityType.PORTFOLIO,EntityType.POSITION,EntityType.TRANSACTION,EntityType.FUNDAMENTALS,
                                EntityType.PERFORMANCE,EntityType.SHARECLASS, EntityType.BANK_OPERATION, EntityType.BANK_ACCOUNT))
                        .addRequiredEntityType(EntityType.ASSET)
                        .addRequiredEntityType(EntityType.PORTFOLIO)
                        .addRequiredEntityType(EntityType.POSITION)
                        .build()).build();
    }

    public ClientInfo buildTestClientInfoWithNoRequiredEntityType(String clientName, String clientId) {
        return ClientInfo.newBuilder().setClientName(clientName)
                .setClientId(clientId).setAuthMetadata("dummy")
                .addEntityService(EntityService.newBuilder().setServiceName(ServiceEnum.INVESTMENTS.getServiceName())
                        .addAllEntityType(Arrays.asList(EntityType.ASSET,EntityType.PORTFOLIO,EntityType.POSITION,EntityType.TRANSACTION,EntityType.FUNDAMENTALS,
                                EntityType.PERFORMANCE,EntityType.SHARECLASS, EntityType.BANK_ACCOUNT, EntityType.BANK_OPERATION))
                        .build()).build();
    }

    public ClientInfo buildTestClientInfoWithFewEntityTypes(String clientName, String clientId) {
        return ClientInfo.newBuilder().setClientName(clientName)
                .setClientId(clientId).setAuthMetadata("dummy")
                .addEntityService(EntityService.newBuilder().setServiceName(ServiceEnum.INVESTMENTS.getServiceName())
                        .addEntityType(EntityType.ASSET)
                        .addEntityType(EntityType.PORTFOLIO)
                        .addEntityType(EntityType.POSITION)
                        .addRequiredEntityType(EntityType.ASSET)
                        .addRequiredEntityType(EntityType.PORTFOLIO)
                        .build()).build();
    }

    public void getEntityServiceList(){
        EntityService.newBuilder().setServiceName(ServiceEnum.INVESTMENTS.getServiceName()).addEntityType(EntityType.ASSET);
    }

    public List<ClientInfo> getAllTestClientInfo(List<String> clients) {
        return clients.stream().map(cl -> buildTestClientInfo(cl))
                .collect(Collectors.toList());
    }

    public Set<ClientInfo> getAllTestClientInfoSet(List<String> clients) {
        return clients.stream().map(cl -> buildTestClientInfo(cl))
                .collect(Collectors.toSet());
    }

    public ClientInfo buildTestClientInfo(String clientName) {
        return ClientInfo.newBuilder()
                .setClientName(clientName)
                .setClientId(clientName)
                .setAuthMetadata("dummy")
                .setLastModifiedTime(Timestamps.fromMillis(12345l)).build();
    }
}
