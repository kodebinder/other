package com.bfm.aap.pmdx.hub.service.entity;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.hub.TestUtils;
import com.bfm.aap.pmdx.hub.model.ExecutionStatus;
import com.bfm.aap.pmdx.hub.model.async.TaskResult;
import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.hub.util.AppConstants;
import com.bfm.aap.pmdx.model.BankAccount;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.aap.pmdx.model.util.LibRedBlueProxy;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.notification.service.EmailNotification;
import com.bfm.aap.pmdx.services.BankAccountRequest;
import com.bfm.aap.pmdx.services.BankAccountServiceGrpc;
import com.bfm.aap.pmdx.services.BankAccountsSinceRequest;
import com.bfm.adl.ADLException;
import com.bfm.metric.StatCollectorMeterRegistry;
import com.bfm.service.ServiceException;
import io.grpc.ClientInterceptor;
import io.grpc.ManagedChannel;
import io.grpc.Status;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.AbstractStub;
import io.grpc.testing.GrpcCleanupRule;
import io.micrometer.core.instrument.Timer;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import java.io.IOException;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.powermock.api.mockito.PowerMockito.doThrow;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore("javax.net.ssl.*")
@PrepareForTest({AppConstants.class, LibRedBlueProxy.class, StatCollectorMeterRegistry.class, BankAccountServiceGrpc.BankAccountServiceBlockingStub.class, ManagedChannel.class, AltsDataWorkspaceDAO.class, EmailNotification.class})
public class BankAccountServiceClientTest extends BaseUnitTest {

    private ManagedChannel mockChannel;
    private AltsDataWorkspaceDAO mockDAO;
    private EntityProcessor<BankAccount> bankAccountProcessorMock;
    private BankAccountServiceClient bankAccountServiceClient;
    private AbstractStub serviceStub;
    private ClientInfo client;

    private StatCollectorMeterRegistry registry;

    @Mock
    private Timer timer;

    private BankAccountServiceGrpc.BankAccountServiceBlockingStub serviceStubMock;

    @Rule
    public final GrpcCleanupRule grpcCleanup = new GrpcCleanupRule();

    @Before
    public void init() throws Exception {
        client = buildTestClientInfoWithAllEntityType("Dummy", "dummy");
        MockitoAnnotations.initMocks(this);
        mockStatic(AppConstants.class);
        mockStatic(LibRedBlueProxy.class);
        mockStatic(EmailNotification.class);
        mockStatic(StatCollectorMeterRegistry.class);
        registry = PowerMockito.mock(StatCollectorMeterRegistry.class);
        when(StatCollectorMeterRegistry.getInstance()).thenReturn(registry);
        serviceStubMock = PowerMockito.mock(BankAccountServiceGrpc.BankAccountServiceBlockingStub.class);
        mockChannel = mock(ManagedChannel.class);
        mockDAO = mock(AltsDataWorkspaceDAO.class);
        bankAccountProcessorMock = mock(EntityProcessor.class);
        bankAccountServiceClient = new BankAccountServiceClient(mockChannel, mockDAO, bankAccountProcessorMock);
        bankAccountServiceClient.registry = registry;
        serviceStub = TestUtils.initServerAndBlockingClient(grpcCleanup, TestUtils.MockBankAccountServer.class);
        Whitebox.setInternalState(bankAccountServiceClient, "serviceStub", serviceStub);
        Whitebox.setInternalState(bankAccountServiceClient, "unaryCallTimeoutMillis", 1500);
        setMocks();
    }

    private void setMocks() throws Exception {
        when(bankAccountProcessorMock.processEntity(any(BankAccount.class))).thenAnswer(new Answer<BankAccount>() {
            @Override
            public BankAccount answer(InvocationOnMock invocation) throws Throwable {
                Object[] args = invocation.getArguments();
                return (BankAccount) args[0];
            }
        });
        when(mockDAO.insertRecord(any(BankAccount.class))).thenAnswer(new Answer<Object>() {
            @Override
            public String answer(InvocationOnMock invocation) throws Throwable {
                Object[] args = invocation.getArguments();
                return ((BankAccount) args[0]).getEntityBankAccountId();
            }
        });
        when(registry.timer(anyString(), Matchers.<String>anyVararg())).thenReturn(timer);
        long time1 = System.currentTimeMillis() - 5000, time2 = System.currentTimeMillis() + 5000, time3 = System.currentTimeMillis() + 5000;
        when(bankAccountProcessorMock.getEntityEpochOriginTime(any(BankAccount.class))).thenReturn(time1 + 15000);
        when(LibRedBlueProxy.getNetworkPredicatesByColor(NetworkMode.RED)).thenReturn(getBQLHistoryResponse(time1, time2, time3));
    }


    @Test
    public void fetchEntities() {
        //Arrange
        //Act
        TaskResult<Set<String>> result = bankAccountServiceClient.fetchEntitiesSince(System.currentTimeMillis(), client, InvestUtils.DataSource.FIA);

        //Verify
        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo(ExecutionStatus.COMPLETED);
        assertThat(result.getResult()).isNotEmpty().size().isEqualTo(1);
        assertThat(result.getLastEntityTime()).isGreaterThan(System.currentTimeMillis());

    }

    @Test
    public void fetchEntities_GRPCFailure() {
        //Arrange
        bankAccountServiceClient.serviceStub = serviceStubMock;
        when(serviceStubMock.withInterceptors(Matchers.<ClientInterceptor>anyVararg())).thenReturn(serviceStubMock);
        doThrow(new StatusRuntimeException(Status.CANCELLED)).when(serviceStubMock).getBankAccountsSince(any(BankAccountsSinceRequest.class));
        //Act
        TaskResult<Set<String>> result = bankAccountServiceClient.fetchEntitiesSince(System.currentTimeMillis(), client, InvestUtils.DataSource.FIA);

        //Verify
        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo(ExecutionStatus.EXCEPTION);
        assertThat(result.getResult()).isEmpty();
        assertThat(result.getFailureMessage()).contains("GRPC request failed with status");
    }

    @Test
    public void fetchEntities_ADLFailure() throws ADLException {
        //Arrange
        doThrow(new RuntimeException("ADL failure")).when(mockDAO).insertRecord(any(BankAccount.class));
        //Act
        TaskResult<Set<String>> result = bankAccountServiceClient.fetchEntitiesSince(System.currentTimeMillis(), client, InvestUtils.DataSource.FIA);

        //Verify
        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo(ExecutionStatus.COMPLETED);
        assertThat(result.getResult()).isEmpty();
    }

    @Test
    public void getEntity() {
        //Arrange
        BankAccountRequest bankAccountRequest = BankAccountRequest.newBuilder().setGuid("ABCD").build();
        //Act
        BankAccount resp = bankAccountServiceClient.getEntity(bankAccountRequest);
        //Verify
        assertEquals(AppConstants.NETWORK_MODE, resp.getEntityInfo().getNetworkMode());
    }

    @Test
    public void getEntityFailure() throws IOException {
        //Arrange
        BankAccountRequest bankAccountRequest = BankAccountRequest.newBuilder().setGuid("ABCD").build();
        doThrow(new RuntimeException("ADL Failure")).when(mockDAO).insertRecords(anyList());
        //Act
        try {
            bankAccountServiceClient.getEntity(bankAccountRequest);
        } catch (ServiceException e) {
            assertEquals("Failed to get bankAccount:ADL Failure", e.getMessage());
        }
    }
}
