package com.bfm.aap.pmdx.hub.service.security;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.crypt.DecryptionException;
import com.bfm.crypt.FileDecrypter;
import org.assertj.core.util.Files;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import java.io.File;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({FileDecrypter.class, FileDecrypter.Factory.class})
public class PerlFileDecrypterServiceTest extends BaseUnitTest {

    private PerlFileDecrypterService perlFileDecrypterService;
    private FileDecrypter fileDecrypter;

    @Before
    public void setup() throws DecryptionException {
        fileDecrypter = mock(FileDecrypter.class);
        PowerMockito.mockStatic(FileDecrypter.class);
        PowerMockito.mockStatic(FileDecrypter.Factory.class);
        when(FileDecrypter.Factory.create(anyString())).thenReturn(fileDecrypter);
        perlFileDecrypterService = new PerlFileDecrypterService();
        Whitebox.setInternalState(perlFileDecrypterService, "privateKeyName", "RSAPrivateKey");
        Whitebox.setInternalState(perlFileDecrypterService, "disableSecureConnection", false);
    }

    @Test
    public void init_DisableSecure() throws DecryptionException {
        perlFileDecrypterService.init();
        Whitebox.setInternalState(perlFileDecrypterService, "disableSecureConnection", true);
        //Act
        perlFileDecrypterService.init();
        //Verify
        assertNotNull(Whitebox.getInternalState(perlFileDecrypterService, "fileDecrypter"));
    }

    @Test
    public void decrypt() throws DecryptionException {
        //Arrange
        perlFileDecrypterService.init();
        when(fileDecrypter.decryptAsString(any(File.class))).thenReturn("dummy");

        //Act
        String pwd = perlFileDecrypterService.decrypt(Files.newTemporaryFile());

        //Verify
        assertEquals("dummy", pwd);
    }

    @Test
    public void decrypt_NonSecure() {
        //Arrange
        Whitebox.setInternalState(perlFileDecrypterService, "disableSecureConnection", true);
        //Act
        try {
            perlFileDecrypterService.decrypt(Files.newTemporaryFile());
        } catch (DecryptionException dec) {
            //Verify
            assertEquals("File decrypter disabled in non secure mode!", dec.getMessage());
        }

    }

    @Test(expected = DecryptionException.class)
    public void decrypt_InvalidFile() throws DecryptionException {
        //Act
        perlFileDecrypterService.decrypt(new File("/dummy"));
    }
}