package com.bfm.aap.pmdx.hub.service.process;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.model.Instrument;
import com.bfm.aap.pmdx.model.util.LibRedBlueProxy;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.model.util.NetworkModeHelper;
import com.bfm.aap.pmdx.notification.service.EmailNotification;
import com.google.protobuf.util.Timestamps;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.bfm.aap.pmdx.model.util.NetworkModeHelper.getCompliment;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@RunWith(PowerMockRunner.class)

@PrepareForTest({EmailNotification.class, LibRedBlueProxy.class})
public class InstrumentProcessorTest extends BaseUnitTest {

    @InjectMocks
    InstrumentProcessor instrumentProcessor;

    private final NetworkMode serverMode = NetworkModeHelper.getNetworkModeFromString(System.getProperty("mode"));

    @Before
    public void init() {
        instrumentProcessor.isPrimary = true;
    }

    @Test
    public void getLastSuccessfulTime() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<Instrument> instruments = getInstruments(t1, t2, t3);
        //Act
        long lastSuccessfulTime = instrumentProcessor.getLastSuccessfulTime(instruments);
        //Verify
        assertEquals(t3, lastSuccessfulTime);
    }

    @Test
    public void processEntities() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<Instrument> instruments = getInstruments(t1, t2, t3);
        //invalid Instrument
        instruments.add(Instrument.newBuilder().setAssetId("dummyID").setAssetName("Invalid instrument").build());
        Instrument.Builder fb = Instrument.newBuilder(instruments.get(0)).setAssetId("id5");
        fb.getEntityInfoBuilder().setNetworkMode(getCompliment(serverMode));
        instruments.add(fb.build());

        //Act
        List<Instrument> updatedInstruments = instrumentProcessor.processEntities(instruments);

        //Verify
        assertEquals(instruments.size() - 2, updatedInstruments.size());
        assertEquals(3, updatedInstruments.stream().filter(a -> a.getEntityInfo().getPrimaryData()).count());
        assertEquals(3, updatedInstruments.stream().filter(a -> a.getEntityInfo().getNetworkMode() == serverMode).count());
    }

    @Test
    public void processEntities_PrimaryFlagTest() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<Instrument> instruments = getInstruments(t1 + 1000, t2 + 1000, t3 + 1000);
        //invalid Instrument
        instruments.add(Instrument.newBuilder().setAssetId("dummyID").setAssetName("Invalid instrument").build());
        Instrument.Builder fb = Instrument.newBuilder(instruments.get(0)).setAssetId("id5");
        fb.getEntityInfoBuilder().setOriginTimestamp(Timestamps.fromMillis(t1 - 1000));
        instruments.add(fb.build());

        //Act
        List<Instrument> updatedInstruments = instrumentProcessor.processEntities(instruments);

        //Verify
        assertEquals(4, updatedInstruments.size());
        assertEquals(4, updatedInstruments.stream().filter(a -> a.getEntityInfo().getPrimaryData()).count());
        assertEquals(4, updatedInstruments.stream().filter(a -> a.getEntityInfo().getNetworkMode() == serverMode).count());
    }

    @Test
    public void processEntity() throws Exception {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<Instrument> instruments = getInstruments(t1 + 1000, t2 + 1000, t3 + 1000);

        //Act
        Instrument updatedInstrument = instrumentProcessor.processEntity(instruments.get(0));
        Instrument updatedInstrument2 = instrumentProcessor.processEntity(instruments.get(1));

        //Verify
        assertTrue(updatedInstrument.getEntityInfo().getPrimaryData());
        assertTrue(updatedInstrument2.getEntityInfo().getPrimaryData());
        assertEquals(serverMode, updatedInstrument.getEntityInfo().getNetworkMode());
    }

    @Test
    public void processEntity_InvalidEntity() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<Instrument> instruments = getInstruments(t1 + 1000, t2 + 1000, t3 + 1000);

        //Act
        try {
            instrumentProcessor.processEntity(instruments.get(0));
//            fail();
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("Invalid entity info for"));
        }
    }

    private List<Instrument> getInstruments(long t1, long t2, long t3) {
        Instrument.Builder fa1 = Instrument.newBuilder().setAssetId("id1");
        fa1.getEntityInfoBuilder().setNetworkMode(serverMode).setOriginTimestamp(Timestamps.fromMillis(t1));
        Instrument.Builder fa2 = Instrument.newBuilder().setAssetId("id2");
        fa2.getEntityInfoBuilder().setNetworkMode(serverMode).setOriginTimestamp(Timestamps.fromMillis(t2));
        Instrument.Builder fa3 = Instrument.newBuilder().setAssetId("id3");
        fa3.getEntityInfoBuilder().setNetworkMode(serverMode).setOriginTimestamp(Timestamps.fromMillis(t3));
        return new ArrayList<>(Arrays.asList(fa1.build(), fa2.build(), fa3.build()));
    }
}