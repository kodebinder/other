package com.bfm.aap.pmdx.hub.service.entity;

import io.grpc.ManagedChannel;
import io.grpc.stub.AbstractStub;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.InvestorResponse;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.services.InvestorRequest;
import com.bfm.aap.pmdx.services.InvestorServiceGrpc;
import com.bfm.service.ServiceException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.doThrow;

@RunWith(PowerMockRunner.class)
@PrepareForTest(InvestorServiceGrpc.InvestorServiceBlockingStub.class)
public class InvestorServiceClientTest extends BaseUnitTest {

    private InvestorServiceClient investorServiceClient;

    @Mock
    private RPCServiceClient rpcServiceClient;

    @Mock
    private EntityProcessor<Investor> entityProcessor;

    @Mock
    private ManagedChannel channel;

    private ClientInfo clientInfo;

    private InvestorServiceGrpc.InvestorServiceBlockingStub investorServiceBlockingStub;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        investorServiceBlockingStub = PowerMockito.mock(InvestorServiceGrpc.InvestorServiceBlockingStub.class);
        this.investorServiceClient = new InvestorServiceClient(rpcServiceClient, channel, entityProcessor);
    }

    @Test
    public void fetchEntitiesSinceTest() {
        //Act
        this.investorServiceClient.fetchEntitiesSince(System.currentTimeMillis(), buildTestClientInfoWithAllEntityType("Dummy", "dummy"), null);

        //Verify
        verify(rpcServiceClient).doFetchSince(any(), any(), any(), any(), any(ClientInfo.class), anyLong());
    }

    @Test
    public void updateInvestorTest(){
        clientInfo = buildTestClientInfoWithAllEntityType("Dummy", "dummy");
        when(rpcServiceClient.getStubWithInterceptor(any(AbstractStub.class),any(ClientInfo.class))).thenReturn(investorServiceBlockingStub);
        InvestorResponse response = InvestorResponse.newBuilder().setIsUpdated(true).setData(Investor.getDefaultInstance()).build();
        when(investorServiceBlockingStub.updateInvestor(any(InvestorRequest.class))).thenReturn(response);
        investorServiceClient.updateInvestor(InvestorRequest.newBuilder().setInvestor(Investor.newBuilder().setInvestorId("123").build()).build(),clientInfo, 1234);
        verify(investorServiceBlockingStub).updateInvestor(any(InvestorRequest.class));
        assertThat(response.getData().getInvestorId()).isEmpty();
    }

    @Test
    public void updateInvestorTest_without_response(){
        clientInfo = buildTestClientInfoWithAllEntityType("Dummy", "dummy");
        when(rpcServiceClient.getStubWithInterceptor(any(AbstractStub.class),any(ClientInfo.class))).thenReturn(investorServiceBlockingStub);
        InvestorResponse response = InvestorResponse.newBuilder().setIsUpdated(false).setData(Investor.getDefaultInstance()).build();
        when(investorServiceBlockingStub.updateInvestor(any(InvestorRequest.class))).thenReturn(response);
        investorServiceClient.updateInvestor(InvestorRequest.newBuilder().setInvestor(Investor.newBuilder().setInvestorId("123").build()).build(),clientInfo, 1234);
        verify(investorServiceBlockingStub).updateInvestor(any(InvestorRequest.class));
        assertThat(response.getData().getInvestorId()).isEmpty();
    }

    @Test
    public void updateInvestorTest_Failure(){
        clientInfo = buildTestClientInfoWithAllEntityType("Dummy", "dummy");
        when(rpcServiceClient.getStubWithInterceptor(any(AbstractStub.class),any(ClientInfo.class))).thenReturn(investorServiceBlockingStub);

        doThrow(new RuntimeException("grpc failure")).when(investorServiceBlockingStub).updateInvestor(any(InvestorRequest.class));
        try {
            investorServiceClient.updateInvestor(InvestorRequest.getDefaultInstance(),clientInfo, 1234);
        } catch (ServiceException ex) {
            assertTrue(ex.getMessage().contains("grpc failure"));
        }
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testGetEntity() {
        investorServiceClient.getEntity(null);
    }
}