package com.bfm.aap.pmdx.hub.service.entity;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.hub.TestUtils;
import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.hub.util.AppConstants;
import com.bfm.aap.pmdx.model.ShareClass;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.LibRedBlueProxy;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.notification.service.EmailNotification;
import com.bfm.aap.pmdx.services.ShareClassRequest;
import com.bfm.adl.ADLException;
import com.bfm.metric.StatCollectorMeterRegistry;
import com.bfm.service.ServiceException;
import io.grpc.ManagedChannel;
import io.grpc.stub.AbstractStub;
import io.grpc.testing.GrpcCleanupRule;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import java.io.IOException;
import java.util.Collections;
import java.util.Iterator;

import static junit.framework.TestCase.assertNotNull;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.powermock.api.mockito.PowerMockito.doThrow;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore("javax.net.ssl.*")
@PrepareForTest({ManagedChannel.class, LibRedBlueProxy.class, StatCollectorMeterRegistry.class, AltsDataWorkspaceDAO.class, EmailNotification.class})
public class ShareClassServiceClientTest extends BaseUnitTest {

    private ManagedChannel mockChannel;
    private AltsDataWorkspaceDAO mockDAO;
    private ShareClassServiceClient shareClassServiceClient;
    private AbstractStub serviceStub;
    private EntityProcessor<ShareClass> shareClassProcessorMock;

    private StatCollectorMeterRegistry registry;

    @Rule
    public final GrpcCleanupRule grpcCleanup = new GrpcCleanupRule();
    private ClientInfo client;

    @Before
    public void init() throws Exception {
        client = buildTestClientInfoWithAllEntityType("dummy", "Dummy");
        MockitoAnnotations.initMocks(this);
        mockChannel = mock(ManagedChannel.class);
        mockStatic(EmailNotification.class);
        mockStatic(StatCollectorMeterRegistry.class);
        mockStatic(LibRedBlueProxy.class);
        registry = PowerMockito.mock(StatCollectorMeterRegistry.class);
        when(StatCollectorMeterRegistry.getInstance()).thenReturn(registry);
        mockDAO = mock(AltsDataWorkspaceDAO.class);
        shareClassProcessorMock = mock(EntityProcessor.class);
        shareClassServiceClient = new ShareClassServiceClient(mockChannel, mockDAO, shareClassProcessorMock);
        shareClassServiceClient.registry = registry;
        serviceStub = TestUtils.initServerAndBlockingClient(grpcCleanup, TestUtils.MockShareClassServer.class);
        Whitebox.setInternalState(shareClassServiceClient,"serviceStub", serviceStub);
        Whitebox.setInternalState(shareClassServiceClient,"unaryCallTimeoutMillis", 1500);
        when(shareClassProcessorMock.processEntity(any(ShareClass.class))).thenAnswer(new Answer<ShareClass>() {
            @Override
            public ShareClass answer(InvocationOnMock invocation) throws Throwable {
                Object[] args = invocation.getArguments();
                return (ShareClass) args[0];
            }
        });
        when(shareClassProcessorMock.getEntityEpochOriginTime(any(ShareClass.class))).thenReturn(System.currentTimeMillis()+100);
        when(LibRedBlueProxy.getNetworkPredicatesByColor(NetworkMode.RED)).thenReturn(Collections.EMPTY_LIST);
    }


    @Test
    public void initiateSingleBlockingRequest() throws IOException, ADLException {
        //Arrange
        long time = System.currentTimeMillis();

        //Act
        Iterator<ShareClass> iterator = shareClassServiceClient.initiateSingleBlockingRequest(time, client, null);

        //Verify
        assertNotNull(iterator);
        assertNotNull(iterator.hasNext());
    }

    @Test
    public void getEntity() {
        //Arrange
        ShareClassRequest shareClassRequest = ShareClassRequest.newBuilder().setGuid("ABCD").build();
        //Act
        ShareClass resp = shareClassServiceClient.getEntity(shareClassRequest);
        //Verify
        assertEquals(AppConstants.NETWORK_MODE, resp.getEntityInfo().getNetworkMode());
    }

    @Test
    public void getEntityFailure() throws IOException {
        //Arrange
        ShareClassRequest shareClassRequest = ShareClassRequest.newBuilder().setGuid("ABCD").build();
        doThrow(new RuntimeException("ADL Failure")).when(mockDAO).insertRecords(anyList());
        //Act
        try {
            shareClassServiceClient.getEntity(shareClassRequest);
        } catch (ServiceException e) {
            assertEquals("Failed to get ShareClass:ADL Failure", e.getMessage());
        }
    }
}