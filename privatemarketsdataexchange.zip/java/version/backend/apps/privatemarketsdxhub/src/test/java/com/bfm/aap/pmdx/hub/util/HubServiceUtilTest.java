package com.bfm.aap.pmdx.hub.util;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.powermock.api.mockito.PowerMockito.when;

import java.time.Instant;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.adl.ADLException;
import com.bfm.util.BFMDate;
import com.bfm.util.BFMDateTime;

@RunWith(PowerMockRunner.class)
public class HubServiceUtilTest extends BaseUnitTest {
    @Mock
    private AltsDataWorkspaceDAO altsDataWorkspaceDAO;

    @InjectMocks
    HubServiceUtil hubServiceUtil;

    @Before
    public void init() throws ADLException {
        when(this.altsDataWorkspaceDAO.fetchLastSuccessfulTime(any(NetworkMode.class), anyString()))
                .thenReturn(12345678l);
    }

    @Test
    public void testGetLastSuccessfulTime() throws ADLException {
        BFMDate startDate = new BFMDate("01/01/2020", BFMDate.FMT_Slash0);
        BFMDateTime dateTime = new BFMDateTime(startDate);
        long datetime=  dateTime.toJavaTime();
        assertThat(hubServiceUtil.getLastSuccessfulTime("Test", ServiceEnum.CRM)).isEqualTo(datetime);
        assertThat(hubServiceUtil.getLastSuccessfulTime("Test", ServiceEnum.INVESTMENTS)).isEqualTo(Instant.EPOCH.toEpochMilli());
        assertThat(hubServiceUtil.getLastSuccessfulTime("ALADDIN_DEMO", ServiceEnum.INVESTMENTS)).isEqualTo(12345678l);
    }
}
