package com.bfm.aap.pmdx.hub.service.process;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.model.BankAccount;
import com.bfm.aap.pmdx.model.util.LibRedBlueProxy;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.model.util.NetworkModeHelper;
import com.bfm.aap.pmdx.notification.service.EmailNotification;
import com.google.protobuf.util.Timestamps;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.bfm.aap.pmdx.model.util.NetworkModeHelper.getCompliment;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@RunWith(PowerMockRunner.class)
@PrepareForTest({EmailNotification.class, LibRedBlueProxy.class})
public class BankAccountProcessorTest extends BaseUnitTest {


    @InjectMocks
    BankAccountProcessor bankAccountProcessor;

    private final NetworkMode serverMode = NetworkModeHelper.getNetworkModeFromString(System.getProperty("mode"));

    @Before
    public void init() {
        bankAccountProcessor.isPrimary = true;
    }

    @Test
    public void getLastSuccessfulTime() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<BankAccount> bankAccounts = getBankAccounts(t1, t2, t3);
        //Act
        long lastSuccessfulTime = bankAccountProcessor.getLastSuccessfulTime(bankAccounts);
        //Verify
        assertEquals(t3, lastSuccessfulTime);
    }

    @Test
    public void processEntities() throws Exception {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<BankAccount> bankAccounts = getBankAccounts(t1, t2, t3);
        //invalid Instrument
        bankAccounts.add(BankAccount.newBuilder().setBankAccountId("dummyID").setBankAccount("Invalid BankAccount").build());
        BankAccount.Builder fb = BankAccount.newBuilder(bankAccounts.get(0)).setBankAccountId("id5");
        fb.getEntityInfoBuilder().setNetworkMode(getCompliment(serverMode));
        bankAccounts.add(fb.build());

        //Act
        List<BankAccount> updatedInstruments = bankAccountProcessor.processEntities(bankAccounts);

        //Verify
        assertEquals(bankAccounts.size() - 2, updatedInstruments.size());
        assertEquals(3, updatedInstruments.stream().filter(a -> a.getEntityInfo().getPrimaryData()).count());
        assertEquals(3, updatedInstruments.stream().filter(a -> a.getEntityInfo().getNetworkMode() == serverMode).count());
    }

    @Test
    public void processEntities_PrimaryFlagTest() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<BankAccount> bankAccounts = getBankAccounts(t1 + 1000, t2 + 1000, t3 + 1000);
        //invalid Instrument
        bankAccounts.add(BankAccount.newBuilder().setBankAccountId("dummyID").setBankAccount("Invalid bankAccounts").build());
        BankAccount.Builder fb = BankAccount.newBuilder(bankAccounts.get(0)).setBankAccountId("id5");
        fb.getEntityInfoBuilder().setOriginTimestamp(Timestamps.fromMillis(t1 - 1000));
        bankAccounts.add(fb.build());

        //Act
        List<BankAccount> updatedInstruments = bankAccountProcessor.processEntities(bankAccounts);

        //Verify
        assertEquals(4, updatedInstruments.size());
        assertEquals(4, updatedInstruments.stream().filter(a -> a.getEntityInfo().getPrimaryData()).count());
        assertEquals(4, updatedInstruments.stream().filter(a -> a.getEntityInfo().getNetworkMode() == serverMode).count());
    }

    @Test
    public void processEntity() throws Exception {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<BankAccount> bankAccounts = getBankAccounts(t1 + 1000, t2 + 1000, t3 + 1000);

        //Act
        BankAccount updatedBankAccounts = bankAccountProcessor.processEntity(bankAccounts.get(0));
        BankAccount updatedBankAccounts2 = bankAccountProcessor.processEntity(bankAccounts.get(1));

        //Verify
        assertTrue(updatedBankAccounts.getEntityInfo().getPrimaryData());
        assertTrue(updatedBankAccounts2.getEntityInfo().getPrimaryData());
        assertEquals(serverMode, updatedBankAccounts.getEntityInfo().getNetworkMode());
    }

    @Test
    public void processEntity_InvalidEntity() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<BankAccount> bankAccounts = getBankAccounts(t1 + 1000, t2 + 1000, t3 + 1000);

        //Act
        try {
            bankAccountProcessor.processEntity(bankAccounts.get(0));
//            fail();
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("Invalid entity info for"));
        }
    }

    private List<BankAccount> getBankAccounts(long t1, long t2, long t3) {
        BankAccount.Builder fa1 = BankAccount.newBuilder().setBankAccountId("id1");
        fa1.getEntityInfoBuilder().setNetworkMode(serverMode).setOriginTimestamp(Timestamps.fromMillis(t1));
        BankAccount.Builder fa2 = BankAccount.newBuilder().setBankAccountId("id2");
        fa2.getEntityInfoBuilder().setNetworkMode(serverMode).setOriginTimestamp(Timestamps.fromMillis(t2));
        BankAccount.Builder fa3 = BankAccount.newBuilder().setBankAccountId("id3");
        fa3.getEntityInfoBuilder().setNetworkMode(serverMode).setOriginTimestamp(Timestamps.fromMillis(t3));
        return new ArrayList<>(Arrays.asList(fa1.build(), fa2.build(), fa3.build()));
    }
}
