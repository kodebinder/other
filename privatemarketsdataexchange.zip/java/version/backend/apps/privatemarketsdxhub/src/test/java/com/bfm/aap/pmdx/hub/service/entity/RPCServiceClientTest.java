package com.bfm.aap.pmdx.hub.service.entity;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.hub.model.ExecutionStatus;
import com.bfm.aap.pmdx.hub.model.async.TaskResult;
import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.model.util.CircuitBreakerHelper;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.LibRedBlueProxy;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.adl.ADLException;
import com.bfm.metric.StatCollectorMeterRegistry;
import com.google.protobuf.GeneratedMessageV3;
import com.google.protobuf.Message;
import io.grpc.CallOptions;
import io.grpc.Channel;
import io.grpc.ClientInterceptor;
import io.grpc.Status;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.AbstractStub;
import io.grpc.testing.GrpcCleanupRule;
import io.micrometer.core.instrument.Timer;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.powermock.api.mockito.PowerMockito.doThrow;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore("javax.net.ssl.*")
@PrepareForTest({LibRedBlueProxy.class, StatCollectorMeterRegistry.class, MockServiceBlockingStub.class})
public class RPCServiceClientTest extends BaseUnitTest {

    private RPCServiceClient rpcServiceClient;

    @Mock
    private CircuitBreakerHelper circuitBreakerHelper;

    @Mock
    private AltsDataWorkspaceDAO altsDataWorkspaceDAO;

    @Mock
    private EntityProcessor entityProcessor;

    @Mock
    private StatCollectorMeterRegistry registry;

    @Mock
    private MockServiceBlockingStub serviceStub;

    @Mock
    private MockProtoSinceRequest mockProtoSinceRequest;

    @Mock
    private Timer timer;

    private ClientInfo client;

    @Rule
    public final GrpcCleanupRule grpcCleanup = new GrpcCleanupRule();

    @Before
    public void init() throws Exception {
        mockStatic(StatCollectorMeterRegistry.class);
        when(StatCollectorMeterRegistry.getInstance()).thenReturn(registry);
        client = buildTestClientInfoWithAllEntityType("Dummy", "dummy");
        mockStatic(LibRedBlueProxy.class);

        rpcServiceClient = new RPCServiceClient(circuitBreakerHelper, altsDataWorkspaceDAO);

        setMocks();
    }

    private void setMocks() throws Exception {
        when(serviceStub.withInterceptors(Matchers.<ClientInterceptor>anyVararg())).thenReturn(serviceStub);
        when(serviceStub.getMockSince(any(MockProtoSinceRequest.class))).thenReturn(Arrays.asList(MockProto.getDefaultInstance(), MockProto.getDefaultInstance()).iterator());
        when(entityProcessor.processEntity(any(MockProto.class))).thenAnswer((Answer<MockProto>) invocation -> {
            Object[] args = invocation.getArguments();
            return (MockProto) args[0];
        });
        when(altsDataWorkspaceDAO.insertRecord(any(MockProto.class))).thenAnswer(new Answer<String>() {
            @Override
            public String answer(InvocationOnMock invocation) throws Throwable {
                Object[] args = invocation.getArguments();
                return ((MockProto) args[0]).getMockId();
            }
        });
        when(registry.timer(anyString(), Matchers.<String>anyVararg())).thenReturn(timer);
        long time1 = System.currentTimeMillis() - 5000, time2 = System.currentTimeMillis() + 5000, time3 = System.currentTimeMillis() + 5000;
        when(entityProcessor.getEntityEpochOriginTime(any(MockProto.class))).thenReturn(time1 + 15000);
        when(entityProcessor.getEntityType()).thenReturn(EntityType.COMPANY.toString());
        when(LibRedBlueProxy.getNetworkPredicatesByColor(NetworkMode.RED)).thenReturn(getBQLHistoryResponse(time1, time2, time3));
    }

    @Test
    public void doFetchSinceTest() {
        //Arrange

        //Act
        TaskResult<Set<String>> result = rpcServiceClient.doFetchSince(MockServiceBlockingStub::getMockSince, serviceStub, mockProtoSinceRequest, entityProcessor, client, System.currentTimeMillis());

        //Verify
        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo(ExecutionStatus.COMPLETED);
        assertThat(result.getResult()).isNotEmpty().size().isEqualTo(2);
        assertThat(result.getLastEntityTime()).isGreaterThan(System.currentTimeMillis());
    }

    @Test
    public void doFetchSinceTest_GRPCFailure() {
        //Arrange
        doThrow(new StatusRuntimeException(Status.CANCELLED)).when(serviceStub).getMockSince(any(MockProtoSinceRequest.class));
        //Act
        TaskResult<Set<String>> result = rpcServiceClient.doFetchSince(MockServiceBlockingStub::getMockSince, serviceStub, mockProtoSinceRequest, entityProcessor, client, System.currentTimeMillis());

        //Verify
        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo(ExecutionStatus.EXCEPTION);
        assertThat(result.getResult()).isEmpty();
        assertThat(result.getFailureMessage()).contains("GRPC request failed with status");
    }

    @Test
    public void doFetchSinceTest_ADLFailure() throws ADLException {
        //Arrange
        doThrow(new RuntimeException("ADL failure")).when(altsDataWorkspaceDAO).insertRecord(any(MockProto.class));
        //Act
        TaskResult<Set<String>> result = rpcServiceClient.doFetchSince(MockServiceBlockingStub::getMockSince, serviceStub, mockProtoSinceRequest, entityProcessor, client, System.currentTimeMillis());

        //Verify
        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo(ExecutionStatus.COMPLETED);
        assertThat(result.getResult()).isEmpty();
    }

}

class MockServiceBlockingStub extends AbstractStub<MockServiceBlockingStub> {
    private MockServiceBlockingStub(Channel channel) {
        super(channel);
    }

    private MockServiceBlockingStub(Channel channel, CallOptions callOptions) {
        super(channel, callOptions);
    }

    @Override
    protected MockServiceBlockingStub build(Channel channel, CallOptions callOptions) {
        return new MockServiceBlockingStub(channel, callOptions);
    }

    public Iterator<MockProto> getMockSince(MockProtoSinceRequest request) {
        return Collections.<MockProto>emptyList().iterator();
    }
}

abstract class MockProto extends GeneratedMessageV3 {
    static final MockProto DEFAULT_INSTANCE;

    static {
        DEFAULT_INSTANCE = new MockProto() {
            @Override
            public Message getDefaultInstanceForType() { return null; }

            @Override
            public Message.Builder newBuilderForType() { return null; }

            @Override
            public Message.Builder toBuilder() { return null;}

            @Override
            protected FieldAccessorTable internalGetFieldAccessorTable() { return null;}

            @Override
            protected Message.Builder newBuilderForType(BuilderParent builderParent) { return null;}
        };
    }

    public static MockProto getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    String getMockId() {return RandomStringUtils.random(32);}
}

abstract class MockProtoSinceRequest extends GeneratedMessageV3 {}