package com.bfm.aap.pmdx.hub.service;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.aap.pmdx.hub.repository.ClientInfoDAO;
import com.bfm.aap.pmdx.hub.service.async.ZookeeperHelper;
import com.bfm.aap.pmdx.hub.service.entity.CompanyServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.ContactServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.EntityService;
import com.bfm.aap.pmdx.hub.service.entity.InvestorAccountServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.InvestorServiceClient;
import com.bfm.aap.pmdx.hub.util.AppConstants;
import com.bfm.aap.pmdx.hub.util.ServiceEnum;
import com.bfm.aap.pmdx.model.Asset;
import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.Fundamentals;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.InvestorAccount;
import com.bfm.aap.pmdx.model.Portfolio;
import com.bfm.aap.pmdx.model.Position;
import com.bfm.aap.pmdx.model.Transaction;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.notification.service.EmailNotification;
import com.bfm.aap.pmdx.services.AssetRequest;
import com.bfm.aap.pmdx.services.CompanyRequest;
import com.bfm.aap.pmdx.services.ContactRequest;
import com.bfm.aap.pmdx.services.FundamentalsRequest;
import com.bfm.aap.pmdx.services.InvestorRequest;
import com.bfm.aap.pmdx.services.PortfolioRequest;
import com.bfm.aap.pmdx.services.PositionRequest;
import com.bfm.aap.pmdx.services.TransactionRequest;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.adl.ADLException;
import com.bfm.adl.exception.ADLErrorCodes;
import com.bfm.adl.exception.ADLExceptionImpl;
import com.bfm.beam2.error.Beam2Exception;
import com.bfm.service.ServiceException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.doThrow;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({AppConstants.class, EmailNotification.class, ZookeeperHelper.class})
public class PrivateMarketsDXHubServiceImplTest extends BaseUnitTest {

    @Mock
    private EntityService<Asset, AssetRequest> assetServiceMock;
    @Mock
    private EntityService<Portfolio, PortfolioRequest> portfolioServiceMock;
    @Mock
    private EntityService<Position, PositionRequest> positionServiceMock;
    @Mock
    private EntityService<Fundamentals, FundamentalsRequest> fundamentalsServiceMock;
    @Mock
    private EntityService<Transaction, TransactionRequest> transactionsServiceMock;
    @Mock
    private ZookeeperHelper zookeeperHelper;
    @Mock
    private ContactServiceClient contactServiceClient;
    @Mock
    private CompanyServiceClient companyServiceClient;
    @Mock
    private InvestorServiceClient investorServiceClient;
    @Mock
    private InvestorAccountServiceClient investorAccountServiceClient;
    @Mock
    private AltsDataWorkspaceDAO altsDataWorkspaceDAO;
    @Mock
    private ClientInfoDAO clientInfoDAO;
    @Mock
    private CRMThirdPartyMapperService crmThirdPartyMapperService;

    private List<ClientInfo> clients;

    @InjectMocks
    PrivateMarketsDXHubServiceImpl privateMarketsDXHubService;


    @Before
    public void setup() {
        Whitebox.setInternalState(privateMarketsDXHubService, "assetService", assetServiceMock);
        Whitebox.setInternalState(privateMarketsDXHubService, "portfolioService", portfolioServiceMock);
        Whitebox.setInternalState(privateMarketsDXHubService, "positionService", positionServiceMock);
        Whitebox.setInternalState(privateMarketsDXHubService, "fundamentalsService", fundamentalsServiceMock);
        Whitebox.setInternalState(privateMarketsDXHubService, "transactionsService", transactionsServiceMock);
    }

    @Test
    public void getFundAsset() {
        //Arrange
        Asset fundAsset = Asset.getDefaultInstance();
        AssetRequest assetRequest = AssetRequest.newBuilder().setGuid("ABCD").build();
        when(assetServiceMock.getEntity(assetRequest)).thenReturn(fundAsset);
        //Act
        Asset resp = privateMarketsDXHubService.getAsset(assetRequest);
        //Verify
        assertEquals(fundAsset, resp);
    }

    @Test
    public void getFundAssetFailure() {
        //Arrange
        AssetRequest assetRequest = AssetRequest.newBuilder().setGuid("ABCD").build();
        doThrow(new ServiceException("grpc failure")).when(assetServiceMock).getEntity(assetRequest);
        //Act
        try {
            privateMarketsDXHubService.getAsset(assetRequest);
        } catch (Exception e) {
            assertEquals("grpc failure", e.getMessage());
        }
    }

    @Test
    public void getPortfolio() {
        //Arrange
        Portfolio portfolio = Portfolio.getDefaultInstance();
        PortfolioRequest portfolioRequest = PortfolioRequest.newBuilder().setGuid("ABCD").build();
        when(portfolioServiceMock.getEntity(portfolioRequest)).thenReturn(portfolio);
        //Act
        Portfolio resp = privateMarketsDXHubService.getPortfolio(portfolioRequest);
        //Verify
        assertEquals(portfolio, resp);
    }

    @Test
    public void getPortfolioFailure() {
        //Arrange
        PortfolioRequest portfolioRequest = PortfolioRequest.newBuilder().setGuid("ABCD").build();
        doThrow(new ServiceException("grpc failure")).when(portfolioServiceMock).getEntity(portfolioRequest);
        //Act
        try {
            privateMarketsDXHubService.getPortfolio(portfolioRequest);
        } catch (Exception e) {
            assertEquals("grpc failure", e.getMessage());
        }
    }

    @Test
    public void getPosition() {
        //Arrange
        Position position = Position.getDefaultInstance();
        PositionRequest positionRequest = PositionRequest.newBuilder().setGuid("ABCD").build();
        when(positionServiceMock.getEntity(positionRequest)).thenReturn(position);
        //Act
        Position resp = privateMarketsDXHubService.getPosition(positionRequest);
        //Verify
        assertEquals(position, resp);
    }

    @Test
    public void getPositionFailure() {
        //Arrange
        PositionRequest positionRequest = PositionRequest.newBuilder().setGuid("ABCD").build();
        doThrow(new ServiceException("grpc failure")).when(positionServiceMock).getEntity(positionRequest);
        //Act
        try {
            privateMarketsDXHubService.getPosition(positionRequest);
        } catch (Exception e) {
            assertEquals("grpc failure", e.getMessage());
        }
    }

    @Test
    public void getFundamentals() {
        //Arrange
        Fundamentals fundamentals = Fundamentals.getDefaultInstance();
        FundamentalsRequest fundamentalsRequest = FundamentalsRequest.newBuilder().setGuid("ABCD").build();
        when(fundamentalsServiceMock.getEntity(fundamentalsRequest)).thenReturn(fundamentals);
        //Act
        Fundamentals resp = privateMarketsDXHubService.getFundamentals(fundamentalsRequest);
        //Verify
        assertEquals(fundamentals, resp);
    }

    @Test
    public void getFundamentalsFailure() {
        //Arrange
        FundamentalsRequest fundamentalsRequest = FundamentalsRequest.newBuilder().setGuid("ABCD").build();
        doThrow(new ServiceException("grpc failure")).when(fundamentalsServiceMock).getEntity(fundamentalsRequest);
        //Act
        try {
            privateMarketsDXHubService.getFundamentals(fundamentalsRequest);
        } catch (Exception e) {
            assertEquals("grpc failure", e.getMessage());
        }
    }

    @Test
    public void getTransaction () {
        //Arrange
        Transaction transaction = Transaction.getDefaultInstance();
        TransactionRequest transactionRequest = TransactionRequest.newBuilder().setGuid("ABCD").build();
        when(transactionsServiceMock.getEntity(transactionRequest)).thenReturn(transaction);
        //Act
        Transaction resp = privateMarketsDXHubService.getTransaction(transactionRequest);
        //Verify
        assertEquals(transaction, resp);
    }

    @Test
    public void getTransactionFailure() {
        //Arrange
        TransactionRequest transactionRequest = TransactionRequest.newBuilder().setGuid("ABCD").build();
        doThrow(new ServiceException("grpc failure")).when(transactionsServiceMock).getEntity(transactionRequest);
        //Act
        try {
            privateMarketsDXHubService.getTransaction(transactionRequest);
        } catch (Exception e) {
            assertEquals("grpc failure", e.getMessage());
        }
    }

    @Test
    public void testUpdateSinceTime() {
        //Arrange
        final long epochTimeMillis = System.currentTimeMillis();
        //Act
        privateMarketsDXHubService.updateSinceTime(epochTimeMillis, "Demo", "Investments");
        //Verify
        verify(zookeeperHelper, times(1)).updateLastSuccessfulTime(eq("Demo"), any(ServiceEnum.class), anyLong());
    }

    @Test
    public void testUpdateSinceTime_InvalidData() {
        //Arrange
        final long epochTimeMillis = System.currentTimeMillis();
        doThrow(new RuntimeException("Failed to update since time")).when(zookeeperHelper).updateLastSuccessfulTime(anyString(), any(), anyLong());
        //Act
        try {
            privateMarketsDXHubService.updateSinceTime(epochTimeMillis,"ASSET", "Investments");
            fail();
        } catch (Beam2Exception.ProcessingError ex) {
            assertTrue(ex.getMessage().contains("Failed to update since time"));
        }
    }

    @Test
    public void testUpdateSinceTime_EmptyService() {
        //Arrange
        final long epochTimeMillis = System.currentTimeMillis();
        //Act
        privateMarketsDXHubService.updateSinceTime(epochTimeMillis, "Demo", "Test");
        //Verify
        verify(zookeeperHelper, never()).updateLastSuccessfulTime(eq("Demo"), any(ServiceEnum.class), anyLong());
    }

    @Test
    public void testUpdateClientStatusToComplete() {
        //Arrange

        //Act
        privateMarketsDXHubService.updateClientStatusToComplete("Demo", "Investments");
        //Verify
        verify(zookeeperHelper, times(1)).updateChildNodeStatusToComplete(eq("Demo"), any(ServiceEnum.class));
    }

    @Test
    public void testUpdateClientStatusToComplete_InvalidData() {
        //Arrange
        doThrow(new RuntimeException("Failed to update client status")).when(zookeeperHelper).updateChildNodeStatusToComplete(anyString(), any());
        //Act
        try {
            privateMarketsDXHubService.updateClientStatusToComplete("ASSET", "Investments");
            fail();
        } catch (Beam2Exception.ProcessingError ex) {
            assertTrue(ex.getMessage().contains("Failed to update client status"));
        }
    }

    @Test
    public void testUpdateClientStatusToComplete_EmptyService() {
        //Arrange
        //Act
        privateMarketsDXHubService.updateClientStatusToComplete( "Demo", "Test");
        //Verify
        verify(zookeeperHelper, never()).updateChildNodeStatusToComplete(eq("Demo"), any(ServiceEnum.class));
    }

    @Test
    public void updateCRMEntities() throws Exception {

        // Arrange
        clients = getAllTestClientInfo(Collections.singletonList("AladdinDemo"));
        when(this.clientInfoDAO.getCRMClients()).thenReturn(this.clients);
        when(altsDataWorkspaceDAO.insertRecord(any())).thenReturn("1234");
        when(contactServiceClient.updateContact(any(ContactRequest.class),any(ClientInfo.class), anyInt())).thenReturn("ABC");
        //Act
        privateMarketsDXHubService.updateContact(createContactRequest(),213);
        //verify
        verify(crmThirdPartyMapperService).create(anyString(),anyInt(), any(ThirdPartyMappingEnum.class));
    }

    private ContactRequest createContactRequest() {
        return ContactRequest.newBuilder().setContact(Contact.newBuilder().setModifiedBy("tsgops").build()).build();
    }

    @Test
    public void updateCRMEntities_ADLFailure() throws ADLException {
        // Arrange
        clients = getAllTestClientInfo(Collections.singletonList("AladdinDemo"));
        when(this.clientInfoDAO.getCRMClients()).thenReturn(this.clients);
        when(contactServiceClient.updateContact(any(ContactRequest.class),any(ClientInfo.class), anyInt())).thenReturn("ABC");
        when(companyServiceClient.updateCompany(any(CompanyRequest.class),any(ClientInfo.class), anyInt())).thenReturn("ABC");
        when(investorServiceClient.updateInvestor(any(InvestorRequest.class),any(ClientInfo.class), anyInt())).thenReturn("ABC");
        when(investorAccountServiceClient.updateInvestorAccount(any(InvestorAccount.class),any(ClientInfo.class), anyInt())).thenReturn("ABC");
        when(altsDataWorkspaceDAO.updateRecord(any(Contact.class),anyString(), anyString())).thenThrow(new ADLExceptionImpl(ADLErrorCodes.UNRECOVERABLE_ERROR));
        when(altsDataWorkspaceDAO.updateRecord(any(Company.class),anyString(), anyString())).thenThrow(new ADLExceptionImpl(ADLErrorCodes.UNRECOVERABLE_ERROR));
        when(altsDataWorkspaceDAO.updateRecord(any(Investor.class),anyString(), anyString())).thenThrow(new ADLExceptionImpl(ADLErrorCodes.UNRECOVERABLE_ERROR));
//        doThrow(new ADLExceptionImpl(ADLErrorCodes.UNRECOVERABLE_ERROR)).when(altsDataWorkspaceDAO).updateRecord(any(Contact.class),anyString(), anyString());

        //Act
        try {
            privateMarketsDXHubService.updateCompany(CompanyRequest.getDefaultInstance(),123);
        }catch (Exception ex){
            //verify
            assertTrue(ex.getMessage().contains(ADLErrorCodes.UNRECOVERABLE_ERROR.getDescription()));
        }
        try {
            privateMarketsDXHubService.updateContact(ContactRequest.getDefaultInstance(),123);
        }catch (Exception ex){
            //verify
            assertTrue(ex.getMessage().contains(ADLErrorCodes.UNRECOVERABLE_ERROR.getDescription()));
        }
        try {
            privateMarketsDXHubService.updateInvestor(InvestorRequest.getDefaultInstance(),123);
        }catch (Exception ex){
            //verify
            assertTrue(ex.getMessage().contains(ADLErrorCodes.UNRECOVERABLE_ERROR.getDescription()));
        }
        try {
            privateMarketsDXHubService.updateInvestorAccount(InvestorAccount.getDefaultInstance(),123);
        }catch (Exception ex){
            //verify
            assertTrue(ex.getMessage().contains(ADLErrorCodes.UNRECOVERABLE_ERROR.getDescription()));
        }

    }

    @Test
    public void updateCRMEntities_ServiceException() {
        // Arrange
        clients = getAllTestClientInfo(Collections.singletonList("AladdinDemo"));
        when(this.clientInfoDAO.getCRMClients()).thenReturn(this.clients);

        doThrow(new ServiceException("Error while calling grpc")).when(investorServiceClient).updateInvestor(any(InvestorRequest.class),any(ClientInfo.class), anyInt());
        doThrow(new ServiceException("Error while calling grpc")).when(contactServiceClient).updateContact(any(ContactRequest.class),any(ClientInfo.class), anyInt());
        doThrow(new ServiceException("Error while calling grpc")).when(companyServiceClient).updateCompany(any(CompanyRequest.class),any(ClientInfo.class), anyInt());
        doThrow(new ServiceException("Error while calling grpc")).when(investorAccountServiceClient).updateInvestorAccount(any(InvestorAccount.class),any(ClientInfo.class), anyInt());
        //Act
        try {
            privateMarketsDXHubService.updateInvestor(InvestorRequest.getDefaultInstance(),123);
        } catch(Exception ex) {
            //verify
            assertTrue(ex.getMessage().contains("Error while calling grpc"));
        }
        try {
            privateMarketsDXHubService.updateContact(ContactRequest.getDefaultInstance(),123);
        } catch(Exception ex) {
            //verify
            assertTrue(ex.getMessage().contains("Error while calling grpc"));
        }
        try {
            privateMarketsDXHubService.updateCompany(CompanyRequest.getDefaultInstance(),123);
        } catch(Exception ex) {
            //verify
            assertTrue(ex.getMessage().contains("Error while calling grpc"));
        }
        //Act
        try {
            privateMarketsDXHubService.updateInvestorAccount(InvestorAccount.getDefaultInstance(),123);
        } catch(Exception ex) {
            //verify
            assertTrue(ex.getMessage().contains("Error while calling grpc"));
        }
    }

    @Test
    public void updateCRMEntities_Exception() {
        // Arrange
        clients = getAllTestClientInfo(Collections.singletonList("AladdinDemo"));
        when(this.clientInfoDAO.getCRMClients()).thenReturn(this.clients);

        doThrow(new RuntimeException("Error while calling grpc")).when(investorServiceClient).updateInvestor(any(InvestorRequest.class),any(ClientInfo.class), anyInt());
        doThrow(new RuntimeException("Error while calling grpc")).when(contactServiceClient).updateContact(any(ContactRequest.class),any(ClientInfo.class), anyInt());
        doThrow(new RuntimeException("Error while calling grpc")).when(companyServiceClient).updateCompany(any(CompanyRequest.class),any(ClientInfo.class), anyInt());
        doThrow(new RuntimeException("Error while calling grpc")).when(investorAccountServiceClient).updateInvestorAccount(any(InvestorAccount.class),any(ClientInfo.class), anyInt());

        //Act
        try {
            privateMarketsDXHubService.updateInvestor(InvestorRequest.getDefaultInstance(),123);
        } catch(Exception ex) {
            //verify
            assertTrue(ex.getMessage().contains("Error while calling grpc"));
        }
        try {
            privateMarketsDXHubService.updateContact(ContactRequest.getDefaultInstance(),123);
        } catch(Exception ex) {
            //verify
            assertTrue(ex.getMessage().contains("Error while calling grpc"));
        }
        try {
            privateMarketsDXHubService.updateCompany(CompanyRequest.getDefaultInstance(),123);
        } catch(Exception ex) {
            //verify
            assertTrue(ex.getMessage().contains("Error while calling grpc"));
        }
        //Act
        try {
            privateMarketsDXHubService.updateInvestorAccount(InvestorAccount.getDefaultInstance(),123);
        } catch(Exception ex) {
            //verify
            assertTrue(ex.getMessage().contains("Error while calling grpc"));
        }
    }

}