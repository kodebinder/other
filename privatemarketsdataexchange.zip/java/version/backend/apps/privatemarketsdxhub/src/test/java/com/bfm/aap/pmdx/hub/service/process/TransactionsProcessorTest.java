package com.bfm.aap.pmdx.hub.service.process;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.model.Transaction;
import com.bfm.aap.pmdx.model.util.LibRedBlueProxy;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.model.util.NetworkModeHelper;
import com.bfm.aap.pmdx.notification.service.EmailNotification;
import com.google.protobuf.util.Timestamps;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.bfm.aap.pmdx.model.util.NetworkModeHelper.getCompliment;
import static org.junit.Assert.assertEquals;

@RunWith(PowerMockRunner.class)
@PrepareForTest({EmailNotification.class, LibRedBlueProxy.class})
public class TransactionsProcessorTest extends BaseUnitTest {

    @InjectMocks
    TransactionsProcessor transactionsProcessor;

    private final NetworkMode serverMode = NetworkModeHelper.getNetworkModeFromString(System.getProperty("mode"));

    @Before
    public void init() {
        transactionsProcessor.isPrimary = true;
    }

    @Test
    public void getLastSuccessfulTime() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<Transaction> txns = getTransactions(t1, t2, t3);
        //Act
        long lastSuccessfulTime = transactionsProcessor.getLastSuccessfulTime(txns);
        //Verify
        assertEquals(t3, lastSuccessfulTime);
    }

    @Test
    public void processEntity() throws Exception {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<Transaction> txns = getTransactions(t1, t2, t3);
        //invalid Performance
        txns.add(Transaction.newBuilder().build());
        Transaction.Builder pb = Transaction.newBuilder(txns.get(0));
        pb.getEntityInfoBuilder().setNetworkMode(getCompliment(serverMode));
        txns.add(pb.build());

        //Act
        List<Transaction> updatedTransactions = transactionsProcessor.processEntities(txns);

        //Verify
        assertEquals(txns.size() - 2, updatedTransactions.size());
        assertEquals(3, updatedTransactions.stream().filter(a -> a.getEntityInfo().getPrimaryData()).count());
        assertEquals(3, updatedTransactions.stream().filter(a -> a.getEntityInfo().getNetworkMode() == serverMode).count());
    }

    private List<Transaction> getTransactions(long t1, long t2, long t3) {
        Transaction.Builder fa1 = Transaction.newBuilder();
        fa1.getEntityInfoBuilder().setNetworkMode(serverMode).setOriginTimestamp(Timestamps.fromMillis(t1));
        Transaction.Builder fa2 = Transaction.newBuilder();
        fa2.getEntityInfoBuilder().setNetworkMode(serverMode).setOriginTimestamp(Timestamps.fromMillis(t2));
        Transaction.Builder fa3 = Transaction.newBuilder();
        fa3.getEntityInfoBuilder().setNetworkMode(serverMode).setOriginTimestamp(Timestamps.fromMillis(t3));
        return new ArrayList<>(Arrays.asList(fa1.build(), fa2.build(), fa3.build()));
    }

}
