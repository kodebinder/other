package com.bfm.aap.pmdx.hub.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.hub.service.security.PerlFileDecrypterService;
import com.bfm.aap.pmdx.hub.util.ServiceEnum;
import com.bfm.aap.pmdx.model.util.ClientInfo;

@RunWith(PowerMockRunner.class)
public class ClientInfoDAOImplTest extends BaseUnitTest {

    ClientInfoDAOImpl clientInfoDAO;
    PerlFileDecrypterService fileDecrypterService;

    @Before
    public void init() throws IOException {
        clientInfoDAO = new ClientInfoDAOImpl();
        fileDecrypterService = PowerMockito.mock(PerlFileDecrypterService.class);
        Whitebox.setInternalState(clientInfoDAO, "credentialsDirectory", "/proj/publish/alts/efront/config/encrypted/");
        setClientInfoInternalStates();
        when(fileDecrypterService.decrypt(any(File.class))).thenReturn("dummy");
        clientInfoDAO.init();
    }

    private void setClientInfoInternalStates(){
        Whitebox.setInternalState(clientInfoDAO, "credentialsDirectory", "/proj/publish/alts/efront/config/encrypted/");
        Whitebox.setInternalState(clientInfoDAO, "credentialsDirectoryPattern", "/usr/local/bfm/clients/XXX/std/encrypted/");
        Whitebox.setInternalState(clientInfoDAO, "fileDecrypterService", fileDecrypterService);
        Whitebox.setInternalState(clientInfoDAO, "disableSecureConnection", false);
        Whitebox.setInternalState(clientInfoDAO, "clientsJson", "[{\"clientName\":\"AladdinDemo\",\"clientId\":\"ALD-DEMO\",\"credentialsFileName\":\"AladdinDemo-PMDXHub.pwd\"},{\"clientName\":\"AladdinInvestDemo\",\"clientId\":\"AladdinInvestDemo\",\"credentialsFileName\":\"AladdinDemo-PMDXHub.pwd\"}]");
        Whitebox.setInternalState(clientInfoDAO, "servicesJson", "[{\"serviceName\":\"CRM\",\"entityTypes\":[\"CONTACT\",\"USER\"],\"requiredEntityTypes\":[\"USER\"],\"clientNames\":[\"AladdinDemo\"]},{\"serviceName\":\"Investments\",\"entityTypes\":[\"ASSET\",\"PORTFOLIO\",\"POSITION\",\"PERFORMANCE\",\"ISSUER\",\"FUNDAMENTALS\",\"HOLDING\"],\"requiredEntityTypes\":[\"ASSET\",\"PORTFOLIO\",\"POSITION\"],\"clientNames\":[\"ALADDINDEV\",\"ALADDINTST\",\"AladdinDemo\"]},{\"serviceName\":\"Investments\",\"entityTypes\":[\"ASSET\",\"PORTFOLIO\",\"POSITION\"],\"requiredEntityTypes\":[\"ASSET\"],\"clientNames\":[\"AladdinInvestDemo\",\"Velliv\"]},{\"serviceName\":\"CRM\",\"entityTypes\":[\"USER\",\"CONTACT\"],\"requiredEntityTypes\":[\"USER\"],\"clientNames\":[\"AladdinInvestDemo\",\"Velliv\"]}]");

    }

    @Test
    public void testInit_NonDev_Insecure() {
        //Arrange
        Whitebox.setInternalState(clientInfoDAO, "disableSecureConnection", true);

        //Verify
        ClientInfo clientInfo = clientInfoDAO.getClientById("ALD-DEMO");
        List<ClientInfo> crmClientsList = clientInfoDAO.getCRMClients();
        Map<String, List<ClientInfo>> crmClientsFromMap = clientInfoDAO.getServiceToClientMap();

        assertThat(clientInfo).isNotNull().extracting("clientName").isEqualTo(Arrays.asList("AladdinDemo"));
        assertThat(crmClientsList).isNotNull().contains(clientInfo);
        assertThat(crmClientsFromMap).isNotEmpty();
        assertThat(crmClientsFromMap).containsKeys(ServiceEnum.CRM.name());
    }

    @Test
    public void testInit_Without_InvestmentsService()  {

        //Arrange
        clientInfoDAO = new ClientInfoDAOImpl();
        setClientInfoInternalStates();
        Whitebox.setInternalState(clientInfoDAO, "disableSecureConnection", true);
        Whitebox.setInternalState(clientInfoDAO, "servicesJson", "[{\"serviceName\":\"CRM\",\"entityTypes\":[\"CONTACT\",\"USER\"],\"requiredEntityTypes\":[\"USER\"],\"clientNames\":[\"AladdinDemo\"]},{\"serviceName\":\"CRM\",\"entityTypes\":[\"CONTACT\",\"USER\"],\"requiredEntityTypes\":[\"USER\"],\"clientNames\":[\"AladdinInvestDemo\"]}]");
        clientInfoDAO.init();
        //Verify
        ClientInfo clientInfo = clientInfoDAO.getClientById("ALD-DEMO");
        List<ClientInfo> crmClientsList = clientInfoDAO.getCRMClients();
        List<ClientInfo> investmentClientsList = clientInfoDAO.getInvestmentClients();
        Map<String, List<ClientInfo>> crmClientsFromMap = clientInfoDAO.getServiceToClientMap();

        assertThat(clientInfo).isNotNull().extracting("clientName").isEqualTo(Arrays.asList("AladdinDemo"));
        assertThat(crmClientsList).isNotNull().contains(clientInfo);
        assertThat(investmentClientsList).isNullOrEmpty();
        assertThat(crmClientsFromMap).isNotEmpty();
        assertThat(crmClientsFromMap).containsKeys(ServiceEnum.CRM.name());
    }

    @Test
    public void testInit_NonDev_Secure(){
        //Arrange
        Whitebox.setInternalState(clientInfoDAO, "disableSecureConnection", false);
        Whitebox.setInternalState(clientInfoDAO, "credentialsDirectory", "");
        //Act
        clientInfoDAO.init();

        //Verify
        ClientInfo clientInfo = clientInfoDAO.getClientById("ALD-DEMO");
        assertThat(clientInfo).isNotNull().extracting("clientName").isEqualTo(Arrays.asList("AladdinDemo"));
    }

    @Test
    public void getClientById() {
        //Act
        ClientInfo clientInfo = clientInfoDAO.getClientById("ALD-DEMO");

        //Verify
        assertThat(clientInfo).isNotNull().extracting("clientName").isEqualTo(Arrays.asList("AladdinDemo"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void getClientById_Failure() {
        //Act
        ClientInfo clientInfo = clientInfoDAO.getClientById("ALD-DEMO2");
    }

    @Test
    public void getClientByName() {
        //Act
        ClientInfo clientInfo = clientInfoDAO.getClientByName("AladdinDemo");

        //Verify
        assertThat(clientInfo).isNotNull().extracting("clientName").isEqualTo(Arrays.asList("AladdinDemo"));
    }

    @Test
    public void getAllClients() {
        //Act
        List<ClientInfo> clientInfo = clientInfoDAO.getAllClients();

        //Verify
        assertThat(clientInfo).isNotEmpty().size().isEqualTo(2);
    }
}
