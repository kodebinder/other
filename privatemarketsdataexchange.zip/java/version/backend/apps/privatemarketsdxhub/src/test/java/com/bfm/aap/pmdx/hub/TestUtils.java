package com.bfm.aap.pmdx.hub;

import com.google.protobuf.Message;
import com.google.protobuf.util.Timestamps;
import io.grpc.BindableService;
import io.grpc.inprocess.InProcessChannelBuilder;
import io.grpc.inprocess.InProcessServerBuilder;
import io.grpc.stub.AbstractStub;
import io.grpc.stub.StreamObserver;
import io.grpc.testing.GrpcCleanupRule;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import java.util.function.Supplier;

import com.bfm.aap.pmdx.hub.util.AppConstants;
import com.bfm.aap.pmdx.model.Asset;
import com.bfm.aap.pmdx.model.BankAccount;
import com.bfm.aap.pmdx.model.BankOperation;
import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.Fundamentals;
import com.bfm.aap.pmdx.model.Instrument;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.Performance;
import com.bfm.aap.pmdx.model.Portfolio;
import com.bfm.aap.pmdx.model.Position;
import com.bfm.aap.pmdx.model.ShareClass;
import com.bfm.aap.pmdx.model.Transaction;
import com.bfm.aap.pmdx.model.User;
import com.bfm.aap.pmdx.services.AssetRequest;
import com.bfm.aap.pmdx.services.AssetServiceGrpc;
import com.bfm.aap.pmdx.services.AssetsSinceRequest;
import com.bfm.aap.pmdx.services.BankAccountRequest;
import com.bfm.aap.pmdx.services.BankAccountServiceGrpc;
import com.bfm.aap.pmdx.services.BankAccountsSinceRequest;
import com.bfm.aap.pmdx.services.BankOperationRequest;
import com.bfm.aap.pmdx.services.BankOperationServiceGrpc;
import com.bfm.aap.pmdx.services.BankOperationsSinceRequest;
import com.bfm.aap.pmdx.services.CompanyRequest;
import com.bfm.aap.pmdx.services.CompanyServiceGrpc;
import com.bfm.aap.pmdx.services.ContactRequest;
import com.bfm.aap.pmdx.services.ContactServiceGrpc;
import com.bfm.aap.pmdx.services.FundamentalsRequest;
import com.bfm.aap.pmdx.services.FundamentalsServiceGrpc;
import com.bfm.aap.pmdx.services.FundamentalsSinceRequest;
import com.bfm.aap.pmdx.services.HistoricalTransactionRequest;
import com.bfm.aap.pmdx.services.HistoricalTransactionServiceGrpc;
import com.bfm.aap.pmdx.services.HistoricalTransactionsSinceRequest;
import com.bfm.aap.pmdx.services.InstrumentRequest;
import com.bfm.aap.pmdx.services.InstrumentServiceGrpc;
import com.bfm.aap.pmdx.services.InstrumentsSinceRequest;
import com.bfm.aap.pmdx.services.InvestorRequest;
import com.bfm.aap.pmdx.services.InvestorServiceGrpc;
import com.bfm.aap.pmdx.services.PerformanceRequest;
import com.bfm.aap.pmdx.services.PerformanceServiceGrpc;
import com.bfm.aap.pmdx.services.PerformanceSinceRequest;
import com.bfm.aap.pmdx.services.PortfolioRequest;
import com.bfm.aap.pmdx.services.PortfolioServiceGrpc;
import com.bfm.aap.pmdx.services.PortfoliosSinceRequest;
import com.bfm.aap.pmdx.services.PositionRequest;
import com.bfm.aap.pmdx.services.PositionServiceGrpc;
import com.bfm.aap.pmdx.services.PositionsSinceRequest;
import com.bfm.aap.pmdx.services.ShareClassRequest;
import com.bfm.aap.pmdx.services.ShareClassServiceGrpc;
import com.bfm.aap.pmdx.services.ShareClassSinceRequest;
import com.bfm.aap.pmdx.services.TransactionRequest;
import com.bfm.aap.pmdx.services.TransactionServiceGrpc;
import com.bfm.aap.pmdx.services.TransactionsSinceRequest;
import com.bfm.aap.pmdx.services.UserServiceGrpc;
import com.bfm.aap.pmdx.services.UserSinceRequest;

public final class TestUtils {

    private static final Map<Class, BindableService> SERVER_MAP;

    static {
        SERVER_MAP = new HashMap<>();
        SERVER_MAP.put(MockAssetServer.class, new MockAssetServer());
        SERVER_MAP.put(MockPositionServer.class, new MockPositionServer());
        SERVER_MAP.put(MockPortfolioServer.class, new MockPortfolioServer());
        SERVER_MAP.put(MockPerformanceServer.class, new MockPerformanceServer());
        SERVER_MAP.put(MockFundamentalsServer.class, new MockFundamentalsServer());
        SERVER_MAP.put(MockUserServer.class, new MockUserServer());
        SERVER_MAP.put(MockContactServer.class, new MockContactServer());
        SERVER_MAP.put(MockCompanyServer.class, new MockCompanyServer());
        SERVER_MAP.put(MockInvestorServer.class, new MockInvestorServer());
        SERVER_MAP.put(MockTransactionServer.class, new MockTransactionServer());
        SERVER_MAP.put(MockShareClassServer.class, new MockShareClassServer());
        SERVER_MAP.put(MockInstrumentServer.class, new MockInstrumentServer());
        SERVER_MAP.put(MockBankAccountServer.class, new MockBankAccountServer());
        SERVER_MAP.put(MockBankOperationServer.class, new MockBankOperationServer());
        SERVER_MAP.put(MockHistoricalTransactionServer.class, new MockHistoricalTransactionServer());
    }

    private TestUtils() { }

    public static AbstractStub initServerAndBlockingClient(GrpcCleanupRule grpcCleanupRule, Class serverClazz) {
        String serverName = InProcessServerBuilder.generateName();

        try {
            // Create a server, add service, start, and register for automatic graceful shutdown.
            grpcCleanupRule.register(InProcessServerBuilder
                .forName(serverName).directExecutor().addService(SERVER_MAP.get(serverClazz)).build().start());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        if (serverClazz.isAssignableFrom(MockAssetServer.class)) {
            return AssetServiceGrpc.newBlockingStub(
                // Create a client channel and register for automatic graceful shutdown.
                grpcCleanupRule.register(InProcessChannelBuilder.forName(serverName).directExecutor().build()));
        }
        if (serverClazz.isAssignableFrom(MockPortfolioServer.class)) {
            return PortfolioServiceGrpc.newBlockingStub(
                // Create a client channel and register for automatic graceful shutdown.
                grpcCleanupRule.register(InProcessChannelBuilder.forName(serverName).directExecutor().build()));
        }
        if (serverClazz.isAssignableFrom(MockPositionServer.class)) {
            return PositionServiceGrpc.newBlockingStub(
                // Create a client channel and register for automatic graceful shutdown.
                grpcCleanupRule.register(InProcessChannelBuilder.forName(serverName).directExecutor().build()));
        }
        if (serverClazz.isAssignableFrom(MockPerformanceServer.class)) {
            return PerformanceServiceGrpc.newBlockingStub(
                // Create a client channel and register for automatic graceful shutdown.
                grpcCleanupRule.register(InProcessChannelBuilder.forName(serverName).directExecutor().build()));
        }
        if (serverClazz.isAssignableFrom(MockFundamentalsServer.class)) {
            return FundamentalsServiceGrpc.newBlockingStub(
                // Create a client channel and register for automatic graceful shutdown.
                grpcCleanupRule.register(InProcessChannelBuilder.forName(serverName).directExecutor().build()));
        }
        if (serverClazz.isAssignableFrom(MockUserServer.class)) {
            return UserServiceGrpc.newBlockingStub(
                grpcCleanupRule.register(InProcessChannelBuilder.forName(serverName).directExecutor().build()));
        }
        if (serverClazz.isAssignableFrom(MockContactServer.class)) {
            return ContactServiceGrpc.newBlockingStub(
                grpcCleanupRule.register(InProcessChannelBuilder.forName(serverName).directExecutor().build()));
        }
        if (serverClazz.isAssignableFrom(MockCompanyServer.class)) {
            return CompanyServiceGrpc.newBlockingStub(
                grpcCleanupRule.register(InProcessChannelBuilder.forName(serverName).directExecutor().build()));
        }
        if (serverClazz.isAssignableFrom(MockInvestorServer.class)) {
            return InvestorServiceGrpc.newBlockingStub(
                grpcCleanupRule.register(InProcessChannelBuilder.forName(serverName).directExecutor().build()));
        }
        if (serverClazz.isAssignableFrom(MockTransactionServer.class)) {
            return TransactionServiceGrpc.newBlockingStub(
                grpcCleanupRule.register(InProcessChannelBuilder.forName(serverName).directExecutor().build()));
        }
        if (serverClazz.isAssignableFrom(MockShareClassServer.class)) {
            return ShareClassServiceGrpc.newBlockingStub(
                grpcCleanupRule.register(InProcessChannelBuilder.forName(serverName).directExecutor().build()));
        }
        if (serverClazz.isAssignableFrom(MockInstrumentServer.class)) {
            return InstrumentServiceGrpc.newBlockingStub(
                grpcCleanupRule.register(InProcessChannelBuilder.forName(serverName).directExecutor().build()));
        }
        if (serverClazz.isAssignableFrom(MockBankAccountServer.class)) {
            return BankAccountServiceGrpc.newBlockingStub(
                grpcCleanupRule.register(InProcessChannelBuilder.forName(serverName).directExecutor().build()));
        }
        if (serverClazz.isAssignableFrom(MockBankOperationServer.class)) {
            return BankOperationServiceGrpc.newBlockingStub(
                grpcCleanupRule.register(InProcessChannelBuilder.forName(serverName).directExecutor().build()));
        }
        if (serverClazz.isAssignableFrom(MockHistoricalTransactionServer.class)) {
            return HistoricalTransactionServiceGrpc.newBlockingStub(
                grpcCleanupRule.register(InProcessChannelBuilder.forName(serverName).directExecutor().build()));
        }
        throw new RuntimeException("Not able to find mock server / client!");
    }

    private static <T extends Message> void sendAndComplete(StreamObserver<T> responseObserver, Supplier<T> entityFactory) {
        sendAndComplete(responseObserver, entityFactory, 1);
    }

    private static <T extends Message> void sendAndComplete(StreamObserver<T> responseObserver, Supplier<T> entityFactory, int howMany) {
        for (int i = 0; i < howMany; i++) {
            responseObserver.onNext((T) updateEntityWithTimestamp().apply(entityFactory.get()));
        }
        responseObserver.onCompleted();
    }

    @SuppressWarnings("unchecked")
    private static <T extends Message> Function<T, T> updateEntityWithTimestamp() {
        return fa -> {
            if (fa.getClass().isAssignableFrom(Position.class)) {
                Position.Builder builder = Position.newBuilder((Position) fa);
                builder.setAssetId(UUID.randomUUID().toString()).setPortfolioId(UUID.randomUUID().toString());
                builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
                return (T) builder.build();
            } else if (fa.getClass().isAssignableFrom(Asset.class)) {
                Asset.Builder builder = Asset.newBuilder((Asset) fa);
                builder.setAssetId(UUID.randomUUID().toString());
                builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
                return (T) builder.build();
            } else if (fa.getClass().isAssignableFrom(Portfolio.class)) {
                Portfolio.Builder builder = Portfolio.newBuilder((Portfolio) fa);
                builder.setPortfolioId(UUID.randomUUID().toString());
                builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
                return (T) builder.build();
            } else if (fa.getClass().isAssignableFrom(Performance.class)) {
                Performance.Builder builder = Performance.newBuilder((Performance) fa);
                builder.setPerformanceId(UUID.randomUUID().toString());
                builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
                return (T) builder.build();
            } else if (fa.getClass().isAssignableFrom(Fundamentals.class)) {
                Fundamentals.Builder builder = Fundamentals.newBuilder((Fundamentals) fa);
                builder.setCompanyId(UUID.randomUUID().toString());
                builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
                return (T) builder.build();
            } else if (fa.getClass().isAssignableFrom(User.class)) {
                User.Builder builder = User.newBuilder((User) fa);
                builder.setUserId(UUID.randomUUID().toString());
                builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
                return (T) builder.build();
            } else if (fa.getClass().isAssignableFrom(Contact.class)) {
                Contact.Builder builder = Contact.newBuilder((Contact) fa);
                builder.setContactId(UUID.randomUUID().toString());
                builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
                return (T) builder.build();
            } else if (fa.getClass().isAssignableFrom(Company.class)) {
                Company.Builder builder = Company.newBuilder((Company) fa);
                builder.setCompanyId(UUID.randomUUID().toString());
                builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
                return (T) builder.build();
            } else if (fa.getClass().isAssignableFrom(Investor.class)) {
                Investor.Builder builder = Investor.newBuilder((Investor) fa);
                builder.setInvestorId(UUID.randomUUID().toString());
                builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
                return (T) builder.build();
            } else if (fa.getClass().isAssignableFrom(Transaction.class)) {
                Transaction.Builder builder = Transaction.newBuilder((Transaction) fa);
                builder.setGuid(UUID.randomUUID().toString());
                builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
                return (T) builder.build();
            } else if (fa.getClass().isAssignableFrom(ShareClass.class)) {
                ShareClass.Builder builder = ShareClass.newBuilder((ShareClass) fa);
                builder.setShareclassId(UUID.randomUUID().toString());
                builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
                return (T) builder.build();
            } else if (fa.getClass().isAssignableFrom(Instrument.class)) {
                Instrument.Builder builder = Instrument.newBuilder((Instrument) fa);
                builder.setAssetId(UUID.randomUUID().toString());
                builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
                return (T) builder.build();
            } else if (fa.getClass().isAssignableFrom(BankAccount.class)) {
                BankAccount.Builder builder = BankAccount.newBuilder((BankAccount) fa);
                builder.setBankAccountId(UUID.randomUUID().toString());
                builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
                return (T) builder.build();
            } else if (fa.getClass().isAssignableFrom(BankOperation.class)) {
                BankOperation.Builder builder = BankOperation.newBuilder((BankOperation) fa);
                builder.setBankOperationId(UUID.randomUUID().toString());
                builder.getEntityInfoBuilder().setNetworkMode(AppConstants.NETWORK_MODE).setOriginTimestamp(Timestamps.fromMillis(System.currentTimeMillis() - 1000));
                return (T) builder.build();
            } else return null;
        };
    }

    public static class SupplierImpl<T extends Message> implements Supplier<T> {

        private final List<T> list;
        private final Iterator<T> iterator;

        SupplierImpl(List<T> messages) {
            this.list = messages;
            this.iterator = this.list.iterator();
        }

        @Override
        public T get() {
            return this.iterator.next();
        }
    }

    public static class MockAssetServer extends AssetServiceGrpc.AssetServiceImplBase {

        @Override
        public void getAssetsSince(AssetsSinceRequest request, StreamObserver<Asset> responseObserver) {
            sendAndComplete(responseObserver, new SupplierImpl<>(Arrays.asList(Asset.getDefaultInstance(), Asset.getDefaultInstance())), 2);
        }

        @Override
        public void getAsset(AssetRequest request, StreamObserver<Asset> responseObserver) {
            sendAndComplete(responseObserver, new SupplierImpl<>(Collections.singletonList(Asset.getDefaultInstance())));
        }
    }

    public static class MockPerformanceServer extends PerformanceServiceGrpc.PerformanceServiceImplBase {

        @Override
        public void getPerformanceSince(PerformanceSinceRequest request, StreamObserver<Performance> responseObserver) {
            sendAndComplete(responseObserver, new SupplierImpl<>(Arrays.asList(Performance.getDefaultInstance(), Performance.getDefaultInstance())), 2);
        }

        @Override
        public void getPerformance(PerformanceRequest request, StreamObserver<Performance> responseObserver) {
            sendAndComplete(responseObserver, new SupplierImpl<>(Collections.singletonList(Performance.getDefaultInstance())));
        }
    }

    public static class MockPortfolioServer extends PortfolioServiceGrpc.PortfolioServiceImplBase {
        @Override
        public void getPortfoliosSince(PortfoliosSinceRequest request, StreamObserver<Portfolio> responseObserver) {
            sendAndComplete(responseObserver, new SupplierImpl<>(Arrays.asList(Portfolio.getDefaultInstance(), Portfolio.getDefaultInstance())), 2);
        }

        @Override
        public void getPortfolio(PortfolioRequest request, StreamObserver<Portfolio> responseObserver) {
            sendAndComplete(responseObserver, new SupplierImpl<>(Collections.singletonList(Portfolio.getDefaultInstance())));
        }
    }

    public static class MockShareClassServer extends ShareClassServiceGrpc.ShareClassServiceImplBase {
        @Override
        public void getShareClassSince(ShareClassSinceRequest request, StreamObserver<ShareClass> responseObserver) {
            sendAndComplete(responseObserver, new SupplierImpl<>(Arrays.asList(ShareClass.getDefaultInstance(), ShareClass.getDefaultInstance())), 2);
        }

        @Override
        public void getShareClass(ShareClassRequest request, StreamObserver<ShareClass> responseObserver) {
            sendAndComplete(responseObserver, new SupplierImpl<>(Collections.singletonList(ShareClass.getDefaultInstance())));
        }
    }

    public static class MockPositionServer extends PositionServiceGrpc.PositionServiceImplBase {
        @Override
        public void getPositionsSince(PositionsSinceRequest request, StreamObserver<Position> responseObserver) {
            sendAndComplete(responseObserver, new SupplierImpl<>(Arrays.asList(Position.getDefaultInstance(), Position.getDefaultInstance())), 2);
        }

        @Override
        public void getPosition(PositionRequest request, StreamObserver<Position> responseObserver) {
            sendAndComplete(responseObserver, new SupplierImpl<>(Collections.singletonList(Position.getDefaultInstance())));
        }
    }

    public static class MockFundamentalsServer extends FundamentalsServiceGrpc.FundamentalsServiceImplBase {

        @Override
        public void getFundamentalsSince(FundamentalsSinceRequest request, StreamObserver<Fundamentals> responseObserver) {
            sendAndComplete(responseObserver, new SupplierImpl<>(Arrays.asList(Fundamentals.getDefaultInstance(), Fundamentals.getDefaultInstance())), 2);
        }

        @Override
        public void getFundamentals(FundamentalsRequest request, StreamObserver<Fundamentals> responseObserver) {
            sendAndComplete(responseObserver, new SupplierImpl<>(Collections.singletonList(Fundamentals.getDefaultInstance())));
        }
    }

    public static class MockUserServer extends UserServiceGrpc.UserServiceImplBase {

        @Override
        public void getUserSince(UserSinceRequest request, StreamObserver<User> responseObserver) {
            sendAndComplete(responseObserver, new SupplierImpl<>(Arrays.asList(User.getDefaultInstance(), User.getDefaultInstance())), 2);
        }
    }

    public static class MockContactServer extends ContactServiceGrpc.ContactServiceImplBase {

        @Override
        public void getContactSince(ContactRequest request, StreamObserver<Contact> responseObserver) {
            sendAndComplete(responseObserver, new SupplierImpl<>(Arrays.asList(Contact.getDefaultInstance(), Contact.getDefaultInstance())), 2);
        }

    }

    public static class MockCompanyServer extends CompanyServiceGrpc.CompanyServiceImplBase {

        @Override
        public void getCompanySince(CompanyRequest request, StreamObserver<Company> responseObserver) {
            sendAndComplete(responseObserver, new SupplierImpl<>(Arrays.asList(Company.getDefaultInstance(), Company.getDefaultInstance())), 2);
        }
    }

    public static class MockInvestorServer extends InvestorServiceGrpc.InvestorServiceImplBase {

        @Override
        public void getInvestorSince(InvestorRequest request, StreamObserver<Investor> responseObserver) {
            sendAndComplete(responseObserver, new SupplierImpl<>(Arrays.asList(Investor.getDefaultInstance(), Investor.getDefaultInstance())), 2);
        }
    }

    public static class MockTransactionServer extends TransactionServiceGrpc.TransactionServiceImplBase {

        @Override
        public void getTransactionsSince(TransactionsSinceRequest request, StreamObserver<Transaction> responseObserver) {
            sendAndComplete(responseObserver, new SupplierImpl<>(Arrays.asList(Transaction.getDefaultInstance(), Transaction.getDefaultInstance())), 2);
        }

        @Override
        public void getTransaction(TransactionRequest request, StreamObserver<Transaction> responseObserver) {
            sendAndComplete(responseObserver, new SupplierImpl<>(Collections.singletonList(Transaction.getDefaultInstance())));
        }
    }
    
    public static class MockInstrumentServer extends InstrumentServiceGrpc.InstrumentServiceImplBase {
    	  @Override
          public void getInstrumentsSince(InstrumentsSinceRequest request, StreamObserver<Instrument> responseObserver) {
              sendAndComplete(responseObserver, new SupplierImpl<>(Arrays.asList(Instrument.getDefaultInstance(), Instrument.getDefaultInstance())), 2);
          }

          @Override
          public void getInstrument(InstrumentRequest request, StreamObserver<Instrument> responseObserver) {
              sendAndComplete(responseObserver, new SupplierImpl<>(Collections.singletonList(Instrument.getDefaultInstance())));
          }
      
    }

    public static class MockBankAccountServer extends BankAccountServiceGrpc.BankAccountServiceImplBase {
    	  @Override
          public void getBankAccountsSince(BankAccountsSinceRequest request, StreamObserver<BankAccount> responseObserver) {
              sendAndComplete(responseObserver, new SupplierImpl<>(Arrays.asList(BankAccount.getDefaultInstance(), BankAccount.getDefaultInstance())), 2);
          }

          @Override
          public void getBankAccount(BankAccountRequest request, StreamObserver<BankAccount> responseObserver) {
              sendAndComplete(responseObserver, new SupplierImpl<>(Collections.singletonList(BankAccount.getDefaultInstance())));
          }

    }

    public static class MockBankOperationServer extends BankOperationServiceGrpc.BankOperationServiceImplBase {
    	  @Override
          public void getBankOperationsSince(BankOperationsSinceRequest request, StreamObserver<BankOperation> responseObserver) {
              sendAndComplete(responseObserver, new SupplierImpl<>(Arrays.asList(BankOperation.getDefaultInstance(), BankOperation.getDefaultInstance())), 2);
          }

          @Override
          public void getBankOperation(BankOperationRequest request, StreamObserver<BankOperation> responseObserver) {
              sendAndComplete(responseObserver, new SupplierImpl<>(Collections.singletonList(BankOperation.getDefaultInstance())));
          }

    }

    public static class MockHistoricalTransactionServer extends HistoricalTransactionServiceGrpc.HistoricalTransactionServiceImplBase {
    	  @Override
          public void getHistoricalTransactionsSince(HistoricalTransactionsSinceRequest request, StreamObserver<Transaction> responseObserver) {
              sendAndComplete(responseObserver, new SupplierImpl<>(Arrays.asList(Transaction.getDefaultInstance(), Transaction.getDefaultInstance())), 2);
          }

          @Override
          public void getHistoricalTransaction(HistoricalTransactionRequest request, StreamObserver<Transaction> responseObserver) {
              sendAndComplete(responseObserver, new SupplierImpl<>(Collections.singletonList(Transaction.getDefaultInstance())));
          }

    }
}
