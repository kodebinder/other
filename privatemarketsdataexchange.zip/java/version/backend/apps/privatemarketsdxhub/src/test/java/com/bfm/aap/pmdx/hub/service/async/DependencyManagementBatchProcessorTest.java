package com.bfm.aap.pmdx.hub.service.async;

import com.bfm.aap.pmdx.hub.model.ExecutionStatus;
import com.bfm.aap.pmdx.hub.model.async.TaskResult;
import com.bfm.aap.pmdx.hub.repository.ClientInfoDAO;
import com.bfm.aap.pmdx.hub.service.entity.EfrontPingClient;
import com.bfm.aap.pmdx.hub.util.HubServiceUtil;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.ClientStatus;
import com.bfm.util.ProtocolSupport;
import com.google.common.collect.Sets;
import io.grpc.ManagedChannel;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore({"javax.crypto.*"})
public class DependencyManagementBatchProcessorTest {

    @Mock
    static ProtocolSupport protocolSupport;
    @Mock
    BatchTask batchTask;
    @Mock
    ManagedChannel channel;
    @Mock
    EfrontPingClient efrontPingClient;
    @Mock
    LockHelper lockHelper;
    @Mock
    HubServiceUtil hubServiceUtil;
    @Mock
    ClientInfoDAO clientInfoDAO;


    ZookeeperHelper zookeeperHelper;
    BatchProcessor batchProcessor;

    @BeforeClass
    public static void setUpBeforeClass() {
        System.setProperty("mode", "BLUE");
    }

    @Before
    public void init() {
        initMocks(this);

        zookeeperHelper = new ZookeeperHelper(protocolSupport, lockHelper, hubServiceUtil, clientInfoDAO);
        batchProcessor = new BatchProcessor(batchTask, efrontPingClient);

        Whitebox.setInternalState(batchProcessor, "concurrentBatchCount", 5);
        Whitebox.setInternalState(batchProcessor, "currentRunningTasks", new AtomicInteger(1));
        Whitebox.setInternalState(batchProcessor, "heartBeatIntervalMillis", 2000);
    }

    private void prepareMocks() {
        List<String> clients = getClients();
        batchProcessor.getAllClients().addAll(clients);
        batchProcessor.getProcessedClients().put(clients.get(0), ExecutionStatus.IN_PROGRESS);
        batchProcessor.getProcessedClients().put(clients.get(1), ExecutionStatus.COMPLETED);
        Whitebox.setInternalState(batchProcessor, "batchExecutor", Executors.newFixedThreadPool(5));
        Whitebox.setInternalState(batchProcessor, "pingExecutor", Executors.newSingleThreadScheduledExecutor());
    }

    private List<String> getClients() {
        return Arrays.asList("Blackrock", "efront", "aladdin-r", "dummy-r", "akash-r", "test1");
    }

    private List<ClientInfo> getRunnableClient(List<String> clientNames) {
        List<ClientInfo> clientInfoList = new ArrayList<>();
        for (String clientName : clientNames) {
            ClientInfo info = zookeeperHelper.buildClientInfo(clientName, ClientStatus.COMPLETED);
            clientInfoList.add(info);
        }
        return clientInfoList;
    }

    private List<ClientInfo> getRunnableClientNoEntityBuilder(List<String> clientNames) {
        List<ClientInfo> clientInfoList = new ArrayList<>();
        for (String clientName : clientNames) {
            ClientInfo info = zookeeperHelper.buildClientInfo(clientName, ClientStatus.COMPLETED);
            ClientInfo.Builder testBuilder = info.toBuilder();
            info = testBuilder.clearEntityService().build();
            clientInfoList.add(info);
        }
        return clientInfoList;
    }

    @Ignore
    @Test
    public void submitTasks() {
        //Arrange
        prepareMocks();

        //Act
        batchProcessor.submitTasks(getRunnableClient(getClients()));

        //Verify
        verify(batchTask, Mockito.atLeastOnce()).submitTask(anyString(), anyLong(), any(AtomicInteger.class), anyMap(), any());

    }

    @Test
    public void getProcessedClientsByStatus() {
        //Arrange
        when(efrontPingClient.fetchEntitiesSince(anyLong(), any(ClientInfo.class), any())).thenReturn(new TaskResult<>(Sets.newHashSet("Hello"), 5000));

        // Act
        batchProcessor.init();

        //Verify
        verify(efrontPingClient, never()).fetchEntitiesSince(anyLong(), any(ClientInfo.class), any());
    }

    @Test
    public void submitTasks_entityServiceDataMissing() {
        //Arrange
        prepareMocks();

        //Act
        batchProcessor.submitTasks(getRunnableClientNoEntityBuilder(getClients()));

        //Verify
        verify(batchTask, never()).submitTask(anyString(), anyLong(), any(AtomicInteger.class), anyMap(), any());
    }

    @After
    public void tearDownAfterClass() throws Exception {
        protocolSupport.close();
    }
}
