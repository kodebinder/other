package com.bfm.aap.pmdx.hub.service.entity;

import static junit.framework.TestCase.assertNotNull;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.powermock.api.mockito.PowerMockito.doThrow;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

import java.io.IOException;
import java.util.Collections;
import java.util.Iterator;

import com.bfm.aap.pmdx.services.HistoricalTransactionRequest;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.hub.TestUtils;
import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.hub.util.AppConstants;
import com.bfm.aap.pmdx.model.Transaction;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.LibRedBlueProxy;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.notification.service.EmailNotification;
import com.bfm.adl.ADLException;
import com.bfm.metric.StatCollectorMeterRegistry;
import com.bfm.service.ServiceException;

import io.grpc.ManagedChannel;
import io.grpc.stub.AbstractStub;
import io.grpc.testing.GrpcCleanupRule;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore("javax.net.ssl.*")
@PrepareForTest({ManagedChannel.class, LibRedBlueProxy.class, StatCollectorMeterRegistry.class, AltsDataWorkspaceDAO.class, EmailNotification.class})

public class HistoricalTransactionsServiceClientTest extends BaseUnitTest  {

    private ManagedChannel mockChannel;
    private AltsDataWorkspaceDAO mockDAO;
    private HistoricalTransactionsServiceClient historicalTransactionsServiceClient;
    private AbstractStub serviceStub;
    private EntityProcessor<Transaction> historicalTransactionProcessorMock;

    private StatCollectorMeterRegistry registry;

    @Rule
    public final GrpcCleanupRule grpcCleanup = new GrpcCleanupRule();
    private ClientInfo client;

    @Before
    public void init() throws Exception {
        client = buildTestClientInfoWithAllEntityType("dummy", "Dummy");
        MockitoAnnotations.initMocks(this);
        mockChannel = mock(ManagedChannel.class);
        mockDAO = mock(AltsDataWorkspaceDAO.class);
        mockStatic(EmailNotification.class);
        mockStatic(LibRedBlueProxy.class);
        mockStatic(StatCollectorMeterRegistry.class);
        registry = PowerMockito.mock(StatCollectorMeterRegistry.class);
        when(StatCollectorMeterRegistry.getInstance()).thenReturn(registry);
        historicalTransactionProcessorMock = mock(EntityProcessor.class);
        historicalTransactionsServiceClient = new HistoricalTransactionsServiceClient(mockChannel, mockDAO, historicalTransactionProcessorMock);
        historicalTransactionsServiceClient.registry = registry;
        serviceStub = TestUtils.initServerAndBlockingClient(grpcCleanup, TestUtils.MockHistoricalTransactionServer.class);
        Whitebox.setInternalState(historicalTransactionsServiceClient,"serviceStub", serviceStub);
        Whitebox.setInternalState(historicalTransactionsServiceClient,"unaryCallTimeoutMillis", 1500);
        when(historicalTransactionProcessorMock.processEntity(any(Transaction.class))).thenAnswer(new Answer<Transaction>() {
            @Override
            public Transaction answer(InvocationOnMock invocation) throws Throwable {
                Object[] args = invocation.getArguments();
                return (Transaction) args[0];
            }
        });
        when(historicalTransactionProcessorMock.getEntityEpochOriginTime(any(Transaction.class))).thenReturn(System.currentTimeMillis()+100);
        when(LibRedBlueProxy.getNetworkPredicatesByColor(NetworkMode.RED)).thenReturn(Collections.EMPTY_LIST);
    }


    @Test
    public void initiateSingleBlockingRequest() throws IOException, ADLException {
        //Arrange
        long time = System.currentTimeMillis();
        //Act
        Iterator<Transaction> iterator = historicalTransactionsServiceClient.initiateSingleBlockingRequest(time, client, null);
        //Verify
        assertNotNull(iterator);
        assertNotNull(iterator.hasNext());
    }

    @Test
    public void getEntity() {
        //Arrange
        HistoricalTransactionRequest transactionRequest = HistoricalTransactionRequest.newBuilder().setGuid("HISTO_TXN").build();
        //Act
        Transaction resp = historicalTransactionsServiceClient.getEntity(transactionRequest);
        //Verify
        assertEquals(AppConstants.NETWORK_MODE, resp.getEntityInfo().getNetworkMode());
    }

    @Test
    public void getEntityFailure() throws IOException {
        //Arrange
        HistoricalTransactionRequest transactionRequest = HistoricalTransactionRequest.newBuilder().setGuid("HISTO_TXN").build();
        doThrow(new RuntimeException("ADL Failure")).when(mockDAO).insertRecords(anyList());
        //Act
        try {
            historicalTransactionsServiceClient.getEntity(transactionRequest);
        } catch (ServiceException e) {
            assertEquals("Failed to get historical Transaction:ADL Failure", e.getMessage());
        }
    }
}
