package com.bfm.aap.pmdx.hub.service.entity;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.metric.StatCollectorMeterRegistry;
import com.bfm.util.Pair;
import com.google.protobuf.Empty;
import eFrontProtobuf.PingServiceGrpc;
import eFrontProtobuf.PingServiceOuterClass;
import io.grpc.ManagedChannel;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.Arrays;
import java.util.Iterator;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore("javax.net.ssl.*")
@PrepareForTest({PingServiceGrpc.PingServiceBlockingStub.class, StatCollectorMeterRegistry.class})
public class EfrontPingClientTest extends BaseUnitTest {

    @Mock
    private ManagedChannel mockChannel;
    @Mock
    private StatCollectorMeterRegistry registry;
    private PingServiceGrpc.PingServiceBlockingStub pingStub;
    private EfrontPingClient pingClient;
    private ClientInfo client;

    @Before
    public void init() {
        client = buildTestClientInfoWithAllEntityType("dummy", "Dummy");
        MockitoAnnotations.initMocks(this);
        mockStatic(StatCollectorMeterRegistry.class);
        when(StatCollectorMeterRegistry.getInstance()).thenReturn(registry);
        pingStub = PowerMockito.mock(PingServiceGrpc.PingServiceBlockingStub.class);
        pingClient = new EfrontPingClient(mockChannel);
        pingClient.registry = registry;
        pingClient.serviceStub = pingStub;
        Iterator<PingServiceOuterClass.PingReply> iteratorList = Arrays.asList(PingServiceOuterClass.PingReply.newBuilder().setMessage("PING").build()).iterator();
        when(pingStub.pingAsStream(any(Empty.class))).thenReturn(iteratorList);
    }

    @Test
    public void initiateSingleBlockingRequest() {
        //Arrange
        //Act
        Iterator<PingServiceOuterClass.PingReply> iterator = pingClient.initiateSingleBlockingRequest(0, client, InvestUtils.DataSource.UNRECOGNIZED);

        //Verify
        assertNotNull(iterator);
        assertTrue(iterator.hasNext());
    }

    @Test
    public void processMessages() {
        //Arrange
        //Act
        Iterator<PingServiceOuterClass.PingReply> iterator = pingClient.initiateSingleBlockingRequest(0, client, null);
        Pair<Set<String>, Long> pair = pingClient.processMessages(iterator, 0, "demo");

        //Verify
        assertThat(pair).isNotNull();
        assertThat(pair.getFirstValue()).isNotEmpty().containsExactly("PING");
        assertThat(pair.getSecondValue()).isEqualTo(0);
    }
}