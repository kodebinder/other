package com.bfm.aap.pmdx.hub.service.entity;

import io.grpc.ManagedChannel;
import io.grpc.stub.AbstractStub;
import io.grpc.testing.GrpcCleanupRule;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.ContactResponse;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.aap.pmdx.services.ContactRequest;
import com.bfm.aap.pmdx.services.ContactServiceGrpc;
import com.bfm.service.ServiceException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.doThrow;


@RunWith(PowerMockRunner.class)
@PrepareForTest(ContactServiceGrpc.ContactServiceBlockingStub.class)
public class ContactServiceClientTest extends BaseUnitTest {

    private ContactServiceClient contactServiceClient;

    @Mock
    private RPCServiceClient rpcServiceClient;

    @Mock
    private EntityProcessor<Contact> entityProcessor;

    @Mock
    private ManagedChannel channel;

    private ContactServiceGrpc.ContactServiceBlockingStub contactServiceBlockingStub;
    private ClientInfo clientInfo;

    @Rule
    public final GrpcCleanupRule grpcCleanup = new GrpcCleanupRule();

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        contactServiceBlockingStub = PowerMockito.mock(ContactServiceGrpc.ContactServiceBlockingStub.class);
        this.contactServiceClient = new ContactServiceClient(rpcServiceClient, channel, entityProcessor);

    }

    @Test
    public void fetchEntitiesSinceTest() {
        //Act
        this.contactServiceClient.fetchEntitiesSince(System.currentTimeMillis(), buildTestClientInfoWithAllEntityType("Dummy", "dummy"), InvestUtils.DataSource.FIA);

        //Verify
        verify(rpcServiceClient).doFetchSince(any(), any(), any(), any(), any(ClientInfo.class), anyLong());
    }

    @Test
    public void updateContactTest() {
        clientInfo = buildTestClientInfoWithAllEntityType("Dummy", "dummy");
        when(rpcServiceClient.getStubWithInterceptor(any(AbstractStub.class), any(ClientInfo.class))).thenReturn(contactServiceBlockingStub);
        ContactResponse response = ContactResponse.newBuilder().setIsUpdated(true).setData(Contact.getDefaultInstance()).build();
        when(contactServiceBlockingStub.updateContact(any(ContactRequest.class))).thenReturn(response);
        contactServiceClient.updateContact(ContactRequest.newBuilder().setContact(Contact.newBuilder().setContactId("123").build()).build(), clientInfo, 1234);
        verify(contactServiceBlockingStub).updateContact(any(ContactRequest.class));
        assertThat(response.getData().getCompanyId()).isEmpty();
    }

    @Test
    public void updateContactTest_with_false_response() {
        clientInfo = buildTestClientInfoWithAllEntityType("Dummy", "dummy");
        when(rpcServiceClient.getStubWithInterceptor(any(AbstractStub.class), any(ClientInfo.class))).thenReturn(contactServiceBlockingStub);
        ContactResponse response = ContactResponse.newBuilder().setIsUpdated(false).setData(Contact.getDefaultInstance()).build();
        when(contactServiceBlockingStub.updateContact(any(ContactRequest.class))).thenReturn(response);
        contactServiceClient.updateContact(ContactRequest.newBuilder().setContact(Contact.newBuilder().setContactId("123").build()).build(), clientInfo, 1234);
        verify(contactServiceBlockingStub).updateContact(any(ContactRequest.class));
        assertThat(response.getData().getCompanyId()).isEmpty();
    }

    @Test
    public void updateContactTest_Failure() {
        clientInfo = buildTestClientInfoWithAllEntityType("Dummy", "dummy");
        when(rpcServiceClient.getStubWithInterceptor(any(AbstractStub.class), any(ClientInfo.class))).thenReturn(contactServiceBlockingStub);

        doThrow(new RuntimeException("grpc failure")).when(contactServiceBlockingStub).updateContact(any(ContactRequest.class));
        try {
            contactServiceClient.updateContact(ContactRequest.getDefaultInstance(), clientInfo, 1234);
        } catch (ServiceException ex) {
            assertTrue(ex.getMessage().contains("grpc failure"));
        }
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testGetEntity() {
        contactServiceClient.getEntity(null);
    }

}