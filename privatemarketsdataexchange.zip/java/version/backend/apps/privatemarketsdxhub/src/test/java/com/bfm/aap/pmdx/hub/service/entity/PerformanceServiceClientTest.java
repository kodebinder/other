package com.bfm.aap.pmdx.hub.service.entity;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.hub.TestUtils;
import com.bfm.aap.pmdx.hub.model.ExecutionStatus;
import com.bfm.aap.pmdx.hub.model.async.TaskResult;
import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.hub.util.AppConstants;
import com.bfm.aap.pmdx.model.Performance;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.LibRedBlueProxy;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.notification.service.EmailNotification;
import com.bfm.aap.pmdx.services.PerformanceRequest;
import com.bfm.aap.pmdx.services.PerformanceServiceGrpc;
import com.bfm.aap.pmdx.services.PerformanceSinceRequest;
import com.bfm.adl.ADLException;
import com.bfm.metric.StatCollectorMeterRegistry;
import com.bfm.service.ServiceException;
import io.grpc.ClientInterceptor;
import io.grpc.ManagedChannel;
import io.grpc.Status;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.AbstractStub;
import io.grpc.testing.GrpcCleanupRule;
import io.micrometer.core.instrument.Timer;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import java.io.IOException;
import java.util.Collections;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.powermock.api.mockito.PowerMockito.doThrow;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore("javax.net.ssl.*")
@PrepareForTest({AppConstants.class, LibRedBlueProxy.class, StatCollectorMeterRegistry.class, PerformanceServiceGrpc.PerformanceServiceBlockingStub.class, ManagedChannel.class, AltsDataWorkspaceDAO.class, EmailNotification.class})
public class PerformanceServiceClientTest extends BaseUnitTest {

    private ManagedChannel mockChannel;
    private AltsDataWorkspaceDAO mockDAO;
    private EntityProcessor<Performance> performanceProcessorMock;
    private PerformanceServiceClient performanceServiceClient;
    private AbstractStub serviceStub;
    private ClientInfo client;

    private StatCollectorMeterRegistry registry;

    @Mock
    private Timer timer;

    private PerformanceServiceGrpc.PerformanceServiceBlockingStub serviceStubMock;

    @Rule
    public final GrpcCleanupRule grpcCleanup = new GrpcCleanupRule();

    @Before
    public void init() throws Exception {
        client = buildTestClientInfoWithAllEntityType("Dummy", "dummy");
        MockitoAnnotations.initMocks(this);
        mockStatic(AppConstants.class);
        mockStatic(EmailNotification.class);
        mockStatic(LibRedBlueProxy.class);
        mockStatic(StatCollectorMeterRegistry.class);
        registry = PowerMockito.mock(StatCollectorMeterRegistry.class);
        when(StatCollectorMeterRegistry.getInstance()).thenReturn(registry);
        serviceStubMock = PowerMockito.mock(PerformanceServiceGrpc.PerformanceServiceBlockingStub.class);
        mockChannel = mock(ManagedChannel.class);
        mockDAO = mock(AltsDataWorkspaceDAO.class);
        performanceProcessorMock = mock(EntityProcessor.class);
        performanceServiceClient = new PerformanceServiceClient(mockChannel, mockDAO, performanceProcessorMock);
        performanceServiceClient.registry = registry;
        serviceStub = TestUtils.initServerAndBlockingClient(grpcCleanup, TestUtils.MockPerformanceServer.class);
        Whitebox.setInternalState(performanceServiceClient,"serviceStub", serviceStub);
        Whitebox.setInternalState(performanceServiceClient,"unaryCallTimeoutMillis", 1500);
        setMocks();
    }

    private void setMocks() throws Exception {
        when(performanceProcessorMock.processEntity(any(Performance.class))).thenAnswer(new Answer<Performance>() {
            @Override
            public Performance answer(InvocationOnMock invocation) throws Throwable {
                Object[] args = invocation.getArguments();
                return (Performance) args[0];
            }
        });
        when(mockDAO.insertRecord(any(Performance.class))).thenAnswer(new Answer<String>() {
            @Override
            public String answer(InvocationOnMock invocation) throws Throwable {
                Object[] args = invocation.getArguments();
                return ((Performance) args[0]).getPerformanceId();
            }
        });
        when(registry.timer(anyString(), Matchers.<String>anyVararg())).thenReturn(timer);
        when(performanceProcessorMock.getEntityEpochOriginTime(any(Performance.class))).thenReturn(System.currentTimeMillis() + 2000);
        when(LibRedBlueProxy.getNetworkPredicatesByColor(NetworkMode.RED)).thenReturn(Collections.EMPTY_LIST);
    }

    @Test
    public void fetchEntities() {
        //Arrange
        //Act
        TaskResult<Set<String>> result = performanceServiceClient.fetchEntitiesSince(1605245939959L, client, null);

        //Verify
        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo(ExecutionStatus.COMPLETED);
        assertThat(result.getResult()).isNotEmpty().size().isEqualTo(2);
        assertThat(result.getLastEntityTime()).isGreaterThan(1605245939959L);
    }

    @Test
    public void fetchEntities_GRPCFailure() {
        //Arrange
        performanceServiceClient.serviceStub = serviceStubMock;
        when(serviceStubMock.withInterceptors(Matchers.<ClientInterceptor>anyVararg())).thenReturn(serviceStubMock);
        doThrow(new StatusRuntimeException(Status.CANCELLED)).when(serviceStubMock).getPerformanceSince(any(PerformanceSinceRequest.class));
        //Act
        TaskResult<Set<String>> result = performanceServiceClient.fetchEntitiesSince(System.currentTimeMillis(), client, null);

        //Verify
        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo(ExecutionStatus.EXCEPTION);
        assertThat(result.getResult()).isEmpty();
        assertThat(result.getFailureMessage()).contains("GRPC request failed with status");
    }

    @Test
    public void fetchEntities_ADLFailure() throws ADLException {
        //Arrange
        doThrow(new RuntimeException("ADL failure")).when(mockDAO).insertRecord(any(Performance.class));
        //Act
        TaskResult<Set<String>> result = performanceServiceClient.fetchEntitiesSince(System.currentTimeMillis(), client, null);

        //Verify
        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo(ExecutionStatus.COMPLETED);
        assertThat(result.getResult()).isEmpty();
    }

    @Test
    public void getEntity() {
        //Arrange
        PerformanceRequest performanceRequest = PerformanceRequest.newBuilder().setGuid("ABCD").build();
        //Act
        Performance resp = performanceServiceClient.getEntity(performanceRequest);
        //Verify
        assertEquals(AppConstants.NETWORK_MODE, resp.getEntityInfo().getNetworkMode());
    }

    @Test
    public void getEntityFailure() throws IOException {
        //Arrange
        PerformanceRequest performanceRequest = PerformanceRequest.newBuilder().setGuid("ABCD").build();
        doThrow(new RuntimeException("ADL Failure")).when(mockDAO).insertRecords(anyList());
        //Act
        try {
            performanceServiceClient.getEntity(performanceRequest);
        } catch (ServiceException e) {
            assertEquals("Failed to get Performance:ADL Failure", e.getMessage());
        }
    }
}