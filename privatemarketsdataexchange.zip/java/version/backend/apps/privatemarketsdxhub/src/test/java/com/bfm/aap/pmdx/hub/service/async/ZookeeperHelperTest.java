package com.bfm.aap.pmdx.hub.service.async;

import com.google.common.collect.Maps;
import com.google.protobuf.Timestamp;
import com.google.protobuf.util.Timestamps;
import org.apache.curator.test.TestingServer;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.ZooKeeper;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.reflect.Whitebox;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static com.bfm.aap.pmdx.hub.util.AppConstants.ZKPATH_PARENT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mock;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.hub.repository.ClientInfoDAO;
import com.bfm.aap.pmdx.hub.util.AppConstants;
import com.bfm.aap.pmdx.hub.util.ClientGuidEnum;
import com.bfm.aap.pmdx.hub.util.HubServiceUtil;
import com.bfm.aap.pmdx.hub.util.ServiceEnum;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.ClientStatus;
import com.bfm.aap.pmdx.model.util.EntityService;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.ServerContext;
import com.bfm.aap.pmdx.proto.util.ProtoJsonHelper;
import com.bfm.beam.ShutdownApplication;
import com.bfm.coordination.tasks.ShutdownApplicationTask;
import com.bfm.util.ProtocolSupport;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@PowerMockIgnore({"javax.crypto.*"})
public class ZookeeperHelperTest extends BaseUnitTest {

    private static final int SESSION_TIMEOUT_DEFAULT = 60000;
    private static final Integer CUT_OFF_TIME = 300000 * 3;

    public static TestingServer zkServer;
    public static ProtocolSupport protocolSupport;
    private ZookeeperHelper zookeeperHelper;
    private LockHelper lockHelper;
    protected static ZooKeeper zooKeeper;
    private HubServiceUtil utilService;
    private ClientInfoDAO clientInfoDAO;
    private Map<String, List<ClientInfo>> serviceToClientInfo = new HashMap<>();

    @BeforeClass
    public static void setupOnce() throws Exception {
        zkServer = new TestingServer();
        //Create ProtocolSupport
        Constructor<ProtocolSupport> constructor = ProtocolSupport.class.getDeclaredConstructor(
                new Class[]{
                        String.class, String.class, Integer.TYPE, Boolean.TYPE, Boolean.TYPE, ShutdownApplicationTask.class
                }
        );
        //This constructor is protected, but it really should be public:
        constructor.setAccessible(true);
        protocolSupport = constructor.newInstance(null, // cluster ID to be ignored
                zkServer.getConnectString(), // Zookeeper connection string
                SESSION_TIMEOUT_DEFAULT,
                true, // auto-connect
                false, // halt on stale session
                new ShutdownApplicationTask(3000, new ShutdownApplication()));
        if (!protocolSupport.isConnected()) protocolSupport.awaitConnection();
    }

    @Before
    public void init() {
        lockHelper = mock(LockHelper.class);
        utilService = mock(HubServiceUtil.class);
        clientInfoDAO = mock(ClientInfoDAO.class);
        zookeeperHelper = new ZookeeperHelper(protocolSupport, lockHelper, utilService, clientInfoDAO);
        zooKeeper = protocolSupport.getZookeeper();
        Whitebox.setInternalState(zookeeperHelper, "protocolSupport", protocolSupport);
        Whitebox.setInternalState(zookeeperHelper, "cutOffTime", 60);

        ClientInfo client = ClientInfo.newBuilder().setClientName("ALADDIN.DEV").build();
        serviceToClientInfo.putIfAbsent("CRM", Collections.singletonList(client));
    }

    @Test
    public void checkIsZKConnected() throws InterruptedException {
        assertThat(zookeeperHelper.zkIsConnected()).isTrue();

        protocolSupport.close();
        assertThat(zookeeperHelper.zkIsConnected()).isTrue();
    }

    @Test
    public void createParentNode_Success() {
        try {
            zookeeperHelper.createZKPath(AppConstants.ZKPATH_PARENT, ServerContext.getDefaultInstance().toByteArray());
            zookeeperHelper.createZKPath(zookeeperHelper.getClientPath("AladdinDemo", ServiceEnum.INVESTMENTS), ClientInfo.getDefaultInstance().toByteArray());
            assertThat(zookeeperHelper.getNodeData(AppConstants.ZKPATH_PARENT)).isNotNull();
            assertThat(zookeeperHelper.getNodeData(AppConstants.ZKPATH_PARENT)).isEqualTo(ServerContext.getDefaultInstance().toByteArray());
            assertThat(zookeeperHelper.getNodeData(zookeeperHelper.getClientPath("AladdinDemo", ServiceEnum.INVESTMENTS))).isNotNull();
            assertThat(zookeeperHelper.getNodeData(zookeeperHelper.getClientPath("AladdinDemo", ServiceEnum.INVESTMENTS))).isEqualTo(ClientInfo.getDefaultInstance().toByteArray());

        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void createParentNode_ZKClient() {
        try {
            ClientInfo clientInfo = zookeeperHelper.buildClientInfo("TestClient1", ClientStatus.INITIATED);
            zookeeperHelper.createZKPath(zookeeperHelper.getClientPath("TestClient1", ServiceEnum.INVESTMENTS), ProtoJsonHelper.convertToJson(clientInfo).getBytes());
            assertThat(zookeeperHelper.getNodeData(zookeeperHelper.getClientPath("TestClient1", ServiceEnum.INVESTMENTS))).isNotNull();
            assertThat(zookeeperHelper.getBuilderFromJson(zookeeperHelper.getClientPath("TestClient1", ServiceEnum.INVESTMENTS)).build()).isEqualTo(clientInfo);

        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void createParentNode_ZKClientUpdate() {
        try {
            ClientInfo clientInfo = zookeeperHelper.buildClientInfo("TestClient1", ClientStatus.COMPLETED);
            zookeeperHelper.updateNodeData(zookeeperHelper.getClientPath("TestClient1", ServiceEnum.INVESTMENTS), ProtoJsonHelper.convertToJson(clientInfo).getBytes());
            assertThat(zookeeperHelper.getNodeData(zookeeperHelper.getClientPath("TestClient1", ServiceEnum.INVESTMENTS))).isNotNull();
            assertThat(zookeeperHelper.getBuilderFromJson(zookeeperHelper.getClientPath("TestClient1", ServiceEnum.INVESTMENTS))
                    .getStatus()).isEqualTo(ClientStatus.COMPLETED);

        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void getNodeData_Success() {
        try {
            assertThat(zookeeperHelper.getNodeData(AppConstants.ZKPATH_PARENT)).isNotNull();
            assertThat(zookeeperHelper.getNodeData(zookeeperHelper.getClientPath("AladdinDemo", ServiceEnum.INVESTMENTS))).isNotNull();
        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void testUpdateChildNodeStatusToComplete_Success() {
        try {
            when(lockHelper.acquireLockWithRetry(anyString())).thenReturn(true);
            ClientInfo clientInfo = zookeeperHelper.buildClientInfo("TestUpdateClient1", ClientStatus.INITIATED);
            zookeeperHelper.createZKPath(zookeeperHelper.getClientPath("TestUpdateClient1", ServiceEnum.INVESTMENTS), ProtoJsonHelper.convertToJson(clientInfo).getBytes());
            zookeeperHelper.updateChildNodeStatusToComplete("TestUpdateClient1", ServiceEnum.INVESTMENTS);
            assertThat(zookeeperHelper.getBuilderFromJson(zookeeperHelper.getClientPath("TestUpdateClient1", ServiceEnum.INVESTMENTS)).getStatus()).isEqualTo(ClientStatus.COMPLETED);
        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void testUpdateChildNodeStatusToCompleteWithLastSuccessfulTime_Success() {
        try {
            when(lockHelper.acquireLockWithRetry(anyString())).thenReturn(true);
            ClientInfo clientInfo = zookeeperHelper.buildClientInfo("TestUpdateClient8", ClientStatus.INITIATED);
            zookeeperHelper.createZKPath(zookeeperHelper.getClientPath("TestUpdateClient8", ServiceEnum.INVESTMENTS), ProtoJsonHelper.convertToJson(clientInfo).getBytes());
            zookeeperHelper.updateChildNodeStatusToComplete("TestUpdateClient8", ServiceEnum.INVESTMENTS, new Long(12346787));
            assertThat(zookeeperHelper.getBuilderFromJson(zookeeperHelper.getClientPath("TestUpdateClient8", ServiceEnum.INVESTMENTS)).getStatus()).isEqualTo(ClientStatus.COMPLETED);
        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void testUpdateChildNodeStatusToComplete_Exception() {
        try {
            doThrow(new NullPointerException()).when(lockHelper).acquireLockWithRetry(anyString());
            ClientInfo clientInfo = zookeeperHelper.buildClientInfo("TestUpdateClient1", ClientStatus.INITIATED);
            zookeeperHelper.createZKPath(zookeeperHelper.getClientPath("TestUpdateClient1", ServiceEnum.INVESTMENTS), ProtoJsonHelper.convertToJson(clientInfo).getBytes());
            zookeeperHelper.updateChildNodeStatusToComplete("TestUpdateClient1", ServiceEnum.INVESTMENTS);
            assertThat(zookeeperHelper.getBuilderFromJson(zookeeperHelper.getClientPath("TestUpdateClient1", ServiceEnum.INVESTMENTS))
                    .getStatus()).isEqualTo(ClientStatus.INITIATED);
        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void testUpdateChildNodeStatusToComplete_NoLockAcquired() {
        try {
            //Arrange
            when(lockHelper.acquireLockWithRetry(anyString())).thenReturn(false);
            ClientInfo clientInfo = zookeeperHelper.buildClientInfo("TestUpdateClient1", ClientStatus.INITIATED);

            //Act
            zookeeperHelper.createZKPath(zookeeperHelper.getClientPath("TestUpdateClient1", ServiceEnum.INVESTMENTS), ProtoJsonHelper.convertToJson(clientInfo).getBytes());
            zookeeperHelper.updateChildNodeStatusToComplete("TestUpdateClient1", ServiceEnum.INVESTMENTS);

            //Verify
            assertThat(zookeeperHelper.getBuilderFromJson(zookeeperHelper.getClientPath("TestUpdateClient1", ServiceEnum.INVESTMENTS))
                    .getStatus()).isNotEqualTo(ClientStatus.COMPLETED);

        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void testUpdateLastSuccessfulTime_Success() {
        try {
            //Arrange
            when(lockHelper.acquireLockWithRetry(anyString())).thenReturn(true);
            ClientInfo clientInfo = zookeeperHelper.buildClientInfo("TestUpdateClient2", ClientStatus.INITIATED);

            //Act
            zookeeperHelper.createZKPath(zookeeperHelper.getClientPath("TestUpdateClient2", ServiceEnum.INVESTMENTS), ProtoJsonHelper.convertToJson(clientInfo).getBytes());
            zookeeperHelper.updateLastSuccessfulTime("TestUpdateClient2", ServiceEnum.INVESTMENTS, new Long(12345667));

            //Verify
            assertThat(zookeeperHelper.getBuilderFromJson(zookeeperHelper.getClientPath("TestUpdateClient2", ServiceEnum.INVESTMENTS)).getStatus()).isEqualTo(ClientStatus.INITIATED);

        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void testUpdateLastSuccessfulTime_Exception() {
        try {
            //Arrange
            doThrow(new NullPointerException()).when(lockHelper).acquireLockWithRetry(anyString());
            ClientInfo clientInfo = zookeeperHelper.buildClientInfo("TestUpdateClient3", ClientStatus.INITIATED);

            //Act
            zookeeperHelper.createZKPath(zookeeperHelper.getClientPath("TestUpdateClient3", ServiceEnum.INVESTMENTS), ProtoJsonHelper.convertToJson(clientInfo).getBytes());
            zookeeperHelper.updateLastSuccessfulTime("TestUpdateClient3", ServiceEnum.INVESTMENTS, new Long(12345667));

            //Verify
            assertThat(zookeeperHelper.getBuilderFromJson(zookeeperHelper.getClientPath("TestUpdateClient3", ServiceEnum.INVESTMENTS))
                    .getStatus()).isEqualTo(ClientStatus.INITIATED);

        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void testUpdateLastSuccessfulTime_BadArgumentException() {
        try {
            //Arrange
            ClientInfo clientInfo = zookeeperHelper.buildClientInfo("TestUpdateClient5", ClientStatus.INITIATED);

            //Act
            zookeeperHelper.createZKPath(zookeeperHelper.getClientPath("TestUpdateClient5", ServiceEnum.INVESTMENTS), clientInfo.toByteArray());
            zookeeperHelper.updateLastSuccessfulTime("TestWrongArgument", ServiceEnum.INVESTMENTS, new Long(12345667));

            //Verify
            assertThat(ClientInfo.parseFrom(zookeeperHelper.getNodeData(zookeeperHelper.getClientPath("TestUpdateClient5", ServiceEnum.INVESTMENTS)))
                    .getStatus()).isEqualTo(ClientStatus.INITIATED);
        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void testUpdateLastSuccessfulTime_NoLockAcquired() {
        try {
            //Arrange
            when(lockHelper.acquireLockWithRetry(anyString())).thenReturn(false);
            ClientInfo clientInfo = zookeeperHelper.buildClientInfo("TestUpdateClient4", ClientStatus.INITIATED);

            //Act
            zookeeperHelper.createZKPath(zookeeperHelper.getClientPath("TestUpdateClient4", ServiceEnum.INVESTMENTS), clientInfo.toByteArray());
            zookeeperHelper.updateLastSuccessfulTime("TestUpdateClient4", ServiceEnum.INVESTMENTS, new Long(12345667));

            //Verify
            assertThat(ClientInfo.parseFrom(zookeeperHelper.getNodeData(zookeeperHelper.getClientPath("TestUpdateClient4", ServiceEnum.INVESTMENTS)))
                    .getStatus()).isNotEqualTo(ClientStatus.COMPLETED);

        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void testServerContextFromDefaultPath_Success() {
        try {
            //Arrange
            when(lockHelper.acquireLockWithRetry(anyString())).thenReturn(true);
            //Act
            ServerContext context = zookeeperHelper.getServerContextFromDefaultZKPath();
            zookeeperHelper.lockUpdateSeverContext(context, getAllTestClientInfo(Arrays.asList("AladdinDemo", "ManjiriTest1")));
            //Verify
            assertThat(zookeeperHelper.getServerContextFromDefaultZKPath().getClientsList().size()).isEqualTo(2);

        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void testServerContextFromDefaultPath_LockFailed() {
        try {
            //Arrange
            when(lockHelper.acquireLockWithRetry(anyString())).thenReturn(false);
            //Act
            zookeeperHelper.lockUpdateSeverContext(ServerContext.getDefaultInstance(), new ArrayList<>());
            //Verify
            verify(lockHelper, never()).releaseLock(anyString());
        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void testServerContextFromDefaultPath_NullData() {
        try {
            //Arrange
            when(lockHelper.acquireLockWithRetry(anyString())).thenReturn(true);
            //Act
            zooKeeper.setData(ZKPATH_PARENT, null, -1);
            ServerContext context = zookeeperHelper.getServerContextFromDefaultZKPath();
            //Verify
            Assert.assertNull(context);
        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void testServerContextFromDefaultPath_ExistingServerContext() {
        try {
            //Arrange
            List<String> clients = Arrays.asList("Blackrock", "efront", "aladdin234", "test1");
            ServerContext.Builder serverContextBuilder = ServerContext.newBuilder();
            serverContextBuilder.setServerInstance("server1")
                    .addAllClients(clients.subList(0, clients.size() - 1))
                    .addClients("extraClient")
                    .addAllInProgressClients(clients.subList(2, 4))
                    .setStartHashRange(0).setEndHashRange(359)
                    .setIsIssuersScheduled(false)
                    .setHeartBeat(Timestamps.fromMillis(System.currentTimeMillis() + 1000));
            byte[] contextData = ProtoJsonHelper.convertToJson(serverContextBuilder).getBytes();
            when(lockHelper.acquireLockWithRetry(anyString())).thenReturn(true);
            //Act
            zookeeperHelper.ensurePathCreated(ZKPATH_PARENT, contextData);
            zooKeeper.setData(ZKPATH_PARENT, contextData, -1);
            ServerContext context = zookeeperHelper.getServerContextFromDefaultZKPath();
            zookeeperHelper.lockUpdateSeverContext(context, getAllTestClientInfo(Arrays.asList("AladdinDemo", "ManjiriTest1")));
            //Verify
            verify(lockHelper, times(1)).acquireLockWithRetry(anyString());
            assertThat(zookeeperHelper.getServerContextFromDefaultZKPath().getClientsList().size()).isEqualTo(4);

        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void testGetClientsForProcessing() {
        try {
            //Arrange
            List<String> clients = Arrays.asList("Blackrock", "efront", "aladdin234", "test1");
            Set<ClientInfo> clientInfos = getAllTestClientInfoSet(clients);
            Map<String, Map<String, String>> clientPathToName = clientInfos.stream()
                    .collect(Collectors.toConcurrentMap(ClientInfo::getClientName,
                            client -> client.getEntityServiceList()
                                    .stream()
                                    .collect(Collectors.toMap(EntityService::getServiceName,
                                            entityService -> this.zookeeperHelper.getClientPath(client.getClientName(),
                                                    ServiceEnum.findService(entityService.getServiceName()))))));
            ServerContext.Builder serverContextBuilder = ServerContext.newBuilder();
            serverContextBuilder.setServerInstance("server1")
                    .addAllClients(clients)
                    .setStartHashRange(0).setEndHashRange(359)
                    .setIsIssuersScheduled(false)
                    .setHeartBeat(Timestamps.fromMillis(System.currentTimeMillis() + 1000));
            byte[] contextData = ProtoJsonHelper.convertToJson(serverContextBuilder).getBytes();
            when(lockHelper.acquireLockWithRetry(anyString())).thenReturn(true);

            //Act
            zookeeperHelper.ensurePathCreated(ZKPATH_PARENT, contextData);
            zooKeeper.setData(ZKPATH_PARENT, contextData, -1);
            zookeeperHelper.getClientsForProcessing(clientPathToName, 300);

            //Verify
//            verify(lockHelper, times(4)).acquireLockWithRetry(anyString());
            assertThat(zookeeperHelper.getServerContextFromDefaultZKPath().getClientsList().size()).isEqualTo(4);

        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void testEnsureChideNodeExists() {
        try {
            //Arrange
            String investClientName = "NewTestClientInvest";
            String crmClientName = "NewTestClientCRM";
            //Act
            zookeeperHelper.ensureChildNodeExists(investClientName, zookeeperHelper.getClientPath(investClientName, ServiceEnum.INVESTMENTS), ServiceEnum.INVESTMENTS);
            zookeeperHelper.ensureChildNodeExists(crmClientName, zookeeperHelper.getClientPath(crmClientName, ServiceEnum.CRM), ServiceEnum.CRM);
            ClientInfo.Builder invClientInfoZk = ClientInfo.newBuilder();
            ClientInfo.Builder crmClientInfoZk = ClientInfo.newBuilder();
            ProtoJsonHelper.tryMergeFromJson(invClientInfoZk, new String(zookeeperHelper.getNodeData(zookeeperHelper.getClientPath(investClientName, ServiceEnum.INVESTMENTS))));
            ProtoJsonHelper.tryMergeFromJson(crmClientInfoZk, new String(zookeeperHelper.getNodeData(zookeeperHelper.getClientPath(crmClientName, ServiceEnum.CRM))));
            invClientInfoZk.build();
            crmClientInfoZk.build();
            //Verify
//            assertThat(Timestamps.toMillis(invClientInfoZk.getLastModifiedTime())).isEqualTo(this.utilService.getLastSuccessfulTime(investClientName, ServiceEnum.Investments));
//            assertThat(Timestamps.toMillis(crmClientInfoZk.getLastModifiedTime())).isEqualTo(this.utilService.getLastSuccessfulTime(crmClientName, ServiceEnum.CRM));
            assertThat(ServiceEnum.findService("cRm")).isEqualTo(ServiceEnum.CRM);
            assertThat(ServiceEnum.findService("inVestments")).isEqualTo(ServiceEnum.INVESTMENTS);
            assertThat(ServiceEnum.findService("Invest")).isNull();
            assertThat(ClientGuidEnum.findGuidEnum(investClientName)).isNull();
            assertThat(ClientGuidEnum.findGuidEnum("ALADDIN_DEMO")).isNotNull();

        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void testEnsurePathCreated() {
        try {
            //Arrange
            String investClientName = "NewTestClientInvest123";

            //Act
            zookeeperHelper.ensurePathCreated(investClientName);

            //Verify
            assertThat(zookeeperHelper.getNodeData(zookeeperHelper.getClientPath(investClientName, ServiceEnum.INVESTMENTS))).isNullOrEmpty();

        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void testEnsurePathCreatedWithUpdate() {
        try {
            //Arrange
            String testClientName = "NewTestClientInvest5678";
            String path = this.zookeeperHelper.getClientPath(testClientName, ServiceEnum.CRM);
            Set<ClientInfo> clientsInfoSet = new HashSet<>();
            ClientInfo.Builder clientInfoZk = ClientInfo.newBuilder();
            //Act
            zookeeperHelper.ensurePathCreated(path);
            zookeeperHelper.getUpdateChildNodes(path, testClientName, clientsInfoSet, 1);
            ProtoJsonHelper.tryMergeFromJson(clientInfoZk, new String(zookeeperHelper.getNodeData(zookeeperHelper.getClientPath(testClientName, ServiceEnum.CRM))));
            clientInfoZk.build();
            //Verify
            assertThat(zookeeperHelper.getNodeData(zookeeperHelper.getClientPath(testClientName, ServiceEnum.CRM))).isNotNull();
            assertThat(clientInfoZk.getStatus()).isEqualTo(ClientStatus.IN_PROGRESS);

        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void testClientEligibility() {
        try {
            //Arrange
            ClientInfo clientInfo = zookeeperHelper.buildClientInfo("NewTestClientInvest_1234", ClientStatus.IN_PROGRESS);
            final Timestamp circuitBreakerInterval = Timestamps.fromMillis(System.currentTimeMillis() - CUT_OFF_TIME);
            ClientInfo.Builder builder = clientInfo.toBuilder();
            clientInfo = builder.setLastModifiedTime(circuitBreakerInterval).build();

            ClientInfo clientInfoInProgress = zookeeperHelper.buildClientInfo("NewTestClientManjiri_1234", ClientStatus.IN_PROGRESS);
            ClientInfo clientInfoInitiatedStatus = zookeeperHelper.buildClientInfo("test_manjiri_client_22334", ClientStatus.INITIATED, (System.currentTimeMillis() - CUT_OFF_TIME));

            List<String> clients = Arrays.asList("Blackrock", "efront", "aladdin234", "test1");
            Set<ClientInfo> clientInfoSet = getAllTestClientInfoSet(clients);
            clientInfoSet.add(clientInfo);
            clientInfoSet.add(clientInfoInProgress);
            clientInfoSet.add(clientInfoInitiatedStatus);


            Map<String, Map<String, String>> clientPathToName = new HashMap<>();
            for (ClientInfo clientInfo1 : clientInfoSet) {
                Map<String, String> pathMap = new HashMap<>();
                pathMap.put("INVESTMENTS", this.zookeeperHelper.getClientPath(clientInfo1.getClientName(), ServiceEnum.INVESTMENTS));
                clientPathToName.put(clientInfo1.getClientName(), pathMap);
            }

            ServerContext.Builder serverContextBuilder = ServerContext.newBuilder();
            serverContextBuilder.setServerInstance("server1")
                    .addAllClients(clients)
                    .setStartHashRange(0).setEndHashRange(359)
                    .setIsIssuersScheduled(false)
                    .setHeartBeat(Timestamps.fromMillis(System.currentTimeMillis() + 1000));
            byte[] contextData = ProtoJsonHelper.convertToJson(serverContextBuilder).getBytes();
            when(lockHelper.acquireLockWithRetry(anyString())).thenReturn(true);

            //Act
            zookeeperHelper.ensurePathCreated(ZKPATH_PARENT, contextData);
            zooKeeper.setData(ZKPATH_PARENT, contextData, -1);
            zookeeperHelper.createZKPath(zookeeperHelper.getClientPath("NewTestClientInvest_1234", ServiceEnum.INVESTMENTS), ProtoJsonHelper.convertToJson(clientInfo).getBytes());
            zookeeperHelper.createZKPath(zookeeperHelper.getClientPath("NewTestClientManjiri_1234", ServiceEnum.INVESTMENTS), ProtoJsonHelper.convertToJson(clientInfoInProgress).getBytes());
            zookeeperHelper.createZKPath(zookeeperHelper.getClientPath("test_manjiri_client_22334", ServiceEnum.INVESTMENTS), ProtoJsonHelper.convertToJson(clientInfoInitiatedStatus).getBytes());
            zookeeperHelper.getClientsForProcessing(clientPathToName, 300);

            //Verify
            verify(lockHelper, times(7)).acquireLockWithRetry(anyString());
            assertThat(zookeeperHelper.getNodeData(zookeeperHelper.getClientPath("NewTestClientInvest_1234", ServiceEnum.INVESTMENTS))).isNotNull();
            assertThat(zookeeperHelper.getBuilderFromJson(zookeeperHelper.getClientPath("NewTestClientInvest_1234", ServiceEnum.INVESTMENTS)).build().getStatus()).isEqualTo(ClientStatus.IN_PROGRESS);
            assertThat(zookeeperHelper.getBuilderFromJson(zookeeperHelper.getClientPath("NewTestClientManjiri_1234", ServiceEnum.INVESTMENTS)).build().getStatus()).isEqualTo(ClientStatus.IN_PROGRESS);
            assertThat(zookeeperHelper.getBuilderFromJson(zookeeperHelper.getClientPath("test_manjiri_client_22334", ServiceEnum.INVESTMENTS)).build().getStatus()).isEqualTo(ClientStatus.IN_PROGRESS);

        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void testClientEligibility_NoEntityServiceData() {
        try {
            //Arrange
            ClientInfo clientInfoInProgress = zookeeperHelper.buildClientInfo("NewTestClientInsight_1234", ClientStatus.IN_PROGRESS);
            ClientInfo clientInfoInitiatedStatus = zookeeperHelper.buildClientInfo("test_insight_client_223344", ClientStatus.INITIATED, (System.currentTimeMillis() - CUT_OFF_TIME));

            ClientInfo.Builder testBuilder1 = clientInfoInProgress.toBuilder();
            clientInfoInProgress = testBuilder1.clearEntityService().build();
            ClientInfo.Builder testBuilder2 = clientInfoInitiatedStatus.toBuilder();
            clientInfoInitiatedStatus = testBuilder2.clearEntityService().build();

            //Act
            zookeeperHelper.createZKPath(zookeeperHelper.getClientPath("NewTestClientInsight_1234", ServiceEnum.INVESTMENTS), ProtoJsonHelper.convertToJson(clientInfoInProgress).getBytes());
            zookeeperHelper.createZKPath(zookeeperHelper.getClientPath("test_insight_client_223344", ServiceEnum.INVESTMENTS), ProtoJsonHelper.convertToJson(clientInfoInitiatedStatus).getBytes());
            zookeeperHelper.updateClientInfo(zookeeperHelper.getClientPath(clientInfoInProgress.getClientName(), ServiceEnum.INVESTMENTS), ClientStatus.COMPLETED, System.currentTimeMillis());
            zookeeperHelper.updateClientInfo(zookeeperHelper.getClientPath(clientInfoInitiatedStatus.getClientName(), ServiceEnum.INVESTMENTS), ClientStatus.COMPLETED, System.currentTimeMillis());


            //Verify
            assertThat(zookeeperHelper.getNodeData(zookeeperHelper.getClientPath("NewTestClientInsight_1234", ServiceEnum.INVESTMENTS))).isNotNull();
            assertThat(zookeeperHelper.getBuilderFromJson(zookeeperHelper.getClientPath("NewTestClientInsight_1234", ServiceEnum.INVESTMENTS)).build().getStatus()).isEqualTo(ClientStatus.COMPLETED);
            assertThat(zookeeperHelper.getBuilderFromJson(zookeeperHelper.getClientPath("test_insight_client_223344", ServiceEnum.INVESTMENTS)).build().getStatus()).isEqualTo(ClientStatus.COMPLETED);
            assertThat(zookeeperHelper.getBuilderFromJson(zookeeperHelper.getClientPath("test_insight_client_223344", ServiceEnum.INVESTMENTS)).build().getEntityServiceList()).isNotEmpty();
            assertThat(zookeeperHelper.getBuilderFromJson(zookeeperHelper.getClientPath("NewTestClientInsight_1234", ServiceEnum.INVESTMENTS)).build().getEntityServiceList()).isNotEmpty();

        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    @Test
    public void testResolveAllClients() throws KeeperException, InterruptedException {
        when(clientInfoDAO.getServiceToClientMap()).thenReturn(serviceToClientInfo);
        when(lockHelper.acquireLockWithRetry(anyString())).thenReturn(true);
        ClientInfo clientInfo = zookeeperHelper.buildClientInfo("ALADDIN.DEV", ClientStatus.INITIATED);
        zookeeperHelper.createZKPath(zookeeperHelper.getClientPath("ALADDIN.DEV", ServiceEnum.CRM), ProtoJsonHelper.convertToJson(clientInfo).getBytes());
        zookeeperHelper.resolveAllClientsOnShutdown();
        assertThat(zookeeperHelper.getBuilderFromJson(zookeeperHelper.getClientPath("ALADDIN.DEV", ServiceEnum.CRM)).getStatus()).isEqualTo(ClientStatus.COMPLETED);
    }

    @Test
    public void updateEntityTimestamp_with_empty_service() throws InterruptedException, KeeperException {
        //Arrange
        when(clientInfoDAO.getServiceToClientMap()).thenReturn(serviceToClientInfo);
        when(lockHelper.acquireLockWithRetry(anyString())).thenReturn(true);
        Map<EntityType, Map<String, Long>> entityTypeTimeStamp = Maps.newEnumMap(EntityType.class);
        Map<String, Long> timestampMap = new HashMap<>();
        timestampMap.put("FIA", new Long(1239876));
        timestampMap.put("DWH", new Long(1239879));
        entityTypeTimeStamp.put(EntityType.ASSET, timestampMap);

        //Act
        zookeeperHelper. updateEntityTimestamp("ALADDIN.DEV", ServiceEnum.INVESTMENTS, new Long(12345667),  entityTypeTimeStamp);


        //Verify
        verify(lockHelper, times(1)).acquireLockWithRetry(anyString());
        verify(lockHelper, times(1)).releaseLock(anyString());
    }

    @Test
    public void updateEntityTimestamp() throws InterruptedException, KeeperException {
        //Arrange
        when(clientInfoDAO.getServiceToClientMap()).thenReturn(serviceToClientInfo);
        when(lockHelper.acquireLockWithRetry(anyString())).thenReturn(true);
        ClientInfo.Builder clientInfoBuilder = ClientInfo.newBuilder(zookeeperHelper.buildClientInfo("ALADDIN.DEV", ClientStatus.INITIATED));
        EntityService.Builder enBuilder = EntityService.newBuilder().addEntityType(EntityType.ASSET).setServiceName("ASSET");
        clientInfoBuilder.addEntityService(enBuilder);
        zookeeperHelper.createZKPath(zookeeperHelper.getClientPath("ALADDIN.DEV", ServiceEnum.INVESTMENTS), ProtoJsonHelper.convertToJson(clientInfoBuilder.build()).getBytes());
        Map<EntityType, Map<String, Long>> entityTypeTimeStamp = Maps.newEnumMap(EntityType.class);
        Map<String, Long> timestampMap = new HashMap<>();
        timestampMap.put("FIA", new Long(1239876));
        timestampMap.put("DWH", new Long(1239879));
        entityTypeTimeStamp.put(EntityType.ASSET, timestampMap);

        //Act
        zookeeperHelper. updateEntityTimestamp("ALADDIN.DEV", ServiceEnum.INVESTMENTS, new Long(12345667),  entityTypeTimeStamp);

        //Verify
        verify(lockHelper, times(1)).acquireLockWithRetry(anyString());
        verify(lockHelper, times(1)).releaseLock(anyString());
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
        zooKeeper.close();
        zkServer.close();
        protocolSupport.close();
        Thread.sleep(600); // Allows some time for the server to stop properly
    }

}
