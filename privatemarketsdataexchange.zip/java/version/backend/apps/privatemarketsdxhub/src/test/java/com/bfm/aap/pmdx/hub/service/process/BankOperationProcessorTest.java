package com.bfm.aap.pmdx.hub.service.process;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.model.BankAccount;
import com.bfm.aap.pmdx.model.BankOperation;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.bfm.aap.pmdx.model.util.LibRedBlueProxy;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.model.util.NetworkModeHelper;
import com.bfm.aap.pmdx.model.util.Source;
import com.bfm.aap.pmdx.notification.service.EmailNotification;
import com.google.protobuf.util.Timestamps;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.bfm.aap.pmdx.model.util.NetworkModeHelper.getCompliment;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

@RunWith(PowerMockRunner.class)

@PrepareForTest({EmailNotification.class, LibRedBlueProxy.class})
public class BankOperationProcessorTest extends BaseUnitTest {


    @InjectMocks
    BankOperationProcessor bankOperationProcessor;

    private final NetworkMode serverMode = NetworkModeHelper.getNetworkModeFromString(System.getProperty("mode"));

    @Before
    public void init() {
        bankOperationProcessor.isPrimary = true;
    }

    @Test
    public void getLastSuccessfulTime() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<BankOperation> bankOperations = getBankOperations(t1, t2, t3);
        //Act
        long lastSuccessfulTime = bankOperationProcessor.getLastSuccessfulTime(bankOperations);
        //Verify
        assertEquals(t3, lastSuccessfulTime);
    }

    @Test
    public void processEntities() throws Exception {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<BankOperation> bankOperations = getBankOperations(t1, t2, t3);
        //invalid Instrument
        bankOperations.add(BankOperation.newBuilder().setBankOperationId("dummyID").build());
        BankOperation.Builder fb = BankOperation.newBuilder(bankOperations.get(0)).setBankOperationId("id5");
        fb.getEntityInfoBuilder().setNetworkMode(getCompliment(serverMode));
        bankOperations.add(fb.build());

        //Act
        List<BankOperation> updatedInstruments = bankOperationProcessor.processEntities(bankOperations);

        //Verify
        assertEquals(3, updatedInstruments.size());
        assertEquals(3, updatedInstruments.stream().filter(a -> a.getEntityInfo().getPrimaryData()).count());
        assertEquals(3, updatedInstruments.stream().filter(a -> a.getEntityInfo().getNetworkMode() == serverMode).count());
    }

    @Test
    public void processEntities_PrimaryFlagTest() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<BankOperation> bankOperations = getBankOperations(t1 + 1000, t2 + 1000, t3 + 1000);
        //invalid Instrument
        bankOperations.add(BankOperation.newBuilder().setBankOperationId("dummyID").build());
        BankOperation.Builder fb = BankOperation.newBuilder(bankOperations.get(0)).setBankOperationId("id5");
        fb.getEntityInfoBuilder().setOriginTimestamp(Timestamps.fromMillis(t1 - 1000));
        bankOperations.add(fb.build());

        //Act
        List<BankOperation> updatedInstruments = bankOperationProcessor.processEntities(bankOperations);

        //Verify
        assertEquals(4, updatedInstruments.size());
        assertEquals(4, updatedInstruments.stream().filter(a -> a.getEntityInfo().getPrimaryData()).count());
        assertEquals(4, updatedInstruments.stream().filter(a -> a.getEntityInfo().getNetworkMode() == serverMode).count());
    }

    @Test
    public void processEntity() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<BankOperation> bankOperations = getBankOperations(t1 + 1000, t2 + 1000, t3 + 1000);

        //Act
        BankOperation updatedBankOperations = bankOperationProcessor.processEntity(bankOperations.get(0)
        );
        BankOperation updatedBankOperations2 = bankOperationProcessor.processEntity(bankOperations.get(1)
        );

        //Verify
        assertTrue(updatedBankOperations.getEntityInfo().getPrimaryData());
        assertTrue(updatedBankOperations2.getEntityInfo().getPrimaryData());
        assertEquals(serverMode, updatedBankOperations.getEntityInfo().getNetworkMode());
    }

    @Test
    public void processEntity_InvalidEntity() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<BankOperation> bankOperations = getBankOperations(t1 + 1000, t2 + 1000, t3 + 1000);

        //Act
        try {
            bankOperationProcessor.processEntity(bankOperations.get(0));
//            fail();
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(e.getMessage().contains("Invalid entity info for"));
        }
    }

    @Test
    public void updatePrimaryFlag(){
        //Act
        BankOperation bankOperation = bankOperationProcessor.updatePrimaryFlag(getBankOperation(), true);

        //Verify
        assertTrue(bankOperation.getEntityBankAccount().getEntityInfo().getPrimaryData());
        assertTrue(bankOperation.getCounterpartyBankAccount().getEntityInfo().getPrimaryData());
    }

    @Test
    public void updatePrimaryFlagFalse(){
        //Act
        BankOperation bankOperation = bankOperationProcessor.updatePrimaryFlag(getBankOperation(), false);

        //Verify
        assertFalse(bankOperation.getEntityBankAccount().getEntityInfo().getPrimaryData());
        assertFalse(bankOperation.getCounterpartyBankAccount().getEntityInfo().getPrimaryData());
    }

    @Test
    public void updatePrimaryFlagWithoutBA(){
        //Act
        BankOperation bankOperation = bankOperationProcessor.updatePrimaryFlag(BankOperation.newBuilder().build(), false);

        //Verify
        assertFalse(bankOperation.getEntityBankAccount().getEntityInfo().getPrimaryData());
        assertFalse(bankOperation.getCounterpartyBankAccount().getEntityInfo().getPrimaryData());
    }

    @Test
    public void updatePrimaryFlagWithoutBAEntityInfo(){
        //arrange
        BankOperation bankOperation = getBankOperation();
        bankOperation = bankOperation.toBuilder().setEntityBankAccount(BankAccount.newBuilder().setEntityBankAccountId("AA").build()).build();

        //Act
        bankOperation = bankOperationProcessor.updatePrimaryFlag(bankOperation, true);

        //Verify
        assertFalse(bankOperation.getEntityBankAccount().getEntityInfo().getPrimaryData());
        assertTrue(bankOperation.getCounterpartyBankAccount().getEntityInfo().getPrimaryData());
    }

    private List<BankOperation> getBankOperations(long t1, long t2, long t3) {
        BankOperation.Builder fa1 = BankOperation.newBuilder().setBankOperationId("id1");
        fa1.getEntityInfoBuilder().setNetworkMode(serverMode).setOriginTimestamp(Timestamps.fromMillis(t1));
        BankOperation.Builder fa2 = BankOperation.newBuilder().setBankOperationId("id2");
        fa2.getEntityInfoBuilder().setNetworkMode(serverMode).setOriginTimestamp(Timestamps.fromMillis(t2));
        BankOperation.Builder fa3 = BankOperation.newBuilder().setBankOperationId("id3");
        fa3.getEntityInfoBuilder().setNetworkMode(serverMode).setOriginTimestamp(Timestamps.fromMillis(t3));
        return new ArrayList<>(Arrays.asList(fa1.build(), fa2.build(), fa3.build()));
    }

    private BankOperation getBankOperation(){
        return BankOperation.newBuilder().setBankOperationId("id1")
                .setEntityBankAccount(BankAccount.newBuilder().
                        setEntityInfo(EntityInfo.newBuilder().setSource(Source.INVEST).build()).build())
                .setCounterpartyBankAccount(BankAccount.newBuilder().
                        setEntityInfo(EntityInfo.newBuilder().setSource(Source.INVEST).build()).build())
                .build();
    }
}
