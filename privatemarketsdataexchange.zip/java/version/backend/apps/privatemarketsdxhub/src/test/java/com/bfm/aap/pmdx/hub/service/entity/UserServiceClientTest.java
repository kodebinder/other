package com.bfm.aap.pmdx.hub.service.entity;

import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.model.User;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import io.grpc.ManagedChannel;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class UserServiceClientTest extends BaseUnitTest {

    private UserServiceClient userServiceClient;

    @Mock
    private RPCServiceClient rpcServiceClient;

    @Mock
    private EntityProcessor<User> entityProcessor;

    @Mock
    private ManagedChannel channel;

    @BeforeEach
    void init() {
        this.userServiceClient = new UserServiceClient(rpcServiceClient, channel, entityProcessor);
    }

    @Test
    void fetchEntitiesSinceTest() {
        //Act
        this.userServiceClient.fetchEntitiesSince(System.currentTimeMillis(), buildTestClientInfoWithAllEntityType("Dummy", "dummy"), null);

        //Verify
        verify(rpcServiceClient).doFetchSince(any(), any(), any(), any(), any(ClientInfo.class), anyLong());
    }
}