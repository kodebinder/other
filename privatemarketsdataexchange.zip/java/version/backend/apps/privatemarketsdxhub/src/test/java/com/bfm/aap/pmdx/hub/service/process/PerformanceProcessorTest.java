package com.bfm.aap.pmdx.hub.service.process;


import com.bfm.aap.pmdx.hub.BaseUnitTest;
import com.bfm.aap.pmdx.model.Performance;
import com.bfm.aap.pmdx.model.util.LibRedBlueProxy;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.model.util.NetworkModeHelper;
import com.bfm.aap.pmdx.notification.service.EmailNotification;
import com.google.protobuf.util.Timestamps;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.bfm.aap.pmdx.model.util.NetworkModeHelper.getCompliment;
import static org.junit.Assert.assertEquals;

@RunWith(PowerMockRunner.class)@PrepareForTest({EmailNotification.class, LibRedBlueProxy.class})
public class PerformanceProcessorTest extends BaseUnitTest {

    @InjectMocks
    PerformanceProcessor performanceProcessor;

    private final NetworkMode serverMode = NetworkModeHelper.getNetworkModeFromString(System.getProperty("mode"));

    @Before
    public void init() {
        performanceProcessor.isPrimary = true;
    }

    @Test
    public void getLastSuccessfulTime() {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<Performance> performances = getPerformances(t1, t2, t3);
        //Act
        long lastSuccessfulTime = performanceProcessor.getLastSuccessfulTime(performances);
        //Verify
        assertEquals(t3, lastSuccessfulTime);
    }

    @Test
    public void processEntity() throws Exception {
        //Arrange
        long t1 = System.currentTimeMillis() - 5000, t2 = System.currentTimeMillis(), t3 = System.currentTimeMillis() + 5000;
        init(t1, t2, t3);
        List<Performance> ports = getPerformances(t1, t2, t3);
        //invalid Performance
        ports.add(Performance.newBuilder().build());
        Performance.Builder pb = Performance.newBuilder(ports.get(0));
        pb.getEntityInfoBuilder().setNetworkMode(getCompliment(serverMode));
        ports.add(pb.build());

        //Act
        List<Performance> updatedPerformances = performanceProcessor.processEntities(ports);

        //Verify
        assertEquals(ports.size() - 2, updatedPerformances.size());
        assertEquals(3, updatedPerformances.stream().filter(a -> a.getEntityInfo().getPrimaryData()).count());
        assertEquals(3, updatedPerformances.stream().filter(a -> a.getEntityInfo().getNetworkMode() == serverMode).count());
    }

    private List<Performance> getPerformances(long t1, long t2, long t3) {
        Performance.Builder fa1 = Performance.newBuilder().setPerformanceId("id1");
        fa1.getEntityInfoBuilder().setNetworkMode(serverMode).setOriginTimestamp(Timestamps.fromMillis(t1));
        Performance.Builder fa2 = Performance.newBuilder().setPerformanceId("id2");
        fa2.getEntityInfoBuilder().setNetworkMode(serverMode).setOriginTimestamp(Timestamps.fromMillis(t2));
        Performance.Builder fa3 = Performance.newBuilder().setPerformanceId("id3");
        fa3.getEntityInfoBuilder().setNetworkMode(serverMode).setOriginTimestamp(Timestamps.fromMillis(t3));
        return new ArrayList<>(Arrays.asList(fa1.build(), fa2.build(), fa3.build()));
    }
}