package com.bfm.aap.pmdx.hub.repository;

import com.bfm.aap.pmdx.model.util.ClientInfo;
import java.util.List;
import java.util.Map;

public interface ClientInfoDAO {
    ClientInfo getClientById(String clientId);

    ClientInfo getClientByName(String clientName);

    List<ClientInfo> getAllClients();

    List<ClientInfo> getInvestmentClients();

    List<ClientInfo> getCRMClients();

    Map<String, List<ClientInfo>> getServiceToClientMap();

}
