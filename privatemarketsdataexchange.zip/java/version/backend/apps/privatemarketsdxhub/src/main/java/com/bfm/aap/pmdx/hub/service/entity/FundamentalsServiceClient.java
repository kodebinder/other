package com.bfm.aap.pmdx.hub.service.entity;

import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.pmdx.model.Fundamentals;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.aap.pmdx.services.FundamentalsRequest;
import com.bfm.aap.pmdx.services.FundamentalsServiceGrpc;
import com.bfm.aap.pmdx.services.FundamentalsSinceRequest;
import com.bfm.service.ServiceException;
import com.bfm.util.BFMTimestamp;
import com.google.protobuf.Timestamp;
import com.google.protobuf.util.Timestamps;
import io.grpc.ManagedChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import static com.bfm.util.BFMDateConstants.FMT_ISODateTime;
import static com.google.protobuf.util.Timestamps.fromMillis;

@Service
public class FundamentalsServiceClient extends BaseServiceClient<Fundamentals, FundamentalsServiceGrpc.FundamentalsServiceBlockingStub> implements EntityService<Fundamentals, FundamentalsRequest> {
    private static final Logger LOGGER = LoggerFactory.getLogger(FundamentalsServiceClient.class);

    @Autowired
    public FundamentalsServiceClient(ManagedChannel channel, AltsDataWorkspaceDAO altsDataWorkspaceDAO,
                              EntityProcessor<Fundamentals> entityProcessor){
        super(channel, FundamentalsServiceClient.class.getSimpleName(), altsDataWorkspaceDAO, EntityType.FUNDAMENTALS, entityProcessor);
        this.serviceStub = FundamentalsServiceGrpc.newBlockingStub(channel);
    }

    @Override
    @RecordStats(metricName = "fundamentalsService_getFundamentalsSince", timer = true)
    Iterator<Fundamentals> initiateSingleBlockingRequest(long sinceTime, ClientInfo clientInfo, InvestUtils.DataSource dataSource) {
        Timestamp sinceTimeTs = fromMillis(sinceTime);
        BFMTimestamp sinceTimeBfm = new BFMTimestamp(sinceTime, TimeUnit.MILLISECONDS);
        LOGGER.info("Initiating gprc request for getFundamentalsSince for client: {} with localtime {}, GMT time:{}",
                clientInfo.getClientName(), sinceTimeBfm.toBFMDateTime().fmt(FMT_ISODateTime), Timestamps.toString(sinceTimeTs));
        FundamentalsSinceRequest request = FundamentalsSinceRequest.newBuilder().setTimestamp(sinceTimeTs).build();
        return ((FundamentalsServiceGrpc.FundamentalsServiceBlockingStub) getStubWithInterceptor(clientInfo)).getFundamentalsSince(request);
    }

    /**
     * Get single entity via unary grpc call.
     * @param entityRequest
     * @return
     * @throws ServiceException
     */
    @Override
    @RecordStats(metricName = "fundamentalsService_getFundamentals", timer = true)
    public Fundamentals getEntity(FundamentalsRequest entityRequest) {
        try {
            LOGGER.info("Processing single entity request for {}", entityRequest);
            Fundamentals fundamentals = serviceStub
                    .withDeadlineAfter(unaryCallTimeoutMillis, TimeUnit.MILLISECONDS)
                    .getFundamentals(entityRequest);
            this.dataWorkspaceDAO.insertRecords(Collections.singletonList(fundamentals));
            return fundamentals;
        } catch (Exception e) {
            throw new ServiceException( "Failed to get Fundamentals:" + e.getMessage(), e);
        }
    }

    @Override
    String getEntityGuid(Fundamentals entity) {
        return entity.getCompanyId();
    }
}
