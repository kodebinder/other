package com.bfm.aap.pmdx.hub.service.async;

import com.bfm.util.lock.Lock;
import com.bfm.util.lock.LockSupport;
import com.bfm.util.lock.LockingException;
import org.apache.commons.lang3.BooleanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.bfm.aap.pmdx.hub.util.AppConstants.FAILED;
import static com.bfm.aap.pmdx.hub.util.AppConstants.SUCCESSFULLY;

@Service
public class LockHelper {

    private static final Logger LOGGER = LoggerFactory.getLogger(LockHelper.class);
    public static final int MILLIS_5SECS = 5000;

    private final LockSupport lockSupport;

    @Autowired
    public LockHelper(LockSupport lockSupport) {
        this.lockSupport = lockSupport;
    }

    public boolean acquireLock(String path) {
        boolean lockAcquired = false;
        Lock<?> lock = lockSupport.mutex(path);
        LOGGER.info("LockPath: {}, Lock ID: {}", path, lock.getID());
        // Attempt to acquire the lock.
        try {
            lockAcquired = lock.tryAcquire();

        } catch (LockingException e) {
            LOGGER.error("Issue when trying to acquire the lock", e);
        }

        LOGGER.info("Lock {} acquired for thread {} on node at path {}", BooleanUtils.toString(lockAcquired, SUCCESSFULLY, FAILED), Thread.currentThread().getName(), path);
        return lockAcquired;
    }

    public boolean acquireLockWithRetry(String path) {
        boolean lockAcquired = false;
        //2 tries to acquire the lock - 5 secs sleep waiting.
        int lockTry = 0;
        final String finalPath = verifyPathForDelimiter(path);
        while (lockTry <= 2) {
            lockAcquired = acquireLock(finalPath);
            if (lockAcquired) break;
            else {
                lockTry++;
                try {
                    Thread.sleep(MILLIS_5SECS);
                } catch (InterruptedException e) {
                    LOGGER.error("Thread interrupted while acquiring lock..{}", e.getMessage(), e);
                    Thread.currentThread().interrupt();
                }
            }
        }

        LOGGER.info("Lock {} acquired for thread {} on node at path {}", BooleanUtils.toString(lockAcquired, SUCCESSFULLY, FAILED), Thread.currentThread().getName(), path);
        return lockAcquired;
    }

    private String verifyPathForDelimiter(String path) {
        String lockPath = path.startsWith("/") ? path.substring(1) : path;
        if (lockPath.contains("/")) {
            lockPath = lockPath.replace("/", "_");
        }
        return lockPath;
    }

    public boolean releaseLock(String path) {
        boolean lockReleased = false;
        Lock<?> lock = lockSupport.mutex(verifyPathForDelimiter(path));
        // Attempt to acquire the lock.
        try {
            lock.release();
            lockReleased = true;
        } catch (LockingException e) {
            LOGGER.error("Issue when trying to acquire the lock", e);
        }
        LOGGER.info("Lock {} released for thread {} on node at path {}", BooleanUtils.toString(lockReleased, SUCCESSFULLY, FAILED), Thread.currentThread().getName(), path);
        return lockReleased;
    }
}
