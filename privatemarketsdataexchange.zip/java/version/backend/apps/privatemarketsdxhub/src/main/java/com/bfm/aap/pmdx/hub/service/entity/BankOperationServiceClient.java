package com.bfm.aap.pmdx.hub.service.entity;

import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.pmdx.model.BankOperation;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.aap.pmdx.services.BankOperationRequest;
import com.bfm.aap.pmdx.services.BankOperationServiceGrpc;
import com.bfm.aap.pmdx.services.BankOperationsSinceRequest;
import com.bfm.service.ServiceException;
import com.bfm.util.BFMTimestamp;
import com.google.protobuf.Timestamp;
import com.google.protobuf.util.Timestamps;
import io.grpc.ManagedChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import static com.bfm.util.BFMDateConstants.FMT_ISODateTime;
import static com.google.protobuf.util.Timestamps.fromMillis;

@Service
public class BankOperationServiceClient extends BaseServiceClient<BankOperation, BankOperationServiceGrpc.BankOperationServiceBlockingStub>
       implements EntityService<BankOperation, BankOperationRequest> {

    private static final Logger LOGGER = LoggerFactory.getLogger(BankOperationServiceClient.class);

    @Autowired
    public BankOperationServiceClient(ManagedChannel channel, AltsDataWorkspaceDAO altsDataWorkspaceDAO,
                                    EntityProcessor<BankOperation> entityProcessor){
        super(channel, BankOperationServiceClient.class.getSimpleName(), altsDataWorkspaceDAO, EntityType.BANK_OPERATION, entityProcessor);
        this.serviceStub = BankOperationServiceGrpc.newBlockingStub(channel);
    }

    @Override
    Iterator<BankOperation> initiateSingleBlockingRequest(long sinceTime, ClientInfo clientInfo, InvestUtils.DataSource dataSource) {
        Timestamp sinceTimeTs = fromMillis(sinceTime);
        BFMTimestamp sinceTimeBfm = new BFMTimestamp(sinceTime, TimeUnit.MILLISECONDS);
        LOGGER.info("Initiating gprc request for getBankOperationsSince for client: {} with localtime {}, GMT time:{}",
                clientInfo.getClientName(), sinceTimeBfm.toBFMDateTime().fmt(FMT_ISODateTime), Timestamps.toString(sinceTimeTs));
        BankOperationsSinceRequest request = BankOperationsSinceRequest.newBuilder().setTimestamp(sinceTimeTs).build();
        return ((BankOperationServiceGrpc.BankOperationServiceBlockingStub) getStubWithInterceptor(clientInfo)).getBankOperationsSince(request);
    }

    @Override
    String getEntityGuid(BankOperation entity) {
        return entity.getBankOperationId();
    }

    @Override
    @RecordStats(metricName = "bankOperationService_getBankOperation", timer = true)
    public BankOperation getEntity(BankOperationRequest entityRequest) {
        try {
            LOGGER.info("Processing single entity request for {}", entityRequest);
            BankOperation bankOperation = serviceStub
                    .withDeadlineAfter(unaryCallTimeoutMillis, TimeUnit.MILLISECONDS)
                    .getBankOperation(entityRequest);
            this.dataWorkspaceDAO.insertRecords(Collections.singletonList(bankOperation));
            return bankOperation;
        } catch (Exception e) {
            throw new ServiceException("Failed to get bankOperation:"+e.getMessage(), e);
        }
    }
}
