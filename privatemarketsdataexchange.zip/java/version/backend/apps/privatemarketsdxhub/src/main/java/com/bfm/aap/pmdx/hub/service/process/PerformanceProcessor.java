package com.bfm.aap.pmdx.hub.service.process;

import com.bfm.aap.pmdx.model.Performance;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.google.protobuf.util.Timestamps;
import org.springframework.stereotype.Service;

@Service
public class PerformanceProcessor extends EntityProcessor<Performance> {

    @Override
    public long getEntityEpochOriginTime(Performance entity) {
        return Timestamps.toMillis(entity.getEntityInfo().getOriginTimestamp());
    }

    @Override
    Performance updatePrimaryFlag(Performance entity, boolean isPrimary) {
        Performance.Builder performanceBuilder = Performance.newBuilder(entity);
        performanceBuilder.getEntityInfoBuilder().setPrimaryData(isPrimary);
        return performanceBuilder.build();
    }

    @Override
    EntityInfo getEntityInfo(Performance entity) {
        return entity.getEntityInfo();
    }

    @Override
    public String getGuid(Performance entity) {
        return entity.getPerformanceId();
    }

    @Override
    boolean isPrimary(Performance entity) {
        return entity.getEntityInfo().getPrimaryData();
    }

    @Override
    public String getEntityType() {
        return Performance.class.getSimpleName();
    }
}
