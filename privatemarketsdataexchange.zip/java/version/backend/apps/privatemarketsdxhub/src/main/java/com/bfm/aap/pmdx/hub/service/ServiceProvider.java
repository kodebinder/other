package com.bfm.aap.pmdx.hub.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.CountDownLatch;

import com.bfm.aap.pmdx.hub.repository.ClientInfoDAO;
import com.bfm.aap.pmdx.hub.service.async.HeartBeatService;
import com.bfm.aap.pmdx.hub.util.AppConstants;
import com.bfm.aap.privatemarkets.common.scheduler.TaskScheduler;
import com.bfm.util.beans.CollectionUtils;

@Service
public class ServiceProvider {

    private static final Logger LOGGER = LoggerFactory.getLogger(ServiceProvider.class);
    private CountDownLatch serviceProviderTerminatedLatch = new CountDownLatch(0);

    private final HeartBeatService heartBeatService;
    private final ClientInfoDAO clientInfoDAO;
    private final TaskScheduler taskScheduler;

    @Autowired
    public ServiceProvider(HeartBeatService heartBeatService,
                           ClientInfoDAO clientInfoDAO,
                           TaskScheduler taskScheduler) {
        this.heartBeatService = heartBeatService;
        this.clientInfoDAO = clientInfoDAO;
        this.taskScheduler = taskScheduler;
    }

    public void execute() {
        serviceProviderTerminatedLatch = new CountDownLatch(1);
        if (!CollectionUtils.isEmpty(clientInfoDAO.getAllClients())) {
            heartBeatService.start(AppConstants.INVESTMENT_JOB_FREQUENCY);
        }
    }

    public void stopExecutors() {
        if (getTerminatedLatch().getCount() == 1) {
            LOGGER.info("Stopping all services");
            heartBeatService.stop();
            serviceProviderTerminatedLatch.countDown();
        }
    }

    public CountDownLatch getTerminatedLatch() {
        return serviceProviderTerminatedLatch;
    }
}
