package com.bfm.aap.pmdx.hub.service.process;

import com.bfm.aap.pmdx.model.Position;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.bfm.aap.pmdx.model.util.PositionUtil;
import com.google.protobuf.util.Timestamps;
import org.springframework.stereotype.Service;

@Service
public class PositionProcessor extends EntityProcessor<Position> {

    @Override
    public long getEntityEpochOriginTime(Position entity) {
        return Timestamps.toMillis(entity.getEntityInfo().getOriginTimestamp());
    }

    @Override
    Position updatePrimaryFlag(Position entity, boolean isPrimary) {
        Position.Builder positionBuilder = Position.newBuilder(entity);
        positionBuilder.getEntityInfoBuilder().setPrimaryData(isPrimary);
        return positionBuilder.build();
    }

    @Override
    EntityInfo getEntityInfo(Position entity) {
        return entity.getEntityInfo();
    }

    @Override
    public String getGuid(Position entity) {
        return PositionUtil.getPositionIdentifier(entity);
    }

    @Override
    boolean isPrimary(Position entity) {
        return entity.getEntityInfo().getPrimaryData();
    }

    @Override
    public String getEntityType() {
        return Position.class.getSimpleName();
    }
}
