package com.bfm.aap.pmdx.hub.util;

import java.util.Arrays;

public enum ServiceEnum {
    INVESTMENTS("Investments"),
    CRM("CRM");

    private String serviceName;

    ServiceEnum(String serviceName) {
        this.serviceName = serviceName;
    }

    public static ServiceEnum findService(String serviceName) {
         return Arrays.stream(values())
                .filter(enumRecord -> enumRecord.serviceName.equalsIgnoreCase(serviceName))
                .findFirst().orElse(null);
    }

    public String getServiceName() {
        return serviceName;
    }
}