package com.bfm.aap.pmdx.hub.repository;

import java.io.IOException;
import java.util.List;

import com.google.protobuf.Message;

import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.adl.ADLException;
import com.bfm.adl.ADLObject;
import com.bfm.adl.ADLResultSet;

public interface AltsDataWorkspaceDAO {

    long fetchLastSuccessfulTime(NetworkMode networkMode, EntityType entityType) throws ADLException;

    long fetchLastSuccessfulTime(NetworkMode networkMode, String guid) throws ADLException;

    void updateLastSuccessfulTime(long epochTime, NetworkMode networkColor, String entityType, String clientName, String guid) throws ADLException;

    <T extends Message> List<String> insertRecords(List<T> records) throws IOException;

    <T extends Message> String insertRecord(T entity) throws ADLException;

    <T extends Message> String insertRecord(T entity, String source, String clientName) throws ADLException;

    <T extends Message> boolean updateRecord(T entity, String source, String guid) throws ADLException;

    ADLResultSet<ADLObject> fetchADLRecordInWindow(String source, String serverMode, EntityType entityType) throws ADLException;
}
