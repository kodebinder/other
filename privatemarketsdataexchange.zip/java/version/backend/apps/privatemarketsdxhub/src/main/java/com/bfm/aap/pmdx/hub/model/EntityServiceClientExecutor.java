package com.bfm.aap.pmdx.hub.model;

import javax.mail.Message;
import java.util.concurrent.ExecutorService;

import com.bfm.aap.pmdx.hub.service.entity.EntityService;

public class EntityServiceClientExecutor {

    private EntityService<? extends Message, ? extends Message> serviceClient;
    private ExecutorService executorService;

    public EntityServiceClientExecutor(EntityService serviceClient, ExecutorService executorService) {
        this.serviceClient = serviceClient;
        this.executorService = executorService;
    }

    public EntityService<? extends Message, ? extends Message> getServiceClient() {
        return serviceClient;
    }

    public ExecutorService getExecutorService() {
        return executorService;
    }
}
