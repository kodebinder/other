package com.bfm.aap.pmdx.hub.config;

import com.bfm.util.ProtocolSupport;
import com.bfm.util.collections.ConstantSet;
import com.bfm.util.lock.LockSupport;
import com.bfm.util.lock.LockSupport.LockType;
import org.apache.zookeeper.KeeperException;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ZookeeperConfig {

    public static final String ZK_DEDICATED = "ZK_DEDICATED";
    //Max timeout = 20 * tick time at ZK server, tick time = 2 secs.
    public static final int SESSION_TIMEOUT_MILLIS = 40000; //40 Secs
    private static final char LOCK_SEPERATOR = '-';
    private static final int LOCKTTL = 30000;
    private static final int NUMBER_OF_SHARDS = 500;
    private static final long GREEDY_TIMEOUT = 0;

    @Bean
    public ProtocolSupport protocolSupport() throws InterruptedException {
        return new ProtocolSupport(ZK_DEDICATED, SESSION_TIMEOUT_MILLIS, true, false, 3);
    }

    @Bean
    public LockSupport lockSupport() throws InterruptedException, KeeperException {
        LockSupport.Configuration config = new LockSupport.Configuration("pmdx", LOCKTTL,
                ConstantSet.create(LockType.OPTIMISTIC, LockType.MUTEX), LOCK_SEPERATOR, NUMBER_OF_SHARDS,
                GREEDY_TIMEOUT);
        return new LockSupport(protocolSupport(), config);
    }
}
