package com.bfm.aap.pmdx.hub.repository;

import com.bfm.aap.pmdx.hub.service.security.FileDecrypterService;
import com.bfm.aap.pmdx.hub.util.AppConstants;
import com.bfm.aap.pmdx.hub.util.ServiceEnum;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.EntityService;
import com.bfm.aap.pmdx.model.util.ServiceDefinition;
import com.bfm.aap.pmdx.proto.util.ProtoJsonHelper;
import com.bfm.crypt.DecryptionException;
import com.google.common.collect.Maps;
import com.google.gson.JsonParser;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanInitializationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;

@Repository
@DependsOn("perlFileDecrypterService")
public class ClientInfoDAOImpl implements ClientInfoDAO {

    private static final Logger LOGGER = LoggerFactory.getLogger(ClientInfoDAOImpl.class);
    private static final String DEFAULT_AUTH_DATA = "aW52ZXN0XGFsYWRkaW5faW52ZXN0X2RlbW9AYmxhY2tyb2NrLmNvbTpQQHNzd29yZDE=";
    private final List<ClientInfo> clientInfos = new ArrayList<>();
    private final Map<String, List<ClientInfo>> serviceToClientMap = new HashMap<>();
    @Autowired
    @Qualifier("perlFileDecrypterService")
    private FileDecrypterService fileDecrypterService;
    @Value("${disable-secure-connection:false}")
    private boolean disableSecureConnection;
    private boolean overrideFileDecryption;
    /**
     * Example
     * eFrontClients=[{"clientName":"ALADDINTST","clientId":"ALADDINTST","credentialsFileName":"ALADDINTST-PMDXHub.pwd"}]
     */
    @Value("${eFrontClients}")
    private String clientsJson;

    /**
     * Example:
     * servicesDefinition=[{"serviceName":"Investments","entityTypes":["ASSET","PORTFOLIO","POSITION","PERFORMANCE","FUNDAMENTALS"],\
     * "requiredEntityTypes":["ASSET","PORTFOLIO","POSITION"],"clientNames":["ALADDINDEV","ALADDINTST","AladdinDemo"]}]
     */
    @Value("${servicesDefinition}")
    private String servicesJson;

    @Value("${spring.config.location}")
    private String configLocation;

    @Value("${credentials-directory:}")
    private String credentialsDirectory;

    @Value("${credentials-directory-pattern:}")
    private String credentialsDirectoryPattern;

    @PostConstruct
    public void init() {
        LOGGER.info("Config path provided: {}", configLocation);
        // get the environment from BFM Token / env.name variable
        if (StringUtils.isEmpty(AppConstants.ENVIRONMENT))
            throw new BeanInitializationException("Failed to get environment");

        overrideFileDecryption = disableSecureConnection && AppConstants.IS_PRE_PROD_CLIENT;
        parseClients();
    }

    private void parseClients() {
        JsonParser jsonParser = new JsonParser();
        Collection<ServiceDefinition> serviceDefinitions = ProtoJsonHelper.extractFromJsonArray(jsonParser.parse(servicesJson).getAsJsonArray(), ServiceDefinition.newBuilder());
        Map<String, Set<ServiceDefinition>> clientServices = Maps.newHashMap();
        serviceDefinitions.forEach(serviceDefinition ->
                createClientServicesMap(serviceDefinition, clientServices));
        Collection<ClientInfo> clientInfosCollection = ProtoJsonHelper.extractFromJsonArray(jsonParser.parse(clientsJson).getAsJsonArray(),
                ClientInfo.newBuilder());
        List<ClientInfo> clientInfoList = updateClientsData(clientInfosCollection, clientServices);
        if (CollectionUtils.isNotEmpty(clientInfoList)) {
            clientInfos.clear();
            clientInfos.addAll(clientInfoList);
        }
        buildClientInfoMap();
    }

    private void createClientServicesMap(ServiceDefinition serviceDefinition, Map<String, Set<ServiceDefinition>> clientServices) {
        serviceDefinition.getClientNamesList()
                .forEach(clientName ->
                        clientServices.computeIfAbsent(clientName, k -> new HashSet<>()).add(serviceDefinition));
    }

    private List<ClientInfo> updateClientsData(Collection<ClientInfo> clientInfosCollection, Map<String, Set<ServiceDefinition>> clientsToServicesMap) {
        List<ClientInfo> clientInfoList = new ArrayList<>();
        try {
            for (ClientInfo clientInfo : clientInfosCollection) {
                ClientInfo.Builder builder = clientInfo.toBuilder();
                LOGGER.info("Using credentials directory pattern {} to determine the credentials folder", credentialsDirectoryPattern);
                if (StringUtils.isEmpty(credentialsDirectory)) {
                    credentialsDirectory = credentialsDirectoryPattern.replace("XXX", AppConstants.ENVIRONMENT).trim();
                }
                Path credentialsFileAbsPath = Paths.get(credentialsDirectory, clientInfo.getCredentialsFileName());
                LOGGER.info("Using credentials file {} from {} dir for authentication.", credentialsFileAbsPath.getFileName(), credentialsDirectory);
                // using dummy base64 encoded credentials for insecure connection
                builder.setAuthMetadata(overrideFileDecryption ? DEFAULT_AUTH_DATA
                        : fileDecrypterService.decrypt(credentialsFileAbsPath.toFile()));
                builder.addAllEntityService(createEntityServicesFromServiceDefinition(clientsToServicesMap.get(clientInfo.getClientName())));
                clientInfoList.add(builder.build());
            }
        } catch (DecryptionException ex) {
            LOGGER.error("Failed to parse client info!", ex);
        }
        return clientInfoList;
    }

    private List<EntityService> createEntityServicesFromServiceDefinition(Set<ServiceDefinition> serviceDefinitions) {
        if (CollectionUtils.isEmpty(serviceDefinitions)) {
            return Collections.emptyList();
        }
        return serviceDefinitions.stream().map(this::buildEntityService).collect(Collectors.toList());
    }

    private EntityService buildEntityService(ServiceDefinition serviceDefinition) {
        return EntityService.newBuilder()
                .addAllEntityType(serviceDefinition.getEntityTypesList())
                .setServiceName(serviceDefinition.getServiceName())
                .addAllRequiredEntityType(serviceDefinition.getRequiredEntityTypesList())
                .build();
    }

    private void  buildClientInfoMap() {
        for(ClientInfo clientInfo : getAllClients()){
            List<EntityService> services = clientInfo.getEntityServiceList();
            for (EntityService entityService : services) {
                List<ClientInfo> clientList = serviceToClientMap.get(entityService.getServiceName());
                if (clientList == null) clientList = new ArrayList<>();
                if (!clientList.contains(clientInfo)) {
                    clientList.add(clientInfo);
                }
                serviceToClientMap.put(entityService.getServiceName(), clientList);
            }
        }
    }

    @Override
    public ClientInfo getClientById(String clientId) {
        return getClient(client -> client.getClientId().equals(clientId),
                () -> new IllegalArgumentException("No client found for id:" + clientId));
    }

    @Override
    public ClientInfo getClientByName(String clientName) {
        return getClient(client -> client.getClientName().equals(clientName),
                () -> new IllegalArgumentException("No client found for name:" + clientName));
    }

    private ClientInfo getClient(Predicate<ClientInfo> filterPredicate, Supplier<IllegalArgumentException> exceptionSupplier) {
        return clientInfos.stream()
                .filter(filterPredicate)
                .findFirst()
                .orElseThrow(exceptionSupplier);
    }

    @Override
    public List<ClientInfo> getAllClients() {
        return this.clientInfos;
    }

    @Override
    public Map<String, List<ClientInfo>> getServiceToClientMap() {
        return this.serviceToClientMap;
    }

    @Override
    public List<ClientInfo> getInvestmentClients() {
        return ListUtils.emptyIfNull(this.serviceToClientMap.get(ServiceEnum.INVESTMENTS.getServiceName()));
    }

    @Override
    public List<ClientInfo> getCRMClients() {
        return ListUtils.emptyIfNull(this.serviceToClientMap.get(ServiceEnum.CRM.getServiceName()));
    }
}
