package com.bfm.aap.pmdx.hub.service.entity;

import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.util.Pair;
import com.google.protobuf.Empty;
import eFrontProtobuf.PingServiceGrpc;
import eFrontProtobuf.PingServiceOuterClass;
import io.grpc.ManagedChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;


@Service
// MC: Deprecated because this has nothing to with the entity processing we use for handling entities we receive from eFront systems
// This is illustrated by not having a suitable EntityType to pass to the constructor and the fact that there is no suitable
// implementation to provide for the getEntityGuid method.
@Deprecated
public class EfrontPingClient extends BaseServiceClient<PingServiceOuterClass.PingReply, PingServiceGrpc.PingServiceBlockingStub> {

    private static final Logger LOGGER = LoggerFactory.getLogger(EfrontPingClient.class);

    @Autowired
    public EfrontPingClient(ManagedChannel channel) {
        super(channel, "EFrontPingClient", null, EntityType.ASSET, null);
        this.serviceStub = PingServiceGrpc.newBlockingStub(channel);
    }

    @Override
    Iterator<PingServiceOuterClass.PingReply> initiateSingleBlockingRequest(long sinceTime, ClientInfo client, InvestUtils.DataSource dataSource) {
        LOGGER.info("Initiating gprc request for pingAsStream..");
        return ((PingServiceGrpc.PingServiceBlockingStub)serviceStub).pingAsStream(Empty.newBuilder().build());
    }

    @Override
    String getEntityGuid(PingServiceOuterClass.PingReply entity) {
        return null;
    }

    @Override
    protected Pair<Set<String>, Long> processMessages(Iterator<PingServiceOuterClass.PingReply> messages, long sinceTime, String clientName) {
        Set<String> pingReply = new HashSet<>();
        while(messages.hasNext()){
            PingServiceOuterClass.PingReply reply = messages.next();
            pingReply.add(reply.getMessage());
        }
        return Pair.of(pingReply, sinceTime);
    }
}
