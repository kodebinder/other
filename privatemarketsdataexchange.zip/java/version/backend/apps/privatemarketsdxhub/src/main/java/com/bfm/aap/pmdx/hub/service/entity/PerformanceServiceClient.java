package com.bfm.aap.pmdx.hub.service.entity;

import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.pmdx.model.Performance;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.aap.pmdx.services.PerformanceRequest;
import com.bfm.aap.pmdx.services.PerformanceServiceGrpc;
import com.bfm.aap.pmdx.services.PerformanceSinceRequest;
import com.bfm.service.ServiceException;
import com.bfm.util.BFMTimestamp;
import com.google.protobuf.Timestamp;
import com.google.protobuf.util.Timestamps;
import io.grpc.ManagedChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import static com.bfm.util.BFMDateConstants.FMT_ISODateTime;
import static com.google.protobuf.util.Timestamps.fromMillis;

@Service
public class PerformanceServiceClient extends BaseServiceClient<Performance, PerformanceServiceGrpc.PerformanceServiceBlockingStub>
        implements EntityService<Performance, PerformanceRequest> {

    private static final Logger LOGGER = LoggerFactory.getLogger(PerformanceServiceClient.class);

    @Autowired
    public PerformanceServiceClient(ManagedChannel channel, AltsDataWorkspaceDAO altsDataWorkspaceDAO,
                              EntityProcessor<Performance> entityProcessor){
        super(channel, PerformanceServiceClient.class.getSimpleName(), altsDataWorkspaceDAO, EntityType.PERFORMANCE, entityProcessor);
        this.serviceStub = PerformanceServiceGrpc.newBlockingStub(channel);
    }

    @Override
    @RecordStats(metricName = "PerformanceService_getPerformancesSince", timer = true)
    Iterator<Performance> initiateSingleBlockingRequest(long sinceTime, ClientInfo clientInfo, InvestUtils.DataSource dataSource) {
        Timestamp sinceTimeTs = fromMillis(sinceTime);
        BFMTimestamp sinceTimeBfm = new BFMTimestamp(sinceTime, TimeUnit.MILLISECONDS);
        LOGGER.info("Initiating gprc request for getPerformanceSince for client: {} with localtime {}, GMT time:{}",
                clientInfo.getClientName(), sinceTimeBfm.toBFMDateTime().fmt(FMT_ISODateTime), Timestamps.toString(sinceTimeTs));
        PerformanceSinceRequest request = PerformanceSinceRequest.newBuilder().setTimestamp(sinceTimeTs).build();
        return ((PerformanceServiceGrpc.PerformanceServiceBlockingStub) getStubWithInterceptor(clientInfo)).getPerformanceSince(request);
    }

    /**
     *  Get single entity via unary grpc call.
     * @param entityRequest
     * @return
     * @throws ServiceException
     */
    @Override
    @RecordStats(metricName = "PerformanceService_getPerformance", timer = true)
    public Performance getEntity(PerformanceRequest entityRequest) {
        try {
            LOGGER.info("Processing single entity request for {}", entityRequest);
            Performance performance = serviceStub
                    .withDeadlineAfter(unaryCallTimeoutMillis, TimeUnit.MILLISECONDS)
                    .getPerformance(entityRequest);
            this.dataWorkspaceDAO.insertRecords(Collections.singletonList(performance));
            return performance;
        } catch (Exception e) {
            throw new ServiceException("Failed to get Performance:"+e.getMessage(), e);
        }
    }

    @Override
    String getEntityGuid(Performance entity) {
        return entity.getPerformanceId();
    }
}
