package com.bfm.aap.pmdx.hub.service.entity;

import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.pmdx.model.Instrument;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.aap.pmdx.services.InstrumentRequest;
import com.bfm.aap.pmdx.services.InstrumentServiceGrpc;
import com.bfm.aap.pmdx.services.InstrumentsSinceRequest;
import com.bfm.service.ServiceException;
import com.bfm.util.BFMTimestamp;
import com.google.protobuf.Timestamp;
import com.google.protobuf.util.Timestamps;
import io.grpc.ManagedChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import static com.bfm.util.BFMDateConstants.FMT_ISODateTime;
import static com.google.protobuf.util.Timestamps.fromMillis;

@Service
public class InstrumentServiceClient extends BaseServiceClient<Instrument, InstrumentServiceGrpc.InstrumentServiceBlockingStub>
        implements EntityService<Instrument, InstrumentRequest> {

    private static final Logger LOGGER = LoggerFactory.getLogger(InstrumentServiceClient.class);

    @Autowired
    public InstrumentServiceClient(ManagedChannel channel, AltsDataWorkspaceDAO altsDataWorkspaceDAO,
                              EntityProcessor<Instrument> entityProcessor){
        super(channel, InstrumentServiceClient.class.getSimpleName(), altsDataWorkspaceDAO, EntityType.INSTRUMENT, entityProcessor);
        this.serviceStub = InstrumentServiceGrpc.newBlockingStub(channel);
    }

    @Override
    @RecordStats(metricName = "instrumentService_getInstrumentsSince", timer = true)
    Iterator<Instrument> initiateSingleBlockingRequest(long sinceTime, ClientInfo clientInfo, InvestUtils.DataSource dataSource) {
        Timestamp sinceTimeTs = fromMillis(sinceTime);
        BFMTimestamp sinceTimeBfm = new BFMTimestamp(sinceTime, TimeUnit.MILLISECONDS);
        LOGGER.info("Initiating gprc request for getInstrumentsSince for client: {} with localtime {}, GMT time:{}",
                clientInfo.getClientName(), sinceTimeBfm.toBFMDateTime().fmt(FMT_ISODateTime), Timestamps.toString(sinceTimeTs));
        InstrumentsSinceRequest.Builder requestBuilder = InstrumentsSinceRequest.newBuilder();
        requestBuilder.setTimestamp(sinceTimeTs).build();
        if(null != dataSource){
            requestBuilder.setDataSource(dataSource);
        }
        return ((InstrumentServiceGrpc.InstrumentServiceBlockingStub) getStubWithInterceptor(clientInfo)).getInstrumentsSince(requestBuilder.build());
    }

    /**
     *  Get single entity via unary grpc call.
     * @param entityRequest
     * @return
     * @throws ServiceException
     */
    @Override
    @RecordStats(metricName = "instrumentService_getInstrument", timer = true)
    public Instrument getEntity(InstrumentRequest entityRequest) {
        try {
            LOGGER.info("Processing single entity request for {}", entityRequest);
            Instrument instrument = serviceStub
                    .withDeadlineAfter(unaryCallTimeoutMillis, TimeUnit.MILLISECONDS)
                    .getInstrument(entityRequest);
            this.dataWorkspaceDAO.insertRecords(Collections.singletonList(instrument));
            return instrument;
        } catch (Exception e) {
            throw new ServiceException("Failed to get Instrument:"+e.getMessage(), e);
        }
    }

    @Override
    String getEntityGuid(Instrument entity) {
        return entity.getAssetId();
    }
}
