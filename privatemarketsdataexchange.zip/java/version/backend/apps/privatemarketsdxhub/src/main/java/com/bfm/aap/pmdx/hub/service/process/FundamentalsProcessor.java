package com.bfm.aap.pmdx.hub.service.process;

import com.bfm.aap.pmdx.model.Fundamentals;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.google.protobuf.util.Timestamps;
import org.springframework.stereotype.Service;

@Service
public class FundamentalsProcessor extends EntityProcessor<Fundamentals> {

    @Override
    public long getEntityEpochOriginTime(Fundamentals entity) {
        return Timestamps.toMillis(entity.getEntityInfo().getOriginTimestamp());
    }

    @Override
    Fundamentals updatePrimaryFlag(Fundamentals entity, boolean isPrimary) {
        Fundamentals.Builder fundamentalsBuilder = Fundamentals.newBuilder(entity);
        fundamentalsBuilder.getEntityInfoBuilder().setPrimaryData(isPrimary);
        return fundamentalsBuilder.build();
    }

    @Override
    EntityInfo getEntityInfo(Fundamentals entity) {
        return entity.getEntityInfo();
    }

    @Override
    public String getGuid(Fundamentals entity) {
        return entity.getCompanyId();
    }

    @Override
    boolean isPrimary(Fundamentals entity) {
        return entity.getEntityInfo().getPrimaryData();
    }

    @Override
    public String getEntityType() {
        return Fundamentals.class.getSimpleName();
    }
}
