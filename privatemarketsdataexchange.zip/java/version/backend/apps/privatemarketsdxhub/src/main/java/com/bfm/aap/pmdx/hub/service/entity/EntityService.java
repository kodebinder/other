package com.bfm.aap.pmdx.hub.service.entity;

import com.bfm.aap.pmdx.hub.model.async.TaskResult;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.service.ServiceException;
import com.google.protobuf.Message;

import java.util.Set;

public interface EntityService<T extends Message, R extends Message> {

    /**
     * Get single entity via unary grpc call.
     *
     * @param entityRequest
     * @return
     * @throws ServiceException
     */
    T getEntity(R entityRequest);

    /**
     * Fetch and return the results from the gRPC service for the given sinceTime and client
     * Any failed entities will be logged and ignored, only successful guids will be returned.
     *
     * @param sinceTime
     * @param client
     * @return
     */
    // MC: TODO: The signature of this method is incorrect. The remote call returns objects.
    // Converting the objects to their IDs for processing is a separate step. This method signature should return
    // a Collection of objects of type T.
    TaskResult<Set<String>> fetchEntitiesSince(long sinceTime, ClientInfo client, InvestUtils.DataSource dataSource);
}
