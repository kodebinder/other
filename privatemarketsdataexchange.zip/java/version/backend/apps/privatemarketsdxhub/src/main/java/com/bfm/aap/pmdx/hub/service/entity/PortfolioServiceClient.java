package com.bfm.aap.pmdx.hub.service.entity;

import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.pmdx.model.Portfolio;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.aap.pmdx.services.PortfolioRequest;
import com.bfm.aap.pmdx.services.PortfolioServiceGrpc;
import com.bfm.aap.pmdx.services.PortfoliosSinceRequest;
import com.bfm.service.ServiceException;
import com.google.protobuf.Timestamp;
import com.google.protobuf.util.Timestamps;
import io.grpc.ManagedChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import static com.google.protobuf.util.Timestamps.fromMillis;

@Service
public class PortfolioServiceClient extends BaseServiceClient<Portfolio, PortfolioServiceGrpc.PortfolioServiceBlockingStub>
        implements EntityService<Portfolio, PortfolioRequest> {

    private static final Logger LOGGER = LoggerFactory.getLogger(PortfolioServiceClient.class);

    @Autowired
    public PortfolioServiceClient(ManagedChannel channel, AltsDataWorkspaceDAO dataWorkspaceDAO,
                                  EntityProcessor<Portfolio> entityProcessor) {
        super(channel, PortfolioServiceClient.class.getSimpleName(), dataWorkspaceDAO, EntityType.PORTFOLIO, entityProcessor);
        this.serviceStub = PortfolioServiceGrpc.newBlockingStub(channel);
    }

    @Override
    @RecordStats(metricName = "portfolioService_getPortfoliosSince", timer = true)
    Iterator<Portfolio> initiateSingleBlockingRequest(long sinceTime, ClientInfo client, InvestUtils.DataSource dataSource) {
        Timestamp sinceTimeTs = fromMillis(sinceTime);
        LOGGER.info("Initiating gprc request for getPortfoliosSince for client:{} with time {}",
                client.getClientName(), Timestamps.toString(sinceTimeTs));
        PortfoliosSinceRequest request = PortfoliosSinceRequest.newBuilder().setTimestamp(sinceTimeTs).build();
        return ((PortfolioServiceGrpc.PortfolioServiceBlockingStub) getStubWithInterceptor(client)).getPortfoliosSince(request);
    }

    /**
     * Get single entity via unary grpc call.
     * @param entityRequest
     * @return
     * @throws ServiceException
     */
    @Override
    @RecordStats(metricName = "portfolioService_getPortfolio", timer = true)
    public Portfolio getEntity(PortfolioRequest entityRequest) {
        try {
            LOGGER.info("Processing single entity request for {}", entityRequest);
            Portfolio portfolio = serviceStub
                    .withDeadlineAfter(unaryCallTimeoutMillis, TimeUnit.MILLISECONDS)
                    .getPortfolio(entityRequest);
            this.dataWorkspaceDAO.insertRecords(Collections.singletonList(portfolio));
            return portfolio;
        } catch (Exception e) {
            throw new ServiceException( "Failed to get Portfolio:"+e.getMessage(), e);
        }
    }

    @Override
    String getEntityGuid(Portfolio entity) {
        return entity.getPortfolioId();
    }
}
