package com.bfm.aap.pmdx.hub.service.entity;

import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.pmdx.model.Transaction;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.aap.pmdx.services.TransactionRequest;
import com.bfm.aap.pmdx.services.TransactionServiceGrpc;
import com.bfm.aap.pmdx.services.TransactionsSinceRequest;
import com.bfm.service.ServiceException;
import com.bfm.util.BFMTimestamp;
import com.google.protobuf.Timestamp;
import com.google.protobuf.util.Timestamps;
import io.grpc.ManagedChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import static com.bfm.util.BFMDateConstants.FMT_ISODateTime;
import static com.google.protobuf.util.Timestamps.fromMillis;

@Service
public class TransactionsServiceClient extends BaseServiceClient<Transaction, TransactionServiceGrpc.TransactionServiceBlockingStub> implements EntityService<Transaction, TransactionRequest> {
    private static final Logger LOGGER = LoggerFactory.getLogger(TransactionsServiceClient.class);

    @Autowired
    public TransactionsServiceClient(ManagedChannel channel, AltsDataWorkspaceDAO altsDataWorkspaceDAO,
                                     EntityProcessor<Transaction> entityProcessor){
        super(channel, TransactionsServiceClient.class.getSimpleName(), altsDataWorkspaceDAO, EntityType.TRANSACTION, entityProcessor);
        this.serviceStub = TransactionServiceGrpc.newBlockingStub(channel);
    }

    @Override
    @RecordStats(metricName = "TransactionService_getTransactionSince", timer = true)
    Iterator<Transaction> initiateSingleBlockingRequest(long sinceTime, ClientInfo clientInfo, InvestUtils.DataSource dataSource) {
        Timestamp sinceTimeTs = fromMillis(sinceTime);
        BFMTimestamp sinceTimeBfm = new BFMTimestamp(sinceTime, TimeUnit.MILLISECONDS);
        LOGGER.info("Initiating gprc request for getTransactionSince for client: {} with localtime {}, GMT time:{}",
                clientInfo.getClientName(), sinceTimeBfm.toBFMDateTime().fmt(FMT_ISODateTime), Timestamps.toString(sinceTimeTs));
        TransactionsSinceRequest.Builder requestBuilder = TransactionsSinceRequest.newBuilder();
        requestBuilder.setTimestamp(sinceTimeTs).build();
        if(null != dataSource){
            requestBuilder.setDataSource(dataSource);
        }
        return ((TransactionServiceGrpc.TransactionServiceBlockingStub) getStubWithInterceptor(clientInfo)).getTransactionsSince(requestBuilder.build());
    }

    /**
     * Get single entity via unary grpc call.
     * @param entityRequest
     * @return
     * @throws ServiceException
     */
    @Override
    @RecordStats(metricName = "TransactionService_getTransaction", timer = true)
    public Transaction getEntity(TransactionRequest entityRequest) {
        try {
            LOGGER.info("Processing single entity request for {}", entityRequest);
            Transaction Transaction = serviceStub
                    .withDeadlineAfter(unaryCallTimeoutMillis, TimeUnit.MILLISECONDS)
                    .getTransaction(entityRequest);
            this.dataWorkspaceDAO.insertRecords(Collections.singletonList(Transaction));
            return Transaction;
        } catch (Exception e) {
            throw new ServiceException( "Failed to get Transaction:" + e.getMessage(), e);
        }
    }

    @Override
    String getEntityGuid(Transaction entity) {
        return entity.getGuid();
    }
}
