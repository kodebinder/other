package com.bfm.aap.pmdx.hub.service.entity;

import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.pmdx.model.BankAccount;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.aap.pmdx.services.BankAccountRequest;
import com.bfm.aap.pmdx.services.BankAccountServiceGrpc;
import com.bfm.aap.pmdx.services.BankAccountsSinceRequest;
import com.bfm.service.ServiceException;
import com.bfm.util.BFMTimestamp;
import com.google.protobuf.Timestamp;
import com.google.protobuf.util.Timestamps;
import io.grpc.ManagedChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import static com.bfm.util.BFMDateConstants.FMT_ISODateTime;
import static com.google.protobuf.util.Timestamps.fromMillis;

@Service
public class BankAccountServiceClient extends BaseServiceClient<BankAccount, BankAccountServiceGrpc.BankAccountServiceBlockingStub>
       implements EntityService<BankAccount, BankAccountRequest> {

    private static final Logger LOGGER = LoggerFactory.getLogger(BankAccountServiceClient.class);

    @Autowired
    public BankAccountServiceClient(ManagedChannel channel, AltsDataWorkspaceDAO altsDataWorkspaceDAO,
                                    EntityProcessor<BankAccount> entityProcessor){
        super(channel, BankAccountServiceClient.class.getSimpleName(), altsDataWorkspaceDAO, EntityType.BANK_ACCOUNT, entityProcessor);
        this.serviceStub = BankAccountServiceGrpc.newBlockingStub(channel);
    }

    @Override
    @RecordStats(metricName = "bankAccountService_getBankAccountsSince", timer = true)
    Iterator<BankAccount> initiateSingleBlockingRequest(long sinceTime, ClientInfo clientInfo, InvestUtils.DataSource dataSource) {
        Timestamp sinceTimeTs = fromMillis(sinceTime);
        BFMTimestamp sinceTimeBfm = new BFMTimestamp(sinceTime, TimeUnit.MILLISECONDS);
        LOGGER.info("Initiating gprc request for getBankAccountsSince for client: {} with localtime {}, GMT time:{}",
                clientInfo.getClientName(), sinceTimeBfm.toBFMDateTime().fmt(FMT_ISODateTime), Timestamps.toString(sinceTimeTs));
        BankAccountsSinceRequest request = BankAccountsSinceRequest.newBuilder().setTimestamp(sinceTimeTs).build();
        return ((BankAccountServiceGrpc.BankAccountServiceBlockingStub) getStubWithInterceptor(clientInfo)).getBankAccountsSince(request);

    }

    @Override
    String getEntityGuid(BankAccount entity) {
        return  entity.getEntityBankAccountId();
    }

    @Override
    @RecordStats(metricName = "bankAccountService_getBankAccount", timer = true)
    public BankAccount getEntity(BankAccountRequest entityRequest) {
        try {
            LOGGER.info("Processing single entity request for {}", entityRequest);
            BankAccount bankAccount = serviceStub
                    .withDeadlineAfter(unaryCallTimeoutMillis, TimeUnit.MILLISECONDS)
                    .getBankAccount(entityRequest);
            this.dataWorkspaceDAO.insertRecords(Collections.singletonList(bankAccount));
            return bankAccount;
        } catch (Exception e) {
            throw new ServiceException("Failed to get bankAccount:"+e.getMessage(), e);
        }
    }
}
