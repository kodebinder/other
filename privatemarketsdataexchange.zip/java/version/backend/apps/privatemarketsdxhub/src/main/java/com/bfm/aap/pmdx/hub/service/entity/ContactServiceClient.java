package com.bfm.aap.pmdx.hub.service.entity;

import java.util.Set;

import com.google.protobuf.Message;
import io.grpc.ManagedChannel;
import io.grpc.stub.AbstractStub;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bfm.aap.pmdx.hub.model.async.TaskResult;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.ContactResponse;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.aap.pmdx.services.ContactRequest;
import com.bfm.aap.pmdx.services.ContactServiceGrpc;
import com.bfm.aap.pmdx.services.ContactServiceGrpc.ContactServiceBlockingStub;
import com.bfm.service.ServiceException;

import static com.google.protobuf.util.Timestamps.fromMillis;

@Service
public class ContactServiceClient implements EntityService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ContactServiceClient.class);
    private final RPCServiceClient rpcServiceClient;
    private final EntityProcessor<Contact> contactEntityProcessor;
    private final AbstractStub<ContactServiceBlockingStub> contactServiceStub;

    @Autowired
    public ContactServiceClient(RPCServiceClient rpcServiceClient, ManagedChannel channel, EntityProcessor<Contact> entityProcessor) {
        this.rpcServiceClient = rpcServiceClient;
        this.contactEntityProcessor = entityProcessor;
        this.contactServiceStub = ContactServiceGrpc.newBlockingStub(channel);
    }

    @Override
    public Message getEntity(Message entityRequest) {
        throw new UnsupportedOperationException();
    }

    @Override
    @RecordStats(metricName = "ContactService_getContactSince", timer = true)
    public TaskResult<Set<String>> fetchEntitiesSince(long lastSuccessfulTime, ClientInfo clientInfo, InvestUtils.DataSource dataSource) {
        ContactRequest contactRequest = ContactRequest.newBuilder().setTimestamp(fromMillis(lastSuccessfulTime)).build();

        return rpcServiceClient.doFetchSince(ContactServiceBlockingStub::getContactSince, contactServiceStub, contactRequest, contactEntityProcessor, clientInfo, lastSuccessfulTime);
    }

    public String updateContact(ContactRequest contactRequest, ClientInfo clientInfo, Integer crmEntityId) {
        String entityId = StringUtils.EMPTY;
        LOGGER.info("Processing Contact entity request for update");
        try {
            ContactServiceBlockingStub contactServiceBlockingStub = rpcServiceClient.getStubWithInterceptor(contactServiceStub, clientInfo);
            ContactResponse response = contactServiceBlockingStub.updateContact(contactRequest);
            LOGGER.info("Contact entity {} {}", crmEntityId, response.getIsUpdated() ? "successfully updated." : "failed to update.");
            if (response.getIsUpdated()) {
                entityId = response.getData().getContactId();
            } else {
                LOGGER.info("Contact request : {}", contactRequest);
                LOGGER.info("Contact response : {}", response);
            }
            return entityId;
        } catch (Exception e) {
            throw new ServiceException("Contact gRPC request failed with status: " + e.getMessage(), e);
        }
    }
}