package com.bfm.aap.pmdx.hub.service.process;

import com.google.protobuf.util.Timestamps;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.bfm.aap.pmdx.model.ShareClass;
import com.bfm.aap.pmdx.model.util.EntityInfo;

@Service
public class ShareClassProcessor extends EntityProcessor<ShareClass> {

    @Override
    public long getEntityEpochOriginTime(ShareClass entity) {
        return Timestamps.toMillis(entity.getEntityInfo().getOriginTimestamp());
    }

    @Override
    ShareClass updatePrimaryFlag(ShareClass entity, boolean isPrimary) {
        ShareClass.Builder crmShareClassBuilder = ShareClass.newBuilder(entity);
        crmShareClassBuilder.getEntityInfoBuilder().setPrimaryData(isPrimary);
        return crmShareClassBuilder.build();
    }

    @Override
    EntityInfo getEntityInfo(ShareClass entity) {
        return entity.getEntityInfo();
    }

    @Override
    public String getGuid(ShareClass entity) {
        return StringUtils.EMPTY;
    }

    @Override
    public String getEntityType() {
        return StringUtils.EMPTY;
    }

    @Override
    boolean isPrimary(ShareClass entity) {
        return entity.getEntityInfo().getPrimaryData();
    }
}
