package com.bfm.aap.pmdx.hub.repository;

import com.bfm.aap.pmdx.hub.model.EntityTimestampGUID;
import com.bfm.aap.pmdx.hub.util.AppConstants;
import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.pmdx.model.Asset;
import com.bfm.aap.pmdx.model.BankAccount;
import com.bfm.aap.pmdx.model.BankOperation;
import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.Fundamentals;
import com.bfm.aap.pmdx.model.Instrument;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.Performance;
import com.bfm.aap.pmdx.model.Portfolio;
import com.bfm.aap.pmdx.model.Position;
import com.bfm.aap.pmdx.model.ShareClass;
import com.bfm.aap.pmdx.model.Transaction;
import com.bfm.aap.pmdx.model.User;
import com.bfm.aap.pmdx.model.util.CompanyUtil;
import com.bfm.aap.pmdx.model.util.ContactUtil;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.FundamentalsUtil;
import com.bfm.aap.pmdx.model.util.InvestorUtil;
import com.bfm.aap.pmdx.model.util.ModelVersion;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.model.util.PerformanceUtil;
import com.bfm.aap.pmdx.model.util.PositionUtil;
import com.bfm.aap.pmdx.model.util.TransactionsUtil;
import com.bfm.aap.pmdx.model.util.UserUtil;
import com.bfm.aap.pmdx.utils.adl.ADLRetryUtil;
import com.bfm.adl.ADLException;
import com.bfm.adl.ADLObject;
import com.bfm.adl.ADLQuery;
import com.bfm.adl.ADLRepository;
import com.bfm.adl.ADLRepositoryFactory;
import com.bfm.adl.ADLResultSet;
import com.bfm.util.BFMTimestamp;
import com.bfm.util.Interval;
import com.google.common.collect.Lists;
import com.google.protobuf.Message;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static com.bfm.aap.pmdx.hub.repository.ADLConstants.APP_NAME;
import static com.bfm.aap.pmdx.hub.repository.ADLConstants.CLIENT;
import static com.bfm.aap.pmdx.hub.repository.ADLConstants.DATA_PRIMARY_INDEX;
import static com.bfm.aap.pmdx.hub.repository.ADLConstants.DATA_SECONDARY_INDEX;
import static com.bfm.aap.pmdx.hub.repository.ADLConstants.EDX_DATA;
import static com.bfm.aap.pmdx.hub.repository.ADLConstants.EMPTY_BYTES;
import static com.bfm.aap.pmdx.hub.repository.ADLConstants.ENTITY_TYPE;
import static com.bfm.aap.pmdx.hub.repository.ADLConstants.GUID;
import static com.bfm.aap.pmdx.hub.repository.ADLConstants.LAST_MODIFIED_TIME;
import static com.bfm.aap.pmdx.hub.repository.ADLConstants.NETWORK_MODE;
import static com.bfm.aap.pmdx.hub.repository.ADLConstants.REPO_NAME;
import static com.bfm.aap.pmdx.hub.repository.ADLConstants.SOURCE;
import static com.bfm.aap.pmdx.hub.repository.ADLConstants.VERSION;
import static com.bfm.aap.pmdx.hub.repository.ADLConstants.VERSION_1;
import static com.bfm.aap.pmdx.hub.util.AppConstants.ENTITY_STATE;
import static com.bfm.util.BFMDateConstants.FMT_ISODateTime;

@Repository
public class AltsDataWorkspaceDAOImpl implements AltsDataWorkspaceDAO {

    private static final Logger LOGGER = LoggerFactory.getLogger(AltsDataWorkspaceDAOImpl.class);

    public static final String UNDEFINED = "UNDEFINED";
    public static final String EFRONT = "EFRONT";
    public static final String SUCCESSFULLY_PERSISTED_ENTITY_WITH_GUID = "successfully persisted entity with guid: {}";
    private static final int WINDOW = -600000;

    private final ADLRepository dataRepo;

    @Value("${adl.batch-size:50}")
    private int adlBatchSize;

    @Value("${adl.retry-count:1}")
    private int adlRetryCount;

    public AltsDataWorkspaceDAOImpl() throws ADLException {
        dataRepo = ADLRepositoryFactory.init(REPO_NAME, APP_NAME);
    }

    @Override
    @RecordStats
    public long fetchLastSuccessfulTime(NetworkMode networkMode, EntityType entityType) throws ADLException {
        return fetchLastSuccessfulTime(networkMode, EntityTimestampGUID.getGUIDFromEntity(ENTITY_STATE, entityType));
    }

    @Override
    @RecordStats
    public long fetchLastSuccessfulTime(NetworkMode networkMode, String guid) throws ADLException {
        ADLQuery query = dataRepo.createQuery(DATA_PRIMARY_INDEX);
        query.addEqualsConstraint(GUID, guid);
        query.addEqualsConstraint(NETWORK_MODE, ENTITY_STATE.toString());

        ADLResultSet<ADLObject> rs = ADLRetryUtil.getWithRetries(adlRetryCount, () -> dataRepo.get(query));
        if (rs.hasNext()) {
            ADLObject obj = rs.getNext();
            BFMTimestamp lastSuccessfulTime = obj.getTimestamp(LAST_MODIFIED_TIME);
            return lastSuccessfulTime.getValue(TimeUnit.MILLISECONDS);
        } else {
            LOGGER.error("No record found to fetch lastSuccessfulTime for mode:{}, guid:{}", networkMode.name(), guid);
            return Instant.EPOCH.toEpochMilli();
        }
    }

    @Override
    @RecordStats
    public void updateLastSuccessfulTime(long epochTime, NetworkMode networkColor, String entityType, String clientName, String guid) throws ADLException {
        BFMTimestamp currentEpochTime = new BFMTimestamp(epochTime, TimeUnit.MILLISECONDS);
        LOGGER.info("Updating last successful time for entityType:{} networkMode:{} clientName:{} lastSuccessfulTime: {}", entityType,
            networkColor.name(), clientName, currentEpochTime.toBFMDateTime().fmt(FMT_ISODateTime));
        ADLObject object = dataRepo.createObject();
        object.set(GUID, guid);
        object.set(NETWORK_MODE, ENTITY_STATE.name());
        object.set(LAST_MODIFIED_TIME, currentEpochTime);
        object.set(CLIENT, clientName);
        object.set(ENTITY_TYPE, entityType);
        object.set(VERSION, VERSION_1);
        object.set(EDX_DATA, EMPTY_BYTES);
        ADLRetryUtil.runWithRetries(adlRetryCount, () -> dataRepo.put(object));
    }

    @Override
    @RecordStats
    public <T extends Message> List<String> insertRecords(List<T> records) throws IOException {
        if (CollectionUtils.isEmpty(records))
            return Collections.emptyList();

        List<String> guids = new ArrayList<>(records.size());
        List<ADLObject> adlObjects = new ArrayList<>(records.size());

        for (T message : records) {
            ADLObject adlObject = getAdlObject(message);
            adlObjects.add(adlObject);
            try {
                guids.add(adlObject.getString(GUID));
            } catch (ADLException e) {
                LOGGER.error("failed to get GUID from adlObject:" + e.getMessage(), e);
            }
        }

        Set<String> failedUUIDs = new HashSet<>();
        persistADLObjects(adlObjects, dataRepo, adlBatchSize, failedUUIDs);
        if (!failedUUIDs.isEmpty()) {
            throw new IOException("Batch insertion to ADL - AltsDataWorkspace has failed! Check prior exceptions in log!");
        }
        return guids;
    }

    @Override
    @RecordStats(timer = true)
    public <T extends Message> String insertRecord(T entity) throws ADLException {
        ADLObject adlObject = getAdlObject(entity);
        ADLRetryUtil.runWithRetries(adlRetryCount, () -> dataRepo.put(adlObject));
        String guid = adlObject.getString(GUID);
        LOGGER.info(SUCCESSFULLY_PERSISTED_ENTITY_WITH_GUID, guid);
        return guid;
    }

    @Override
    public <T extends Message> String insertRecord(T entity, String source, String clientName) throws ADLException {
        ADLObject adlObject = getAdlObject(entity);
        adlObject.set(SOURCE, source);
        adlObject.set(CLIENT, clientName);
        ADLRetryUtil.runWithRetries(adlRetryCount, () -> dataRepo.put(adlObject));
        String guid = adlObject.getString(GUID);
        LOGGER.info(SUCCESSFULLY_PERSISTED_ENTITY_WITH_GUID, guid);
        return guid;
    }

    @Override
    public <T extends Message> boolean updateRecord(T entity, String source, String guid) throws ADLException {
        ADLObject adlObject = getAdlObject(entity);
        adlObject.set(SOURCE, source);
        adlObject.set(GUID, guid);
        ADLRetryUtil.runWithRetries(adlRetryCount, () -> dataRepo.put(adlObject));
        LOGGER.info(SUCCESSFULLY_PERSISTED_ENTITY_WITH_GUID, guid);
        return true;
    }

    @Override
    public ADLResultSet<ADLObject> fetchADLRecordInWindow(String source, String serverMode, EntityType entityType) throws ADLException {
        LOGGER.info("Received request with TimeStamp : {} , current serverMode : {} and entityType : {}", new BFMTimestamp(), serverMode, entityType);

        BFMTimestamp refTime = new BFMTimestamp();
        ADLQuery query = dataRepo.createQuery(DATA_SECONDARY_INDEX)
            .addEqualsConstraint(SOURCE, source)
            .addEqualsConstraint(NETWORK_MODE, serverMode)
            .addEqualsConstraint(ENTITY_TYPE, String.valueOf(entityType))
            .addRangeConstraint(LAST_MODIFIED_TIME, refTime.addTime(new Interval(WINDOW, TimeUnit.MILLISECONDS)), refTime);
        return dataRepo.get(query);
    }

    private <T extends Message> ADLObject getAdlObject(T message) {
        ADLObject adlObject = dataRepo.createObject();
        adlObject.set(NETWORK_MODE, AppConstants.NETWORK_MODE.name());
        adlObject.set(LAST_MODIFIED_TIME, new BFMTimestamp());
        adlObject.set(SOURCE, EFRONT);

        if (message instanceof Asset) {
            setAdditionalInfo(((Asset) message).getEntityInfo(), EntityType.ASSET, adlObject, message, ((Asset) message).getAssetId());
        } else if (message instanceof Portfolio) {
            setAdditionalInfo(((Portfolio) message).getEntityInfo(), EntityType.PORTFOLIO, adlObject, message, ((Portfolio) message).getPortfolioId());
        } else if (message instanceof Position) {
            Position.Builder builder = ((Position) message).toBuilder();
            String guid = PositionUtil.getPositionGuid(builder);
            setAdditionalInfo(builder.getEntityInfo(), EntityType.POSITION, adlObject, builder.setGuid(guid).build(), guid);
        } else if (message instanceof Performance) {
            setAdditionalInfo(((Performance) message).getEntityInfo(), EntityType.PERFORMANCE, adlObject, message, PerformanceUtil.getPerformanceGuid((Performance) message));
        } else if (message instanceof Fundamentals) {
            setAdditionalInfo(((Fundamentals) message).getEntityInfo(), EntityType.FUNDAMENTALS, adlObject, message, FundamentalsUtil.getFundamentalsGuid((Fundamentals) message));
        } else if (message instanceof Transaction) {
            setAdditionalInfo(((Transaction) message).getEntityInfo(), EntityType.TRANSACTION, adlObject, message, TransactionsUtil.getTransactionGuid((Transaction) message));
        } else if (message instanceof Instrument) {
            setAdditionalInfo(((Instrument) message).getEntityInfo(), EntityType.INSTRUMENT, adlObject, message, ((Instrument) message).getAssetId());
        } else if (message instanceof BankAccount) {
            setAdditionalInfo(((BankAccount) message).getEntityInfo(), EntityType.BANK_ACCOUNT, adlObject, message, ((BankAccount) message).getEntityBankAccountId());
        } else if (message instanceof BankOperation) {
            setAdditionalInfo(((BankOperation) message).getEntityInfo(), EntityType.BANK_OPERATION, adlObject, message, ((BankOperation) message).getBankOperationId());
        } else if (message instanceof User) {
            setAdditionalInfo(((User) message).getEntityInfo(), EntityType.USER, adlObject, message, UserUtil.getUserGuid((User) message));
        } else if (message instanceof Contact) {
            setAdditionalInfo(((Contact) message).getEntityInfo(), EntityType.CONTACT, adlObject, message, ContactUtil.getContactGuid((Contact) message));
        } else if (message instanceof Company) {
            setAdditionalInfo(((Company) message).getEntityInfo(), EntityType.COMPANY, adlObject, message, CompanyUtil.getCompanyGuid((Company) message));
        } else if (message instanceof Investor) {
            setAdditionalInfo(((Investor) message).getEntityInfo(), EntityType.INVESTOR, adlObject, message, InvestorUtil.getInvestorGuid((Investor) message));
        } else if (message instanceof ShareClass) {
            setAdditionalInfo(((ShareClass) message).getEntityInfo(), EntityType.SHARECLASS, adlObject, message, ((ShareClass) message).getShareclassId());
        } else
            throw new IllegalArgumentException("Invalid entity type!");

        return adlObject;
    }

    private <T extends Message> void setAdditionalInfo(EntityInfo entityInfo, EntityType entityType, ADLObject adlObject, T message, String guid) {
        adlObject.set(CLIENT, entityInfo.getClientName());
        adlObject.set(ENTITY_TYPE, entityType.name());
        adlObject.set(EDX_DATA, message.toByteArray());
        adlObject.set(GUID, guid);
        String version = entityInfo.getModelVersion();
        version = (version.equals(UNDEFINED) || StringUtils.isEmpty(version)) ? ModelVersion.getVersion() : version;
        adlObject.set(VERSION, version);
    }

    private void persistADLObjects(List<ADLObject> adlObjects, ADLRepository repository, int batchSize, Set<String> failedDealIds) {
        Lists.partition(adlObjects, batchSize)
            .forEach(adlObjectsSubList -> batchUpdate(repository, failedDealIds, adlObjectsSubList));
    }

    private void batchUpdate(ADLRepository repository, Set<String> failedDealIds, List<ADLObject> adlObjectsSubList) {
        //capture uuid in batch.
        List<String> uuids = adlObjectsSubList.stream()
            .map(adlObject -> {
                try {
                    return adlObject.getString(GUID);
                } catch (ADLException e) {
                    LOGGER.error("Failed to get UUID from adl object:" + e.getMessage(), e);
                    return null;
                }
            }).filter(Objects::nonNull).collect(Collectors.toList());

        //update the repo
        try {
            if (CollectionUtils.isNotEmpty(adlObjectsSubList))
                repository.put(adlObjectsSubList);
            LOGGER.info("batch update successful for batch of size {} with uuids : {}", uuids.size(), uuids);
        } catch (Exception e) {
            LOGGER.error("Failed to batch update: {}", e.getMessage(), e);
            LOGGER.info("batch update failed, size {} with uuids: {}", uuids.size(), uuids);
            failedDealIds.addAll(uuids);
        }
    }

}
