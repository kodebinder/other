package com.bfm.aap.pmdx.hub.model;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.StringJoiner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bfm.aap.pmdx.hub.util.AppConstants;
import com.bfm.util.BFMUtil;

public final class CertHelper {

	private static final Logger LOGGER = LoggerFactory.getLogger(CertHelper.class);
	private static final String CLIENT_WEB_SSL_LOCATION = "Client.WebSSL.Location";
	private static final String HYPHEN = "-";
	private static final String HUB = "hub";
	private static final String KEY_EXTENSION = ".key";
	private static final String CER_EXTENSION = ".cer";

	private static final String KEY_FILE_NAME = new StringJoiner(HYPHEN).add(AppConstants.ENVIRONMENT.toUpperCase())
		.add(HUB).add(AppConstants.SERVER_MODE.toLowerCase()).toString() + KEY_EXTENSION;
	private static final String CER_FILE_NAME = new StringJoiner(HYPHEN).add(AppConstants.ENVIRONMENT.toUpperCase())
		.add(HUB).add(AppConstants.SERVER_MODE.toLowerCase()).toString() + CER_EXTENSION;
	private static final String CRT_FILE_NAME = "HubParentChain.crt";
	private static final String BASE_PATH = BFMUtil.getBfmSystemToken(CLIENT_WEB_SSL_LOCATION);

	private CertHelper() {}

	public static Path getPrivateKeyPath() {
		Path path = Paths.get(BASE_PATH, KEY_FILE_NAME);
		LOGGER.info("Key file:{}", path.getFileName());
		return path;
	}

	public static Path getCertPath() {
		Path path = Paths.get(BASE_PATH, CER_FILE_NAME);
		LOGGER.info("Cert file:{}", path.getFileName());
		return path;
	}

	public static Path getCaPath() {
		Path path = Paths.get(BASE_PATH, CRT_FILE_NAME);
		LOGGER.info("Crt file:{}", path.getFileName());
		return path;
	}

}