package com.bfm.aap.pmdx.hub.service.entity;

import com.bfm.aap.pmdx.hub.model.async.TaskResult;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.pmdx.model.User;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.aap.pmdx.services.UserServiceGrpc;
import com.bfm.aap.pmdx.services.UserSinceRequest;
import com.google.protobuf.Message;
import io.grpc.ManagedChannel;
import io.grpc.stub.AbstractStub;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Set;

import static com.bfm.aap.pmdx.services.UserServiceGrpc.UserServiceBlockingStub;
import static com.google.protobuf.util.Timestamps.fromMillis;

@Service
public class UserServiceClient implements EntityService {

    private final RPCServiceClient rpcServiceClient;
    private final EntityProcessor<User> userEntityProcessor;
    private final AbstractStub<UserServiceBlockingStub> userServiceStub;

    @Autowired
    public UserServiceClient(RPCServiceClient rpcServiceClient, ManagedChannel channel, EntityProcessor<User> entityProcessor) {
        this.rpcServiceClient = rpcServiceClient;
        this.userEntityProcessor = entityProcessor;
        this.userServiceStub = UserServiceGrpc.newBlockingStub(channel);
    }

    @Override
    public Message getEntity(Message entityRequest) {
        throw new UnsupportedOperationException();
    }

    @Override
    @RecordStats(metricName = "UserService_getUserSince", timer = true)
    public TaskResult<Set<String>> fetchEntitiesSince(long lastSuccessfulTime, ClientInfo clientInfo, InvestUtils.DataSource dataSource) {
        UserSinceRequest userRequest = UserSinceRequest.newBuilder().setTimestamp(fromMillis(lastSuccessfulTime)).build();

        return rpcServiceClient.doFetchSince(UserServiceBlockingStub::getUserSince, userServiceStub, userRequest, userEntityProcessor, clientInfo, lastSuccessfulTime);
    }

}