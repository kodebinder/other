package com.bfm.aap.pmdx.hub.util;

import com.bfm.aap.pmdx.hub.model.EntityState;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.model.util.NetworkModeHelper;
import com.bfm.util.BFMTimestamp;
import com.bfm.util.BFMUtil;
import org.apache.commons.lang.StringUtils;

import java.util.StringJoiner;

import static com.bfm.util.BFMDateConstants.FMT_ISODateTime;

public final class AppConstants {

    public static final String APPLICATION_NAME = "PrivateMarketsDXHub";
    public static final String APP_SHORT_NAME = "PMDXHUB";
    public static final int NUM_WORKER_THREADS = 50;
    public static final String SERVER_MODE = System.getProperty("mode");
    public static final String ENV_NAME = System.getProperty("env.name");
    public static final String CLIENT_ABBREV = "ClientAbbrev";
    public static final String ENVIRONMENT = StringUtils.defaultString(BFMUtil.getBfmToken(CLIENT_ABBREV), AppConstants.ENV_NAME);
    public static final NetworkMode NETWORK_MODE = NetworkModeHelper.getNetworkModeFromString(SERVER_MODE);
    public static final EntityState ENTITY_STATE = EntityState.getState(NETWORK_MODE);
    public static final String TEST_ENV_NAMES = "DEV,TST,TSTBEN";
    public static final boolean IS_PRE_PROD_CLIENT = TEST_ENV_NAMES.contains(ENVIRONMENT);
    public static final Integer CRM_JOB_FREQUENCY = BFMUtil.getBfmSystemToken("PMDX_CRM_JOB_FREQ", 300000);
    public static final Integer INVESTMENT_JOB_FREQUENCY = BFMUtil.getBfmSystemToken("PMDX_INVESTMENTS_JOB_FREQ", 300000);

    public static final String GET_ENTITY_SINCE = "grpc_entities_processing_latency";

    public static final String UNDERSCORE_SEPARATOR = "_";
    public static final String ZK_DELIMITER = "/";

    public static final String ENTITY_TYPE_ALL = "ALL";
    public static final String SUCCESSFULLY = "successfully";
    public static final String FAILED = "failed";

    private static final String HOST = "EFRONT_DXPROVIDER_XXX_HOST";
    private static final String PORT = "EFRONT_DXPROVIDER_XXX_PORT";

    public static final boolean IS_TSGOPS = "tsgops".equalsIgnoreCase(BFMUtil.getUser());

    // will be different for network and environment: PMDXHUB_DEV_RED, PMDXHUB_BEN_BLUE
    public static final String PMDX_HUB_ID;
    public static final String INSTANCE_ID;
    public static final String HOST_TOKEN;
    public static final String PORT_TOKEN;

    public static final String ZKPATH_PARENT;

    private AppConstants() { }

    static {
        HOST_TOKEN = HOST.replace("XXX", NETWORK_MODE.name());
        PORT_TOKEN = PORT.replace("XXX", NETWORK_MODE.name());
        String environment = StringUtils.defaultString(BFMUtil.getBfmToken(CLIENT_ABBREV), AppConstants.ENV_NAME);
        StringJoiner joiner = new StringJoiner(UNDERSCORE_SEPARATOR)
                    .add(AppConstants.APP_SHORT_NAME)
                    .add(environment.toUpperCase())
                    .add(AppConstants.NETWORK_MODE.name());
        if (!IS_TSGOPS) {
            joiner.add(BFMUtil.getUser());
        }
        PMDX_HUB_ID = joiner.toString();
        BFMTimestamp startTime = new BFMTimestamp();
        INSTANCE_ID = PMDX_HUB_ID + UNDERSCORE_SEPARATOR + startTime.toBFMDateTime().fmt(FMT_ISODateTime);
        ZKPATH_PARENT = new StringBuffer(ZK_DELIMITER).append(PMDX_HUB_ID).toString();
    }
}
