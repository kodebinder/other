package com.bfm.aap.pmdx.hub.service.entity;

import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.pmdx.model.Transaction;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.aap.pmdx.services.HistoricalTransactionRequest;
import com.bfm.aap.pmdx.services.HistoricalTransactionsSinceRequest;
import com.bfm.aap.pmdx.services.HistoricalTransactionServiceGrpc;
import com.bfm.service.ServiceException;
import com.bfm.util.BFMTimestamp;
import com.google.protobuf.Timestamp;
import com.google.protobuf.util.Timestamps;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import io.grpc.ManagedChannel;
import java.util.Collections;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import static com.bfm.util.BFMDateConstants.FMT_ISODateTime;
import static com.google.protobuf.util.Timestamps.fromMillis;

@Service
public class HistoricalTransactionsServiceClient extends BaseServiceClient<Transaction, HistoricalTransactionServiceGrpc.HistoricalTransactionServiceBlockingStub>
        implements EntityService<Transaction, HistoricalTransactionRequest> {
    private static final Logger LOGGER = LoggerFactory.getLogger(HistoricalTransactionsServiceClient.class);

    @Autowired
    public HistoricalTransactionsServiceClient(ManagedChannel channel, AltsDataWorkspaceDAO altsDataWorkspaceDAO,
                                     EntityProcessor<Transaction> entityProcessor){
        super(channel, HistoricalTransactionsServiceClient.class.getSimpleName(), altsDataWorkspaceDAO, EntityType.HIST_TRANSACTION, entityProcessor);
        this.serviceStub = HistoricalTransactionServiceGrpc.newBlockingStub(channel);
    }

    @Override
    @RecordStats(metricName = "HistoricalTransactionService_getHistoricalTransactionsSince", timer = true)
    Iterator<Transaction> initiateSingleBlockingRequest(long sinceTime, ClientInfo clientInfo, InvestUtils.DataSource dataSource) {
        Timestamp sinceTimeTs = fromMillis(sinceTime);
        BFMTimestamp sinceTimeBfm = new BFMTimestamp(sinceTime, TimeUnit.MILLISECONDS);
        String localTime = sinceTimeBfm.toBFMDateTime().fmt(FMT_ISODateTime);
        String gmtTime = Timestamps.toString(sinceTimeTs);
        LOGGER.info("Initiating gprc request for getHistoricalTransactionsSince for client: {} with localtime {}, GMT time:{}",
                clientInfo.getClientName(), localTime, gmtTime);
        HistoricalTransactionsSinceRequest request = HistoricalTransactionsSinceRequest.newBuilder().setTimestamp(sinceTimeTs).build();
        return ((HistoricalTransactionServiceGrpc.HistoricalTransactionServiceBlockingStub) getStubWithInterceptor(clientInfo)).getHistoricalTransactionsSince(request);
    }

    /**
     * Get single entity via unary grpc call.
     * @param entityRequest
     * @return
     * @throws ServiceException
     */
    @Override
    @RecordStats(metricName = "HistoricalTransactionService_getHistoricalTransaction", timer = true)
    public Transaction getEntity(HistoricalTransactionRequest entityRequest) {
        try {
            LOGGER.info("Processing single entity request for {}", entityRequest);
            Transaction transaction = serviceStub
                    .withDeadlineAfter(unaryCallTimeoutMillis, TimeUnit.MILLISECONDS)
                    .getHistoricalTransaction(entityRequest);
            this.dataWorkspaceDAO.insertRecords(Collections.singletonList(transaction));
            return transaction;
        } catch (Exception e) {
            throw new ServiceException( "Failed to get historical Transaction:" + e.getMessage(), e);
        }
    }

    @Override
    String getEntityGuid(Transaction entity) {
        return entity.getGuid();
    }

}
