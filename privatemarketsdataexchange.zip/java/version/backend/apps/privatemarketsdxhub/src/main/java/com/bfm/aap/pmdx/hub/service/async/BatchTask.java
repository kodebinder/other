package com.bfm.aap.pmdx.hub.service.async;

import com.bfm.aap.pmdx.hub.model.EntityServiceClientExecutor;
import com.bfm.aap.pmdx.hub.model.ExecutionStatus;
import com.bfm.aap.pmdx.hub.model.async.TaskResult;
import com.bfm.aap.pmdx.hub.repository.ClientInfoDAO;
import com.bfm.aap.pmdx.hub.service.entity.AssetServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.BankAccountServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.BankOperationServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.CompanyServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.ContactServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.FundamentalsServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.InstrumentServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.InvestorAccountServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.InvestorServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.PerformanceServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.PortfolioServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.PositionServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.ShareClassServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.TransactionsServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.UserServiceClient;
import com.bfm.aap.pmdx.hub.util.ServiceEnum;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.EntityService;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.aap.pmdx.transformer.util.TransformerClientServiceHelper;
import com.bfm.metric.StatCollectorMeterRegistry;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Preconditions;
import com.google.common.collect.Maps;
import com.google.protobuf.util.Timestamps;
import io.micrometer.core.instrument.Tag;
import io.micrometer.core.instrument.Tags;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.zookeeper.KeeperException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import static com.bfm.aap.pmdx.model.ModelConstants.ASSET_TYPE_NAME;
import static com.bfm.aap.pmdx.model.ModelConstants.BANK_ACCOUNT_TYPE_NAME;
import static com.bfm.aap.pmdx.model.ModelConstants.BANK_OPERATION_TYPE_NAME;
import static com.bfm.aap.pmdx.model.ModelConstants.COMPANY_TYPE_NAME;
import static com.bfm.aap.pmdx.model.ModelConstants.CONTACT_TYPE_NAME;
import static com.bfm.aap.pmdx.model.ModelConstants.FUNDAMENTALS_TYPE_NAME;
import static com.bfm.aap.pmdx.model.ModelConstants.INSTRUMENT_TYPE_NAME;
import static com.bfm.aap.pmdx.model.ModelConstants.INVESTOR_ACCOUNT_TYPE_NAME;
import static com.bfm.aap.pmdx.model.ModelConstants.INVESTOR_TYPE_NAME;
import static com.bfm.aap.pmdx.model.ModelConstants.PERFORMANCE_TYPE_NAME;
import static com.bfm.aap.pmdx.model.ModelConstants.PORTFOLIO_TYPE_NAME;
import static com.bfm.aap.pmdx.model.ModelConstants.POSITION_TYPE_NAME;
import static com.bfm.aap.pmdx.model.ModelConstants.SHARECLASS_TYPE_NAME;
import static com.bfm.aap.pmdx.model.ModelConstants.TRANSACTION_TYPE_NAME;
import static com.bfm.aap.pmdx.model.ModelConstants.USER_TYPE_NAME;

@Service
public class BatchTask {

    private static final Logger LOGGER = LoggerFactory.getLogger(BatchTask.class);
    public static final String FIA = "FIA";
    public static final String DWH = "DWH";
    protected final StatCollectorMeterRegistry metricRegistry = StatCollectorMeterRegistry.getInstance();
    private final AssetServiceClient assetServiceClient;
    private final FundamentalsServiceClient fundamentalsServiceClient;
    private final TransactionsServiceClient transactionsServiceClient;
    private final PortfolioServiceClient portfolioServiceClient;
    private final PositionServiceClient positionServiceClient;
    private final PerformanceServiceClient performanceServiceClient;
    private final InstrumentServiceClient instrumentServiceClient;
    private final BankAccountServiceClient bankAccountServiceClient;
    private final BankOperationServiceClient bankOperationServiceClient;
    private final ShareClassServiceClient shareClassServiceClient;
    private final UserServiceClient userServiceClient;
    private final ContactServiceClient contactServiceClient;
    private final CompanyServiceClient companyServiceClient;
    private final InvestorServiceClient investorServiceClient;
    private final InvestorAccountServiceClient investorAccountServiceClient;

    private final TransformerClientServiceHelper transformerServiceHelper;
    private final ClientInfoDAO clientInfoDAO;
    private final ZookeeperHelper zookeeperHelper;

    private final AtomicInteger assetThreadCount = new AtomicInteger(0);
    private final AtomicInteger portfolioThreadCount = new AtomicInteger(0);
    private final AtomicInteger shareClassThreadCount = new AtomicInteger(0);
    private final AtomicInteger positionThreadCount = new AtomicInteger(0);
    private final AtomicInteger performanceThreadCount = new AtomicInteger(0);
    private final AtomicInteger fundamentalsThreadCount = new AtomicInteger(0);
    private final AtomicInteger transactionsThreadCount = new AtomicInteger(0);
    private final AtomicInteger instrumentThreadCount = new AtomicInteger(0);
    private final AtomicInteger bankAccountThreadCount = new AtomicInteger(0);
    private final AtomicInteger bankOperationThreadCount = new AtomicInteger(0);
    private final AtomicInteger contactThreadCount = new AtomicInteger(0);
    private final AtomicInteger companyThreadCount = new AtomicInteger(0);
    private final AtomicInteger userThreadCount = new AtomicInteger(0);
    private final AtomicInteger investorThreadCount = new AtomicInteger(0);
    private final AtomicInteger investorAccountThreadCount = new AtomicInteger(0);

    private final Map<String, EntityServiceClientExecutor> entityServiceClientMap = new HashMap<>();

    @Value("${gprc.concurrent-batch-count:5}")
    private int concurrentBatchCount;

    @Autowired
    public BatchTask(TransformerClientServiceHelper transformerServiceHelper,
                     ClientInfoDAO clientInfoDAO,
                     AssetServiceClient assetServiceClient,
                     PortfolioServiceClient portfolioServiceClient,
                     PositionServiceClient positionServiceClient,
                     PerformanceServiceClient performanceServiceClient,
                     BankOperationServiceClient bankOperationServiceClient,
                     FundamentalsServiceClient fundamentalsServiceClient,
                     TransactionsServiceClient transactionsServiceClient,
                     ShareClassServiceClient shareClassServiceClient,
                     InstrumentServiceClient instrumentServiceClient,
                     BankAccountServiceClient bankAccountServiceClient,
                     UserServiceClient userServiceClient,
                     ContactServiceClient contactServiceClient,
                     CompanyServiceClient companyServiceClient,
                     InvestorServiceClient investorServiceClient,
                     InvestorAccountServiceClient investorAccountServiceClient,
                     ZookeeperHelper zookeeperHelper) {
        this.assetServiceClient = assetServiceClient;
        this.portfolioServiceClient = portfolioServiceClient;
        this.positionServiceClient = positionServiceClient;
        this.performanceServiceClient = performanceServiceClient;
        this.bankOperationServiceClient = bankOperationServiceClient;
        this.fundamentalsServiceClient = fundamentalsServiceClient;
        this.transactionsServiceClient = transactionsServiceClient;
        this.instrumentServiceClient = instrumentServiceClient;
        this.bankAccountServiceClient = bankAccountServiceClient;
        this.shareClassServiceClient = shareClassServiceClient;
        this.transformerServiceHelper = transformerServiceHelper;
        this.clientInfoDAO = clientInfoDAO;
        this.userServiceClient = userServiceClient;
        this.contactServiceClient = contactServiceClient;
        this.companyServiceClient = companyServiceClient;
        this.investorServiceClient = investorServiceClient;
        this.investorAccountServiceClient = investorAccountServiceClient;
        this.zookeeperHelper = zookeeperHelper;
    }

    @PostConstruct
    public void init() {

        entityServiceClientMap.put(USER_TYPE_NAME,
                new EntityServiceClientExecutor(userServiceClient, Executors.newFixedThreadPool(concurrentBatchCount, runnable -> new Thread(runnable, "User-thread-" + userThreadCount.incrementAndGet()))));
        entityServiceClientMap.put(CONTACT_TYPE_NAME,
                new EntityServiceClientExecutor(contactServiceClient, Executors.newFixedThreadPool(concurrentBatchCount, runnable -> new Thread(runnable, "Contact-thread-" + contactThreadCount.incrementAndGet()))));
        entityServiceClientMap.put(COMPANY_TYPE_NAME,
                new EntityServiceClientExecutor(companyServiceClient, Executors.newFixedThreadPool(concurrentBatchCount, runnable -> new Thread(runnable, "Company-thread-" + companyThreadCount.incrementAndGet()))));
        entityServiceClientMap.put(INVESTOR_TYPE_NAME,
                new EntityServiceClientExecutor(investorServiceClient, Executors.newFixedThreadPool(concurrentBatchCount, runnable -> new Thread(runnable, "Investor-thread-" + investorThreadCount.incrementAndGet()))));
        entityServiceClientMap.put(INVESTOR_ACCOUNT_TYPE_NAME,
                new EntityServiceClientExecutor(investorAccountServiceClient, Executors.newFixedThreadPool(concurrentBatchCount, runnable -> new Thread(runnable, "Investor-Account-thread-" + investorAccountThreadCount.incrementAndGet()))));
        entityServiceClientMap.put(POSITION_TYPE_NAME,
                new EntityServiceClientExecutor(positionServiceClient, Executors.newFixedThreadPool(concurrentBatchCount, runnable -> new Thread(runnable, "Position-thread-" + positionThreadCount.incrementAndGet()))));
        entityServiceClientMap.put(ASSET_TYPE_NAME,
                new EntityServiceClientExecutor(assetServiceClient, Executors.newFixedThreadPool(concurrentBatchCount, runnable -> new Thread(runnable, "Asset-thread-" + assetThreadCount.incrementAndGet()))));
        entityServiceClientMap.put(PORTFOLIO_TYPE_NAME,
                new EntityServiceClientExecutor(portfolioServiceClient, Executors.newFixedThreadPool(concurrentBatchCount, runnable -> new Thread(runnable, "Portfolio-thread-" + portfolioThreadCount.incrementAndGet()))));
        entityServiceClientMap.put(PERFORMANCE_TYPE_NAME,
                new EntityServiceClientExecutor(performanceServiceClient, Executors.newFixedThreadPool(concurrentBatchCount, runnable -> new Thread(runnable, "Performance-thread-" + performanceThreadCount.incrementAndGet()))));
        entityServiceClientMap.put(INSTRUMENT_TYPE_NAME,
                new EntityServiceClientExecutor(instrumentServiceClient, Executors.newFixedThreadPool(concurrentBatchCount, runnable -> new Thread(runnable, "Instrument-thread-" + instrumentThreadCount.incrementAndGet()))));
        entityServiceClientMap.put(FUNDAMENTALS_TYPE_NAME,
                new EntityServiceClientExecutor(fundamentalsServiceClient, Executors.newFixedThreadPool(concurrentBatchCount, runnable -> new Thread(runnable, "Fundamentals-thread-" + fundamentalsThreadCount.incrementAndGet()))));
        entityServiceClientMap.put(TRANSACTION_TYPE_NAME,
                new EntityServiceClientExecutor(transactionsServiceClient, Executors.newFixedThreadPool(concurrentBatchCount, runnable -> new Thread(runnable, "Transactions-thread-" + transactionsThreadCount.incrementAndGet()))));
        entityServiceClientMap.put(SHARECLASS_TYPE_NAME,
                new EntityServiceClientExecutor(shareClassServiceClient, Executors.newFixedThreadPool(concurrentBatchCount, runnable -> new Thread(runnable, "ShareClass-thread-" + shareClassThreadCount.incrementAndGet()))));
        entityServiceClientMap.put(BANK_OPERATION_TYPE_NAME,
                new EntityServiceClientExecutor(bankOperationServiceClient, Executors.newFixedThreadPool(concurrentBatchCount, runnable -> new Thread(runnable, "BankOperation-thread-" + bankOperationThreadCount.incrementAndGet()))));
        entityServiceClientMap.put(BANK_ACCOUNT_TYPE_NAME,
                new EntityServiceClientExecutor(bankAccountServiceClient, Executors.newFixedThreadPool(concurrentBatchCount, runnable -> new Thread(runnable, "BankAccount-thread-" + bankAccountThreadCount.incrementAndGet()))));

    }

    /**
     * Process a batch task asynchronously for the given client:
     * Needs 4 threads to run one batch task.
     * 3 threads - one each for Assets, Portfolios and Positions.
     * One thread waits for the result when all the above are completed and processes the response.
     * Increments the currentRunningTasks before the task and decrements when done
     *
     * @param clientName
     * @param defaultLastSuccessfulTime
     * @param currentRunningTasks
     * @param processedClients
     */
    public void submitTask(String clientName, final long defaultLastSuccessfulTime, AtomicInteger currentRunningTasks, Map<String, ExecutionStatus> processedClients, ClientInfo clientInfoZK) {

        final ClientInfo clientInfoProps;//client config from Hub properties.
        try {
            clientInfoProps = Preconditions.checkNotNull(clientInfoDAO.getClientByName(clientName));
        } catch (Exception ex) {
            LOGGER.warn("Cannot find configuration for Client: {}", clientName, ex);
            return;
        }

        try {
            List<EntityService> entityServicesProps = clientInfoProps.getEntityServiceList();
            if (CollectionUtils.isNotEmpty(entityServicesProps)) {
                LOGGER.info("Starting batch task for {}", clientName);
                currentRunningTasks.incrementAndGet();

                Map<String, List<Long>> entityTimestampMap = createEntityTimestampMap(defaultLastSuccessfulTime, clientInfoZK);
                LOGGER.info("Fetch since timestamps for {} is {}", clientName, entityTimestampMap);

                Map<EntityType, Map<String, CompletableFuture<TaskResult<Set<String>>>>> entityTypeFuturesEnumMap = fetchEntitiesSince(clientName,
                        defaultLastSuccessfulTime,
                        clientInfoProps,
                        entityServicesProps,
                        entityTimestampMap);

                // the return from allOf() is not handled as the intention is
                // to only move forward when all the futures are completed.
                LOGGER.info("Waiting for all futures for {}", clientName);
                CompletableFuture.allOf(entityTypeFuturesEnumMap
                                .values()
                                .stream()
                                .flatMap(entry -> entry.values().stream())
                                .toArray(CompletableFuture[]::new))
                        .get();


                LOGGER.info("data received, calling handleCompletedFutures to send batch to transformer for {}", clientName);
                handleCompletedFutures(entityTypeFuturesEnumMap, clientInfoProps);
            }
        } catch (InterruptedException e) {
            LOGGER.error("Failed to run batch task for client: {}", clientName, e);
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            LOGGER.error("Failed to run batch task for client: {} :", clientName, e);
        } finally {
            processedClients.put(clientName, ExecutionStatus.COMPLETED);
            clientInfoProps.getEntityServiceList().forEach(entityService ->
            {
                LOGGER.info("Executing finally ... Batch task completed for batchClient = {} service = {}", clientName, entityService.getServiceName());
                zookeeperHelper.updateChildNodeStatusToComplete(clientName, ServiceEnum.findService(entityService.getServiceName()), defaultLastSuccessfulTime);
            });
            currentRunningTasks.decrementAndGet();
        }
    }

    /**
     * Create map of timestamp for each entity service from ZK.
     *
     * @param defaultLastSuccessfulTime
     * @param clientInfoZK
     * @return
     */
    private Map<String, List<Long>> createEntityTimestampMap(long defaultLastSuccessfulTime, ClientInfo clientInfoZK) {
        Map<String, List<Long>> entityTimestampMap = new HashMap<>();
        clientInfoZK.getEntityServiceList().forEach(entityService -> {
            List<Long> timestamp = new ArrayList<>(2);
            //index - 0 is always FIA and index 1 is always DWH
            timestamp.add(0, null != entityService.getLastSuccessfulTime() ? Timestamps.toMillis(entityService.getLastSuccessfulTime()) : defaultLastSuccessfulTime);
            timestamp.add(1, null != entityService.getLastSuccessfulTimeDwh() ? Timestamps.toMillis(entityService.getLastSuccessfulTimeDwh()) : defaultLastSuccessfulTime);
            entityTimestampMap.put(entityService.getServiceName(), timestamp);
        });
        LOGGER.info("Timestamp map for client : {} is - {}", clientInfoZK.getClientName(), entityTimestampMap);
        return entityTimestampMap;
    }

    /**
     * @param clientName
     * @param lastSuccessfulTime
     * @param clientInfoProps
     * @param entityServicesProps
     * @param entityTimestampMap
     * @return
     */
    private Map<EntityType, Map<String, CompletableFuture<TaskResult<Set<String>>>>> fetchEntitiesSince(String clientName,
                                                                                                        long lastSuccessfulTime,
                                                                                                        ClientInfo clientInfoProps,
                                                                                                        List<EntityService> entityServicesProps,
                                                                                                        Map<String, List<Long>> entityTimestampMap) {

        Map<EntityType, Map<String, CompletableFuture<TaskResult<Set<String>>>>> entityTypeFuturesEnumMap = Maps.newEnumMap(EntityType.class);
        //loop through each service(Investments/CRM)
        for (EntityService entityServiceProp : entityServicesProps) {
            //loop through each entity type
            for (EntityType entityTypeProp : entityServiceProp.getEntityTypeList()) {
                //stores each entity and the multiple futures from different data sources(IFA/DWH)
                EntityServiceClientExecutor entityServiceClientExecutor = entityServiceClientMap.get(entityTypeProp.name());
                Long sinceTimeFIA = (null != entityTimestampMap.get(entityTypeProp.name())) ?
                        entityTimestampMap.get(entityTypeProp.name()).get(0) :
                        lastSuccessfulTime;
                Long sinceTimeDWH = (null != entityTimestampMap.get(entityTypeProp.name())) ?
                        entityTimestampMap.get(entityTypeProp.name()).get(1) :
                        lastSuccessfulTime;

                Map<String, CompletableFuture<TaskResult<Set<String>>>> entitySourceFuture = new HashMap<>();
                //Do not pass datasource for entities except for Instruments and Transactions.

                if (EntityType.INSTRUMENT == entityTypeProp || EntityType.TRANSACTION == entityTypeProp) {
                    LOGGER.info("{} fetchSince time for {} is {} and DWH time {}", entityTypeProp, clientName, sinceTimeFIA, sinceTimeDWH);
                    CompletableFuture<TaskResult<Set<String>>> futureFIA = CompletableFuture.supplyAsync(() -> entityServiceClientExecutor.getServiceClient()
                                    .fetchEntitiesSince(sinceTimeFIA, clientInfoProps, InvestUtils.DataSource.FIA),
                            entityServiceClientExecutor.getExecutorService());
                    entitySourceFuture.put(FIA, futureFIA);

                    CompletableFuture<TaskResult<Set<String>>> futureDWH = CompletableFuture.supplyAsync(() -> entityServiceClientExecutor.getServiceClient()
                                    .fetchEntitiesSince(sinceTimeDWH, clientInfoProps, InvestUtils.DataSource.DWH),
                            entityServiceClientExecutor.getExecutorService());
                    entitySourceFuture.put(DWH, futureDWH);
                } else {
                    LOGGER.info("{} fetchSince time for {} is {}", entityTypeProp, clientName, sinceTimeFIA);
                    CompletableFuture<TaskResult<Set<String>>> futureFIA = CompletableFuture.supplyAsync(() -> entityServiceClientExecutor.getServiceClient()
                                    .fetchEntitiesSince(sinceTimeFIA, clientInfoProps, null),
                            entityServiceClientExecutor.getExecutorService());
                    entitySourceFuture.put(FIA, futureFIA);
                }
                entityTypeFuturesEnumMap.put(entityTypeProp, entitySourceFuture);
            }
        }
        return entityTypeFuturesEnumMap;
    }

    @VisibleForTesting
    void handleCompletedFutures(Map<EntityType, Map<String, CompletableFuture<TaskResult<Set<String>>>>> completableFutureMap,
                                ClientInfo clientInfoProps) throws InterruptedException, ExecutionException {
        Map<EntityType, Map<String, TaskResult<Set<String>>>> taskResults = Maps.newHashMap();

        LOGGER.info("completableFutureMap result size for {} is {}", clientInfoProps.getClientName(), completableFutureMap.size());

        boolean requiredEntitiesValidationFailed = clientInfoProps.getEntityServiceList().stream()
                .map(entityService -> areAllRequiredEntitiesProcessingCompleted(completableFutureMap, entityService)
                ).collect(Collectors.toList()).contains(false);

        if (!requiredEntitiesValidationFailed) {
            LOGGER.info("Required entities validation successful for {}", clientInfoProps.getClientName());
            Map<EntityType, Map<String, Long>> entityTimestampHashMap = populateTaskResults(completableFutureMap, taskResults);

            Long defaultLastSuccessfulTimeMin = Collections.min(entityTimestampHashMap
                    .values()
                    .stream()
                    .flatMap(x -> x.values().stream()).collect(Collectors.toList()));
            LOGGER.info("New DefaultlastSuccessFulTime for {} is {}", clientInfoProps.getClientName(), defaultLastSuccessfulTimeMin);
            triggerEtlBatch(taskResults, clientInfoProps.getClientName());
            //loop through all services(INVESTMENTS/CRM)
            for (EntityService entityServiceProp : clientInfoProps.getEntityServiceList()) {
                //check if all required entity types have completed processing.
                try {
                    //update the node data with correct timestamp
                    zookeeperHelper.updateEntityTimestamp(clientInfoProps.getClientName(), ServiceEnum.findService(entityServiceProp.getServiceName()), defaultLastSuccessfulTimeMin, entityTimestampHashMap);
                } catch (KeeperException exception) {
                    LOGGER.error("Error updating entity timestamps for client : {}, service : {}.", clientInfoProps.getClientName(), entityServiceProp.getServiceName());
                }
            }
        } else {
            LOGGER.info("Required entities validation failed for {}", clientInfoProps.getClientName());
        }


    }

    /**
     * @param completableFutureMap
     * @param taskResults          - used to store the completed results which will be passed to transformer.
     * @return - map of timestamps for each entity.
     * @throws InterruptedException
     * @throws ExecutionException
     */
    private Map<EntityType, Map<String, Long>> populateTaskResults(Map<EntityType, Map<String, CompletableFuture<TaskResult<Set<String>>>>> completableFutureMap,
                                                                   Map<EntityType, Map<String, TaskResult<Set<String>>>> taskResults) throws InterruptedException, ExecutionException {
        Map<EntityType, Map<String, Long>> entityTimestampMap = Maps.newEnumMap(EntityType.class);
        for (Map.Entry<EntityType, Map<String, CompletableFuture<TaskResult<Set<String>>>>> entityEntry : completableFutureMap.entrySet()) {
            Map<String, Long> timestamp = new HashMap<>(2);// max holds only two values - FIA and DWH times
            Map<String, TaskResult<Set<String>>> taskResult = new HashMap<>();
            for (Map.Entry<String, CompletableFuture<TaskResult<Set<String>>>> entitySubEntry : entityEntry.getValue().entrySet()) {
                TaskResult<Set<String>> result = entitySubEntry.getValue().get();
                if (ExecutionStatus.COMPLETED.equals(result.getStatus())) {
                    timestamp.put(entitySubEntry.getKey(), result.getLastEntityTime());
                    taskResult.put(entitySubEntry.getKey(), result);
                }
                LOGGER.info("ExecutionStatus for {} for source {} is {}", entityEntry.getKey(), entitySubEntry.getKey(), result.getStatus());
            }
            entityTimestampMap.put(entityEntry.getKey(), timestamp);
            taskResults.put(entityEntry.getKey(), taskResult);
        }
        return entityTimestampMap;
    }

    private boolean areAllRequiredEntitiesProcessingCompleted(Map<EntityType, Map<String, CompletableFuture<TaskResult<Set<String>>>>> completableFutureMap, EntityService entityService) {
        return completableFutureMap.entrySet()
                .stream()
                .filter(entry -> entityService.getRequiredEntityTypeList().contains(entry.getKey()))
                .noneMatch(this::isTaskResultCompleted);
    }

    /**
     * @param entry
     * @return
     */
    private boolean isTaskResultCompleted(Map.Entry<EntityType, Map<String, CompletableFuture<TaskResult<Set<String>>>>> entry) {
        if (!entry.getValue().isEmpty()) {
            for (Map.Entry<String, CompletableFuture<TaskResult<Set<String>>>> subEntry : entry.getValue().entrySet()) {
                try {
                    TaskResult<Set<String>> result = subEntry.getValue().get();
                    return result.getStatus() != ExecutionStatus.COMPLETED;
                } catch (InterruptedException exception) {
                    LOGGER.error("Interrupted Exception getting completion status for : {}", entry.getKey(), exception);
                    Thread.currentThread().interrupt();
                } catch (Exception exception) {
                    LOGGER.error("Exception getting completion status for : {}", entry.getKey(), exception);
                }
            }
        }
        return true;
    }

    /**
     * Pass the task results to transformer
     *
     * @param taskResults
     * @param clientName
     */
    @VisibleForTesting
    void triggerEtlBatch(Map<EntityType, Map<String, TaskResult<Set<String>>>> taskResults, final String clientName) {
        //log details of the batch first
        logger().info("ETL Batch Triggered for Client {}", clientName);

        Map<EntityType, Collection<String>> entities = Maps.newEnumMap(EntityType.class);
        taskResults.forEach((key, value) -> value.entrySet().forEach(entry -> {
            logger().info("Client {} Entity {} Datasource {}  size {}", clientName, key.name(), entry.getKey(), entry.getValue().getResult().size());
            if (null != entities.get(key)) {
                entities.get(key).addAll(entry.getValue().getResult());
            } else {
                entities.put(key, entry.getValue().getResult());
            }
        }));

        //send reference entities first(Synchronous call).
        Map<EntityType, Collection<String>> referenceEntities = transformerServiceHelper.loadReferenceEntities(entities);

        //Remove/Exclude bank account(synchronous if data present) and bank operation(async).
        Collection<String> bankAccounts = entities.remove(EntityType.BANK_ACCOUNT);
        Collection<String> bankOperations = entities.remove(EntityType.BANK_OPERATION);

        //send remaining
        entities.forEach(transformerServiceHelper::extractTransformLoad);

        //Send bank account in synchronous manner.
        transformerServiceHelper.loadDataSync(EntityType.BANK_ACCOUNT, bankAccounts);

        // Send bank operation in asynchronous manner.
        transformerServiceHelper.extractTransformLoad(EntityType.BANK_OPERATION, bankOperations);

        //update counter
        entities.forEach(this::incrementEntityCounters);
        referenceEntities.forEach(this::incrementEntityCounters);
        this.incrementEntityCounters(EntityType.BANK_ACCOUNT, bankAccounts);
        this.incrementEntityCounters(EntityType.BANK_OPERATION, bankOperations);
    }

    private void incrementEntityCounters(EntityType key, Collection<String> value) {
        try {
            if (CollectionUtils.isNotEmpty(value)) {
                Iterable<Tag> itr = Tags.of(key.name(), String.valueOf(value.size()));
                metricRegistry.counter(key.name(), "CountToTransformer", itr).increment(value.size());
            }
        } catch (Exception e) {
            logger().error("Failed to record LibMetric counter in PMDX HUB ", e);
        }
    }

    @VisibleForTesting
    Logger logger() {
        return LOGGER;
    }

}