package com.bfm.aap.pmdx.hub.service.entity;

import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.pmdx.model.Asset;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.aap.pmdx.services.AssetRequest;
import com.bfm.aap.pmdx.services.AssetServiceGrpc;
import com.bfm.aap.pmdx.services.AssetsSinceRequest;
import com.bfm.service.ServiceException;
import com.bfm.util.BFMTimestamp;
import com.google.protobuf.Timestamp;
import com.google.protobuf.util.Timestamps;
import io.grpc.ManagedChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import static com.bfm.util.BFMDateConstants.FMT_ISODateTime;
import static com.google.protobuf.util.Timestamps.fromMillis;

@Service
public class AssetServiceClient extends BaseServiceClient<Asset, AssetServiceGrpc.AssetServiceBlockingStub>
        implements EntityService<Asset, AssetRequest> {

    private static final Logger LOGGER = LoggerFactory.getLogger(AssetServiceClient.class);

    @Autowired
    public AssetServiceClient(ManagedChannel channel, AltsDataWorkspaceDAO altsDataWorkspaceDAO,
                              EntityProcessor<Asset> entityProcessor){
        super(channel, AssetServiceClient.class.getSimpleName(), altsDataWorkspaceDAO, EntityType.ASSET, entityProcessor);
        this.serviceStub = AssetServiceGrpc.newBlockingStub(channel);
    }

    @Override
    @RecordStats(metricName = "assetService_getAssetsSince", timer = true)
    Iterator<Asset> initiateSingleBlockingRequest(long sinceTime, ClientInfo clientInfo, InvestUtils.DataSource dataSource) {
        Timestamp sinceTimeTs = fromMillis(sinceTime);
        BFMTimestamp sinceTimeBfm = new BFMTimestamp(sinceTime, TimeUnit.MILLISECONDS);
        LOGGER.info("Initiating gprc request for getAssetsSince for client: {} with localtime {}, GMT time:{}",
                clientInfo.getClientName(), sinceTimeBfm.toBFMDateTime().fmt(FMT_ISODateTime), Timestamps.toString(sinceTimeTs));
        AssetsSinceRequest request = AssetsSinceRequest.newBuilder().setTimestamp(sinceTimeTs).build();
        return ((AssetServiceGrpc.AssetServiceBlockingStub) getStubWithInterceptor(clientInfo)).getAssetsSince(request);
    }

    /**
     *  Get single entity via unary grpc call.
     * @param entityRequest
     * @return
     * @throws ServiceException
     */
    @Override
    @RecordStats(metricName = "assetService_getAsset", timer = true)
    public Asset getEntity(AssetRequest entityRequest) {
        try {
            LOGGER.info("Processing single entity request for {}", entityRequest);
            Asset fundAsset = serviceStub
                    .withDeadlineAfter(unaryCallTimeoutMillis, TimeUnit.MILLISECONDS)
                    .getAsset(entityRequest);
            this.dataWorkspaceDAO.insertRecords(Collections.singletonList(fundAsset));
            return fundAsset;
        } catch (Exception e) {
            throw new ServiceException("Failed to get Asset:"+e.getMessage(), e);
        }
    }

    @Override
    String getEntityGuid(Asset entity) {
        return entity.getAssetId();
    }
}
