package com.bfm.aap.pmdx.hub.service.entity;

import static com.google.protobuf.util.Timestamps.fromMillis;

import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bfm.aap.pmdx.hub.model.async.TaskResult;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.pmdx.model.InvestorAccount;
import com.bfm.aap.pmdx.model.InvestorAccountResponse;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.aap.pmdx.services.InvestorAccountServiceGrpc;
import com.bfm.aap.pmdx.services.InvestorAccountSinceRequest;
import com.bfm.service.ServiceException;
import com.google.protobuf.Message;

import io.grpc.ManagedChannel;
import io.grpc.stub.AbstractStub;

@Service
public class InvestorAccountServiceClient implements EntityService {

    private static final Logger LOGGER = LoggerFactory.getLogger(InvestorAccountServiceClient.class);
    private final RPCServiceClient rpcServiceClient;
    private final EntityProcessor<InvestorAccount> investorAccountEntityProcessor;
    private final AbstractStub<InvestorAccountServiceGrpc.InvestorAccountServiceBlockingStub> investorAccountServiceStub;

    @Autowired
    public InvestorAccountServiceClient(RPCServiceClient rpcServiceClient, ManagedChannel channel, EntityProcessor<InvestorAccount> entityProcessor) {
        this.rpcServiceClient = rpcServiceClient;
        this.investorAccountEntityProcessor = entityProcessor;
        this.investorAccountServiceStub = InvestorAccountServiceGrpc.newBlockingStub(channel);
    }

    @Override
    public Message getEntity(Message entityRequest) {
        throw new UnsupportedOperationException();
    }

    @Override
    @RecordStats(metricName = "InvestorAccountService_getInvestorAccountSince", timer = true)
    public TaskResult<Set<String>> fetchEntitiesSince(long lastSuccessfulTime, ClientInfo clientInfo, InvestUtils.DataSource dataSource) {
        InvestorAccountSinceRequest investorAccountSinceRequest = InvestorAccountSinceRequest.newBuilder().setTimestamp(fromMillis(lastSuccessfulTime)).build();

        return rpcServiceClient.doFetchSince(InvestorAccountServiceGrpc.InvestorAccountServiceBlockingStub::getInvestorAccountSince, investorAccountServiceStub, investorAccountSinceRequest, investorAccountEntityProcessor, clientInfo, lastSuccessfulTime);
    }

    public String updateInvestorAccount(InvestorAccount investorAccount, ClientInfo clientInfo, Integer crmEntityId) {
        String entityId = StringUtils.EMPTY;
        LOGGER.info("Processing Investor Account entity request for update");
        try {
            InvestorAccountServiceGrpc.InvestorAccountServiceBlockingStub investorAccountServiceBlockingStub = rpcServiceClient.getStubWithInterceptor(investorAccountServiceStub, clientInfo);
            InvestorAccountResponse response = investorAccountServiceBlockingStub.updateInvestorAccount(investorAccount);
            LOGGER.info("Investor Account entity {} {}", crmEntityId, response.getIsUpdated() ? "updated successfully." : "failed to update.");
            if (response.getIsUpdated()) {
                entityId = response.getData().getInvestorAccountId();
            } else {
                LOGGER.info("Investor Account request : {}", investorAccount);
                LOGGER.info("Investor Account request : {}", response);
            }
            return entityId;
        } catch (Exception e) {
            throw new ServiceException("InvestorAccount gRPC request failed with status: " + e.getMessage(), e);
        }
    }
}