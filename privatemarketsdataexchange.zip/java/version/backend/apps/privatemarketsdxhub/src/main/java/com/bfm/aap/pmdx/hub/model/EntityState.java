package com.bfm.aap.pmdx.hub.model;

import com.bfm.aap.pmdx.model.util.NetworkMode;
import java.util.Arrays;

import static java.text.MessageFormat.format;

/**
 * Represents the networkMode state for storing the last successful time when
 * entities were fetched.
 * networkMode -> REDSTATE, BLUESTATE to differentiate the records from actual data.
 */
public enum EntityState {
    REDSTATE(NetworkMode.RED),
    BLUESTATE(NetworkMode.BLUE);

    private final NetworkMode networkMode;

    EntityState(NetworkMode networkMode) {
        this.networkMode = networkMode;
    }

    public static EntityState getState(NetworkMode networkMode){
        return Arrays.stream(EntityState.values())
                .filter(entityState -> entityState.networkMode == networkMode)
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException(format("EntityState not found for {0} networkMode ", networkMode)));
    }
}
