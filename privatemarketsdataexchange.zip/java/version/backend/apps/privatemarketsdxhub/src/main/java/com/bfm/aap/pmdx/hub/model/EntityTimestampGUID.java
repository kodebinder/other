package com.bfm.aap.pmdx.hub.model;

import com.bfm.aap.pmdx.model.util.EntityType;
import com.google.common.collect.ImmutableTable;

import java.text.MessageFormat;

/**
 * Enum for entityState, entityType and GUID mapping.
 * These GUIDs are used for storing the last successful time when the entities were fetched.
 */
public enum EntityTimestampGUID {

    REDSTATE_ASSET_GUID(EntityState.REDSTATE, EntityType.ASSET, "8d7203f6-e72c-4060-b6bf-d7ee30c39f98"),
    REDSTATE_PORTFOLIO_GUID(EntityState.REDSTATE, EntityType.PORTFOLIO,"62782b65-14f4-4de3-a2b1-8bc352c552fd"),
    REDSTATE_POSITION_GUID(EntityState.REDSTATE, EntityType.POSITION,"fdb3e83b-fb9d-45e3-96a1-f51615ba4bb0"),
    REDSTATE_FUNDAMENTALS_GUID(EntityState.REDSTATE, EntityType.FUNDAMENTALS,"b3a7991f-7231-0e21-a87a-8af5e34fd10"),
    BLUESTATE_ASSET_GUID(EntityState.BLUESTATE, EntityType.ASSET,"f4eb44e0-7759-40a3-ba09-c838f6ece479"),
    BLUESTATE_PORTFOLIO_GUID(EntityState.BLUESTATE, EntityType.PORTFOLIO,"d54e9d5d-5c59-4e6a-957c-ec06d7078aee"),
    BLUESTATE_POSITION_GUID(EntityState.BLUESTATE, EntityType.POSITION,"e377ee54-747f-4269-9ef9-79dc572a4957"),
    BLUESTATE_FUNDAMENTALS_GUID(EntityState.BLUESTATE, EntityType.FUNDAMENTALS,"f3a7191e-7e31-fee1-d17a-8fa8e342d1e");

    private final EntityState entityState;
    private final EntityType entityType;
    private final String guid;

    EntityTimestampGUID(EntityState entityState, EntityType entityType, String guid) {
        this.entityState = entityState;
        this.entityType = entityType;
        this.guid = guid;
    }

    public EntityState getEntityState() {
        return entityState;
    }

    public EntityType getEntityType() {
        return entityType;
    }

    public String getGuid() {
        return guid;
    }

    private static ImmutableTable<EntityState, EntityType, String> ENTITY_GUID_TABLE;

    static {
        ImmutableTable.Builder<EntityState, EntityType, String> entityGuidTableBuilder = ImmutableTable.builder();
        for (EntityTimestampGUID entityTimestampGUID : EntityTimestampGUID.values()) {
            entityGuidTableBuilder.put(entityTimestampGUID.getEntityState(), entityTimestampGUID.getEntityType(), entityTimestampGUID.getGuid());
        }
        ENTITY_GUID_TABLE = entityGuidTableBuilder.build();
    }

    public static String getGUIDFromEntity(EntityState entityState, EntityType entityType) throws IllegalArgumentException {
        if (ENTITY_GUID_TABLE.contains(entityState, entityType)) {
            return ENTITY_GUID_TABLE.get(entityState, entityType);
        }
        throw new IllegalArgumentException(MessageFormat.format("Unable to find GUID for state:{0} and entityType:{1}", entityState,entityType));
    }

}
