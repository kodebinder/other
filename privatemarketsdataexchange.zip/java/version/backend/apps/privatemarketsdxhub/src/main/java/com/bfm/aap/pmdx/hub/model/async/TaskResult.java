package com.bfm.aap.pmdx.hub.model.async;

import com.bfm.aap.pmdx.hub.model.ExecutionStatus;
import org.apache.commons.lang.StringUtils;

import java.time.Instant;
import org.apache.tools.ant.taskdefs.Exec;

// MC: TODO: Why do the constructors not use a consistent order for parameters?
public class TaskResult<T> {

    private final T result;
    private final ExecutionStatus status;
    private final String failureMessage;
    private final long lastEntityTime;

    public TaskResult(T result, long lastEntityTime) {
        this(result, ExecutionStatus.COMPLETED, "", lastEntityTime);
    }

    public TaskResult(ExecutionStatus status, String failureMessage, T result) {
        this(result, status, failureMessage, Instant.EPOCH.toEpochMilli());
    }

    // Constructor for testing to allow all parameters to be specified
    public TaskResult(final T result, final ExecutionStatus status, final String failureMessage, final long lastEntityTime) {
        this.result = result;
        this.status = status;
        this.failureMessage = failureMessage;
        this.lastEntityTime = lastEntityTime;
    }

    public T getResult() {
        return result;
    }

    public ExecutionStatus getStatus() {
        return status;
    }

    public String getFailureMessage() {
        return failureMessage;
    }

    public long getLastEntityTime() {
        return lastEntityTime;
    }

    @Override
    public String toString() {
        return "TaskResult{" +
                "status=" + status +
                ", failureMessage='" + failureMessage + '\'' +
                ", lastEntityTime=" + lastEntityTime +
                '}';
    }
}
