/*
 *  Copyright (C) 2020 BlackRock
 *
 *  Created: Jul 21, 2020
 *   Author: micclark
 */
package com.bfm.aap.pmdx.hub.service.grpc;

import com.google.protobuf.Message;
import io.grpc.Metadata;
import java.util.Collection;
import java.util.Iterator;

/**
 * Provides a common interface to the entity type specific calls available through the PMDX gRPC service definitions.
 * Since we're using the BlockingStub variant provided by the type specific stub factories and only making Unary calls,
 * the signatures look like this:
 * <pre>
 *      Function<RequestType,ResponseType>
 *      Function<RequestType,Iterator<ResponseType>>
 * </pre>
 * {@link Iterator} is not a very useful return type, so this interface uses a {@link Collection} return type instead.
 * Conversion from {code Iterator} to {@code Collection} should be handled by the implementation.
 *
 * The correct request type to wrap the parameters for each call should be created by the implementation.
 *
 * @param <T> - the output/response type
 */

public interface GrpcEntityClient<T extends Message> {

    /**
     * Returns a single entity based on the parameters supplied in the request. The metadata is used to provide additional header
     * information on the gRPC request.
     * @param id
     * @param metadata
     * @return
     */
    T getEntityById(String id, Metadata metadata);

    /**
     * Returns a {@link Collection} of entities based on the parameters supplied in the request. The metadata is used to provide additional
     * header information in the gRPC request
     * @param epochMillis
     * @param metadata
     * @return
     */
    Collection<T> getEntitiesSince(long epochMillis, Metadata metadata);
}
