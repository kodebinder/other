package com.bfm.aap.pmdx.hub.service;

import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import io.grpc.ConnectivityState;
import io.grpc.ManagedChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Service;

import java.util.concurrent.CountDownLatch;

@Service
@DependsOn("channel")
public class GRPCChannelManager {

    private final ManagedChannel channel;
    private final ServiceProvider serviceProvider;
    private CountDownLatch channelTerminatedLatch = new CountDownLatch(0);

    private static final Logger LOGGER = LoggerFactory.getLogger(GRPCChannelManager.class);

    @Value("${gprc.channel-retry-interval-millis:600000}")
    private long channelRetryInterval;

    @Value("${gprc.channel-monitor-interval-millis:10000}")
    private long channelMonitorInterval;

    @Autowired
    public GRPCChannelManager(ManagedChannel channel, ServiceProvider serviceProvider){
        this.channel = channel;
        this.serviceProvider = serviceProvider;
    }

    @RecordStats
    public void monitorChannel(){
        ConnectivityState channelState = channel.getState(true);
        LOGGER.info("Monitoring GRPC channel...Current channel state: {}", channelState);

        //Registers a one-off callback that will be run if the connectivity state of the channel diverges from the given source
        //Transition from any state -> Ready / Shutdown / Failure
        //more info: https://github.com/grpc/grpc-java/issues/3721
        statusChangeHandler();
    }

    private void statusChangeHandler() {
        ConnectivityState currentState = channel.getState(false);
        // handle currentState
        LOGGER.info("Channel notifyWhenStateChanged: {}",currentState);
        if(ConnectivityState.READY.equals(currentState))
            startListeners();
        else if(ConnectivityState.SHUTDOWN.equals(currentState))
            stopListeners();
        try {
            Thread.sleep(channelMonitorInterval);
        } catch (InterruptedException e) {
            LOGGER.info("Channel status listener thread interrupted..{}", e.getMessage(), e);
            Thread.currentThread().interrupt();
        }
        channel.notifyWhenStateChanged(currentState, this::statusChangeHandler);
    }

    private void stopListeners() {
        if(channelTerminatedLatch.getCount() == 1) {
            LOGGER.info("Channel connection failure, stopping batch executor");
            serviceProvider.stopExecutors();
            channelTerminatedLatch.countDown();
        }
    }

    private void startListeners() {
        if(channelTerminatedLatch.getCount() == 0) {
            LOGGER.info("Channel in ready state, starting batch executor...");
            serviceProvider.execute();
            channelTerminatedLatch = new CountDownLatch(1);
        }
    }

    public CountDownLatch getTerminatedLatch() {
        return channelTerminatedLatch;
    }

    public long getChannelRetryInterval() {
        return channelRetryInterval;
    }
}
