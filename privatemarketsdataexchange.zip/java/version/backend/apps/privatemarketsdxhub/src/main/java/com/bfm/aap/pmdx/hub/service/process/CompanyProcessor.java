package com.bfm.aap.pmdx.hub.service.process;

import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.util.CompanyUtil;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.google.protobuf.util.Timestamps;
import org.springframework.stereotype.Service;

@Service
public class CompanyProcessor extends EntityProcessor<Company> {

    @Override
    public long getEntityEpochOriginTime(Company entity) {
        return Timestamps.toMillis(entity.getEntityInfo().getOriginTimestamp());
    }

    @Override
    Company updatePrimaryFlag(Company entity, boolean isPrimary) {
        Company.Builder crmCompanyBuilder = Company.newBuilder(entity);
        crmCompanyBuilder.getEntityInfoBuilder().setPrimaryData(isPrimary);
        return crmCompanyBuilder.build();
    }

    @Override
    EntityInfo getEntityInfo(Company entity) {
        return entity.getEntityInfo();
    }

    @Override
    public String getGuid(Company entity) {
        return CompanyUtil.getCompanyGuid(entity);
    }

    @Override
    boolean isPrimary(Company entity) {
        return entity.getEntityInfo().getPrimaryData();
    }

    @Override
    public String getEntityType() {
        return Company.class.getSimpleName();
    }
}
