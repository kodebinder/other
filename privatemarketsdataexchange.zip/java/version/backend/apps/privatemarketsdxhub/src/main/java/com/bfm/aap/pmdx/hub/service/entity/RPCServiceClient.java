package com.bfm.aap.pmdx.hub.service.entity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.function.BiFunction;

import com.google.common.base.Stopwatch;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.Message;
import io.grpc.ClientInterceptor;
import io.grpc.Metadata;
import io.grpc.Status;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.AbstractStub;
import io.grpc.stub.MetadataUtils;
import io.micrometer.core.instrument.Timer;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bfm.aap.pmdx.hub.model.ExecutionStatus;
import com.bfm.aap.pmdx.hub.model.async.TaskResult;
import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.hub.util.AppConstants;
import com.bfm.aap.pmdx.model.util.CircuitBreakerHelper;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.privatemarkets.common.constant.CommonConstants;
import com.bfm.adl.ADLException;
import com.bfm.adl.ADLObject;
import com.bfm.adl.ADLResultSet;
import com.bfm.metric.StatCollectorMeterRegistry;
import com.bfm.util.Pair;

import static java.text.MessageFormat.format;

@Service
public class RPCServiceClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(RPCServiceClient.class);
    public static final String SOURCE = "CRM";

    private final AltsDataWorkspaceDAO dataWorkspaceDAO;
    private final CircuitBreakerHelper circuitBreakerHelper;
    private final StatCollectorMeterRegistry registry = StatCollectorMeterRegistry.getInstance();
    private final boolean isCircuitBreakingEnabled = Boolean.getBoolean("circuitBreaking");

    @Autowired
    public RPCServiceClient(CircuitBreakerHelper circuitBreakerHelper,
                            AltsDataWorkspaceDAO dataWorkspaceDAO) {
        this.circuitBreakerHelper = circuitBreakerHelper;
        this.dataWorkspaceDAO = dataWorkspaceDAO;
    }

    @Value("${grpc.unary-call-timeout-millis:120000}")
    protected int unaryCallTimeoutMillis;

    public <T extends Message, R extends Message, S extends AbstractStub<S>> TaskResult<Set<String>> doFetchSince(BiFunction<S, T, Iterator<R>> grpcFunction,
                                                                                                                  AbstractStub<S> serviceStub,
                                                                                                                  T request,
                                                                                                                  EntityProcessor<R> entityProcessor,
                                                                                                                  ClientInfo clientInfo,
                                                                                                                  long sinceTime) {
        String exceptionMessage = "";
        try {
            //  (BiFunction<AbstractStub<S>, T, Iterator<R>> grpcFunction, AbstractStub<S> serviceStub, T request, ClientInfo clientInfo) {
            Iterator<R> iterator = initiateSingleBlockingRequest(grpcFunction, serviceStub, request, clientInfo);
            if (isCircuitBreakingEnabled) {
                iterator = this.filter(iterator, CommonConstants.NETWORK_MODE.name(), EntityType.valueOf(entityProcessor.getEntityType()));
            }

            Pair<Set<String>, Long> guidTimePair = processMessages(entityProcessor, iterator, sinceTime, clientInfo.getClientName());
            return new TaskResult<>(guidTimePair.getFirstValue(), guidTimePair.getSecondValue());
        } catch (StatusRuntimeException ex) {
            Status exStatus = ex.getStatus();
            exceptionMessage = format("{0}:GRPC request failed with status: {1}", request.getClass().getSimpleName(), StringUtils.defaultString(exStatus.getDescription(), ex.getMessage()));
            LOGGER.error(exceptionMessage, ex);
        } catch (Exception ex) {
            exceptionMessage = format("GRPC request failed: {0}", ex.getMessage());
            LOGGER.error(exceptionMessage, ex);
        }
        return new TaskResult<Set<String>>(ExecutionStatus.EXCEPTION, exceptionMessage, Collections.EMPTY_SET);
    }

    <T extends Message, R extends Message, S extends AbstractStub<S>> Iterator<R> initiateSingleBlockingRequest(BiFunction<S, T, Iterator<R>> grpcFunction, AbstractStub<S> serviceStub, T request, ClientInfo clientInfo) {
        return grpcFunction.apply(this.getStubWithInterceptor(serviceStub, clientInfo), request);
    }

    private <R extends Message> Pair<Set<String>, Long> processMessages(EntityProcessor<R> entityProcessor, Iterator<R> messageIterator, long sinceTime, String clientName) {
        Set<String> entityGuids = new HashSet<>();
        Stopwatch stopwatch = Stopwatch.createStarted();
        while (messageIterator.hasNext()) {
            try {
                R entity = messageIterator.next();
                LOGGER.info("Received {} entity with guid {} for client {}", entityProcessor.getEntityType(), entityProcessor.getGuid(entity), clientName);

                //update entities for primaryData flag
                R updatedEntity = entityProcessor.processEntity(entity);


                String entityGuid = dataWorkspaceDAO.insertRecord(updatedEntity);
                long entityOriginTime = entityProcessor.getEntityEpochOriginTime(updatedEntity);
                if (sinceTime < entityOriginTime) {
                    sinceTime = entityOriginTime;
                }
                entityGuids.add(entityGuid);
                LOGGER.info("method=processMessages hubEntity={}", entityProcessor.getEntityType());
            } catch (Exception ex) {
                LOGGER.error("method=processMessages hubEntityErr={} GRPC request failed: {}", entityProcessor.getEntityType(), ex.getMessage(), ex);
            }
        }
        if (!entityGuids.isEmpty()) {
            LOGGER.info("Successfully persisted {} {} type entities.", entityGuids.size(), entityProcessor.getEntityType());
        }
        publishLatency(entityProcessor, stopwatch.elapsed(TimeUnit.MILLISECONDS));
        return Pair.of(entityGuids, sinceTime);
    }

    private <R extends Message> void publishLatency(EntityProcessor<R> entityProcessor, long elapsed) {
        try {
            Timer timer = registry.timer(AppConstants.GET_ENTITY_SINCE, "entity_type", entityProcessor.getEntityType());
            timer.record(elapsed, TimeUnit.MILLISECONDS);
        } catch (Exception e) {
            LOGGER.error("Failed to publish {} grpc processing latency", entityProcessor.getEntityType());
        }
    }

    protected <S extends AbstractStub<S>> S getStubWithInterceptor(AbstractStub<S> serviceStub, ClientInfo clientInfo) {
        //Set auth metadata
        String basicAuthPayload = "Basic " + clientInfo.getAuthMetadata().trim();
        Metadata authMetadata = new Metadata();
        authMetadata.put(Metadata.Key.of("Authorization", Metadata.ASCII_STRING_MARSHALLER), basicAuthPayload);
        ClientInterceptor clientInterceptor = MetadataUtils.newAttachHeadersInterceptor(authMetadata);
        return serviceStub.withInterceptors(clientInterceptor);
    }

    private <T extends Message> Iterator<T> filter(Iterator<T> iterator,
                                                   String serverMode,
                                                   EntityType entityType) throws ADLException, InvalidProtocolBufferException {
        ADLResultSet<ADLObject> adlObjectList = dataWorkspaceDAO.fetchADLRecordInWindow(SOURCE, serverMode, entityType);
        List<T> protos = new ArrayList<>();
        while (iterator.hasNext()) {
            T proto = iterator.next();
            if (!this.circuitBreakerHelper.checkCircuitBreaker(proto, adlObjectList, entityType)) {
                protos.add(proto);
            }
        }
        return protos.iterator();
    }

}
