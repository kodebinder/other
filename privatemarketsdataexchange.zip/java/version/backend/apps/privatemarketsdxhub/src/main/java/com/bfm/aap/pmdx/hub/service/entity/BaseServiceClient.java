package com.bfm.aap.pmdx.hub.service.entity;

import com.google.common.base.Stopwatch;
import com.google.protobuf.Message;
import com.google.protobuf.util.Timestamps;
import io.grpc.ClientInterceptor;
import io.grpc.ManagedChannel;
import io.grpc.Metadata;
import io.grpc.Status;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.AbstractStub;
import io.grpc.stub.MetadataUtils;
import io.micrometer.core.instrument.Timer;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import static com.bfm.aap.pmdx.hub.util.AppConstants.NETWORK_MODE;
import static com.bfm.util.BFMDateConstants.FMT_ISODateTime;
import static com.google.protobuf.util.Timestamps.fromMillis;
import static java.text.MessageFormat.format;

import com.bfm.aap.pmdx.hub.model.ExecutionStatus;
import com.bfm.aap.pmdx.hub.model.async.TaskResult;
import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.hub.util.AppConstants;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.metric.StatCollectorMeterRegistry;
import com.bfm.util.BFMTimestamp;
import com.bfm.util.Pair;

public abstract class BaseServiceClient<T extends Message, S extends AbstractStub<S>> {

    private static final Logger LOGGER = LoggerFactory.getLogger(BaseServiceClient.class);
    protected AbstractStub<S> serviceStub;
    protected final ManagedChannel channel;
    protected final String serviceName;
    protected final NetworkMode networkMode;
    protected final AltsDataWorkspaceDAO dataWorkspaceDAO;
    protected final EntityType entityType;
    protected final EntityProcessor<T> entityProcessor;

    protected StatCollectorMeterRegistry registry = StatCollectorMeterRegistry.getInstance();


    public BaseServiceClient(ManagedChannel channel, String serviceName,
                             AltsDataWorkspaceDAO dataWorkspaceDAO, EntityType entityType,
                             EntityProcessor<T> entityProcessor) {
        this.channel = channel;
        this.serviceName = serviceName;
        this.dataWorkspaceDAO = dataWorkspaceDAO;
        this.entityType = entityType;
        this.entityProcessor = entityProcessor;
        this.networkMode = NETWORK_MODE;
    }

    @Value("${grpc.unary-call-timeout-millis:120000}")
    protected int unaryCallTimeoutMillis;

    public TaskResult<Set<String>> fetchEntitiesSince(long sinceTime, ClientInfo client, InvestUtils.DataSource dataSource) {
        String exceptionMessage = "";
        try {
            Iterator<T> iterator = initiateSingleBlockingRequest(sinceTime, client, dataSource);
            Pair<Set<String>, Long> guidTimePair = processMessages(iterator, sinceTime, client.getClientName());
            return new TaskResult<>(guidTimePair.getFirstValue(), guidTimePair.getSecondValue());
        } catch (StatusRuntimeException ex) {
            Status exStatus = ex.getStatus();
            exceptionMessage = format("{0}:GRPC request failed with status: {1}", serviceName, StringUtils.defaultString(exStatus.getDescription(), ex.getMessage()));
            LOGGER.error(exceptionMessage, ex);
        } catch (Exception ex) {
            exceptionMessage = format("GRPC request failed: {0}", ex.getMessage());
            LOGGER.error(exceptionMessage, ex);
        }
        return new TaskResult<Set<String>>(Collections.EMPTY_SET, ExecutionStatus.EXCEPTION, exceptionMessage, sinceTime);
    }

    protected Pair<Set<String>, Long> processMessages(Iterator<T> messageIterator, long sinceTime, String clientName) {
        Set<String> entityGuids = new HashSet<>();
        Stopwatch stopwatch = Stopwatch.createStarted();
        while(messageIterator.hasNext()){
            try {
                T entity = messageIterator.next();
                LOGGER.info("received {} message for client:{} with guid/id: {}", entityType.name(), clientName, getEntityGuid(entity));

                //update entities for primaryData flag
                T updatedEntity = entityProcessor.processEntity(entity);
                String entityGuid = dataWorkspaceDAO.insertRecord(updatedEntity);
                long entityOriginTime = entityProcessor.getEntityEpochOriginTime(updatedEntity);
                if(sinceTime < entityOriginTime){
                    sinceTime = entityOriginTime;
                }
                entityGuids.add(entityGuid);
                LOGGER.info("method=processMessages hubEntity={}, sinceTime={}", this.entityType, sinceTime);
            } catch (Exception ex) {
                LOGGER.error("method=processMessages hubEntityErr={} GRPC request failed: {}", this.entityType,ex.getMessage(), ex);
            }
        }
        if(!entityGuids.isEmpty()){
            LOGGER.info("Successfully persisted {} {} with networkMode: {}",entityGuids.size(), entityType.name(),  networkMode.name());
        }
        LOGGER.info("Max originTime received for {} is localtime {}, GMT time:{}",
                entityType.name(),
                new BFMTimestamp(sinceTime, TimeUnit.MILLISECONDS).toBFMDateTime().fmt(FMT_ISODateTime),
                Timestamps.toString(fromMillis(sinceTime)));
        publishLatency(stopwatch.elapsed(TimeUnit.MILLISECONDS));
        return Pair.of(entityGuids, sinceTime);
    }

    private void publishLatency(long elapsed) {
        try {
            Timer timer = registry.timer(AppConstants.GET_ENTITY_SINCE, "entity_type", entityType.name());
            timer.record(elapsed, TimeUnit.MILLISECONDS);
        } catch (Exception e) {
            LOGGER.error("Failed to publish {} grpc processing latency", entityType.name());
        }
    }

    protected AbstractStub<S> getStubWithInterceptor(ClientInfo clientInfo) {
        //Set auth metadata
        String basicAuthPayload = "Basic " + clientInfo.getAuthMetadata().trim();
        Metadata authMetadata = new Metadata();
        authMetadata.put(Metadata.Key.of("Authorization", Metadata.ASCII_STRING_MARSHALLER), basicAuthPayload);
        ClientInterceptor clientInterceptor = MetadataUtils.newAttachHeadersInterceptor(authMetadata);
        return serviceStub.withInterceptors(clientInterceptor);
    }

    abstract Iterator<T> initiateSingleBlockingRequest(long sinceTime, ClientInfo client, InvestUtils.DataSource dataSource);
    abstract String getEntityGuid(T entity);
}
