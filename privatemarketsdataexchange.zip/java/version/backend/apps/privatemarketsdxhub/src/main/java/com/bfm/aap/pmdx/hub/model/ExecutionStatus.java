package com.bfm.aap.pmdx.hub.model;

public enum ExecutionStatus {
    INITIATED,
    EXCEPTION,
    IN_PROGRESS,
    COMPLETED,
    CHANNEL_NOT_READY
}
