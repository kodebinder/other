package com.bfm.aap.pmdx.hub.repository;

public final class ADLConstants {

    public static final String VERSION = "version";
    public static final String REPO_NAME = "AlternativesDataWorkspace";
    public static final String APP_NAME = "A4A";
    public static final String GUID = "gUID";
    public static final String NETWORK_MODE = "networkMode";
    public static final String DATA_PRIMARY_INDEX = "idxPrimary";
    public static final String DATA_SECONDARY_INDEX = "idxModifiedTime";
    public static final String LAST_MODIFIED_TIME = "lastModifiedTime";
    public static final String EDX_DATA = "edxData";
    public static final String CLIENT = "client";
    public static final String ENTITY_TYPE = "entityType";
    public static final String VERSION_1 = "1.0";
    public static final byte[] EMPTY_BYTES = new byte[0];
    public static final String SOURCE = "source";
    public static final String ENTITY_ID = "entityID";

    private ADLConstants() {}
}
