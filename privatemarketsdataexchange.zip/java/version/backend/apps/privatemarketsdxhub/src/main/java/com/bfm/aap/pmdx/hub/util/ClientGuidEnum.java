package com.bfm.aap.pmdx.hub.util;

import java.util.Arrays;

public enum ClientGuidEnum {
    ALADDIN_DEMO("8d7203f6-e72c-4060-abcd-d71230c39f98"),
    ALADDIN_INVEST_DEMO("5b2a4bb4-f727-4f02-b930-80604aa75183"),
    VELLIV("6683bd42-528c-11ea-8d77-2e728ce88125"),
    ALADDINDEV("18b9482e-d6c9-4265-bfa9-08cd1af33947"),
    ALADDINTST("8abef37f-2cd4-4e27-9746-fce049a63eeb");

    private String guid;

    ClientGuidEnum (String guid) {
        this.guid = guid;
    }

    public String getGuid() {
        return this.guid;
    }

    public static ClientGuidEnum findGuidEnum(String clientName) {
        return  Arrays.stream(values())
                .filter(enumRecord -> enumRecord.name().equalsIgnoreCase(clientName))
                .findFirst().orElse(null);
    }
}
