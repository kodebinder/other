package com.bfm.aap.pmdx.hub.util;

import static com.bfm.aap.pmdx.hub.util.AppConstants.NETWORK_MODE;

import java.time.Instant;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.adl.ADLException;
import com.bfm.util.BFMDate;
import com.bfm.util.BFMDateTime;

@Service
public class HubServiceUtil {

    private final AltsDataWorkspaceDAO altsDataWorkspaceDAO;

    @Autowired
    public HubServiceUtil(AltsDataWorkspaceDAO altsDataWorkspaceDAO) {
        this.altsDataWorkspaceDAO = altsDataWorkspaceDAO;
    }

    public long getLastSuccessfulTime(String clientName, ServiceEnum serviceEnum) throws ADLException {
        if(ServiceEnum.CRM.equals(serviceEnum)) {
            BFMDate startDate = new BFMDate("01/01/2020", BFMDate.FMT_Slash0);
            BFMDateTime dateTime = new BFMDateTime(startDate);
            return dateTime.toJavaTime();
        } else if(ServiceEnum.INVESTMENTS.equals(serviceEnum)) {
            ClientGuidEnum guid = ClientGuidEnum.findGuidEnum(clientName);
            if(guid!=null) {
                return altsDataWorkspaceDAO.fetchLastSuccessfulTime(NETWORK_MODE, guid.getGuid());
            }
        }
        return Instant.EPOCH.toEpochMilli();
    }

    public static <T> CompletableFuture<T> timeoutAfter(ScheduledExecutorService es,
                                                        long timeout, TimeUnit unit, CompletableFuture<T> f) {
        es.schedule(() -> f.get(timeout, unit), timeout, unit);
        return f;
    }

}
