package com.bfm.aap.pmdx.hub.model;

import com.bfm.aap.pmdx.hub.service.entity.EntityService;

import java.util.concurrent.ExecutorService;

public class ServiceClientExecutor {
    private EntityService serviceClient;
    private ExecutorService executorService;

    public ServiceClientExecutor(EntityService serviceClient, ExecutorService executorService) {
        this.serviceClient = serviceClient;
        this.executorService = executorService;
    }

    public EntityService getServiceClient() {
        return serviceClient;
    }

    public ExecutorService getExecutorService() {
        return executorService;
    }
}
