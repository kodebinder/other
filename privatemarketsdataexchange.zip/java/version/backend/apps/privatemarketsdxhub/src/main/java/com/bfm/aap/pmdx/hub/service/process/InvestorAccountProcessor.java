package com.bfm.aap.pmdx.hub.service.process;

import com.bfm.aap.pmdx.model.InvestorAccount;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.bfm.aap.pmdx.model.util.InvestorAccountUtil;
import com.google.protobuf.util.Timestamps;
import org.springframework.stereotype.Service;

@Service
public class InvestorAccountProcessor extends EntityProcessor<InvestorAccount> {

    @Override
    public long getEntityEpochOriginTime(InvestorAccount entity) {
        return Timestamps.toMillis(entity.getEntityInfo().getOriginTimestamp());
    }

    @Override
    InvestorAccount updatePrimaryFlag(InvestorAccount entity, boolean isPrimary) {
        InvestorAccount.Builder investorAccountBuilder = InvestorAccount.newBuilder(entity);
        investorAccountBuilder.getEntityInfoBuilder().setPrimaryData(isPrimary);
        return investorAccountBuilder.build();
    }

    @Override
    EntityInfo getEntityInfo(InvestorAccount entity) {
        return entity.getEntityInfo();
    }

    @Override
    public String getGuid(InvestorAccount entity) {
        return InvestorAccountUtil.getInvestorAccountGuid(entity);
    }

    @Override
    boolean isPrimary(InvestorAccount entity) {
        return entity.getEntityInfo().getPrimaryData();
    }

    @Override
    public String getEntityType() {
        return InvestorAccount.class.getSimpleName();
    }
}
