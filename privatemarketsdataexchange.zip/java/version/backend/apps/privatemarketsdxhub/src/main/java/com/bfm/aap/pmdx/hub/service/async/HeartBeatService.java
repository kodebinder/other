package com.bfm.aap.pmdx.hub.service.async;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.ImmutableMap;
import io.grpc.ConnectivityState;
import io.grpc.ManagedChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Service;

import javax.annotation.PreDestroy;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import com.bfm.aap.pmdx.hub.repository.ClientInfoDAO;
import com.bfm.aap.pmdx.hub.util.ServiceEnum;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.EntityService;
import com.bfm.aap.pmdx.model.util.ServerContext;
import com.bfm.util.beans.CollectionUtils;

/**
 * Persists heartbeat for the server every 5 minutes.
 * Along with the heartbeat, it also checks if other servers are dead.
 * Automatically rebalances the clients across servers using ADL storage.
 * Distributed lock is acquired when updating the heartbeat in hub context (ADL storage)
 */
@Service
@DependsOn({"batchProcessor"})
public class HeartBeatService implements Runnable {

    private static final Logger LOGGER = LoggerFactory.getLogger(HeartBeatService.class);

    private final BatchProcessor batchProcessor;
    private final ClientInfoDAO clientInfoDAO;
    private final ManagedChannel channel;
    private ScheduledExecutorService heartBeatExecutor;
    private CountDownLatch terminatedLatch;
    private final ZookeeperHelper zookeeperHelper;
    private final Map<String, Map<String, String>> clientToEntityServicePathMap;
    private final Set<ClientInfo> toBeProcessedClients = new HashSet<>();

    private int heartBeatIntervalMillis;

    @Autowired
    public HeartBeatService(BatchProcessor batchProcessor, ManagedChannel channel, ClientInfoDAO clientInfoDAO,
                            ZookeeperHelper zookeperHelper) {
        this.batchProcessor = batchProcessor;
        this.clientInfoDAO = clientInfoDAO;
        this.channel = channel;
        this.zookeeperHelper = zookeperHelper;
        this.clientToEntityServicePathMap = ImmutableMap.copyOf(buildClientToEntityServicePathMap(clientInfoDAO));
    }

    public Map<String, Map<String, String>> buildClientToEntityServicePathMap(ClientInfoDAO clientInfoDAO) {
        return clientInfoDAO.getAllClients()
                .stream()
                .collect(Collectors.toConcurrentMap(ClientInfo::getClientName,
                        client -> client.getEntityServiceList()
                                .stream()
                                .collect(Collectors.toMap(EntityService::getServiceName,
                                        entityService -> this.zookeeperHelper.getClientPath(client.getClientName(),
                                                ServiceEnum.findService(entityService.getServiceName()))))));

    }

    public void start(int interval) {
        if (interval == 0) {
            LOGGER.error("Failed to get valid value for heartbeat interval: {} ", interval);
            throw new IllegalArgumentException("Error while starting the investments scheduler");
        }
        heartBeatIntervalMillis = interval;
        if (heartBeatExecutor == null || heartBeatExecutor.isShutdown()) {
            LOGGER.info("Starting heart beat with batch processor...");
            terminatedLatch = new CountDownLatch(1);
            heartBeatExecutor = Executors.newSingleThreadScheduledExecutor(runnable -> new Thread(runnable, "HeartBeatThread"));
            heartBeatExecutor.scheduleAtFixedRate(this, 0, heartBeatIntervalMillis, TimeUnit.MILLISECONDS);
        }
    }

    public void stop() {
        if (heartBeatExecutor != null && !heartBeatExecutor.isShutdown()) {
            LOGGER.info("Shutting down heart beat with batch processor..");
            //shutdown immediately
            terminatedLatch.countDown();
            heartBeatExecutor.shutdownNow();
        }
    }

    @PreDestroy
    public void destroy() {
        if (heartBeatExecutor != null && !heartBeatExecutor.isShutdown())
            heartBeatExecutor.shutdownNow();
    }

    @Override
    public void run() {
        try {
            ServerContext serverContext = zookeeperHelper.getServerContextFromDefaultZKPath();
            //TODO whatif the lock is not acquired. Also Zookeeper methods needs return
            zookeeperHelper.lockUpdateSeverContext(serverContext, clientInfoDAO.getAllClients());
            if(isChannelReady()) {
                toBeProcessedClients.addAll(zookeeperHelper.getClientsForProcessing(clientToEntityServicePathMap, heartBeatIntervalMillis));
            }
            // Why is the batch processing triggered from the HeartBeatService? It has nothing to do with heartbeats.
            //run batch processor and submit tasks...
            //TODO check logic - toBeProcessedClients
            if (!CollectionUtils.isEmpty(toBeProcessedClients)) {
                LOGGER.info("Submitted clients for batch processing {}", toBeProcessedClients);
                batchProcessor.submitTasks(toBeProcessedClients);
                toBeProcessedClients.clear();
            }
        } catch (Exception ex) {
            LOGGER.error("Failed to run heartbeat task: {} ", ex.getMessage(), ex);
        }
    }

    private boolean isChannelReady() {
        ConnectivityState channelState = getChannelStatus();
        if (!channelState.equals(ConnectivityState.READY)) {
            // retry connection
            channel.resetConnectBackoff();
            channel.getState(true);
            LOGGER.info("Channel not in ready state! :{}", channelState);
            return false;
        }
        return true;
    }

    private ConnectivityState getChannelStatus(){
        return channel.getState(false);
    }

    @VisibleForTesting
    CountDownLatch getTerminatedLatch() {
        return terminatedLatch;
    }

}
