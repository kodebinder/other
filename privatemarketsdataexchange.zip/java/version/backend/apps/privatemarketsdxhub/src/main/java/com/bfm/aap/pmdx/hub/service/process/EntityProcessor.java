package com.bfm.aap.pmdx.hub.service.process;

import com.bfm.aap.pmdx.hub.util.AppConstants;
import com.bfm.aap.pmdx.hub.util.NotificationUtil;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.bfm.aap.pmdx.model.util.LibRedBlueProxy;
import com.bfm.aap.pmdx.notification.model.NotificationEnums;
import com.bfm.aap.pmdx.notification.service.Notification;
import com.bfm.aap.pmdx.redblue.RedBlueNetworkChecker;
import com.bfm.aap.privatemarkets.common.constant.CommonConstants;
import com.bfm.service.ServiceException;
import com.google.protobuf.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static java.text.MessageFormat.format;
import static java.util.stream.Collectors.mapping;
import static java.util.stream.Collectors.toSet;

public abstract class EntityProcessor<T extends Message> {

    protected static final Logger LOGGER = LoggerFactory.getLogger(EntityProcessor.class);
    protected boolean isPrimary;

    @PostConstruct
    public void init() {
        // Initialize RedBlueNetworkChecker with its own DataSource
        RedBlueNetworkChecker.initDataSource();
        isPrimary = LibRedBlueProxy.isCurrentInstancePrimary(CommonConstants.NETWORK_MODE);
    }

    /**
     * Processes the entities by comparing the entity origin timestamp with the red-blue switch
     * timestamp, and accordingly setting the primary data flag.
     *
     * @param entities entities
     * @return List of entities
     */
    public List<T> processEntities(List<T> entities) {

        List<T> updatedEntities = entities.stream()
                .filter(this::handleAndFilterInvalidEntity)
                .map(entity -> this.updatePrimaryFlag(entity, isPrimary))
                .collect(Collectors.toList());

        Map<Boolean, Set<String>> primaryMap = updatedEntities.stream().collect(Collectors.groupingBy(this::isPrimary, mapping(this::getGuid, toSet())));
        LOGGER.info("Primary flag set for below {}: {}", getEntityType(), primaryMap);

        return updatedEntities;
    }

    /**
     * Processes the entity by comparing the entity origin timestamp with the red-blue switch
     * timestamp, and accordingly setting the primary data flag.
     *
     * @param entity entity
     * @return Updated entity
     */
    public T processEntity(T entity) {

        if (handleAndFilterInvalidEntity(entity)) {
            T updatedEntity = updatePrimaryFlag(entity, isPrimary);

            LOGGER.info("Primary flag set for entity {} with guid/id: {}, isPrimary: {}",
                    getEntityType(), getGuid(entity), isPrimary(updatedEntity));
            return updatedEntity;
        } else
            throw new ServiceException(format("Invalid entity info for {0} with guid/id:{1}", getEntityType(), getGuid(entity)));
    }


    protected boolean handleAndFilterInvalidEntity(T entity) {
        final String message;
        EntityInfo entityInfo = getEntityInfo(entity);
        if (!entityInfo.hasOriginTimestamp()) {
            message = format("{0} does not have origin timestamp! Ignoring the entity! guid/id: {1}", entity.getClass(), getGuid(entity));
            LOGGER.error(message);
            Notification.sendNotification(NotificationUtil.getNotificationParams(message, NotificationEnums.NotificationSeverity.RED, null));
            return false;
        } else if (entityInfo.getNetworkMode() != AppConstants.NETWORK_MODE) {
            message = format("Network mode mismatch for {0} with guid/id: {1}", entity.getClass().getSimpleName(), getGuid(entity));
            LOGGER.error(message);
            Notification.sendNotification(NotificationUtil.getNotificationParams(message, NotificationEnums.NotificationSeverity.RED, null));
            return false;
        } else
            return true;
    }

    /**
     * Get the last origin timestamp for successful entites.
     * It sorts the entities in ascending order and fetches the last one.
     *
     * @param entities entities
     * @return last origin timestamp
     */
    public long getLastSuccessfulTime(List<T> entities) {
        T entity = entities.stream()
                .max(Comparator.comparingLong(this::getEntityEpochOriginTime))
                .orElseThrow(RuntimeException::new);

        return getEntityEpochOriginTime(entity);
    }

    abstract EntityInfo getEntityInfo(T entity);

    public abstract long getEntityEpochOriginTime(T entity);

    abstract T updatePrimaryFlag(T entity, boolean isPrimary);

    public abstract String getGuid(T entity);

    abstract boolean isPrimary(T entity);

    public abstract String getEntityType();
}
