package com.bfm.aap.pmdx.hub.service.entity;

import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.pmdx.model.ShareClass;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.aap.pmdx.services.ShareClassRequest;
import com.bfm.aap.pmdx.services.ShareClassServiceGrpc;
import com.bfm.aap.pmdx.services.ShareClassSinceRequest;
import com.bfm.service.ServiceException;
import com.google.protobuf.Timestamp;
import com.google.protobuf.util.Timestamps;
import io.grpc.ManagedChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import static com.google.protobuf.util.Timestamps.fromMillis;

@Service
public class ShareClassServiceClient extends BaseServiceClient<ShareClass, ShareClassServiceGrpc.ShareClassServiceBlockingStub>
    implements EntityService<ShareClass, ShareClassRequest> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ShareClassServiceClient.class);

    @Autowired
    public ShareClassServiceClient(ManagedChannel channel, AltsDataWorkspaceDAO dataWorkspaceDAO, EntityProcessor<ShareClass> entityProcessor) {
        super(channel, ShareClassServiceClient.class.getSimpleName(), dataWorkspaceDAO, EntityType.SHARECLASS, entityProcessor);
        this.serviceStub = ShareClassServiceGrpc.newBlockingStub(channel);
    }

    @Override
    @RecordStats(metricName = "shareClassService_getShareClasssSince", timer = true)
    Iterator<ShareClass> initiateSingleBlockingRequest(long sinceTime, ClientInfo client, InvestUtils.DataSource dataSource) {
        Timestamp sinceTimeTs = fromMillis(sinceTime);
        String timeStamp = Timestamps.toString(sinceTimeTs);
        LOGGER.info("Initiating grpc request for getShareClasssSince for client:{} with time {}",
            client.getClientName(), timeStamp);
        ShareClassSinceRequest request = ShareClassSinceRequest.newBuilder().setTimestamp(sinceTimeTs).build();
        return ((ShareClassServiceGrpc.ShareClassServiceBlockingStub) getStubWithInterceptor(client)).getShareClassSince(request);
    }

    /**
     * Get single entity via unary grpc call.
     *
     * @param entityRequest
     * @return
     * @throws ServiceException
     */

    @Override
    @RecordStats(metricName = "shareClassService_getShareClass", timer = true)
    public ShareClass getEntity(ShareClassRequest entityRequest) {
        try {
            LOGGER.info("Processing single entity request for {}", entityRequest);
            ShareClass shareClass = serviceStub
                .withDeadlineAfter(unaryCallTimeoutMillis, TimeUnit.MILLISECONDS)
                .getShareClass(entityRequest);
            this.dataWorkspaceDAO.insertRecords(Collections.singletonList(shareClass));
            return shareClass;
        } catch (Exception e) {
            throw new ServiceException("Failed to get ShareClass:" + e.getMessage(), e);
        }
    }

    @Override
    String getEntityGuid(ShareClass entity) { return entity.getShareclassId();}
}
