package com.bfm.aap.pmdx.hub.service.security;

import com.bfm.crypt.DecryptionException;

import java.io.File;

public interface FileDecrypterService {

    String decrypt(File passwordFile) throws DecryptionException;
}
