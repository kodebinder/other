package com.bfm.aap.pmdx.hub.service.process;

import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.bfm.aap.pmdx.model.util.InvestorUtil;
import com.google.protobuf.util.Timestamps;
import org.springframework.stereotype.Service;

@Service
public class InvestorProcessor extends EntityProcessor<Investor> {

    @Override
    public long getEntityEpochOriginTime(Investor entity) {
        return Timestamps.toMillis(entity.getEntityInfo().getOriginTimestamp());
    }

    @Override
    Investor updatePrimaryFlag(Investor entity, boolean isPrimary) {
        Investor.Builder crmInvestorBuilder = Investor.newBuilder(entity);
        crmInvestorBuilder.getEntityInfoBuilder().setPrimaryData(isPrimary);
        return crmInvestorBuilder.build();
    }

    @Override
    EntityInfo getEntityInfo(Investor entity) {
        return entity.getEntityInfo();
    }

    @Override
    public String getGuid(Investor entity) {
        return InvestorUtil.getInvestorGuid(entity);
    }

    @Override
    boolean isPrimary(Investor entity) {
        return entity.getEntityInfo().getPrimaryData();
    }

    @Override
    public String getEntityType() {
        return Investor.class.getSimpleName();
    }
}
