package com.bfm.aap.pmdx.hub.service.process;

import com.bfm.aap.pmdx.model.Portfolio;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.google.protobuf.util.Timestamps;
import org.springframework.stereotype.Service;

@Service
public class PortfolioProcessor extends EntityProcessor<Portfolio> {

    @Override
    public long getEntityEpochOriginTime(Portfolio entity) {
        return Timestamps.toMillis(entity.getEntityInfo().getOriginTimestamp());
    }

    @Override
    Portfolio updatePrimaryFlag(Portfolio entity, boolean isPrimary) {
        Portfolio.Builder portfolioBuilder = Portfolio.newBuilder(entity);
        portfolioBuilder.getEntityInfoBuilder().setPrimaryData(isPrimary);
        return portfolioBuilder.build();
    }

    @Override
    EntityInfo getEntityInfo(Portfolio entity) {
        return entity.getEntityInfo();
    }

    @Override
    public String getGuid(Portfolio entity) {
        return entity.getPortfolioId();
    }

    @Override
    boolean isPrimary(Portfolio entity) {
        return entity.getEntityInfo().getPrimaryData();
    }

    @Override
    public String getEntityType() {
        return Portfolio.class.getSimpleName();
    }
}
