package com.bfm.aap.pmdx.hub.service.process;

import com.bfm.aap.pmdx.model.User;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.bfm.aap.pmdx.model.util.UserUtil;
import com.bfm.aap.privatemarkets.common.crm.model.EntityType;
import com.google.protobuf.util.Timestamps;
import org.springframework.stereotype.Service;

@Service
public class UserProcessor extends EntityProcessor<User> {

    @Override
    public long getEntityEpochOriginTime(User entity) {
        return Timestamps.toMillis(entity.getEntityInfo().getOriginTimestamp());
    }

    @Override
    User updatePrimaryFlag(User entity, boolean isPrimary) {
        User.Builder crmUserBuilder = User.newBuilder(entity);
        crmUserBuilder.getEntityInfoBuilder().setPrimaryData(isPrimary);
        return crmUserBuilder.build();
    }

    @Override
    EntityInfo getEntityInfo(User entity) {
        return entity.getEntityInfo();
    }

    @Override
    public String getGuid(User entity) {
        return UserUtil.getUserGuid(entity);
    }

    @Override
    public String getEntityType() {return EntityType.USER.name();}

    @Override
    boolean isPrimary(User entity) {
        return entity.getEntityInfo().getPrimaryData();
    }
}
