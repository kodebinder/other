package com.bfm.aap.pmdx.hub.service.process;

import com.bfm.aap.pmdx.model.BankAccount;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.google.protobuf.util.Timestamps;
import org.springframework.stereotype.Service;

@Service
public class BankAccountProcessor extends EntityProcessor<BankAccount> {
    @Override
    EntityInfo getEntityInfo(BankAccount entity) {
        return entity.getEntityInfo();
    }

    @Override
    public long getEntityEpochOriginTime(BankAccount entity) {
          return Timestamps.toMillis(entity.getEntityInfo().getOriginTimestamp());
    }

    @Override
    BankAccount updatePrimaryFlag(BankAccount entity, boolean isPrimary) {
        BankAccount.Builder bankAccountBuilder = BankAccount.newBuilder(entity);
        bankAccountBuilder.getEntityInfoBuilder().setPrimaryData(isPrimary);
        return bankAccountBuilder.build();
    }

    @Override
    public String getGuid(BankAccount entity) {
        return entity.getEntityBankAccountId();
    }

    @Override
    boolean isPrimary(BankAccount entity) {
        return entity.getEntityInfo().getPrimaryData();
    }

    @Override
    public String getEntityType() {
        return BankAccount.class.getSimpleName();
    }
}
