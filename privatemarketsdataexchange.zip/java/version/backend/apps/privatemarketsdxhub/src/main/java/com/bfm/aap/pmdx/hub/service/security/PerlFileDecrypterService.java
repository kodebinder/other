package com.bfm.aap.pmdx.hub.service.security;

import com.bfm.crypt.DecryptionException;
import com.bfm.crypt.FileDecrypter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.File;

import static java.text.MessageFormat.format;

@Service
public class PerlFileDecrypterService implements FileDecrypterService {

    private static final Logger LOGGER = LoggerFactory.getLogger(PerlFileDecrypterService.class);
    private FileDecrypter fileDecrypter;

    @Value("${security.private-key-name:RSAPrivateKey}")
    private String privateKeyName;

    @Value("${disable-secure-connection:false}")
    private boolean disableSecureConnection;

    @PostConstruct
    public void init() throws DecryptionException {
        if (!disableSecureConnection)
            fileDecrypter = FileDecrypter.Factory.create(privateKeyName);
    }

    @Override
    public String decrypt(File passwordFile) throws DecryptionException {
        LOGGER.info("Trying to decrypt file: {}", passwordFile.getAbsolutePath());
        if (!passwordFile.exists())
            throw new DecryptionException(format("File does not exist to decrypt: {0}", passwordFile.getAbsolutePath()));

        if (disableSecureConnection)
            throw new DecryptionException("File decrypter disabled in non secure mode!");

        return fileDecrypter.decryptAsString(passwordFile);
    }

}
