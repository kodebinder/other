package com.bfm.aap.pmdx.hub.config;

import com.bfm.aap.pmdx.hub.service.PrivateMarketsDXHubService;
import com.bfm.aap.pmdx.hub.service.PrivateMarketsDXHubServiceImpl;
import com.bfm.aap.pmdx.hub.util.AppConstants;
import com.bfm.aap.pmdx.logmetrics.logger.EDXBeam2MetricListener;
import com.bfm.aap.pmdx.model.util.LibRedBlueProxy;
import com.bfm.aap.pmdx.redblue.PmdxServiceType;
import com.bfm.aap.privatemarkets.common.constant.CommonConstants;
import com.bfm.aap.privatemarkets.common.scheduler.TaskScheduler;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperServiceImpl;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.util.CRMThirdPartyMappingHelper;
import com.bfm.beam2.Configs;
import com.bfm.beam2.server.ServiceGateway;
import com.bfm.beam2.server.ServiceGateways;
import com.bfm.beam2.StatusEvent;
import com.bfm.beam2.server.bmsintegration.BmsServiceGateways;
import com.bfm.beam2.event.RequestEvent;
import com.bfm.beam2.permission.PermissionStores;
import com.bfm.metric.beam2.Beam2MetricListener;
import com.bfm.privatemarkets.beam2.util.Proto3JsonConverter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

@Configuration
public class Beam2Config {

    private static final Logger LOGGER = LoggerFactory.getLogger(Beam2Config.class);

    @Bean
    public ServiceGateway serviceGateway() {
        BmsServiceGateways.BmsServiceGatewayConfig config = (new BmsServiceGateways.BmsServiceGatewayConfig())
                .name(AppConstants.APPLICATION_NAME).numberOfWorkers(AppConstants.NUM_WORKER_THREADS)
                .permissionStore(PermissionStores.bfmPermissionsSetStore());
        config.addConverterFactory(Proto3JsonConverter.factory());
        return ServiceGateways.bmsGateway(config);
    }

    @Bean
    public PrivateMarketsDXHubService privateMarketsDXHubService() {
        return new PrivateMarketsDXHubServiceImpl();
    }

    @Bean
    public ServiceGateway privateMarketsDXHubServiceGateway() {
        ServiceGateway serviceGateway = serviceGateway();
        int sourceId = LibRedBlueProxy.getSourceIdByTypeAndColor(PmdxServiceType.PRIVATEMARKETS_DX_HUB, AppConstants.NETWORK_MODE);
        if (System.getProperty(CommonConstants.DX_HUB_SOURCE_ID_OVERRIDE) != null) {
            sourceId = Integer.parseInt(System.getProperty(CommonConstants.DX_HUB_SOURCE_ID_OVERRIDE));
        }
        LOGGER.info("Starting PrivateMarketsDXHubService beam2 service with sourceId:{}", sourceId);
        serviceGateway.register(privateMarketsDXHubService(), Configs.builder().setSourceId(sourceId).build());
        serviceGateway.addStatusListener(Beam2Config::logServiceGatewayEvent);
        serviceGateway.addRequestEventListener(Beam2Config::logRequestEvent);
        final boolean enableTelemetry = Boolean.parseBoolean(System.getProperty("telemetry", "true"));
        if (enableTelemetry) {
            Beam2MetricListener.addListenerToGateway(serviceGateway, new EDXBeam2MetricListener(true));
        }
        LOGGER.info("Beam2 service successfully started..");
        return serviceGateway;
    }

    @Bean(name = "crmThirdPartyMappingHelper")
    public CRMThirdPartyMappingHelper crmThirdPartyMappingHelper() {
        return new CRMThirdPartyMappingHelper();
    }

    @Bean(name = "crmThirdPartyMapperService")
    public CRMThirdPartyMapperService crmThirdPartyMapperService(CRMThirdPartyMappingHelper crmThirdPartyMappingHelper) {
        return new CRMThirdPartyMapperServiceImpl(crmThirdPartyMappingHelper);
    }

    private static void logServiceGatewayEvent(StatusEvent statusEvent) {
        LOGGER.debug("ServiceGateway Event: {}", statusEvent);
    }

    private static void logRequestEvent(RequestEvent requestEvent) {
        LOGGER.debug("Request Event: {}", requestEvent);
    }

    @Bean
    public TaskScheduler taskSchedulerBean() {
        TaskScheduler taskScheduler = new TaskScheduler();
        getFactory().start();
        taskScheduler.setScheduler(getFactory().getScheduler());
        return taskScheduler;
    }

    @Bean
    public SchedulerFactoryBean getFactory() {
        SchedulerFactoryBean factoryBean = new SchedulerFactoryBean();
        factoryBean.setPhase(10);
        factoryBean.setConfigLocation(new ClassPathResource("quartz.properties"));
        return factoryBean;
    }

}
