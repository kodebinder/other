package com.bfm.aap.pmdx.hub.service.entity;

import java.util.Set;

import com.google.protobuf.Message;
import io.grpc.ManagedChannel;
import io.grpc.stub.AbstractStub;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bfm.aap.pmdx.hub.model.async.TaskResult;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.InvestorResponse;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.aap.pmdx.services.InvestorRequest;
import com.bfm.aap.pmdx.services.InvestorServiceGrpc;
import com.bfm.aap.pmdx.services.InvestorServiceGrpc.InvestorServiceBlockingStub;
import com.bfm.service.ServiceException;

import static com.google.protobuf.util.Timestamps.fromMillis;

@Service
public class InvestorServiceClient implements EntityService {

	private static final Logger LOGGER = LoggerFactory.getLogger(InvestorServiceClient.class);
	private final RPCServiceClient rpcServiceClient;
	private final EntityProcessor<Investor> investorEntityProcessor;
	private final AbstractStub<InvestorServiceBlockingStub> investorServiceStub;

	@Autowired
	public InvestorServiceClient(RPCServiceClient rpcServiceClient, ManagedChannel channel,
			EntityProcessor<Investor> entityProcessor) {
		this.rpcServiceClient = rpcServiceClient;
		this.investorEntityProcessor = entityProcessor;
		this.investorServiceStub = InvestorServiceGrpc.newBlockingStub(channel);
	}

	@Override
	public Message getEntity(Message entityRequest) {
		throw new UnsupportedOperationException();
	}

	@Override
	@RecordStats(metricName = "InvestorService_getInvestorSince", timer = true)
	public TaskResult<Set<String>> fetchEntitiesSince(long lastSuccessfulTime, ClientInfo clientInfo, InvestUtils.DataSource dataSource) {
		InvestorRequest investorRequest = InvestorRequest.newBuilder().setTimestamp(fromMillis(lastSuccessfulTime))
				.build();

		return rpcServiceClient.doFetchSince(InvestorServiceBlockingStub::getInvestorSince, investorServiceStub,
				investorRequest, investorEntityProcessor, clientInfo, lastSuccessfulTime);
	}

	public String updateInvestor(InvestorRequest investorRequest, ClientInfo clientInfo, Integer crmEntityId) {
		String entityId = StringUtils.EMPTY;
		LOGGER.info("Processing Investor entity request for update");
		try {
			InvestorServiceBlockingStub investorServiceBlockingStub = rpcServiceClient
				.getStubWithInterceptor(investorServiceStub, clientInfo);
			InvestorResponse response = investorServiceBlockingStub.updateInvestor(investorRequest);
			LOGGER.info("Investor entity {} {}", crmEntityId, response.getIsUpdated() ? "updated successfully." : "failed to update.");
			if (response.getIsUpdated()) {
				entityId = response.getData().getInvestorId();
			} else {
				LOGGER.info("Investor request : {}", investorRequest);
				LOGGER.info("Investor request : {}", response);
			}
			return entityId;
		} catch (Exception e) {
			throw new ServiceException("Investor gRPC request failed with status: " + e.getMessage(), e);
		}
	}
}