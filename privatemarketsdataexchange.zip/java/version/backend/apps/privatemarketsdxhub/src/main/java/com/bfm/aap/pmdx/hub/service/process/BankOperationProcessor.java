package com.bfm.aap.pmdx.hub.service.process;

import com.bfm.aap.pmdx.model.BankOperation;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.google.protobuf.util.Timestamps;
import org.springframework.stereotype.Service;

@Service
public class BankOperationProcessor  extends EntityProcessor<BankOperation>  {
    @Override
    EntityInfo getEntityInfo(BankOperation entity) {
        return entity.getEntityInfo();
    }

    @Override
    public long getEntityEpochOriginTime(BankOperation entity) {
        return Timestamps.toMillis(entity.getEntityInfo().getOriginTimestamp());
    }

    @Override
    BankOperation updatePrimaryFlag(BankOperation entity, boolean isPrimary) {
        BankOperation.Builder bankOperationBuilder = BankOperation.newBuilder(entity);
        bankOperationBuilder.getEntityInfoBuilder().setPrimaryData(isPrimary);
        if(bankOperationBuilder.hasEntityBankAccount() && bankOperationBuilder.getEntityBankAccount().hasEntityInfo()){
            bankOperationBuilder.getEntityBankAccountBuilder().getEntityInfoBuilder().setPrimaryData(isPrimary);
        }
        if(bankOperationBuilder.hasCounterpartyBankAccount() && bankOperationBuilder.getCounterpartyBankAccount().hasEntityInfo()){
            bankOperationBuilder.getCounterpartyBankAccountBuilder().getEntityInfoBuilder().setPrimaryData(isPrimary);
        }
        return bankOperationBuilder.build();
    }

    @Override
    public String getGuid(BankOperation entity) {
        return entity.getBankOperationId();
    }

    @Override
    boolean isPrimary(BankOperation entity) {
       return entity.getEntityInfo().getPrimaryData();
    }

    @Override
    public String getEntityType() {
        return BankOperation.class.getSimpleName();
    }
}
