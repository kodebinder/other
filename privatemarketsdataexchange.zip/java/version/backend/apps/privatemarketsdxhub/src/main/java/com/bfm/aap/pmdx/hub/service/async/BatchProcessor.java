package com.bfm.aap.pmdx.hub.service.async;

import com.google.protobuf.util.Timestamps;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import com.bfm.aap.pmdx.hub.model.ExecutionStatus;
import com.bfm.aap.pmdx.hub.model.async.TaskResult;
import com.bfm.aap.pmdx.hub.service.entity.EfrontPingClient;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.EntityService;
import com.bfm.aap.pmdx.model.util.InvestUtils;

/**
 * Batch Processor, which submits async batch tasks for clients.
 */
@Service
public class BatchProcessor {

    private static final Logger LOGGER = LoggerFactory.getLogger(BatchProcessor.class);
    private final BatchTask batchTask;
    private final EfrontPingClient efrontPingClient;
    private ExecutorService batchExecutor;
    private ScheduledExecutorService pingExecutor;
    private AtomicInteger threadCount = new AtomicInteger(0);
    private AtomicInteger currentRunningTasks = new AtomicInteger(0);
    private Set<String> allClients = Collections.synchronizedSet(new HashSet<>());
    private Map<String, ExecutionStatus> processedClients = new ConcurrentHashMap<>();

    @Value("${gprc.concurrent-batch-count:5}")
    private int concurrentBatchCount;

    @Value("${server.heart-beat-interval-millis:300000}")  //5 mins
    private int heartBeatIntervalMillis;


    @Autowired
    public BatchProcessor(BatchTask batchTask, EfrontPingClient efrontPingClient) {
        this.batchTask = batchTask;
        this.efrontPingClient = efrontPingClient;
    }

    @PostConstruct
    public void init() {
        batchExecutor = Executors.newFixedThreadPool(concurrentBatchCount, runnable -> new Thread(runnable, "BatchPool-thread-" + threadCount.incrementAndGet()));
        pingExecutor = Executors.newSingleThreadScheduledExecutor(runnable -> new Thread(runnable, "PingThread"));
        pingExecutor.scheduleAtFixedRate(this::pingTask, 1000, heartBeatIntervalMillis, TimeUnit.MILLISECONDS);
    }

    @PreDestroy
    public void destroy() throws InterruptedException {
        this.batchExecutor.shutdown();
        if (!batchExecutor.awaitTermination(60, TimeUnit.MILLISECONDS)) {
            batchExecutor.shutdownNow();
        }
        this.pingExecutor.shutdownNow();
    }


    public void pingTask() {
        ClientInfo pingClient = ClientInfo.newBuilder()
                .setClientName("Ping")
                .setClientId("PING")
                .setCredentialsFileName("dummy").build();
        TaskResult<Set<String>> result = efrontPingClient.fetchEntitiesSince(System.currentTimeMillis(), pingClient, InvestUtils.DataSource.UNRECOGNIZED);
        LOGGER.info("Ping service reply:{}", result.getResult());
    }


    /**
     * Submit batch fetch tasks for clients.
     * Run is dispatch based on currently running batch count.
     *
     * @param runnableClients
     */
    public void submitTasks(Collection<ClientInfo> runnableClients) {
        int maxRunnable = concurrentBatchCount - currentRunningTasks.get();
        Set<String> clientNames = runnableClients.stream().map(ClientInfo::getClientName).filter(StringUtils::isNotEmpty).collect(Collectors.toSet());
        if (maxRunnable > 0) {
            for (String clientName : clientNames) {
                Optional<ClientInfo> clientInfoZK = runnableClients.stream().filter(info -> info.getClientName().equalsIgnoreCase(clientName)).findFirst();
                if(!clientInfoZK.isPresent() || clientInfoZK.get().getEntityServiceList().isEmpty()
                        || clientInfoZK.get().getEntityService(0) == null) {
                    LOGGER.error("Client {} has entity service level data missing. Please check.", clientInfoZK);
                    continue;
                }

                Optional<EntityService> defaultServiceZK = clientInfoZK.get().getEntityServiceList()
                        .stream()
                        .filter(service->service.getServiceName().equalsIgnoreCase("ALL"))
                        .findFirst();

                Long defaultLastSuccessfulTime = defaultServiceZK.isPresent() ? Timestamps.toMillis(defaultServiceZK.get().getLastSuccessfulTime()) : 0L;

                CompletableFuture.runAsync(() -> batchTask.submitTask(clientName, defaultLastSuccessfulTime, currentRunningTasks, processedClients, clientInfoZK.get()), batchExecutor);
                processedClients.put(clientInfoZK.get().getClientName(), ExecutionStatus.IN_PROGRESS);
                maxRunnable--;
                if (maxRunnable == 0) break;
            }
        }
    }

    public Set<String> getAllClients() {
        return allClients;
    }

    public Map<String, ExecutionStatus> getProcessedClients() {
        return processedClients;
    }
}
