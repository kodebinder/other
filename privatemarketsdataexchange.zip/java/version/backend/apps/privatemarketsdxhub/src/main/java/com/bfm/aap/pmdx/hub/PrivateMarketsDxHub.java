package com.bfm.aap.pmdx.hub;

import com.bfm.aap.pmdx.hub.model.CertHelper;
import com.bfm.aap.pmdx.hub.service.GRPCChannelManager;
import com.bfm.aap.pmdx.hub.service.async.ZookeeperHelper;
import com.bfm.aap.pmdx.hub.service.entity.BaseServiceClient;
import com.bfm.aap.pmdx.hub.util.AppConstants;
import com.bfm.aap.pmdx.hub.util.NotificationUtil;
import com.bfm.aap.pmdx.logmetrics.logger.DefaultLoggerConfig;
import com.bfm.aap.pmdx.notification.model.NotificationEnums;
import com.bfm.aap.pmdx.notification.model.NotificationParams;
import com.bfm.aap.pmdx.notification.service.Notification;
import com.bfm.aap.pmdx.security.PMDXTrustManagerFactory;
import com.bfm.aap.pmdx.util.GuavaBytecodeManipulator;
import com.bfm.util.BFMUtil;
import io.grpc.ConnectivityState;
import io.grpc.ManagedChannel;
import io.grpc.netty.shaded.io.grpc.netty.GrpcSslContexts;
import io.grpc.netty.shaded.io.grpc.netty.NettyChannelBuilder;
import io.grpc.netty.shaded.io.netty.handler.ssl.SslContext;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.SystemUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.BeanInitializationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.cassandra.CassandraAutoConfiguration;
import org.springframework.boot.autoconfigure.freemarker.FreeMarkerAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.kafka.KafkaAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Import;
import org.springframework.context.event.EventListener;

import javax.net.ssl.SSLException;
import javax.net.ssl.TrustManagerFactory;
import java.nio.file.Path;
import java.util.List;

import static com.bfm.aap.pmdx.hub.util.AppConstants.ENTITY_STATE;
import static com.bfm.aap.pmdx.hub.util.AppConstants.NETWORK_MODE;

@SpringBootApplication
@EnableAutoConfiguration(exclude = {CassandraAutoConfiguration.class, KafkaAutoConfiguration.class, DataSourceAutoConfiguration.class, DataSourceTransactionManagerAutoConfiguration.class, HibernateJpaAutoConfiguration.class, FreeMarkerAutoConfiguration.class})
@Import({DefaultLoggerConfig.class})
public class PrivateMarketsDxHub {
    private static final Logger LOGGER = LoggerFactory.getLogger(PrivateMarketsDxHub.class);

    @Autowired
    private ZookeeperHelper zookeeperHelper;

    @Value("${disable-secure-connection:false}")
    private boolean disableSecureConnection;

    @Bean("channel")
    @DependsOn({"clientInfoDAOImpl"})
    public ManagedChannel channel() throws SSLException {
        // Get the host and port from BFM tokens
        String host = BFMUtil.getBfmToken(AppConstants.HOST_TOKEN).trim();
        String portString = BFMUtil.getBfmToken(AppConstants.PORT_TOKEN).trim();
        LOGGER.info("Host:{} \t Port:{}", host, portString);
        // Get the environment from BFM Token / env.name variable
        final String environment = StringUtils.defaultString(BFMUtil.getBfmToken("ClientAbbrev"), AppConstants.ENV_NAME);
        if (StringUtils.isEmpty(environment)) {
            throw new BeanInitializationException("Failed to get environment");
        }

        // Option to override the service endpoint for local testing
        if (SystemUtils.IS_OS_WINDOWS || SystemUtils.IS_OS_MAC) {
            host = System.getProperty("EFRONT_DXPROVIDER_HOST", host);
            portString = System.getProperty("EFRONT_DXPROVIDER_PORT", portString);
        }

        if (StringUtils.isEmpty(host) || StringUtils.isEmpty(portString)) {
            LOGGER.error("Failed to get host/port from BFMToken! host:{},  port:{}", host, portString);
            throw new BeanCreationException("Invalid host/port!");
        }

        final int port = Integer.parseInt(portString);
        LOGGER.info("Establishing secure channel connection with host:{} and port:{}", host, port);

        // Add bouncy castle to support multiple formats of SSL certificates
        java.security.Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());

        // Option to override security (only in pre prod envs)
        final boolean useInsecureConnection = disableSecureConnection && AppConstants.IS_PRE_PROD_CLIENT;

        if (useInsecureConnection) {
            LOGGER.warn("Using insecure connection.. using plain text channel!");
            return NettyChannelBuilder.forAddress(host, port).usePlaintext().build();
        }
        return NettyChannelBuilder.forAddress(host, port)
                .enableRetry()
                .sslContext(buildSslContext())
                .build();
    }

    /**
     * Build ssl context with mutual TLS.
     */
    private SslContext buildSslContext() throws SSLException {
        final Path privateKeyPath = CertHelper.getPrivateKeyPath();
        final Path certPath = CertHelper.getCertPath();
        final Path trustCaPath = CertHelper.getCaPath();
        final TrustManagerFactory trustManagerFactory = new PMDXTrustManagerFactory(trustCaPath.toString());

        LOGGER.info("Securely connecting with CA:{}, Key:{}, Cert:{}", trustCaPath.toAbsolutePath(), privateKeyPath.toAbsolutePath(), certPath.toAbsolutePath());
        return GrpcSslContexts.forClient()
                .trustManager(trustManagerFactory)
                .protocols("TLSv1.2", "TLSv1.3")
                .keyManager(certPath.toFile(), privateKeyPath.toFile())
                .build();
    }

    @Autowired
    private GRPCChannelManager grpcChannelManager;

    @Autowired
    private List<BaseServiceClient> serviceClients;

    public static void main(final String[] args) throws InterruptedException {
        LOGGER.info("Starting PrivateMarketsDXHub.. NetworkMode:{}, EntityState:{}, Instance ID:{}", NETWORK_MODE, ENTITY_STATE, AppConstants.INSTANCE_ID);
        GuavaBytecodeManipulator.manipulateClasses();
        final ConfigurableApplicationContext applicationContext = SpringApplication.run(PrivateMarketsDxHub.class, args);
        final GRPCChannelManager channelManager = applicationContext.getBean(GRPCChannelManager.class);
        final ManagedChannel channel = applicationContext.getBean(ManagedChannel.class);
        applicationContext.registerShutdownHook();
        while (true) {
            //Wait for 10 mins and monitor for channel status
            Thread.sleep(channelManager.getChannelRetryInterval());
            channelManager.getTerminatedLatch().await();
            LOGGER.info("Channel failure... trying to re-connect");
            final ConnectivityState currentState = channel.getState(true);
            if (ConnectivityState.SHUTDOWN.equals(currentState)) {
                final String message = "Channel shutdown (non-recoverable state)... stopping server. ";
                LOGGER.info(message);
                Notification.sendNotification(NotificationUtil.getNotificationParams(message, NotificationEnums.NotificationSeverity.PURPLE, null));
                applicationContext.close();
                break;
            }
        }
    }

    @EventListener(ApplicationReadyEvent.class)
    public void onApplicationStartup() {
        LOGGER.info("PrivateMarketsDXHub started... Starting {} message listeners...", serviceClients.size());
        grpcChannelManager.monitorChannel();
        addShutDownHook();
    }

    /**
     * Add graceful shut down hook to deregister services.
     */
    private void addShutDownHook() {
        // Register shutdown hook for channel and listeners
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            LOGGER.info("Private markets DX Hub Server shutting down...");
            try {
                zookeeperHelper.resolveAllClientsOnShutdown();
                channel().shutdownNow();
            } catch (final SSLException e) {
                LOGGER.error("failed to get channel:" + e.getMessage(), e);
            }
            final NotificationParams notificationParams = NotificationUtil.getNotificationParams("PrivateMarketsDXHub server shutting down!", NotificationEnums.NotificationSeverity.PURPLE, null);
            Notification.sendNotification(notificationParams);
        }));
        LOGGER.info("Graceful shutdown deregistration hook is installed.");
    }

}
