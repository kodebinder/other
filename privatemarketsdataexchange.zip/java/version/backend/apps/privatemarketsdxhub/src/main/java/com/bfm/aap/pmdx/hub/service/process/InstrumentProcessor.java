package com.bfm.aap.pmdx.hub.service.process;

import com.bfm.aap.pmdx.model.Instrument;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.google.protobuf.util.Timestamps;
import org.springframework.stereotype.Service;

@Service
public class InstrumentProcessor extends EntityProcessor<Instrument> {
	  @Override
	    public long getEntityEpochOriginTime(Instrument entity) {
	        return Timestamps.toMillis(entity.getEntityInfo().getOriginTimestamp());
	    }

	    @Override
	    Instrument updatePrimaryFlag(Instrument entity, boolean isPrimary) {
	        Instrument.Builder instrumentBuilder = Instrument.newBuilder(entity);
	        instrumentBuilder.getEntityInfoBuilder().setPrimaryData(isPrimary);
	        return instrumentBuilder.build();
	    }

	    @Override
	    EntityInfo getEntityInfo(Instrument entity) {
	        return entity.getEntityInfo();
	    }

	    @Override
	    public String getGuid(Instrument entity) {
	        return entity.getAssetId();
	    }

	    @Override
	    boolean isPrimary(Instrument entity) {
	        return entity.getEntityInfo().getPrimaryData();
	    }

	    @Override
	    public String getEntityType() {
	        return Instrument.class.getSimpleName();
	    }

}
