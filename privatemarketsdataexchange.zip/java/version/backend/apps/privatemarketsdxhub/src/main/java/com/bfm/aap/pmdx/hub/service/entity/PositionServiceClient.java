package com.bfm.aap.pmdx.hub.service.entity;

import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.pmdx.model.Position;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.aap.pmdx.model.util.PositionUtil;
import com.bfm.aap.pmdx.services.PositionRequest;
import com.bfm.aap.pmdx.services.PositionServiceGrpc;
import com.bfm.aap.pmdx.services.PositionsSinceRequest;
import com.bfm.service.ServiceException;
import com.google.protobuf.Timestamp;
import com.google.protobuf.util.Timestamps;
import io.grpc.ManagedChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import static com.google.protobuf.util.Timestamps.fromMillis;

@Service
public class PositionServiceClient extends BaseServiceClient<Position, PositionServiceGrpc.PositionServiceBlockingStub>
    implements EntityService<Position, PositionRequest> {

    private static final Logger LOGGER = LoggerFactory.getLogger(PositionServiceClient.class);

    @Autowired
    public PositionServiceClient(ManagedChannel channel, AltsDataWorkspaceDAO dataWorkspaceDAO,
                                 EntityProcessor<Position> entityProcessor) {
        super(channel, PositionServiceClient.class.getSimpleName(), dataWorkspaceDAO, EntityType.POSITION, entityProcessor);
        this.serviceStub = PositionServiceGrpc.newBlockingStub(channel);
    }

    @Override
    @RecordStats(metricName = "positionService_getPositionsSince", timer = true)
    Iterator<Position> initiateSingleBlockingRequest(long sinceTime, ClientInfo client, InvestUtils.DataSource dataSource) {
        Timestamp sinceTimeTs = fromMillis(sinceTime);
        LOGGER.info("Initiating gprc request for getPositionsSince for client:{} with time {}",
                client.getClientName(), Timestamps.toString(sinceTimeTs));
        PositionsSinceRequest request = PositionsSinceRequest.newBuilder().setTimestamp(sinceTimeTs).build();
        return ((PositionServiceGrpc.PositionServiceBlockingStub) getStubWithInterceptor(client)).getPositionsSince(request);
    }

    /**
     * Get single entity via unary grpc call.
     * @param entityRequest
     * @return
     * @throws ServiceException
     */
    @Override
    @RecordStats(metricName = "positionService_getPosition", timer = true)
    public Position getEntity(PositionRequest entityRequest) {
        try {
            LOGGER.info("Processing single entity request for {}", entityRequest);
            Position position = serviceStub
                    .withDeadlineAfter(unaryCallTimeoutMillis, TimeUnit.MILLISECONDS)
                    .getPosition(entityRequest);
            this.dataWorkspaceDAO.insertRecords(Collections.singletonList(position));
            return position;
        } catch (Exception e) {
            throw new ServiceException("Failed to get Position:"+e.getMessage(), e);
        }
    }

    @Override
    String getEntityGuid(Position entity) {
        return PositionUtil.getPositionIdentifier(entity);
    }
}
