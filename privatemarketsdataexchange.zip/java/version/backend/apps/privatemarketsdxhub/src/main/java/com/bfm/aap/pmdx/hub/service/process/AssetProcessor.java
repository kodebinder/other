package com.bfm.aap.pmdx.hub.service.process;

import com.bfm.aap.pmdx.model.Asset;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.google.protobuf.util.Timestamps;
import org.springframework.stereotype.Service;

@Service
public class AssetProcessor extends EntityProcessor<Asset> {

    @Override
    public long getEntityEpochOriginTime(Asset entity) {
        return Timestamps.toMillis(entity.getEntityInfo().getOriginTimestamp());
    }

    @Override
    Asset updatePrimaryFlag(Asset entity, boolean isPrimary) {
        Asset.Builder fundAssetBuilder = Asset.newBuilder(entity);
        fundAssetBuilder.getEntityInfoBuilder().setPrimaryData(isPrimary);
        return fundAssetBuilder.build();
    }

    @Override
    EntityInfo getEntityInfo(Asset entity) {
        return entity.getEntityInfo();
    }

    @Override
    public String getGuid(Asset entity) {
        return entity.getAssetId();
    }

    @Override
    boolean isPrimary(Asset entity) {
        return entity.getEntityInfo().getPrimaryData();
    }

    @Override
    public String getEntityType() {
        return Asset.class.getSimpleName();
    }
}
