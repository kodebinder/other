package com.bfm.aap.pmdx.hub.config;

import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.transformer.service.AssetTransformerService;
import com.bfm.aap.pmdx.transformer.service.BankAccountTransformerService;
import com.bfm.aap.pmdx.transformer.service.CompanyTransformerService;
import com.bfm.aap.pmdx.transformer.service.InstrumentTransformerService;
import com.bfm.aap.pmdx.transformer.service.InvestorTransformerService;
import com.bfm.aap.pmdx.transformer.service.PortfolioTransformerService;
import com.bfm.aap.pmdx.transformer.util.TransformerClientServiceHelper;
import com.bfm.aap.pmdx.transformer.util.TransformerClientServiceUtil;
import com.bfm.aap.privatemarkets.common.constant.CommonConstants;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static com.bfm.aap.pmdx.redblue.PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_ASSET;
import static com.bfm.aap.pmdx.redblue.PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_BANK_ACCOUNT;
import static com.bfm.aap.pmdx.redblue.PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_BANK_OPERATIONS;
import static com.bfm.aap.pmdx.redblue.PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_COMPANY;
import static com.bfm.aap.pmdx.redblue.PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_CONTACT;
import static com.bfm.aap.pmdx.redblue.PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_FUNDAMENTALS;
import static com.bfm.aap.pmdx.redblue.PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_INSTRUMENTS;
import static com.bfm.aap.pmdx.redblue.PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_INVESTOR;
import static com.bfm.aap.pmdx.redblue.PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_INVESTOR_ACCOUNT;
import static com.bfm.aap.pmdx.redblue.PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_PERFORMANCE;
import static com.bfm.aap.pmdx.redblue.PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_PORTFOLIO;
import static com.bfm.aap.pmdx.redblue.PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_POSITION;
import static com.bfm.aap.pmdx.redblue.PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_SHARE_CLASS;
import static com.bfm.aap.pmdx.redblue.PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_TRANSACTION;
import static com.bfm.aap.pmdx.redblue.PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_USER;

@Configuration
public class TransformersBeam2Config {

    @Value("${transformer.asset.batch.size:10}")
    private int assetBatchSize;
    @Value("${transformer.portfolio.batch.size:10}")
    private int portfolioBatchSize;
    @Value("${transformer.performance.batch.size:10}")
    private int performanceBatchSize;
    @Value("${transformer.fundamentals.batch.size:10}")
    private int fundamentalsBatchSize;
    @Value("${transformer.user.batch.size:10}")
    private int userBatchSize;
    @Value("${transformer.contact.batch.size:10}")
    private int contactBatchSize;
    @Value("${transformer.company.batch.size:10}")
    private int companyBatchSize;
    @Value("${transformer.investor.batch.size:10}")
    private int investorBatchSize;
    @Value("${transformer.transaction.batch.size:10}")
    private int transactionBatchSize;
    @Value("${transformer.investor.account.batch.size:10}")
    private int investorAccountBatchSize;
    @Value("${transformer.instrument.batch.size:10}")
    private int instrumentBatchSize;
    @Value("${transformer.bank.account.batch.size:10}")
    private int bankAccountBatchSize;
    @Value("${transformer.bank.ops.batch.size:10}")
    private int bankOpsBatchSize;
    @Value("${transformer.share.class.batch.size:10}")
    private int shareClassBatchSize;
    @Value("${transformer.position.batch.size:10}")
    private int positionBatchSize;

    @Value("${transformer.sync.batch.size:10}")
    private int syncBatchSize;

    @Value("${transformer.sync.etl.size:10}")
    private int syncEltSize;

    @Bean
    public TransformerClientServiceHelper transformerServiceHelper() {
        TransformerClientServiceHelper transformerServiceHelper = new TransformerClientServiceHelper(syncEltSize, syncBatchSize);
        transformerServiceHelper.addTransformerService(EntityType.USER, TransformerClientServiceUtil.getTransformerForgetServiceClient(PRIVATEMARKETS_TRANSFORMER_USER, CommonConstants.USER_TRANSFORMER_SOURCE_ID_OVERRIDE), userBatchSize);
        transformerServiceHelper.addTransformerService(EntityType.CONTACT, TransformerClientServiceUtil.getTransformerForgetServiceClient(PRIVATEMARKETS_TRANSFORMER_CONTACT, CommonConstants.CONTACT_TRANSFORMER_SOURCE_ID_OVERRIDE), contactBatchSize);
        transformerServiceHelper.addTransformerService(EntityType.INVESTOR_ACCOUNT, TransformerClientServiceUtil.getTransformerForgetServiceClient(PRIVATEMARKETS_TRANSFORMER_INVESTOR_ACCOUNT, CommonConstants.INVESTOR_ACCOUNT_TRANSFORMER_SOURCE_ID_OVERRIDE), investorAccountBatchSize);

        transformerServiceHelper.addTransformerService(EntityType.POSITION, TransformerClientServiceUtil.getTransformerForgetServiceClient(PRIVATEMARKETS_TRANSFORMER_POSITION, CommonConstants.POSITION_TRANSFORMER_SOURCE_ID_OVERRIDE), positionBatchSize);
        transformerServiceHelper.addTransformerService(EntityType.BANK_OPERATION, TransformerClientServiceUtil.getTransformerForgetServiceClient(PRIVATEMARKETS_TRANSFORMER_BANK_OPERATIONS, CommonConstants.BANK_OPERATION_TRANSFORMER_SOURCE_ID_OVERRIDE), bankOpsBatchSize);
        transformerServiceHelper.addTransformerService(EntityType.PERFORMANCE, TransformerClientServiceUtil.getTransformerForgetServiceClient(PRIVATEMARKETS_TRANSFORMER_PERFORMANCE, CommonConstants.PERFORMANCE_TRANSFORMER_SOURCE_ID_OVERRIDE), performanceBatchSize);
        transformerServiceHelper.addTransformerService(EntityType.FUNDAMENTALS, TransformerClientServiceUtil.getTransformerForgetServiceClient(PRIVATEMARKETS_TRANSFORMER_FUNDAMENTALS, CommonConstants.FUNDAMENTALS_TRANSFORMER_SOURCE_ID_OVERRIDE), fundamentalsBatchSize);
        transformerServiceHelper.addTransformerService(EntityType.SHARECLASS, TransformerClientServiceUtil.getTransformerForgetServiceClient(PRIVATEMARKETS_TRANSFORMER_SHARE_CLASS, CommonConstants.SHARECLASS_TRANSFORMER_SOURCE_ID_OVERRIDE), shareClassBatchSize);
        transformerServiceHelper.addTransformerService(EntityType.TRANSACTION, TransformerClientServiceUtil.getTransformerForgetServiceClient(PRIVATEMARKETS_TRANSFORMER_TRANSACTION, CommonConstants.TRANSACTIONS_TRANSFORMER_SOURCE_ID_OVERRIDE), transactionBatchSize);

        //Synchronous services.
        transformerServiceHelper.addTransformerService(EntityType.ASSET, TransformerClientServiceUtil.getTransformerClientService(AssetTransformerService.class, PRIVATEMARKETS_TRANSFORMER_ASSET, CommonConstants.ASSET_TRANSFORMER_SOURCE_ID_OVERRIDE), assetBatchSize);
        transformerServiceHelper.addTransformerService(EntityType.PORTFOLIO, TransformerClientServiceUtil.getTransformerClientService(PortfolioTransformerService.class, PRIVATEMARKETS_TRANSFORMER_PORTFOLIO, CommonConstants.PORTFOLIO_TRANSFORMER_SOURCE_ID_OVERRIDE), portfolioBatchSize);
        transformerServiceHelper.addTransformerService(EntityType.INSTRUMENT, TransformerClientServiceUtil.getTransformerClientService(InstrumentTransformerService.class, PRIVATEMARKETS_TRANSFORMER_INSTRUMENTS, CommonConstants.INSTRUMENT_TRANSFORMER_SOURCE_ID_OVERRIDE), instrumentBatchSize);
        transformerServiceHelper.addTransformerService(EntityType.COMPANY, TransformerClientServiceUtil.getTransformerClientService(CompanyTransformerService.class, PRIVATEMARKETS_TRANSFORMER_COMPANY, CommonConstants.COMPANY_TRANSFORMER_SOURCE_ID_OVERRIDE), companyBatchSize);
        transformerServiceHelper.addTransformerService(EntityType.INVESTOR, TransformerClientServiceUtil.getTransformerClientService(InvestorTransformerService.class, PRIVATEMARKETS_TRANSFORMER_INVESTOR, CommonConstants.INVESTOR_TRANSFORMER_SOURCE_ID_OVERRIDE), investorBatchSize);
        transformerServiceHelper.addTransformerService(EntityType.BANK_ACCOUNT, TransformerClientServiceUtil.getTransformerClientService(BankAccountTransformerService.class, PRIVATEMARKETS_TRANSFORMER_BANK_ACCOUNT, CommonConstants.BANKACCOUNT_TRANSFORMER_SOURCE_ID_OVERRIDE), bankAccountBatchSize);
        return transformerServiceHelper;
    }

}
