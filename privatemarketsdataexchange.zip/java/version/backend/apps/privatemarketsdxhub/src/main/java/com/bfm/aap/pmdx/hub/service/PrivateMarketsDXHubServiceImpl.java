package com.bfm.aap.pmdx.hub.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Service;

import com.bfm.aap.pmdx.hub.repository.AltsDataWorkspaceDAO;
import com.bfm.aap.pmdx.hub.repository.ClientInfoDAO;
import com.bfm.aap.pmdx.hub.service.async.ZookeeperHelper;
import com.bfm.aap.pmdx.hub.service.entity.CompanyServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.ContactServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.EntityService;
import com.bfm.aap.pmdx.hub.service.entity.InvestorAccountServiceClient;
import com.bfm.aap.pmdx.hub.service.entity.InvestorServiceClient;
import com.bfm.aap.pmdx.hub.util.NotificationUtil;
import com.bfm.aap.pmdx.hub.util.ServiceEnum;
import com.bfm.aap.pmdx.model.Asset;
import com.bfm.aap.pmdx.model.BankAccount;
import com.bfm.aap.pmdx.model.BankOperation;
import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.Fundamentals;
import com.bfm.aap.pmdx.model.Instrument;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.InvestorAccount;
import com.bfm.aap.pmdx.model.Portfolio;
import com.bfm.aap.pmdx.model.Position;
import com.bfm.aap.pmdx.model.Transaction;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.notification.model.BusinessNotificationTypes;
import com.bfm.aap.pmdx.notification.model.NotificationEnums;
import com.bfm.aap.pmdx.notification.service.Notification;
import com.bfm.aap.pmdx.services.AssetRequest;
import com.bfm.aap.pmdx.services.BankAccountRequest;
import com.bfm.aap.pmdx.services.BankOperationRequest;
import com.bfm.aap.pmdx.services.CompanyRequest;
import com.bfm.aap.pmdx.services.ContactRequest;
import com.bfm.aap.pmdx.services.FundamentalsRequest;
import com.bfm.aap.pmdx.services.InstrumentRequest;
import com.bfm.aap.pmdx.services.InvestorRequest;
import com.bfm.aap.pmdx.services.PortfolioRequest;
import com.bfm.aap.pmdx.services.PositionRequest;
import com.bfm.aap.pmdx.services.TransactionRequest;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.adl.ADLException;
import com.bfm.beam2.annotation.Beam2Method;
import com.bfm.beam2.annotation.Beam2Service;
import com.bfm.beam2.annotation.Param;
import com.bfm.beam2.error.Beam2Exception;
import com.bfm.service.ServiceException;
import com.bfm.util.beans.CollectionUtils;

/**
 * Private Markets DX Hub service.
 * Beam2 endpoints to retrieve single entities from eFront grpc server.
 */

@Service
@Beam2Service
@DependsOn("channel")
public class PrivateMarketsDXHubServiceImpl implements PrivateMarketsDXHubService {

    private static final Logger LOGGER = LoggerFactory.getLogger(PrivateMarketsDXHubServiceImpl.class);
    public static final String CRM = "CRM";
    public static final String PROCESSING_RESPONSE_TO_SET_EFRONT_ID = "Processing response to set efront Id into ADL and generate ThirdPartyMapping for GUID ; {}";
    public static final String FAILED_TO_UPDATE_CRM_ENTITIES = "Failed to update CRM Entities: ";

    @Autowired
    private EntityService<Asset, AssetRequest> assetService;
    @Autowired
    private EntityService<Portfolio, PortfolioRequest> portfolioService;
    @Autowired
    private EntityService<Position, PositionRequest> positionService;
    @Autowired
    private EntityService<Transaction, TransactionRequest> transactionsService;
    @Autowired
    private EntityService<Fundamentals, FundamentalsRequest> fundamentalsService;
    @Autowired
    private EntityService<Instrument, InstrumentRequest> instrumentService;
    @Autowired
    private EntityService<BankAccount, BankAccountRequest> bankAccountService;
    @Autowired
    private EntityService<BankOperation, BankOperationRequest> bankOperationService;
    @Autowired
    private ZookeeperHelper zookeeperHelper;
    @Autowired
    private ContactServiceClient contactServiceClient;
    @Autowired
    private CompanyServiceClient companyServiceClient;
    @Autowired
    private InvestorServiceClient investorServiceClient;
    @Autowired
    private InvestorAccountServiceClient investorAccountServiceClient;
    @Autowired
    private AltsDataWorkspaceDAO altsDataWorkspaceDAO;
    @Autowired
    private ClientInfoDAO clientInfoDAO;

    @Autowired
    private CRMThirdPartyMapperService crmThirdPartyMapperService;

    @Override
    @Beam2Method(command = PrivateMarketsDXHubServiceConstants.GET_ASSET)
    public Asset getAsset(@Param("assetRequest") AssetRequest assetRequest) {
        try {
            return assetService.getEntity(assetRequest);
        } catch (ServiceException e) {
            LOGGER.error("Failed to fetch fund asset for request {}, exception: {}", assetRequest, e.getMessage(), e);
            throw new Beam2Exception.ProcessingError(e.getMessage());
        }
    }

    @Override
    @Beam2Method(command = PrivateMarketsDXHubServiceConstants.GET_PORTFOLIO)
    public Portfolio getPortfolio(@Param("portfolioRequest") PortfolioRequest portfolioRequest) {
        try {
            return portfolioService.getEntity(portfolioRequest);
        } catch (ServiceException e) {
            LOGGER.error("Failed to fetch portfolio for request {}, exception: {}", portfolioRequest, e.getMessage(), e);
            throw new Beam2Exception.ProcessingError(e.getMessage());
        }
    }

    @Override
    @Beam2Method(command = PrivateMarketsDXHubServiceConstants.GET_POSITION)
    public Position getPosition(@Param("positionRequest") PositionRequest positionRequest) {
        try {
            return positionService.getEntity(positionRequest);
        } catch (ServiceException e) {
            LOGGER.error("Failed to fetch position for request {}, exception: {}", positionRequest, e.getMessage(), e);
            throw new Beam2Exception.ProcessingError(e.getMessage());
        }
    }

    @Override
    @Beam2Method(command = PrivateMarketsDXHubServiceConstants.GET_TRANSACTIONS)
    public Transaction getTransaction(@Param("transactionRequest") TransactionRequest transactionRequest) {
        try {
            return transactionsService.getEntity(transactionRequest);
        } catch (ServiceException e) {
            LOGGER.error("Failed to fetch transaction for request {}, exception: {}", transactionRequest, e.getMessage(), e);
            throw new Beam2Exception.ProcessingError(e.getMessage());
        }
    }

    @Override
    @Beam2Method(command = PrivateMarketsDXHubServiceConstants.GET_FUNDAMENTALS)
    public Fundamentals getFundamentals(@Param("fundamentalsRequest") FundamentalsRequest fundamentalsRequest) {
        try {
            return fundamentalsService.getEntity(fundamentalsRequest);
        } catch (ServiceException e) {
            LOGGER.error("Failed to fetch fundamentals for request {}, exception: {}", fundamentalsRequest, e.getMessage(), e);
            throw new Beam2Exception.ProcessingError(e.getMessage());
        }
    }
    
    @Override
    @Beam2Method(command = PrivateMarketsDXHubServiceConstants.GET_INSTRUMENT)
    public Instrument getInstrument(@Param("instrumentRequest") InstrumentRequest instrumentRequest) {
        try {
            return instrumentService.getEntity(instrumentRequest);
        } catch (ServiceException e) {
            LOGGER.error("Failed to fetch Instrument for request {}, exception: {}", instrumentRequest, e.getMessage(), e);
            throw new Beam2Exception.ProcessingError(e.getMessage());
        }
    }

    @Override
    @Beam2Method(command = PrivateMarketsDXHubServiceConstants.GET_BANKACCOUNT)
    public BankAccount getBankAccount(@Param("bankAccountRequest") BankAccountRequest bankAccountRequest) {
        try {
            return bankAccountService.getEntity(bankAccountRequest);
        } catch (ServiceException e) {
            LOGGER.error("Failed to fetch bank account for request {}, exception: {}", bankAccountRequest, e.getMessage(), e);
            throw new Beam2Exception.ProcessingError(e.getMessage());
        }
    }

    @Override
    @Beam2Method(command = PrivateMarketsDXHubServiceConstants.GET_BANKOPERATION)
    public BankOperation getBankOperation(@Param("bankOperationRequest") BankOperationRequest bankOperationRequest) {
        try {
            return bankOperationService.getEntity(bankOperationRequest);
        } catch (ServiceException e) {
            LOGGER.error("Failed to fetch bank Operation for request {}, exception: {}", bankOperationRequest, e.getMessage(), e);
            throw new Beam2Exception.ProcessingError(e.getMessage());
        }
    }

    @Override
    @Beam2Method(command = PrivateMarketsDXHubServiceConstants.UPDATE_SINCETIME)
    public void updateSinceTime(@Param("epochTimeMillis") long epochTimeMillis, @Param("clientName") String clientName, @Param("serviceName") String serviceName) {
        try {
            ServiceEnum serviceEnum = ServiceEnum.findService(serviceName);
            if (serviceEnum == null) {
                LOGGER.error("Service value doesn't match. Please verify value : {}. Currently supported values are : {} ", serviceName, ServiceEnum.values());
                return;
            }
            zookeeperHelper.updateLastSuccessfulTime(clientName, serviceEnum, epochTimeMillis);
        } catch (Exception e) {
            final String failureMessage = "Failed to update since time: " + e.getMessage();
            LOGGER.error(failureMessage, e);
            throw new Beam2Exception.ProcessingError(failureMessage);
        }
    }

    @Override
    @Beam2Method(command = PrivateMarketsDXHubServiceConstants.UPDATE_CLIENT_STATUS)
    public void updateClientStatusToComplete(@Param("clientName") String clientName, @Param("serviceName") String serviceName) {
        try {
            ServiceEnum serviceEnum = ServiceEnum.findService(serviceName);
            if (serviceEnum == null) {
                LOGGER.error("Service value doesn't match. Please verify value : {}. Currently supported values are : {} ", serviceName, ServiceEnum.values());
                return;
            }
            zookeeperHelper.updateChildNodeStatusToComplete(clientName, serviceEnum);
        } catch (Exception e) {
            final String failureMessage = "Failed to update client status to complete time: " + e.getMessage();
            LOGGER.error(failureMessage, e);
            throw new Beam2Exception.ProcessingError(failureMessage);
        }
    }

    @Override
    @Beam2Method(command = PrivateMarketsDXHubServiceConstants.UPDATE_CONTACT)
    public void updateContact(@Param("contactRequest") ContactRequest contactRequest, @Param("crmEntityId")Integer crmEntityId) {
        List<ClientInfo> clientInfoList = clientInfoDAO.getCRMClients();
        //Assuming there will be a single client with CRM service enabled.
        if (CollectionUtils.isEmpty(clientInfoList)) {
            return;
        }
        try {
            Contact contact = contactRequest.getContact();
            String clientName = clientInfoList.get(0).getClientName();
            String gUID = altsDataWorkspaceDAO.insertRecord(contact, CRM, clientName);
            contact = contact.getModifiedBy().isEmpty() ? Contact.newBuilder(contact).setModifiedBy(clientInfoList.get(0).getDefaultInvestUserId()).build() : contact;
            String entityIdRequest = contact.getContactId();
            String entityIdResponse = contactServiceClient.updateContact(contactRequest, clientInfoList.get(0), crmEntityId);

            if (entityIdRequest.isEmpty() && !entityIdResponse.isEmpty()) {
                altsDataWorkspaceDAO.updateRecord(Contact.newBuilder(contact).setContactId(entityIdResponse).build(), CRM, gUID);
                LOGGER.info(PROCESSING_RESPONSE_TO_SET_EFRONT_ID, gUID);
                crmThirdPartyMapperService.create(entityIdResponse, crmEntityId, ThirdPartyMappingEnum.CONTACT_INVEST);
            }
        } catch (ADLException | ServiceException exception) {
            final String failureMessage = new StringBuilder().append(FAILED_TO_UPDATE_CRM_ENTITIES).append(exception.getMessage()).toString();
            LOGGER.error(failureMessage, exception);
            Notification.sendNotification(NotificationUtil.getNotificationParams(NotificationEnums.NotificationSeverity.YELLOW, BusinessNotificationTypes.CRM, exception));
            throw new Beam2Exception.ProcessingError(failureMessage);
        } catch (Exception exception) {
            final String failureMessage = new StringBuilder().append(FAILED_TO_UPDATE_CRM_ENTITIES).append(exception.getMessage()).toString();
            LOGGER.error(failureMessage, exception);
            Notification.sendNotification(NotificationUtil.getNotificationParams(NotificationEnums.NotificationSeverity.YELLOW, BusinessNotificationTypes.CRM, exception));
        }
    }

    @Override
    @Beam2Method(command = PrivateMarketsDXHubServiceConstants.UPDATE_COMPANY)
    public void updateCompany(@Param("companyRequest") CompanyRequest companyRequest, @Param("crmEntityId")Integer crmEntityId) {
        List<ClientInfo> clientInfoList = clientInfoDAO.getCRMClients();
        //Assuming there will be a single client with CRM service enabled.
        if (CollectionUtils.isEmpty(clientInfoList)) {
            return;
        }

        try {
            Company company = companyRequest.getCompany();
            String clientName = clientInfoList.get(0).getClientName();
            String gUID = altsDataWorkspaceDAO.insertRecord(company, CRM, clientName);
            company = company.getModifiedBy().isEmpty() ? Company.newBuilder(company).setModifiedBy(clientInfoList.get(0).getDefaultInvestUserId()).build() : company;
            String entityIdResponse = companyServiceClient.updateCompany(companyRequest, clientInfoList.get(0), crmEntityId);
            String entityIdRequest = company.getCompanyId();
            if (entityIdRequest.isEmpty() && !entityIdResponse.isEmpty()) {
                altsDataWorkspaceDAO.updateRecord(Company.newBuilder(company).setCompanyId(entityIdResponse).build(), CRM, gUID);
                LOGGER.info(PROCESSING_RESPONSE_TO_SET_EFRONT_ID, gUID);
                crmThirdPartyMapperService.create(entityIdResponse, crmEntityId, ThirdPartyMappingEnum.COMPANY_INVEST);
            }
        } catch (ADLException | ServiceException exception) {
            final String failureMessage = new StringBuilder().append(FAILED_TO_UPDATE_CRM_ENTITIES).append(exception.getMessage()).toString();
            LOGGER.error(failureMessage, exception);
            Notification.sendNotification(NotificationUtil.getNotificationParams(NotificationEnums.NotificationSeverity.YELLOW, BusinessNotificationTypes.CRM, exception));
            throw new Beam2Exception.ProcessingError(failureMessage);
        } catch (Exception exception) {
            final String failureMessage = new StringBuilder().append(FAILED_TO_UPDATE_CRM_ENTITIES).append(exception.getMessage()).toString();
            LOGGER.error(failureMessage, exception);
            Notification.sendNotification(NotificationUtil.getNotificationParams(NotificationEnums.NotificationSeverity.YELLOW, BusinessNotificationTypes.CRM, exception));
        }
    }

    @Override
    @Beam2Method(command = PrivateMarketsDXHubServiceConstants.UPDATE_INVESTOR)
    public void updateInvestor(@Param("investorRequest") InvestorRequest investorRequest, @Param("crmEntityId")Integer crmEntityId) {
        List<ClientInfo> clientInfoList = clientInfoDAO.getCRMClients();
        //Assuming there will be a single client with CRM service enabled.
        if (CollectionUtils.isEmpty(clientInfoList)) {
            return;
        }
        try {
            Investor investor = investorRequest.getInvestor();
            String clientName = clientInfoList.get(0).getClientName();
            String gUID = altsDataWorkspaceDAO.insertRecord(investor, CRM, clientName);
            investor = investor.getModifiedBy().isEmpty() ? Investor.newBuilder(investor).setModifiedBy(clientInfoList.get(0).getDefaultInvestUserId()).build() : investor;
            String entityIdResponse = investorServiceClient.updateInvestor(investorRequest, clientInfoList.get(0), crmEntityId);
            String entityIdRequest = investor.getInvestorId();
            if (entityIdRequest.isEmpty() && !entityIdResponse.isEmpty()) {
                altsDataWorkspaceDAO.updateRecord(Investor.newBuilder(investor).setInvestorId(entityIdResponse).build(), CRM, gUID);
                LOGGER.info(PROCESSING_RESPONSE_TO_SET_EFRONT_ID, gUID);
                crmThirdPartyMapperService.create(entityIdResponse, crmEntityId, ThirdPartyMappingEnum.INVESTOR_INVEST);
            }
        } catch (ADLException | ServiceException exception) {
            final String failureMessage = new StringBuilder().append(FAILED_TO_UPDATE_CRM_ENTITIES).append(exception.getMessage()).toString();
            LOGGER.error(failureMessage, exception);
            Notification.sendNotification(NotificationUtil.getNotificationParams(NotificationEnums.NotificationSeverity.YELLOW, BusinessNotificationTypes.CRM, exception));
            throw new Beam2Exception.ProcessingError(failureMessage);
        } catch (Exception exception) {
            final String failureMessage = new StringBuilder().append(FAILED_TO_UPDATE_CRM_ENTITIES).append(exception.getMessage()).toString();
            LOGGER.error(failureMessage, exception);
            Notification.sendNotification(NotificationUtil.getNotificationParams(NotificationEnums.NotificationSeverity.YELLOW, BusinessNotificationTypes.CRM, exception));
        }
    }

    @Override
    @Beam2Method(command = PrivateMarketsDXHubServiceConstants.UPDATE_INVESTOR_ACCOUNT)
    public void updateInvestorAccount(@Param("investorAccount") InvestorAccount investorAccount, @Param("crmEntityId")Integer crmEntityId) {
        List<ClientInfo> clientInfoList = clientInfoDAO.getCRMClients();
        //Assuming there will be a single client with CRM service enabled.
        if (CollectionUtils.isEmpty(clientInfoList)) {
            return;
        }
        try {
            String clientName = clientInfoList.get(0).getClientName();
            String gUID = altsDataWorkspaceDAO.insertRecord(investorAccount, CRM, clientName);
            if(investorAccount.getModifiedBy().isEmpty()) {
                InvestorAccount.Builder builder = InvestorAccount.newBuilder(investorAccount);
                builder.setModifiedBy(clientInfoList.get(0).getDefaultInvestUserId()).build();
                investorAccount = builder.build();
            }
            String entityIdResponse = investorAccountServiceClient.updateInvestorAccount(investorAccount, clientInfoList.get(0), crmEntityId);
            String entityIdRequest = investorAccount.getInvestorAccountId();
            if (entityIdRequest.isEmpty() && !entityIdResponse.isEmpty()) {
                altsDataWorkspaceDAO.updateRecord(InvestorAccount.newBuilder(investorAccount).setInvestorAccountId(entityIdResponse).build(), CRM, gUID);
                LOGGER.info(PROCESSING_RESPONSE_TO_SET_EFRONT_ID, gUID);
                crmThirdPartyMapperService.create(entityIdResponse, crmEntityId, ThirdPartyMappingEnum.INVESTOR_ACCOUNT_INVEST);
            }
        } catch (ADLException | ServiceException exception) {
            final String failureMessage = new StringBuilder().append(FAILED_TO_UPDATE_CRM_ENTITIES).append(exception.getMessage()).toString();
            LOGGER.error(failureMessage, exception);
            Notification.sendNotification(NotificationUtil.getNotificationParams(NotificationEnums.NotificationSeverity.YELLOW, BusinessNotificationTypes.CRM, exception));
            throw new Beam2Exception.ProcessingError(failureMessage);
        } catch (Exception exception) {
            final String failureMessage = new StringBuilder().append(FAILED_TO_UPDATE_CRM_ENTITIES).append(exception.getMessage()).toString();
            LOGGER.error(failureMessage, exception);
            Notification.sendNotification(NotificationUtil.getNotificationParams(NotificationEnums.NotificationSeverity.YELLOW, BusinessNotificationTypes.CRM, exception));
        }
    }
}
