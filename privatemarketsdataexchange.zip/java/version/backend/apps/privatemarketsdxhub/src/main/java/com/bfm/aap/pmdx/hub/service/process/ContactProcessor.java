package com.bfm.aap.pmdx.hub.service.process;

import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.util.ContactUtil;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.google.protobuf.util.Timestamps;
import org.springframework.stereotype.Service;

@Service
public class ContactProcessor extends EntityProcessor<Contact> {

    @Override
    public long getEntityEpochOriginTime(Contact entity) {
        return Timestamps.toMillis(entity.getEntityInfo().getOriginTimestamp());
    }

    @Override
    Contact updatePrimaryFlag(Contact entity, boolean isPrimary) {
        Contact.Builder crmContactBuilder = Contact.newBuilder(entity);
        crmContactBuilder.getEntityInfoBuilder().setPrimaryData(isPrimary);
        return crmContactBuilder.build();
    }

    @Override
    EntityInfo getEntityInfo(Contact entity) {
        return entity.getEntityInfo();
    }

    @Override
    public String getGuid(Contact entity) {
        return ContactUtil.getContactGuid(entity);
    }

    @Override
    boolean isPrimary(Contact entity) {
        return entity.getEntityInfo().getPrimaryData();
    }

    @Override
    public String getEntityType() {
        return Contact.class.getSimpleName();
    }
}
