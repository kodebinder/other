package com.bfm.aap.pmdx.hub.service.process;

import com.bfm.aap.pmdx.model.Transaction;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.bfm.aap.pmdx.model.util.TransactionsUtil;
import com.google.protobuf.util.Timestamps;
import org.springframework.stereotype.Service;

@Service
public class TransactionsProcessor extends EntityProcessor<Transaction> {

    @Override
    public long getEntityEpochOriginTime(Transaction entity) {
        return Timestamps.toMillis(entity.getEntityInfo().getOriginTimestamp());
    }

    @Override
    Transaction updatePrimaryFlag(Transaction entity, boolean isPrimary) {
        Transaction.Builder transactionBuilder = Transaction.newBuilder(entity);
        transactionBuilder.getEntityInfoBuilder().setPrimaryData(isPrimary);
        return transactionBuilder.build();
    }

    @Override
    EntityInfo getEntityInfo(Transaction entity) {
        return entity.getEntityInfo();
    }

    @Override
    public String getGuid(Transaction entity) {
        return TransactionsUtil.getTransactionIdentifier(entity);
    }

    @Override
    boolean isPrimary(Transaction entity) {
        return entity.getEntityInfo().getPrimaryData();
    }

    @Override
    public String getEntityType() {
        return Transaction.class.getSimpleName();
    }

}
