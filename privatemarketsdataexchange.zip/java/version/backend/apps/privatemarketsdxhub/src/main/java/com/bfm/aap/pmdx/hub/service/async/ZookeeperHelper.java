package com.bfm.aap.pmdx.hub.service.async;

import com.google.protobuf.Timestamp;
import com.google.protobuf.util.Timestamps;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.ZooKeeper;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.StringJoiner;
import java.util.stream.Collectors;

import static com.bfm.aap.pmdx.hub.util.AppConstants.PMDX_HUB_ID;
import static com.bfm.aap.pmdx.hub.util.AppConstants.ZKPATH_PARENT;

import com.bfm.aap.pmdx.hub.repository.ClientInfoDAO;
import com.bfm.aap.pmdx.hub.util.AppConstants;
import com.bfm.aap.pmdx.hub.util.HubServiceUtil;
import com.bfm.aap.pmdx.hub.util.ServiceEnum;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.ClientStatus;
import com.bfm.aap.pmdx.model.util.EntityService;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.ServerContext;
import com.bfm.aap.pmdx.proto.util.ProtoJsonHelper;
import com.bfm.adl.ADLException;
import com.bfm.util.ProtocolSupport;
import com.bfm.util.ZKPathUtils;
import com.bfm.util.ZooKeeperRetryOperations;

@Service
public final class ZookeeperHelper {
    private static final Logger LOGGER = LoggerFactory.getLogger(ZookeeperHelper.class);
    public static final String COULDN_T_ACQUIRE_LOCK_TO_UPDATE_STATUS_TO_COMPLETE_FOR_CLIENT = "Couldn't acquire lock to update status to complete for client: {}";
    public static final String ZOOKEEPER_NOT_CONNECTED_CANNOT_UPDATE_NODE = "Zookeeper not connected, cannot update node!";
    public static final String FAILED_TO_UPDATE_CLIENT_STATUS_TO_COMPLETION_IN_ZOOKEEPER_FOR_CLIENT = "Failed to update client status to completion in Zookeeper for client :{}";

    private final ProtocolSupport protocolSupport;
    private final LockHelper lockHelper;
    private final ZooKeeperRetryOperations zooKeeperRetryOperations;
    private final HubServiceUtil utilService;
    private ZooKeeper zooKeeper;
    private final ClientInfoDAO clientInfoDAO;
    private static final String ENTITY_SERVICE_NAME = "ALL";
    @Value("${zookeeper-cutoff:60}")
    private Integer cutOffTime;

    @Autowired
    public ZookeeperHelper(ProtocolSupport protocolSupport,
                           LockHelper lockHelper,
                           HubServiceUtil utilService, ClientInfoDAO clientInfoDAO) {
        this.protocolSupport = protocolSupport;
        this.lockHelper = lockHelper;
        this.zooKeeper = protocolSupport.getZookeeper();
        this.zooKeeperRetryOperations = new ZooKeeperRetryOperations(protocolSupport);
        this.utilService = utilService;
        this.clientInfoDAO = clientInfoDAO;
    }

    boolean zkIsConnected() {
        boolean isConnected = zooKeeper.getState().isConnected();

        if (!isConnected) {
            protocolSupport.connect();
            protocolSupport.awaitConnection();
            zooKeeper = protocolSupport.getZookeeper();
            isConnected = zooKeeper.getState().isConnected();
        }
        return isConnected;
    }

    boolean createZKPath(String path, byte[] zooObject) throws KeeperException {//TODO make child nodes Epemeral
        LOGGER.info("creating zookeeper node at path {}", path);
        return zooKeeperRetryOperations.ensurePathExists(path, zooObject, CreateMode.CONTAINER);
    }

    public byte[] getNodeData(String path) throws KeeperException, InterruptedException {
        byte[] zooInfo = null;
        if (verifyPath(path)) {
            return zooInfo;
        }
        zooInfo = zooKeeper.getData(path, true, null);//seed entry
        return zooInfo;
    }

    void updateNodeData(String path, byte[] zooInfo) throws KeeperException {
        zooKeeperRetryOperations.setData(path, zooInfo, -1);
        //zooKeeper.setData(path, zooInfo, -1); //TODO do we need to update the version # -1 means file version # is not verified.
    }

    private boolean verifyPath(String path) throws KeeperException, InterruptedException {
        return zooKeeper.exists(path, false) == null;
    }

    void ensurePathCreated(String path) throws KeeperException {
        this.zooKeeperRetryOperations.ensurePathExists(path, null, CreateMode.CONTAINER);
    }

    void ensurePathCreated(String path, byte[] data) throws KeeperException {
        this.zooKeeperRetryOperations.ensurePathExists(path, data, CreateMode.CONTAINER);
    }

    public String getClientPath(String clientName, ServiceEnum serviceEnum) {
        String clientPath = new StringJoiner(AppConstants.ZK_DELIMITER)
                .add(AppConstants.ZKPATH_PARENT)
                .add(clientName)
                .add(serviceEnum.name())
                .toString();
        LOGGER.debug("Built Path for client name : {},  path : {} ", clientName, clientPath);
        return clientPath;
    }

    public ClientInfo buildClientInfo(String client, ClientStatus status) {
        return this.buildClientInfo(client, status, null);
    }

    public ClientInfo buildClientInfo(String client, ClientStatus status, Long lastSuccessfulTime) {
        ClientInfo.Builder clientInfoBuilder = ClientInfo.newBuilder();
        clientInfoBuilder.setClientName(client)
                .setLastModifiedTime(Timestamps.fromMillis(System.currentTimeMillis()))
                .setUpdatedBy(ZKPathUtils.constructThreadSpecificId("_"))
                .setStatus(status);
        EntityService.Builder service = EntityService.newBuilder();
        service.setServiceName(ENTITY_SERVICE_NAME);
        service.setLastSuccessfulTime(Timestamps.fromMillis(Objects.isNull(lastSuccessfulTime) ? Instant.EPOCH.toEpochMilli() : lastSuccessfulTime));
        clientInfoBuilder.addEntityService(0, service);
        return clientInfoBuilder.build();
    }

    public ServerContext getServerContextFromDefaultZKPath() throws KeeperException, InterruptedException {
        if (!this.zkIsConnected()) {
            LOGGER.warn("Zookeeper is not connected, cannot get the HubContext!");
            return null;
        }
        if (this.verifyPath(ZKPATH_PARENT)) {
            LOGGER.info("Could not find {}. Creating path now..", ZKPATH_PARENT);
            this.ensurePathCreated(ZKPATH_PARENT);
            return null;
        }
        byte[] data = this.getNodeData(ZKPATH_PARENT);
        if (data == null) {
            LOGGER.warn("No data found at ZK node for path {}", ZKPATH_PARENT);
            return null;
        }
        ServerContext.Builder context = ServerContext.newBuilder();
        ProtoJsonHelper.tryMergeFromJson(context, new String(data));
        return context.build();
    }

    public boolean lockUpdateSeverContext(ServerContext serverContext, List<ClientInfo> clientListProps) throws KeeperException {
        if (!this.zkIsConnected()) {
            LOGGER.warn("Zookeeper is not connected, cannot update the HubContext!");
        }

        //Check and update the HubContext
        boolean lockAcquired = this.lockHelper.acquireLockWithRetry(PMDX_HUB_ID); // lock parent container node
        if (lockAcquired) {
            getUpdateServerContext(serverContext, clientListProps);
            lockHelper.releaseLock(PMDX_HUB_ID);
            return true;
        }
        return false;
    }

    private void getUpdateServerContext(ServerContext serverContext, List<ClientInfo> clientListZK) throws KeeperException {
        if (serverContext == null) {//this might be needed for the first time
            serverContext = ServerContext.getDefaultInstance();
        }
        if (serverContext.equals(ServerContext.getDefaultInstance())) {
            serverContext = handleNewHubContext(clientListZK).build();
        } else {
            serverContext = updateHeartBeats(serverContext.toBuilder());
        }
        this.updateNodeData(ZKPATH_PARENT, ProtoJsonHelper.convertToJson(serverContext).getBytes());
    }

    private ServerContext updateHeartBeats(ServerContext.Builder serverContext) {
        serverContext.setHeartBeat(Timestamps.fromMillis(System.currentTimeMillis()));
        LOGGER.info("Updated heartbeats for server context..");
        return serverContext.build();
    }

    private ServerContext.Builder handleNewHubContext(List<ClientInfo> clientList) {
        ServerContext.Builder newServerContext = ServerContext.newBuilder();
        //add all service clients to this first server.
        List<String> allClients = clientList.stream().map(ClientInfo::getClientName).collect(Collectors.toList());
        newServerContext.setServerInstance(AppConstants.INSTANCE_ID)
                .setHeartBeat(Timestamps.fromMillis(System.currentTimeMillis()))
                .setStartHashRange(0).setEndHashRange(360 - 1)
                .addAllClients(allClients)
                .setIsIssuersScheduled(true);
        LOGGER.info("Handling new server context: {}", newServerContext);
        return newServerContext;
    }

    public void updateLastSuccessfulTime(String clientName, ServiceEnum serviceEnum, Long lastSuccessfulTime) {
        boolean lockAcquired = false;
        String clientPath = getClientPath(clientName, serviceEnum);
        try {
            if (this.verifyPath(clientPath)) {
                LOGGER.error("{} -> client path doesnt exists in Zookeeper. Please verify your request", clientPath);
                throw new KeeperException.BadArgumentsException();
            }
            lockAcquired = lockHelper.acquireLockWithRetry(clientPath);
            if (lockAcquired) {
                updateClientInfo(clientPath, lastSuccessfulTime);
            } else {
                LOGGER.warn(COULDN_T_ACQUIRE_LOCK_TO_UPDATE_STATUS_TO_COMPLETE_FOR_CLIENT, clientName);
            }
        } catch (InterruptedException ex) {
            LOGGER.error("Failed to update client status to completion in Zookeeper for client: {}, {} ", clientName, ex.getMessage(), ex);
            Thread.currentThread().interrupt();
        } catch (Exception ex) {
            LOGGER.error("Failed to update client status to completion in Zookeeper for client: {}, {} ", clientName, ex.getMessage(), ex);
        } finally {
            if (lockAcquired) {//release lock in the end.
                lockHelper.releaseLock(clientPath);
            }
        }
    }

    public void updateChildNodeStatusToComplete(String clientName, ServiceEnum serviceEnum) {
        if (!this.zkIsConnected()) {
            LOGGER.warn(ZOOKEEPER_NOT_CONNECTED_CANNOT_UPDATE_NODE);
        }

        this.lockAndUpdateClientInfo(clientName, serviceEnum, null);
    }

    public void updateChildNodeStatusToComplete(String clientName, ServiceEnum serviceEnum, Long lastSuccessfulTime) {
        if (!this.zkIsConnected()) {
            LOGGER.warn(ZOOKEEPER_NOT_CONNECTED_CANNOT_UPDATE_NODE);
        }

        this.lockAndUpdateClientInfo(clientName, serviceEnum, lastSuccessfulTime);
    }

    private void lockAndUpdateClientInfo(String clientName, ServiceEnum serviceEnum, Long lastSuccessfulTime) {
        boolean lockAcquired = false;
        String clientPath = getClientPath(clientName, serviceEnum);
        try {
            lockAcquired = lockHelper.acquireLockWithRetry(clientPath);
            if (lockAcquired) {
                LOGGER.info("Status changed to COMPLETED for {}", clientPath);
                this.updateClientInfo(clientPath, ClientStatus.COMPLETED, lastSuccessfulTime);
            } else {
                LOGGER.warn(COULDN_T_ACQUIRE_LOCK_TO_UPDATE_STATUS_TO_COMPLETE_FOR_CLIENT, clientName);
            }
        } catch (InterruptedException ex) {
            LOGGER.error(FAILED_TO_UPDATE_CLIENT_STATUS_TO_COMPLETION_IN_ZOOKEEPER_FOR_CLIENT, clientName, ex);
            Thread.currentThread().interrupt();
        } catch (Exception ex) {
            LOGGER.error(FAILED_TO_UPDATE_CLIENT_STATUS_TO_COMPLETION_IN_ZOOKEEPER_FOR_CLIENT, clientName, ex);
        } finally {
            if (lockAcquired) {//release lock in the end.
                lockHelper.releaseLock(clientPath);
            }
        }
    }

    public Set<ClientInfo> getClientsForProcessing(Map<String, Map<String, String>> clientToEntityServicePathMap, int batchInterval) {
        LOGGER.warn("Get list of clients from Zookeeper to process");
        Set<ClientInfo> clientsReadyForProcessing = new HashSet<>();
        if (!this.zkIsConnected()) {
            LOGGER.warn("Zookeeper not connected, cannot get nodes!");
        }

        boolean lockAcquired = false;
        String pathToNode = StringUtils.EMPTY;
        try {
            for (Map.Entry<String, Map<String, String>> entry : clientToEntityServicePathMap.entrySet()) {
                for (String entityService : entry.getValue().keySet()) {
                    pathToNode = entry.getValue().get(entityService);
                    ServiceEnum serviceEnum = ServiceEnum.findService(entityService);
                    this.ensureChildNodeExists(entry.getKey(), pathToNode, serviceEnum);
                    lockAcquired = lockHelper.acquireLockWithRetry(pathToNode);//acquire lock on each child
                    if (lockAcquired) { //lock child znode
                        this.getUpdateChildNodes(pathToNode, entry.getKey(), clientsReadyForProcessing, batchInterval);
                        lockAcquired = !lockHelper.releaseLock(pathToNode); //release lock in the end.
                    }
                }
            }
        } catch (KeeperException | InterruptedException | ADLException ex) {
            LOGGER.error("Exception occurred while processing client @ : {} : {} ", pathToNode, ex.getMessage(), ex);
            Thread.currentThread().interrupt();
        } finally {
            if (lockAcquired) {//release lock in the end.
                lockHelper.releaseLock(pathToNode);
            }
        }
        return clientsReadyForProcessing;
    }

    /**
     *
     * @param pathToNode
     * @param clientName
     * @param clientsReadyForProcessing
     * @param batchInterval
     * @throws KeeperException
     * @throws InterruptedException
     */
    void getUpdateChildNodes(String pathToNode, String clientName, Set<ClientInfo> clientsReadyForProcessing, int batchInterval)
            throws KeeperException, InterruptedException {
        ClientInfo.Builder clientInfoBuilder = ClientInfo.newBuilder();
        byte[] childData = this.getNodeData(pathToNode);
        ClientInfo clientInfoAtNode;
        if (childData != null) {
            ProtoJsonHelper.tryMergeFromJson(clientInfoBuilder, new String(childData));
            clientInfoAtNode = clientInfoBuilder.build();
        } else {
            clientInfoAtNode = ClientInfo.getDefaultInstance();
        }

        if (clientInfoAtNode.equals(ClientInfo.getDefaultInstance())) {
            clientInfoAtNode = this.buildClientInfo(clientName, ClientStatus.INITIATED);
            this.updateNodeData(pathToNode, ProtoJsonHelper.convertToJson(clientInfoAtNode).getBytes());
            LOGGER.info("Updated client info for znode at path {}", pathToNode);
        }

        if (isEligibleForProcessing(clientInfoAtNode, batchInterval)) { //check the clients status and then last time it was processed. If delta is greater than 5 minutes then pick it up.
            clientsReadyForProcessing.add(clientInfoAtNode);
            LOGGER.info("Added client {} for processing.", clientName);
            this.updateClientInfo(pathToNode, ClientStatus.IN_PROGRESS, null);
        }
    }

    /**
     * Find if the client is eligible for processing
     *
     * @param info
     * @param batchInterval
     * @return
     */
    private boolean isEligibleForProcessing(ClientInfo info, int batchInterval) {
        if (ClientStatus.IN_PROGRESS == info.getStatus()) {
            final Timestamp circuitBreakerInterval = Timestamps.fromMillis(System.currentTimeMillis() - (cutOffTime * 60000));
            int difference = Timestamps.compare(info.getLastModifiedTime(), circuitBreakerInterval);
            if (difference <= 0) {
                LOGGER.error("Client {} is processing since {} minutes.", info.getClientName(), circuitBreakerInterval.getSeconds()/60);
            }
            LOGGER.info("Client {} already processing, skipping", info.getClientName());
            return false;
        }
        if (info.getEntityServiceList().isEmpty()) {
            LOGGER.error("Client {} has entity service level data missing. Please check.", info);
            return false;
        }
        //Prevents execution before the delayInterval in a multi instance.
        final Timestamp delayInterval = Timestamps.fromMillis(System.currentTimeMillis() - batchInterval);
        return Timestamps.compare(info.getEntityService(0).getLastSuccessfulTime(), delayInterval) <= 0;
    }

    /**
     * Makes sure node exists at the path orElse creates one.
     *
     * @param clientName
     * @param childPath
     * @param serviceEnum
     * @throws KeeperException
     * @throws ADLException
     */
    void ensureChildNodeExists(String clientName, String childPath, ServiceEnum serviceEnum) throws KeeperException, ADLException {
        ClientInfo clientInfo = this.buildClientInfo(clientName, ClientStatus.INITIATED, utilService.getLastSuccessfulTime(clientName, serviceEnum));
        this.ensurePathCreated(childPath, ProtoJsonHelper.convertToJson(clientInfo).getBytes());
    }

    public void updateClientInfo(String clientPath, Long lastSuccessfulTime) throws KeeperException, InterruptedException {
        this.updateClientInfo(clientPath, null, lastSuccessfulTime);
    }

    /**
     * Update child node with correct status
     *
     * @param clientPath
     * @param status
     * @param lastSuccessfulTime
     * @throws KeeperException
     * @throws InterruptedException
     */
    public void updateClientInfo(String clientPath, ClientStatus status, Long lastSuccessfulTime) throws KeeperException, InterruptedException {
        ClientInfo.Builder clientInfoBuilder = getBuilderFromJson(clientPath);
        //if the path to node do not have any data, update default data to the node -- ServiceName : ALL
        List<EntityService> entityServiceList = checkAndCreateDefaultEntityServicesDataForZKNode(lastSuccessfulTime, clientInfoBuilder);
        clientInfoBuilder.clearEntityService();
        for(EntityService entityService : entityServiceList){
            clientInfoBuilder.addEntityService(entityService);
        }
        clientInfoBuilder.setLastModifiedTime(Timestamps.fromMillis(System.currentTimeMillis()));
        if (!Objects.isNull(status)) {
            clientInfoBuilder.setStatus(status);
        }
        clientInfoBuilder.setUpdatedBy(ZKPathUtils.constructThreadSpecificId("_"));
        this.updateNodeData(clientPath, ProtoJsonHelper.convertToJson(clientInfoBuilder.build()).getBytes());
    }

    /**
     * Updates the timestamp data for all entities sent to transformer
     *
     * @param clientName
     * @param serviceEnum
     * @param defaultLastSuccessfulTime
     * @param entityTypeTimeStamp
     * @throws KeeperException
     * @throws InterruptedException
     */
    public void updateEntityTimestamp(String clientName, ServiceEnum serviceEnum, Long defaultLastSuccessfulTime, Map<EntityType, Map<String, Long>> entityTypeTimeStamp) throws KeeperException {
        if (!this.zkIsConnected()) {
            LOGGER.warn(ZOOKEEPER_NOT_CONNECTED_CANNOT_UPDATE_NODE);
        }
        boolean lockAcquired = false;
        String clientPath = getClientPath(clientName, serviceEnum);
        try {
             ClientInfo.Builder clientInfoBuilderZK = getBuilderFromJson(clientPath);//get the node data from the subnode - client/service. Eg: AladdinDemo/INVESTMENTS
             lockAcquired = lockHelper.acquireLockWithRetry(clientPath);
            if (lockAcquired) {
                Map<EntityType, Map<String, Long>> entityTypeTimeStampTemp = new HashMap<>();
                entityTypeTimeStamp.forEach((entityType, stringLongMap) -> entityTypeTimeStampTemp.put(entityType, stringLongMap));
                //if the path to node do not have any data, update default data to the node -- ServiceName : ALL
                List<EntityService> entityServiceListZK = checkAndCreateDefaultEntityServicesDataForZKNode(defaultLastSuccessfulTime, clientInfoBuilderZK);
                clientInfoBuilderZK.clearEntityService();
                //even if there is a duplicate entry for an entity in ZK data
                //this code makes sure, we persist only one entry that is latest for an entity.
                entityServiceListZK.stream()
                        .collect(Collectors.toMap(EntityService::getServiceName, name -> name, (name , service) -> name))
                        .values()
                        .forEach(serviceZK ->  updateEntityServiceIntoClientInfoBuilderZK(entityTypeTimeStampTemp, clientInfoBuilderZK, serviceZK, defaultLastSuccessfulTime));

                updateTimestampForEntityServicesZK(entityTypeTimeStampTemp, clientInfoBuilderZK);

                clientInfoBuilderZK.setUpdatedBy(ZKPathUtils.constructThreadSpecificId("_"));
                String nodeDataJsonString = ProtoJsonHelper.convertToJson(clientInfoBuilderZK.build());
                LOGGER.info("Updating data at node {} to {}", clientPath, nodeDataJsonString);
                this.updateNodeData(clientPath, nodeDataJsonString.getBytes());

            } else {
                LOGGER.warn(COULDN_T_ACQUIRE_LOCK_TO_UPDATE_STATUS_TO_COMPLETE_FOR_CLIENT, clientName);
            }
        } catch (InterruptedException ex) {
            LOGGER.error(FAILED_TO_UPDATE_CLIENT_STATUS_TO_COMPLETION_IN_ZOOKEEPER_FOR_CLIENT, clientName, ex);
            Thread.currentThread().interrupt();
        } catch (Exception ex) {
            LOGGER.error(FAILED_TO_UPDATE_CLIENT_STATUS_TO_COMPLETION_IN_ZOOKEEPER_FOR_CLIENT, clientName, ex);
        }finally {
            if (lockAcquired) {//release lock in the end.
                lockHelper.releaseLock(clientPath);
            }
        }
    }

    /**
     *
     * @param entityTypeTimeStamp
     * @param clientInfoBuilderZK
     */
    private void updateTimestampForEntityServicesZK(Map<EntityType, Map<String, Long>> entityTypeTimeStamp, ClientInfo.Builder clientInfoBuilderZK) {
        for(Map.Entry<EntityType, Map<String, Long>> entry : entityTypeTimeStamp.entrySet()){
            EntityService.Builder entityServiceBuilder = EntityService.newBuilder();
            entityServiceBuilder.setServiceName(entry.getKey().name());
            Map<String, Long> entryValue = entry.getValue();
            for(Map.Entry<String, Long> subEntry: entryValue.entrySet()){
                switch(subEntry.getKey()){
                    case "FIA":
                        entityServiceBuilder.setLastSuccessfulTime(Timestamps.fromMillis(subEntry.getValue()));
                        break;
                    case "DWH":
                        entityServiceBuilder.setLastSuccessfulTimeDwh(Timestamps.fromMillis(subEntry.getValue()));
                        break;
                    default:

                        break;
                }
            }
            clientInfoBuilderZK.addEntityService(entityServiceBuilder.build());
        }
    }

    /**
     *
     * @param entityTypeTimeStamp
     * @param clientInfoBuilderZK
     * @param serviceZK
     */
    private void updateEntityServiceIntoClientInfoBuilderZK(Map<EntityType, Map<String, Long>> entityTypeTimeStamp, ClientInfo.Builder clientInfoBuilderZK, EntityService serviceZK, Long defaultLastSuccessfulTime) {
        //checks if there is only default service data in the node.
        if("ALL".equalsIgnoreCase(serviceZK.getServiceName())){
            EntityService.Builder esBuilder = EntityService.newBuilder(serviceZK);
            esBuilder.setLastSuccessfulTime(Timestamps.fromMillis(defaultLastSuccessfulTime));
            clientInfoBuilderZK.addEntityService(esBuilder.build());
            return;
        }

        Map<String, Long> timestamp = entityTypeTimeStamp.get(EntityType.valueOf(serviceZK.getServiceName()));
        if (null != timestamp) {
            if(CollectionUtils.isNotEmpty(timestamp.values())){
                Iterator<Map.Entry<String, Long>> timestampIterator = timestamp.entrySet().iterator();
                EntityService.Builder entityServiceBuilder = EntityService.newBuilder(serviceZK);
                while (timestampIterator.hasNext()) {
                    Map.Entry<String, Long> e = timestampIterator.next();
                    switch (e.getKey()) {
                        case "FIA":
                            entityServiceBuilder.setLastSuccessfulTime(Timestamps.fromMillis(e.getValue()));
                            entityTypeTimeStamp.remove(EntityType.valueOf(serviceZK.getServiceName()));
                            break;
                        case "DWH":
                            entityServiceBuilder.setLastSuccessfulTimeDwh(Timestamps.fromMillis(e.getValue()));
                            entityTypeTimeStamp.remove(EntityType.valueOf(serviceZK.getServiceName()));
                            break;
                        default:
                            //irrelevant case as of now.
                            break;
                    }
                }
                clientInfoBuilderZK.addEntityService(entityServiceBuilder.build());
            }else{
                clientInfoBuilderZK.addEntityService(serviceZK);
                entityTypeTimeStamp.remove(EntityType.valueOf(serviceZK.getServiceName()));
            }
        } else {
            clientInfoBuilderZK.addEntityService(serviceZK);
        }
    }

    @NotNull
    private List<EntityService> checkAndCreateDefaultEntityServicesDataForZKNode(Long defaultLastSuccessfulTime, ClientInfo.Builder clientInfoBuilderZK) {
        if (CollectionUtils.isEmpty(clientInfoBuilderZK.getEntityServiceList())) {
            List<EntityService> entityServiceListZK = new ArrayList<>();
            EntityService.Builder entityServiceBuilder = EntityService.newBuilder();
            entityServiceBuilder.setServiceName(ENTITY_SERVICE_NAME);
            if (!Objects.isNull(defaultLastSuccessfulTime))
                entityServiceBuilder.setLastSuccessfulTime(Timestamps.fromMillis(defaultLastSuccessfulTime));
            entityServiceListZK.add(entityServiceBuilder.build());
            return  entityServiceListZK;
        }
        return clientInfoBuilderZK.getEntityServiceList();
    }

    /**
     * This will be invoked when the server is shutting down.
     * Update the node status to COMPLETED.
     */
    public void resolveAllClientsOnShutdown() {
        clientInfoDAO.getServiceToClientMap().forEach((service, clients) -> {
            LOGGER.info("Marking all {} clients as completed", service);
            ServiceEnum serviceEnum = ServiceEnum.findService(service);
            clients.forEach(client -> updateChildNodeStatusToComplete(client.getClientName(), serviceEnum));
        });
    }

    /**
     * Read node data(json), build ClientInfo
     *
     * @param clientPath
     * @return
     * @throws KeeperException
     * @throws InterruptedException
     */
    ClientInfo.Builder getBuilderFromJson(String clientPath) throws KeeperException, InterruptedException {
        ClientInfo.Builder clientInfoBuilder = ClientInfo.newBuilder();
        byte[] childData = this.getNodeData(clientPath);
        if (childData != null) {
            ProtoJsonHelper.tryMergeFromJson(clientInfoBuilder, new String(childData));
        }
        return clientInfoBuilder;
    }
}