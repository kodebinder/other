package com.bfm.aap.pmdx.hub.util;

import com.bfm.aap.pmdx.notification.model.BusinessNotificationTypes;
import com.bfm.aap.pmdx.notification.model.EmailParams;
import com.bfm.aap.pmdx.notification.model.NotificationEnums;
import com.bfm.aap.pmdx.notification.model.NotificationParams;
import com.bfm.aap.privatemarkets.common.constant.CommonConstants;
import com.bfm.util.BFMUtil;

public final class NotificationUtil {

    private NotificationUtil() {
    }

    public static NotificationParams getNotificationParams(String message, NotificationEnums.NotificationSeverity severity, Exception ex) {
        return new NotificationParams.Builder(severity, AppConstants.APPLICATION_NAME)
                .setEmailBuilder(new EmailParams.Builder().setSubject(message)
                        .setUserName(BFMUtil.getUser())
                        .setException(ex)
                        .setMode(AppConstants.NETWORK_MODE.name()))
                .build();
    }

    public static NotificationParams getNotificationParams(NotificationEnums.NotificationSeverity severity, BusinessNotificationTypes businessNotificationTypes, Exception exception){
        return new NotificationParams.Builder(severity, AppConstants.APPLICATION_NAME)
                .setEmailBuilder(new EmailParams.Builder().setSubject("Error processing EM notification")
                        .setBusinessNotificationType(businessNotificationTypes)
                        .setUserRequest(null)
                        .setException(exception)
                        .setUserName(BFMUtil.getUser())
                        .setMode(CommonConstants.NETWORK_MODE.name()))
                .build();
    }

}
