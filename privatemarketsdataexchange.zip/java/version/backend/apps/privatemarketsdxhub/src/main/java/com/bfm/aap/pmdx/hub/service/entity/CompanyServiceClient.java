package com.bfm.aap.pmdx.hub.service.entity;

import java.util.Set;

import com.google.protobuf.Message;
import io.grpc.ManagedChannel;
import io.grpc.stub.AbstractStub;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bfm.aap.pmdx.hub.model.async.TaskResult;
import com.bfm.aap.pmdx.hub.service.process.EntityProcessor;
import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.CompanyResponse;
import com.bfm.aap.pmdx.model.util.ClientInfo;
import com.bfm.aap.pmdx.model.util.InvestUtils;
import com.bfm.aap.pmdx.services.CompanyRequest;
import com.bfm.aap.pmdx.services.CompanyServiceGrpc;
import com.bfm.aap.pmdx.services.CompanyServiceGrpc.CompanyServiceBlockingStub;
import com.bfm.service.ServiceException;

import static com.google.protobuf.util.Timestamps.fromMillis;

@Service
public class CompanyServiceClient implements EntityService {

    private static final Logger LOGGER = LoggerFactory.getLogger(CompanyServiceClient.class);
    private final RPCServiceClient rpcServiceClient;
    private final EntityProcessor<Company> companyEntityProcessor;
    private final AbstractStub<CompanyServiceBlockingStub> companyServiceStub;

    @Autowired
    public CompanyServiceClient(RPCServiceClient rpcServiceClient, ManagedChannel channel, EntityProcessor<Company> entityProcessor) {
        this.rpcServiceClient = rpcServiceClient;
        this.companyEntityProcessor = entityProcessor;
        this.companyServiceStub = CompanyServiceGrpc.newBlockingStub(channel);
    }

    @Override
    public Message getEntity(Message entityRequest) {
        throw new UnsupportedOperationException();
    }

    @Override
    @RecordStats(metricName = "CompanyService_getCompanySince", timer = true)
    public TaskResult<Set<String>> fetchEntitiesSince(long lastSuccessfulTime, ClientInfo clientInfo, InvestUtils.DataSource dataSource) {
        CompanyRequest companyRequest = CompanyRequest.newBuilder().setTimestamp(fromMillis(lastSuccessfulTime)).build();

        return rpcServiceClient.doFetchSince(CompanyServiceBlockingStub::getCompanySince, companyServiceStub, companyRequest, companyEntityProcessor, clientInfo, lastSuccessfulTime);
    }

    // TODO: check for the ClientInfo
    public String updateCompany(CompanyRequest companyRequest, ClientInfo clientInfo, Integer crmEntityId) {
        String entityId = StringUtils.EMPTY;
        LOGGER.info("Processing Company entity request for update");
        try {
            // TODO: check for what can be used
            CompanyServiceBlockingStub companyServiceBlockingStub = rpcServiceClient.getStubWithInterceptor(companyServiceStub, clientInfo);
            CompanyResponse response = companyServiceBlockingStub.updateCompany(companyRequest);
            LOGGER.info("Company entity - {} {}", crmEntityId, response.getIsUpdated() ? "updated successfully." : "failed to update.");
            // TODO: what needs to be done if there is some error from grpc
            if (response.getIsUpdated()) {
                entityId = response.getData().getCompanyId();
            } else {
                LOGGER.info("Company request : {}", companyRequest);
                LOGGER.info("Company response : {}", response);
            }
            return entityId;
        } catch (Exception e) {
            throw new ServiceException("Company gRPC request failed with status: " + e.getMessage(), e);
        }
    }
}