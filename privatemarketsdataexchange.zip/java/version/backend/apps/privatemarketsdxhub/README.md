## PrivateMarketsDXHub

PrivateMarketsDXHub  is a multi-threaded GRPC Java server in Aladdin. It is responsible to receive streams of messages from eFront GRPC server, process them and notify downstream systems in Aladdin.

PrivateMarketsDXHub  is the first point of entry in the series of servers /  transformers in Aladdin for eFront data exchange pipeline. The hub receives Assets, Portfolios and Positions from eFront grpc server.

### Getting Started

These instructions will guide you to add functionalities to leverage the different features of this server

More info: [https://webster.bfm.com/Wiki/display/AFA/PMDX+Hub](https://webster.bfm.com/Wiki/display/AFA/PMDX+Hub)

### Endpoints
The server will have an endpoint that will be called by BMS message containing an identifier

### Development Environment
Here are the VM arguments that need to be added to the run configurations in your IDE to get the server up locally

#### VM Args

##### The Standard Args

```
-DdefaultWebServer=https://dev.blackrock.com
-DAUTH_METHOD=SERVER
```

##### ADL Args

```
-DBRS.ADL_CONFIG_DIR=<Mount point for /u1/build/dev/std/adl/ folder>
-DBRS.ADL_TOPOLOGY_CONFIG=<Path to the /u1/build/dev/std/adl/adlClusterTopology.cfg file>
-DBRS.ADL_DEFAULT_LOCATION_ON_FAILURE=EWD
```

##### Server Config

```
-Dspring.config.location="file:///C:\BLKDeveloper\Codebase\privatemarketsdataexchange\java\version\backend\apps\privatemarketsdxhub\src\main\resources\PrivateMarketsDxHub.properties"
-Dmode=<RED/BLUE>
-Ddisable-secure-connection=true
```

##### Optional
Override BMS Source IDs

```
-DoverrideDXHubSourceId=54123
-DoverrideDXTransformerSourceId=54312
```

Override the target host and port for testing against DXProvider locally

```
-DEFRONT_DXPROVIDER_HOST=localhost
-DEFRONT_DXPROVIDER_PORT=<DXProvider Port>
```

##### Libmetric settings
You need to do either of the following to prevent libmetric from flooding your logs with errors.
Enable the telemetry and point StatCollector to the right host

```
-DBRS.STAT_COLLECTOR_BASE_URL=http://devcxsl001:60026/
```

Or disable libmetric when running locally. This is advised

```
-Dtelemetry=false
```

##### Encryption Args

```
-DBRS.PKILIB_DEV_MODE_ROOT_PATH=<Mount point for /u1/build/dev/ folder>
```

### Windows Example VM Args

 ```
-DdefaultWebServer=https://dev.blackrock.com
-DAUTH_METHOD=SERVER
-DBRS.ADL_DEFAULT_LOCATION_ON_FAILURE=EWD
-DBRS.ADL_CONFIG_DIR=X:/build/dev/std/adl
-DBRS.ADL_TOPOLOGY_CONFIG=X:/build/dev/std/adl/adlClusterTopology.cfg
-DBRS.PKILIB_DEV_MODE_ROOT_PATH=X:/build/dev/
-Dtelemetry=false
-Ddisable-secure-connection=true
-DEFRONT_DXPROVIDER_HOST=localhost
-DEFRONT_DXPROVIDER_PORT=50051
-DoverrideDXHubSourceId=12345
-Dmode=BLUE
-Dspring.config.location="file:///C:\BLKDeveloper\workspace\privatemarketsdataexchange\java\version\backend\apps\privatemarketsdxhub\src\main\resources\PrivateMarketsDxHub.properties"
 ```

### Mac Example VM Args

```
-DdefaultWebServer=https://dev.blackrock.com
-DAUTH_METHOD=SERVER
-DBRS.ADL_DEFAULT_LOCATION_ON_FAILURE=EWD
-DBRS.ADL_CONFIG_DIR=/u1/build/dev/std/adl
-DBRS.ADL_TOPOLOGY_CONFIG=/u1/build/dev/std/adl/adlClusterTopology.cfg
-DBRS.PKILIB_DEV_MODE_ROOT_PATH=/u1/build/dev/
-Dtelemetry=false
-Ddisable-secure-connection=true
-DEFRONT_DXPROVIDER_HOST=localhost
-DEFRONT_DXPROVIDER_PORT=50051
-Dmode=RED
-Dspring.config.location="file:////Users/adevarap/BLKDeveloper/Workspace/privatemarketsdataexchange/java/version/backend/apps/privatemarketsdxhub/src/main/resources/PrivateMarketsDxHub.properties"
```