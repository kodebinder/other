package com.bfm.aap.pmdx.transformer.service;

import static org.junit.Assert.assertNotNull;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.CompanyResponse;
import com.bfm.aap.pmdx.plugin.crm.config.CRMConfig;
import com.bfm.aap.pmdx.plugin.crm.service.CompanyBeam2Service;
import com.bfm.aap.pmdx.plugin.crm.service.CompanyETLService;
import com.bfm.aap.pmdx.transformer.util.CRMCompanyAssertionUtility;
import com.bfm.aap.pmdx.transformer.util.CRMCompanyTestData;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import cucumber.api.java8.En;

@SuppressWarnings("deprecation")
public class PrivateMarketsDXTransformerCRMCompanyStepDefinition implements En {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(PrivateMarketsDXTransformerCRMCompanyStepDefinition.class);

	@Autowired
	private CRMConfig crmConfig;
	@Autowired
	private CompanyETLService companyETLService;
	private CompanyBeam2Service companyBeam2Service;
	
	private Collection<Company> companies_transformLoadEntities_api = new LinkedList<>();
	private Collection<Company> companies_transformEntities_api_success = new LinkedList<>();
	private Collection<Company> companies_transformEntities_api_fail_missing_mandatory_fields = new LinkedList<>();
	private Collection<Company> companies_transformEntities_api_fail_missing_companyId_field = new LinkedList<>();
	private Collection<Company> companies_transformEntities_api_fail_missing_companyName_field = new LinkedList<>();
	private Collection<Company> companies_transformEntities_api_fail_missing_active_field = new LinkedList<>();
	
	List<CompanyResponse> transformLoadGuids_response_null_data;
	List<CompanyResponse> transformLoadGuids_response_empty_data;
	List<CompanyResponse> transformLoadEntities_response_success;
	List<CompanyResponse> transformLoadEntities_response_null_data;
	List<CompanyResponse> transformLoadEntities_response_empty_data;
	List<CompanyResponse> transformEntities_response_success;
	List<CompanyResponse> transformEntities_response_null_data;
	List<CompanyResponse> transformEntities_response_empty_data;
	List<CompanyResponse> transformEntities_response_missing_mandatory_fields;
	List<CompanyResponse> transformEntities_response_missing_companyId_field;
	List<CompanyResponse> transformEntities_response_missing_name_field;
	List<CompanyResponse> transformEntities_response_missing_domicile_field;
	List<CompanyResponse> transformEntities_response_missing_active_field;
	
	public PrivateMarketsDXTransformerCRMCompanyStepDefinition() {

		Given("user {string} wants to transform a company", (String user) -> {
			LOGGER.info("User : {}", user);
		});
		
		When("user sends company request to PrivateMarketsDXTransformer", () -> {
			companyBeam2Service = crmConfig.getCompanyBeam2Service(companyETLService);
			assertNotNull(companyBeam2Service);
		});

		When("user sends invalid company proto with null data to server for transformLoadGuids api", () -> {
			transformLoadGuids_response_null_data = companyBeam2Service.transformLoadGuids(null);
			printResponse(transformLoadGuids_response_null_data);
		});

		Then("company transformation unsuccessful due to null data for transformLoadGuids api", () -> {
			CRMCompanyAssertionUtility.assertFailureResponse_transformLoadGuids(transformLoadGuids_response_null_data);
		});
		
		When("user sends invalid company proto with empty collection of guids data to server for transformLoadGuids api", () -> {
			transformLoadGuids_response_empty_data = companyBeam2Service.transformLoadGuids(Collections.emptyList());
			printResponse(transformLoadGuids_response_empty_data);
		});

		Then("company transformation unsuccessful due to empty collection of guid for transformLoadGuids api", () -> {
			CRMCompanyAssertionUtility.assertFailureResponse_transformLoadGuids(transformLoadGuids_response_empty_data);
		});
		
		When("user sends valid company proto data to server for transformLoadEntities api", () -> {
			companies_transformLoadEntities_api.add(CRMCompanyTestData.getCompany_success());
			transformLoadEntities_response_success = companyBeam2Service.transformLoadEntities(companies_transformLoadEntities_api);
			printResponse(transformLoadEntities_response_success);
		});

		Then("company transformation successful for transformLoadEntities api", () -> {
			CRMCompanyAssertionUtility.assertSuccessResponse_transformLoadEntities(transformLoadEntities_response_success);
		});
		
		When("user sends invalid company proto with null data to server for transformLoadEntities api", () -> {
			transformLoadEntities_response_null_data = companyBeam2Service.transformLoadEntities(null);
			printResponse(transformLoadEntities_response_null_data);
		});

		Then("company transformation unsuccessful due to null data for transformLoadEntities api", () -> {
			CRMCompanyAssertionUtility.assertFailureResponse_transformLoadEntities_empty(transformLoadEntities_response_null_data);
		});
		
		When("user sends invalid company proto with empty collection of company entities data to server for transformLoadEntities api", () -> {
			transformLoadEntities_response_empty_data = companyBeam2Service.transformLoadEntities(Collections.emptyList());
			printResponse(transformLoadEntities_response_empty_data);
		});

		Then("company transformation unsuccessful due to empty collection of company entities for transformLoadEntities api", () -> {
			CRMCompanyAssertionUtility.assertFailureResponse_transformLoadEntities_empty(transformLoadEntities_response_empty_data);
		});
		
		When("user sends valid company proto with all mandatory field data to server for transformEntities api", () -> {
			companies_transformEntities_api_success.add(CRMCompanyTestData.getCompany_success());
			transformEntities_response_success = companyBeam2Service.transformEntities(companies_transformEntities_api_success);
			printResponse(transformEntities_response_success);
		});

		Then("company transformation successful for transformEntities api", () -> {
			CRMCompanyAssertionUtility.assertSuccessResponse_transformEntities(transformEntities_response_success);
		});
		
		When("user sends invalid company proto with null data to server for transformEntities api", () -> {
			transformEntities_response_null_data = companyBeam2Service.transformEntities(null);
			printResponse(transformEntities_response_null_data);
		});

		Then("company transformation unsuccessful due to null data for transformEntities api", () -> {
			CRMCompanyAssertionUtility.assertFailureResponse_transformEntities_empty(transformEntities_response_null_data);
		});
		
		When("user sends invalid company proto with empty collection of company entities data to server for transformEntities api", () -> {
			transformEntities_response_empty_data = companyBeam2Service.transformEntities(Collections.emptyList());
			printResponse(transformEntities_response_empty_data);
		});

		Then("company transformation unsuccessful due to empty collection of company entities for transformEntities api", () -> {
			CRMCompanyAssertionUtility.assertFailureResponse_transformEntities_empty(transformEntities_response_empty_data);
		});
		
		When("user sends invalid company proto with missing mandatory fields data to server for transformEntities api", () -> {
			companies_transformEntities_api_fail_missing_mandatory_fields.add(CRMCompanyTestData.getCompany_fail());
			transformEntities_response_missing_mandatory_fields = companyBeam2Service.transformEntities(companies_transformEntities_api_fail_missing_mandatory_fields);
			printResponse(transformEntities_response_missing_mandatory_fields);
		});

		Then("company transformation unsuccessful due to missing mandatory fields for transformEntities api", () -> {
			CRMCompanyAssertionUtility.assertFailureResponse_transformEntities(transformEntities_response_missing_mandatory_fields);
		});
		
		When("user sends invalid company proto with missing companyId field data to server for transformEntities api", () -> {
			companies_transformEntities_api_fail_missing_companyId_field.add(CRMCompanyTestData.getCompany_fail_missing_companyId());
			transformEntities_response_missing_companyId_field = companyBeam2Service.transformEntities(companies_transformEntities_api_fail_missing_companyId_field);
			printResponse(transformEntities_response_missing_companyId_field);
		});

		Then("company transformation unsuccessful due to missing companyId field for transformEntities api", () -> {
			CRMCompanyAssertionUtility.assertFailureResponse_transformEntities(transformEntities_response_missing_companyId_field);
		});
		
		When("user sends invalid company proto with missing name field data to server for transformEntities api", () -> {
			companies_transformEntities_api_fail_missing_companyName_field.add(CRMCompanyTestData.getCompany_fail_missing_companyName());
			transformEntities_response_missing_name_field = companyBeam2Service.transformEntities(companies_transformEntities_api_fail_missing_companyName_field);
			printResponse(transformEntities_response_missing_name_field);
		});

		Then("company transformation unsuccessful due to missing name field for transformEntities api", () -> {
			CRMCompanyAssertionUtility.assertFailureResponse_transformEntities(transformEntities_response_missing_name_field);
		});
		
		When("user sends invalid company proto with missing active field data to server for transformEntities api", () -> {
			companies_transformEntities_api_fail_missing_active_field.add(CRMCompanyTestData.getCompany_fail_missing_active());
			transformEntities_response_missing_active_field = companyBeam2Service.transformEntities(companies_transformEntities_api_fail_missing_active_field);
			printResponse(transformEntities_response_missing_active_field);
		});

		Then("company transformation unsuccessful due to missing active field for transformEntities api", () -> {
			CRMCompanyAssertionUtility.assertFailureResponse_transformEntities(transformEntities_response_missing_active_field);
		});

	}
	
		private void printResponse(List<CompanyResponse> response) {
			Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().create();
			LOGGER.info("List of CompanyResponse : {}", (gson.toJson(response)));
		}
		
}
