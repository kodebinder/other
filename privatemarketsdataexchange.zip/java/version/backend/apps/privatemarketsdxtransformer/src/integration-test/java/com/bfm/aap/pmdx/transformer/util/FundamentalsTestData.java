package com.bfm.aap.pmdx.transformer.util;

import java.util.LinkedList;
import java.util.List;

import com.bfm.aap.pmdx.model.BalanceSheet;
import com.bfm.aap.pmdx.model.Fundamentals;
import com.bfm.aap.pmdx.model.FundamentalsResponse;
import com.bfm.aap.pmdx.model.IncomeStatement;
import com.bfm.aap.pmdx.model.OperatingDataType;
import com.bfm.aap.pmdx.model.util.ReferenceLevel;
import com.bfm.aap.pmdx.transformer.constants.CucumberConstantsTransformer;
import com.bfm.aap.pmdx.transformer.service.FundamentalsTransformerService;
import com.google.protobuf.Timestamp;

public class FundamentalsTestData {
	private static Timestamp date = Timestamp.newBuilder().setSeconds(23233443).build();
	
	private static Fundamentals.Builder getFundamentalsProto(){
		return Fundamentals.newBuilder()
				.setCompanyId("F86125D7361844448EEA00B10AAC9996")
				.setReferenceDate(date)
				.setOperatingDataDate(date)
				.setReportingCurrency("USD")
				.setOperatingDataType(OperatingDataType.ACTUALS)
				.setNumberOfEmployees(100);
	}

	public static List<Fundamentals> getFundamentalsScenarioSuccess() {
		Fundamentals fundamentals = getFundamentalsProto()
				.setBalanceSheet(BalanceSheet.newBuilder()
						.setEnterpriseValue(100.90)
						.setTotalEquityValue(88.9)
						.setNetDebt(23.1))
				.setIncomeStatement(IncomeStatement.newBuilder()
						.setRevenue(99.9))
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE)
						.setReferenceLevel(ReferenceLevel.COMPANY_ASSET_LEVEL))
				.setSource("INVEST")
				.build();
		
		List<Fundamentals> fundamentalsList = new LinkedList<>();
		fundamentalsList.add(fundamentals);
		return fundamentalsList;
	}
	
	public static List<Fundamentals> getFundamentalsMissingBalanceSheetScenario() {
		Fundamentals fundamentals = getFundamentalsProto()
				.setIncomeStatement(IncomeStatement.newBuilder()
						.setRevenue(99.9))
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE)
						.setReferenceLevel(ReferenceLevel.COMPANY_ASSET_LEVEL))
				.setSource("INVEST")
				.build();
		
		List<Fundamentals> fundamentalsList = new LinkedList<>();
		fundamentalsList.add(fundamentals);
		return fundamentalsList;
	}
	
	public static List<Fundamentals> getFundamentalsMissingIncomeStatementScenario() {
		Fundamentals fundamentals = getFundamentalsProto()
				.setBalanceSheet(BalanceSheet.newBuilder()
						.setEnterpriseValue(100.90)
						.setTotalEquityValue(88.9)
						.setNetDebt(23.1))
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE)
						.setReferenceLevel(ReferenceLevel.COMPANY_ASSET_LEVEL))
				.setSource("INVEST")
				.build();
		
		List<Fundamentals> fundamentalsList = new LinkedList<>();
		fundamentalsList.add(fundamentals);
		return fundamentalsList;
	}
	
	public static List<Fundamentals> getFundamentalsMissingEntityInfoScenario() {
		Fundamentals fundamentals = getFundamentalsProto()
				.setBalanceSheet(BalanceSheet.newBuilder()
						.setEnterpriseValue(100.90)
						.setTotalEquityValue(88.9)
						.setNetDebt(23.1))
				.setIncomeStatement(IncomeStatement.newBuilder()
						.setRevenue(99.9))
				.setSource("INVEST")
				.build();
		
		List<Fundamentals> fundamentalsList = new LinkedList<>();
		fundamentalsList.add(fundamentals);
		return fundamentalsList;
	}
	
	public static List<Fundamentals> getFundamentalsMissingSourceScenario() {
		Fundamentals fundamentals = getFundamentalsProto()
				.setBalanceSheet(BalanceSheet.newBuilder()
						.setEnterpriseValue(100.90)
						.setTotalEquityValue(88.9)
						.setNetDebt(23.1))
				.setIncomeStatement(IncomeStatement.newBuilder()
						.setRevenue(99.9))
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE)
						.setReferenceLevel(ReferenceLevel.COMPANY_ASSET_LEVEL))
				.build();
		
		List<Fundamentals> fundamentalsList = new LinkedList<>();
		fundamentalsList.add(fundamentals);
		return fundamentalsList;
	}
	
	public static List<Fundamentals> getFundamentalsMissingBalanceSheetAndIncomeStatementScenario() {
		Fundamentals fundamentals = getFundamentalsProto()
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE)
						.setReferenceLevel(ReferenceLevel.COMPANY_ASSET_LEVEL))
				.setSource("INVEST")
				.build();
		
		List<Fundamentals> fundamentalsList = new LinkedList<>();
		fundamentalsList.add(fundamentals);
		return fundamentalsList;
	}
	
	public static List<Fundamentals> getFundamentalsMissingBalanceSheetIncomeStatementAndEntityInfoScenario() {
		Fundamentals fundamentals = getFundamentalsProto()
				.setSource("INVEST")
				.build();
		
		List<Fundamentals> fundamentalsList = new LinkedList<>();
		fundamentalsList.add(fundamentals);
		return fundamentalsList;
	}
	
	public static List<Fundamentals> getFundamentalsMissingAllMandatoryFieldsScenario() {
		Fundamentals fundamentals = getFundamentalsProto()
				.build();
		
		List<Fundamentals> fundamentalsList = new LinkedList<>();
		fundamentalsList.add(fundamentals);
		return fundamentalsList;
	}

	public static List<FundamentalsResponse> getFundamentalsResponse(
			FundamentalsTransformerService service, List<Fundamentals> fundamentals) {
		return service.transformLoadEntities(fundamentals);
	}

}
