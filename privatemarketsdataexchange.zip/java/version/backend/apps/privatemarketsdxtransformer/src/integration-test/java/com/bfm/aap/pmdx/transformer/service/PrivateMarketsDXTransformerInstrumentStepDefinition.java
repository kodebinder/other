package com.bfm.aap.pmdx.transformer.service;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.bfm.aap.pmdx.model.Instrument;
import com.bfm.aap.pmdx.model.InstrumentResponse;
import com.bfm.aap.pmdx.redblue.PmdxServiceType;
import com.bfm.aap.pmdx.transformer.constants.CucumberConstantsTransformer;
import com.bfm.aap.pmdx.transformer.util.InstrumentTestData;
import com.bfm.aap.pmdx.transformer.util.TestHelper;
import com.bfm.aap.privatemarkets.dao.CreditRatingHistDao;
import com.bfm.aap.privatemarkets.dao.CusipAliasesDao;
import com.bfm.aap.privatemarkets.dao.EqDataDao;
import com.bfm.aap.privatemarkets.dao.NewIssueInfoDao;
import com.bfm.aap.privatemarkets.dao.OptionsDataDao;
import com.bfm.aap.privatemarkets.dao.SecurityMasterDao;
import com.bfm.aap.privatemarkets.dao.model.CreditRatingHist;
import com.bfm.aap.privatemarkets.dao.model.EqData;
import com.bfm.aap.privatemarkets.dao.model.NewIssueInfo;
import com.bfm.aap.privatemarkets.dao.model.OptionsData;
import com.bfm.aap.privatemarkets.dao.model.SecMaster;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import cucumber.api.java8.En;

@SuppressWarnings("deprecation")
public class PrivateMarketsDXTransformerInstrumentStepDefinition implements En {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(PrivateMarketsDXTransformerInstrumentStepDefinition.class);

	private static final String DEFAULT_TO_N = "N";
	private static final String DEFAULT_TO_Y = "Y";
	private static final String DEFAULT_EXCHANGE = "XXX";
	private static final String DEFAULT_MARKET_MIC = "XXXX";
	private static final String DEFAULT_UNDERLYING_CUSIP = "123456782";
	private List<InstrumentResponse> instrumentResponses;

	@Autowired
	@Qualifier("newIssueInfoDaoImpl")
	private NewIssueInfoDao newIssueInfoDao;

	@Autowired
	@Qualifier("eqDataDaoImpl")
	private EqDataDao eqDataDao;

	@Autowired
	@Qualifier("optionsDataDaoImpl")
	private OptionsDataDao optionsDataDao;

	@Autowired
	@Qualifier("creditRatingHistDaoImpl")
	private CreditRatingHistDao creditRatingHistDao;

	@Autowired
	@Qualifier("cusipAliasesDaoImpl")
	private CusipAliasesDao cusipAliasesDao;

	@Autowired
	@Qualifier("securityMasterDaoImpl")
	private SecurityMasterDao securityMasterDao;

	public PrivateMarketsDXTransformerInstrumentStepDefinition() {

		Given("user {string} wants to transform an instrument", (String user) -> {
			LOGGER.info("User : {}", user);
		});

		When("user sends valid instrument proto to server", () -> {
			instrumentResponses = InstrumentTestData.getInstrumentResponse(getInstrumentTransformerService(),
					InstrumentTestData.getInstrumentsScenarioSuccess());
			printResponse(instrumentResponses);
		});

		Then("instrument transformation successful", () -> {
			assertSuccessResponse();
			Instrument instrument = InstrumentTestData.getInstrumentsScenarioSuccess().get(0);
			String cusip = cusipAliasesDao.getCusipByEFrontId(instrument.getInstrumentDetails(0).getInstrumentId());
			Optional<List<CreditRatingHist>> creditRatingList = creditRatingHistDao.fetchByCusip(cusip);
			assertEquals(4, creditRatingList.get().size());
		});

		When("user sends invalid instrument proto with missing mandatory args data to server", () -> {
			instrumentResponses = InstrumentTestData.getInstrumentResponse(getInstrumentTransformerService(),
					InstrumentTestData.getInstrumentsScenarioMissingMandatoryArgs());
			printResponse(instrumentResponses);
		});

		Then("instrument transformation unsuccessful due to missing mandatory args", () -> {
			assertUnsuccessResponseValidationFail();
		});

		When("user sends invalid instrument proto with missing instrumentDetails data to server", () -> {
			instrumentResponses = InstrumentTestData.getInstrumentResponse(getInstrumentTransformerService(),
					InstrumentTestData.getInstrumentsScenarioMissingInstrumentDetails());
			printResponse(instrumentResponses);
		});

		Then("instrument transformation unsuccessful due to missing instrumentDetails", () -> {
			assertUnsuccessResponse();
		});

		When("user sends invalid instrument proto with invalid instrumentDetails data to server", () -> {
			instrumentResponses = InstrumentTestData.getInstrumentResponse(getInstrumentTransformerService(),
					InstrumentTestData.getInstrumentsScenarioInvalidInstrumentDetails());
			printResponse(instrumentResponses);
		});

		Then("instrument transformation unsuccessful due to invalid instrumentDetails", () -> {
			assertUnsuccessResponse();
		});

		When("user sends valid instrument proto with attributes secGroup: Loan and secType: Term to server", () -> {
			instrumentResponses = InstrumentTestData.getInstrumentResponse(getInstrumentTransformerService(),
					InstrumentTestData.getInstrumentsScenarioSuccessValidSecGroupLoanAndValidSecTypeTerm());
			printResponse(instrumentResponses);
		});

		Then("instrument transformation successful for secGroup: Loan and secType: Term", () -> {
			assertSuccessResponse();
			Instrument instrument = InstrumentTestData
					.getInstrumentsScenarioSuccessValidSecGroupLoanAndValidSecTypeTerm().get(0);
			String cusip = cusipAliasesDao.getCusipByEFrontId(instrument.getInstrumentDetails(0).getInstrumentId());
			Optional<List<CreditRatingHist>> creditRatingList = creditRatingHistDao.fetchByCusip(cusip);
			assertEquals(4, creditRatingList.get().size());
		});

		When("user sends valid instrument proto with attributes secGroup: Equity and secType: Private to server",
				() -> {
					instrumentResponses = InstrumentTestData.getInstrumentResponse(getInstrumentTransformerService(),
							InstrumentTestData
									.getInstrumentsScenarioSuccessValidSecGroupEquityAndValidSecTypePrivate());
					printResponse(instrumentResponses);
				});

		Then("instrument transformation successful for secGroup: Equity and secType: Private", () -> {
			assertSuccessResponse();
			Instrument instrument = InstrumentTestData
					.getInstrumentsScenarioSuccessValidSecGroupEquityAndValidSecTypePrivate().get(0);
			String cusip = cusipAliasesDao.getCusipByEFrontId(instrument.getInstrumentDetails(0).getInstrumentId());
			Optional<List<CreditRatingHist>> creditRatingList = creditRatingHistDao.fetchByCusip(cusip);
			assertEquals(4, creditRatingList.get().size());
			NewIssueInfo newIssueInfo = newIssueInfoDao.loadNewIssueInfo(cusip);
			assertEquals(DEFAULT_TO_N, newIssueInfo.getPriceAsPct());
		});

		When("user sends valid instrument proto with attributes secGroup: Equity and secType: Warrant to server",
				() -> {
					instrumentResponses = InstrumentTestData.getInstrumentResponse(getInstrumentTransformerService(),
							InstrumentTestData
									.getInstrumentsScenarioSuccessValidSecGroupEquityAndValidSecTypeWarrant());
					printResponse(instrumentResponses);
				});

		Then("instrument transformation successful for secGroup: Equity and secType: Warrant", () -> {
			assertSuccessResponse();
			Instrument instrument = InstrumentTestData
					.getInstrumentsScenarioSuccessValidSecGroupEquityAndValidSecTypeWarrant().get(0);
			String cusip = cusipAliasesDao.getCusipByEFrontId(instrument.getInstrumentDetails(0).getInstrumentId());
			Optional<List<CreditRatingHist>> creditRatingList = creditRatingHistDao.fetchByCusip(cusip);
			assertEquals(4, creditRatingList.get().size());
			NewIssueInfo newIssueInfo = newIssueInfoDao.loadNewIssueInfo(cusip);
			assertEquals(DEFAULT_TO_N, newIssueInfo.getPriceAsPct());
			OptionsData optionsData = optionsDataDao.loadOptionsData(cusip);
			assertEquals(DEFAULT_EXCHANGE, optionsData.getExchange());
			assertEquals(DEFAULT_UNDERLYING_CUSIP, optionsData.getUnderlyingCusip());
			EqData eqData = eqDataDao.loadEqData(cusip);
			assertEquals(DEFAULT_MARKET_MIC, eqData.getMarketMic());
		});

		When("user sends valid instrument proto with valid issuer data to server", () -> {
			instrumentResponses = InstrumentTestData.getInstrumentResponse(getInstrumentTransformerService(),
					InstrumentTestData.getInstrumentsForValidIssuer());
			printResponse(instrumentResponses);
		});

		Then("instrument transformation should be successful due to valid issuer", () -> {
			successResponseWithValidIssuer();
			Instrument instrument = InstrumentTestData.getInstrumentsForValidIssuer().get(0);
			String cusip = cusipAliasesDao.getCusipByEFrontId(instrument.getInstrumentDetails(0).getInstrumentId());
			Optional<List<CreditRatingHist>> creditRatingList = creditRatingHistDao.fetchByCusip(cusip);
			assertEquals(4, creditRatingList.get().size());
		});

		When("user sends invalid instrument proto with invalid issuer data to server", () -> {
			instrumentResponses = InstrumentTestData.getInstrumentResponse(getInstrumentTransformerService(),
					InstrumentTestData.getInstrumentsForInvalidIssuer());
			printResponse(instrumentResponses);
		});

		Then("instrument transformation unsuccessful due to invalid issuer", () -> {
			unSuccessResponseWithInvalidIssuer();
		});

		When("user sends valid instrument proto with empty issuer data to server", () -> {
			instrumentResponses = InstrumentTestData.getInstrumentResponse(getInstrumentTransformerService(),
					InstrumentTestData.getInstrumentsForEmptyIssuer());
			printResponse(instrumentResponses);
		});

		Then("instrument transformation should be successful due to default issuer", () -> {
			successResponseWithValidIssuer();
			Instrument instrument = InstrumentTestData.getInstrumentsForEmptyIssuer().get(0);
			String cusip = cusipAliasesDao.getCusipByEFrontId(instrument.getInstrumentDetails(0).getInstrumentId());
			Optional<List<CreditRatingHist>> creditRatingList = creditRatingHistDao.fetchByCusip(cusip);
			assertEquals(4, creditRatingList.get().size());
		});

		When("user sends valid instrument proto with invalid issuer data to server", () -> {
			instrumentResponses = InstrumentTestData.getInstrumentResponse(getInstrumentTransformerService(),
					InstrumentTestData.getInstrumentsForEmptyIssuer());
			printResponse(instrumentResponses);
		});

		Then("instrument transformation should be successful and existing issuer should not be changed", () -> {
			successResponseWithValidIssuer();
			Instrument instrument = InstrumentTestData.getInstrumentsForEmptyIssuer().get(0);
			String cusip = cusipAliasesDao.getCusipByEFrontId(instrument.getInstrumentDetails(0).getInstrumentId());
			Optional<List<CreditRatingHist>> creditRatingList = creditRatingHistDao.fetchByCusip(cusip);
			assertEquals(4, creditRatingList.get().size());
		});

		When("user sends a company instrument proto without instrumentId to server", () -> {
			instrumentResponses = InstrumentTestData.getInstrumentResponse(getInstrumentTransformerService(),
					InstrumentTestData.getCompanyInstrumentWithoutInstrumentId());
			printResponse(instrumentResponses);
		});

		Then("instrument transformation should be unsuccessful due to missing Instrument Id", () -> {
			boolean success = instrumentResponses.get(0).getSuccess();
			String message = instrumentResponses.get(0).getMessage();
			assertEquals(false, success);
			assertEquals(true, message.contains(
					"Instrument Validation failed. Basic validation failure: [instrumentDetails[0].instrumentId: is missing but it is required]"));

		});

		When("user sends a deals instrument proto without dealStructuringId to server", () -> {
			instrumentResponses = InstrumentTestData.getInstrumentResponse(getInstrumentTransformerService(),
					InstrumentTestData.getDealsInstrumentWithoutDealStructuringId());
			printResponse(instrumentResponses);
		});

		Then("instrument transformation should be unsuccessful due to missing dealStructuring Id", () -> {
			boolean success = instrumentResponses.get(0).getSuccess();
			String message = instrumentResponses.get(0).getMessage();
			assertEquals(false, success);
			assertEquals(true, message.contains(
					"Instrument Validation failed. Basic validation failure: [instrumentDetails[0].dealStructuringId: is missing but it is required]"));

		});

		When("user sends a deals instrument proto without dealId to server", () -> {
			instrumentResponses = InstrumentTestData.getInstrumentResponse(getInstrumentTransformerService(),
					InstrumentTestData.getDealsInstrumentsWithoutDealId());
			printResponse(instrumentResponses);
		});

		Then("deals instrument transformation should be unsuccessful due to missing dealId", () -> {
			boolean success = instrumentResponses.get(0).getSuccess();
			String message = instrumentResponses.get(0).getMessage();
			assertEquals(false, success);
			assertEquals(true, message.contains(
					"Instrument Validation failed. Basic validation failure: [dealDetails.dealId: is missing but it is required]"));
		});

		When("user sends a deals instrument proto without assetId to server", () -> {
			instrumentResponses = InstrumentTestData.getInstrumentResponse(getInstrumentTransformerService(),
					InstrumentTestData.getDealsInstrumentWithoutAssetId());
			printResponse(instrumentResponses);
		});

		Then("deals instrument transformation should be unsuccessful due to missing assetId", () -> {
			assertUnsuccessResponseValidationFail();

		});

		When("user sends valid deals instrument proto data to server", () -> {
			instrumentResponses = InstrumentTestData.getInstrumentResponse(getInstrumentTransformerService(),
					InstrumentTestData.getDealsInstruments());
			printResponse(instrumentResponses);
		});

		Then("deals instrument transformation should be successful", () -> {
			boolean success = instrumentResponses.get(0).getSuccess();
			String message = instrumentResponses.get(0).getMessage();
			assertEquals(false, success);
			assertEquals(true, message.contains("Failed requests: 1\nSuccessful requests: 1"));
			Instrument instrument = InstrumentTestData.getDealsInstruments().get(0);
			String cusip = cusipAliasesDao
					.getCusipByEFrontId(instrument.getInstrumentDetails(0).getDealStructuringId());
			Optional<List<CreditRatingHist>> creditRatingList = creditRatingHistDao.fetchByCusip(cusip);
			assertEquals(4, creditRatingList.get().size());
		});

		When("user sends a valid debt deals instrument proto data to server", () -> {
			instrumentResponses = InstrumentTestData.getInstrumentResponse(getInstrumentTransformerService(),
					InstrumentTestData.getDebtDealInstruments());
			printResponse(instrumentResponses);
		});

		Then("debt deals instrument transformation should be successful", () -> {
			boolean success = instrumentResponses.get(0).getSuccess();
			String message = instrumentResponses.get(0).getMessage();
			assertEquals(false, success);
			assertEquals(true, message.contains("Failed requests: 1\nSuccessful requests: 1"));
			Instrument instrument = InstrumentTestData.getDebtDealInstruments().get(0);
			String cusip = cusipAliasesDao
					.getCusipByEFrontId(instrument.getInstrumentDetails(0).getDealStructuringId());
			Optional<List<CreditRatingHist>> creditRatingList = creditRatingHistDao.fetchByCusip(cusip);
			assertEquals(4, creditRatingList.get().size());
			SecMaster secMaster = securityMasterDao.getSecurity(cusip);
			assertEquals(DEFAULT_TO_N, secMaster.getLiquidity());
			NewIssueInfo newIssueInfo = newIssueInfoDao.loadNewIssueInfo(cusip);
			assertEquals(DEFAULT_TO_Y, newIssueInfo.getPriceAsPct());
		});

		When("user sends an instrument proto with invalid secGroup and sectype", () -> {
			instrumentResponses = InstrumentTestData.getInstrumentResponse(getInstrumentTransformerService(),
					InstrumentTestData.getInstrumentsWithInvalidSecGroupSecType());
			printResponse(instrumentResponses);
		});

		Then("instrument transformation should be unsuccessful due to invalid secGroup and sectype", () -> {
			boolean success = instrumentResponses.get(0).getSuccess();
			String message = instrumentResponses.get(0).getMessage();
			assertEquals(false, success);
			assertEquals(true, message.contains("Invalid SecGroup/SecType for Instrument"));
		});

		When("user sends a company instrument proto without InstrumentSource to server", () -> {
			instrumentResponses = InstrumentTestData.getInstrumentResponse(getInstrumentTransformerService(),
					InstrumentTestData.getInstrumentsWithoutInstrumentSource());
			printResponse(instrumentResponses);
		});

		Then("instrument transformation should be unsuccessful due to missing InstrumentSource", () -> {
			boolean success = instrumentResponses.get(0).getSuccess();
			String message = instrumentResponses.get(0).getMessage();
			assertEquals(false, success);
			assertEquals(true, message.contains(
					"Instrument Validation failed. Basic validation failure: [instrumentDetails[0].instrumentSource: is missing but it is required]"));
		});

	}

	private void printResponse(List<InstrumentResponse> instrumentResponses) {
		Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().create();
		LOGGER.info("List of InstrumentResponse : {}", (gson.toJson(instrumentResponses)));
	}

	private void assertSuccessResponse() {
		boolean success = instrumentResponses.get(0).getSuccess();
		String message = instrumentResponses.get(0).getMessage();
		assertEquals(false, success);
		assertEquals(true, message.contains("Failed requests: 1\nSuccessful requests: 1"));
	}

	private void assertUnsuccessResponseValidationFail() {
		boolean success = instrumentResponses.get(0).getSuccess();
		String message = instrumentResponses.get(0).getMessage();
		assertEquals(false, success);
		assertEquals(true, message.contains(
				"Instrument Validation failed. Basic validation failure: [assetId: is missing but it is required]"));
	}

	private void assertUnsuccessResponse() {
		boolean success = instrumentResponses.get(0).getSuccess();
		String message = instrumentResponses.get(0).getMessage();
		assertEquals(false, success);
		assertEquals(true, message.contains("All of the requests failed"));
	}

	private void successResponseWithValidIssuer() {
		boolean success = instrumentResponses.get(0).getSuccess();
		assertEquals(false, success);
	}

	private InstrumentTransformerService getInstrumentTransformerService() {
		return TestHelper.getEntityTransformerBeam2Service(InstrumentTransformerService.class,
				PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_INSTRUMENTS,
				CucumberConstantsTransformer.CURRENT_NETWORK_MODE);
	}

	private void unSuccessResponseWithInvalidIssuer() {
		boolean success = instrumentResponses.get(0).getSuccess();
		assertEquals(false, success);
	}

}