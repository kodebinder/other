package com.bfm.aap.pmdx.transformer.service;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Collections;
import java.util.List;

import com.bfm.aap.pmdx.model.ShareClassResponse;
import com.bfm.aap.pmdx.redblue.PmdxServiceType;
import com.bfm.aap.pmdx.transformer.constants.CucumberConstantsTransformer;
import com.bfm.aap.pmdx.transformer.util.ShareClassTestData;
import com.bfm.aap.pmdx.transformer.util.TestHelper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import io.cucumber.java8.En;

public class PrivateMarketsDXTransformerShareClassStepDefinition implements En {
	private List<ShareClassResponse> shareClassResponses;

	PrivateMarketsDXTransformerShareClassStepDefinition() {

		Given("user {string} wants to transform an shareclass", (String user) -> {
		});

		When("user sends shareclass proto with valid data to server", () -> {
			shareClassResponses = getShareClassTransformerService()
					.transformLoadEntities(Collections.singletonList(ShareClassTestData.getShareClassWithValidData()));
			printResponse(shareClassResponses);
		});

		When("user sends shareclass proto having invalid portfolio guid to server", () -> {
			shareClassResponses = getShareClassTransformerService().transformLoadEntities(
					Collections.singletonList(ShareClassTestData.getShareClassWithInvalidPortfolioGuID()));
			printResponse(shareClassResponses);
		});

		When("user sends shareclass proto without ShareClass ShortName to server", () -> {
			shareClassResponses = getShareClassTransformerService().transformLoadEntities(
					Collections.singletonList(ShareClassTestData.getShareClassWithoutShareClassShortname()));
			printResponse(shareClassResponses);
		});

		When("user sends shareclass proto without currency to server", () -> {
			shareClassResponses = getShareClassTransformerService().transformLoadEntities(
					Collections.singletonList(ShareClassTestData.getShareClassWithoutCurrency()));
			printResponse(shareClassResponses);
		});

		When("user sends an existing shareclass proto with updated valid currency data to server", () -> {
			shareClassResponses = getShareClassTransformerService().transformLoadEntities(
					Collections.singletonList(ShareClassTestData.getExistingShareClassWithUpdatedCurrency()));
			printResponse(shareClassResponses);
		});

		When("user sends an existing shareclass proto with updated invalid currency data to server", () -> {
			shareClassResponses = getShareClassTransformerService().transformLoadEntities(
					Collections.singletonList(ShareClassTestData.getExistingShareClassWithUpdatedIncorrectCurrency()));
			printResponse(shareClassResponses);
		});

		Then("shareclass should be transformed", () -> {
			boolean success = shareClassResponses.get(0).getSuccess();
			int errorMessageLength = shareClassResponses.get(0).getMessage().length();
			assertTrue(success);
			assertEquals(0, errorMessageLength);
		});

		Then("we get a validation failed for invalid portfolio guid", () -> {
			boolean success = shareClassResponses.get(0).getSuccess();
			int errorMessageLength = shareClassResponses.get(0).getMessage().length();
			assertEquals(false, success);
			assertNotEquals(0, errorMessageLength);
		});

		Then("we get a validation failed for missing ShareClass ShortName", () -> {
			boolean success = shareClassResponses.get(0).getSuccess();
			int errorMessageLength = shareClassResponses.get(0).getMessage().length();
			assertEquals(false, success);
			assertNotEquals(0, errorMessageLength);
		});

		Then("we get a validation failed for missing currency", () -> {
			boolean success = shareClassResponses.get(0).getSuccess();
			int errorMessageLength = shareClassResponses.get(0).getMessage().length();
			assertEquals(false, success);
			assertNotEquals(0, errorMessageLength);
		});

		Then("shareclass update should be successful", () -> {
			boolean success = shareClassResponses.get(0).getSuccess();
			int errorMessageLength = shareClassResponses.get(0).getMessage().length();
			assertTrue(success);
			assertEquals(0, errorMessageLength);
		});

		Then("shareclass update failed for invalid currency data", () -> {
			boolean success = shareClassResponses.get(0).getSuccess();
			int errorMessageLength = shareClassResponses.get(0).getMessage().length();
			assertFalse(success);
			assertNotEquals(0, errorMessageLength);
		});
	}

	private void printResponse(List<ShareClassResponse> shareClassResponses) {
		Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().create();
		System.out.println(gson.toJson(shareClassResponses));
	}

	private ShareClassTransformerService getShareClassTransformerService() {
		return TestHelper.getEntityTransformerBeam2Service(ShareClassTransformerService.class,
				PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_SHARE_CLASS,
				CucumberConstantsTransformer.CURRENT_NETWORK_MODE);
	}
}
