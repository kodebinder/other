package com.bfm.aap.pmdx.transformer.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bfm.aap.pmdx.model.AssetResponse;
import com.bfm.aap.pmdx.redblue.PmdxServiceType;
import com.bfm.aap.pmdx.transformer.constants.CucumberConstantsTransformer;
import com.bfm.aap.pmdx.transformer.util.AssetTestData;
import com.bfm.aap.pmdx.transformer.util.TestHelper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import cucumber.api.java8.En;

@SuppressWarnings("deprecation")
public class PrivateMarketsDXTransformerAssetStepDefinition implements En {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(PrivateMarketsDXTransformerAssetStepDefinition.class);
	
	private List<AssetResponse> assetResponses;

	public PrivateMarketsDXTransformerAssetStepDefinition() {
		
		Given("user {string} wants to transform an asset", (String user) -> {
			LOGGER.info("User : {}",user);
		});

		When("user sends valid asset proto to server", () -> {
			assetResponses = AssetTestData.getAssetResponse(getAssetTransformerService(),AssetTestData.getAssetsScenarioSuccess());
			printResponse(assetResponses);
		});

		Then("asset transformation successful", () -> {
			assertSuccessResponse();
		});

		When("user sends invalid asset proto with missing assetId data to server", () -> {
			assetResponses = AssetTestData.getAssetResponse(getAssetTransformerService(),AssetTestData.getAssetsScenarioMissingAssetIdField());
			printResponse(assetResponses);
		});

		Then("asset transformation unsuccessful due to missing assetId", () -> {
			assertFailureResponse();
		});
		
		When("user sends invalid asset proto with missing assetName data to server", () -> {
			assetResponses = AssetTestData.getAssetResponse(getAssetTransformerService(),AssetTestData.getAssetsScenarioMissingAssetNameField());
			printResponse(assetResponses);
		});

		Then("asset transformation unsuccessful due to missing assetName", () -> {
			assertFailureResponse();
		});

		When("user sends invalid asset proto with missing domicile data to server", () -> {
			assetResponses = AssetTestData.getAssetResponse(getAssetTransformerService(),AssetTestData.getAssetsScenarioMissingDomicileField());
			printResponse(assetResponses);
		});

		Then("asset transformation unsuccessful due to missing domicile", () -> {
			assertFailureResponse();
		});
		
		When("user sends invalid asset proto with invalid clientName data to server", () -> {
			assetResponses = AssetTestData.getAssetResponse(getAssetTransformerService(),AssetTestData.getAssetsScenarioInvalidClientName());
			printResponse(assetResponses);
		});

		Then("asset transformation unsuccessful due to invalid clientName", () -> {
			assertFailureResponse();
		});

		When("user sends invalid asset proto with invalid assetType data to server", () -> {
			assetResponses = AssetTestData.getAssetResponse(getAssetTransformerService(),AssetTestData.getAssetsScenarioInvalidAssetType());
			printResponse(assetResponses);
		});

		Then("asset transformation unsuccessful due to invalid assetType", () -> {
			assertFailureResponse();
		});

	}
	
	private void printResponse(List<AssetResponse> assetResponses) {
		Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().create();
		LOGGER.info("List of AssetResponse : {}",(gson.toJson(assetResponses)));
	}
	
	private void assertSuccessResponse() {
		boolean success = assetResponses.get(0).getSuccess();
		assertEquals(true, success);
	}
	
	private void assertFailureResponse() {
		boolean success = assetResponses.get(0).getSuccess();
		assertEquals(false, success);
	}
	
	private AssetTransformerService getAssetTransformerService() {
		return TestHelper.getEntityTransformerBeam2Service(AssetTransformerService.class, 
				PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_ASSET, 
				CucumberConstantsTransformer.CURRENT_NETWORK_MODE);
	}

}
