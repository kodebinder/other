package com.bfm.aap.pmdx.transformer.runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features = "classpath:features", 
				 glue = "com.bfm.aap.pmdx.transformer.service",
				 plugin = { "html:src/integration-test/resources/cucumber",
						    "json:src/integration-test/resources/cucumber/cucumber-privatemarketsdxtransformer.json",
						    "junit:src/integration-test/resources/cucumber/cucumber.xml",
						    "pretty:src/integration-test/resources/cucumber/cucumber-pretty.txt" },
				 tags = "not @ignore")
public class PrivateMarketsDXTransformerTestSuiteIT {

}
