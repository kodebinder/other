package com.bfm.aap.pmdx.transformer.service;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bfm.aap.pmdx.model.TransactionResponse;
import com.bfm.aap.pmdx.redblue.PmdxServiceType;
import com.bfm.aap.pmdx.transformer.constants.CucumberConstantsTransformer;
import com.bfm.aap.pmdx.transformer.util.TestHelper;
import com.bfm.aap.pmdx.transformer.util.TransactionTestData;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import io.cucumber.java8.En;

public class PrivateMarketsDXTransformerTransactionStepDefinition implements En {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(PrivateMarketsDXTransformerTransactionStepDefinition.class);
	private List<TransactionResponse> transactionResponses;

	PrivateMarketsDXTransformerTransactionStepDefinition() {

		Given("user {string} wants to transform a transaction", (String user) -> {
			LOGGER.info("User : {}", user);
		});

		When("user sends transaction proto with valid data to server", () -> {
			transactionResponses = getTransactionTransformerService()
					.transformLoadEntities(Collections.singletonList(TransactionTestData.getTransactionWithValidData()));
			printResponse(transactionResponses);
		});

		Then("transaction should be transformed", () -> {
			assertTrue(transactionResponses.get(0).getSuccess());
			assertEquals(0, transactionResponses.get(0).getMessage().length());
		});

		When("user sends transaction proto having invalid asset guid to server", () -> {
			transactionResponses = getTransactionTransformerService()
					.transformLoadEntities(Collections.singletonList(TransactionTestData.getTransactionWithInvalidAssetId()));
			printResponse(transactionResponses);
		});

		Then("we get a transaction validation failed for invalid asset guid", () -> {
			assertEquals(false, transactionResponses.get(0).getSuccess());
			assertEquals(false, transactionResponses.get(0).getMessage().length() == 0);
		});

		When("user sends transaction proto with invalid Portfolio Id to server", () -> {
			transactionResponses = getTransactionTransformerService()
					.transformLoadEntities(Collections.singletonList(TransactionTestData.getTransactionWithInvalidPortfolioId()));
			printResponse(transactionResponses);
		});

		Then("we get a validation failed for invalid Portfolio Id", () -> {
			assertEquals(false, transactionResponses.get(0).getSuccess());
			assertEquals(false, transactionResponses.get(0).getMessage().length() == 0);
		});

		When("user sends a batch of transaction proto having one invalid transaction data to server", () -> {
			transactionResponses = getTransactionTransformerService()
					.transformLoadEntities(Arrays.asList(TransactionTestData.getTransactionWithValidData(),TransactionTestData.getTransactionWithInvalidPortfolioId()));
			printResponse(transactionResponses);
		});

		Then("we get atleast one success response", () -> {
			assertTrue(transactionResponses.stream().filter(trresponse->trresponse.getSuccess() == true).count()>0);
		});
		
		When("user sends a batch of transaction proto having invalidPortfolio Id to server", () -> {
			transactionResponses = getTransactionTransformerService()
					.transformLoadEntities(Arrays.asList(TransactionTestData.getTransactionWithInvalidPortfolioId(),TransactionTestData.getTransactionWithInvalidPortfolioId()));
			printResponse(transactionResponses);
		});

		Then("we get a failure response for entire batch", () -> {
			assertEquals(0,transactionResponses.stream().filter(trresponse->trresponse.getSuccess() == true).count());
		});
	}

	private void printResponse(List<TransactionResponse> transactionResponses) {
		Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().create();
		System.out.println(gson.toJson(transactionResponses));
	}
	
	private TransactionTransformerService getTransactionTransformerService() {
		return TestHelper.getEntityTransformerBeam2Service(TransactionTransformerService.class,
				PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_TRANSACTION, CucumberConstantsTransformer.CURRENT_NETWORK_MODE);
	}

}
