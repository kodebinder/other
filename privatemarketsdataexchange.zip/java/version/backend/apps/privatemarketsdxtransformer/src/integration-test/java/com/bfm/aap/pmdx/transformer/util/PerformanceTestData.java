package com.bfm.aap.pmdx.transformer.util;

import java.util.LinkedList;
import java.util.List;

import com.bfm.aap.pmdx.model.Performance;
import com.bfm.aap.pmdx.model.PerformanceResponse;
import com.bfm.aap.pmdx.transformer.constants.CucumberConstantsTransformer;
import com.bfm.aap.pmdx.transformer.service.PerformanceTransformerService;
import com.google.protobuf.Timestamp;

public class PerformanceTestData {
	
	private static Performance.Builder getPerformanceProto() {
		return Performance.newBuilder()
				.setPerformanceId("6591CB65B6C64E5CBBE0868FB03C0D37")
				.setObjectId("RI28E66250084E50916MANUAG31FA011")
				.setNetIrr(0.0525)
				.setNetTvpi(1.0786003421932127)
				.setCusip("");
	}

	public static List<Performance> getPerformanceScenarioSuccess() {
		Performance performance = PerformanceTestData.getPerformanceProto()
				.setAsOfDate(Timestamp.newBuilder().setSeconds(55556666).build())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE))
				.build();
		List<Performance> performances = new LinkedList<>();
		performances.add(performance);
		return performances;
	}
	
	public static List<Performance> getPerformanceScenarioFailure() {
		Performance performance = PerformanceTestData.getPerformanceProto()
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE))
				.build();
		List<Performance> performances = new LinkedList<>();
		performances.add(performance);
		return performances;
	}
	
	public static List<Performance> getPerformanceScenarioEntityInfoFailure() {
		Performance performance = PerformanceTestData.getPerformanceProto()
				.setAsOfDate(Timestamp.newBuilder().setSeconds(55556666).build())
				.build();
		List<Performance> performances = new LinkedList<>();
		performances.add(performance);
		return performances;
	}
	
	public static List<PerformanceResponse> getPerformanceResponse(PerformanceTransformerService service, List<Performance> performances) {
		return service.transformLoadEntities(performances);
	}
	
	public static List<PerformanceResponse> getPerformancetransformEntitiesResponse(PerformanceTransformerService service, List<Performance> performances) {
		return service.transformEntities(performances);
	}
}
