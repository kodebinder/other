package com.bfm.aap.pmdx.transformer.service;

import static org.junit.Assert.assertNotNull;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.ContactResponse;
import com.bfm.aap.pmdx.plugin.crm.config.CRMConfig;
import com.bfm.aap.pmdx.plugin.crm.service.ContactBeam2Service;
import com.bfm.aap.pmdx.plugin.crm.service.ContactETLService;
import com.bfm.aap.pmdx.transformer.util.CRMContactAssertionUtility;
import com.bfm.aap.pmdx.transformer.util.CRMContactTestData;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import cucumber.api.java8.En;

@SuppressWarnings("deprecation")
public class PrivateMarketsDXTransformerCRMContactStepDefinition implements En {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(PrivateMarketsDXTransformerCRMContactStepDefinition.class);

	@Autowired
	private CRMConfig crmConfig;
	@Autowired
	private ContactETLService contactETLService;
	private ContactBeam2Service contactBeam2Service;
	
	private Collection<Contact> contact_transformLoadEntities_api = new LinkedList<>();
	private Collection<Contact> contact_transformEntities_api_success = new LinkedList<>();
	private Collection<Contact> contact_transformEntities_api_fail_missing_mandatory_fields = new LinkedList<>();
	private Collection<Contact> contact_transformEntities_api_fail_missing_contactId_field = new LinkedList<>();
	private Collection<Contact> contact_transformEntities_api_fail_missing_name_field = new LinkedList<>();
	private Collection<Contact> contact_transformEntities_api_fail_missing_entityInfo_field = new LinkedList<>();
	
	List<ContactResponse> transformLoadGuids_response_null_data;
	List<ContactResponse> transformLoadGuids_response_empty_data;
	List<ContactResponse> transformLoadEntities_response_success;
	List<ContactResponse> transformLoadEntities_response_null_data;
	List<ContactResponse> transformLoadEntities_response_empty_data;
	List<ContactResponse> transformEntities_response_success;
	List<ContactResponse> transformEntities_response_null_data;
	List<ContactResponse> transformEntities_response_empty_data;
	List<ContactResponse> transformEntities_response_missing_mandatory_fields;
	List<ContactResponse> transformEntities_response_missing_contactId_field;
	List<ContactResponse> transformEntities_response_missing_name_field;
	List<ContactResponse> transformEntities_response_missing_entityInfo_field;
	
	public PrivateMarketsDXTransformerCRMContactStepDefinition() {

		Given("user {string} wants to transform a contact", (String user) -> {
			LOGGER.info("User : {}", user);
		});
		
		When("user sends contact request to PrivateMarketsDXTransformer", () -> {
			contactBeam2Service = crmConfig.getContactBeam2Service(contactETLService);
			assertNotNull(contactBeam2Service);
		});

		When("user sends invalid contact proto with null data to server for transformLoadGuids api", () -> {
			transformLoadGuids_response_null_data = contactBeam2Service.transformLoadGuids(null);
			printResponse(transformLoadGuids_response_null_data);
		});

		Then("contact transformation unsuccessful due to null data for transformLoadGuids api", () -> {
			CRMContactAssertionUtility.assertFailureResponse_transformLoadGuids(transformLoadGuids_response_null_data);
		});
		
		When("user sends invalid contact proto with empty collection of guids data to server for transformLoadGuids api", () -> {
			transformLoadGuids_response_empty_data = contactBeam2Service.transformLoadGuids(Collections.emptyList());
			printResponse(transformLoadGuids_response_empty_data);
		});

		Then("contact transformation unsuccessful due to empty collection of guid for transformLoadGuids api", () -> {
			CRMContactAssertionUtility.assertFailureResponse_transformLoadGuids(transformLoadGuids_response_empty_data);
		});
		
		When("user sends valid contact proto data to server for transformLoadEntities api", () -> {
			contact_transformLoadEntities_api.add(CRMContactTestData.getContact());
			transformLoadEntities_response_success = contactBeam2Service.transformLoadEntities(contact_transformLoadEntities_api);
			printResponse(transformLoadEntities_response_success);
		});

		Then("contact transformation successful for transformLoadEntities api", () -> {
			CRMContactAssertionUtility.assertSuccessResponse_transformLoadEntities(transformLoadEntities_response_success);
		});
		
		When("user sends invalid contact proto with null data to server for transformLoadEntities api", () -> {
			transformLoadEntities_response_null_data = contactBeam2Service.transformLoadEntities(null);
			printResponse(transformLoadEntities_response_null_data);
		});

		Then("contact transformation unsuccessful due to null data for transformLoadEntities api", () -> {
			CRMContactAssertionUtility.assertFailureResponse_transformLoadEntities_empty(transformLoadEntities_response_null_data);
		});
		
		When("user sends invalid contact proto with empty collection of contact entities data to server for transformLoadEntities api", () -> {
			transformLoadEntities_response_empty_data = contactBeam2Service.transformLoadEntities(Collections.emptyList());
			printResponse(transformLoadEntities_response_empty_data);
		});

		Then("contact transformation unsuccessful due to empty collection of contact entities for transformLoadEntities api", () -> {
			CRMContactAssertionUtility.assertFailureResponse_transformLoadEntities_empty(transformLoadEntities_response_empty_data);
		});
		
		When("user sends valid contact proto with all mandatory field data to server for transformEntities api", () -> {
			contact_transformEntities_api_success.add(CRMContactTestData.getContact());
			transformEntities_response_success = contactBeam2Service.transformEntities(contact_transformEntities_api_success);
			printResponse(transformEntities_response_success);
		});

		Then("contact transformation successful for transformEntities api", () -> {
			CRMContactAssertionUtility.assertSuccessResponse_transformEntities(transformEntities_response_success);
		});
		
		When("user sends invalid contact proto with null data to server for transformEntities api", () -> {
			transformEntities_response_null_data = contactBeam2Service.transformEntities(null);
			printResponse(transformEntities_response_null_data);
		});

		Then("contact transformation unsuccessful due to null data for transformEntities api", () -> {
			CRMContactAssertionUtility.assertFailureResponse_transformEntities_empty(transformEntities_response_null_data);
		});
		
		When("user sends invalid contact proto with empty collection of contact entities data to server for transformEntities api", () -> {
			transformEntities_response_empty_data = contactBeam2Service.transformEntities(Collections.emptyList());
			printResponse(transformEntities_response_empty_data);
		});

		Then("contact transformation unsuccessful due to empty collection of contact entities for transformEntities api", () -> {
			CRMContactAssertionUtility.assertFailureResponse_transformEntities_empty(transformEntities_response_empty_data);
		});
		
		When("user sends invalid contact proto with missing mandatory fields data to server for transformEntities api", () -> {
			contact_transformEntities_api_fail_missing_mandatory_fields.add(CRMContactTestData.getContact_fail());
			transformEntities_response_missing_mandatory_fields = contactBeam2Service.transformEntities(contact_transformEntities_api_fail_missing_mandatory_fields);
			printResponse(transformEntities_response_missing_mandatory_fields);
		});

		Then("contact transformation unsuccessful due to missing mandatory fields for transformEntities api", () -> {
			CRMContactAssertionUtility.assertFailureResponse_transformEntities(transformEntities_response_missing_mandatory_fields);
		});
		
		When("user sends invalid contact proto with missing contactId field data to server for transformEntities api", () -> {
			contact_transformEntities_api_fail_missing_contactId_field.add(CRMContactTestData.getContact_fail_missing_contactId());
			transformEntities_response_missing_contactId_field = contactBeam2Service.transformEntities(contact_transformEntities_api_fail_missing_contactId_field);
			printResponse(transformEntities_response_missing_contactId_field);
		});

		Then("contact transformation unsuccessful due to missing contactId field for transformEntities api", () -> {
			CRMContactAssertionUtility.assertFailureResponse_transformEntities(transformEntities_response_missing_contactId_field);
		});
		
		When("user sends invalid contact proto with missing name field data to server for transformEntities api", () -> {
			contact_transformEntities_api_fail_missing_name_field.add(CRMContactTestData.getContact_fail_missing_name());
			transformEntities_response_missing_name_field = contactBeam2Service.transformEntities(contact_transformEntities_api_fail_missing_name_field);
			printResponse(transformEntities_response_missing_name_field);
		});

		Then("contact transformation unsuccessful due to missing name field for transformEntities api", () -> {
			CRMContactAssertionUtility.assertFailureResponse_transformEntities(transformEntities_response_missing_name_field);
		});
		
		When("user sends invalid contact proto with missing entityInfo field data to server for transformEntities api", () -> {
			contact_transformEntities_api_fail_missing_entityInfo_field.add(CRMContactTestData.getContact_fail_missing_entityInfo());
			transformEntities_response_missing_entityInfo_field = contactBeam2Service.transformEntities(contact_transformEntities_api_fail_missing_entityInfo_field);
			printResponse(transformEntities_response_missing_entityInfo_field);
		});

		Then("contact transformation unsuccessful due to missing entityInfo field for transformEntities api", () -> {
			CRMContactAssertionUtility.assertFailureResponse_transformEntities(transformEntities_response_missing_entityInfo_field);
		});

	}
	
		private void printResponse(List<ContactResponse> response) {
			Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().create();
			LOGGER.info("List of ContactResponse : {}", (gson.toJson(response)));
		}
		
}
