package com.bfm.aap.pmdx.transformer.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bfm.aap.pmdx.model.InvestorAccount;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import cucumber.api.java8.En;

/*
 * NOTE: 
 * Investor Account API is still under development by CRM team.
 * Adding placeholder code for same in advance.
 * Implementation will be added once API is fully functional and ready for testing. 
 * 
 * */
@SuppressWarnings("deprecation")
public class PrivateMarketsDXTransformerCRMInvestorAccountStepDefinition implements En {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(PrivateMarketsDXTransformerCRMInvestorAccountStepDefinition.class);

	public PrivateMarketsDXTransformerCRMInvestorAccountStepDefinition() {

		Given("user {string} wants to transform an investor account", (String user) -> {
			LOGGER.info("User : {}", user);
		});
		
		When("user sends investor account request to PrivateMarketsDXTransformer", () -> {
			
		});

		When("user sends invalid investor account proto with null data to server for transformLoadGuids api", () -> {
			
		});

		Then("investor account transformation unsuccessful due to null data for transformLoadGuids api", () -> {

		});
		
		When("user sends invalid investor account proto with empty collection of guids data to server for transformLoadGuids api", () -> {

		});

		Then("investor account transformation unsuccessful due to empty collection of guid for transformLoadGuids api", () -> {

		});
		
		When("user sends valid investor account proto data to server for transformLoadEntities api", () -> {
			
		});

		Then("investor account transformation successful for transformLoadEntities api", () -> {

		});
		
		When("user sends invalid investor account proto with null data to server for transformLoadEntities api", () -> {

		});

		Then("investor account transformation unsuccessful due to null data for transformLoadEntities api", () -> {
		
		});
		
		When("user sends invalid investor account proto with empty collection of investor account entities data to server for transformLoadEntities api", () -> {
		
		});

		Then("investor account transformation unsuccessful due to empty collection of investor account entities for transformLoadEntities api", () -> {
		
		});
		
		When("user sends valid investor account proto with all mandatory field data to server for transformEntities api", () -> {
		
		});

		Then("investor account transformation successful for transformEntities api", () -> {
		
		});
		
		When("user sends invalid investor account proto with null data to server for transformEntities api", () -> {
		
		});

		Then("investor account transformation unsuccessful due to null data for transformEntities api", () -> {
		
		});
		
		When("user sends invalid investor account proto with empty collection of investor account entities data to server for transformEntities api", () -> {
		
		});

		Then("investor account transformation unsuccessful due to empty collection of investor account entities for transformEntities api", () -> {
		
		});
		
		When("user sends invalid investor account proto with missing mandatory fields data to server for transformEntities api", () -> {
		
		});

		Then("investor account transformation unsuccessful due to missing mandatory fields for transformEntities api", () -> {
		
		});
		
		When("user sends invalid investor account proto with missing userId field data to server for transformEntities api", () -> {
		
		});

		Then("investor account transformation unsuccessful due to missing userId field for transformEntities api", () -> {
		
		});
		
		When("user sends invalid investor account proto with missing name field data to server for transformEntities api", () -> {
		
		});

		Then("investor account transformation unsuccessful due to missing name field for transformEntities api", () -> {
		
		});
		
		When("user sends invalid investor account proto with missing email field data to server for transformEntities api", () -> {
		
		});

		Then("investor account transformation unsuccessful due to missing email field for transformEntities api", () -> {

		});

	}
	
		private void printResponse(List<InvestorAccount> response) {
			Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().create();
			LOGGER.info("List of InvestorAccount : {}", (gson.toJson(response)));
		}
		
}
