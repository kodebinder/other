package com.bfm.aap.pmdx.transformer.util;

import java.util.LinkedList;
import java.util.List;

import com.bfm.aap.pmdx.model.BankAccount;
import com.bfm.aap.pmdx.model.BankAccountResponse;
import com.bfm.aap.pmdx.transformer.constants.CucumberConstantsTransformer;
import com.bfm.aap.pmdx.transformer.service.BankAccountTransformerService;

public class BankAccountTestData {
	private static final String BANK_TYPE = "DDA";
	private static final String BANK_ACCOUNT_ID = "BANKACCOUNTID48EEA00B10AAC99961";
	private static final String BANK_ACCOUNT_NAME = "Testing";
	private static final String BANK_ACCOUNT_NUMBER = "ACCOUNTNUMBER420";
	
	
	public static List<BankAccount> getBankAccountScenarioSuccess() {
		BankAccount bankAccount = BankAccountTestData.getBankAccountProto()
				.setEntityBankAccountId("SHAJAN11ED5FF3676760A08BE3E3B0000011")
				.setBankAladdinName(BANK_ACCOUNT_NAME)
				.setLinkedEntityDetail(TestHelper.getLinkedEntityDetail())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE))
				.build();
		List<BankAccount> bankAccounts = new LinkedList<>();
		bankAccounts.add(bankAccount);
		return bankAccounts;
	}
	
	public static List<BankAccount> getBankAccountDeLinkScenarioSuccess() {
		BankAccount bankAccount = BankAccountTestData.getBankAccountProto()
				.setEntityBankAccountId("SHAJAN11ED5FF3676760A08BE3E3B0000011")
				.setBankAladdinName(BANK_ACCOUNT_NAME)
				.setLinkedEntityDetail(TestHelper.getLinkedEntityDetail())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE))
				.setDeleted(true)
				.build();
		List<BankAccount> bankAccounts = new LinkedList<>();
		bankAccounts.add(bankAccount);
		return bankAccounts;
	}
	
	public static List<BankAccount> getBankAccountScenarioLinkedEntityDetailFailure() {
		BankAccount bankAccount = BankAccountTestData.getBankAccountProto()
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE))
				.build();
		List<BankAccount> bankAccounts = new LinkedList<>();
		bankAccounts.add(bankAccount);
		return bankAccounts;
	}
	
	public static List<BankAccount> getBankAccountScenarioEntityDetailFailure() {
		BankAccount bankAccount = BankAccountTestData.getBankAccountProto()
				.setLinkedEntityDetail(TestHelper.getLinkedEntityDetailWithMissingMandatoryField())
				.build();
		List<BankAccount> bankAccounts = new LinkedList<>();
		bankAccounts.add(bankAccount);
		return bankAccounts;
	}
	
	public static List<BankAccount> getBankAccountFundScenarioSuccess() {
		BankAccount bankAccount = BankAccountTestData.getBankAccountProto()
				.setEntityBankAccountId("SHAJAN11ED5FF3676760A08BE3E3B0000011")
				.setBankAladdinName(BANK_ACCOUNT_NAME)
				.setLinkedEntityDetail(TestHelper.getLinkedEntityDetail())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE))
				.build();
		List<BankAccount> bankAccounts = new LinkedList<>();
		bankAccounts.add(bankAccount);
		return bankAccounts;
	}
	
	public static List<BankAccount> getBankAccountScenarioLinkedEntityDetailAndEntityDetailFailure() {
		BankAccount bankAccount = BankAccountTestData.getBankAccountProto().build();
		List<BankAccount> bankAccounts = new LinkedList<>();
		bankAccounts.add(bankAccount);
		return bankAccounts;
	}
	
	public static BankAccount.Builder getBankAccountProto() {
		return BankAccount.newBuilder()
				.setBankAccountId(BANK_ACCOUNT_ID)
				.setBankAccount(BANK_ACCOUNT_NAME)
				.setCurrency(CucumberConstantsTransformer.CURRENCY)
				.setAccountNumber(BANK_ACCOUNT_NUMBER)
				.setDeleted(Boolean.FALSE)
				.setLinked(Boolean.TRUE)
				.setType(BANK_TYPE);
	}
	
	public static List<BankAccount> getBankAccountScenarioFailureForRetryLogic() {
		BankAccount bankAccount = BankAccountTestData.getBankAccountProto()
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE))
				.build();
		List<BankAccount> bankAccounts = new LinkedList<>();
		bankAccounts.add(bankAccount);
		return bankAccounts;
	}
	
	public static List<BankAccountResponse> getBankAccountResponse(BankAccountTransformerService service, List<BankAccount> bankAccounts) {
		return service.transformLoadEntities(bankAccounts);
	}
	
	public static List<BankAccountResponse> getBankAccountResponseTransformEntities(BankAccountTransformerService service, List<BankAccount> bankAccounts) {
		return service.transformEntities(bankAccounts);
	}
	
	public static List<BankAccount> getBankAccountInvesteeFundScenarioSuccess() {
		BankAccount bankAccount = BankAccountTestData.getBankAccountProto()
				.setEntityBankAccountId("SHAJAN11ED5FF3676760A08BE3E3B0000011")
				.setBankAladdinName(BANK_ACCOUNT_NAME)
				.setLinkedEntityDetail(TestHelper.getLinkedEntityDetail())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE))
				.build();
		List<BankAccount> bankAccounts = new LinkedList<>();
		bankAccounts.add(bankAccount);
		return bankAccounts;
	}

}
