package com.bfm.aap.pmdx.transformer.service;

import com.bfm.aap.pmdx.broker.service.PrivateMarketsCpmService;
import com.bfm.aap.pmdx.transformer.util.TestHelper;
import com.bfm.aap.privatemarkets.broker.service.PrivateMarketsBrokerService;
import com.bfm.aap.privatemarkets.dao.BrokerDao;
import com.bfm.aap.privatemarkets.dao.ExternBrokerIdDaoImpl;
import com.bfm.aap.privatemarkets.dao.PortfoliosDao;
import com.bfm.aap.privatemarkets.dao.TickerGenerator;
import com.bfm.aap.privatemarkets.dao.cache.ClientNameCache;
import cucumber.api.java8.En;
import io.cucumber.datatable.DataTable;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;


@SuppressWarnings("deprecation")
public class PrivateMarketsDXTransformerInvestorStepDefinition implements En {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(PrivateMarketsDXTransformerInvestorStepDefinition.class);

	@Autowired
	private PortfoliosDao portfoliosDao;
	private PrivateMarketsCpmService privateMarketsCpmService;
	@Autowired
	private TickerGenerator tickerGenerator;
	@Autowired
	private ClientNameCache clientNameCache;
	@Autowired
	private BrokerDao brokerDao;
	private ExternBrokerIdDaoImpl externBrokerIdDao;
	private PrivateMarketsBrokerService privateMarketsBrokerService;

	@PersistenceContext
	protected EntityManager entityManager;

	private Map<String, String> mandatoryArgsForValidRequestData;
	private Map<String, String> mandatoryArgsForInvalidRequestData;
	private Integer brokerCode = Integer.MIN_VALUE;

	private Boolean isCreateBrokerForInvstStrucSuccessful = Boolean.FALSE;
	private Boolean isBrokerExistingInAladdin = Boolean.FALSE;
	private Boolean hasExceptionOccurredWhileCreatingBrokerStructure = Boolean.FALSE;
	private Boolean hasExceptionOccurredWhileRetrievingBrokerCodeFromPortfolioCode = Boolean.FALSE;

	public PrivateMarketsDXTransformerInvestorStepDefinition() {
		Given("user {string} wants to create a broker on an Investor object captured from eFront Invest",
				(String user) -> {
					LOGGER.info("User : {}",user);
				});

		When("user sends investor request to PrivateMarketsDXTransformer", () -> {
			privateMarketsCpmService = TestHelper.getPrivateMarketsCpmService();
			externBrokerIdDao = new ExternBrokerIdDaoImpl(entityManager);
		});

		Given("the following attributes are available for updating the investor successfully:",
				(DataTable dataTable) -> {
					mandatoryArgsForValidRequestData = dataTable.asMap(String.class, String.class);
				});

		Given("the following attributes are available for updating the investor unsuccessfully:",
				(DataTable dataTable) -> {
					mandatoryArgsForInvalidRequestData = dataTable.asMap(String.class, String.class);
				});

		Given("request has all the mandatory fields for an investor and all fields have valid data", () -> {
			assertArguments(mandatoryArgsForValidRequestData, true);
		});

		When("user sends request for create Broker for Investor Structure with valid data", () -> {
			createBrokerForInvstStruc(mandatoryArgsForValidRequestData);
		});

		Then("successful creation of a broker on an Investor object captured from eFront Invest", () -> {
			assertTrue(isCreateBrokerForInvstStrucSuccessful);
		});

		And("user sends request to validate if a broker exists in aladdin with valid data", () -> {
			isBrokerExistingInAladdin = privateMarketsBrokerService
					.checkExistingBroker(mandatoryArgsForValidRequestData.get("EXISTING_BROKER_TICKER"));
		});

		And("successful validation for broker existence in aladdin", () -> {
			assertTrue(isBrokerExistingInAladdin);
		});

		When("user sends request to retrieve broker_code using portfolio_code with valid data", () -> {
			getBrokerCodeFromPortfolioCode(mandatoryArgsForValidRequestData);
		});

		Then("successful retrieval of broker_code using portfolio_code", () -> {
			assertFalse(hasExceptionOccurredWhileRetrievingBrokerCodeFromPortfolioCode);
		});

		When("user sends request to create the broker,desk and broker aka record with valid data", () -> {
			createBrokerStructure(mandatoryArgsForValidRequestData);
		});

		Then("successful creation of the broker,desk and broker aka record", () -> {
			assertFalse(hasExceptionOccurredWhileCreatingBrokerStructure);
		});

		Given("request has all the mandatory fields for an investor but some fields have invalid data", () -> {
			assertArguments(mandatoryArgsForInvalidRequestData, false);
		});

		When("user sends request for create Broker for Investor Structure with invalid data", () -> {
			createBrokerForInvstStruc(mandatoryArgsForInvalidRequestData);
		});

		Then("unsuccessful creation of a broker on an Investor object captured from eFront Invest", () -> {
			assertFalse(isCreateBrokerForInvstStrucSuccessful);
		});

		And("user sends request to validate if a broker exists in aladdin with invalid data", () -> {
			isBrokerExistingInAladdin = privateMarketsBrokerService
					.checkExistingBroker(mandatoryArgsForInvalidRequestData.get("NON_EXISTING_BROKER_TICKER"));
		});

		And("unsuccessful validation for broker existence in aladdin", () -> {
			assertFalse(isBrokerExistingInAladdin);
		});

		When("user sends request to retrieve broker_code using portfolio_code with invalid data", () -> {
			getBrokerCodeFromPortfolioCode(mandatoryArgsForInvalidRequestData);
		});

		Then("unsuccessful retrieval of broker_code using portfolio_code", () -> {
			assertTrue(hasExceptionOccurredWhileRetrievingBrokerCodeFromPortfolioCode);
		});

		When("user sends request to create the broker,desk and broker aka record with invalid data", () -> {
			createBrokerStructure(mandatoryArgsForInvalidRequestData);
		});

		Then("unsuccessful creation of the broker,desk and broker aka record", () -> {
			assertTrue(hasExceptionOccurredWhileCreatingBrokerStructure);
		});

	}

	private void assertArguments(Map<String, String> mandatoryArgsCache, Boolean validMandatoryArgsCacheFlag) {
		assertNotNull(mandatoryArgsCache.get("ENTITY_IQID"));
		assertNotNull(mandatoryArgsCache.get("BROKER_TICKER"));
		assertNotNull(mandatoryArgsCache.get("INVESTOR_COUNTER"));
		assertNotNull(mandatoryArgsCache.get("PORTFOLIO_CODE"));
		assertNotNull(mandatoryArgsCache.get("PORTFOLIO_TICKER"));
		assertNotNull(mandatoryArgsCache.get("PORTFOLIO_GUID"));
		assertNotNull(mandatoryArgsCache.get("CLIENT_ID"));
		if (validMandatoryArgsCacheFlag)
			assertNotNull(mandatoryArgsCache.get("EXISTING_BROKER_TICKER"));
		else
			assertNotNull(mandatoryArgsCache.get("NON_EXISTING_BROKER_TICKER"));
		assertNotNull(portfoliosDao);
		assertNotNull(privateMarketsCpmService);
		assertNotNull(tickerGenerator);
		assertNotNull(clientNameCache);
		assertNotNull(brokerDao);
		assertNotNull(externBrokerIdDao);
		privateMarketsBrokerService = new PrivateMarketsBrokerService(portfoliosDao, privateMarketsCpmService,
				tickerGenerator, clientNameCache, brokerDao, externBrokerIdDao);
		assertNotNull(privateMarketsBrokerService);
	}

	@Transactional
	public void createBrokerForInvstStruc(Map<String, String> mandatoryArgsCache) {
		LOGGER.info("EntityIQID : {}, BrokerTicker : {}, Counter : {}", mandatoryArgsCache.get("ENTITY_IQID"),
				mandatoryArgsCache.get("BROKER_TICKER"), mandatoryArgsCache.get("INVESTOR_COUNTER"));
		try {
			privateMarketsBrokerService.upsertBrokerForInvstStruc(mandatoryArgsCache.get("ENTITY_IQID"),
					mandatoryArgsCache.get("BROKER_TICKER"), mandatoryArgsCache.get("INVESTOR_COUNTER"), StringUtils.EMPTY);
			isCreateBrokerForInvstStrucSuccessful = Boolean.TRUE;
			LOGGER.info("Creation of Broker for Investor Structure is Successful? : {}",
					isCreateBrokerForInvstStrucSuccessful);
		} catch (Exception e) {
			isCreateBrokerForInvstStrucSuccessful = Boolean.FALSE;
			LOGGER.info("Creation of Broker for Investor Structure failed with Error Message : {} ", e.getMessage());
		}
	}

	private void getBrokerCodeFromPortfolioCode(Map<String, String> mandatoryArgsCache) {
		try {
			brokerCode = privateMarketsBrokerService
					.getBrokerCodeFromPortCode(Integer.parseInt(mandatoryArgsCache.get("PORTFOLIO_CODE")));
			hasExceptionOccurredWhileRetrievingBrokerCodeFromPortfolioCode = Boolean.FALSE;
			LOGGER.info("Retrieving BrokerCode : {} from PortfolioCode : {} ", brokerCode,
					mandatoryArgsCache.get("PORTFOLIO_CODE"));
		} catch (Exception e) {
			hasExceptionOccurredWhileRetrievingBrokerCodeFromPortfolioCode = Boolean.TRUE;
			LOGGER.info("Retrieving BrokerCode : {} from PortfolioCode : {}  failed with Error Message : {} ",
					brokerCode, mandatoryArgsCache.get("PORTFOLIO_CODE"), e.getMessage());
		}

	}

	private void createBrokerStructure(Map<String, String> mandatoryArgsCache) {
		try {
			privateMarketsBrokerService.upsertBrokerStructure(mandatoryArgsCache.get("PORTFOLIO_TICKER"),
					mandatoryArgsCache.get("PORTFOLIO_GUID"), Integer.parseInt(mandatoryArgsCache.get("CLIENT_ID")), null);
			hasExceptionOccurredWhileCreatingBrokerStructure = Boolean.FALSE;
			LOGGER.error("Creation of Broker Structure with PORTFOLIOTICKER : {}, PORTFOLIOGUID : {}, CLIENTID : {}",
					mandatoryArgsCache.get("PORTFOLIO_TICKER"), mandatoryArgsCache.get("PORTFOLIO_GUID"),
					mandatoryArgsCache.get("CLIENT_ID"));
		} catch (RuntimeException e) {
			hasExceptionOccurredWhileCreatingBrokerStructure = Boolean.TRUE;
			LOGGER.error(
					"Creation of Broker Structure with PORTFOLIOTICKER : {}, PORTFOLIOGUID : {}, CLIENTID : {} failed with Error Message : {}",
					mandatoryArgsCache.get("PORTFOLIO_TICKER"), mandatoryArgsCache.get("PORTFOLIO_GUID"),
					mandatoryArgsCache.get("CLIENT_ID"), e.getMessage());
		}

	}

}
