package com.bfm.aap.pmdx.transformer.util;

import static com.google.protobuf.util.Timestamps.fromMillis;
import static java.lang.System.currentTimeMillis;

import org.apache.commons.lang3.RandomStringUtils;

import com.bfm.aap.pmdx.model.User;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.model.util.ReferenceLevel;
import com.bfm.aap.pmdx.model.util.Source;

public class CRMUserTestData {

	public static User getUser() {
		return User.newBuilder()
				.setUserId(RandomStringUtils.randomAlphanumeric(32))
				.setIdentifier("AIDEMO")
				.setFirstName("Aladdin")
				.setMiddleName("Invest")
				.setLastName("Demo")
				.setEmail("aladdin_invest_demo@blackrock.com")
				.setEntityInfo(getEntityInfo()).build();
	}
	
	public static User getUser_fail() {
		return User.newBuilder()
				.build();
	}
	
	public static User getUser_fail_missing_userId() {
		return User.newBuilder()
				.setIdentifier("AIDEMO")
				.setFirstName("Aladdin")
				.setMiddleName("Invest")
				.setLastName("Demo")
				.setEmail("aladdin_invest_demo@blackrock.com")
				.setEntityInfo(getEntityInfo()).build();
	}
	
	public static User getUser_fail_missing_name() {
		return User.newBuilder()
				.setUserId(RandomStringUtils.randomAlphanumeric(32))
				.setIdentifier("AIDEMO")
				.setEmail("aladdin_invest_demo@blackrock.com")
				.setEntityInfo(getEntityInfo()).build();
	}
	
	public static User getUser_fail_missing_email() {
		return User.newBuilder()
				.setUserId(RandomStringUtils.randomAlphanumeric(32))
				.setIdentifier("AIDEMO")
				.setFirstName("Aladdin")
				.setMiddleName("Invest")
				.setLastName("Demo")
				.setEntityInfo(getEntityInfo()).build();
	}
	
	public static EntityInfo getEntityInfo(){
		return EntityInfo.newBuilder()
				.setClientName("DEV")
				.setPrimaryData(true)
				.setNetworkMode(NetworkMode.valueOf("BLUE"))
				.setOriginTimestamp(fromMillis(currentTimeMillis()))
				.setSource(Source.INVEST)
				.setReferenceLevel(ReferenceLevel.PORTFOLIO_LEVEL)
				.setModelVersion("5.1.2")
				.build();
	}
	
}
