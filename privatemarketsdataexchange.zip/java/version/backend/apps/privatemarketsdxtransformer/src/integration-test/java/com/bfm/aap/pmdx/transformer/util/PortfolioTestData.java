package com.bfm.aap.pmdx.transformer.util;

import java.util.ArrayList;
import java.util.List;

import com.bfm.aap.pmdx.model.Portfolio;
import com.bfm.aap.pmdx.model.PortfolioResponse;
import com.bfm.aap.pmdx.transformer.constants.CucumberConstantsTransformer;
import com.bfm.aap.pmdx.transformer.service.PortfolioTransformerService;
import com.google.protobuf.Timestamp;

public class PortfolioTestData {

	private static Portfolio.Builder getPortfolioProto() {
		return Portfolio.newBuilder().setPortfolioId("ED5FF3D09A7D40A08BE3E3B5DB921ADE").setTicker("E2E_AP12")
				.setPortfolioName("End 2 End Test Aladdin Portfolio 1").setPortfolioType("TEST_TYPE").setCurrency("USD")
				.setCreationDate(Timestamp.newBuilder().setSeconds(1565383786).setNanos(0).build())
				.setInceptionDate(Timestamp.newBuilder().setSeconds(1565898996).setNanos(0).build())
				.setModificationDate(Timestamp.newBuilder().setSeconds(1565383786).setNanos(0).build())
				.setDeleted(false).setClientId("1000");
	}

	public static List<Portfolio> getPortfolioScenarioSuccess() {
		Portfolio.Builder builder = getPortfolioProto()
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE))
				.setPortfolioCode(12345);
		List<Portfolio> portfolios = new ArrayList<>();
		portfolios.add(builder.build());
		return portfolios;
	}

	public static List<Portfolio> getPortfolioScenarioEntityInfoFailure() {
		Portfolio.Builder builder = getPortfolioProto().setPortfolioCode(12345);
		List<Portfolio> portfolios = new ArrayList<>();
		portfolios.add(builder.build());
		return portfolios;
	}

	public static List<Portfolio> getPortfolioScenarioPortfolioCodeFailure() {
		Portfolio.Builder builder = getPortfolioProto()
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE));
		List<Portfolio> portfolios = new ArrayList<>();
		portfolios.add(builder.build());
		return portfolios;
	}

	public static List<Portfolio> getPortfolioScenarioPortfolioCodeAndEntityInfoFailure() {
		Portfolio.Builder builder = getPortfolioProto();
		List<Portfolio> portfolios = new ArrayList<>();
		portfolios.add(builder.build());
		return portfolios;
	}

	public static List<PortfolioResponse> getPortfolioResponse(PortfolioTransformerService service,
			List<Portfolio> portfolios) {
		return service.transformLoadEntities(portfolios);
	}

}
