package com.bfm.aap.pmdx.transformer.util;

import java.util.LinkedList;
import java.util.List;

import com.bfm.aap.pmdx.model.Asset;
import com.bfm.aap.pmdx.model.AssetResponse;
import com.bfm.aap.pmdx.model.FundDetails;
import com.bfm.aap.pmdx.transformer.constants.CucumberConstantsTransformer;
import com.bfm.aap.pmdx.transformer.service.AssetTransformerService;

public class AssetTestData {

	public static Asset.Builder getAssetProto() {
		 return Asset.newBuilder()
					 .setFundDetails(FundDetails.newBuilder()
										       .setFundSize(CucumberConstantsTransformer.FUND_SIZE)
										       .setVintageYear(CucumberConstantsTransformer.VINTAGE_YEAR)
										       .build())
					 .setSecGroup(CucumberConstantsTransformer.SEC_GROUP_LOAN)
					 .setSecType(CucumberConstantsTransformer.SEC_TYPE_TERM)
					 .setCurrency(CucumberConstantsTransformer.CURRENCY)
					 .setManagementCompany(CucumberConstantsTransformer.MANAGEMENT_COMPANY)
					 .setInvestmentStructure(CucumberConstantsTransformer.INVESTMENT_STRUCTURE)
					 .setCapitalStructure(CucumberConstantsTransformer.CAPITAL_STRUCTURE_DEBT)
					 .setFlag144A(CucumberConstantsTransformer.FLAG_144A)
					 .setReviewedBy(CucumberConstantsTransformer.REVIEWED_BY)
					 .setMarket(CucumberConstantsTransformer.MARKET)
					 .setSecDesc2(CucumberConstantsTransformer.SEC_DESC_2)
					 .setMTN(CucumberConstantsTransformer.MTN)
					 .setNotionalFlag(CucumberConstantsTransformer.NOTIONAL_FLAG)
					 .setFlagRound(CucumberConstantsTransformer.FLAG_ROUND)
					 .setSettleLocation(CucumberConstantsTransformer.SETTLE_LOCATION)
					 .setPmtLocation(CucumberConstantsTransformer.PMT_LOCATION)
					 .setBenchmark(CucumberConstantsTransformer.BENCHMARK)
					 .setPortfolioTicker(CucumberConstantsTransformer.PORTFOLIO_TICKER)
					 .setNote(CucumberConstantsTransformer.NOTE)
					 .setFundStatus(CucumberConstantsTransformer.FUND_STATUS)
					 .setSecLongName(CucumberConstantsTransformer.SEC_LONG_NAME)
					 .setFundDetails(TestHelper.getFundDetails());
	}
	
	public static List<Asset> getAssetsScenarioSuccess() {
		Asset asset = AssetTestData.getAssetProto()
								.setAssetId(CucumberConstantsTransformer.ASSET_ID)
								.setAssetName(CucumberConstantsTransformer.ASSET_NAME)
								.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				  				.setDomicile(CucumberConstantsTransformer.DOMICILE)
				  				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE).setClientName(CucumberConstantsTransformer.VALID_CLIENT_NAME).build())
				  				.build();
		List<Asset> assets = new LinkedList<>();
		assets.add(asset);
		return assets;
	}
	
	public static List<Asset> getAssetsScenarioMissingAssetIdField() {
		Asset asset = AssetTestData.getAssetProto()
								.setAssetName(CucumberConstantsTransformer.ASSET_NAME)
								.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
								.setDomicile(CucumberConstantsTransformer.DOMICILE)
								.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE).setClientName(CucumberConstantsTransformer.VALID_CLIENT_NAME).build())
								.build();
		List<Asset> assets = new LinkedList<>();
		assets.add(asset);
		return assets;
	}
	
	public static List<Asset> getAssetsScenarioMissingAssetNameField() {
		Asset asset = AssetTestData.getAssetProto()
								.setAssetId(CucumberConstantsTransformer.ASSET_ID)
								.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
								.setDomicile(CucumberConstantsTransformer.DOMICILE)
								.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE).setClientName(CucumberConstantsTransformer.VALID_CLIENT_NAME).build())
								.build();
		List<Asset> assets = new LinkedList<>();
		assets.add(asset);
		return assets;
	}
	
	public static List<Asset> getAssetsScenarioMissingDomicileField() {
		Asset asset = AssetTestData.getAssetProto()
								.setAssetId(CucumberConstantsTransformer.ASSET_ID)
								.setAssetName(CucumberConstantsTransformer.ASSET_NAME)
								.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
								.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE).setClientName(CucumberConstantsTransformer.VALID_CLIENT_NAME).build())
								.build();
		List<Asset> assets = new LinkedList<>();
		assets.add(asset);
		return assets;
	}
	
	public static List<Asset> getAssetsScenarioInvalidClientName() {
		Asset asset = AssetTestData.getAssetProto()
								.setAssetId(CucumberConstantsTransformer.ASSET_ID)
								.setAssetName(CucumberConstantsTransformer.ASSET_NAME)
								.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
								.setDomicile(CucumberConstantsTransformer.DOMICILE)
								.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE).setClientName(CucumberConstantsTransformer.INVALID_CLIENT_NAME).build())
								.build();
		List<Asset> assets = new LinkedList<>();
		assets.add(asset);
		return assets;
	}
	
	public static List<Asset> getAssetsScenarioInvalidAssetType() {
		Asset asset = AssetTestData.getAssetProto()
				  				.setAssetId(CucumberConstantsTransformer.ASSET_ID)
				  				.setAssetName(CucumberConstantsTransformer.ASSET_NAME)
								.setAssetType(CucumberConstantsTransformer.INVALID_ASSET_TYPE)
				  				.setDomicile(CucumberConstantsTransformer.DOMICILE)
				  				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE).setClientName(CucumberConstantsTransformer.VALID_CLIENT_NAME).build())
				  				.build();
		List<Asset> assets = new LinkedList<>();
		assets.add(asset);
		return assets;
	}
	
	public static List<AssetResponse> getAssetResponse(AssetTransformerService service, List<Asset> assets) {
		List<AssetResponse> response = service.transformLoadEntities(assets);
		return response;
	}
	
}
