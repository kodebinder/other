package com.bfm.aap.pmdx.transformer.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bfm.aap.pmdx.model.FundamentalsResponse;
import com.bfm.aap.pmdx.redblue.PmdxServiceType;
import com.bfm.aap.pmdx.transformer.constants.CucumberConstantsTransformer;
import com.bfm.aap.pmdx.transformer.util.FundamentalsTestData;
import com.bfm.aap.pmdx.transformer.util.TestHelper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import io.cucumber.java8.En;

public class PrivateMarketsDXTransformerFundamentalsStepDefinition implements En {

	private static final Logger LOGGER = LoggerFactory.getLogger(PrivateMarketsDXTransformerFundamentalsStepDefinition.class);
	private List<FundamentalsResponse> fundamentalsResponse;
	
	public PrivateMarketsDXTransformerFundamentalsStepDefinition() {

		Given("user {string} wants to transform a fundamentals", (String user) -> {
			LOGGER.info("User : {}",user);
		});

		When("user sends valid fundamentals proto to server", () -> {
			fundamentalsResponse = FundamentalsTestData.getFundamentalsResponse(getFundamentalsTransformerService(),FundamentalsTestData.getFundamentalsScenarioSuccess());
			printResponse(fundamentalsResponse);
		});

		Then("fundamentals should be transformed", () -> {
			assertSuccessResponse();
		});
		
		When("user sends valid fundamentals proto to server without BalanceSheet details", () -> {
			fundamentalsResponse = FundamentalsTestData.getFundamentalsResponse(getFundamentalsTransformerService(),FundamentalsTestData.getFundamentalsMissingBalanceSheetScenario());
			printResponse(fundamentalsResponse);
		});

		When("user sends valid fundamentals proto to server without IncomeStatement details", () -> {
			fundamentalsResponse = FundamentalsTestData.getFundamentalsResponse(getFundamentalsTransformerService(),FundamentalsTestData.getFundamentalsMissingIncomeStatementScenario());
			printResponse(fundamentalsResponse);
		});

		When("user sends valid fundamentals proto to server without EntityInfo details", () -> {
			fundamentalsResponse = FundamentalsTestData.getFundamentalsResponse(getFundamentalsTransformerService(),FundamentalsTestData.getFundamentalsMissingEntityInfoScenario());
			printResponse(fundamentalsResponse);
		});

		Then("fundamentals should not be transformed", () -> {
			assertFailureResponse();
		});
		
		When("user sends valid fundamentals proto to server without Source details", () -> {
			fundamentalsResponse = FundamentalsTestData.getFundamentalsResponse(getFundamentalsTransformerService(),FundamentalsTestData.getFundamentalsMissingSourceScenario());
			printResponse(fundamentalsResponse);
		});

		When("user sends valid fundamentals proto to server without BalanceSheet And IncomeStatement details", () -> {
			fundamentalsResponse = FundamentalsTestData.getFundamentalsResponse(getFundamentalsTransformerService(),FundamentalsTestData.getFundamentalsMissingBalanceSheetAndIncomeStatementScenario());
			printResponse(fundamentalsResponse);
		});

		When("user sends valid fundamentals proto to server without BalanceSheet, IncomeStatement And EntityInfo details", () -> {
			fundamentalsResponse = FundamentalsTestData.getFundamentalsResponse(getFundamentalsTransformerService(),FundamentalsTestData.getFundamentalsMissingBalanceSheetIncomeStatementAndEntityInfoScenario());
			printResponse(fundamentalsResponse);
		});

		When("user sends valid fundamentals proto to server without Mandatory Fields details", () -> {
			fundamentalsResponse = FundamentalsTestData.getFundamentalsResponse(getFundamentalsTransformerService(),FundamentalsTestData.getFundamentalsMissingAllMandatoryFieldsScenario());
			printResponse(fundamentalsResponse);
		});

	}

	private void printResponse(List<FundamentalsResponse> fundamentalsResponse) {
		Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().create();
		LOGGER.info("List of FundamentalsResponse : {}",(gson.toJson(fundamentalsResponse)));
	}
	
	private void assertSuccessResponse() {
		boolean message = fundamentalsResponse.get(0).getSuccess();
		assertEquals(Boolean.TRUE,message);
	}
	
	private void assertFailureResponse() {
		boolean success = fundamentalsResponse.get(0).getSuccess();
		assertEquals(false, success);
	}
	
	private FundamentalsTransformerService getFundamentalsTransformerService() {
		return TestHelper.getEntityTransformerBeam2Service(FundamentalsTransformerService.class, 
				PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_FUNDAMENTALS, 
				CucumberConstantsTransformer.CURRENT_NETWORK_MODE);
	}

}
