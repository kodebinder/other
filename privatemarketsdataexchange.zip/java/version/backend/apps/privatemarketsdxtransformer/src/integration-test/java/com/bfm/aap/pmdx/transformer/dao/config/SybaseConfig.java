package com.bfm.aap.pmdx.transformer.dao.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bfm.util.DatabaseUtil;
import com.bfm.util.PropertyConfig;

public class SybaseConfig {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SybaseConfig.class);
	private static SybaseConfig instance;
	private String username;
    private String password;
    private String jdbcURL;
    
    // to help with unit testing - should not be used otherwise
    public SybaseConfig() {}
    
    private SybaseConfig(final boolean unitTestMode) throws Exception {
        if (!unitTestMode) {
            Properties properties = new Properties(PropertyConfig.PROPERTIES);
            this.username = properties.getProperty("brs.database.user");
            this.password = DatabaseUtil.getDatabasePassword();
            this.jdbcURL = "jdbc:sybase:Tds:" + properties.getProperty("brs.dsread");
            Class.forName("com.sybase.jdbc4.jdbc.SybDriver");
            LOGGER.info("SybaseConfig DB Connection Established");
        }
    }
    
    public static SybaseConfig getInstance() throws Exception {
        if (instance == null) {
            instance = new SybaseConfig(false);
        }
        return instance;
    }
    
    // method to help with unit testing
    public Connection getConnection() throws SQLException {
    	return DriverManager.getConnection(jdbcURL, username, password);
    }

}
