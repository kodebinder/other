package com.bfm.aap.pmdx.transformer.util;

import org.apache.commons.lang3.RandomStringUtils;

import com.bfm.aap.pmdx.model.AccessRights;
import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.Region;
import com.bfm.aap.pmdx.model.VcData;

public class CRMCompanyTestData {

	public static Company getCompany1() {
		return Company.newBuilder()	
					.setActive(true)
					.setDomicile("US")
					.setCompanyId(RandomStringUtils.randomAlphanumeric(20))
					.build();
	}
	
	public static Company getCompany2() {
		return Company.newBuilder()	
				.setCompanyId(RandomStringUtils.randomAlphanumeric(20))
				.setActive(Boolean.TRUE)
				.setDeleted(Boolean.FALSE)
				.setName("BLACKROCK")
				.setAccessRights(AccessRights.newBuilder().setWrite(Boolean.TRUE).build())
				.setModifiedBy("Test")
				.setAladdinId("Test")
				.setCompanyType("Test")
				.setVcData(VcData.newBuilder().setDeleted(Boolean.TRUE).setId("Test").build())
				.build();
	}
	
	public static Company getCompany_success() {
		return Company.newBuilder()
				.setCompanyId(RandomStringUtils.randomAlphanumeric(20))
				.setActive(Boolean.TRUE)
				.setDeleted(Boolean.FALSE)
				.setName("BLACKROCK")
				.setKnownAs("BLACKROCK")
				.setShortCode("BLK")
				.setDescription("Asset Management")
				.setStatus("OPEN")
				.setLegalForm("Test")
				.setLegalFormInsight("Test")
				.setDomicile("US")
				.setDomicileInsight("US")
				.setRegion(Region.newBuilder()
						.setWriteAccess(Boolean.TRUE)
						.setAlias("NAM")
						.setId("123")
						.setName("NAM")
						.setReadAccesss(Boolean.TRUE).build())
				.setNumber("123")
				.setTicker("CMPNY")
				.setMainContactId("Test")
				.setSubsidiaryOfId("Test")
				.setParentCompanyId("BLK")
				.setWeb("Test")
				.setCurrency("USD")
				.setGeographicMandate("Test")
				.setSectorFocus("NAM")
				.setActivityMemo("Test")
				.setRating("Excellent")
				.setAccessRights(AccessRights.newBuilder().setWrite(Boolean.TRUE).build())
				.setModifiedBy("Test")
				.setAladdinId("Test")
				.setCompanyType("Test")
				.setVcData(VcData.newBuilder().setDeleted(Boolean.TRUE).setId("Test").build())
				.build();
	}
	
	public static Company getCompany_fail() {
		return Company.newBuilder()
				.build();
	}
	
	public static Company getCompany_fail_missing_companyId() {
		return Company.newBuilder()
				.setName("Test")
				.setDomicile("US")
				.setActive(Boolean.TRUE)
				.build();
	}
	
	public static Company getCompany_fail_missing_companyName() {
		return Company.newBuilder()
				.setCompanyId(RandomStringUtils.randomAlphanumeric(20))
				.setDomicile("US")
				.setActive(Boolean.TRUE)
				.build();
	}
	
	public static Company getCompany_fail_missing_active() {
		return Company.newBuilder()
				.setCompanyId(RandomStringUtils.randomAlphanumeric(20))
				.setDomicile("US")
				.setName("Test")
				.build();
	}
}
