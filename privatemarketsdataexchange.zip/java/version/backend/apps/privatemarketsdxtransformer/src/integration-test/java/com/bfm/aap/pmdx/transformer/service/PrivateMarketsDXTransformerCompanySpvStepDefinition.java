package com.bfm.aap.pmdx.transformer.service;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.bfm.aap.pmdx.model.Instrument;
import com.bfm.aap.pmdx.model.InstrumentResponse;
import com.bfm.aap.pmdx.redblue.PmdxServiceType;
import com.bfm.aap.pmdx.transformer.constants.CucumberConstantsTransformer;
import com.bfm.aap.pmdx.transformer.util.CompanySpvTestData;
import com.bfm.aap.pmdx.transformer.util.InstrumentTestData;
import com.bfm.aap.pmdx.transformer.util.TestHelper;
import com.bfm.aap.privatemarkets.dao.CreditRatingHistDao;
import com.bfm.aap.privatemarkets.dao.CusipAliasesDao;
import com.bfm.aap.privatemarkets.dao.NewIssueInfoDao;
import com.bfm.aap.privatemarkets.dao.SecurityMasterDao;
import com.bfm.aap.privatemarkets.dao.model.CreditRatingHist;
import com.bfm.aap.privatemarkets.dao.model.NewIssueInfo;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import io.cucumber.java8.En;

public class PrivateMarketsDXTransformerCompanySpvStepDefinition implements En{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(PrivateMarketsDXTransformerCompanySpvStepDefinition.class);
	
	private static final String DEFAULT_TO_N = "N";
	private List<InstrumentResponse> instrumentResponses;
	
	@Autowired
	@Qualifier("securityMasterDaoImpl")
	private SecurityMasterDao securityMasterDao;
	
	@Autowired
	@Qualifier("newIssueInfoDaoImpl")
	private NewIssueInfoDao newIssueInfoDao;

	@Autowired
	@Qualifier("cusipAliasesDaoImpl")
	private CusipAliasesDao cusipAliasesDao;

	@Autowired
	@Qualifier("creditRatingHistDaoImpl")
	private CreditRatingHistDao creditRatingHistDao;

	public PrivateMarketsDXTransformerCompanySpvStepDefinition() {


		Given("user {string} wants to transform company spv", (String user) -> {
			LOGGER.info("User : {}", user);
		});
		
		When("user sends valid company spv instrument proto to server", () -> {
			instrumentResponses = CompanySpvTestData.getCompantSpvInstrumentResponse(getInstrumentTransformerService(),
					CompanySpvTestData.getCompanySpvInstrumentsScenarioSuccess());
			printResponse(instrumentResponses);
		});

		Then("company spv transformation successful", () -> {
			assertSuccessResponse();
		});
		
		When("user sends invalid company spv instrument proto with missing mandatory args data to server", () -> {
			instrumentResponses = CompanySpvTestData.getCompantSpvInstrumentResponse(getInstrumentTransformerService(),
					CompanySpvTestData.getInstrumentsScenarioMissingMandatoryArgs());
			printResponse(instrumentResponses);
		});

		Then("company spv transformation unsuccessful due to missing mandatory args", () -> {
			assertUnsuccessResponse();
		});
		
		When("user sends invalid company spv instrument proto with missing company spv details data to server", () -> {
			instrumentResponses = CompanySpvTestData.getCompantSpvInstrumentResponse(getInstrumentTransformerService(),
					CompanySpvTestData.getInstrumentsScenarioMissingInstrumentDetails());
			printResponse(instrumentResponses);
		});

		Then("company spv transformation unsuccessful due to missing company spv details", () -> {
			assertUnsuccessResponse();
		});
		
		When("user sends valid company spv instrument proto with attributes secGroup: Loan and secType: Term to server", () -> {
			instrumentResponses = CompanySpvTestData.getCompantSpvInstrumentResponse(getInstrumentTransformerService(),
					CompanySpvTestData.getInstrumentsScenarioSuccessValidSecGroupLoanAndValidSecTypeTerm());
			printResponse(instrumentResponses);
		});

		Then("company spv transformation successful for secGroup: Loan and secType: Term", () -> {
			assertSuccessResponse();
			Instrument instrument = CompanySpvTestData
					.getInstrumentsScenarioSuccessValidSecGroupLoanAndValidSecTypeTerm().get(0);
			String cusip = cusipAliasesDao.getCusipByEFrontId(instrument.getInstrumentDetails(0).getInstrumentId());
			Optional<List<CreditRatingHist>> creditRatingList = creditRatingHistDao.fetchByCusip(cusip);
			assertEquals(4, creditRatingList.get().size());
		});
		
		When("user sends valid company spv instrument proto with attributes secGroup: Equity and secType: Private to server", () -> {
			instrumentResponses = CompanySpvTestData.getCompantSpvInstrumentResponse(getInstrumentTransformerService(),
							      CompanySpvTestData.getInstrumentsScenarioSuccessValidSecGroupEquityAndValidSecTypePrivate());
			printResponse(instrumentResponses);
		});

		Then("company spv transformation successful for secGroup: Equity and secType: Private", () -> {
			assertSuccessResponse();
			Instrument instrument = InstrumentTestData
					.getInstrumentsScenarioSuccessValidSecGroupEquityAndValidSecTypePrivate().get(0);
			String cusip = cusipAliasesDao.getCusipByEFrontId(instrument.getInstrumentDetails(0).getInstrumentId());
			Optional<List<CreditRatingHist>> creditRatingList = creditRatingHistDao.fetchByCusip(cusip);
			assertEquals(4, creditRatingList.get().size());
			NewIssueInfo newIssueInfo = newIssueInfoDao.loadNewIssueInfo(cusip);
			assertEquals(DEFAULT_TO_N, newIssueInfo.getPriceAsPct());
		});
		
		When("user sends valid company spv instrument proto with attributes secGroup: Equity and secType: Warrant to server", () -> {
			instrumentResponses = CompanySpvTestData.getCompantSpvInstrumentResponse(getInstrumentTransformerService(),
							      CompanySpvTestData.getInstrumentsScenarioSuccessValidSecGroupEquityAndValidSecTypeWarrant());
			printResponse(instrumentResponses);
		});

		Then("company spv transformation successful for secGroup: Equity and secType: Warrant", () -> {
			assertSuccessResponse();
		});
		
		When("user sends an company spv instrument proto with invalid secGroup and sectype", () -> {
			instrumentResponses = CompanySpvTestData.getCompantSpvInstrumentResponse(getInstrumentTransformerService(),
					CompanySpvTestData.getInstrumentsWithInvalidSecGroupSecType());
			printResponse(instrumentResponses);
		});

		Then("company spv transformation should be unsuccessful due to invalid secGroup and sectype", () -> {
			boolean success = instrumentResponses.get(0).getSuccess();
			assertEquals(false, success);
		});
		
		When("user sends a company spv instrument proto without instrumentId to server", () -> {
			instrumentResponses = CompanySpvTestData.getCompantSpvInstrumentResponse(getInstrumentTransformerService(),
					CompanySpvTestData.getCompanyInstrumentWithoutInstrumentId());
			printResponse(instrumentResponses);
		});

		Then("company spv transformation should be unsuccessful due to missing instrumentId", () -> {
			boolean success = instrumentResponses.get(0).getSuccess();
			assertEquals(false, success);
		});		
	}
	
	private void printResponse(List<InstrumentResponse> instrumentResponses) {
		Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().create();
		LOGGER.info("List of InstrumentResponse : {}", (gson.toJson(instrumentResponses)));
	}
	
	private void assertSuccessResponse() {
		boolean success = instrumentResponses.get(0).getSuccess();
		assertEquals(true, success);
	}
	private void assertUnsuccessResponse() {
		boolean success = instrumentResponses.get(0).getSuccess();
		assertEquals(false, success);
	}
	
	private InstrumentTransformerService getInstrumentTransformerService() {
		return TestHelper.getEntityTransformerBeam2Service(InstrumentTransformerService.class,
				PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_INSTRUMENTS,
				CucumberConstantsTransformer.CURRENT_NETWORK_MODE);
	}

}
