package com.bfm.aap.pmdx.transformer.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bfm.aap.pmdx.transformer.dao.config.SybaseConfig;

public class QuerySybaseForBrokerRouting {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(QuerySybaseForBrokerRouting.class);
	
    // to help with unit testing - should not be used otherwise
    public QuerySybaseForBrokerRouting() {}

    public List<String> getBrokerRoutingRecords(String value30) throws Exception {
    	String sql = "select * from externdb.dbo.broker_routing where value30 = '" + value30 + "'";
        LOGGER.info(sql);
        return executeQuery(sql, "value30");
    }
    
    public List<String> getExternEntitiesRecords(String entityId, long externEntity) throws Exception {
        String sql = "SELECT  ee.extern_acct, p.portfolio_name,  p.portfolio_code,  p.portfolio_type, "
            		+ "p.pos_table,  p.cusip,  p.currency,  p.full_name "
            		+ "FROM externdb.dbo.extern_entities ee, portdb.dbo.portfolios p "
            		+ "WHERE  ee.extern_acct = '" + entityId +"' AND "
            		+ "ee.extern_entity = " + externEntity
            		+ " AND ee.fund = p.portfolio_code";
        LOGGER.info(sql);
        return executeQuery(sql, "portfolio_code");
    }
    
    public List<Long> getExternEntityId(String bankAccountName) throws Exception {
        List<Long> result = new ArrayList<>();
        String sql = "select acct_code from externdb.dbo.acct_info where shortname = '" + bankAccountName + "'";
        LOGGER.info(sql);
        SybaseConfig sybaseConfig = SybaseConfig.getInstance();
        try (Connection connection = sybaseConfig.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                try (ResultSet rs = ps.executeQuery()) {
                	while (rs.next()) {
                		result.add(rs.getLong("acct_code"));
                	}
                	return result;
                }
            }
        }
    }
    
    private List<String> executeQuery(String sql, String column) throws Exception {
    	List<String> result = new ArrayList<>();
    	SybaseConfig sybaseConfig = SybaseConfig.getInstance();
        try (Connection connection = sybaseConfig.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                try (ResultSet rs = ps.executeQuery()) {
                	while (rs.next()) {
                		result.add(rs.getString(column));
                	}
                	return result;
                }
            }
        }
    }
    
}
