package com.bfm.aap.pmdx.transformer.util;

import java.util.LinkedList;
import java.util.List;

import com.bfm.aap.pmdx.model.DealDetails;
import com.bfm.aap.pmdx.model.Instrument;
import com.bfm.aap.pmdx.model.InstrumentDetails;
import com.bfm.aap.pmdx.model.InstrumentResponse;
import com.bfm.aap.pmdx.model.InstrumentSource;
import com.bfm.aap.pmdx.transformer.constants.CucumberConstantsTransformer;
import com.bfm.aap.pmdx.transformer.service.InstrumentTransformerService;

public class InstrumentTestData {

	public static Instrument.Builder getInstrumentProto() {
		return Instrument.newBuilder().setCurrency(CucumberConstantsTransformer.CURRENCY)
				.setManagementCompany(CucumberConstantsTransformer.MANAGEMENT_COMPANY)
				.setInvestmentStructure(CucumberConstantsTransformer.INVESTMENT_STRUCTURE)
				.setFlag144A(CucumberConstantsTransformer.FLAG_144A)

				.setFlagRound(CucumberConstantsTransformer.FLAG_ROUND)
				.setSettleLocation(CucumberConstantsTransformer.SETTLE_LOCATION)
				.setPmtLocation(CucumberConstantsTransformer.PMT_LOCATION)
				.setBenchmark(CucumberConstantsTransformer.BENCHMARK);
	}

	public static InstrumentDetails getInstrumentDetailsWithoutInstrumentId() {
		return InstrumentDetails.newBuilder().setInstrumentName(CucumberConstantsTransformer.INSTRUMENT_NAME)
				.setInstrumentClass(CucumberConstantsTransformer.INSTRUMENT_CLASS)
				.setInstrumentType(CucumberConstantsTransformer.INSTRUMENT_TYPE)
				.setInstrumentCurrency(CucumberConstantsTransformer.CURRENCY)
				.setInstrumentDomicile(CucumberConstantsTransformer.DOMICILE)
				.setCapitalStructure(CucumberConstantsTransformer.CAPITAL_STRUCTURE_DEBT)
				.setCusip(CucumberConstantsTransformer.VALID_CUSIP_RDDANMKE2)
				.setSecGroup(CucumberConstantsTransformer.SEC_GROUP_EQUITY)
				.setSecType(CucumberConstantsTransformer.SEC_TYPE_PRIVATE)
				.setReviewedBy(CucumberConstantsTransformer.REVIEWED_BY)
				.setSecDesc2(CucumberConstantsTransformer.SEC_DESC_2).setMtnFlag(CucumberConstantsTransformer.MTN)
				.setNotionalFlag(CucumberConstantsTransformer.NOTIONAL_FLAG)
				.setInstrumentSource(InstrumentSource.COMPANY).setDealStructuringId(CucumberConstantsTransformer.XX)
				.setAladdinInstrumentType(CucumberConstantsTransformer.SEC_GROUP_EQUITY + "/"
						+ CucumberConstantsTransformer.SEC_TYPE_PRIVATE)
				.build();
	}

	public static InstrumentDetails getInstrumentDetailsWithoutDealStructuringId() {
		return InstrumentDetails.newBuilder().setInstrumentId(CucumberConstantsTransformer.INSTRUMENT_ID)
				.setInstrumentName(CucumberConstantsTransformer.INSTRUMENT_NAME)
				.setInstrumentClass(CucumberConstantsTransformer.INSTRUMENT_CLASS)
				.setInstrumentType(CucumberConstantsTransformer.INSTRUMENT_TYPE)
				.setInstrumentCurrency(CucumberConstantsTransformer.CURRENCY)
				.setInstrumentDomicile(CucumberConstantsTransformer.DOMICILE)
				.setCapitalStructure(CucumberConstantsTransformer.CAPITAL_STRUCTURE_DEBT)
				.setCusip(CucumberConstantsTransformer.VALID_CUSIP_RDDANMKE2)
				.setSecGroup(CucumberConstantsTransformer.SEC_GROUP_EQUITY)
				.setSecType(CucumberConstantsTransformer.SEC_TYPE_PRIVATE)
				.setReviewedBy(CucumberConstantsTransformer.REVIEWED_BY)
				.setSecDesc2(CucumberConstantsTransformer.SEC_DESC_2).setMtnFlag(CucumberConstantsTransformer.MTN)
				.setNotionalFlag(CucumberConstantsTransformer.NOTIONAL_FLAG).setInstrumentSource(InstrumentSource.DEAL)
				.setAladdinInstrumentType(CucumberConstantsTransformer.SEC_GROUP_EQUITY + "/"
						+ CucumberConstantsTransformer.SEC_TYPE_PRIVATE)
				.build();
	}

	public static InstrumentDetails getInstrumentsDetailsForScenarioInvalidInstrumentDetails() {
		return InstrumentDetails.newBuilder().setInstrumentId(CucumberConstantsTransformer.INSTRUMENT_ID)
				.setInstrumentName(CucumberConstantsTransformer.DOUBLE_SLASH)
				.setInstrumentType(CucumberConstantsTransformer.DOUBLE_SLASH)
				.setInstrumentCurrency(CucumberConstantsTransformer.DOUBLE_SLASH)
				.setInstrumentDomicile(CucumberConstantsTransformer.DOUBLE_SLASH)
				.setCapitalStructure(CucumberConstantsTransformer.DOUBLE_SLASH)
				.setCusip(CucumberConstantsTransformer.VALID_CUSIP_RDDANMKE2)
				.setSecGroup(CucumberConstantsTransformer.SEC_GROUP_LOAN)
				.setSecType(CucumberConstantsTransformer.SEC_TYPE_TERM)
				.setReviewedBy(CucumberConstantsTransformer.REVIEWED_BY)
				.setSecDesc2(CucumberConstantsTransformer.SEC_DESC_2).setMtnFlag(CucumberConstantsTransformer.MTN)
				.setNotionalFlag(CucumberConstantsTransformer.NOTIONAL_FLAG)
				.setInstrumentSource(InstrumentSource.COMPANY).setDealStructuringId(CucumberConstantsTransformer.XX)
				.setAladdinInstrumentType(CucumberConstantsTransformer.SEC_GROUP_EQUITY + "/"
						+ CucumberConstantsTransformer.SEC_TYPE_PRIVATE)
				.build();
	}

	public static InstrumentDetails getInstrumentsDetailsForScenarioSuccessValidSecGroupEquityAndValidSecTypePrivate() {
		return InstrumentDetails.newBuilder().setInstrumentId(CucumberConstantsTransformer.PRIVATE_EQUITY_INSTRUMENT_ID)
				.setInstrumentName(CucumberConstantsTransformer.INSTRUMENT_NAME)
				.setInstrumentType(CucumberConstantsTransformer.INSTRUMENT_TYPE)
				.setInstrumentCurrency(CucumberConstantsTransformer.CURRENCY)
				.setInstrumentDomicile(CucumberConstantsTransformer.DOMICILE)
				.setCapitalStructure(CucumberConstantsTransformer.CAPITAL_STRUCTURE_EQUITY)
				.setCusip(CucumberConstantsTransformer.VALID_CUSIP_RDDANMKF9)
				.setSecGroup(CucumberConstantsTransformer.SEC_GROUP_EQUITY)
				.setSecType(CucumberConstantsTransformer.SEC_TYPE_PRIVATE)
				.setReviewedBy(CucumberConstantsTransformer.REVIEWED_BY)
				.setSecDesc2(CucumberConstantsTransformer.SEC_DESC_2).setMtnFlag(CucumberConstantsTransformer.MTN)
				.setNotionalFlag(CucumberConstantsTransformer.NOTIONAL_FLAG)
				.setInstrumentSource(InstrumentSource.COMPANY).setDealStructuringId(CucumberConstantsTransformer.XX)
				.setAladdinInstrumentType(CucumberConstantsTransformer.SEC_GROUP_EQUITY + "/"
						+ CucumberConstantsTransformer.SEC_TYPE_PRIVATE)
				.build();
	}

	public static InstrumentDetails getInstrumentsDetailsForScenarioSuccessValidSecGroupEquityAndValidSecTypeWarrant() {
		return InstrumentDetails.newBuilder().setInstrumentId(CucumberConstantsTransformer.WARRANT_EQUITY_INSTRUMENT_ID)
				.setInstrumentName(CucumberConstantsTransformer.INSTRUMENT_NAME)
				.setInstrumentType(CucumberConstantsTransformer.INSTRUMENT_TYPE)
				.setInstrumentCurrency(CucumberConstantsTransformer.CURRENCY)
				.setInstrumentDomicile(CucumberConstantsTransformer.DOMICILE)
				.setCapitalStructure(CucumberConstantsTransformer.CAPITAL_STRUCTURE_EQUITY)
				.setCusip(CucumberConstantsTransformer.VALID_CUSIP_RDDANMKF9)
				.setSecGroup(CucumberConstantsTransformer.SEC_GROUP_EQUITY)
				.setSecType(CucumberConstantsTransformer.SEC_TYPE_WARRANT)
				.setReviewedBy(CucumberConstantsTransformer.REVIEWED_BY)
				.setSecDesc2(CucumberConstantsTransformer.SEC_DESC_2).setMtnFlag(CucumberConstantsTransformer.MTN)
				.setNotionalFlag(CucumberConstantsTransformer.NOTIONAL_FLAG)
				.setInstrumentSource(InstrumentSource.COMPANY).setDealStructuringId(CucumberConstantsTransformer.XX)
				.setAladdinInstrumentType(CucumberConstantsTransformer.SEC_GROUP_EQUITY + "/"
						+ CucumberConstantsTransformer.SEC_TYPE_WARRANT)
				.build();
	}

	public static InstrumentDetails getInstrumentDetailsForScenarioSuccess() {
		return InstrumentDetails.newBuilder().setInstrumentId(CucumberConstantsTransformer.INSTRUMENT_ID)
				.setInstrumentName(CucumberConstantsTransformer.INSTRUMENT_NAME)
				.setInstrumentClass(CucumberConstantsTransformer.INSTRUMENT_CLASS)
				.setInstrumentType(CucumberConstantsTransformer.INSTRUMENT_TYPE)
				.setInstrumentCurrency(CucumberConstantsTransformer.CURRENCY)
				.setInstrumentDomicile(CucumberConstantsTransformer.DOMICILE)
				.setCapitalStructure(CucumberConstantsTransformer.CAPITAL_STRUCTURE_DEBT)
				.setCusip(CucumberConstantsTransformer.VALID_CUSIP_RDDANMKE2)
				.setSecGroup(CucumberConstantsTransformer.SEC_GROUP_EQUITY)
				.setSecType(CucumberConstantsTransformer.SEC_TYPE_PRIVATE)
				.setReviewedBy(CucumberConstantsTransformer.REVIEWED_BY)
				.setSecDesc2(CucumberConstantsTransformer.SEC_DESC_2).setMtnFlag(CucumberConstantsTransformer.MTN)
				.setNotionalFlag(CucumberConstantsTransformer.NOTIONAL_FLAG)
				.setInstrumentSource(InstrumentSource.COMPANY).setDealStructuringId(CucumberConstantsTransformer.XX)
				.setAladdinInstrumentType(CucumberConstantsTransformer.SEC_GROUP_EQUITY + "/"
						+ CucumberConstantsTransformer.SEC_TYPE_PRIVATE)
				.build();
	}

	public static InstrumentDetails getInstrumentDetailsWithoutInstrumentSource() {
		return InstrumentDetails.newBuilder().setInstrumentId(CucumberConstantsTransformer.INSTRUMENT_ID)
				.setInstrumentName(CucumberConstantsTransformer.INSTRUMENT_NAME)
				.setInstrumentClass(CucumberConstantsTransformer.INSTRUMENT_CLASS)
				.setInstrumentType(CucumberConstantsTransformer.INSTRUMENT_TYPE)
				.setInstrumentCurrency(CucumberConstantsTransformer.CURRENCY)
				.setInstrumentDomicile(CucumberConstantsTransformer.DOMICILE)
				.setCapitalStructure(CucumberConstantsTransformer.CAPITAL_STRUCTURE_DEBT)
				.setCusip(CucumberConstantsTransformer.VALID_CUSIP_RDDANMKE2)
				.setSecGroup(CucumberConstantsTransformer.SEC_GROUP_EQUITY)
				.setSecType(CucumberConstantsTransformer.SEC_TYPE_PRIVATE)
				.setReviewedBy(CucumberConstantsTransformer.REVIEWED_BY)
				.setSecDesc2(CucumberConstantsTransformer.SEC_DESC_2).setMtnFlag(CucumberConstantsTransformer.MTN)
				.setNotionalFlag(CucumberConstantsTransformer.NOTIONAL_FLAG)
				.setDealStructuringId(CucumberConstantsTransformer.XX)
				.setAladdinInstrumentType(CucumberConstantsTransformer.SEC_GROUP_EQUITY + "/"
						+ CucumberConstantsTransformer.SEC_TYPE_PRIVATE)
				.build();
	}

	public static InstrumentDetails getDealsInstrumentDetailsForScenarioSuccess() {
		return InstrumentDetails.newBuilder().setInstrumentId(CucumberConstantsTransformer.XX)
				.setInstrumentName(CucumberConstantsTransformer.INSTRUMENT_NAME)
				.setInstrumentClass(CucumberConstantsTransformer.INSTRUMENT_CLASS)
				.setInstrumentType(CucumberConstantsTransformer.INSTRUMENT_TYPE)
				.setInstrumentCurrency(CucumberConstantsTransformer.CURRENCY)
				.setInstrumentDomicile(CucumberConstantsTransformer.DOMICILE)
				.setCapitalStructure(CucumberConstantsTransformer.CAPITAL_STRUCTURE_DEBT)
				.setCusip(CucumberConstantsTransformer.VALID_CUSIP_RDDANMKE2)
				.setSecGroup(CucumberConstantsTransformer.SEC_GROUP_EQUITY)
				.setSecType(CucumberConstantsTransformer.SEC_TYPE_PRIVATE)
				.setReviewedBy(CucumberConstantsTransformer.REVIEWED_BY)
				.setSecDesc2(CucumberConstantsTransformer.SEC_DESC_2).setMtnFlag(CucumberConstantsTransformer.MTN)
				.setNotionalFlag(CucumberConstantsTransformer.NOTIONAL_FLAG).setInstrumentSource(InstrumentSource.DEAL)
				.setDealStructuringId(CucumberConstantsTransformer.DEAL_STRUCTURING_ID)
				.setAladdinInstrumentType(CucumberConstantsTransformer.SEC_GROUP_EQUITY + "/"
						+ CucumberConstantsTransformer.SEC_TYPE_PRIVATE)
				.build();
	}

	public static InstrumentDetails getDebtDealsInstrumentDetailsWithInvalidSecGroupSecType() {
		return InstrumentDetails.newBuilder().setInstrumentId(CucumberConstantsTransformer.XX)
				.setInstrumentName(CucumberConstantsTransformer.INSTRUMENT_NAME)
				.setInstrumentClass(CucumberConstantsTransformer.INSTRUMENT_CLASS)
				.setInstrumentType(CucumberConstantsTransformer.INSTRUMENT_TYPE)
				.setInstrumentCurrency(CucumberConstantsTransformer.CURRENCY)
				.setInstrumentDomicile(CucumberConstantsTransformer.DOMICILE)
				.setCapitalStructure(CucumberConstantsTransformer.CAPITAL_STRUCTURE_DEBT)
				.setCusip(CucumberConstantsTransformer.VALID_CUSIP_RDDANMKE2)
				.setSecGroup(CucumberConstantsTransformer.SEC_GROUP_FUND)
				.setSecType(CucumberConstantsTransformer.SEC_TYPE_PRIVATE)
				.setReviewedBy(CucumberConstantsTransformer.REVIEWED_BY)
				.setSecDesc2(CucumberConstantsTransformer.SEC_DESC_2).setMtnFlag(CucumberConstantsTransformer.MTN)
				.setNotionalFlag(CucumberConstantsTransformer.NOTIONAL_FLAG).setInstrumentSource(InstrumentSource.DEAL)
				.setDealStructuringId(CucumberConstantsTransformer.DEAL_STRUCTURING_ID)
				.setAladdinInstrumentType(CucumberConstantsTransformer.SEC_GROUP_FUND + "/"
						+ CucumberConstantsTransformer.SEC_TYPE_PRIVATE)
				.build();
	}

	public static InstrumentDetails getDebtDealsInstrumentDetailsForScenarioSuccess() {
		return InstrumentDetails.newBuilder().setInstrumentId(CucumberConstantsTransformer.XX)
				.setInstrumentName(CucumberConstantsTransformer.INSTRUMENT_NAME)
				.setInstrumentClass(CucumberConstantsTransformer.INSTRUMENT_CLASS)
				.setInstrumentType(CucumberConstantsTransformer.INSTRUMENT_TYPE)
				.setInstrumentCurrency(CucumberConstantsTransformer.CURRENCY)
				.setInstrumentDomicile(CucumberConstantsTransformer.DOMICILE)
				.setCapitalStructure(CucumberConstantsTransformer.CAPITAL_STRUCTURE_DEBT)
				.setCusip(CucumberConstantsTransformer.VALID_CUSIP_RDDANMKE2)
				.setSecGroup(CucumberConstantsTransformer.SEC_GROUP_LOAN)
				.setSecType(CucumberConstantsTransformer.SEC_TYPE_TERM)
				.setReviewedBy(CucumberConstantsTransformer.REVIEWED_BY)
				.setSecDesc2(CucumberConstantsTransformer.SEC_DESC_2).setMtnFlag(CucumberConstantsTransformer.MTN)
				.setNotionalFlag(CucumberConstantsTransformer.NOTIONAL_FLAG).setInstrumentSource(InstrumentSource.DEAL)
				.setDealStructuringId(CucumberConstantsTransformer.DEBT_DEAL_STRUCTURING_ID)
				.setAladdinInstrumentType(
						CucumberConstantsTransformer.SEC_GROUP_LOAN + "/" + CucumberConstantsTransformer.SEC_TYPE_TERM)
				.build();
	}

	public static List<Instrument> getInstrumentsScenarioSuccess() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetId(CucumberConstantsTransformer.ASSET_ID).setAssetName(CucumberConstantsTransformer.ASSET_NAME)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE).setIssuer(CucumberConstantsTransformer.ISSUER)
				.addInstrumentDetails(getInstrumentDetailsForScenarioSuccess())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE)
						.setClientName(CucumberConstantsTransformer.VALID_CLIENT_NAME).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}

	public static List<Instrument> getInstrumentsWithoutInstrumentSource() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetId(CucumberConstantsTransformer.ASSET_ID).setAssetName(CucumberConstantsTransformer.ASSET_NAME)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE).setIssuer(CucumberConstantsTransformer.ISSUER)
				.addInstrumentDetails(getInstrumentDetailsWithoutInstrumentSource())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE)
						.setClientName(CucumberConstantsTransformer.VALID_CLIENT_NAME).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}

	public static List<Instrument> getCompanyInstrumentWithoutInstrumentId() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetId(CucumberConstantsTransformer.ASSET_ID).setAssetName(CucumberConstantsTransformer.ASSET_NAME)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE).setIssuer(CucumberConstantsTransformer.ISSUER)
				.addInstrumentDetails(getInstrumentDetailsWithoutInstrumentId())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE)
						.setClientName(CucumberConstantsTransformer.VALID_CLIENT_NAME).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}

	public static List<Instrument> getDealsInstrumentWithoutDealStructuringId() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetId(CucumberConstantsTransformer.ASSET_ID).setAssetName(CucumberConstantsTransformer.ASSET_NAME)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE).setIssuer(CucumberConstantsTransformer.ISSUER)
				.addInstrumentDetails(getInstrumentDetailsWithoutDealStructuringId())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE)
						.setClientName(CucumberConstantsTransformer.VALID_CLIENT_NAME).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}

	public static List<Instrument> getDealsInstrumentWithoutAssetId() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetName(CucumberConstantsTransformer.ASSET_NAME)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE).setIssuer(CucumberConstantsTransformer.ISSUER)
				.addInstrumentDetails(getDealsInstrumentDetailsForScenarioSuccess())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE)
						.setClientName(CucumberConstantsTransformer.VALID_CLIENT_NAME).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}

	public static List<Instrument> getInstrumentsScenarioMissingMandatoryArgs() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetName(CucumberConstantsTransformer.ASSET_NAME)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE).setIssuer(CucumberConstantsTransformer.ISSUER)
				.addInstrumentDetails(getInstrumentDetailsForScenarioSuccess())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE)
						.setClientName(CucumberConstantsTransformer.VALID_CLIENT_NAME).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}

	public static List<Instrument> getInstrumentsScenarioMissingInstrumentDetails() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetId(CucumberConstantsTransformer.ASSET_ID).setAssetName(CucumberConstantsTransformer.ASSET_NAME)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE).setIssuer(CucumberConstantsTransformer.ISSUER)
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE)
						.setClientName(CucumberConstantsTransformer.VALID_CLIENT_NAME).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}

	public static List<Instrument> getInstrumentsScenarioInvalidInstrumentDetails() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetId(CucumberConstantsTransformer.ASSET_ID).setAssetName(CucumberConstantsTransformer.ASSET_NAME)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE).setIssuer(CucumberConstantsTransformer.ISSUER)
				.addInstrumentDetails(getInstrumentsDetailsForScenarioInvalidInstrumentDetails())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE)
						.setClientName(CucumberConstantsTransformer.VALID_CLIENT_NAME).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}

	public static List<Instrument> getInstrumentsScenarioSuccessValidSecGroupLoanAndValidSecTypeTerm() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetId(CucumberConstantsTransformer.ASSET_ID).setAssetName(CucumberConstantsTransformer.ASSET_NAME)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE).setIssuer(CucumberConstantsTransformer.ISSUER)
				.addInstrumentDetails(getInstrumentDetailsForScenarioSuccess())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE)
						.setClientName(CucumberConstantsTransformer.VALID_CLIENT_NAME).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}

	public static List<Instrument> getInstrumentsScenarioSuccessValidSecGroupEquityAndValidSecTypePrivate() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetId(CucumberConstantsTransformer.ASSET_ID).setAssetName(CucumberConstantsTransformer.ASSET_NAME)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE).setIssuer(CucumberConstantsTransformer.ISSUER)
				.addInstrumentDetails(
						getInstrumentsDetailsForScenarioSuccessValidSecGroupEquityAndValidSecTypePrivate())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE)
						.setClientName(CucumberConstantsTransformer.VALID_CLIENT_NAME).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}

	public static List<Instrument> getInstrumentsScenarioSuccessValidSecGroupEquityAndValidSecTypeWarrant() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetId(CucumberConstantsTransformer.ASSET_ID).setAssetName(CucumberConstantsTransformer.ASSET_NAME)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE).setIssuer(CucumberConstantsTransformer.ISSUER)
				.addInstrumentDetails(
						getInstrumentsDetailsForScenarioSuccessValidSecGroupEquityAndValidSecTypeWarrant())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE)
						.setClientName(CucumberConstantsTransformer.VALID_CLIENT_NAME).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}

	public static List<Instrument> getInstrumentsForValidIssuer() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetId(CucumberConstantsTransformer.ASSET_ID).setAssetName(CucumberConstantsTransformer.ASSET_NAME)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE).setCurrency(CucumberConstantsTransformer.CURRENCY)
				.setIssuer(CucumberConstantsTransformer.VALID_ISSUER)
				.addInstrumentDetails(getInstrumentDetailsForScenarioSuccess())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE)
						.setClientName(CucumberConstantsTransformer.VALID_CLIENT_NAME).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}

	public static List<Instrument> getInstrumentsForInvalidIssuer() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetId(CucumberConstantsTransformer.ASSET_ID).setAssetName(CucumberConstantsTransformer.ASSET_NAME)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE).setCurrency(CucumberConstantsTransformer.CURRENCY)
				.setIssuer(CucumberConstantsTransformer.INVALID_ISSUER)
				.addInstrumentDetails(getInstrumentDetailsForScenarioSuccess())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE)
						.setClientName(CucumberConstantsTransformer.VALID_CLIENT_NAME).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}

	public static List<Instrument> getDealsInstruments() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetName(CucumberConstantsTransformer.ASSET_NAME).setAssetId(CucumberConstantsTransformer.ASSET_ID)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE).setCurrency(CucumberConstantsTransformer.CURRENCY)
				.addInstrumentDetails(getDealsInstrumentDetailsForScenarioSuccess())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE)
						.setClientName(CucumberConstantsTransformer.VALID_CLIENT_NAME).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}

	public static List<Instrument> getDealsInstrumentsWithoutDealId() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetName(CucumberConstantsTransformer.ASSET_NAME).setAssetId(CucumberConstantsTransformer.ASSET_ID)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE).setCurrency(CucumberConstantsTransformer.CURRENCY)
				.setDealDetails(DealDetails.newBuilder().build())
				.addInstrumentDetails(getDealsInstrumentDetailsForScenarioSuccess())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE)
						.setClientName(CucumberConstantsTransformer.VALID_CLIENT_NAME).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}

	public static List<Instrument> getDebtDealInstruments() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetName(CucumberConstantsTransformer.ASSET_NAME).setAssetId(CucumberConstantsTransformer.ASSET_ID)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE).setCurrency(CucumberConstantsTransformer.CURRENCY)
				.addInstrumentDetails(getDebtDealsInstrumentDetailsForScenarioSuccess())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE)
						.setClientName(CucumberConstantsTransformer.VALID_CLIENT_NAME).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}

	public static List<Instrument> getInstrumentsWithInvalidSecGroupSecType() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetName(CucumberConstantsTransformer.ASSET_NAME).setAssetId(CucumberConstantsTransformer.ASSET_ID)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE).setCurrency(CucumberConstantsTransformer.CURRENCY)
				.addInstrumentDetails(getDebtDealsInstrumentDetailsWithInvalidSecGroupSecType())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE)
						.setClientName(CucumberConstantsTransformer.VALID_CLIENT_NAME).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}

	public static List<Instrument> getInstrumentsForEmptyIssuer() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetName(CucumberConstantsTransformer.ASSET_NAME).setAssetId(CucumberConstantsTransformer.ASSET_ID)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE).setCurrency(CucumberConstantsTransformer.CURRENCY)
				.addInstrumentDetails(getInstrumentDetailsForScenarioSuccess())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE)
						.setClientName(CucumberConstantsTransformer.VALID_CLIENT_NAME).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}

	public static List<Instrument> getInstruments() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetId(CucumberConstantsTransformer.ASSET_ID).setAssetName(CucumberConstantsTransformer.ASSET_NAME)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE).setIssuer(CucumberConstantsTransformer.ISSUER)
				.addInstrumentDetails(
						getInstrumentsDetailsForScenarioSuccessValidSecGroupEquityAndValidSecTypePrivate())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE)
						.setClientName(CucumberConstantsTransformer.VALID_CLIENT_NAME).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}

	public static List<InstrumentResponse> getInstrumentResponse(InstrumentTransformerService service,
			List<Instrument> instruments) {
		List<InstrumentResponse> response = service.transformLoadEntities(instruments);
		return response;
	}

}
