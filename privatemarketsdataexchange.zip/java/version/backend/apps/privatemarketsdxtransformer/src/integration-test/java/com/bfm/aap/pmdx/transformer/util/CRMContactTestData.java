package com.bfm.aap.pmdx.transformer.util;

import static com.google.protobuf.util.Timestamps.fromMillis;
import static java.lang.System.currentTimeMillis;

import org.apache.commons.lang3.RandomStringUtils;

import com.bfm.aap.pmdx.model.Address;
import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.ContactEmail;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.model.util.ReferenceLevel;
import com.bfm.aap.pmdx.model.util.Source;

public class CRMContactTestData {

	public static Contact getContact() {
		return Contact.newBuilder()
				.addEmailList(getContactEmail())
				.addAddressList(getAddress())
				.setContactId(RandomStringUtils.randomAlphanumeric(32))
				.setFirstName("Walter")
				.setMiddleName("Hartwell")
				.setLastName("White")
				.setNickName("Heisenberg")
				.setDateOfBirth("September 7, 1958")
				.setBirthPlaceCity("Albuquerque")
				.setPrimaryCitizenship("USA")
				.setEntityInfo(getEntityInfo()).build();
	}
	
	public static ContactEmail getContactEmail() {
		return ContactEmail.newBuilder()
				.setEmail("Walter.White@yahoo.com")
				.setIsPrimary(true)
				.build();
	}
	
	public static Address getAddress() {
		return Address.newBuilder()
				.setAddressType("Office")
				.setStreet1("308 Negra Arroyo Lane")
				.setCity("Albuquerque")
				.setState("New Mexico")
				.setCountry("USA")
				.build();
	}
	
	public static Contact getContact_fail() {
		return Contact.newBuilder()
				.build();
	}
	
	public static Contact getContact_fail_missing_contactId() {
		return Contact.newBuilder()
				.setFirstName("Walter")
				.setMiddleName("Hartwell")
				.setLastName("White")
				.setNickName("Heisenberg")
				.setDateOfBirth("September 7, 1958")
				.setBirthPlaceCity("Albuquerque")
				.setPrimaryCitizenship("USA")
				.setEntityInfo(getEntityInfo()).build();
	}
	
	public static Contact getContact_fail_missing_name() {
		return Contact.newBuilder()
				.setContactId(RandomStringUtils.randomAlphanumeric(32))
				.setNickName("Heisenberg")
				.setDateOfBirth("September 7, 1958")
				.setBirthPlaceCity("Albuquerque")
				.setPrimaryCitizenship("USA")
				.setEntityInfo(getEntityInfo()).build();
	}
	
	public static Contact getContact_fail_missing_entityInfo() {
		return Contact.newBuilder()
				.setContactId(RandomStringUtils.randomAlphanumeric(32))
				.setFirstName("Walter")
				.setMiddleName("Hartwell")
				.setLastName("White")
				.setNickName("Heisenberg")
				.setDateOfBirth("September 7, 1958")
				.setBirthPlaceCity("Albuquerque")
				.setPrimaryCitizenship("USA").build();
	}
	
	public static EntityInfo getEntityInfo(){
		return EntityInfo.newBuilder()
				.setClientName("DEV")
				.setPrimaryData(true)
				.setNetworkMode(NetworkMode.valueOf("BLUE"))
				.setOriginTimestamp(fromMillis(currentTimeMillis()))
				.setSource(Source.INVEST)
				.setReferenceLevel(ReferenceLevel.PORTFOLIO_LEVEL)
				.setModelVersion("5.1.2")
				.build();
	}
	
}
