package com.bfm.aap.pmdx.transformer.service;

import com.bfm.aap.pmdx.transformer.BaseIT;

import cucumber.api.java.Before;

@SuppressWarnings("deprecation")
public class CucumberConfiguration extends BaseIT {

	/*
	 * Dummy method so cucumber will recognize this class
	 * as glue and use its context configuration
	 * */
	@Before
	public void setup_cucumber_spring_context() {
		
	}

}
