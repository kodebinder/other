package com.bfm.aap.pmdx.transformer.service;

import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bfm.aap.pmdx.model.Portfolio;
import com.bfm.aap.pmdx.model.PortfolioResponse;
import com.bfm.aap.pmdx.model.ShareClass;
import com.bfm.aap.pmdx.redblue.PmdxServiceType;
import com.bfm.aap.pmdx.transformer.constants.CucumberConstantsTransformer;
import com.bfm.aap.pmdx.transformer.util.PortfolioTestData;
import com.bfm.aap.pmdx.transformer.util.TestHelper;
import com.bfm.aap.privatemarkets.dao.CusipAliasesDao;
import com.bfm.aap.privatemarkets.dao.DaoFactory;
import com.bfm.aap.privatemarkets.dao.SecurityMasterDao;
import com.bfm.aap.privatemarkets.dao.model.SecMaster;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.protobuf.Timestamp;

import io.cucumber.java8.En;

public class PrivateMarketsDXTransformerPortfolioStepDefinition implements En {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(PrivateMarketsDXTransformerPortfolioStepDefinition.class);
	private List<PortfolioResponse> portfolioResponses;

	PrivateMarketsDXTransformerPortfolioStepDefinition(final DaoFactory daoFactory) {

		Given("user {string} wants to transform an portfolio", (String user) -> {
			LOGGER.info("User : {}", user);
		});

		When("portfolio transform request contains the mandatory field and all fields have valid data", () -> {
			portfolioResponses = PortfolioTestData.getPortfolioResponse(getPortfolioTransformerService(),
					PortfolioTestData.getPortfolioScenarioSuccess());
			printResponse(portfolioResponses);
		});

		Then("portfolio should be transformed", () -> {
			assertSuccessResponse();
		});

		When("user sends portfolio proto without EntityInfo", () -> {
			portfolioResponses = PortfolioTestData.getPortfolioResponse(getPortfolioTransformerService(),
					PortfolioTestData.getPortfolioScenarioEntityInfoFailure());
			printResponse(portfolioResponses);
		});

		Then("portfolio should not be transformed", () -> {
			assertFailureResponse();
		});

		When("user sends portfolio proto without PortfolioCode", () -> {
			portfolioResponses = PortfolioTestData.getPortfolioResponse(getPortfolioTransformerService(),
					PortfolioTestData.getPortfolioScenarioPortfolioCodeFailure());
			printResponse(portfolioResponses);
		});

		When("user sends portfolio proto without PortfolioCode and EntityInfo", () -> {
			portfolioResponses = PortfolioTestData.getPortfolioResponse(getPortfolioTransformerService(),
					PortfolioTestData.getPortfolioScenarioPortfolioCodeAndEntityInfoFailure());
			printResponse(portfolioResponses);
		});

		When("user sends an existing portfolio proto contains some updated fields and all fields have valid data",
				() -> {
					// Portfolio Created
					String portfolioId = "ED5FF3D09A7D40CASCADEUPDATE01";
					Portfolio.Builder builder = Portfolio.newBuilder().setPortfolioId(portfolioId).setTicker("CIT02")
							.setPortfolioName("End 2 End Test Aladdin Portfolio 1").setPortfolioType("TEST_TYPE")
							.setCurrency("USD")
							.setCreationDate(Timestamp.newBuilder().setSeconds(1565383786).setNanos(0).build())
							.setInceptionDate(Timestamp.newBuilder().setSeconds(1565898996).setNanos(0).build())
							.setModificationDate(Timestamp.newBuilder().setSeconds(1565383786).setNanos(0).build())
							.setDeleted(false).setClientId("1000")
							.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE))
							.setPortfolioCode(12345);
					portfolioResponses = PortfolioTestData.getPortfolioResponse(getPortfolioTransformerService(),
							Collections.singletonList(builder.build()));
					Portfolio.Builder existingPortfolio = portfolioResponses.get(0).getData().toBuilder();
					// ShareClass Created Under the created portfolio
					String shareClassId = "MCHINAPR05052021SUPDATE";
					ShareClass.Builder shareClass = ShareClass.newBuilder().setShareclassId(shareClassId)
							.setShareclassShortname("CITUP1").setCurrency("USD").setPortfolioId(portfolioId)
							.setInceptionDate(TestHelper.getTimestamp())
							.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE));
					getShareClassTransformerService()
							.transformLoadEntities(Collections.singletonList(shareClass.build()));
					// Portfolio Updated
					String newPortfolioName = "UpdatedPFName";
					existingPortfolio.setPortfolioName(newPortfolioName);
					getPortfolioTransformerService()
							.transformLoadEntities(Collections.singletonList(existingPortfolio.build()));
					// Check If ShareClass also got updated
					String shareClassCusip = daoFactory.getDao(CusipAliasesDao.class, true)
							.getCusipByEFrontId(shareClassId);
					SecMaster secMaster = daoFactory.getDao(SecurityMasterDao.class, true).getSecurity(shareClassCusip);
					assertTrue(secMaster.getSecDesc1().contains(newPortfolioName));
				});

		Then("portfolio and its associated shareclasses should be updated", () -> {
			assertSuccessResponse();
		});

	}

	private void printResponse(List<PortfolioResponse> portfolioResponses) {
		Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().create();
		System.out.println(gson.toJson(portfolioResponses));
	}

	private void assertSuccessResponse() {
		boolean success = portfolioResponses.get(0).getSuccess();
		int errorMessageLength = portfolioResponses.get(0).getMessage().length();
		assertEquals(true, success);
		assertEquals(0, errorMessageLength);
	}

	private void assertFailureResponse() {
		boolean success = portfolioResponses.get(0).getSuccess();
		int errorMessageLength = portfolioResponses.get(0).getMessage().length();
		assertEquals(false, success);
		assertNotEquals(0, errorMessageLength);
	}

	private PortfolioTransformerService getPortfolioTransformerService() {
		return TestHelper.getEntityTransformerBeam2Service(PortfolioTransformerService.class,
				PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_PORTFOLIO,
				CucumberConstantsTransformer.CURRENT_NETWORK_MODE);
	}

	private ShareClassTransformerService getShareClassTransformerService() {
		return TestHelper.getEntityTransformerBeam2Service(ShareClassTransformerService.class,
				PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_SHARE_CLASS,
				CucumberConstantsTransformer.CURRENT_NETWORK_MODE);
	}
}
