package com.bfm.aap.pmdx.transformer.util;

import org.apache.commons.lang3.RandomStringUtils;

import com.bfm.aap.pmdx.model.Issuer;
import com.bfm.aap.pmdx.transformer.constants.CucumberConstantsTransformer;

public class IssuerTestData {
	
	public static Issuer.Builder getIssuerProto(){
		return Issuer.newBuilder()
				.setActiveInd(Boolean.TRUE)
				.setAladdinIssuerId(RandomStringUtils.randomAlphanumeric(20))
				.setClientId(RandomStringUtils.randomAlphanumeric(20))
				.setCreationDate(TestHelper.getTimestamp())
				.setDeleted(Boolean.FALSE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE)
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE))
				.setIssuerId(RandomStringUtils.randomAlphanumeric(20))
				.setManagerName(CucumberConstantsTransformer.MANAGER_NAME)
				.setPrivateInd(Boolean.TRUE)
				.setRegionId(CucumberConstantsTransformer.REGION_ID)
				.setShortName(CucumberConstantsTransformer.ISSUER_SHORTNAME)
				.setSourceId(RandomStringUtils.randomAlphanumeric(20))
				.setSourceName(RandomStringUtils.randomAlphanumeric(20))
				.setTicker(RandomStringUtils.randomAlphanumeric(20))
				.setWebsite(CucumberConstantsTransformer.WEBSITE);
	}
	
	public static Issuer getIssuer() {
		return IssuerTestData.getIssuerProto()
				.build();
	}
}
