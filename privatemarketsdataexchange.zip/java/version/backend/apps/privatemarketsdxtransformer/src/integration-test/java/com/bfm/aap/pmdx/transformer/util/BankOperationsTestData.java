package com.bfm.aap.pmdx.transformer.util;

import java.util.LinkedList;
import java.util.List;

import com.bfm.aap.pmdx.model.BankOperation;
import com.bfm.aap.pmdx.model.BankOperationResponse;
import com.bfm.aap.pmdx.model.LinkedEntityDetail;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.transformer.constants.CucumberConstantsTransformer;
import com.bfm.aap.pmdx.transformer.service.BankOperationTransformerService;
import com.google.type.Money;

public class BankOperationsTestData {
	private static final long AMOUNT_OP_CURRENCY_UNITS = 111111;
	private static final String BANK_OPERATION_ID = "BANKOPERATIONID3B43BC3CBB6C539DABLUE1X";
	private static final String LINKED_ENTITY_DETAIL_ENTITY_ID = "LINKEDENTITYDETAILENTITYID0000000011";
	private static final String LINKED_COUNTERPARTY_DETAIL_ENTITY_ID = "LINKEDCOUNTERPARTYDETAILENTITYID0012";
	private static final String LINKED_ENTITY_DETAIL_ENTITY_BANK_ACCOUNT_ID = "LINKEDENTITYDETAILENTITYBANKACCOUNTID0013";
	private static final String LINKED_COUNTERPARTY_DETAIL_ENTITY_BANK_ACCOUNT_ID = "LINKEDCOUNTERPARTYDETAILENTITYBANKACCOUNTID0014";
	
	public static List<BankOperation> getBankOperationScenarioSuccess() {
		BankOperation bankOperation = BankOperation.newBuilder()
				.setBankOperationId(BANK_OPERATION_ID)
				.setCreationDate(TestHelper.getTimestamp())
				.setSettleDate(TestHelper.getTimestamp())
				.setOperationCurrency(CucumberConstantsTransformer.CURRENCY)
				.setAmountOpCurrency(Money.newBuilder()
						.setUnits(AMOUNT_OP_CURRENCY_UNITS).build())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE))
				.setLinkedCounterpartyDetail(LinkedEntityDetail.newBuilder()
						.setEntityType(EntityType.PORTFOLIO)
						.setEntityId(LINKED_COUNTERPARTY_DETAIL_ENTITY_ID)
						.build())
				.setLinkedEntityDetail(LinkedEntityDetail.newBuilder()
						.setEntityType(EntityType.ASSET)
						.setEntityId(LINKED_ENTITY_DETAIL_ENTITY_ID))
				.build();
		List<BankOperation> bankOperations = new LinkedList<>();
		bankOperations.add(bankOperation);
		return bankOperations;
	}
	
	public static List<BankOperation> getBankOperationScenarioFailure() {
		BankOperation bankOperation = BankOperation.newBuilder()
				.setBankOperationId(BANK_OPERATION_ID)
				.setCreationDate(TestHelper.getTimestamp())
				.setSettleDate(TestHelper.getTimestamp())
				.setOperationCurrency(CucumberConstantsTransformer.CURRENCY)
				.setAmountOpCurrency(Money.newBuilder()
						.setUnits(AMOUNT_OP_CURRENCY_UNITS).build())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE))
				.setLinkedCounterpartyDetail(LinkedEntityDetail.newBuilder()
						.setEntityType(EntityType.PORTFOLIO)
						.setEntityId(LINKED_COUNTERPARTY_DETAIL_ENTITY_ID)
						.build())
				.setLinkedEntityDetail(LinkedEntityDetail.newBuilder()
						.setEntityType(EntityType.ASSET)
						.setEntityId(LINKED_ENTITY_DETAIL_ENTITY_ID)
						.build())
				.build();
		List<BankOperation> bankOperations = new LinkedList<>();
		bankOperations.add(bankOperation);
		return bankOperations;
	}
	
	public static List<BankOperation> getBankOperationScenarioFailureForRetry() {
		BankOperation bankOperation = BankOperation.newBuilder()
				.setBankOperationId(BANK_OPERATION_ID)
				.setCreationDate(TestHelper.getTimestamp())
				.setSettleDate(TestHelper.getTimestamp())
				.setOperationCurrency(CucumberConstantsTransformer.CURRENCY)
				.setAmountOpCurrency(Money.newBuilder()
						.setUnits(AMOUNT_OP_CURRENCY_UNITS).build())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE))
				.setLinkedCounterpartyDetail(LinkedEntityDetail.newBuilder()
						.setEntityType(EntityType.PORTFOLIO)
						.setEntityId(LINKED_COUNTERPARTY_DETAIL_ENTITY_ID)
						.setEntityBankAccountId(LINKED_COUNTERPARTY_DETAIL_ENTITY_BANK_ACCOUNT_ID)
						.build())
				.setLinkedEntityDetail(LinkedEntityDetail.newBuilder()
						.setEntityType(EntityType.ASSET)
						.setEntityId(LINKED_ENTITY_DETAIL_ENTITY_ID)
						.setEntityBankAccountId(LINKED_ENTITY_DETAIL_ENTITY_BANK_ACCOUNT_ID)
						.build())
				.setIsDebit(true)
				.build();
		List<BankOperation> bankOperations = new LinkedList<>();
		bankOperations.add(bankOperation);
		return bankOperations;
	}
	
	public static List<BankOperation> getBankOperationScenarioEntityInfoFailure() {
		BankOperation bankOperation = BankOperation.newBuilder()
				.setBankOperationId(BANK_OPERATION_ID)
				.setCreationDate(TestHelper.getTimestamp())
				.setSettleDate(TestHelper.getTimestamp())
				.setOperationCurrency(CucumberConstantsTransformer.CURRENCY)
				.setAmountOpCurrency(Money.newBuilder()
						.setUnits(AMOUNT_OP_CURRENCY_UNITS).build())
				.setLinkedCounterpartyDetail(LinkedEntityDetail.newBuilder()
						.setEntityType(EntityType.PORTFOLIO)
						.setEntityId(LINKED_COUNTERPARTY_DETAIL_ENTITY_ID)
						.build())
				.setLinkedEntityDetail(LinkedEntityDetail.newBuilder()
						.setEntityType(EntityType.ASSET)
						.setEntityId(LINKED_ENTITY_DETAIL_ENTITY_ID))
				.build();
		List<BankOperation> bankOperations = new LinkedList<>();
		bankOperations.add(bankOperation);
		return bankOperations;
	}
	
	public static List<BankOperation> getBankOperationScenarioLinkedCounterpartyDetailFailure() {
		BankOperation bankOperation = BankOperation.newBuilder()
				.setBankOperationId(BANK_OPERATION_ID)
				.setCreationDate(TestHelper.getTimestamp())
				.setSettleDate(TestHelper.getTimestamp())
				.setOperationCurrency(CucumberConstantsTransformer.CURRENCY)
				.setAmountOpCurrency(Money.newBuilder()
						.setUnits(AMOUNT_OP_CURRENCY_UNITS).build())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE))
				.setLinkedEntityDetail(LinkedEntityDetail.newBuilder()
						.setEntityType(EntityType.ASSET)
						.setEntityId(LINKED_ENTITY_DETAIL_ENTITY_ID))
				.build();
		List<BankOperation> bankOperations = new LinkedList<>();
		bankOperations.add(bankOperation);
		return bankOperations;
	}
	
	public static List<BankOperation> getBankOperationScenarioLinkedEntityDetailFailure() {
		BankOperation bankOperation = BankOperation.newBuilder()
				.setBankOperationId(BANK_OPERATION_ID)
				.setCreationDate(TestHelper.getTimestamp())
				.setSettleDate(TestHelper.getTimestamp())
				.setOperationCurrency(CucumberConstantsTransformer.CURRENCY)
				.setAmountOpCurrency(Money.newBuilder()
						.setUnits(AMOUNT_OP_CURRENCY_UNITS).build())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE))
				.setLinkedCounterpartyDetail(LinkedEntityDetail.newBuilder()
						.setEntityType(EntityType.PORTFOLIO)
						.setEntityId(LINKED_COUNTERPARTY_DETAIL_ENTITY_ID)
						.build())
				.build();
		List<BankOperation> bankOperations = new LinkedList<>();
		bankOperations.add(bankOperation);
		return bankOperations;
	}
	
	public static List<BankOperationResponse> getBankOperationResponse(BankOperationTransformerService service, List<BankOperation> bankOperations) {
		return service.transformLoadEntities(bankOperations);
	}
	
	public static List<BankOperationResponse> getBankOperationResponseTransformEntities(BankOperationTransformerService service, List<BankOperation> bankOperations) {
		return service.transformEntities(bankOperations);
	}

}
