package com.bfm.aap.pmdx.transformer.util;

import java.util.LinkedList;
import java.util.List;

import com.bfm.aap.pmdx.model.Instrument;
import com.bfm.aap.pmdx.model.InstrumentDetails;
import com.bfm.aap.pmdx.model.InstrumentResponse;
import com.bfm.aap.pmdx.model.InstrumentSource;
import com.bfm.aap.pmdx.transformer.constants.CucumberConstantsTransformer;
import com.bfm.aap.pmdx.transformer.service.InstrumentTransformerService;

public class CompanySpvTestData {
	
	public static List<Instrument> getCompanySpvInstrumentsScenarioSuccess() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetId(CucumberConstantsTransformer.ASSET_ID)
				.setAssetName(CucumberConstantsTransformer.ASSET_NAME)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE)
				.setIssuer(CucumberConstantsTransformer.ISSUER)
				.setCompanyStatus(CucumberConstantsTransformer.COMPANY_STATUS)
				.setAladdinTicker(CucumberConstantsTransformer.ALADDIN_TICKER)
				.addInstrumentDetails(getInstrumentDetailsForScenarioSuccess())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}
	public static List<Instrument> getInstrumentsScenarioMissingMandatoryArgs() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetName(CucumberConstantsTransformer.ASSET_NAME)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE)
				.setIssuer(CucumberConstantsTransformer.ISSUER)
				.setCompanyStatus(CucumberConstantsTransformer.COMPANY_STATUS)
				.setAladdinTicker(CucumberConstantsTransformer.ALADDIN_TICKER)
				.addInstrumentDetails(getInstrumentDetailsForScenarioSuccess())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}
	public static InstrumentDetails getInstrumentDetailsForScenarioSuccess() {
		return InstrumentDetails.newBuilder()
				.setInstrumentId(CucumberConstantsTransformer.INSTRUMENT_ID)
				.setInstrumentName(CucumberConstantsTransformer.INSTRUMENT_NAME)
				.setInstrumentClass(CucumberConstantsTransformer.INSTRUMENT_CLASS)
				.setInstrumentType(CucumberConstantsTransformer.INSTRUMENT_TYPE)
				.setInstrumentCurrency(CucumberConstantsTransformer.CURRENCY)
				.setInstrumentDomicile(CucumberConstantsTransformer.DOMICILE)
				.setCapitalStructure(CucumberConstantsTransformer.CAPITAL_STRUCTURE_DEBT)
				.setCusip(CucumberConstantsTransformer.VALID_CUSIP_RDDANMKE2)
				.setSecGroup(CucumberConstantsTransformer.SEC_GROUP_EQUITY)
				.setSecType(CucumberConstantsTransformer.SEC_TYPE_PRIVATE)
				.setReviewedBy(CucumberConstantsTransformer.REVIEWED_BY)
				.setSecDesc2(CucumberConstantsTransformer.SEC_DESC_2)
				.setMtnFlag(CucumberConstantsTransformer.MTN)
				.setNotionalFlag(CucumberConstantsTransformer.NOTIONAL_FLAG)
				.setInstrumentSource(InstrumentSource.COMPANY)
				.setDealStructuringId(CucumberConstantsTransformer.XX)
				.setAladdinInstrumentType(CucumberConstantsTransformer.SEC_GROUP_EQUITY + "/"
						+ CucumberConstantsTransformer.SEC_TYPE_PRIVATE)
				.build();
	}
	public static List<Instrument> getInstrumentsScenarioMissingInstrumentDetails() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetId(CucumberConstantsTransformer.ASSET_ID)
				.setAssetName(CucumberConstantsTransformer.ASSET_NAME)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE)
				.setIssuer(CucumberConstantsTransformer.ISSUER)
				.setCompanyStatus(CucumberConstantsTransformer.COMPANY_STATUS)
				.setAladdinTicker(CucumberConstantsTransformer.ALADDIN_TICKER)
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}
	
	public static List<Instrument> getInstrumentsScenarioSuccessValidSecGroupLoanAndValidSecTypeTerm() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetId(CucumberConstantsTransformer.ASSET_ID)
				.setAssetName(CucumberConstantsTransformer.ASSET_NAME)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE)
				.setIssuer(CucumberConstantsTransformer.ISSUER)
				.setCompanyStatus(CucumberConstantsTransformer.COMPANY_STATUS)
				.setAladdinTicker(CucumberConstantsTransformer.ALADDIN_TICKER)
				.addInstrumentDetails(getInstrumentsDetailsForSecGroupAndSecType(CucumberConstantsTransformer.SEC_GROUP_LOAN, CucumberConstantsTransformer.SEC_TYPE_TERM))
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}
	public static List<Instrument> getInstrumentsScenarioSuccessValidSecGroupEquityAndValidSecTypePrivate() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetId(CucumberConstantsTransformer.ASSET_ID)
				.setAssetName(CucumberConstantsTransformer.ASSET_NAME)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE)
				.setIssuer(CucumberConstantsTransformer.ISSUER)
				.setCompanyStatus(CucumberConstantsTransformer.COMPANY_STATUS)
				.setAladdinTicker(CucumberConstantsTransformer.ALADDIN_TICKER)
				.addInstrumentDetails(getInstrumentsDetailsForSecGroupAndSecType(CucumberConstantsTransformer.SEC_GROUP_EQUITY, CucumberConstantsTransformer.SEC_TYPE_PRIVATE))
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}
	public static List<Instrument> getInstrumentsScenarioSuccessValidSecGroupEquityAndValidSecTypeWarrant() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetId(CucumberConstantsTransformer.ASSET_ID)
				.setAssetName(CucumberConstantsTransformer.ASSET_NAME)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE)
				.setIssuer(CucumberConstantsTransformer.ISSUER)
				.setCompanyStatus(CucumberConstantsTransformer.COMPANY_STATUS)
				.setAladdinTicker(CucumberConstantsTransformer.ALADDIN_TICKER)
				.addInstrumentDetails(getInstrumentsDetailsForSecGroupAndSecType(CucumberConstantsTransformer.SEC_GROUP_EQUITY, CucumberConstantsTransformer.SEC_TYPE_WARRANT))
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}
	public static List<Instrument> getInstrumentsWithInvalidSecGroupSecType() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetId(CucumberConstantsTransformer.ASSET_ID)
				.setAssetName(CucumberConstantsTransformer.ASSET_NAME)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE)
				.setCurrency(CucumberConstantsTransformer.CURRENCY)
				.setCompanyStatus(CucumberConstantsTransformer.COMPANY_STATUS)
				.setAladdinTicker(CucumberConstantsTransformer.ALADDIN_TICKER)
				.addInstrumentDetails(getDebtDealsInstrumentDetailsWithInvalidSecGroupSecType())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}
	
	public static InstrumentDetails getInstrumentsDetailsForSecGroupAndSecType(String secGroup, String secType) {
		return InstrumentDetails.newBuilder()
				.setInstrumentId(CucumberConstantsTransformer.PRIVATE_EQUITY_INSTRUMENT_ID)
				.setInstrumentName(CucumberConstantsTransformer.INSTRUMENT_NAME)
				.setInstrumentType(CucumberConstantsTransformer.INSTRUMENT_TYPE)
				.setInstrumentCurrency(CucumberConstantsTransformer.CURRENCY)
				.setInstrumentDomicile(CucumberConstantsTransformer.DOMICILE)
				.setCapitalStructure(CucumberConstantsTransformer.CAPITAL_STRUCTURE_EQUITY)
				.setCusip(CucumberConstantsTransformer.VALID_CUSIP_RDDANMKF9)
				.setSecGroup(secGroup)
				.setSecType(secType)
				.setReviewedBy(CucumberConstantsTransformer.REVIEWED_BY)
				.setSecDesc2(CucumberConstantsTransformer.SEC_DESC_2)
				.setMtnFlag(CucumberConstantsTransformer.MTN)
				.setNotionalFlag(CucumberConstantsTransformer.NOTIONAL_FLAG)
				.setInstrumentSource(InstrumentSource.COMPANY)
				.setDealStructuringId(CucumberConstantsTransformer.XX)
				.setAladdinInstrumentType(CucumberConstantsTransformer.SEC_GROUP_EQUITY + "/"
						+ CucumberConstantsTransformer.SEC_TYPE_PRIVATE)
				.build();
	}
	
	public static InstrumentDetails getDebtDealsInstrumentDetailsWithInvalidSecGroupSecType() {
		return InstrumentDetails.newBuilder().setInstrumentId(CucumberConstantsTransformer.XX)
				.setInstrumentName(CucumberConstantsTransformer.INSTRUMENT_NAME)
				.setInstrumentClass(CucumberConstantsTransformer.INSTRUMENT_CLASS)
				.setInstrumentType(CucumberConstantsTransformer.INSTRUMENT_TYPE)
				.setInstrumentCurrency(CucumberConstantsTransformer.CURRENCY)
				.setInstrumentDomicile(CucumberConstantsTransformer.DOMICILE)
				.setCapitalStructure(CucumberConstantsTransformer.CAPITAL_STRUCTURE_DEBT)
				.setCusip(CucumberConstantsTransformer.VALID_CUSIP_RDDANMKE2)
				.setSecGroup(CucumberConstantsTransformer.SEC_GROUP_FUND)
				.setSecType(CucumberConstantsTransformer.SEC_TYPE_PRIVATE)
				.setReviewedBy(CucumberConstantsTransformer.REVIEWED_BY)
				.setSecDesc2(CucumberConstantsTransformer.SEC_DESC_2)
				.setMtnFlag(CucumberConstantsTransformer.MTN)
				.setNotionalFlag(CucumberConstantsTransformer.NOTIONAL_FLAG)
				.setInstrumentSource(InstrumentSource.DEAL)
				.setDealStructuringId(CucumberConstantsTransformer.DEAL_STRUCTURING_ID)
				.setAladdinInstrumentType(CucumberConstantsTransformer.SEC_GROUP_FUND + "/"
						+ CucumberConstantsTransformer.SEC_TYPE_PRIVATE)
				.build();
	}
	
	public static List<Instrument> getCompanyInstrumentWithoutInstrumentId() {
		Instrument instrument = InstrumentTestData.getInstrumentProto()
				.setAssetId(CucumberConstantsTransformer.ASSET_ID)
				.setAssetName(CucumberConstantsTransformer.ASSET_NAME)
				.setAssetType(CucumberConstantsTransformer.VALID_ASSET_TYPE)
				.setDomicile(CucumberConstantsTransformer.DOMICILE)
				.setIssuer(CucumberConstantsTransformer.ISSUER)
				.setCompanyStatus(CucumberConstantsTransformer.COMPANY_STATUS)
				.setAladdinTicker(CucumberConstantsTransformer.ALADDIN_TICKER)
				.addInstrumentDetails(getInstrumentDetailsWithoutInstrumentId())
				.setEntityInfo(TestHelper.getEntityInfo(CucumberConstantsTransformer.CURRENT_NETWORK_MODE).build())
				.build();
		List<Instrument> instruments = new LinkedList<>();
		instruments.add(instrument);
		return instruments;
	}
	public static InstrumentDetails getInstrumentDetailsWithoutInstrumentId() {
		return InstrumentDetails.newBuilder().setInstrumentName(CucumberConstantsTransformer.INSTRUMENT_NAME)
				.setInstrumentClass(CucumberConstantsTransformer.INSTRUMENT_CLASS)
				.setInstrumentType(CucumberConstantsTransformer.INSTRUMENT_TYPE)
				.setInstrumentCurrency(CucumberConstantsTransformer.CURRENCY)
				.setInstrumentDomicile(CucumberConstantsTransformer.DOMICILE)
				.setCapitalStructure(CucumberConstantsTransformer.CAPITAL_STRUCTURE_DEBT)
				.setCusip(CucumberConstantsTransformer.VALID_CUSIP_RDDANMKE2)
				.setSecGroup(CucumberConstantsTransformer.SEC_GROUP_EQUITY)
				.setSecType(CucumberConstantsTransformer.SEC_TYPE_PRIVATE)
				.setReviewedBy(CucumberConstantsTransformer.REVIEWED_BY)
				.setSecDesc2(CucumberConstantsTransformer.SEC_DESC_2).setMtnFlag(CucumberConstantsTransformer.MTN)
				.setNotionalFlag(CucumberConstantsTransformer.NOTIONAL_FLAG)
				.setInstrumentSource(InstrumentSource.COMPANY).setDealStructuringId(CucumberConstantsTransformer.XX)
				.setAladdinInstrumentType(CucumberConstantsTransformer.SEC_GROUP_EQUITY + "/"
						+ CucumberConstantsTransformer.SEC_TYPE_PRIVATE)
				.build();
	}
	
	
	public static List<InstrumentResponse> getCompantSpvInstrumentResponse(InstrumentTransformerService service,
			List<Instrument> instruments) {
		List<InstrumentResponse> response = service.transformLoadEntities(instruments);
		return response;
	}

}
