package com.bfm.aap.pmdx.transformer.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import com.bfm.aap.pmdx.model.CompanyResponse;

public class CRMCompanyAssertionUtility {

	private static final String EMPTY_REQUEST_RECEIVED = "Empty request received";

	public static void assertFailureResponse_transformLoadGuids(List<CompanyResponse> response) {
		assertEquals(1, response.size());
		assertFalse(response.get(0).getSuccess());
		assertEquals(EMPTY_REQUEST_RECEIVED, response.get(0).getMessage());
	}

	public static void assertSuccessResponse_transformLoadEntities(List<CompanyResponse> response) {
		assertEquals(1, response.size());
		assertTrue(response.get(0).getSuccess());
	}

	public static void assertFailureResponse_transformLoadEntities_empty(List<CompanyResponse> response) {
		assertEquals(1, response.size());
		assertFalse(response.get(0).getSuccess());
		assertEquals(EMPTY_REQUEST_RECEIVED, response.get(0).getMessage());
	}

	public static void assertSuccessResponse_transformEntities(List<CompanyResponse> response) {
		assertEquals(1, response.size());
		assertTrue(response.get(0).getSuccess());
	}

	public static void assertFailureResponse_transformEntities_empty(List<CompanyResponse> response) {
		assertEquals(1, response.size());
		assertFalse(response.get(0).getSuccess());
		assertEquals(EMPTY_REQUEST_RECEIVED, response.get(0).getMessage());
	}

	public static void assertFailureResponse_transformEntities(List<CompanyResponse> response) {
		assertEquals(1, response.size());
		assertFalse(response.get(0).getSuccess());
	}
}
