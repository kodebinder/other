package com.bfm.aap.pmdx.transformer.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bfm.aap.pmdx.model.PerformanceResponse;
import com.bfm.aap.pmdx.redblue.PmdxServiceType;
import com.bfm.aap.pmdx.transformer.constants.CucumberConstantsTransformer;
import com.bfm.aap.pmdx.transformer.util.PerformanceTestData;
import com.bfm.aap.pmdx.transformer.util.TestHelper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import io.cucumber.java8.En;

public class PrivateMarketsDXTransformerPerformanceStepDefinition implements En{

	private static final Logger LOGGER = LoggerFactory.getLogger(PrivateMarketsDXTransformerPerformanceStepDefinition.class);
	private List<PerformanceResponse> performanceResponse;

	PrivateMarketsDXTransformerPerformanceStepDefinition() {

		Given("user {string} wants to transform a performance", (String user) -> {
			LOGGER.info("User : {}",user);
		});

		When("user sends performance proto to server", () -> {
			performanceResponse = PerformanceTestData.getPerformanceResponse(getPerformanceTransformerService(),PerformanceTestData.getPerformanceScenarioSuccess());
			printResponse(performanceResponse);
		});
		
		Then("performence should be created", () -> {
			assertSuccessResponse();
		});

		When("user sends performance proto to server without AsOfDate", () -> {
			performanceResponse = PerformanceTestData.getPerformanceResponse(getPerformanceTransformerService(),PerformanceTestData.getPerformanceScenarioFailure());
			printResponse(performanceResponse);
		});
		
		Then("performence should be not be created", () -> {
			assertFailureResponse();
		});
		
		When("user sends performance proto to server without EntityInfo", () -> {
			performanceResponse = PerformanceTestData.getPerformanceResponse(getPerformanceTransformerService(),PerformanceTestData.getPerformanceScenarioEntityInfoFailure());
			printResponse(performanceResponse);
		});
		
		When("user sends performance proto to server for transformEntities API", () -> {
			performanceResponse = PerformanceTestData.getPerformancetransformEntitiesResponse(getPerformanceTransformerService(),PerformanceTestData.getPerformanceScenarioSuccess());
			printResponse(performanceResponse);
		});
		
		When("user sends performance proto to server without AsOfDate for transformEntities API", () -> {
			performanceResponse = PerformanceTestData.getPerformancetransformEntitiesResponse(getPerformanceTransformerService(),PerformanceTestData.getPerformanceScenarioFailure());
			printResponse(performanceResponse);
		});
		
		When("user sends performance proto to server without EntityInfo for transformEntities API", () -> {
			performanceResponse = PerformanceTestData.getPerformancetransformEntitiesResponse(getPerformanceTransformerService(),PerformanceTestData.getPerformanceScenarioEntityInfoFailure());
			printResponse(performanceResponse);
		});
	}

	private void printResponse(List<PerformanceResponse> performanceResponses) {
		Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().create();
		System.out.println(gson.toJson(performanceResponses));
		LOGGER.info("List of PerformanceResponses : {}",(gson.toJson(performanceResponses)));
	}
	
	private void assertSuccessResponse() {
		String message = performanceResponse.get(0).getMessage();
		assertEquals(true,message.length()>0);
	}
	
	private void assertFailureResponse() {
		boolean success = performanceResponse.get(0).getSuccess();
		assertEquals(false, success);
	}
	
	private PerformanceTransformerService getPerformanceTransformerService() {
		return TestHelper.getEntityTransformerBeam2Service(PerformanceTransformerService.class, 
				PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_PERFORMANCE, 
				CucumberConstantsTransformer.CURRENT_NETWORK_MODE);
	}

}
