package com.bfm.aap.pmdx.transformer.constants;

import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.transformer.util.TestHelper;

/**
 * Constants file specific to cucumber test case
 */
public final class CucumberConstantsTransformer {
	private CucumberConstantsTransformer() {
	}

	/**
	 * Constants for Asset plug-in
	 */
	public static final String ASSET_NAME = "Test company asset name 1";
	public static final String ASSET_ID = "BE9BDB3099604B56BFCDFC6A807F9996ASSET";
	public static final String PRIVATE_EQUITY_ASSET_ID = "BE9BDB3099604B56BFCDFC6A807F9996ASSET1";
	public static final String VALID_ASSET_TYPE = "FUND";
	public static final String INVALID_ASSET_TYPE = "INVALID_ASSET_TYPE";
	public static final String VALID_CLIENT_NAME = "DEV";
	public static final String INVALID_CLIENT_NAME = "INVALID_CLIENT_NAME";
	public static final String DOMICILE = "US";
	public static final String SEC_GROUP_LOAN = "LOAN";
	public static final String SEC_GROUP_EQUITY = "EQUITY";
	public static final String SEC_GROUP_FUND = "FUND";
	public static final String SEC_TYPE_TERM = "TERM";
	public static final String SEC_TYPE_PRIVATE = "PRIVATE";
	public static final String SEC_TYPE_WARRANT = "WARRANT";
	public static final String CURRENCY = "USD";
	public static final String FLAG_144A = "P";
	public static final String CAPITAL_STRUCTURE_EQUITY = "EQ";
	public static final String CAPITAL_STRUCTURE_DEBT = "DEBT";
	public static final String FUND_NAME = "Ara Strategic Fund IV LP";
	public static final String VINTAGE_YEAR = "2018";
	public static final String FUND_CURRENCY = "USD";
	public static final String MODEL_VERSION = "7.1.1";
	public static final String MANAGEMENT_COMPANY = "F86125D7361844448EEA00B10AAC9996";
	public static final String INVESTMENT_STRUCTURE = "dummy_investment_structure";
	public static final String REVIEWED_BY = "dummy_reviewed_by";
	public static final String MARKET = "US";
	public static final String SEC_DESC_2 = "dummy_sec_desc_2";
	public static final String MTN = "N";
	public static final String NOTIONAL_FLAG = "N";
	public static final String FLAG_ROUND = "N";
	public static final String SETTLE_LOCATION = "N";
	public static final String PMT_LOCATION = "N";
	public static final String BENCHMARK = "dummy_benchmark";
	public static final String PORTFOLIO_TICKER = "AFL";
	public static final String NOTE = "TEST";
	public static final String XX = "XX";
	public static final String FUND_STATUS = "OPEN";
	public static final String SEC_LONG_NAME = "Universal Core Bond";
	public static final double FUND_SIZE = 5300200000.0;
	public static final boolean PRIMARY_DATA = Boolean.TRUE;

	/**
	 * Constants for Instrument plug-in
	 */
	public static final String INSTRUMENT_ID = "INS5A14D5D5C4C9F92E7904B7430001";
	public static final String PRIVATE_EQUITY_INSTRUMENT_ID = "INS5A14D5D5C4C9F92E7904B7430002";
	public static final String WARRANT_EQUITY_INSTRUMENT_ID = "INS5A14D5D5C4C9F92E7904B7430003";
	public static final String DEAL_STRUCTURING_ID = "DEALINS5A14D5D5C4C9F92E7904B743";
	public static final String DEBT_DEAL_STRUCTURING_ID = "DEALINS5A14D5D5C4C9F92E7904B742";
	public static final String INSTRUMENT_NAME = "dummy_instrument";
	public static final String INSTRUMENT_CLASS = "test";
	public static final String INSTRUMENT_TYPE = "Common Equity";
	public static final String DOUBLE_SLASH = "\\";
	public static final String VALID_CUSIP_RDDANMKE2 = "RDDANMKE2";
	public static final String VALID_CUSIP_RDDANMKF9 = "RDDANMKF9";

	/**
	 * Constants for Issuer plug-in
	 */
	public static final String MANAGER_NAME = "Test Manager Name";
	public static final String REGION_ID = "New Mexico (NM)";
	public static final String ISSUER = "BLACKROCK";
	public static final String ISSUER_SHORTNAME = "BLK";
	public static final String WEBSITE = "www.blackrock.com";
	public static final String VALID_ISSUER = "J49795";
	public static final String INVALID_ISSUER = "J4876025";

	/**
	 * Common Constants for all plug-in
	 */
	public static final NetworkMode CURRENT_NETWORK_MODE = TestHelper.getPrimaryNetwork();
	
	/**
	 * Error Message
	 */
	public static final String EXP_MSG_INVEST_INSTRUMENT_VALID_FAIL = "Exception message: INVEST: DEV: Instrument Validation failed. Basic validation failure: [instrumentDetails[0].dealStructuringId: is missing but it is required, instrumentDetails[0].instrumentSource: is missing but it is required, instrumentDetails[0].aladdinInstrumentType: is missing but it is required]Basic validation warning: [INS5A14D5D5C4C9F92E7904B7430001instrumentDetails[0].dealStructuringId: is missing but it is required, INS5A14D5D5C4C9F92E7904B7430001instrumentDetails[0].instrumentSource: is missing but it is required, INS5A14D5D5C4C9F92E7904B7430001instrumentDetails[0].aladdinInstrumentType: is missing but it is required]";
	public static final String EXP_MSG_INVEST_INSTRUMENT_ASSETID_VALID_FAIL = "Exception message: INVEST: DEV: Instrument Validation failed. Basic validation failure: [assetId: is missing but it is required, instrumentDetails[0].dealStructuringId: is missing but it is required, instrumentDetails[0].instrumentSource: is missing but it is required, instrumentDetails[0].aladdinInstrumentType: is missing but it is required]Basic validation warning: [INS5A14D5D5C4C9F92E7904B7430001instrumentDetails[0].dealStructuringId: is missing but it is required, INS5A14D5D5C4C9F92E7904B7430001instrumentDetails[0].instrumentSource: is missing but it is required, INS5A14D5D5C4C9F92E7904B7430001instrumentDetails[0].aladdinInstrumentType: is missing but it is required]";
	public static final String EXP_MSG_DECODE_INSTRUMENT_DOMICILE_VALID_FAIL = "Decode validation warning: [instrumentDomicile | received Value = '\\']";
	public static final String EXP_MSG_ALL_REQ_FAILED = "Exception message: All of the requests failed";
	
	/**
	 * Common Constants for Company SPV
	 */
	public static final String COMPANY_STATUS = "COMPANYSPV";
	public static final String ALADDIN_TICKER = "CSPV002";

}
