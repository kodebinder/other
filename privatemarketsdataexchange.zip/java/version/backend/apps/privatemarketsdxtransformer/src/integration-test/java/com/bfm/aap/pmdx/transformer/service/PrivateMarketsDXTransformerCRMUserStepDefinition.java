package com.bfm.aap.pmdx.transformer.service;

import static org.junit.Assert.assertNotNull;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bfm.aap.pmdx.model.User;
import com.bfm.aap.pmdx.model.UserResponse;
import com.bfm.aap.pmdx.plugin.crm.config.CRMConfig;
import com.bfm.aap.pmdx.plugin.crm.service.UserBeam2Service;
import com.bfm.aap.pmdx.plugin.crm.service.UserETLService;
import com.bfm.aap.pmdx.transformer.util.CRMUserAssertionUtility;
import com.bfm.aap.pmdx.transformer.util.CRMUserTestData;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import cucumber.api.java8.En;

@SuppressWarnings("deprecation")
public class PrivateMarketsDXTransformerCRMUserStepDefinition implements En {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(PrivateMarketsDXTransformerCRMUserStepDefinition.class);

	@Autowired
	private CRMConfig crmConfig;
	@Autowired
	private UserETLService userETLService;
	private UserBeam2Service userBeam2Service;
	
	private Collection<User> user_transformLoadEntities_api = new LinkedList<>();
	private Collection<User> user_transformEntities_api_success = new LinkedList<>();
	private Collection<User> user_transformEntities_api_fail_missing_mandatory_fields = new LinkedList<>();
	private Collection<User> user_transformEntities_api_fail_missing_userId_field = new LinkedList<>();
	private Collection<User> user_transformEntities_api_fail_missing_name_field = new LinkedList<>();
	private Collection<User> user_transformEntities_api_fail_missing_email_field = new LinkedList<>();
	
	List<UserResponse> transformLoadGuids_response_null_data;
	List<UserResponse> transformLoadGuids_response_empty_data;
	List<UserResponse> transformLoadEntities_response_success;
	List<UserResponse> transformLoadEntities_response_null_data;
	List<UserResponse> transformLoadEntities_response_empty_data;
	List<UserResponse> transformEntities_response_success;
	List<UserResponse> transformEntities_response_null_data;
	List<UserResponse> transformEntities_response_empty_data;
	List<UserResponse> transformEntities_response_missing_mandatory_fields;
	List<UserResponse> transformEntities_response_missing_userId_field;
	List<UserResponse> transformEntities_response_missing_name_field;
	List<UserResponse> transformEntities_response_missing_email_field;
	
	public PrivateMarketsDXTransformerCRMUserStepDefinition() {

		Given("user {string} wants to transform an user", (String user) -> {
			LOGGER.info("User : {}", user);
		});
		
		When("user sends user request to PrivateMarketsDXTransformer", () -> {
			userBeam2Service = crmConfig.getUserBeam2Service(userETLService);
			assertNotNull(userBeam2Service);
		});

		When("user sends invalid user proto with null data to server for transformLoadGuids api", () -> {
			transformLoadGuids_response_null_data = userBeam2Service.transformLoadGuids(null);
			printResponse(transformLoadGuids_response_null_data);
		});

		Then("user transformation unsuccessful due to null data for transformLoadGuids api", () -> {
			CRMUserAssertionUtility.assertFailureResponse_transformLoadGuids(transformLoadGuids_response_null_data);
		});
		
		When("user sends invalid user proto with empty collection of guids data to server for transformLoadGuids api", () -> {
			transformLoadGuids_response_empty_data = userBeam2Service.transformLoadGuids(Collections.emptyList());
			printResponse(transformLoadGuids_response_empty_data);
		});

		Then("user transformation unsuccessful due to empty collection of guid for transformLoadGuids api", () -> {
			CRMUserAssertionUtility.assertFailureResponse_transformLoadGuids(transformLoadGuids_response_empty_data);
		});
		
		When("user sends valid user proto data to server for transformLoadEntities api", () -> {
			user_transformLoadEntities_api.add(CRMUserTestData.getUser());
			transformLoadEntities_response_success = userBeam2Service.transformLoadEntities(user_transformLoadEntities_api);
			printResponse(transformLoadEntities_response_success);
		});

		Then("user transformation successful for transformLoadEntities api", () -> {
			CRMUserAssertionUtility.assertSuccessResponse_transformLoadEntities(transformLoadEntities_response_success);
		});
		
		When("user sends invalid user proto with null data to server for transformLoadEntities api", () -> {
			transformLoadEntities_response_null_data = userBeam2Service.transformLoadEntities(null);
			printResponse(transformLoadEntities_response_null_data);
		});

		Then("user transformation unsuccessful due to null data for transformLoadEntities api", () -> {
			CRMUserAssertionUtility.assertFailureResponse_transformLoadEntities_empty(transformLoadEntities_response_null_data);
		});
		
		When("user sends invalid user proto with empty collection of user entities data to server for transformLoadEntities api", () -> {
			transformLoadEntities_response_empty_data = userBeam2Service.transformLoadEntities(Collections.emptyList());
			printResponse(transformLoadEntities_response_empty_data);
		});

		Then("user transformation unsuccessful due to empty collection of user entities for transformLoadEntities api", () -> {
			CRMUserAssertionUtility.assertFailureResponse_transformLoadEntities_empty(transformLoadEntities_response_empty_data);
		});
		
		When("user sends valid user proto with all mandatory field data to server for transformEntities api", () -> {
			user_transformEntities_api_success.add(CRMUserTestData.getUser());
			transformEntities_response_success = userBeam2Service.transformEntities(user_transformEntities_api_success);
			printResponse(transformEntities_response_success);
		});

		Then("user transformation successful for transformEntities api", () -> {
			CRMUserAssertionUtility.assertSuccessResponse_transformEntities(transformEntities_response_success);
		});
		
		When("user sends invalid user proto with null data to server for transformEntities api", () -> {
			transformEntities_response_null_data = userBeam2Service.transformEntities(null);
			printResponse(transformEntities_response_null_data);
		});

		Then("user transformation unsuccessful due to null data for transformEntities api", () -> {
			CRMUserAssertionUtility.assertFailureResponse_transformEntities_empty(transformEntities_response_null_data);
		});
		
		When("user sends invalid user proto with empty collection of user entities data to server for transformEntities api", () -> {
			transformEntities_response_empty_data = userBeam2Service.transformEntities(Collections.emptyList());
			printResponse(transformEntities_response_empty_data);
		});

		Then("user transformation unsuccessful due to empty collection of user entities for transformEntities api", () -> {
			CRMUserAssertionUtility.assertFailureResponse_transformEntities_empty(transformEntities_response_empty_data);
		});
		
		When("user sends invalid user proto with missing mandatory fields data to server for transformEntities api", () -> {
			user_transformEntities_api_fail_missing_mandatory_fields.add(CRMUserTestData.getUser_fail());
			transformEntities_response_missing_mandatory_fields = userBeam2Service.transformEntities(user_transformEntities_api_fail_missing_mandatory_fields);
			printResponse(transformEntities_response_missing_mandatory_fields);
		});

		Then("user transformation unsuccessful due to missing mandatory fields for transformEntities api", () -> {
			CRMUserAssertionUtility.assertFailureResponse_transformEntities(transformEntities_response_missing_mandatory_fields);
		});
		
		When("user sends invalid user proto with missing userId field data to server for transformEntities api", () -> {
			user_transformEntities_api_fail_missing_userId_field.add(CRMUserTestData.getUser_fail_missing_userId());
			transformEntities_response_missing_userId_field = userBeam2Service.transformEntities(user_transformEntities_api_fail_missing_userId_field);
			printResponse(transformEntities_response_missing_userId_field);
		});

		Then("user transformation unsuccessful due to missing userId field for transformEntities api", () -> {
			CRMUserAssertionUtility.assertFailureResponse_transformEntities(transformEntities_response_missing_userId_field);
		});
		
		When("user sends invalid user proto with missing name field data to server for transformEntities api", () -> {
			user_transformEntities_api_fail_missing_name_field.add(CRMUserTestData.getUser_fail_missing_name());
			transformEntities_response_missing_name_field = userBeam2Service.transformEntities(user_transformEntities_api_fail_missing_name_field);
			printResponse(transformEntities_response_missing_name_field);
		});

		Then("user transformation unsuccessful due to missing name field for transformEntities api", () -> {
			CRMUserAssertionUtility.assertFailureResponse_transformEntities(transformEntities_response_missing_name_field);
		});
		
		When("user sends invalid user proto with missing email field data to server for transformEntities api", () -> {
			user_transformEntities_api_fail_missing_email_field.add(CRMUserTestData.getUser_fail_missing_email());
			transformEntities_response_missing_email_field = userBeam2Service.transformEntities(user_transformEntities_api_fail_missing_email_field);
			printResponse(transformEntities_response_missing_email_field);
		});

		Then("user transformation unsuccessful due to missing email field for transformEntities api", () -> {
			CRMUserAssertionUtility.assertFailureResponse_transformEntities(transformEntities_response_missing_email_field);
		});

	}
	
		private void printResponse(List<UserResponse> response) {
			Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().create();
			LOGGER.info("List of UserResponse : {}", (gson.toJson(response)));
		}
		
}
