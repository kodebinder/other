package com.bfm.aap.pmdx.transformer;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.test.context.ContextConfiguration;

import com.bfm.aap.pmdx.plugin.crm.config.CRMConfig;
import com.bfm.aap.pmdx.transformer.util.TestHelper;

@ContextConfiguration(classes = BaseIT.TestConfiguration.class)
public class BaseIT {

	@Configuration
	@ComponentScan({
        "com.bfm.aap.pmdx.logmetrics",
        "com.bfm.aap.privatemarkets.common",
        "com.bfm.aap.privatemarkets.datadictionary",
        "com.bfm.aap.privatemarkets.decode",
        "com.bfm.aap.pmdx.api",
        "com.bfm.aap.pmdx.model",
        "com.bfm.aap.pmdx.transformer.dao",
        "com.bfm.aap.pmdx.transformer.util",
        "com.bfm.aap.pmdx.validate",
        "com.bfm.aap.privatemarkets.dao",
        "com.bfm.aap.privatemarkets.permission"
	})
	@Import({
	    CRMConfig.class
	})
	@EnableAspectJAutoProxy(proxyTargetClass=true)
	@PropertySource(value = { "classpath:PrivateMarketsDXTransformer.properties" }, ignoreResourceNotFound = true)
	public static class TestConfiguration {

		static {
			System.setProperty("BRS.DISABLE_SSL_ALL", "true");
			System.setProperty("applicationName", "PrivateMarketsDXTransformer");
			System.setProperty("defaultWebServer", "https://dev.blackrock.com");
			System.setProperty("AUTH_METHOD", "SERVER");
			System.setProperty("bms.port", "5000");
			System.setProperty("mode", TestHelper.getPrimaryNetwork().name());
			System.setProperty("writeAccess", "true");
			System.setProperty("BRS.STAT_COLLECTOR_BASE_URL", "http://devcxsl001:60026/");
			System.setProperty("BRS.ADL_DEFAULT_LOCATION_ON_FAILURE", "EWD");
			System.setProperty("BRS.ADL_CONFIG_DIR", "/usr/local/bfm/std/adl");
			System.setProperty("BRS.ADL_TOPOLOGY_CONFIG", "/usr/local/bfm/std/adl/adlClusterTopology.cfg");
			System.setProperty("BRS.brs_root","/usr/local/bfm");
			System.setProperty("BRS.brs_uat","/usr/local/bfm/brs_uat");
			System.setProperty("BRS.brs_std","/usr/local/bfm/brs_std");
			System.setProperty("telemetry", "false");
			System.setProperty("EFRONT_DXPROVIDER_HOST", "10.50.195.78");
			System.setProperty("EFRONT_DXPROVIDER_PORT", "50052");
			System.setProperty("credentials-directory-pattern", "");
			System.setProperty("BRS.PMDX_BASE_DIR_BLUE", "/usr/local/bfm/apps/privatemarketsdataexchange/blue");
			System.setProperty("BRS.PMDX_BASE_DIR_RED", "/usr/local/bfm/apps/privatemarketsdataexchange/red");
			System.setProperty("spring.config.location", "classpath:PrivateMarketsDXTransformer.properties");
			System.setProperty("properties", "classpath:PrivateMarketsDXTransformer.properties");
		}

		@Bean
		public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
			return new PropertySourcesPlaceholderConfigurer();
		}
	}
}