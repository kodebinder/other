package com.bfm.aap.pmdx.transformer.service;

import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bfm.aap.pmdx.model.PositionResponse;
import com.bfm.aap.pmdx.redblue.PmdxServiceType;
import com.bfm.aap.pmdx.transformer.constants.CucumberConstantsTransformer;
import com.bfm.aap.pmdx.transformer.util.PositionTestData;
import com.bfm.aap.pmdx.transformer.util.TestHelper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import io.cucumber.java8.En;

public class PrivateMarketsDXTransformerPositionStepDefinition implements En {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(PrivateMarketsDXTransformerPositionStepDefinition.class);
	private List<PositionResponse> positionResponses;

	PrivateMarketsDXTransformerPositionStepDefinition() {

		Given("user {string} wants to transform a position", (String user) -> {
			LOGGER.info("User : {}", user);
		});

		When("user sends position proto with valid data to server", () -> {
			positionResponses = getPositionTransformerService()
					.transformLoadEntities(Collections.singletonList(PositionTestData.getPositionWithValidData()));
			printResponse(positionResponses);
		});

		Then("position should be transformed", () -> {
			boolean success = positionResponses.get(0).getSuccess();
			String errorMessage = positionResponses.get(0).getMessage();
			assertTrue(success);
			assertEquals(0, errorMessage.length());
		});

		When("user sends position proto having invalid asset guid to server", () -> {
			positionResponses = getPositionTransformerService().transformLoadEntities(
					Collections.singletonList(PositionTestData.getPositionWithInvalidAssetGuid()));
			printResponse(positionResponses);
		});

		Then("we get a validation failed for invalid asset guid", () -> {
			boolean success = positionResponses.get(0).getSuccess();
			String errorMessage = positionResponses.get(0).getMessage();
			assertEquals(false, success);
			assertNotEquals(0, errorMessage.length());
		});

		When("user sends position proto without Investement Id to server", () -> {
			positionResponses = getPositionTransformerService().transformLoadEntities(
					Collections.singletonList(PositionTestData.getPositionWithInvalidInvestmentId()));
			printResponse(positionResponses);
		});

		Then("we get a validation failed for Investement Id missing", () -> {
			boolean success = positionResponses.get(0).getSuccess();
			String errorMessage = positionResponses.get(0).getMessage();
			assertEquals(false, success);
			assertNotEquals(0, errorMessage.length());
		});

		When("user sends position proto without Investor Currency to server", () -> {
			positionResponses = getPositionTransformerService().transformLoadEntities(
					Collections.singletonList(PositionTestData.getPositionWithoutInvestorCurrency()));
			printResponse(positionResponses);
		});

		Then("we get a validation failed for Investor Currency missing", () -> {
			boolean success = positionResponses.get(0).getSuccess();
			String errorMessage = positionResponses.get(0).getMessage();
			assertEquals(false, success);
			assertNotEquals(0, errorMessage.length());
		});

		When("user sends a batch of position proto having one invalid position data to server", () -> {
			positionResponses = getPositionTransformerService()
					.transformLoadEntities(PositionTestData.getPositionsListWithOneInvalidPosition());
			printResponse(positionResponses);
		});

		Then("we get a failure message for entire batch failure", () -> {
			boolean success = positionResponses.get(0).getSuccess();
			String errorMessage = positionResponses.get(0).getMessage();
			assertEquals(false, success);
			assertNotEquals(0, errorMessage.length());
		});
	}

	private void printResponse(List<PositionResponse> positionResponses) {
		Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().create();
		System.out.println(gson.toJson(positionResponses));
	}

	private PositionTransformerService getPositionTransformerService() {
		return TestHelper.getEntityTransformerBeam2Service(PositionTransformerService.class,
				PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_POSITION, CucumberConstantsTransformer.CURRENT_NETWORK_MODE);
	}

}
