package com.bfm.aap.pmdx.transformer.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bfm.aap.pmdx.model.BankOperationResponse;
import com.bfm.aap.pmdx.redblue.PmdxServiceType;
import com.bfm.aap.pmdx.transformer.constants.CucumberConstantsTransformer;
import com.bfm.aap.pmdx.transformer.util.BankOperationsTestData;
import com.bfm.aap.pmdx.transformer.util.TestHelper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import io.cucumber.java8.En;

public class PrivateMarketsDXTransformerBankOperationsStepDefinition implements En {

	private static final Logger LOGGER = LoggerFactory.getLogger(PrivateMarketsDXTransformerBankOperationsStepDefinition.class);
	private List<BankOperationResponse> bankOperationResponses;
	
	public PrivateMarketsDXTransformerBankOperationsStepDefinition() {

		Given("user {string} wants to transform a bank operations", (String user) -> {
			LOGGER.info("User : {}",user);
		});

		When("user sends valid bank operations proto to server", () -> {
			bankOperationResponses = BankOperationsTestData.getBankOperationResponse(getBankOperationTransformerService(),BankOperationsTestData.getBankOperationScenarioSuccess());
			printResponse(bankOperationResponses);
		});

		Then("bank operations should be transformed", () -> {
			assertSuccessResponse();
		});
		
		When("user sends bank Operations proto to server for missing broker code", () -> {
			bankOperationResponses = BankOperationsTestData.getBankOperationResponse(getBankOperationTransformerService(),BankOperationsTestData.getBankOperationScenarioFailure());
			printResponse(bankOperationResponses);
		});
		
		Then("we get a enrichment failed for bank Operations", () -> {
			assertFailureResponse();
		});
		
		When("user sends bank Operations proto to server for Retry Logic", () -> {
			bankOperationResponses = BankOperationsTestData.getBankOperationResponse(getBankOperationTransformerService(),BankOperationsTestData.getBankOperationScenarioFailureForRetry());
			printResponse(bankOperationResponses);
		});
		
		Then("Retry Logic working fine for bank Operations", () -> {
			assertFailureResponse();
		});
		
		When("user sends bank Operations proto to server with missing LinkedCounterpartyDetail", () -> {
			bankOperationResponses = BankOperationsTestData.getBankOperationResponse(getBankOperationTransformerService(),BankOperationsTestData.getBankOperationScenarioLinkedCounterpartyDetailFailure());
			printResponse(bankOperationResponses);
		});
		
		Then("we get a writer failure for bank Operations", () -> {
			assertFailureResponse();
		});
		
		When("user sends bank Operations proto to server with missing LinkedEntityDetail", () -> {
			bankOperationResponses = BankOperationsTestData.getBankOperationResponse(getBankOperationTransformerService(),BankOperationsTestData.getBankOperationScenarioLinkedEntityDetailFailure());
			printResponse(bankOperationResponses);
		});
		
		When("user sends valid bank operations proto to server for transformEntities API", () -> {
			bankOperationResponses = BankOperationsTestData.getBankOperationResponseTransformEntities(getBankOperationTransformerService(),BankOperationsTestData.getBankOperationScenarioSuccess());
			printResponse(bankOperationResponses);
		});

		When("user sends bank Operations proto to server for missing broker code for transformEntities API", () -> {
			bankOperationResponses = BankOperationsTestData.getBankOperationResponseTransformEntities(getBankOperationTransformerService(),BankOperationsTestData.getBankOperationScenarioFailure());
			printResponse(bankOperationResponses);
		});
		
		When("user sends bank Operations proto to server with missing LinkedCounterpartyDetail for transformEntities API", () -> {
			bankOperationResponses = BankOperationsTestData.getBankOperationResponseTransformEntities(getBankOperationTransformerService(),BankOperationsTestData.getBankOperationScenarioLinkedCounterpartyDetailFailure());
			printResponse(bankOperationResponses);
		});
		
		When("user sends bank Operations proto to server with missing LinkedEntityDetail for transformEntities API", () -> {
			bankOperationResponses = BankOperationsTestData.getBankOperationResponseTransformEntities(getBankOperationTransformerService(),BankOperationsTestData.getBankOperationScenarioLinkedEntityDetailFailure());
			printResponse(bankOperationResponses);
		});
		
		When("user sends bank Operations proto to server for Retry Logic for transformEntities API", () -> {
			bankOperationResponses = BankOperationsTestData.getBankOperationResponse(getBankOperationTransformerService(),BankOperationsTestData.getBankOperationScenarioFailureForRetry());
			printResponse(bankOperationResponses);
		});

	}

	private void printResponse(List<BankOperationResponse> bankOperationResponse) {
		Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().create();
		LOGGER.info("List of BankOperationResponse : {}",(gson.toJson(bankOperationResponse)));
	}
	
	private void assertSuccessResponse() {
		String message = bankOperationResponses.get(0).getMessage();
		assertEquals(Boolean.TRUE,message.length()>0);
	}
	
	private void assertFailureResponse() {
		boolean success = bankOperationResponses.get(0).getSuccess();
		assertEquals(false, success);
	}
	
	private BankOperationTransformerService getBankOperationTransformerService() {
		return TestHelper.getEntityTransformerBeam2Service(BankOperationTransformerService.class, 
				PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_BANK_OPERATIONS, 
				CucumberConstantsTransformer.CURRENT_NETWORK_MODE);
	}

}
