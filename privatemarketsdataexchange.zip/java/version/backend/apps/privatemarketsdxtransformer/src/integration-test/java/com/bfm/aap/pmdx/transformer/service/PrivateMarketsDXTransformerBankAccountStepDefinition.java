package com.bfm.aap.pmdx.transformer.service;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bfm.aap.pmdx.model.BankAccountResponse;
import com.bfm.aap.pmdx.redblue.PmdxServiceType;
import com.bfm.aap.pmdx.transformer.constants.CucumberConstantsTransformer;
import com.bfm.aap.pmdx.transformer.dao.QuerySybaseForBrokerRouting;
import com.bfm.aap.pmdx.transformer.util.BankAccountTestData;
import com.bfm.aap.pmdx.transformer.util.TestHelper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import io.cucumber.java8.En;

public class PrivateMarketsDXTransformerBankAccountStepDefinition implements En {

	private static final Logger LOGGER = LoggerFactory.getLogger(PrivateMarketsDXTransformerBankAccountStepDefinition.class);
	private List<BankAccountResponse> bankAccountResponses;
	
	public PrivateMarketsDXTransformerBankAccountStepDefinition() {

		Given("user {string} wants to transform a bank account", (String user) -> {
			LOGGER.info("User : {}",user);
		});

		When("user sends valid bank account proto to server", () -> {
			bankAccountResponses = BankAccountTestData.getBankAccountResponse(getBankAccountTransformerService(),BankAccountTestData.getBankAccountScenarioSuccess());
			printResponse(bankAccountResponses);
		});

		Then("bank account should be transformed", () -> {
			assertSuccessResponse();
		});

		When("user sends bank account proto to server with missing LinkedEntityDetail", () -> {
			bankAccountResponses = BankAccountTestData.getBankAccountResponse(getBankAccountTransformerService(),BankAccountTestData.getBankAccountScenarioLinkedEntityDetailFailure());
			printResponse(bankAccountResponses);
		});
		
		Then("we get a enrichment failed for bank account", () -> {
			assertFailureResponse();
		});
		
		When("user sends bank account proto to server for Retry Logic", () -> {
			bankAccountResponses = BankAccountTestData.getBankAccountResponse(getBankAccountTransformerService(),BankAccountTestData.getBankAccountScenarioFailureForRetryLogic());
			printResponse(bankAccountResponses);
		});
		
		Then("Retry Logic Testing successfull for bank account", () -> {
			assertFailureResponse();
		});

		When("user sends bank account proto to server with missing EntityInfoDetail", () -> {
			bankAccountResponses = BankAccountTestData.getBankAccountResponse(getBankAccountTransformerService(),BankAccountTestData.getBankAccountScenarioEntityDetailFailure());
			printResponse(bankAccountResponses);
		});

		Then("we get a writer failure for bank account", () -> {
			assertFailureResponse();
		});

		When("user sends bank account proto to server with missing LinkedEntityDetail and EntityInfoDetail", () -> {
			bankAccountResponses = BankAccountTestData.getBankAccountResponse(getBankAccountTransformerService(),BankAccountTestData.getBankAccountScenarioLinkedEntityDetailAndEntityDetailFailure());
			printResponse(bankAccountResponses);
		});

		Then("we get a enrichment failed for bank account due to IllegalArgumentException", () -> {
			assertFailureResponse();
		});
		
		
		When("user sends valid bank account proto to server for transformEntities API", () -> {
			bankAccountResponses = BankAccountTestData.getBankAccountResponseTransformEntities(getBankAccountTransformerService(),BankAccountTestData.getBankAccountScenarioSuccess());
			printResponse(bankAccountResponses);
		});

		When("user sends bank account proto to server with missing LinkedEntityDetail for transformEntities API", () -> {
			bankAccountResponses = BankAccountTestData.getBankAccountResponseTransformEntities(getBankAccountTransformerService(),BankAccountTestData.getBankAccountScenarioLinkedEntityDetailFailure());
			printResponse(bankAccountResponses);
		});
		
		When("user sends bank account proto to server for Retry Logic for transformEntities API", () -> {
			bankAccountResponses = BankAccountTestData.getBankAccountResponseTransformEntities(getBankAccountTransformerService(),BankAccountTestData.getBankAccountScenarioFailureForRetryLogic());
			printResponse(bankAccountResponses);
		});
		
		When("user sends bank account proto to server with missing EntityInfoDetail for transformEntities API", () -> {
			bankAccountResponses = BankAccountTestData.getBankAccountResponseTransformEntities(getBankAccountTransformerService(),BankAccountTestData.getBankAccountScenarioEntityDetailFailure());
			printResponse(bankAccountResponses);
		});

		When("user sends bank account proto to server with missing LinkedEntityDetail and EntityInfoDetail for transformEntities API", () -> {
			bankAccountResponses = BankAccountTestData.getBankAccountResponseTransformEntities(getBankAccountTransformerService(),BankAccountTestData.getBankAccountScenarioLinkedEntityDetailAndEntityDetailFailure());
			printResponse(bankAccountResponses);
		});

		When("user sends bank account proto to server", () -> {
			bankAccountResponses = BankAccountTestData.getBankAccountResponse(getBankAccountTransformerService(),BankAccountTestData.getBankAccountScenarioLinkedEntityDetailFailure());
			printResponse(bankAccountResponses);
		});

		Then("bank account should fail because of missing bank_aladdin_name", () -> {
			assertFailureResponse();
		});
		
		Then("bank account should have only entry in broker_routing table", () -> {
			assertEquals(1, new QuerySybaseForBrokerRouting().getBrokerRoutingRecords("987B84DDB3D24938B38DAC0FBFA45302").size());
		});
		
		When("user sends valid bank account proto to server with Defunc true", () -> {
			bankAccountResponses = BankAccountTestData.getBankAccountResponse(getBankAccountTransformerService(),BankAccountTestData.getBankAccountDeLinkScenarioSuccess());
			printResponse(bankAccountResponses);
		});

		Then("bank account should be transformed for Defunc true", () -> {
			assertSuccessResponse();
			QuerySybaseForBrokerRouting querySybase = new QuerySybaseForBrokerRouting();
			
			List<Long> externEntityId = querySybase.getExternEntityId(BankAccountTestData.getBankAccountDeLinkScenarioSuccess().get(0).getBankAccount());
			
			List<String> externEntitiesRecords = querySybase.getExternEntitiesRecords("SHAJAN13ED5FF3676760A08BE3E3B0000011", externEntityId.get(0));
			assertTrue(externEntitiesRecords.size() <= 1);
			
			List<String> brokerRoutingRecords = querySybase.getBrokerRoutingRecords("SHAJAN13ED5FF3676760A08BE3E3B0000011");
			assertTrue(brokerRoutingRecords.size() <= 1);
		});
		
		When("user sends valid bank account proto to server for Fund", () -> {
			bankAccountResponses = BankAccountTestData.getBankAccountResponse(getBankAccountTransformerService(),BankAccountTestData.getBankAccountFundScenarioSuccess());
			printResponse(bankAccountResponses);
		});
		
		When("user sends valid bank account proto to server for Investee Fund", () -> {
			bankAccountResponses = BankAccountTestData.getBankAccountResponse(getBankAccountTransformerService(),BankAccountTestData.getBankAccountInvesteeFundScenarioSuccess());
			printResponse(bankAccountResponses);
		});

	}

	private void printResponse(List<BankAccountResponse> bankAccountResponse) {
		Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().create();
		LOGGER.info("List of BankAccountResponse : {}",(gson.toJson(bankAccountResponse)));
	}
	
	private void assertSuccessResponse() {
		boolean message = bankAccountResponses.get(0).getSuccess();
		assertEquals(Boolean.TRUE,message);
	}
	
	private void assertFailureResponse() {
		boolean success = bankAccountResponses.get(0).getSuccess();
		assertEquals(false, success);
	}
	
	private BankAccountTransformerService getBankAccountTransformerService() {
		return TestHelper.getEntityTransformerBeam2Service(BankAccountTransformerService.class, 
				PmdxServiceType.PRIVATEMARKETS_TRANSFORMER_BANK_ACCOUNT, 
				CucumberConstantsTransformer.CURRENT_NETWORK_MODE);
	}

}
