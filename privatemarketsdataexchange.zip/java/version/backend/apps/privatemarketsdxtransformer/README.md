## PrivateMarketsDXTransformer

PrivateMarketsDXTransformer sits in the core of eFront/Aladdin data exchange. It is responsible for reading eFront data, validating, transforming, enriching and writing it into Aladdin.

### Table of contents
* [Getting Started](#getting-started)
* [Dependencies](#dependencies)
* [Workflow](#workflow)
* [Methods](#methods)
* [Endpoints](#endpoints)
* [Quick Start](#quick-start)
* [Deployment](#deployment)

### Getting Started

These instructions will guide you to add functionalities to leverage the different features of this server

#### Overview
Server:
privatemarketsdxtransformer (PrivateMarketsDXTransformer) – Includes 6 libraries

Libraries:
-   pmdx-template – Consists of abstract ETLService class and all Service’s Interfaces
-   pmdx-asset-transformer – Includes pmdx-template library and consists of AssetETLService concrete class and Implementors of required Service’s Interfaces
-   pmdx-portfolio-transformer – Includes pmdx-template library and consists of PortfolioETLService concrete class and Implementors of required Service’s Interfaces
-   pmdx-position-transformer – Includes pmdx-template library and consists of PositionETLService concrete class and Implementors of required Service’s Interfaces
-   pmdx-model – Includes models for FundAsset, Holding, Portfolio and Position
-   pmdx-validator – Includes methods to validate pmdx proto objects with their respective schemas.
-   pmdx-bank-accounts-transformer
-   pmdx-bank-operations-transformer
-   pmdx-crm-transformer
-   pmdx-performance-transformer
-   pmdx-transactions-transformer
-   pmdx-common-transformer

### Dependencies

PrivateMarketsDXTransformer depends on PrivateMarketsDXFileReader for the GUID of the object persisited in ADL
For creation of assets, it depends on PrivateMarketsAssetLoader.
For creation of portfolios, it depends on PortfolioToolkit.jar
For creation of positions, it depends on Position Loader

### BMS Source IDs Reference 
Entity              RED     Blue
ASSET	            79971	79991
BANK_ACCOUNT	    79972	79992
BANK_OPERATIONS	    79973	79993
FUNDAMENTALS	    79974	79994
INSTRUMENTS	        79975	79995
ISSUER	            79976	79996
PERFORMANCE	        79977	79997
PORTFOLIO	        79978	79998
POSITION	        79979	79999
INVESTOR	        79980	80000
COMPANY	            79981	80001
USER	            79982	80002
INVESTOR_ACCOUNT	79983	80003
CONTACT	            79984	80004
SHARE_CLASS 	    79985	80005
TRANSACTION	        79986	80006

### Workflow ###


Once the server starts,PrivateMarketsDXTransformer would fetch the ADL object and domain from ADL, and read pmdxPluginWhitelist.properties from a pre-determined path.
This properties file would contain all the list of plugins to activate.
During the server startup, pmdxPluginWhitelist.properties will be read and stored in cache.
Leveraging of this pmdxPluginWhitelist.properties file from cache will be done in ETLPluginRouter and respective ETLService Implementors will be called like AssetETLService.
If the plugin is not found we will send notification that respective plugin is not available.
**Server start up will check cache is loaded before processing requests.**

The execution will follow the order:

1.    T convert(byte[] pmdxBinaryData)
2.    ETLResponse<T> validateIncoming(T pmdxObject)
3.    ETLResponse<T> transform(T pmdxObject)
4.    ETLResponse<T> enrich(T pmdxObject)
5.    ETLResponse<T> validateOutgoing(T pmdxObject)
6.    void write(T pmdxObject)

### Methods ###

**aap.pmdx.transform.extract.ExtractorService**\
T extract(byte[] pmdxBinaryData)
This menthod will convert the array of bytes into proto object
_Individual Plugins will implement their own convert method_

**aap.pmdx.transform.validate.ValidatorService**\
ETLResponse<T> validate(T pmdxObject)
This executes a json schema validator and can get decodes from the DecodesService/DecodesDao. Exceptions are output to notification lib.

**aap.pmdx.transform.transform.TransformerService**\
ETLResponse<T> transform(IncomingObject)\
This method is for attribute value transformation
_Individual Plugins will implement their own transform method_

**aap.pmdx.transform.enrich.EnricherService**\
ETLResponse<T> enrich(T pmdxObject)\
_Individual Plugins will implement their own enrich method_

**aap.pmdx.transform.load.WriterService**\
void write(T pmdxObject)\
_Individual Plugins will implement their own write method_


### Endpoints
The server will have an endpoint that will be called by BMS message containing an identifier

### Development Environment
Here are the VM arguments that need to be added to the run configurations in your IDE to get the server up locally

```
-DdefaultWebServer=https://dev.blackrock.com
-DAUTH_METHOD=SERVER
-Dbms.port=5000
-Dmode=BLUE
-DBRS.ADL_DEFAULT_LOCATION_ON_FAILURE=EWD
-DBRS.ADL_CONFIG_DIR=X:/build/dev/std/adl
-DBRS.ADL_TOPOLOGY_CONFIG=X:/build/dev/std/adl/adlClusterTopology.cfg
-DBRS.brs_root=X:/brs_root
-DBRS.brs_uat=X:/brs_uat
-DBRS.brs_std=X:/brs_std
-DBRS.build=X:/build
-DBRS.STAT_COLLECTOR_BASE_URL=http://devcxsl001:60026/
-DapplicationName=PrivateMarketsDXTransformer
-DwriteAccess=true
-DBRS.PMDX_BASE_DIR_BLUE=C:/schema_files
-DBRS.PMDX_BASE_DIR_RED=C:/schema_files
-Dspring.profiles.active=asset,portfolio
-DoverrideAssetTransformerSourceId=373963
-Dspring.config.location=file:C:/schema_files/PrivateMarketsDXTransformer.properties
-Denv.name=DEV
 ```

##### Optional
Override BMS Source IDs

```
-DoverrideAssetTransformerSourceId=373963
-DoverrideDXCRMLoaderSourceId=43215
```
### Deployment 