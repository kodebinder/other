package com.bfm.aap.privatemarkets.crm.loader.integration.gateway;

import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;

public interface InvestorProcessingGateway {
    CRMLoaderResponse processMapCRMInvestor(Investor investor);
}
