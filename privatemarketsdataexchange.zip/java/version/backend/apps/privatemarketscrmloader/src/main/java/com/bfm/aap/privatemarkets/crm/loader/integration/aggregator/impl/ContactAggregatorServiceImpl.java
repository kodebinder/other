package com.bfm.aap.privatemarkets.crm.loader.integration.aggregator.impl;

import com.bfm.aap.privatemarkets.common.crm.model.CRMChannelResponseList;
import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMResponseStatusEnum;
import com.bfm.aap.privatemarkets.common.crm.model.EntityType;
import com.bfm.aap.privatemarkets.crm.loader.integration.aggregator.AggregatorService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ContactAggregatorServiceImpl implements AggregatorService {

    @Override
    public CRMLoaderResponse composeEndpointResponse(List<CRMChannelResponseList> responseList) {
        Map<String, CRMChannelResponseList> responseByEntityTypeMap = translateToMap(responseList);
        boolean addressStatusFailed = getStatus(responseByEntityTypeMap, EntityType.ADDRESS.name());
        boolean entityAttributeFailed = getStatus(responseByEntityTypeMap, EntityType.ENTITY_ATTRIBUTE.name());
        boolean electronicAddressFailed = getStatus(responseByEntityTypeMap, EntityType.EMAIL.name());
        boolean relationshipFailed = getStatus(responseByEntityTypeMap, EntityType.CONTACT_COMPANY_REL.name());
        return buildLoaderResponse( electronicAddressFailed, relationshipFailed || entityAttributeFailed || addressStatusFailed);

    }

    private boolean getStatus(Map<String, CRMChannelResponseList> responseByEntityTypeMap, String entityType) {
        return null != responseByEntityTypeMap.get(entityType) && responseByEntityTypeMap.get(entityType).getResponseList()
                .stream().anyMatch(a -> !a.getStatus());
    }

    private CRMLoaderResponse buildLoaderResponse(boolean electronicAddressFailed, boolean otherLinkedEntitiesFailed) {
        CRMLoaderResponse.Builder crmResponseBuilder = CRMLoaderResponse.newBuilder();
        if (electronicAddressFailed) {
            crmResponseBuilder.setStatus(CRMResponseStatusEnum.CORE_ATTRIBUTE_FAIL);
            crmResponseBuilder.setMessage("All linked attributes failed to process");
        } else if (otherLinkedEntitiesFailed) {
            crmResponseBuilder.setStatus(CRMResponseStatusEnum.CORE_ATTRIBUTE_SUCCESS);
            crmResponseBuilder.setMessage("Core attribute succeeded in processing");
        } else {
            crmResponseBuilder.setStatus(CRMResponseStatusEnum.FULL_SUCCESS);
            crmResponseBuilder.setMessage("All entities processed successfully");
        }
        return crmResponseBuilder.build();
    }

    private Map<String, CRMChannelResponseList> translateToMap(List<CRMChannelResponseList> responseList) {
        Map<String, CRMChannelResponseList> responseByEntityTypeMap = new HashMap<>();
        for (CRMChannelResponseList responses : responseList) {
            responseByEntityTypeMap.put(responses.getResponseList().get(0).getEntityType().name(),
                    CRMChannelResponseList.newBuilder().addAllResponse(responses.getResponseList()).build());
        }
        return responseByEntityTypeMap;
    }
}
