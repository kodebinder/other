package com.bfm.aap.privatemarkets.crm.loader.dao.impl;

import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.privatemarkets.crm.loader.dao.ADLRepositoryDAO;
import com.bfm.adl.ADLException;
import com.bfm.adl.ADLObject;
import com.bfm.adl.ADLQuery;
import com.bfm.adl.ADLRepository;
import com.bfm.adl.ADLRepositoryFactory;
import com.bfm.adl.ADLResultSet;
import com.bfm.util.BFMTimestamp;
import com.bfm.util.Interval;

@Repository
public class ADLRepositoryDAOImpl implements ADLRepositoryDAO {

    private static final Logger LOGGER = LoggerFactory.getLogger(ADLRepositoryDAOImpl.class);

    private static final String REPO_NAME = "AlternativesDataWorkspace";
    private static final String APP_NAME = "A4A";
    private static final String DATA_SECONDARY_INDEX = "idxModifiedTime";
    private static final String NETWORK_MODE = "networkMode";
    private static final String SOURCE = "source";
    private static final String ENTITY_TYPE = "entityType";
    private static final String LAST_MODIFIED_TIME = "lastModifiedTime";
    private static final int WINDOW = -600000;

    private ADLRepository edxDataRepository;

    public ADLRepositoryDAOImpl() throws ADLException {
        this.edxDataRepository = ADLRepositoryFactory.init(REPO_NAME, APP_NAME);
    }

    @Override
    @RecordStats(timer = true, counter = true)
    public ADLResultSet<ADLObject> fetchADLRecordInWindow(String source, String serverMode, EntityType entityType) {
        try {
            LOGGER.info("Received request with TimeStamp : {} , current serverMode : {} and entityType : {}", new BFMTimestamp(), serverMode, entityType);

            BFMTimestamp refTime = new BFMTimestamp();
            ADLQuery query = edxDataRepository.createQuery(DATA_SECONDARY_INDEX)
                .addEqualsConstraint(SOURCE, source)
                .addEqualsConstraint(NETWORK_MODE, serverMode)
                .addEqualsConstraint(ENTITY_TYPE, String.valueOf(entityType))
                .addRangeConstraint(LAST_MODIFIED_TIME, refTime.addTime(new Interval(WINDOW, TimeUnit.MILLISECONDS)), refTime);
            return edxDataRepository.get(query);
        } catch (ADLException e) {
            throw new IllegalStateException("Exception while fetching data from ADL Repo", e);
        }
    }

}
