package com.bfm.aap.privatemarkets.crm.loader.integration.service;

import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.privatemarkets.crm.loader.model.UserCRM;
import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMResponseStatusEnum;
import com.bfm.aap.privatemarkets.crm.loader.service.CRMLoaderCoreService;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.entitymaster.dto.contact.ContactSearchDetail;
import com.bfm.util.BFMUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class UserCRMCoreService {
    private static final Logger LOGGER = LoggerFactory.getLogger(UserCRMCoreService.class);
    public static final String CLIENT_ABBREV = "ClientAbbrev";
    public static final String TEST_ENV_NAMES = "DEV,TST,TSTBEN";

    @Autowired
    private CRMLoaderCoreService crmUserLoaderService;
    @Autowired
    private CRMThirdPartyMapperService crmThirdPartyMapperService;

    @RecordStats
    public UserCRM searchContactByEmail(UserCRM user) {
        String userEmail = checkIfPreProd() ? "blktester1+" + user.getUserEmail().replaceFirst("@", "o.o") + "@gmail.com" :
                user.getUserEmail();
        List<ContactSearchDetail> contactSearchDetails = crmUserLoaderService.searchCRMUserEntity(userEmail);
        if (CollectionUtils.isNotEmpty(contactSearchDetails)) {
            user.setRetreivedCRMEntityId(contactSearchDetails.get(0).getEntityId());
        }
        return user;

    }

    private boolean checkIfPreProd() {
        return TEST_ENV_NAMES.contains(StringUtils.defaultString(BFMUtil.getBfmToken(CLIENT_ABBREV), System.getProperty("env.name")));
    }

    @RecordStats
    public UserCRM findCrmEntityId(UserCRM user) {
        user.setCrmEntityId(crmThirdPartyMapperService.lookUp(user.geteFrontId(), ThirdPartyMappingEnum.USER_INVEST));
        return user;
    }

    @RecordStats
    public CRMLoaderResponse createThirdPartyMapping(UserCRM user) {
        String thirdPartyIdentifier = crmThirdPartyMapperService.create(user.geteFrontId(), user.getRetreivedCRMEntityId(), ThirdPartyMappingEnum.USER_INVEST);
        if (StringUtils.isNotBlank(thirdPartyIdentifier))
            user.setCrmEntityId(crmThirdPartyMapperService.lookUp(thirdPartyIdentifier, ThirdPartyMappingEnum.USER_INVEST));
        return buildLoaderResponse(user);
    }

    public CRMLoaderResponse discardingUser(UserCRM user) {
        return CRMLoaderResponse.newBuilder()
            .setMessage(String.format("User already mapped with entity %s", user.getCrmEntityId()))
            .build();
    }

    public void setCrmThirdPartyMapperService(CRMThirdPartyMapperService crmThirdPartyMapperService) {
        this.crmThirdPartyMapperService = crmThirdPartyMapperService;
    }

    public void setCrmUserLoaderService(CRMLoaderCoreService crmUserLoaderService) {
        this.crmUserLoaderService = crmUserLoaderService;
    }

    private CRMLoaderResponse buildLoaderResponse(UserCRM user) {
        CRMLoaderResponse.Builder crmResponseBuilder = CRMLoaderResponse.newBuilder();
        if (user.getCrmEntityId() != 0 && user.getCrmEntityId() != -1) {
            crmResponseBuilder.setStatus(CRMResponseStatusEnum.FULL_SUCCESS);
            crmResponseBuilder.setMessage("User successfully mapped.");
        } else {
            crmResponseBuilder.setStatus(CRMResponseStatusEnum.CORE_ATTRIBUTE_FAIL);
            crmResponseBuilder.setMessage("User couldn't be mapped.");
        }
        return crmResponseBuilder.build();
    }

}
