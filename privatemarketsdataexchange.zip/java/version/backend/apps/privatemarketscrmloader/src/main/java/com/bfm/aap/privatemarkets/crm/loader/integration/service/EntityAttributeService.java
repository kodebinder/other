package com.bfm.aap.privatemarkets.crm.loader.integration.service;

import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.privatemarkets.crm.loader.mapper.EntityAttributeTransformer;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreCompanyMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreContactMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.EntityAttributeMessage;
import com.bfm.aap.privatemarkets.common.crm.model.CRMChannelResponse;
import com.bfm.aap.privatemarkets.common.crm.model.EntityType;
import com.bfm.aap.privatemarkets.crm.loader.service.CRMLoaderCoreService;
import com.bfm.aap.privatemarkets.crm.loader.util.CRMLoaderConstants;
import com.bfm.entitymaster.dto.entityattribute.EntityAttribute;
import com.bfm.util.BFMDate;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class EntityAttributeService {
    private static final Logger LOGGER = LoggerFactory.getLogger(EntityAttributeService.class);

    @Autowired
    private EntityAttributeTransformer entityAttributeTransformer;
    @Autowired
    private CRMLoaderCoreService crmUserLoaderService;

    @RecordStats
    public EntityAttributeMessage translateToCRMMessage(CoreContactMessage contact) {
        EntityAttributeMessage msg = new EntityAttributeMessage();
        msg.setLinkedCRMEntityId(contact.getCrmContact().getEntityId());
        List<EntityAttribute> entityAttributeList = getEntityAttributes(contact.getPmdxContact());
        msg.setEntityAttributeList(entityAttributeList);
        LOGGER.info("success - Translater-Contact: translateToCRMMessage - EntityId:{}", contact.getPmdxContact().getContactId());
        return msg;
    }

    @RecordStats
    public EntityAttributeMessage translateToCRMMessage(CoreCompanyMessage company) {
        EntityAttributeMessage msg = new EntityAttributeMessage();
        msg.setLinkedCRMEntityId(company.getOrgEntity().getEntityId());
        LOGGER.info("success - Translater-Company: translateToCRMMessage - EntityId:{}", company.getCompany().getCompanyId());
        return msg;
    }

    @RecordStats
    public EntityAttributeMessage translateToCRMMessage(CoreInvestorMessage coreInvestorMessage) {
        EntityAttributeMessage msg = new EntityAttributeMessage();
        msg.setLinkedCRMEntityId(coreInvestorMessage.getOrgEntity().getEntityId());
        List<EntityAttribute> entityAttributeList = getEntityAttributes(coreInvestorMessage.getInvestor());
        msg.setEntityAttributeList(entityAttributeList);
        LOGGER.info("success - Translater -Investor: translateToCRMMessage - EntityId:{}", coreInvestorMessage.getOrgEntity().getEntityId());
        return msg;
    }

    @RecordStats
    public CRMChannelResponse handleEntityAttributeCreate(Message<EntityAttributeMessage> msg) {
        EntityAttributeMessage eaMsg = msg.getPayload();
        String user = (String) msg.getHeaders().get(CRMLoaderConstants.USER);
        if (CollectionUtils.isNotEmpty(eaMsg.getEntityAttributeList())) {
            LOGGER.info("EM API call - EntityAttribute Create: handleEntityAttributeCreate - EntityId:{}", eaMsg.getLinkedCRMEntityId());
            return getCrmChannelResponse(eaMsg, user);
        } else {
            return buildResponse(eaMsg.getLinkedCRMEntityId(), -1, true, EntityType.ENTITY_ATTRIBUTE_VALUE);
        }
    }

    @RecordStats
    public CRMChannelResponse handleEntityAttributeUpdate(Message<EntityAttributeMessage> msg) {
        EntityAttributeMessage eaMsg = msg.getPayload();
        String user = (String) msg.getHeaders().get(CRMLoaderConstants.USER);
        if (CollectionUtils.isNotEmpty(eaMsg.getEntityAttributeList())) {
            List<EntityAttribute> eaList = crmUserLoaderService.getEntityAttributesByEntityId(eaMsg.getLinkedCRMEntityId(), null != user ? user : CRMLoaderConstants.TSG_OPS);
            eaMsg.getEntityAttributeList().removeAll(eaList);
            if (CollectionUtils.isNotEmpty(eaMsg.getEntityAttributeList())) {
                LOGGER.info("EM API call - EntityAttribute Update: handleEntityAttributeUpdate - EntityId:{}", eaMsg.getLinkedCRMEntityId());
                return getCrmChannelResponse(eaMsg, user);
            }
        }
        return buildResponse(eaMsg.getLinkedCRMEntityId(), -1, true, EntityType.ENTITY_ATTRIBUTE_VALUE);

    }

    private List<EntityAttribute> getEntityAttributes(Investor investor) {
        List<EntityAttribute> entityAttributeList = new ArrayList<>();
        if (null != investor.getLegal()) {
            addEntityAttribute(CRMLoaderConstants.DATE_OF_BIRTH, investor.getLegal().getDateOfBirth()).ifPresent(entityAttributeList::add);
            addEntityAttribute(CRMLoaderConstants.BIRTH_PLACE_COUNTRY, investor.getLegal().getCountryOfBirth()).ifPresent(entityAttributeList::add);
            addEntityAttribute(CRMLoaderConstants.TAX_IDENTIFICATION, investor.getLegal().getTaxIdentification()).ifPresent(entityAttributeList::add);
            addEntityAttribute(CRMLoaderConstants.ERISA_INVESTOR, investor.getLegal().getErisaInvestor() ? CRMLoaderConstants.ERISA_STATUTORY : CRMLoaderConstants.ERISA_NO).ifPresent(entityAttributeList::add);
            if (null != investor.getLegal().getTaxDomicileCountry())
                addEntityAttribute(CRMLoaderConstants.PRIMARY_TAX_COUNTRY, investor.getLegal().getTaxDomicileCountry()).ifPresent(entityAttributeList::add);
            if (null != investor.getLegal().getFatcaDetails() && null != investor.getLegal().getFatcaDetails().getStatus())
                addEntityAttribute(CRMLoaderConstants.FATCA_STATUS, investor.getLegal().getFatcaDetails().getStatus()).ifPresent(entityAttributeList::add);
        }
        return entityAttributeList;
    }

    private List<EntityAttribute> getEntityAttributes(Contact pmdxContact) {
        List<EntityAttribute> entityAttributeList = new ArrayList<>();
        addEntityAttribute(CRMLoaderConstants.DATE_OF_BIRTH, pmdxContact.getDateOfBirth()).ifPresent(entityAttributeList::add);
        addEntityAttribute(CRMLoaderConstants.BIRTH_PLACE_CITY, pmdxContact.getBirthPlaceCity()).ifPresent(entityAttributeList::add);
        addEntityAttribute(CRMLoaderConstants.CITIZENSHIP, pmdxContact.getPrimaryCitizenship()).ifPresent(entityAttributeList::add);

        return entityAttributeList;
    }

    private Optional<EntityAttribute> addEntityAttribute(String attributeCode, String value) {
        if (StringUtils.isNotBlank(value)) {
            return Optional.ofNullable(entityAttributeTransformer.eFrontToCRMTransform(attributeCode, value,
                    new BFMDate(System.currentTimeMillis()), new BFMDate(BFMDate.max_date)));
        }
        return Optional.empty();
    }


    private CRMChannelResponse getCrmChannelResponse(EntityAttributeMessage msg, String user) {
        try {
            List<EntityAttribute> processedList = crmUserLoaderService.createEntityAttributes(msg.getLinkedCRMEntityId(), msg.getEntityAttributeList(), user);
            if (CollectionUtils.isNotEmpty(processedList) && processedList.size() == msg.getEntityAttributeList().size()) {
                LOGGER.info("success - EntityAttribute Create/Update - EntityId:{}", msg.getLinkedCRMEntityId());
                return buildResponse(msg.getLinkedCRMEntityId(), -1, true, EntityType.ENTITY_ATTRIBUTE_VALUE);
            }
        } catch (Exception e) {
            LOGGER.info("Exception in EntityAttribute Create/Update: CoreEntityId:{}, {}", msg.getLinkedCRMEntityId(), e);
        }
        return buildResponse(msg.getLinkedCRMEntityId(), -1, false, EntityType.ENTITY_ATTRIBUTE_VALUE);
    }

    public void setEntityAttributeTransformer(EntityAttributeTransformer entityAttributeTransformer) {
        this.entityAttributeTransformer = entityAttributeTransformer;
    }

    public void setCrmUserLoaderService(CRMLoaderCoreService crmUserLoaderService) {
        this.crmUserLoaderService = crmUserLoaderService;
    }

    private CRMChannelResponse buildResponse(int linkedCRMEntityId, int entityId, boolean status, int entityType) {
        return CRMChannelResponse.newBuilder()
                .setCoreEntityId(linkedCRMEntityId)
                .setEntityId(entityId)
                .setStatus(status)
                .setEntityTypeValue(entityType)
                .build();
    }
}
