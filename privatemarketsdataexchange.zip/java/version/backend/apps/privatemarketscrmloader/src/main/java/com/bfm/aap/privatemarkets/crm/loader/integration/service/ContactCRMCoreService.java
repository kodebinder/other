package com.bfm.aap.privatemarkets.crm.loader.integration.service;

import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreContactInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreContactMessage;
import com.bfm.aap.privatemarkets.crm.loader.service.CRMLoaderCoreService;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.entitymaster.dto.contact.Contact;
import com.bfm.entitymaster.dto.contact.ContactDetail;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;

public class ContactCRMCoreService {
   
    private static final Logger LOGGER = LoggerFactory.getLogger(ContactCRMCoreService.class);
    private static final String USER = "user";
    private static final String TSG_OPS = "tsgops";

    @Autowired
    private CRMLoaderCoreService crmCoreService;
    @Autowired
    private CRMThirdPartyMapperService crmThirdPartyMapperService;

    @RecordStats
    public Message<CoreContactMessage> populateCRMEntityId(Message<CoreContactMessage> msg) {
        int entityId = crmThirdPartyMapperService.lookUp(msg.getPayload().getPmdxContact().getContactId(), ThirdPartyMappingEnum.CONTACT_INVEST);
        msg.getPayload().getCrmContact().setEntityId(entityId);
        int userEntityId = crmThirdPartyMapperService.lookUp(msg.getPayload().getPmdxContact().getModifiedBy(), ThirdPartyMappingEnum.USER_INVEST);
        LOGGER.info("Contact: populateCRMEntityId : userEntityId -> {}", userEntityId);
        String user = userEntityId > 0 ? crmThirdPartyMapperService.getLoginByEntityId(userEntityId) : TSG_OPS;
        LOGGER.info("Company: populateCRMEntityId : user -> {}", user);
        msg.getPayload().setUser(user);
        LOGGER.info("populateCRMEntityId : entityId -> {}", entityId);
        return msg;
    }

    @RecordStats
    public CoreContactMessage handleCoreContactCreate(Message<CoreContactMessage> msg) {
        CoreContactMessage cMsg = msg.getPayload();
        String user = (String) msg.getHeaders().get(USER);
        Contact contact = crmCoreService.createContact(cMsg.getCrmContact(), cMsg.getPrimaryEmail().getElectronicAddress(), user);
        cMsg.getCrmContact().setEntityId(contact.getEntityId());
        crmThirdPartyMapperService.create(cMsg.getPmdxContact().getContactId(), contact.getEntityId(), ThirdPartyMappingEnum.CONTACT_INVEST);
        LOGGER.info("handleCoreContactCreate : entityId -> {}", contact.getEntityId());
        return cMsg;
    }

    @RecordStats
    public CoreContactMessage handleCoreContactUpdate(Message<CoreContactMessage> msg) {
        CoreContactMessage cMsg = msg.getPayload();
        String user = (String) msg.getHeaders().get(USER);
        ContactDetail contactDetail = crmCoreService.getCRMUserContact(cMsg.getCrmContact().getEntityId(), user);
        Contact c = contactDetail.getContact();
        if (!cMsg.getCrmContact().equals(c)) {
            crmCoreService.updateContact(cMsg.getCrmContact().getEntityId(), cMsg.getCrmContact(), user);
            LOGGER.info("handleCoreContactUpdate : entityId -> {}", cMsg.getCrmContact().getEntityId());
        }
        return cMsg;
    }

    public CoreContactInverseMessage populateEfrontContact(Message<CoreContactInverseMessage> message) {
        String user = (String) message.getHeaders().get(USER);
        CoreContactInverseMessage coreContactInverseMessage = message.getPayload();
        coreContactInverseMessage.setCrmEntity(crmCoreService.getCRMUserContact(coreContactInverseMessage.getCrmContactId(), null != user ? user : TSG_OPS));
        coreContactInverseMessage.setEntityAttributes(crmCoreService.getEntityAttributesByEntityId(coreContactInverseMessage.getCrmContactId(), null != user ? user : TSG_OPS));
        coreContactInverseMessage.setEmployer(crmCoreService.getEmployerByEntityId(coreContactInverseMessage.getCrmContactId(), null != user ? user : TSG_OPS));
        coreContactInverseMessage.setModifiedByCRMUserEntityId(crmCoreService.getEmployeeCRMIdFromLogin(coreContactInverseMessage.getModifiedByCRMUserLogin(), null != user ? user : TSG_OPS));
        coreContactInverseMessage.setAddresses(crmCoreService.getContactAddresses(coreContactInverseMessage.getCrmContactId(), null != user ? user : TSG_OPS));
        coreContactInverseMessage.setAliases(crmCoreService.getEntityAliasByEntityIdCRM(coreContactInverseMessage.getCrmContactId(), null != user ? user : TSG_OPS));
        LOGGER.info("populateEfrontContact completed for CRM entityId -> {}", coreContactInverseMessage.getCrmEntity());
        return coreContactInverseMessage;
    }

    public void setCrmCoreService(CRMLoaderCoreService crmCoreService) {
        this.crmCoreService = crmCoreService;
    }

    public void setCrmThirdPartyMapperService(CRMThirdPartyMapperService crmThirdPartyMapperService) {
        this.crmThirdPartyMapperService = crmThirdPartyMapperService;
    }
}
