package com.bfm.aap.privatemarkets.crm.loader.config;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.function.Supplier;

import com.google.common.base.Suppliers;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bfm.aap.pmdx.async.util.ExecutorServiceFactory;
import com.bfm.aap.privatemarkets.crm.loader.service.kafka.StreamProcessorRunner;

@Configuration
public class EntityNotificationConfig {

    private static final Supplier<ThreadFactory> STREAM_PROCESSOR_EXECUTOR_THREAD_FACTORY =
            Suppliers.memoize(() -> new ThreadFactoryBuilder().setNameFormat("crm-stream-processor-%d").build());

    private static final Supplier<ThreadFactory> PROCESS_NOTIFICATION_EXECUTOR_THREAD_FACTORY =
            Suppliers.memoize(() -> new ThreadFactoryBuilder().setNameFormat("crm-notification-processor-%d").build());

    @Value("${crm.stream.processor.number.threads:5}")
    private int streamProcessorNThreads;

    @Value("${crm.stream.processor.queue.size:50}")
    private int streamProcessorQueueSize;

    @Value("${executor.pool.size:5}")
    private int processNotificationExecutorServiceThreadPoolSize;

    @Bean
    @Qualifier("streamProcessorRunner")
    public StreamProcessorRunner streamProcessorRunner() {
        return new StreamProcessorRunner();
    }

    @Bean
    public ThreadPoolExecutor streamProcessorExecutor() {
        return ExecutorServiceFactory.newExecutorService(streamProcessorNThreads, streamProcessorQueueSize, STREAM_PROCESSOR_EXECUTOR_THREAD_FACTORY.get());
    }

    @Bean
    @Qualifier("processNotificationExecutorService")
    public ExecutorService processNotificationExecutorService(){
        return Executors.newFixedThreadPool(processNotificationExecutorServiceThreadPoolSize, PROCESS_NOTIFICATION_EXECUTOR_THREAD_FACTORY.get());
    }
}
