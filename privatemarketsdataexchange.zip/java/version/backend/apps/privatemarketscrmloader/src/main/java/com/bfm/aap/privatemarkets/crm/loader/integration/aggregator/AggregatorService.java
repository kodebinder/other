package com.bfm.aap.privatemarkets.crm.loader.integration.aggregator;

import java.util.List;

import com.bfm.aap.privatemarkets.common.crm.model.CRMChannelResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMChannelResponseList;
import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;

public interface AggregatorService {
    default CRMChannelResponseList aggregateAndPublish(List<CRMChannelResponse> responseList) {
        return CRMChannelResponseList.newBuilder().addAllResponse(responseList).build();
    }

    default CRMChannelResponseList aggregateAndPublishSingleResponse(CRMChannelResponse response) {
        return CRMChannelResponseList.newBuilder().addResponse(response).build();
    }

    CRMLoaderResponse composeEndpointResponse(List<CRMChannelResponseList> responseList);
}
