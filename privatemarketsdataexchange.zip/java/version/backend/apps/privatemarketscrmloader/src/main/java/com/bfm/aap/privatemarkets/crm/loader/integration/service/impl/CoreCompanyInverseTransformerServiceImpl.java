package com.bfm.aap.privatemarkets.crm.loader.integration.service.impl;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.google.protobuf.Timestamp;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bfm.aap.pmdx.model.AccessRights;
import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.PropertyInfo;
import com.bfm.aap.pmdx.model.Region;
import com.bfm.aap.pmdx.model.VcData;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.bfm.aap.privatemarkets.common.constant.CommonConstants;
import com.bfm.aap.privatemarkets.common.crm.model.CRMCoreEntityTypes;
import com.bfm.aap.privatemarkets.crm.loader.integration.service.PermRegionService;
import com.bfm.aap.privatemarkets.crm.loader.integration.service.TransformerService;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreCompanyInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.util.DecodeHelper;
import com.bfm.aap.privatemarkets.crm.loader.util.ElectronicAddressConstants;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.entitymaster.dto.common.Decode;
import com.bfm.entitymaster.dto.common.ElectronicAddress;
import com.bfm.entitymaster.dto.common.Entity;
import com.bfm.entitymaster.dto.entitythirdparty.ThirdPartyMapping;
import com.bfm.entitymaster.dto.entitythirdparty.ThirdPartySource;
import com.bfm.entitymaster.dto.organization.OrganizationDetail;
import com.bfm.entitymaster.dto.organization.OrganizationType;

import static com.bfm.aap.privatemarkets.common.crm.util.EntityMasterDecodeTableConstants.COUNTRIES;
import static com.bfm.aap.privatemarkets.common.crm.util.EntityMasterDecodeTableConstants.EM_INV_ORGANIZATION_TYPE;

public class CoreCompanyInverseTransformerServiceImpl implements TransformerService<CoreCompanyInverseMessage, CoreCompanyInverseMessage> {

    private static final Logger LOGGER = LoggerFactory.getLogger(CoreCompanyInverseTransformerServiceImpl.class);

    @Autowired
    private CRMThirdPartyMapperService crmThirdPartyMapperService;

    @Autowired
    private PermRegionService permRegionService;

    @Override
    public CoreCompanyInverseMessage transform(CoreCompanyInverseMessage coreCompanyInverseMessage) throws Exception {

        ThirdPartyMapping thirdPartyMapping = crmThirdPartyMapperService.lookupThirdPartMapping(coreCompanyInverseMessage.getOrganization().getMasterOrganization().getEntityId(), ThirdPartyMappingEnum.COMPANY_INVEST);

        String name = Optional.ofNullable(coreCompanyInverseMessage)
            .map(CoreCompanyInverseMessage::getOrganization)
            .map(OrganizationDetail::getOrganization)
            .map(Entity::getEntityName)
            .orElse(StringUtils.EMPTY);

        String orgTypeCode = Optional.ofNullable(coreCompanyInverseMessage)
            .map(CoreCompanyInverseMessage::getOrganization)
            .map(OrganizationDetail::getOrganizationType)
            .map(OrganizationType::getOrganizationType)
            .map(Decode::getCode)
            .orElse(StringUtils.EMPTY);

        String orgTypeDecode = Optional.ofNullable(DecodeHelper.getDecode(EM_INV_ORGANIZATION_TYPE, orgTypeCode))
                .map(Decode::getDecode)
                .orElse(StringUtils.EMPTY);

        String countryCode = Optional.ofNullable(coreCompanyInverseMessage)
                .map(CoreCompanyInverseMessage::getOrganization)
                .map(OrganizationDetail::getDomicile)
                .orElse(StringUtils.EMPTY);

        String countryDecode = Optional.ofNullable(DecodeHelper.getDecode(COUNTRIES, countryCode))
                .map(Decode::getDecode)
                .orElse(StringUtils.EMPTY);


        Company.Builder companyBuilder = Company.newBuilder()
                .setName(name)
                .setStatus(orgTypeDecode)
                .setDomicile(countryDecode)
                .setRegion(getRegion(coreCompanyInverseMessage));


        updateParentCompanyId(companyBuilder, thirdPartyMapping);
        updateModificationDateTime(companyBuilder);
        updateCompanyModifiedBy(companyBuilder, coreCompanyInverseMessage.getModifiedByCRMUserEntityId());
        updateCompanyId(companyBuilder, coreCompanyInverseMessage.getCrmCompanyId());
        updateCompanyEntityInfo(companyBuilder);
        updateCompanyAccessRights(companyBuilder);
        updateCompanyStatusAndPropertyInfo(companyBuilder);
        updateCompanyFoundedInfo(companyBuilder);
        populateElectronAddressWebType(companyBuilder, coreCompanyInverseMessage.getElectronicAddresses());
        coreCompanyInverseMessage.setEfrontEntity(companyBuilder.build());
        return coreCompanyInverseMessage;
    }

    private Region getRegion(CoreCompanyInverseMessage coreCompanyInverseMessage) {
        String regionIqId;
        if (null != coreCompanyInverseMessage && null != coreCompanyInverseMessage.getCrmCompanyId()) {
            regionIqId = permRegionService.getRegionByEntityIdAndType(coreCompanyInverseMessage.getCrmCompanyId(), CRMCoreEntityTypes.COMPANY);
        } else {
            regionIqId = StringUtils.EMPTY;
        }
        return Region.newBuilder().setId(regionIqId).build();
    }

    private void updateCompanyFoundedInfo(Company.Builder companyBuilder) {
        companyBuilder.setFoundedOn(Timestamp.newBuilder()
                .setSeconds(0)
                .setNanos(0)
                .build());
    }

    private void updateCompanyStatusAndPropertyInfo(Company.Builder companyBuilder) {
        companyBuilder.setStatus(StringUtils.isEmpty(companyBuilder.getStatus()) ? "1" : companyBuilder.getStatus())
                .setVcData(VcData.newBuilder().build())
                .setPropertyInfo(PropertyInfo.newBuilder().build());
    }

    private void updateParentCompanyId(Company.Builder companyBuilder, ThirdPartyMapping thirdPartyMapping) {
        int companyId = Optional.ofNullable(thirdPartyMapping)
                .map(ThirdPartyMapping::getThirdPartySource)
                .map(ThirdPartySource::getThirdPartySourceId)
                .orElseGet(() -> 0);
        companyBuilder.setParentCompanyId(companyId != 0 ? String.valueOf(companyId) : "");
    }

    private void updateCompanyAccessRights(Company.Builder companyBuilder) {
        companyBuilder.setAccessRights(AccessRights
                .newBuilder()
                .setDelete(Boolean.TRUE)
                .setWrite(Boolean.TRUE)
                .setNew(Boolean.TRUE)
                .setDuplicate(Boolean.TRUE)
                .build());
    }

    private void updateModificationDateTime(Company.Builder companyBuilder) {
        companyBuilder.setModificationDateTime(
                Timestamp.newBuilder()
                        .setSeconds(Instant.now().getEpochSecond())
                        .setNanos(Instant.now().getNano())
                        .build())
                .setCreationDate(Timestamp.newBuilder()
                        .build());
    }

    private void updateCompanyEntityInfo(Company.Builder companyBuilder) {
        companyBuilder.setEntityInfo(EntityInfo.newBuilder()
            .setNetworkMode(CommonConstants.NETWORK_MODE)
                .setOriginTimestamp(Timestamp.newBuilder()
                        .setSeconds(Instant.now().getEpochSecond())
                        .setNanos(Instant.now().getNano())
                        .build())
                .setPrimaryData(Boolean.TRUE)
                .build());

    }

    private void updateCompanyId(Company.Builder companyBuilder, Integer crmCompanyId) {
        ThirdPartyMapping thirdPartyMapping = crmThirdPartyMapperService.lookupThirdPartMapping(crmCompanyId, ThirdPartyMappingEnum.COMPANY_INVEST);
        if (null != thirdPartyMapping) {
            companyBuilder.setCompanyId(thirdPartyMapping.getThirdPartyIdentifier());
        }
    }

    private void updateCompanyModifiedBy(Company.Builder companyBuilder, Integer modifiedByCRMUserEntityId) {
        if (modifiedByCRMUserEntityId != -1) {
            ThirdPartyMapping thirdPartyMapping = crmThirdPartyMapperService.lookupThirdPartMapping(modifiedByCRMUserEntityId, ThirdPartyMappingEnum.COMPANY_INVEST);
            if (null != thirdPartyMapping) {
                companyBuilder.setModifiedBy(thirdPartyMapping.getThirdPartyIdentifier());
            }
        }
    }

    private void populateElectronAddressWebType(Company.Builder companyBuilder, List<ElectronicAddress> electronicAddressList) {

        electronicAddressList = CollectionUtils.isNotEmpty(electronicAddressList) ?
                electronicAddressList.stream()
                        .filter(electronicAddress ->
                            ElectronicAddressConstants.WEB.equals(Optional.ofNullable(electronicAddress)
                                .map(ElectronicAddress::getElectronicType)
                                .map(Decode::getCode)
                                .orElse(StringUtils.EMPTY)))
                        .collect(Collectors.toList()) : new ArrayList<>();

        for (ElectronicAddress electronicAddress : electronicAddressList) {

            String electronicAddressCode = Optional.ofNullable(electronicAddress)
                .map(ElectronicAddress::getElectronicSubType)
                .map(Decode::getCode).orElse(StringUtils.EMPTY);

            if (StringUtils.isNotEmpty(electronicAddressCode)) {
                switch (electronicAddressCode) {
                    case ElectronicAddressConstants.LINKEDIN:
                        companyBuilder.setLinkedin(electronicAddress.getAddress()).build();
                        break;
                    case ElectronicAddressConstants.TWITTER:
                        companyBuilder.setTwitter(electronicAddress.getAddress()).build();
                        break;
                }
            }
        }

    }
}