/**
 * 
 */
package com.bfm.aap.privatemarkets.crm.loader.integration.router;

import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.integration.annotation.MessageEndpoint;
import org.springframework.integration.annotation.Router;

import com.bfm.aap.pmdx.model.User;

/**
 * @author hthakkar
 *
 */
@MessageEndpoint
public class UserCRMCoreServiceRouter {
	private static final Logger LOGGER = LoggerFactory.getLogger(UserCRMCoreServiceRouter.class);
	
	@Value("${processUserMappingFromEMS:false}")
	private boolean processUserMappingFromEMS;
	@Value("${processUserMappingFromAGU:false}")
	private boolean processUserMappingFromAGU;
	private static final String USER_PROCESS_EMS_CHANNEL = "userProcessInitEMSChannel";
	private static final String USER_PROCESS_AGU_CHANNEL = "userProcessInitAGUChannel";
	
	@Router
	public List<String> route(User user) {
		LOGGER.info("Enable User Processing via EMS for BLK {}", processUserMappingFromEMS);
		LOGGER.info("Enable User Processing via AGU for BLK {}", processUserMappingFromAGU);
		List<String> outputChannels = new LinkedList<>();
		if(processUserMappingFromEMS && !processUserMappingFromAGU) {
			outputChannels.add(USER_PROCESS_EMS_CHANNEL);
			return outputChannels;
		} else if(!processUserMappingFromEMS && processUserMappingFromAGU) {
			outputChannels.add(USER_PROCESS_AGU_CHANNEL);
			return outputChannels;
		} else if(processUserMappingFromEMS && processUserMappingFromAGU) {
			outputChannels.add(USER_PROCESS_AGU_CHANNEL);
			outputChannels.add(USER_PROCESS_EMS_CHANNEL);
			return outputChannels;
		} else {
			outputChannels.add(USER_PROCESS_AGU_CHANNEL);
			return outputChannels;
		}
	}

}
