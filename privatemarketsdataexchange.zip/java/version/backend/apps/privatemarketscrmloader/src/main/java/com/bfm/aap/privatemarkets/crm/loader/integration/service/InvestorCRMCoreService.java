package com.bfm.aap.privatemarkets.crm.loader.integration.service;

import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorMessage;
import com.bfm.aap.privatemarkets.crm.loader.service.CRMLoaderCoreService;
import com.bfm.aap.privatemarkets.crm.loader.util.CustomEntityComparator;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.entitymaster.dto.organization.OrganizationDetail;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;

public class InvestorCRMCoreService {
    private static final Logger LOGGER = LoggerFactory.getLogger(InvestorCRMCoreService.class);
    private static final String USER = "user";
    private static final String TSG_OPS = "tsgops";
    @Autowired
    private CRMLoaderCoreService crmCoreService;
    @Autowired
    private CRMThirdPartyMapperService crmThirdPartyMapperService;

    @RecordStats
    public Message<CoreInvestorMessage> populateCRMEntityId(Message<CoreInvestorMessage> msg) {
        int entityId = crmThirdPartyMapperService.lookUp(msg.getPayload().getInvestor().getInvestorId(), ThirdPartyMappingEnum.INVESTOR_INVEST);
        int userEntityId = crmThirdPartyMapperService.lookUp(msg.getPayload().getInvestor().getModifiedBy(), ThirdPartyMappingEnum.USER_INVEST);
        LOGGER.info("Investor: populateCRMEntityId : userEntityId -> {}", userEntityId);
        String user = userEntityId > 0 ? crmThirdPartyMapperService.getLoginByEntityId(userEntityId) : TSG_OPS;
        LOGGER.info("Company: populateCRMEntityId : user -> {}", user);
        msg.getPayload().setUser(user);
        msg.getPayload().getOrgEntity().setEntityId(entityId);
        LOGGER.info("Investor: populateCRMEntityId : entityId -> {}", entityId);
        return msg;
    }

    @RecordStats
    public CoreInvestorMessage handleCoreInvestorCreate(Message<CoreInvestorMessage> msg) {
        CoreInvestorMessage iMsg = msg.getPayload();
        String user = (String) msg.getHeaders().get(USER);
        iMsg.setCrmParentCompanyEntityId(crmThirdPartyMapperService.lookUp(iMsg.getInvestor().getCompanyId(), ThirdPartyMappingEnum.COMPANY_INVEST));
        LOGGER.info("handleCoreInvestorCreate : crmParentCompanyId -> {}", iMsg.getCrmParentCompanyEntityId());
        OrganizationDetail organizationDetail = crmCoreService.createInvestorWithParentOrg(iMsg.getOrgEntity(), iMsg.getOrganizationType(), iMsg.getCountryDecode(), iMsg.getCrmParentCompanyEntityId(), user);
        iMsg.getOrgEntity().setEntityId(organizationDetail.getOrganization().getEntityId());
        crmThirdPartyMapperService.create(iMsg.getInvestor().getInvestorId(), iMsg.getOrgEntity().getEntityId(), ThirdPartyMappingEnum.INVESTOR_INVEST);
        LOGGER.info("handleCoreInvestorCreate : entityId -> {}", iMsg.getOrgEntity().getEntityId());
        return iMsg;
    }

    @RecordStats
    public CoreInvestorMessage handleCoreInvestorUpdate(Message<CoreInvestorMessage> msg) {
        CoreInvestorMessage iMsg = msg.getPayload();
        String user = (String) msg.getHeaders().get(USER);
        iMsg.setCrmParentCompanyEntityId(crmThirdPartyMapperService.lookUp(iMsg.getInvestor().getCompanyId(), ThirdPartyMappingEnum.COMPANY_INVEST));
        LOGGER.info("handleCoreInvestorUpdate : crmParentCompanyId -> {}", iMsg.getCrmParentCompanyEntityId());
        OrganizationDetail orgDetail = crmCoreService.getOrganizationByIdCRM(iMsg.getOrgEntity().getEntityId(), user);
        if ((CustomEntityComparator.compareEntity.compare(orgDetail.getOrganization(), iMsg.getOrgEntity()) != 0)
                || !iMsg.getOrganizationType().equals(orgDetail.getOrganizationType())) {
            crmCoreService.updateOrganizationCRM(iMsg.getOrgEntity().getEntityId(), iMsg.getOrgEntity(), iMsg.getOrganizationType(), user);
            LOGGER.info("Investor: handleCoreInvestorUpdate : entityId -> {}", iMsg.getOrgEntity().getEntityId());
        }
        return iMsg;
    }

    public CoreInvestorInverseMessage populateEfrontInvestor(Message<CoreInvestorInverseMessage> message) {
        String user = (String) message.getHeaders().get(USER);
        CoreInvestorInverseMessage coreInvestorInverseMessage = message.getPayload();
        coreInvestorInverseMessage.setEntityAttributes(crmCoreService.getEntityAttributesByEntityId(coreInvestorInverseMessage.getCrmInvestorId(), null != user ? user : TSG_OPS));
        coreInvestorInverseMessage.setElectronicAddresses(crmCoreService.getElectronicAddressByEntityId(coreInvestorInverseMessage.getCrmInvestorId(), null != user ? user : TSG_OPS));
        coreInvestorInverseMessage.setAliases(crmCoreService.getEntityAliasByEntityIdCRM(coreInvestorInverseMessage.getCrmInvestorId(), null != user ? user : TSG_OPS));
        coreInvestorInverseMessage.setOrganization(crmCoreService.getOrganizationByIdCRM(coreInvestorInverseMessage.getCrmInvestorId(), null != user ? user : TSG_OPS));
        coreInvestorInverseMessage.setNotes(crmCoreService.getNotesByEntityIdCRM(coreInvestorInverseMessage.getCrmInvestorId(), null != user ? user : TSG_OPS));
        coreInvestorInverseMessage.setModifiedByCRMUserEntityId(crmCoreService.getEmployeeCRMIdFromLogin(coreInvestorInverseMessage.getModifiedByCRMUserLogin(), null != user ? user : TSG_OPS));
        LOGGER.info("populateEfrontInvestor completed for CRM entityId -> {}", coreInvestorInverseMessage.getCrmInvestorId());
        return coreInvestorInverseMessage;
    }

    public void setCrmCoreService(CRMLoaderCoreService crmCoreService) {
        this.crmCoreService = crmCoreService;
    }

    public void setCrmThirdPartyMapperService(CRMThirdPartyMapperService crmThirdPartyMapperService) {
        this.crmThirdPartyMapperService = crmThirdPartyMapperService;
    }
}
