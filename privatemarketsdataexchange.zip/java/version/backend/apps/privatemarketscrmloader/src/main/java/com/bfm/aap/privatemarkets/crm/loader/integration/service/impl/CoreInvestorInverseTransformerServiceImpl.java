package com.bfm.aap.privatemarkets.crm.loader.integration.service.impl;

import com.bfm.aap.pmdx.model.AccessRights;
import com.bfm.aap.pmdx.model.FundRaising;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.Region;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.util.DecodeHelper;
import com.bfm.aap.privatemarkets.common.constant.CommonConstants;
import com.bfm.aap.privatemarkets.common.crm.model.CRMCoreEntityTypes;
import com.bfm.aap.privatemarkets.common.crm.util.EntityMasterDecodeTableConstants;
import com.bfm.aap.privatemarkets.crm.loader.integration.service.PermRegionService;
import com.bfm.aap.privatemarkets.crm.loader.integration.service.TransformerService;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.entitymaster.dto.common.Decode;
import com.bfm.entitymaster.dto.common.Entity;
import com.bfm.entitymaster.dto.entitythirdparty.ThirdPartyMapping;
import com.bfm.entitymaster.dto.organization.OrganizationDetail;
import com.bfm.entitymaster.dto.organization.OrganizationType;
import com.google.protobuf.Timestamp;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.Instant;
import java.util.Optional;

public class CoreInvestorInverseTransformerServiceImpl implements TransformerService<CoreInvestorInverseMessage, CoreInvestorInverseMessage> {

    private static final Logger LOGGER = LoggerFactory.getLogger(CoreInvestorInverseTransformerServiceImpl.class);

    public static final String UNAVAILABLE = "Unavailable";
    public static final String USD = "USD";

    @Autowired
    private CRMThirdPartyMapperService crmThirdPartyMapperService;
    @Autowired
    private PermRegionService permRegionService;

    @Override
    public CoreInvestorInverseMessage transform(CoreInvestorInverseMessage coreInvestorInverseMessage) {
        String name = Optional.ofNullable(coreInvestorInverseMessage)
                .map(CoreInvestorInverseMessage::getOrganization)
                .map(OrganizationDetail::getOrganization)
                .map(Entity::getEntityName)
                .orElseGet(() -> UNAVAILABLE);

        String investorType = Optional.ofNullable(coreInvestorInverseMessage)
                .map(CoreInvestorInverseMessage::getOrganization)
                .map(OrganizationDetail::getOrganizationType)
                .map(OrganizationType::getOrganizationType)
                .map(Decode::getCode)
                .orElse("BAA");

        String investorTypeDecode = Optional.ofNullable(DecodeHelper.getDecode(EntityMasterDecodeTableConstants.EM_INV_INVESTOR_TYPE, investorType))
                .map(Decode::getDecode)
                .orElse(StringUtils.EMPTY);

        Investor.Builder investorBuilder = Investor.newBuilder()
                .setName(name)
                .setInvestorType(investorTypeDecode)
                .setCurrency(USD)
                .setRegion(getRegion(coreInvestorInverseMessage));

        updateInvestorModifiedBy(investorBuilder, coreInvestorInverseMessage.getModifiedByCRMUserEntityId());
        updateModificationDateTime(investorBuilder);
        updateInvestorId(investorBuilder, coreInvestorInverseMessage.getCrmInvestorId());
        updateInvestorEntityInfo(investorBuilder);
        updateInvestorAccessRights(investorBuilder);
        updateInvestorFundRaising(investorBuilder);
        coreInvestorInverseMessage.setEfrontEntity(investorBuilder.build());
        return coreInvestorInverseMessage;
    }

    private Region getRegion(CoreInvestorInverseMessage coreInvestorInverseMessage) {
        String regionIqId;
        if (null != coreInvestorInverseMessage && null != coreInvestorInverseMessage.getCrmInvestorId()) {
            regionIqId = permRegionService.getRegionByEntityIdAndType(coreInvestorInverseMessage.getCrmInvestorId(), CRMCoreEntityTypes.INVESTOR);
        } else {
            regionIqId = StringUtils.EMPTY;
        }
        return Region.newBuilder().setId(regionIqId).build();
    }

    private void updateInvestorFundRaising(Investor.Builder investorBuilder) {
        investorBuilder.setFundRaising(FundRaising
                .newBuilder()
                .build());
    }

    private void updateInvestorAccessRights(Investor.Builder investorBuilder) {
        investorBuilder.setAccessRights(AccessRights
                .newBuilder()
                .setDelete(Boolean.TRUE)
                .setWrite(Boolean.TRUE)
                .setNew(Boolean.TRUE)
                .setDuplicate(Boolean.TRUE)
                .build());
    }

    private void updateModificationDateTime(Investor.Builder investorBuilder) {
        investorBuilder.setModificationDateTime(
                Timestamp.newBuilder()
                        .setSeconds(Instant.now().getEpochSecond())
                        .setNanos(Instant.now().getNano())
                        .build())
                .setCreationDate(Timestamp.newBuilder()
                        .build());
    }

    private void updateInvestorEntityInfo(Investor.Builder investorBuilder) {
        investorBuilder.setEntityInfo(EntityInfo.newBuilder()
                .setNetworkMode(CommonConstants.NETWORK_MODE)
                .setOriginTimestamp(Timestamp.newBuilder()
                        .setSeconds(Instant.now().getEpochSecond())
                        .setNanos(Instant.now().getNano())
                        .build())
                .setPrimaryData(Boolean.TRUE)
                .build());
    }

    private void updateInvestorModifiedBy(Investor.Builder investorBuilder, Integer modifiedByCRMUserEntityId) {

        if (modifiedByCRMUserEntityId != -1) {
            ThirdPartyMapping thirdPartyMapping = crmThirdPartyMapperService.lookupThirdPartMapping(modifiedByCRMUserEntityId, ThirdPartyMappingEnum.USER_INVEST);
            if (null != thirdPartyMapping) {
                investorBuilder.setModifiedBy(thirdPartyMapping.getThirdPartyIdentifier());
            }
        }
    }

    private void updateInvestorId(Investor.Builder investorBuilder, Integer crmInvestorId) {
        ThirdPartyMapping thirdPartyMapping = crmThirdPartyMapperService.lookupThirdPartMapping(crmInvestorId, ThirdPartyMappingEnum.INVESTOR_INVEST);
        if (null != thirdPartyMapping) {
            investorBuilder.setInvestorId(thirdPartyMapping.getThirdPartyIdentifier());
        }
    }

}