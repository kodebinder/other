package com.bfm.aap.privatemarkets.crm.loader.integration.service;

import com.bfm.aap.privatemarkets.common.crm.model.CRMChannelResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMCoreEntityTypes;
import com.bfm.aap.privatemarkets.common.crm.model.EntityType;
import com.bfm.aap.privatemarkets.permission.restrict.PermissionMappingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class PermRegionService {
    private static final Logger LOGGER = LoggerFactory.getLogger(PermRegionService.class);

    @Autowired
    private PermissionMappingService permissionMappingService;


    public CRMChannelResponse createPermissionGroupFromRegion(int entityId, String entityType, String investRegion, String createdBy) {
        LOGGER.debug("createPermissionGroupFromRegion : Entity {} , Region : {}", entityId,investRegion);
        return getCrmChannelResponse(entityId, permissionMappingService.createItemRestrictions(entityId, CRMCoreEntityTypes.valueOf(entityType), investRegion, createdBy));
    }

    public CRMChannelResponse updatePermissionGroupFromRegion(int entityId, String entityType, String investRegion, String createdBy) {
        LOGGER.debug("updatePermissionGroupFromRegion : Entity {} , Region : {}", entityId,investRegion);
        return getCrmChannelResponse(entityId, permissionMappingService.updateItemRestrictions(entityId, CRMCoreEntityTypes.valueOf(entityType), investRegion, createdBy));
    }

    public String getRegionByEntityIdAndType(int entityId, CRMCoreEntityTypes entityType){
        return permissionMappingService.retrieveInvestRegionByEntityId(entityId,entityType);
    }

    private CRMChannelResponse getCrmChannelResponse(int entityId, boolean response) {
        return CRMChannelResponse.newBuilder()
                .setCoreEntityId(-1)
                .setEntityId(entityId)
                .setStatus(response)
                .setEntityTypeValue(EntityType.SPG_PERMISSION_VALUE)
                .build();
    }

}
