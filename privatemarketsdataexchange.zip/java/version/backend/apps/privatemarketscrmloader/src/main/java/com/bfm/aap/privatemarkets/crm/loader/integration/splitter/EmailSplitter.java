package com.bfm.aap.privatemarkets.crm.loader.integration.splitter;

import com.bfm.aap.pmdx.model.util.SchemaEnum;
import com.bfm.aap.privatemarkets.crm.loader.mapper.ElectronicAddressTransformer;
import com.bfm.aap.privatemarkets.crm.loader.mapper.EmailTransformer;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreCompanyMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreContactMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.ElectronicAddressMessage;
import com.bfm.entitymaster.dto.common.ElectronicAddress;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class EmailSplitter {
    private static final Logger LOGGER = LoggerFactory.getLogger(EmailSplitter.class);

    private static final String TWITTER = "twitter";
    private static final String FACEBOOK = "facebook";
    private static final String LINKEDIN = "linkedin";
    private static final String SKYPE = "skype";
    private static final String WEB = "web";

    @Autowired
    EmailTransformer emailTransformer;
    @Autowired
    ElectronicAddressTransformer electronicAddressTransformer;

    public List<ElectronicAddressMessage> splitAndPublishContactElectronicAddress(Message<CoreContactMessage> message) {

        List<ElectronicAddressMessage> electronicAddressMessages = new ArrayList<>();
        electronicAddressMessages.addAll(message.getPayload().getPmdxContact().getEmailListList().stream()
                .filter(email -> null != email && StringUtils.isNotBlank(email.getEmail()) && email.getIsPrimary())
                .map(email -> createMessage(emailTransformer.eFrontToCRMTransform(email, SchemaEnum.EFRONT_CONTACT_SCHEMA), message.getPayload().getCrmContact().getEntityId()))
                .collect(Collectors.toList()));

        populateWebAddress(message.getPayload().getPmdxContact().getTwitter(), TWITTER, message.getPayload().getCrmContact().getEntityId(), SchemaEnum.EFRONT_CONTACT_SCHEMA).ifPresent(electronicAddressMessages::add);
        populateWebAddress(message.getPayload().getPmdxContact().getFacebook(), FACEBOOK, message.getPayload().getCrmContact().getEntityId(), SchemaEnum.EFRONT_CONTACT_SCHEMA).ifPresent(electronicAddressMessages::add);
        populateWebAddress(message.getPayload().getPmdxContact().getLinkedin(), LINKEDIN, message.getPayload().getCrmContact().getEntityId(), SchemaEnum.EFRONT_CONTACT_SCHEMA).ifPresent(electronicAddressMessages::add);
        populateWebAddress(message.getPayload().getPmdxContact().getSkype(), SKYPE, message.getPayload().getCrmContact().getEntityId(), SchemaEnum.EFRONT_CONTACT_SCHEMA).ifPresent(electronicAddressMessages::add);
        return electronicAddressMessages;
    }
    public List<ElectronicAddressMessage> splitAndPublishCompanyElectronicAddress(Message<CoreCompanyMessage> message) {
        List<ElectronicAddressMessage> electronicAddressMessages = new ArrayList<>();

        populateWebAddress(message.getPayload().getCompany().getTwitter(), TWITTER, message.getPayload().getOrgEntity().getEntityId(), SchemaEnum.EFRONT_COMPANY_SCHEMA).ifPresent(electronicAddressMessages::add);
        populateWebAddress(message.getPayload().getCompany().getLinkedin(), LINKEDIN, message.getPayload().getOrgEntity().getEntityId(), SchemaEnum.EFRONT_COMPANY_SCHEMA).ifPresent(electronicAddressMessages::add);
        populateWebAddress(message.getPayload().getCompany().getWeb(), WEB, message.getPayload().getOrgEntity().getEntityId(), SchemaEnum.EFRONT_COMPANY_SCHEMA).ifPresent(electronicAddressMessages::add);
        return electronicAddressMessages;
    }

    public List<ElectronicAddressMessage> splitAndPublishInvestorElectronicAddress(Message<CoreInvestorMessage> message) {
        List<ElectronicAddressMessage> electronicAddressMessages = new ArrayList<>();
        populateWebAddress(message.getPayload().getInvestor().getWeb(), WEB, message.getPayload().getOrgEntity().getEntityId(), SchemaEnum.EFRONT_INVESTOR_SCHEMA).ifPresent(electronicAddressMessages::add);
        return electronicAddressMessages;
    }

    private Optional<ElectronicAddressMessage> populateWebAddress(String webAddress, String platform, int entityId, SchemaEnum schemaEnum) {
        if (StringUtils.isNotBlank(webAddress)) {
            return Optional.of(createMessage(electronicAddressTransformer.eFrontToCRMTransform(webAddress, platform, schemaEnum),
                    entityId));
        }
        return Optional.empty();
    }

    private ElectronicAddressMessage createMessage(ElectronicAddress address, int linkedCRMEntityId) {
        ElectronicAddressMessage msg = new ElectronicAddressMessage();
        msg.setElectronicAddress(address);
        msg.setLinkedCRMEntityId(linkedCRMEntityId);
        return msg;
    }

    public void setEmailTransformer(EmailTransformer emailTransformer) {
        this.emailTransformer = emailTransformer;
    }

    public void setElectronicAddressTransformer(ElectronicAddressTransformer electronicAddressTransformer) {
        this.electronicAddressTransformer = electronicAddressTransformer;
    }
}
