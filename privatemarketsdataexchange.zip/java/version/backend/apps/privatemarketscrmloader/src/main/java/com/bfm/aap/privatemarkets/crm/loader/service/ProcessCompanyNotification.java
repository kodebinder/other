package com.bfm.aap.privatemarkets.crm.loader.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.stream.Collectors;

import javax.validation.constraints.NotNull;

import com.google.gson.JsonParser;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.CompanyResponse;
import com.bfm.aap.pmdx.proto.util.ProtoJsonHelper;
import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMResponseStatusEnum;
import com.bfm.aap.privatemarkets.crm.loader.integration.gateway.CompanyInverseProcessingGateway;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreCompanyInverseMessage;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.beam2.annotation.Param;
import com.bfm.entitymaster.dto.common.Entity;

import static com.bfm.aap.privatemarkets.crm.loader.util.CRMLoaderConstants.OBJECT_MAPPER;

@Service
public class ProcessCompanyNotification {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProcessCompanyNotification.class);

    private final CompanyInverseProcessingGateway companyInverseProcessingGateway;
    private final ExecutorService processNotificationExecutorService;
    private final CRMThirdPartyMapperService crmThirdPartyMapperService;
    public static final String MODIFIED_BY = "TSG_OPS";

    @Autowired
    public ProcessCompanyNotification(CompanyInverseProcessingGateway companyInverseProcessingGateway, ExecutorService processNotificationExecutorService, CRMThirdPartyMapperService crmThirdPartyMapperService) {
        this.companyInverseProcessingGateway = companyInverseProcessingGateway;
        this.processNotificationExecutorService = processNotificationExecutorService;
        this.crmThirdPartyMapperService = crmThirdPartyMapperService;
    }

    public Company process(Integer entityId, String modifiedBy) throws Exception {
    	validateNullValues(entityId,modifiedBy);
    	LOGGER.info("Received entityId : {},\nReceived modifiedBy : {}", entityId, modifiedBy);
        CRMLoaderResponse loaderResponse = companyInverseProcessingGateway.processMapEfrontCompany(new CoreCompanyInverseMessage(entityId, modifiedBy));
        if (loaderResponse.getStatus() == CRMResponseStatusEnum.FULL_SUCCESS) {
            LOGGER.info("Processing completed for entityID : {}", entityId);
            JsonParser jsonParser = new JsonParser();
            return ProtoJsonHelper.extractFromJson(jsonParser.parse(loaderResponse.getMessage()).getAsJsonObject(), Company.newBuilder());
        }
        throw new Exception(loaderResponse.getMessage());
    }


    public List<CompanyResponse> getCompanyResponsesFromFutures(List<Future<CompanyResponse.Builder>> companyResponseBuilderFutures) {
    	if(ObjectUtils.isEmpty(companyResponseBuilderFutures)) {
    		LOGGER.warn("Empty companyResponseBuilderFutures passed for method : {}", Thread.currentThread().getStackTrace()[0].getMethodName());
    	}
    	LOGGER.info("Received companyResponseBuilderFutures : {}", companyResponseBuilderFutures);
    	List<CompanyResponse> companyResponses = new ArrayList<>();
    	companyResponseBuilderFutures
                .forEach(companyResponseBuilderFuture -> {
                    try {
                        CompanyResponse.Builder companyResponseBuilder = companyResponseBuilderFuture.get(10L, TimeUnit.SECONDS);
                        if (companyResponseBuilderFuture.isDone()) {
                        	companyResponses.add(companyResponseBuilder.build());
                        }
                    } catch (InterruptedException | ExecutionException | TimeoutException exception) {
                        LOGGER.error("Company could not be extracted from CompanyFuture Object because of the error : ", exception);
                        Thread.currentThread().interrupt();
                    }
                });
        return companyResponses;
    }

    @NotNull
    public List<Future<CompanyResponse.Builder>> getCompanyResponseFutures( @Param("efrontId") List<String> eFrontIdList) {
    	if(ObjectUtils.isEmpty(eFrontIdList)) {
    		LOGGER.warn("Empty eFrontIdList passed for method : {}", Thread.currentThread().getStackTrace()[0].getMethodName());
    	}
    	LOGGER.info("Received efrontIdList : {}", eFrontIdList);
    	
    	Map<String, Entity> efrontEntityList = crmThirdPartyMapperService.getEntityThirdPartyByEfrontIdList(eFrontIdList, ThirdPartyMappingEnum.COMPANY_INVEST.getThirdPartySource())
            .entrySet()
            .stream()
            .collect(Collectors.toMap(entry -> OBJECT_MAPPER.convertValue(entry.getKey(), String.class),
                entry -> OBJECT_MAPPER.convertValue(entry.getValue(), Entity.class)));

        return eFrontIdList
                .stream()
                .map(eFrontId -> processNotificationExecutorService.submit(() -> {
                    CompanyResponse.Builder companyResponseBuilder = CompanyResponse.newBuilder();
                    try {
                        LOGGER.info("Creating the proto for Company with eFront id {}", eFrontId);
                        Entity entity = efrontEntityList.get(eFrontId);
                        int crmId = null != entity ? entity.getEntityId() : -1;
                        companyResponseBuilder.setData((crmId != -1) ?
                                this.process(crmId, MODIFIED_BY) : Company.getDefaultInstance());
                    } catch (Exception e) {
                        LOGGER.error("Company Proto creation failed for efront id {} with the exception: {}", eFrontId, e);
                        companyResponseBuilder.setMessage(e.getMessage());
                    } finally {
                        companyResponseBuilder.getDataBuilder().setCompanyId(eFrontId);
                    }
                    return companyResponseBuilder;
                })).collect(Collectors.toList());
    }
    
    private void validateNullValues(Integer entityId, String modifiedBy) {
    	if(ObjectUtils.isEmpty(entityId)) {
    		LOGGER.warn("Empty entityId passed for method : {}", Thread.currentThread().getStackTrace()[0].getMethodName());
    	}
    	if(StringUtils.isBlank(modifiedBy)) {
    		LOGGER.warn("Empty modifiedBy passed for method : {}", Thread.currentThread().getStackTrace()[0].getMethodName());
    	}
    }
}