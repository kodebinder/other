package com.bfm.aap.privatemarkets.crm.loader.integration.service;

import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorInverseMessage;
import com.bfm.entitymaster.dto.common.Decode;
import com.bfm.entitymaster.dto.note.Note;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Optional;

public class NotesInverseService {
    private static final String COMPANY_DESCRIPTION = "Company Description";
    private static final String ORG_DESCRIPTION = "ORG_BUS_OVERVW";

    public CoreInvestorInverseMessage translateToEfrontNotes(CoreInvestorInverseMessage coreInvestorInverseMessage) {
        List<Note> notes = coreInvestorInverseMessage.getNotes();
        if(CollectionUtils.isNotEmpty(notes)) {
            notes.stream().forEach(eachNote -> {

                boolean isCompanyDescription = Optional.ofNullable(eachNote)
                        .map(Note :: getTitle)
                        .orElse(StringUtils.EMPTY)
                        .equals(COMPANY_DESCRIPTION);

                boolean isOrgDescription = Optional.ofNullable(eachNote)
                        .map(Note :: getType)
                        .map(Decode:: getCode)
                        .orElse(StringUtils.EMPTY)
                        .equals(ORG_DESCRIPTION);

                if(isCompanyDescription && isOrgDescription) {
                    coreInvestorInverseMessage.setEfrontEntity(Investor
                            .newBuilder(coreInvestorInverseMessage.getEfrontEntity())
                            .setDescription(eachNote.getNote())
                            .build());
                }
            });
        }
        return coreInvestorInverseMessage;
    }
}