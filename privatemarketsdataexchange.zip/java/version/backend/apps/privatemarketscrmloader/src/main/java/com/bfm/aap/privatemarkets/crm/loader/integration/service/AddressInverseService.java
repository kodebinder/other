package com.bfm.aap.privatemarkets.crm.loader.integration.service;

import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.privatemarkets.crm.loader.mapper.AddressInverseTransformer;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreCompanyInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreContactInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorInverseMessage;
import com.bfm.entitymaster.dto.common.Address;
import com.bfm.entitymaster.dto.organization.OrganizationDetail;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Optional;

public class AddressInverseService {

    @Autowired
    AddressInverseTransformer addressInverseTransformer;

    public AddressInverseService() {
    }

    public AddressInverseService(AddressInverseTransformer addressInverseTransformer) {
        this.addressInverseTransformer = addressInverseTransformer;
    }

    public CoreContactInverseMessage translateToEfrontAddress(CoreContactInverseMessage coreContactInverseMessage) {

        return coreContactInverseMessage;
    }

    public CoreCompanyInverseMessage translateToEfrontAddress(CoreCompanyInverseMessage coreCompanyInverseMessage) {
        Address address = Optional.ofNullable(coreCompanyInverseMessage.getOrganization())
                .map(OrganizationDetail::getPrimaryAddress)
                .orElse(new Address());
        coreCompanyInverseMessage.setEfrontEntity(
                Company.newBuilder(coreCompanyInverseMessage.getEfrontEntity()).addOfficeAddressList(addressInverseTransformer.crmToEfrontTransform(address)).build());
        return coreCompanyInverseMessage;
    }

    public CoreInvestorInverseMessage translateToEfrontAddress(CoreInvestorInverseMessage coreInvestorInverseMessage) {
        Address address = Optional.ofNullable(coreInvestorInverseMessage.getOrganization())
                .map(OrganizationDetail::getPrimaryAddress)
                .orElse(new Address());
        coreInvestorInverseMessage.setEfrontEntity(
                Investor.newBuilder(coreInvestorInverseMessage.getEfrontEntity()).addOfficeAddressList(addressInverseTransformer.crmToEfrontTransform(address)).build());
        return coreInvestorInverseMessage;
    }
}
