package com.bfm.aap.privatemarkets.crm.loader.integration.service;

public interface TransformerService<T, U> {
    T transform(U o) throws Exception;
}
