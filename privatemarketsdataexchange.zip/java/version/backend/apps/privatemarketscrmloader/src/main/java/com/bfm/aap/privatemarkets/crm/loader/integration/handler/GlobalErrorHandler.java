package com.bfm.aap.privatemarkets.crm.loader.integration.handler;

import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMResponseStatusEnum;
import org.springframework.messaging.MessageHandlingException;

public class GlobalErrorHandler {

    public CRMLoaderResponse handleError(MessageHandlingException messageException) {
        return CRMLoaderResponse.newBuilder()
                .setStatus(CRMResponseStatusEnum.ERROR)
                .setMessage(messageException.getMessage())
                .build();
    }
}
