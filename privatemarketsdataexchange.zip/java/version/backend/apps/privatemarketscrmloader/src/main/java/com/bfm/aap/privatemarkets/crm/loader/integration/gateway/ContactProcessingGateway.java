package com.bfm.aap.privatemarkets.crm.loader.integration.gateway;

import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;

public interface ContactProcessingGateway {
    CRMLoaderResponse processMapCRMContact(Contact contact);
}
