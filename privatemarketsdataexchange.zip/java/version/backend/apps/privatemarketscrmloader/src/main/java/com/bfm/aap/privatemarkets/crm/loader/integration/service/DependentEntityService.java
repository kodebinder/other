package com.bfm.aap.privatemarkets.crm.loader.integration.service;

import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.pmdx.model.util.SchemaEnum;
import com.bfm.aap.privatemarkets.crm.loader.mapper.EmploymentRelTransformer;
import com.bfm.aap.privatemarkets.crm.loader.mapper.EntityRelationshipTransformer;
import com.bfm.aap.privatemarkets.crm.loader.mapper.NoteTransformer;
import com.bfm.aap.privatemarkets.crm.loader.model.AddressMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.AliasMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreCompanyMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreContactMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.ElectronicAddressMessage;
import com.bfm.aap.privatemarkets.common.crm.model.CRMChannelResponse;
import com.bfm.aap.privatemarkets.common.crm.model.EntityType;
import com.bfm.aap.privatemarkets.crm.loader.service.CRMLoaderCoreService;
import com.bfm.aap.privatemarkets.crm.loader.util.CustomEntityComparator;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.entitymaster.dto.alias.Alias;
import com.bfm.entitymaster.dto.common.Address;
import com.bfm.entitymaster.dto.common.ElectronicAddress;
import com.bfm.entitymaster.dto.entityrelationship.Employment;
import com.bfm.entitymaster.dto.entityrelationship.Relationship;
import com.bfm.entitymaster.dto.note.Note;
import com.bfm.util.BFMDate;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class DependentEntityService {
    private static final Logger LOGGER = LoggerFactory.getLogger(DependentEntityService.class);
    private static final String COMPANY_DESCRIPTION = "Company Description";
    private static final String USER = "user";
    private static final String EMPLOYMENT = "EMPLOYMENT";
    private static final String EMPLOYER = "EMPLOYER";
    private static final String ORGANIZATIONAL = "ORGANIZATIONAL";
    private static final String PARENT = "PARENT";
    private static final String SUBCOMPANY = "SUBCOMPANY";
    private static final String PARENT_COMPANY_ID = "parentCompanyId";
    private static final String SUBSIDIARY_OF_ID = "subsidiaryOfId";
    public static final String DESCRIPTION = "description";
    private static final String MAIN_CONTACT_ID = "mainContactId";
    private static final String COMPANY_ID = "companyId";

    @Autowired
    private CRMLoaderCoreService crmCoreService;
    @Autowired
    private CRMThirdPartyMapperService crmThirdPartyMapperService;
    @Autowired
    private NoteTransformer noteTransformer;
    @Autowired
    private EntityRelationshipTransformer relationshipTransformer;
    @Autowired
    private EmploymentRelTransformer employmentRelTransformer;

    @RecordStats
    public CRMChannelResponse createCRMAddress(Message<AddressMessage> msg) {
        AddressMessage addressMessage = msg.getPayload();
        String user = (String) msg.getHeaders().get(USER);
        if (null != addressMessage.getCrmAddress()) {
            try {
                Optional<Address> address = Optional.ofNullable(crmCoreService.createContactAddress(addressMessage.getLinkedCRMEntityId(), addressMessage.getCrmAddress(), user));
                if (address.isPresent()) {
                    addressMessage.getCrmAddress().setAddressId(address.get().getAddressId());
                    crmThirdPartyMapperService.create(addressMessage.getPmdxAddress().getId(), address.get().getAddressId(), ThirdPartyMappingEnum.ADDRESS_INVEST);
                    LOGGER.info("success - Address: createCRMAddress - EntityId:{}, EFront-AddressId:{}", addressMessage.getLinkedCRMEntityId(), addressMessage.getPmdxAddress().getId());
                    return buildResponse(addressMessage.getLinkedCRMEntityId(), addressMessage.getCrmAddress().getAddressId(), true, EntityType.ADDRESS_VALUE);
                }
            } catch (Exception e) {
                LOGGER.info("Exception in createCRMAddress: CoreEntityId:{}, {}", addressMessage.getLinkedCRMEntityId(), e);
            }
            return buildResponse(addressMessage.getLinkedCRMEntityId(), -1, false, EntityType.ADDRESS_VALUE);
        } else {
            return buildResponse(addressMessage.getLinkedCRMEntityId(), -1, true, EntityType.ADDRESS_VALUE);
        }

    }

    @RecordStats
    public CRMChannelResponse createElectronicAddress(Message<ElectronicAddressMessage> msg) {
        ElectronicAddressMessage eMessage = msg.getPayload();
        String user = (String) msg.getHeaders().get(USER);
        try {
            Optional<ElectronicAddress> ea = Optional.ofNullable(crmCoreService.createContactElectronicAddress(eMessage.getLinkedCRMEntityId(), eMessage.getElectronicAddress(), user));
            if (ea.isPresent()) {
                eMessage.getElectronicAddress().setElectronicAddressId(ea.get().getElectronicAddressId());
                LOGGER.info("success - ElectroniAddress: createElectronicAddress - EntityId:{}", eMessage.getLinkedCRMEntityId());
                return buildResponse(eMessage.getLinkedCRMEntityId(), ea.get().getElectronicAddressId(), true, EntityType.EMAIL_VALUE);
            }
        } catch (Exception e) {
            LOGGER.info("Exception in createElectronicAddress: CoreEntityId:{}, {}", eMessage.getLinkedCRMEntityId(), e);
        }
        return buildResponse(eMessage.getLinkedCRMEntityId(), -1, false, EntityType.EMAIL_VALUE);
    }

    @RecordStats
    public AddressMessage populateAddressCRMEntityId(AddressMessage msg) {
        int entityId = crmThirdPartyMapperService.lookUp(msg.getPmdxAddress().getId(), ThirdPartyMappingEnum.ADDRESS_INVEST);
        msg.getCrmAddress().setAddressId(entityId);
        return msg;
    }

    @RecordStats
    public CRMChannelResponse handleAddressUpdate(Message<AddressMessage> msg) {
        AddressMessage aMsg = msg.getPayload();
        String user = (String) msg.getHeaders().get(USER);
        try {
            if (null != aMsg.getCrmAddress() && null != aMsg.getCrmAddress().getAddressId() && aMsg.getCrmAddress().getAddressId() > 0) {
                Address currentAddress = crmCoreService.getAddress(aMsg.getCrmAddress().getAddressId(), user);
                if (CustomEntityComparator.compareAddress.compare(aMsg.getCrmAddress(), currentAddress) != 0) {
                    Optional<Address> address = Optional.ofNullable(crmCoreService.updateContactAddress(aMsg.getLinkedCRMEntityId(), aMsg.getCrmAddress(), user));
                    if (address.isPresent() && CustomEntityComparator.compareAddress.compare(address.get(), aMsg.getCrmAddress()) == 0) {
                        LOGGER.info("success - Address: handleAddressUpdate - EntityId:{}, EFront-AddressId:{}", aMsg.getLinkedCRMEntityId(), aMsg.getPmdxAddress().getId());
                        return buildResponse(aMsg.getLinkedCRMEntityId(), address.get().getAddressId(), true, EntityType.ADDRESS_VALUE);
                    }
                }
            } else {
                return createCRMAddress(msg);
            }
        } catch (Exception e) {
            LOGGER.info("Exception in handleAddressUpdate: CoreEntityId:{}, {}", aMsg.getLinkedCRMEntityId(), e);
        }
        return buildResponse(aMsg.getLinkedCRMEntityId(), -1, false, EntityType.ADDRESS_VALUE);
    }


    /*
        TODO: Open decision item for business on the contact attribute wiki.
        Currently this will add new electronic address and keep the existing one inplace.
     */
    @RecordStats
    public CRMChannelResponse handleElectronicAddressUpdate(Message<ElectronicAddressMessage> msg) {
        ElectronicAddressMessage eMessage = msg.getPayload();
        String user = (String) msg.getHeaders().get(USER);
        try {
            List<ElectronicAddress> eaList = crmCoreService.getElectronicAddressByEntityId(eMessage.getLinkedCRMEntityId(), user);
            if (CollectionUtils.isNotEmpty(eaList)
                    && eaList.stream().noneMatch(ea -> CustomEntityComparator.compareElectronicAddress.compare(ea, eMessage.getElectronicAddress()) == 0)) {
                Optional<ElectronicAddress> eaAddress = Optional.ofNullable(crmCoreService.createContactElectronicAddress(eMessage.getLinkedCRMEntityId(), eMessage.getElectronicAddress(), user));
                if (eaAddress.isPresent() && CustomEntityComparator.compareElectronicAddress.compare(eaAddress.get(), eMessage.getElectronicAddress()) == 0) {
                    LOGGER.info("success - ElectronicAddress: handleElectronicAddressUpdate - EntityId:{}", eMessage.getLinkedCRMEntityId());
                    return buildResponse(eMessage.getLinkedCRMEntityId(), eaAddress.get().getElectronicAddressId(), true, EntityType.EMAIL_VALUE);
                }
            } else {
                return createElectronicAddress(msg);
            }
        } catch (Exception e) {
            LOGGER.info("Exception in handleElectronicAddressUpdate: CoreEntityId:{}, {}", eMessage.getLinkedCRMEntityId(), e);
        }
        return buildResponse(eMessage.getLinkedCRMEntityId(), -1, false, EntityType.EMAIL_VALUE);
    }

    @RecordStats
    public CRMChannelResponse createOrgAlias(Message<AliasMessage> msg) {
        AliasMessage aMessage = msg.getPayload();
        String user = (String) msg.getHeaders().get(USER);
        Optional<Alias> ea = Optional.ofNullable(crmCoreService.createEntityAliasCRM(aMessage.getLinkedCRMEntityId(), aMessage.getAlias(), user));
        if (ea.isPresent()) {
            aMessage.getAlias().setAliasId(ea.get().getAliasId());
            LOGGER.info("success - CompanyAlias: createCompanyAlias - EntityId:{}", aMessage.getLinkedCRMEntityId());
            return buildResponse(aMessage.getLinkedCRMEntityId(), ea.get().getAliasId(), true, EntityType.ENTITY_ALIAS_VALUE);
        }
        return buildResponse(aMessage.getLinkedCRMEntityId(), -1, false, EntityType.ENTITY_ALIAS_VALUE);
    }

    @RecordStats
    public CRMChannelResponse handleOrgAliasUpdate(Message<AliasMessage> msg) {
        AliasMessage aMessage = msg.getPayload();
        String user = (String) msg.getHeaders().get(USER);
        try {
            List<Alias> aliasList = crmCoreService.getEntityAliasByEntityIdCRM(aMessage.getLinkedCRMEntityId(), user);
            if (CollectionUtils.isNotEmpty(aliasList) &&
                    aliasList.stream().filter(Objects::nonNull)
                            .anyMatch(a -> checkIfAliasesDifferInContent(a, aMessage.getAlias()))) {
                Optional<Alias> oldAlias = aliasList.stream().filter(Objects::nonNull)
                        .filter(a -> checkIfAliasesDifferInContent(a, aMessage.getAlias()))
                        .findFirst();
                Alias oldAliasVal = oldAlias.isPresent() ? oldAlias.get() : new Alias();
                oldAliasVal.setAliasName(aMessage.getAlias().getAliasName());
                oldAliasVal.setAliasType(aMessage.getAlias().getAliasType());
                crmCoreService.updateEntityAliasCRM(aMessage.getLinkedCRMEntityId(), oldAliasVal, user);
                LOGGER.info("success - CompanyAlias: handleCompanyAliasUpdate - EntityId:{}", aMessage.getLinkedCRMEntityId());
                return buildResponse(aMessage.getLinkedCRMEntityId(), oldAliasVal.getAliasId(), true, EntityType.ENTITY_ALIAS_VALUE);
            } else {
                return createOrgAlias(msg);
            }
        } catch (Exception e) {
            LOGGER.info("Exception in handleCompanyAliasUpdate: CoreEntityId:{}, {}", aMessage.getLinkedCRMEntityId(), e);
            return buildResponse(aMessage.getLinkedCRMEntityId(), -1, false, EntityType.ENTITY_ALIAS_VALUE);
        }
    }

    private boolean checkIfAliasesDifferInContent(Alias a1, Alias a2) {
        return a1.getAliasType().getCode().equals(a2.getAliasType().getCode()) && !a1.getAliasName().equalsIgnoreCase(a2.getAliasName());
    }

    /*TODO: Not possible to find old note to update as eFront doesn't sent ID on note. So Mapping the notes by NoteType for create/update
     */
    @RecordStats
    public CRMChannelResponse handleCompanyDescCreateOrUpdate(Message<CoreCompanyMessage> msg) {
        CoreCompanyMessage cMessage = msg.getPayload();
        String user = (String) msg.getHeaders().get(USER);
        try {
            List<Note> noteList = crmCoreService.getNotesByEntityIdCRM(cMessage.getOrgEntity().getEntityId(), user);
            Note newNote = noteTransformer.eFrontToCRMTransform(cMessage.getOrgEntity().getEntityId(), COMPANY_DESCRIPTION, cMessage.getCompany().getDescription(), DESCRIPTION, SchemaEnum.EFRONT_COMPANY_SCHEMA);
            LOGGER.info("success - CompanyDesc: handleCompanyDescCreateOrUpdate - EntityId:{}", cMessage.getCompany().getCompanyId());
            return processCompanyDescription(noteList, newNote, user);
        } catch (Exception e) {
            LOGGER.info("Exception in handleCompanyDescCreateOrUpdate: CoreEntityId:{}, {}", cMessage.getOrgEntity().getEntityId(), e);
        }
        return buildResponse(cMessage.getOrgEntity().getEntityId(), -1, false, EntityType.NOTE_VALUE);
    }

    /*TODO: Not possible to find old note to update as eFront doesn't sent ID on note. So Mapping the notes by NoteType for create/update
     */
    @RecordStats
    public CRMChannelResponse handleInvestorDescCreateOrUpdate(Message<CoreInvestorMessage> msg) {
        CoreInvestorMessage iMessage = msg.getPayload();
        String user = (String) msg.getHeaders().get(USER);
        try {
            List<Note> noteList = crmCoreService.getNotesByEntityIdCRM(iMessage.getOrgEntity().getEntityId(), user);
            Note newNote = noteTransformer.eFrontToCRMTransform(iMessage.getOrgEntity().getEntityId(), COMPANY_DESCRIPTION, iMessage.getInvestor().getDescription(), DESCRIPTION, SchemaEnum.EFRONT_INVESTOR_SCHEMA);
            LOGGER.info("success - CompanyDesc: handleInvestorDescCreateOrUpdate - EntityId:{}", iMessage.getInvestor().getInvestorId());
            return processCompanyDescription(noteList, newNote, user);
        } catch (Exception e) {
            LOGGER.info("Exception in handleCompanyDescCreateOrUpdate: CoreEntityId:{}, {}", iMessage.getOrgEntity().getEntityId(), e);
        }
        return buildResponse(iMessage.getOrgEntity().getEntityId(), -1, false, EntityType.NOTE_VALUE);
    }

    private CRMChannelResponse processCompanyDescription(List<Note> noteList, Note newNote, String user) {
        if (CollectionUtils.isNotEmpty(noteList)) {
            Optional<Note> existingNote = noteList.stream()
                    .filter(Objects::nonNull)
                    .filter(n -> n.getType().getCode().equalsIgnoreCase(newNote.getType().getCode()))
                    .findFirst();
            if (!existingNote.isPresent()) {
                return createNewNote(newNote, user);
            } else {
                existingNote.get().setNote(newNote.getNote());
                Note response = crmCoreService.updateEntityNoteCRM(existingNote.get(), user);
                return buildResponse(response.getEntityId(), response.getNoteId(), true, EntityType.NOTE_VALUE);
            }
        } else {
            return createNewNote(newNote, user);
        }
    }

    private CRMChannelResponse createNewNote(Note newNote, String user) {
        Note response = crmCoreService.createEntityNoteCRM(newNote, user);
        return buildResponse(response.getEntityId(), response.getNoteId(), true, EntityType.NOTE_VALUE);
    }

    @RecordStats
    public CRMChannelResponse handleCompanyToParentCompanyRelationshipCreateOrUpdate(Message<CoreCompanyMessage> msg) {
        CoreCompanyMessage cMsg = msg.getPayload();
        if (StringUtils.isNotBlank(cMsg.getCompany().getParentCompanyId())) {
            int parentCompanyEntityId = crmThirdPartyMapperService.lookUp(cMsg.getCompany().getParentCompanyId(), ThirdPartyMappingEnum.COMPANY_INVEST);
            if (parentCompanyEntityId > 0) {
                return createRelationship(cMsg.getOrgEntity().getEntityId(), parentCompanyEntityId,
                        ORGANIZATIONAL, PARENT, false, EntityType.COMPANY_PARENT_REL_VALUE, cMsg.getUser(), PARENT_COMPANY_ID, SchemaEnum.EFRONT_COMPANY_SCHEMA);
            } else {
                LOGGER.info("Failed - OrgRel: handleCompanyToParentCompanyRelationshipCreateOrUpdate - EntityId:{}", cMsg.getCompany().getParentCompanyId());
                return buildResponse(cMsg.getOrgEntity().getEntityId(), -1, false, EntityType.COMPANY_PARENT_REL_VALUE);
            }
        } else {
            LOGGER.info("Success - No OrgRel: handleCompanyToParentCompanyRelationshipCreateOrUpdate - EntityId:{}", cMsg.getCompany().getParentCompanyId());
            return buildResponse(cMsg.getOrgEntity().getEntityId(), -1, true, EntityType.COMPANY_PARENT_REL_VALUE);
        }
    }

    @RecordStats
    public CRMChannelResponse handleCompanyToSubsidiaryCompanyRelationshipCreateOrUpdate(Message<CoreCompanyMessage> msg) {
        CoreCompanyMessage cMsg = msg.getPayload();
        if (StringUtils.isNotBlank(cMsg.getCompany().getSubsidiaryOfId())) {
            int subsidiaryEntityId = crmThirdPartyMapperService.lookUp(cMsg.getCompany().getSubsidiaryOfId(), ThirdPartyMappingEnum.COMPANY_INVEST);
            if (subsidiaryEntityId > 0) {
                return createRelationship(cMsg.getOrgEntity().getEntityId(), subsidiaryEntityId,
                        ORGANIZATIONAL, SUBCOMPANY, false, EntityType.COMPANY_SUBSIDIARY_REL_VALUE, cMsg.getUser(), SUBSIDIARY_OF_ID, SchemaEnum.EFRONT_COMPANY_SCHEMA);
            } else {
                LOGGER.info("Failed - OrgRel: handleCompanyToSubsidiaryCompanyRelationshipCreateOrUpdate - EntityId:{}", cMsg.getCompany().getSubsidiaryOfId());
                return buildResponse(cMsg.getOrgEntity().getEntityId(), -1, false, EntityType.COMPANY_SUBSIDIARY_REL_VALUE);
            }
        } else {
            LOGGER.info("Success - No OrgRel: handleCompanyToSubsidiaryCompanyRelationshipCreateOrUpdate - EntityId:{}", cMsg.getCompany().getSubsidiaryOfId());
            return buildResponse(cMsg.getOrgEntity().getEntityId(), -1, true, EntityType.COMPANY_SUBSIDIARY_REL_VALUE);
        }
    }

    @RecordStats
    public CRMChannelResponse handleContactCompanyRelationshipCreateOrUpdate(Message<CoreContactMessage> msg) {
        CoreContactMessage cMsg = msg.getPayload();
        if (StringUtils.isNotBlank(cMsg.getPmdxContact().getCompanyId())) {
            int companyEntityId = crmThirdPartyMapperService.lookUp(cMsg.getPmdxContact().getCompanyId(), ThirdPartyMappingEnum.COMPANY_INVEST);
            if (companyEntityId > 0) {

                return createEmploymentRel(cMsg.getCrmContact().getEntityId(), companyEntityId,
                        false, EntityType.CONTACT_COMPANY_REL_VALUE, cMsg.getUser(),
                        cMsg.getPmdxContact().getPosition());
            } else {
                LOGGER.info("Failed - OrgRel: handleContactCompanyRelationshipCreateOrUpdate - EntityId:{}", cMsg.getPmdxContact().getCompanyId());
                return buildResponse(cMsg.getCrmContact().getEntityId(), -1, false, EntityType.CONTACT_COMPANY_REL_VALUE);
            }
        } else {
            LOGGER.info("Success - No OrgRel: handleContactCompanyRelationshipCreateOrUpdate - EntityId:{}", cMsg.getPmdxContact().getCompanyId());
            return buildResponse(cMsg.getCrmContact().getEntityId(), -1, true, EntityType.CONTACT_COMPANY_REL_VALUE);
        }
    }

    private CRMChannelResponse createEmploymentRel(Integer employeeEntityId, int employerEntityId,
                                                   boolean isPrimaryOrg, int entityTypeEnum, String user,
                                                   String position) {
        try {
            Employment newEmp = employmentRelTransformer.eFrontToCRMTransform(employerEntityId, employeeEntityId,
                    new BFMDate(System.currentTimeMillis()),
                    null, isPrimaryOrg,
                    position);
            List<Employment> employmentList = crmCoreService.getEmployerByEntityId(employeeEntityId, user);
            if (CollectionUtils.isNotEmpty(employmentList)) {
                return processEmploymentRelUpdate(entityTypeEnum, newEmp, employmentList, user);
            } else {
                return processEmploymentRelCreate(newEmp, entityTypeEnum, user);
            }
        } catch (Exception e) {
            LOGGER.info("Exception in createRelationship: CoreEntityId:{} {}, {}", employeeEntityId, employerEntityId, e);
            return buildResponse(employeeEntityId, employerEntityId, false, entityTypeEnum);
        }
    }

    private CRMChannelResponse processEmploymentRelUpdate(int entityTypeEnum, Employment newEmp, List<Employment> employmentList, String user) {
        Optional<Employment> existingRel = employmentList.stream()
                .filter(r -> (r.getEmployeeEntityId().intValue() == newEmp.getEmployeeEntityId().intValue()
                        && r.getEmployerEntityId().intValue() == newEmp.getEmployerEntityId().intValue()))
                .findFirst();
        if (existingRel.isPresent()) {
            return buildResponse(newEmp.getEmployeeEntityId(), newEmp.getEmployerEntityId(), true, entityTypeEnum);
        } else {
            return processEmploymentRelCreate(newEmp, entityTypeEnum, user);
        }
    }

    private CRMChannelResponse processEmploymentRelCreate(Employment newEmp, int entityTypeEnum, String user) {
        Employment e = crmCoreService.createEmployment(newEmp, user);
        if (null != e && null != e.getEmploymentId()) {
            LOGGER.info("Success - OrgRel: processEmploymentRelCreate - EntityIds:{},{}", newEmp.getEmployeeEntityId(), newEmp.getEmployerEntityId());
            return buildResponse(e.getEmployeeEntityId(), e.getEmployerEntityId(), true, entityTypeEnum);
        }
        LOGGER.info("Failed - OrgRel: processEmploymentRelCreate - EntityIds:{},{}", newEmp.getEmployeeEntityId(), newEmp.getEmployerEntityId());
        return buildResponse(newEmp.getEmployeeEntityId(), newEmp.getEmployerEntityId(), false, entityTypeEnum);
    }

    private CRMChannelResponse createRelationship(Integer firstEntityId, int secondEntityId,
                                                  String relationshipCategory, String relationshipSubCategory,
                                                  boolean primaryRelationship, int entityTypeEnum, String user,
                                                  String attribute, SchemaEnum schema) {
        try {
            Relationship newRel = relationshipTransformer.eFrontToCRMTransform(firstEntityId, secondEntityId,
                    new BFMDate(System.currentTimeMillis()),
                    new BFMDate(BFMDate.max_date), primaryRelationship, attribute, schema);
            List<Relationship> relList = crmCoreService.getEntityRelationship(firstEntityId, secondEntityId, relationshipCategory, relationshipSubCategory, user);
            if (CollectionUtils.isNotEmpty(relList)) {
                return processRelationshipUpdate(entityTypeEnum, newRel, relList, user);
            } else {
                return processRelationshipCreate(newRel, entityTypeEnum, user);
            }
        } catch (Exception e) {
            LOGGER.info("Exception in createRelationship: CoreEntityId:{}, {}", firstEntityId, e);
            return buildResponse(firstEntityId, -1, false, entityTypeEnum);
        }
    }

    private CRMChannelResponse processRelationshipUpdate(int entityTypeEnum, Relationship newRel, List<Relationship> relList, String user) {
        Optional<Relationship> existingRel = relList.stream()
                .filter(r -> (r.getFirstEntityId().intValue() == newRel.getFirstEntityId().intValue()
                        && r.getSecondEntityId().intValue() == newRel.getSecondEntityId().intValue()))
                .findFirst();
        if (existingRel.isPresent() && CustomEntityComparator.compareRelationship.compare(existingRel.get(), newRel) == 0) {
            LOGGER.info("Success - No Change OrgRel: processRelationshipUpdate - EntityIds:{},{}", newRel.getFirstEntityId(), newRel.getSecondEntityId());
            return buildResponse(newRel.getFirstEntityId(), existingRel.get().getRelationshipId(), true, entityTypeEnum);
        } else if (existingRel.isPresent() && CustomEntityComparator.compareRelationship.compare(existingRel.get(), newRel) != 0) {
            LOGGER.info("Success - Updated OrgRel: processRelationshipUpdate - EntityIds:{},{}", newRel.getFirstEntityId(), newRel.getSecondEntityId());
            Relationship updatedRel = crmCoreService.updateRelationship(existingRel.get().getRelationshipId(), newRel, user);
            return buildResponse(updatedRel.getFirstEntityId(), updatedRel.getRelationshipId(), true, entityTypeEnum);
        } else {
            return processRelationshipCreate(newRel, entityTypeEnum, user);
        }
    }

    private CRMChannelResponse processRelationshipCreate(Relationship rel, int entityTypeEnum, String user) {
        Relationship r = crmCoreService.createRelationship(rel, user);
        if (null != r && null != r.getRelationshipId()) {
            LOGGER.info("Success - Created OrgRel: processRelationshipUpdate - EntityIds:{},{}", rel.getFirstEntityId(), rel.getSecondEntityId());
            return buildResponse(rel.getFirstEntityId(), r.getRelationshipId(), true, entityTypeEnum);
        }
        LOGGER.info("Failed - OrgRel: processRelationshipUpdate - EntityIds:{},{}", rel.getFirstEntityId(), rel.getSecondEntityId());
        return buildResponse(rel.getFirstEntityId(), -1, false, entityTypeEnum);
    }

    private CRMChannelResponse buildResponse(int linkedCRMEntityId, int entityId, boolean status, int entityType) {
        return CRMChannelResponse.newBuilder()
                .setCoreEntityId(linkedCRMEntityId)
                .setEntityId(entityId)
                .setStatus(status)
                .setEntityTypeValue(entityType)
                .build();
    }

    public void setCrmCoreService(CRMLoaderCoreService crmCoreService) {
        this.crmCoreService = crmCoreService;
    }

    public void setCrmThirdPartyMapperService(CRMThirdPartyMapperService crmThirdPartyMapperService) {
        this.crmThirdPartyMapperService = crmThirdPartyMapperService;
    }

    public void setRelationshipTransformer(EntityRelationshipTransformer relationshipTransformer) {
        this.relationshipTransformer = relationshipTransformer;
    }

    public void setNoteTransformer(NoteTransformer noteTransformer) {
        this.noteTransformer = noteTransformer;
    }
}
