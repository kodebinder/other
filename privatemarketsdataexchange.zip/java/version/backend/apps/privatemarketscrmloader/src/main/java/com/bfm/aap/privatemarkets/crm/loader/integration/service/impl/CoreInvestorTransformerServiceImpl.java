package com.bfm.aap.privatemarkets.crm.loader.integration.service.impl;

import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.privatemarkets.crm.loader.mapper.EntityTransformer;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorMessage;
import com.bfm.aap.privatemarkets.crm.loader.util.DecodeHelper;
import com.bfm.aap.privatemarkets.common.crm.util.EntityMasterDecodeTableConstants;
import com.bfm.aap.privatemarkets.crm.loader.integration.service.TransformerService;
import com.bfm.entitymaster.dto.common.Decode;
import com.bfm.entitymaster.dto.organization.OrganizationType;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import static com.bfm.aap.privatemarkets.common.crm.util.EntityMasterDecodeTableConstants.DX_EM_ORGANIZATION_SUB_TYPE;
import static com.bfm.aap.privatemarkets.common.crm.util.EntityMasterDecodeTableConstants.DX_EM_ORGANIZATION_TYPE;

public class CoreInvestorTransformerServiceImpl implements TransformerService<CoreInvestorMessage, Investor> {

    private static final Logger LOGGER = LoggerFactory.getLogger(CoreInvestorTransformerServiceImpl.class);

    private static final String ORG = "O";
    private static final String UNKNOWN = "UNKNOWN0";

    @Autowired
    private EntityTransformer entityTransformer;

    @Override
    public CoreInvestorMessage transform(Investor investor) throws Exception {
        CoreInvestorMessage msg = new CoreInvestorMessage();
        msg.setInvestor(investor);
        msg.setOrgEntity(entityTransformer.eFrontToCRMTransform(investor.getName(), ORG));
        msg.setOrganizationType(getOrganizationType(investor));
        //TODO: Do we need domicile at the entity level? It's available at the legal attributes level
        msg.setCountryDecode(getDomicile(investor));
        LOGGER.info("success: End of Investor transform: {}",investor.getInvestorId());
        return msg;
    }

    private Decode getDomicile(Investor investor) {
        if (null != investor &&
                null != investor.getLegal() &&
                null != investor.getLegal().getLegalDomicileCountry() &&
                StringUtils.isNotBlank(investor.getLegal().getLegalDomicileCountry()))
            return DecodeHelper.getDecode(EntityMasterDecodeTableConstants.COUNTRIES,
                    investor.getLegal().getLegalDomicileCountry());
        return null;
    }

    private OrganizationType getOrganizationType(Investor investor) {
        OrganizationType organizationType = new OrganizationType();
        if (StringUtils.isNotBlank(investor.getInvestorType())) {
            organizationType.setOrganizationType(DecodeHelper.getDecode(DX_EM_ORGANIZATION_TYPE, investor.getInvestorType()));
            organizationType.setOrganizationSubType(DecodeHelper.getDecode(DX_EM_ORGANIZATION_SUB_TYPE, UNKNOWN));
        }
        return organizationType;
    }

    public void setEntityTransformer(EntityTransformer entityTransformer) {
        this.entityTransformer = entityTransformer;
    }
}
