package com.bfm.aap.privatemarkets.crm.loader.integration.gateway;

import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorInverseMessage;
import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;

public interface InvestorInverseProcessingGateway {
    CRMLoaderResponse mapEfrontInvestor(CoreInvestorInverseMessage coreInvestorInverseMessage);
}
