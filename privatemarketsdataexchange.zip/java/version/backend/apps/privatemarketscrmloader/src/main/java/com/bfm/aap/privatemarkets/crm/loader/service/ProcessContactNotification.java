package com.bfm.aap.privatemarkets.crm.loader.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.stream.Collectors;

import javax.validation.constraints.NotNull;

import com.google.gson.JsonParser;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.ContactResponse;
import com.bfm.aap.pmdx.proto.util.ProtoJsonHelper;
import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMResponseStatusEnum;
import com.bfm.aap.privatemarkets.crm.loader.integration.gateway.ContactInverseProcessingGateway;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreContactInverseMessage;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.beam2.annotation.Param;
import com.bfm.entitymaster.dto.common.Entity;

import static com.bfm.aap.pmdx.model.ContactResponse.newBuilder;
import static com.bfm.aap.privatemarkets.crm.loader.util.CRMLoaderConstants.OBJECT_MAPPER;

@Service
public class ProcessContactNotification {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProcessContactNotification.class);

    private final ContactInverseProcessingGateway contactInverseProcessingGateway;
    private final ExecutorService processNotificationExecutorService;
    private final CRMThirdPartyMapperService crmThirdPartyMapperService;
    public static final String MODIFIED_BY = "TSG_OPS";

    @Autowired
    public ProcessContactNotification(ContactInverseProcessingGateway contactInverseProcessingGateway,
                                      ExecutorService processNotificationExecutorService, CRMThirdPartyMapperService crmThirdPartyMapperService) {
        this.contactInverseProcessingGateway = contactInverseProcessingGateway;
        this.processNotificationExecutorService = processNotificationExecutorService;
        this.crmThirdPartyMapperService = crmThirdPartyMapperService;
    }

    public Contact process(Integer entityId, String modifiedBy) throws Exception {
        validateNullValues(entityId, modifiedBy);
        LOGGER.info("Received entityId : {},\nReceived modifiedBy : {}", entityId, modifiedBy);
        CRMLoaderResponse loaderResponse = contactInverseProcessingGateway.processMapEfrontContact(new CoreContactInverseMessage(entityId, modifiedBy));
        if (loaderResponse.getStatus() == CRMResponseStatusEnum.FULL_SUCCESS) {
            LOGGER.info("Processing completed for entityID : {}", entityId);
            JsonParser jsonParser = new JsonParser();
            return ProtoJsonHelper.extractFromJson(jsonParser.parse(loaderResponse.getMessage()).getAsJsonObject(), Contact.newBuilder());
        }
        throw new Exception(loaderResponse.getMessage());
    }

    public List<ContactResponse> getContactResponsesFromFutures(List<Future<ContactResponse.Builder>> contactResponseBuilderFutures) {
    	if(ObjectUtils.isEmpty(contactResponseBuilderFutures)) {
    		LOGGER.warn("Empty contactResponseBuilderFutures passed for method : {}", Thread.currentThread().getStackTrace()[0].getMethodName());
    	}
    	LOGGER.info("Received contactResponseBuilderFutures : {}", contactResponseBuilderFutures);
    	List<ContactResponse> contactResponses = new ArrayList<>();
        contactResponseBuilderFutures
                .stream()
                .forEach(contactResponseBuilderFuture -> {
                    try {
                        ContactResponse.Builder contactResponseBuilder = contactResponseBuilderFuture.get(10L, TimeUnit.SECONDS);
                        if (contactResponseBuilderFuture.isDone()) {
                            contactResponses.add(contactResponseBuilder.build());
                        }
                    } catch (InterruptedException | ExecutionException | TimeoutException exception) {
                        LOGGER.error("Contact could not be extracted from ContactFuture Object because of the error : ", exception);
                        Thread.currentThread().interrupt();
                    }
                });
        return contactResponses;
    }

    @NotNull
    public List<Future<ContactResponse.Builder>> getContactResponseFutures(@Param("efrontId") List<String> eFrontIdList) {
    	if(ObjectUtils.isEmpty(eFrontIdList)) {
    		LOGGER.warn("Empty eFrontIdList passed for method : {}", Thread.currentThread().getStackTrace()[0].getMethodName());
    	}
    	LOGGER.info("Received efrontIdList : {}", eFrontIdList);
    	
    	Map<String, Entity> efrontEntityList = crmThirdPartyMapperService.getEntityThirdPartyByEfrontIdList(eFrontIdList, ThirdPartyMappingEnum.CONTACT_INVEST.getThirdPartySource())
            .entrySet()
            .stream()
            .collect(Collectors.toMap(entry -> OBJECT_MAPPER.convertValue(entry.getKey(), String.class),
                entry -> OBJECT_MAPPER.convertValue(entry.getValue(), Entity.class)));

        return eFrontIdList
                .stream()
                .map(eFrontId -> processNotificationExecutorService.submit(() -> {
                    ContactResponse.Builder contactResponseBuilder = newBuilder();
                    try {
                        LOGGER.info("Creating the proto for Contact with eFront id {}", eFrontId);
                        Entity entity = efrontEntityList.get(eFrontId);
                        int crmId = null != entity ? entity.getEntityId() : -1;
                        contactResponseBuilder.setData((crmId != -1) ?
                                this.process(crmId, MODIFIED_BY) : Contact.getDefaultInstance());

                    } catch (Exception e) {
                        LOGGER.error("Contact Proto creation failed for efront id {} with the exception: {}", eFrontId, e);
                        contactResponseBuilder.setMessage(e.getMessage());
                    } finally {
                        contactResponseBuilder.getDataBuilder().setContactId(eFrontId);
                    }
                    return contactResponseBuilder;
                })).collect(Collectors.toList());
    }
    
    private void validateNullValues(Integer entityId, String modifiedBy) {
    	if(ObjectUtils.isEmpty(entityId)) {
    		LOGGER.warn("Empty entityId passed for method : {}", Thread.currentThread().getStackTrace()[0].getMethodName());
    	}
    	if(StringUtils.isBlank(modifiedBy)) {
    		LOGGER.warn("Empty modifiedBy passed for method : {}", Thread.currentThread().getStackTrace()[0].getMethodName());
    	}
    }
}
