package com.bfm.aap.privatemarkets.crm.loader.api;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bfm.aap.pmdx.hub.service.PrivateMarketsDXHubService;
import com.bfm.aap.pmdx.loader.service.PrivateMarketsCRMLoaderService;
import com.bfm.aap.pmdx.loader.service.PrivateMarketsCRMLoaderServiceConstants;
import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.CompanyResponse;
import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.ContactResponse;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.InvestorAccount;
import com.bfm.aap.pmdx.model.InvestorAccountResponse;
import com.bfm.aap.pmdx.model.InvestorResponse;
import com.bfm.aap.pmdx.model.User;
import com.bfm.aap.pmdx.redblue.util.Beam2APIService;
import com.bfm.aap.pmdx.services.CompanyRequest;
import com.bfm.aap.pmdx.services.ContactRequest;
import com.bfm.aap.pmdx.services.InvestorRequest;
import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;
import com.bfm.aap.privatemarkets.crm.loader.integration.gateway.UserProcessingGateway;
import com.bfm.aap.privatemarkets.crm.loader.service.ProcessCompanyNotification;
import com.bfm.aap.privatemarkets.crm.loader.service.ProcessContactNotification;
import com.bfm.aap.privatemarkets.crm.loader.service.ProcessInvestorAccountNotification;
import com.bfm.aap.privatemarkets.crm.loader.service.ProcessInvestorNotification;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.beam2.annotation.Beam2Method;
import com.bfm.beam2.annotation.Beam2Service;
import com.bfm.beam2.annotation.Param;
import com.bfm.util.beans.CollectionUtils;

@Service
@Beam2Service
public class CRMLoaderService implements PrivateMarketsCRMLoaderService, Beam2APIService {

    private static final Logger LOGGER = LoggerFactory.getLogger(CRMLoaderService.class);

    private static final String SKIPPING_ENTITY_PROCESSING_MSG = "Skipping processing because network is secondary";
    private static final String EMPTY_EFRONT_ID_LIST = "Empty eFrontIdList passed for method : {}";
    private static final String EMPTY_ENTITY_ID_LIST = "Empty ENTITY_ID_LIST passed for method : {}";
    private static final String RECEIVED_ENTITY_ID_LIST_MODIFIED_BY_RECORDS = "Received ENTITY_ID_LIST: {}\nReceived modifiedBy : {}\nStarting {} ... Total Records : {}";
    private static final String RECEIVED_EFRONT_ID_LIST_RECORDS = "Received eFrontIdList: {}\nStarting {} ... Total Records : {}";

    private final UserProcessingGateway userProcessingGateway;
    private final ProcessContactNotification processContactNotification;
    private final ProcessCompanyNotification processCompanyNotification;
    private final ProcessInvestorNotification processInvestorNotification;
    private final ProcessInvestorAccountNotification processInvestorAccountNotification;
    private final CRMThirdPartyMapperService crmThirdPartyMapperService;
    private final PrivateMarketsDXHubService privateMarketsDXHubService;

    @Autowired
    public CRMLoaderService(UserProcessingGateway userProcessingGateway,
                            ProcessContactNotification processContactNotification,
                            ProcessCompanyNotification processCompanyNotification,
                            ProcessInvestorNotification processInvestorNotification,
                            ProcessInvestorAccountNotification processInvestorAccountNotification,
                            PrivateMarketsDXHubService privateMarketsDXHubService,
                            CRMThirdPartyMapperService crmThirdPartyMapperService) {
        this.userProcessingGateway = userProcessingGateway;
        this.processContactNotification = processContactNotification;
        this.processCompanyNotification = processCompanyNotification;
        this.processInvestorNotification = processInvestorNotification;
        this.processInvestorAccountNotification = processInvestorAccountNotification;
        this.privateMarketsDXHubService = privateMarketsDXHubService;
        this.crmThirdPartyMapperService = crmThirdPartyMapperService;
    }

    /**
     * @param user
     * @return
     */
    @Override
    @RecordStats
    @Beam2Method(command = PrivateMarketsCRMLoaderServiceConstants.MAP_CRM_USER)
    public CRMLoaderResponse mapCRMUserContact(@Param("user") User user) {
        if (!user.getEntityInfo().getPrimaryData()) {
            LOGGER.info(SKIPPING_ENTITY_PROCESSING_MSG);
            return CRMLoaderResponse.getDefaultInstance();
        }
        return userProcessingGateway.processMapCRMUser(user);
    }

    //AFA-11846 Disable EM updates
    @Override
    @RecordStats
    @Beam2Method(command = PrivateMarketsCRMLoaderServiceConstants.MAP_CRM_CONTACT)
    public CRMLoaderResponse mapCRMContact(@Param("contact") Contact contact) {
        return CRMLoaderResponse.getDefaultInstance();
    }

    //AFA-11846 Disable EM updates
    @Override
    @RecordStats
    @Beam2Method(command = PrivateMarketsCRMLoaderServiceConstants.MAP_CRM_COMPANY)
    public CRMLoaderResponse mapCRMCompany(@Param("company") Company company) {
        return CRMLoaderResponse.getDefaultInstance();
    }

    //AFA-11846 Disable EM updates
    @Override
    @RecordStats
    @Beam2Method(command = PrivateMarketsCRMLoaderServiceConstants.MAP_CRM_INVESTOR)
    public CRMLoaderResponse mapCRMInvestor(@Param("investor") Investor investor) {
        return CRMLoaderResponse.getDefaultInstance();
    }

    @Override
    @RecordStats
    @Beam2Method(command = PrivateMarketsCRMLoaderServiceConstants.MAP_CRM_INVESTOR_ACCOUNT)
    public CRMLoaderResponse mapCRMInvestorAccount(@Param("investorAccount") InvestorAccount investorAccount) {
        return CRMLoaderResponse.getDefaultInstance();
    }

    @Override
    @Beam2Method(command = PrivateMarketsCRMLoaderServiceConstants.UPDATE_THIRD_PARTY_MAPPING)
    public boolean mapEfrontCrmThirdPartyMapping(@Param("efrontId") String efrontId, @Param("crmEntityId") Integer crmEntityId, @Param("entityType") String entityType) {
        com.bfm.entitymaster.dto.entitythirdparty.ThirdPartyMapping thirdPartyMapping = crmThirdPartyMapperService.lookupThirdPartMapping(
                crmEntityId, ThirdPartyMappingEnum.get(entityType));
        if (null == thirdPartyMapping) {
            LOGGER.info("No thirdpartymapping found for entityId : {}. Creating new mapping with efrontId-{} and crmEntityId-{}", crmEntityId, efrontId, crmEntityId);
            crmThirdPartyMapperService.create(efrontId, crmEntityId, ThirdPartyMappingEnum.get(entityType));
        } else {
            LOGGER.info("Updating thirdpartymapping with efrontId-{} and crmEntityId-{}", efrontId, crmEntityId);
            thirdPartyMapping.setThirdPartyIdentifier(efrontId);
            crmThirdPartyMapperService.updateThirdPartyMapping(thirdPartyMapping);
        }
        return true;
    }

    /**
     * API - Contacts bulk uploads using batch
     *
     * @param ENTITY_ID_LIST
     * @param modifiedBy
     * @return
     */
    @Override
    @Beam2Method(command = PrivateMarketsCRMLoaderServiceConstants.BULK_TRANSFER_CONTACT_FROM_CRM_EFRONT)
    public List<Integer> loadContactsToEfront(@Param("entityId") List<Integer> ENTITY_ID_LIST, @Param("modifiedBy") String modifiedBy) {
        if (CollectionUtils.isEmpty(ENTITY_ID_LIST)) {
            LOGGER.warn(EMPTY_ENTITY_ID_LIST, Thread.currentThread().getStackTrace()[0].getMethodName());
        }
        LOGGER.info(RECEIVED_ENTITY_ID_LIST_MODIFIED_BY_RECORDS, ENTITY_ID_LIST, modifiedBy, PrivateMarketsCRMLoaderServiceConstants.BULK_TRANSFER_CONTACT_FROM_CRM_EFRONT, ENTITY_ID_LIST.size());
        List<Integer> failedENTITY_ID_LIST = new ArrayList<>();
        ENTITY_ID_LIST.forEach(entityId -> {
            try {
                LOGGER.info("Processing EntityType - P (Contact)");
                privateMarketsDXHubService.updateContact(ContactRequest.newBuilder().setContact(processContactNotification.process(entityId, modifiedBy)).build(), entityId);
            } catch (Exception exception) {
                LOGGER.error(new StringBuilder("Contact load to eFront failed for - ").append(entityId).toString(), exception);
                failedENTITY_ID_LIST.add(entityId);
            }
        });
        return failedENTITY_ID_LIST;
    }

    /**
     * API - Company bulk uploads using batch
     *
     * @param ENTITY_ID_LIST
     * @param modifiedBy
     * @return
     */
    @Override
    @Beam2Method(command = PrivateMarketsCRMLoaderServiceConstants.BULK_TRANSFER_COMPANY_FROM_CRM_EFRONT)
    public List<Integer> loadCompaniesToEfront(@Param("entityId") List<Integer> ENTITY_ID_LIST, @Param("modifiedBy") String modifiedBy) {
        if (CollectionUtils.isEmpty(ENTITY_ID_LIST)) {
            LOGGER.warn(EMPTY_ENTITY_ID_LIST, Thread.currentThread().getStackTrace()[0].getMethodName());
        }
        LOGGER.info(RECEIVED_ENTITY_ID_LIST_MODIFIED_BY_RECORDS, ENTITY_ID_LIST, modifiedBy, PrivateMarketsCRMLoaderServiceConstants.BULK_TRANSFER_CONTACT_FROM_CRM_EFRONT, ENTITY_ID_LIST.size());
        List<Integer> failedENTITY_ID_LIST = new ArrayList<>();
        ENTITY_ID_LIST.forEach(entityId -> {
            try {
                LOGGER.info("Processing EntityType - O (Company)");
                privateMarketsDXHubService.updateCompany(CompanyRequest.newBuilder().setCompany(processCompanyNotification.process(entityId, modifiedBy)).build(), entityId);
            } catch (Exception exception) {
                LOGGER.error(new StringBuilder("Company load to eFront failed for - ").append(entityId).toString(), exception);
                failedENTITY_ID_LIST.add(entityId);
            }
        });
        return failedENTITY_ID_LIST;
    }

    /**
     * API - Investor bulk uploads using batch
     *
     * @param ENTITY_ID_LIST
     * @param modifiedBy
     * @return
     */
    @Override
    @Beam2Method(command = PrivateMarketsCRMLoaderServiceConstants.BULK_TRANSFER_INVESTOR_FROM_CRM_EFRONT)
    public List<Integer> loadInvestorsToEfront(@Param("entityId") List<Integer> ENTITY_ID_LIST, @Param("modifiedBy") String modifiedBy) {
        if (CollectionUtils.isEmpty(ENTITY_ID_LIST)) {
            LOGGER.warn(EMPTY_ENTITY_ID_LIST, Thread.currentThread().getStackTrace()[0].getMethodName());
        }
        LOGGER.info(RECEIVED_ENTITY_ID_LIST_MODIFIED_BY_RECORDS, ENTITY_ID_LIST, modifiedBy, PrivateMarketsCRMLoaderServiceConstants.BULK_TRANSFER_CONTACT_FROM_CRM_EFRONT, ENTITY_ID_LIST.size());
        List<Integer> failedENTITY_ID_LIST = new ArrayList<>();
        ENTITY_ID_LIST.forEach(entityId -> {
            try {
                LOGGER.info("Processing EntityType - O (Investor)");
                privateMarketsDXHubService.updateInvestor(InvestorRequest.newBuilder().setInvestor(processInvestorNotification.process(entityId, modifiedBy)).build(), entityId);
            } catch (Exception exception) {
                LOGGER.error(new StringBuilder("Investor load to eFront failed for - ").append(entityId).toString(), exception);
                failedENTITY_ID_LIST.add(entityId);
            }
        });
        return failedENTITY_ID_LIST;
    }

    /**
     * API - Investor aacount bulk uploads using batch
     *
     * @param ENTITY_ID_LIST
     * @param modifiedBy
     * @return
     */
    @Override
    @Beam2Method(command = PrivateMarketsCRMLoaderServiceConstants.BULK_TRANSFER_INVESTOR_ACCOUNT_FROM_CRM_EFRONT)
    public List<Integer> loadInvestorAccountsToEfront(@Param("entityId") List<Integer> ENTITY_ID_LIST, @Param("modifiedBy") String modifiedBy) {
        if (CollectionUtils.isEmpty(ENTITY_ID_LIST)) {
            LOGGER.warn(EMPTY_ENTITY_ID_LIST, Thread.currentThread().getStackTrace()[0].getMethodName());
        }
        LOGGER.info(RECEIVED_ENTITY_ID_LIST_MODIFIED_BY_RECORDS, ENTITY_ID_LIST, modifiedBy, PrivateMarketsCRMLoaderServiceConstants.BULK_TRANSFER_INVESTOR_ACCOUNT_FROM_CRM_EFRONT, ENTITY_ID_LIST.size());
        List<Integer> failedENTITY_ID_LIST = new ArrayList<>();
        ENTITY_ID_LIST.forEach(entityId -> {
            try {
                LOGGER.info("Processing EntityType - O (InvestorAccount)");
                privateMarketsDXHubService.updateInvestorAccount(processInvestorAccountNotification.process(entityId, modifiedBy), entityId);
            } catch (Exception exception) {
                LOGGER.error(new StringBuilder("Investor Account load to eFront failed for - ").append(entityId).toString(), exception);
                failedENTITY_ID_LIST.add(entityId);
            }
        });
        return failedENTITY_ID_LIST;
    }

    /**
     * Beam2 end point for CRM recon for contacts
     *
     * @param eFrontIdList
     * @return
     */
    @Override
    @Beam2Method(command = PrivateMarketsCRMLoaderServiceConstants.GET_CONTACT_PROTO)
    public Collection<ContactResponse> getContactProtos(@Param("efrontId") List<String> eFrontIdList) {
        if (CollectionUtils.isEmpty(eFrontIdList)) {
            LOGGER.warn(EMPTY_EFRONT_ID_LIST, Thread.currentThread().getStackTrace()[0].getMethodName());
        }
        LOGGER.info(RECEIVED_EFRONT_ID_LIST_RECORDS, eFrontIdList, PrivateMarketsCRMLoaderServiceConstants.BULK_TRANSFER_CONTACT_FROM_CRM_EFRONT, eFrontIdList.size());
        List<Future<ContactResponse.Builder>> contactResponseBuilderFutures = processContactNotification.getContactResponseFutures(eFrontIdList);
        return processContactNotification.getContactResponsesFromFutures(contactResponseBuilderFutures);
    }

    /**
     * Beam2 end point for CRM recon for company
     *
     * @param eFrontIdList
     * @return
     */
    @Override
    @Beam2Method(command = PrivateMarketsCRMLoaderServiceConstants.GET_COMPANY_PROTO)
    public Collection<CompanyResponse> getCompanyProtos(@Param("efrontId") List<String> eFrontIdList) {
        if (CollectionUtils.isEmpty(eFrontIdList)) {
            LOGGER.warn(EMPTY_EFRONT_ID_LIST, Thread.currentThread().getStackTrace()[0].getMethodName());
        }
        LOGGER.info(RECEIVED_EFRONT_ID_LIST_RECORDS, eFrontIdList, PrivateMarketsCRMLoaderServiceConstants.BULK_TRANSFER_CONTACT_FROM_CRM_EFRONT, eFrontIdList.size());
        List<Future<CompanyResponse.Builder>> companyResponseBuilderFutures = processCompanyNotification.getCompanyResponseFutures(eFrontIdList);
        return processCompanyNotification.getCompanyResponsesFromFutures(companyResponseBuilderFutures);
    }

    /**
     * Beam2 end point for CRM recon for investor
     *
     * @param eFrontIdList
     * @return
     */
    @Override
    @Beam2Method(command = PrivateMarketsCRMLoaderServiceConstants.GET_INVESTOR_PROTO)
    public Collection<InvestorResponse> getInvestorProtos(@Param("efrontId") List<String> eFrontIdList) {
        if (CollectionUtils.isEmpty(eFrontIdList)) {
            LOGGER.warn(EMPTY_EFRONT_ID_LIST, Thread.currentThread().getStackTrace()[0].getMethodName());
        }
        LOGGER.info(RECEIVED_EFRONT_ID_LIST_RECORDS, eFrontIdList, PrivateMarketsCRMLoaderServiceConstants.BULK_TRANSFER_CONTACT_FROM_CRM_EFRONT, eFrontIdList.size());
        List<Future<InvestorResponse.Builder>> investorResponseBuilderFutures = processInvestorNotification.getInvestorResponseFutures(eFrontIdList);
        return processInvestorNotification.getInvestorResponsesFromFutures(investorResponseBuilderFutures);
    }

    /**
     * Beam2 end point for CRM recon for investor account
     *
     * @param eFrontIdList
     * @return
     */
    @Override
    @Beam2Method(command = PrivateMarketsCRMLoaderServiceConstants.GET_INVESTOR_ACCOUNT_PROTO)
    public Collection<InvestorAccountResponse> getInvestorAccountProtos(@Param("efrontId") List<String> eFrontIdList) {
        if (CollectionUtils.isEmpty(eFrontIdList)) {
            LOGGER.warn(EMPTY_EFRONT_ID_LIST, Thread.currentThread().getStackTrace()[0].getMethodName());
        }
        LOGGER.info(RECEIVED_EFRONT_ID_LIST_RECORDS, eFrontIdList, PrivateMarketsCRMLoaderServiceConstants.GET_INVESTOR_ACCOUNT_PROTO, eFrontIdList.size());
        List<Future<InvestorAccountResponse.Builder>> investorResponseBuilderFutures = processInvestorAccountNotification.getInvestorAccountResponseFutures(eFrontIdList);
        return processInvestorAccountNotification.getInvestorAccountResponsesFromFutures(investorResponseBuilderFutures);
    }
}
