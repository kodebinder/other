package com.bfm.aap.privatemarkets.crm.loader.integration.splitter;

import com.bfm.aap.pmdx.model.Address;
import com.bfm.aap.pmdx.model.util.SchemaEnum;
import com.bfm.aap.privatemarkets.crm.loader.mapper.AddressTransformer;
import com.bfm.aap.privatemarkets.crm.loader.model.AddressMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreCompanyMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreContactMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class AddressSplitter {
    private static final Logger LOGGER = LoggerFactory.getLogger(AddressSplitter.class);

    @Autowired
    AddressTransformer addressTransformer;

    public List<AddressMessage> splitAndPublishContactAddress(Message<CoreContactMessage> message) {
        return message.getPayload().getPmdxContact().getAddressListList().stream()
            .filter(Objects::nonNull)
            .map(address -> processAddress(message.getPayload().getCrmContact().getEntityId(), address, SchemaEnum.EFRONT_CONTACT_SCHEMA))
                .collect(Collectors.toList());
    }

    public List<AddressMessage> splitAndPublishCompanyAddress(Message<CoreCompanyMessage> message) {
        return message.getPayload().getCompany().getOfficeAddressListList().stream()
            .filter(Objects::nonNull)
            .map(address -> processAddress(message.getPayload().getOrgEntity().getEntityId(), address, SchemaEnum.EFRONT_COMPANY_SCHEMA))
                .collect(Collectors.toList());
    }

    public List<AddressMessage> splitAndPublishInvestorAddress(Message<CoreInvestorMessage> message) {
        return message.getPayload().getInvestor().getOfficeAddressListList().stream()
            .filter(Objects::nonNull)
            .map(address -> processAddress(message.getPayload().getOrgEntity().getEntityId(), address, SchemaEnum.EFRONT_INVESTOR_SCHEMA))
                .collect(Collectors.toList());
    }

    private AddressMessage processAddress(int entityId, Address pmdxAddress, SchemaEnum schema) {
        AddressMessage msg = new AddressMessage();
        if (null != pmdxAddress) {
            msg.setCrmAddress(addressTransformer.eFrontToCRMTransform(pmdxAddress, schema));
            msg.setPmdxAddress(pmdxAddress);
            msg.setLinkedCRMEntityId(entityId);
        }
        return msg;
    }

    public void setAddressTransformer(AddressTransformer addressTransformer) {
        this.addressTransformer = addressTransformer;
    }
}
