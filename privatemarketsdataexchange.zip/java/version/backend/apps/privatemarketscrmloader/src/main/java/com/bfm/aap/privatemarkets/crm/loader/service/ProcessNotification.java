package com.bfm.aap.privatemarkets.crm.loader.service;

import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.streams.processor.Processor;
import org.apache.kafka.streams.processor.ProcessorContext;
import org.apache.kafka.streams.state.KeyValueStore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.bfm.aap.pmdx.async.util.ThreadPoolHealthMonitor;
import com.bfm.aap.pmdx.hub.service.PrivateMarketsDXHubForgetService;
import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.util.CircuitBreakerHelper;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.LibRedBlueProxy;
import com.bfm.aap.pmdx.notification.model.BusinessNotificationTypes;
import com.bfm.aap.pmdx.notification.model.EmailParams;
import com.bfm.aap.pmdx.notification.model.NotificationEnums;
import com.bfm.aap.pmdx.notification.model.NotificationParams;
import com.bfm.aap.pmdx.notification.service.Notification;
import com.bfm.aap.pmdx.services.CompanyRequest;
import com.bfm.aap.pmdx.services.ContactRequest;
import com.bfm.aap.pmdx.services.InvestorRequest;
import com.bfm.aap.privatemarkets.common.constant.CommonConstants;
import com.bfm.aap.privatemarkets.crm.loader.dao.ADLRepositoryDAO;
import com.bfm.aap.privatemarkets.crm.loader.model.EntityBundle;
import com.bfm.aap.privatemarkets.crm.loader.model.WindowedKey;
import com.bfm.aap.privatemarkets.crm.loader.util.CRMLoaderConstants;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.adl.ADLObject;
import com.bfm.adl.ADLResultSet;
import com.bfm.util.BFMUtil;

@Service
public class ProcessNotification implements Processor<WindowedKey, EntityBundle> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProcessNotification.class);
    private static final String ENTITYID_ISDUPLICATEENTITY = "Circuit breaker detected entityId : {} as duplicate : {}";

    public static final char CONTACT = 'P';
    public static final char ORGANIZATION = 'O';
    public static final String SOURCE = "EFRONT";

    private final ProcessContactNotification processContactNotification;
    private final ProcessCompanyNotification processCompanyNotification;
    private final ProcessInvestorNotification processInvestorNotification;
    private final CircuitBreakerHelper circuitBreakerHelper;
    private final ADLRepositoryDAO adlRepositoryDAO;

    private final PrivateMarketsDXHubForgetService privateMarketsDXHubForgetServiceClient;
    private final CRMThirdPartyMapperService crmThirdPartyMapperService;

    private KeyValueStore<WindowedKey, EntityBundle> bundleStore;
    private ExecutorService streamProcessorExecutor;
    private ExecutorService processNotificationExecutorService;

    private final boolean isProcessContactNotification = Boolean.getBoolean("processContact");
    private final boolean isProcessCompanyNotification = Boolean.getBoolean("processCompany");
    private final boolean isProcessInvestorNotification = Boolean.getBoolean("processInvestor");

    @Autowired
    public ProcessNotification(ADLRepositoryDAO adlRepositoryDAO,
                               ProcessContactNotification processContactNotification,
                               ProcessInvestorNotification processInvestorNotification,
                               ProcessCompanyNotification processCompanyNotification,
                               CircuitBreakerHelper circuitBreakerHelper,
                               PrivateMarketsDXHubForgetService privateMarketsDXHubForgetServiceClient,
                               CRMThirdPartyMapperService crmThirdPartyMapperService, ThreadPoolExecutor streamProcessorExecutor,
                               ThreadPoolExecutor processNotificationExecutorService) {
        this.adlRepositoryDAO = adlRepositoryDAO;
        this.processContactNotification = processContactNotification;
        this.processInvestorNotification = processInvestorNotification;
        this.processCompanyNotification = processCompanyNotification;
        this.circuitBreakerHelper = circuitBreakerHelper;
        this.privateMarketsDXHubForgetServiceClient = privateMarketsDXHubForgetServiceClient;
        this.crmThirdPartyMapperService = crmThirdPartyMapperService;
        this.streamProcessorExecutor = streamProcessorExecutor;
        this.processNotificationExecutorService = processNotificationExecutorService;
    }

    @Scheduled(fixedDelayString = "${crm.stream.delay.health.check:300000}")
    public void healthCheckStreamProcessorExecutor() {
        ThreadPoolHealthMonitor.getHealthUpdate("CRM-Stream-Processor", streamProcessorExecutor);
        ThreadPoolHealthMonitor.getHealthUpdate("CRM-Notification-Processor", processNotificationExecutorService);
    }

    @Override
    public void init(ProcessorContext processorContext) {
        this.bundleStore = (KeyValueStore<WindowedKey, EntityBundle>) processorContext.getStateStore(CRMLoaderConstants.PMDX_STORE);
    }

    @Override
    public void process(WindowedKey windowedKey, EntityBundle entityBundle) {
        if (!LibRedBlueProxy.isCurrentInstancePrimary(CommonConstants.NETWORK_MODE)) {
            LOGGER.info("This instance is not primary. As a result the entityId - {} will not be processed.", entityBundle.getDataBundle().getEntityId());
            bundleStore.delete(windowedKey);
            return;
        }
        streamProcessorExecutor.execute(() -> this.processAsync(windowedKey, entityBundle));
    }

    public void processAsync(WindowedKey windowedKey, EntityBundle entityBundle) {
        String modifiedBy = windowedKey.getChangedBy();
        try {
            if (Objects.nonNull(entityBundle.getDataBundle()) && Objects.nonNull(entityBundle.getDataBundle().getEntityType())) {
                LOGGER.info("EntityMasterNotification contact processing is {}.", BooleanUtils.toString(isProcessContactNotification, CRMLoaderConstants.ENABLED, CRMLoaderConstants.DISABLED));
                if (CONTACT == entityBundle.getDataBundle().getEntityType().charValue() && isProcessContactNotification) {
                    LOGGER.info("Processing EntityType - P (Contact)");
                    Contact proto = processContactNotification.process(entityBundle.getDataBundle().getEntityId(), modifiedBy);
                    if (StringUtils.isNotEmpty(proto.getContactId()) || StringUtils.isNotEmpty(proto.getCompanyId())) {
                        ADLResultSet<ADLObject> adlObjectList = adlRepositoryDAO.fetchADLRecordInWindow(SOURCE, CommonConstants.NETWORK_MODE.name(), EntityType.CONTACT);
                        Boolean isDuplicateEntity = this.circuitBreakerHelper.checkCircuitBreaker(proto, adlObjectList, EntityType.CONTACT);
                        LOGGER.info(ENTITYID_ISDUPLICATEENTITY, entityBundle.getDataBundle().getEntityId(), isDuplicateEntity);
                        if (BooleanUtils.isNotTrue(isDuplicateEntity)) {
                            privateMarketsDXHubForgetServiceClient.updateContact(ContactRequest.newBuilder()
                                    .setContact(proto).build(),
                                entityBundle.getDataBundle().getEntityId());
                        }
                    }
                } else if (ORGANIZATION == entityBundle.getDataBundle().getEntityType().charValue()) {
                    LOGGER.info("EntityMasterNotification investor processing is {}.", BooleanUtils.toString(isProcessInvestorNotification, CRMLoaderConstants.ENABLED, CRMLoaderConstants.DISABLED));
                    if (isProcessInvestorNotification) {
                        com.bfm.entitymaster.dto.entitythirdparty.ThirdPartyMapping thirdPartyMapping = crmThirdPartyMapperService.lookupThirdPartMapping(entityBundle.getDataBundle().getEntityId(), ThirdPartyMappingEnum.INVESTOR_INVEST);
                        if (null != thirdPartyMapping) {
                            Investor investorProto = processInvestorNotification.process(entityBundle.getDataBundle().getEntityId(), modifiedBy);
                            ADLResultSet<ADLObject> adlObjectListForInvestor = adlRepositoryDAO.fetchADLRecordInWindow(SOURCE, CommonConstants.NETWORK_MODE.name(), EntityType.INVESTOR);
                            Boolean isDuplicateInvestorEntity = this.circuitBreakerHelper.checkCircuitBreaker(investorProto, adlObjectListForInvestor, EntityType.INVESTOR);
                            LOGGER.info(ENTITYID_ISDUPLICATEENTITY, entityBundle.getDataBundle().getEntityId(), isDuplicateInvestorEntity);
                            if (BooleanUtils.isNotTrue(isDuplicateInvestorEntity)) {
                                privateMarketsDXHubForgetServiceClient.updateInvestor(
                                    InvestorRequest.newBuilder().setInvestor(investorProto).build(),
                                    entityBundle.getDataBundle().getEntityId());
                            }
                        }
                    }

                    LOGGER.info("EntityMasterNotification company processing is {}.", BooleanUtils.toString(isProcessInvestorNotification, CRMLoaderConstants.ENABLED, CRMLoaderConstants.DISABLED));
                    if (isProcessCompanyNotification) {
                        com.bfm.entitymaster.dto.entitythirdparty.ThirdPartyMapping thirdPartyMapping = crmThirdPartyMapperService.lookupThirdPartMapping(entityBundle.getDataBundle().getEntityId(), ThirdPartyMappingEnum.COMPANY_INVEST);
                        if (null != thirdPartyMapping) {
                            Company company = processCompanyNotification.process(entityBundle.getDataBundle().getEntityId(), modifiedBy);
                            ADLResultSet<ADLObject> adlObjectListForCompany = adlRepositoryDAO.fetchADLRecordInWindow(SOURCE, CommonConstants.NETWORK_MODE.name(), EntityType.COMPANY);
                            Boolean isDuplicateCompanyEntity = this.circuitBreakerHelper.checkCircuitBreaker(company, adlObjectListForCompany, EntityType.COMPANY);
                            LOGGER.info(ENTITYID_ISDUPLICATEENTITY, entityBundle.getDataBundle().getEntityId(), isDuplicateCompanyEntity);
                            if (BooleanUtils.isNotTrue(isDuplicateCompanyEntity)) {
                                privateMarketsDXHubForgetServiceClient.updateCompany(
                                    CompanyRequest.newBuilder().setCompany(company).build(),
                                    entityBundle.getDataBundle().getEntityId());
                            }
                        }
                    }
                }
            }
        } catch (Exception ex) {
            LOGGER.error("Error while processing notification", ex);
            final NotificationParams notificationParams = new NotificationParams.Builder(NotificationEnums.NotificationSeverity.YELLOW, CRMLoaderConstants.CRM_LOADER_SERVER_NAME)
                .setEmailBuilder(new EmailParams.Builder().setSubject("Error processing EM notification")
                    .setBusinessNotificationType(BusinessNotificationTypes.CRM)
                    .setUserRequest(null)
                    .setException(ex)
                    .setUserName(BFMUtil.getUser())
                    .setMode(CommonConstants.NETWORK_MODE.name()))
                .build();

            Notification.sendNotification(notificationParams);
        } finally {
            LOGGER.info("Entity ID {} is processed successfully. Removing from the CRM-Notification-Processor queue", windowedKey);
            bundleStore.delete(windowedKey);
        }
    }

    @Override
    public void close() {
    	// method for resource clean up
    }
}