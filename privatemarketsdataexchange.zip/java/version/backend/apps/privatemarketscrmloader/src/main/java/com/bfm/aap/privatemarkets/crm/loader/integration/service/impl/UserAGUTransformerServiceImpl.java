/**
 * 
 */
package com.bfm.aap.privatemarkets.crm.loader.integration.service.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.bfm.aap.pmdx.model.User;
import com.bfm.aap.privatemarkets.crm.loader.mapper.UserTransformer;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreUserMessage;
import com.bfm.aap.privatemarkets.crm.loader.integration.service.TransformerService;

/**
 * @author hthakkar
 *
 */
public class UserAGUTransformerServiceImpl implements TransformerService<CoreUserMessage, User> {

	@Autowired
	private UserTransformer userTransformer;
	
	@Override
	public CoreUserMessage transform(User user) throws Exception {
		CoreUserMessage msg = new CoreUserMessage();
		msg.setUserCRM(userTransformer.eFrontToCRMTransform(user));
		return msg;
	}

}
