package com.bfm.aap.privatemarkets.crm.loader.integration.splitter;


import com.bfm.aap.pmdx.model.util.SchemaEnum;
import com.bfm.aap.privatemarkets.crm.loader.mapper.AliasTransformer;
import com.bfm.aap.privatemarkets.crm.loader.model.AliasMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreCompanyMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorMessage;
import com.bfm.entitymaster.dto.alias.Alias;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class AliasSplitter {
    private static final Logger LOGGER = LoggerFactory.getLogger(AliasSplitter.class);
    private static final String KNOW_AS = "knownAs";
    @Autowired
    AliasTransformer aliasTransformer;

    public List<AliasMessage> splitAndPublishCompanyAliases(Message<CoreCompanyMessage> message) {
        List<AliasMessage> aliasMessages = new ArrayList<>();
        populateAlias(message.getPayload().getCompany().getKnownAs(), KNOW_AS, message.getPayload().getOrgEntity().getEntityId(), SchemaEnum.EFRONT_COMPANY_SCHEMA).ifPresent(aliasMessages::add);
        return aliasMessages;
    }

    public List<AliasMessage> splitAndPublishInvestorAliases(Message<CoreInvestorMessage> message) {
        return new ArrayList<>();
    }

    private Optional<AliasMessage> populateAlias(String attribute, String code, int entityId, SchemaEnum schema) {
        if (StringUtils.isNotBlank(attribute)) {
            return Optional.of(createMessage(aliasTransformer.eFrontToCRMTransform(attribute, code, schema),
                    entityId));
        }
        return Optional.empty();
    }

    private AliasMessage createMessage(Alias alias, int linkedCRMEntityId) {
        AliasMessage msg = new AliasMessage();
        msg.setAlias(alias);
        msg.setLinkedCRMEntityId(linkedCRMEntityId);
        return msg;
    }

    public void setAliasTransformer(AliasTransformer aliasTransformer) {
        this.aliasTransformer = aliasTransformer;
    }
}
