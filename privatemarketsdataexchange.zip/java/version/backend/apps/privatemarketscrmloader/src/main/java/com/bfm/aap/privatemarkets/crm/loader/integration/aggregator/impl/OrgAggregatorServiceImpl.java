package com.bfm.aap.privatemarkets.crm.loader.integration.aggregator.impl;


import com.bfm.aap.privatemarkets.common.crm.model.CRMChannelResponseList;
import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMResponseStatusEnum;
import com.bfm.aap.privatemarkets.crm.loader.integration.aggregator.AggregatorService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.List;

public class OrgAggregatorServiceImpl implements AggregatorService {
    private static final Logger LOGGER = LoggerFactory.getLogger(OrgAggregatorServiceImpl.class);
    @Override
    public CRMLoaderResponse composeEndpointResponse(List<CRMChannelResponseList> responseList) {
        LOGGER.info("composeEndpointResponse - ResponseList size: {}",responseList.size());
        return buildLoaderResponse(checkIfAnyFailed(responseList));

    }

    private CRMLoaderResponse buildLoaderResponse(boolean linkedEntityFailed) {
        LOGGER.info("buildLoaderResponse - Org Endpoint response: {}",linkedEntityFailed);
        CRMLoaderResponse.Builder crmResponseBuilder = CRMLoaderResponse.newBuilder();
        if (linkedEntityFailed) {
            crmResponseBuilder.setStatus(CRMResponseStatusEnum.CORE_ATTRIBUTE_SUCCESS);
            crmResponseBuilder.setMessage("Core attribute succeeded in processing");
        } else {
            crmResponseBuilder.setStatus(CRMResponseStatusEnum.FULL_SUCCESS);
            crmResponseBuilder.setMessage("All entities processed successfully");
        }
        return crmResponseBuilder.build();
    }

    private boolean checkIfAnyFailed(List<CRMChannelResponseList> responseList) {
        return responseList.stream()
                .map(CRMChannelResponseList::getResponseList)
                .flatMap(Collection::stream)
                .anyMatch(a -> !a.getStatus());
    }
}
