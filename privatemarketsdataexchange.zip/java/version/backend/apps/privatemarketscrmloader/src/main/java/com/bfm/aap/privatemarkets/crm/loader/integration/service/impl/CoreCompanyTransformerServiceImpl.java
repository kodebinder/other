package com.bfm.aap.privatemarkets.crm.loader.integration.service.impl;

import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.privatemarkets.crm.loader.mapper.EntityTransformer;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreCompanyMessage;
import com.bfm.aap.privatemarkets.crm.loader.util.DecodeHelper;
import com.bfm.aap.privatemarkets.crm.loader.integration.service.TransformerService;
import com.bfm.entitymaster.dto.organization.OrganizationType;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import static com.bfm.aap.privatemarkets.common.crm.util.EntityMasterDecodeTableConstants.COUNTRIES;
import static com.bfm.aap.privatemarkets.common.crm.util.EntityMasterDecodeTableConstants.DX_EM_ORGANIZATION_SUB_TYPE;
import static com.bfm.aap.privatemarkets.common.crm.util.EntityMasterDecodeTableConstants.DX_EM_ORGANIZATION_TYPE;

public class CoreCompanyTransformerServiceImpl implements TransformerService<CoreCompanyMessage, Company> {

    private static final Logger LOGGER = LoggerFactory.getLogger(CoreCompanyTransformerServiceImpl.class);
    
    private static final String ORG = "O";
    private static final String UNKNOWN = "UNKNOWN0";

    @Autowired
    private EntityTransformer entityTransformer;

    @Override
    public CoreCompanyMessage transform(Company company) {
        CoreCompanyMessage msg = new CoreCompanyMessage();
        msg.setCompany(company);
        msg.setOrgEntity(entityTransformer.eFrontToCRMTransform(company.getName(), ORG));
        msg.setOrganizationType(getOrganizationType(company));
        msg.setCountryDecode(DecodeHelper.getDecode(COUNTRIES, company.getDomicile()));
        LOGGER.info("success: End of Investor transform: {}", company.getCompanyId());
        return msg;
    }

    private OrganizationType getOrganizationType(Company company) {
        OrganizationType organizationType = new OrganizationType();
        if (StringUtils.isNotBlank(company.getStatus())) {
            organizationType.setOrganizationType(DecodeHelper.getDecode(DX_EM_ORGANIZATION_TYPE, company.getStatus()));
            organizationType.setOrganizationSubType(DecodeHelper.getDecode(DX_EM_ORGANIZATION_SUB_TYPE, UNKNOWN));
        }
        return organizationType;
    }

    public void setEntityTransformer(EntityTransformer entityTransformer) {
        this.entityTransformer = entityTransformer;
    }
}
