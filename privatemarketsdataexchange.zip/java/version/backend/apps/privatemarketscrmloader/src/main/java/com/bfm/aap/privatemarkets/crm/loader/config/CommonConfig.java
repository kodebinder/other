package com.bfm.aap.privatemarkets.crm.loader.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bfm.aap.pmdx.model.util.CircuitBreakerHelper;

@Configuration
public class CommonConfig {

    @Bean
    public CircuitBreakerHelper getCircuitBreakerHelper() {
        return new CircuitBreakerHelper();
    }
}