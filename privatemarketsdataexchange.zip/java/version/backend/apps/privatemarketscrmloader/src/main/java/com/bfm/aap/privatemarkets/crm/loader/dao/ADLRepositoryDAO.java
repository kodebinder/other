package com.bfm.aap.privatemarkets.crm.loader.dao;

import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.adl.ADLObject;
import com.bfm.adl.ADLResultSet;

public interface ADLRepositoryDAO {

    ADLResultSet<ADLObject> fetchADLRecordInWindow(String gUID, String serverMode, EntityType entityType);

}
