package com.bfm.aap.privatemarkets.crm.loader;

import com.bfm.aap.pmdx.notification.model.EmailParams;
import com.bfm.aap.pmdx.notification.model.NotificationEnums;
import com.bfm.aap.pmdx.notification.model.NotificationParams;
import com.bfm.aap.pmdx.notification.service.Notification;
import com.bfm.aap.pmdx.redblue.PmdxServiceType;
import com.bfm.aap.pmdx.redblue.util.Beam2APIService;
import com.bfm.aap.pmdx.redblue.util.BmsHelper;
import com.bfm.aap.privatemarkets.common.constant.CommonConstants;
import com.bfm.aap.privatemarkets.crm.loader.api.CRMLoaderService;
import com.bfm.aap.privatemarkets.crm.loader.model.EntityBundle;
import com.bfm.aap.privatemarkets.crm.loader.model.WindowedKey;
import com.bfm.aap.privatemarkets.crm.loader.service.ProcessNotification;
import com.bfm.aap.privatemarkets.crm.loader.service.kafka.StreamProcessorRunner;
import com.bfm.aap.privatemarkets.crm.loader.util.CRMLoaderConstants;
import com.bfm.beam2.server.ServiceGateway;
import com.bfm.util.BFMUtil;
import org.apache.kafka.streams.processor.ProcessorSupplier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MapPropertySource;
import org.springframework.scheduling.annotation.EnableScheduling;

import javax.annotation.PostConstruct;
import java.util.Optional;
import org.springframework.stereotype.Component;

@EnableScheduling
@EnableAspectJAutoProxy
@ComponentScan({"com.bfm.aap.privatemarkets.crm", "com.bfm.aap.privatemarkets.common.config",
        "com.bfm.aap.privatemarkets.permission.restrict"})
@ImportResource("classpath:/spring-integration-config.xml")
@PropertySource(name = "properties", value = "${db.property}")
@Component
public class PrivateMarketsCRMLoader {

    private static final Logger LOGGER = LoggerFactory.getLogger(PrivateMarketsCRMLoader.class);
    private final ConfigurableEnvironment configurableEnvironment;


    @Autowired
    public PrivateMarketsCRMLoader(final ConfigurableEnvironment configurableEnvironment) {
        this.configurableEnvironment = configurableEnvironment;
    }

    public static void main(String[] args) {
        try {
            LOGGER.debug("Starting Private Markets CRM Loader Server...");
            startLoader();
            LOGGER.debug("Private Markets CRM Loader Server started");
        } catch (Exception e) {
            LOGGER.error("Error starting server", e);
            final NotificationParams notificationParams = new NotificationParams.Builder(
                    NotificationEnums.NotificationSeverity.PURPLE, CRMLoaderConstants.CRM_LOADER_SERVER_SHORT_NAME)
                    .setEmailBuilder(new EmailParams.Builder().setSubject("Error starting server")
                            .setUserRequest(null).setException(e).setUserName(BFMUtil.getUser())
                            .setMode(CommonConstants.NETWORK_MODE.name()))
                    .build();

            Notification.sendNotification(notificationParams);

            System.exit(-1);

        }
    }

    private static void startLoader() {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(
                PrivateMarketsCRMLoader.class);
        context.registerShutdownHook();
        ServiceGateway serviceGateway = context.getBean(ServiceGateway.class);
        Beam2APIService service = context.getBean(CRMLoaderService.class);
        BmsHelper.registerBMS(serviceGateway, service, PmdxServiceType.PRIVATEMARKETS_CRM_LOADER,
                CommonConstants.DX_CRM_LOADER_SOURCE_ID_OVERRIDE);

        // Register Entity-Master Kafka Notification Listener
        boolean isProcessEntityMasterNotifications = Boolean.getBoolean("processEntityMasterNotifications");

        LOGGER.info("Subscribe to EntityMasterNotification Queue is {}", isProcessEntityMasterNotifications ? CRMLoaderConstants.ENABLED : CRMLoaderConstants.DISABLED);

        if (isProcessEntityMasterNotifications) {
            String[] topic = {"em_cn_entity", "em_cn_entity_relationship"};
            StreamProcessorRunner streamProcessorRunner = new StreamProcessorRunner();
            ProcessorSupplier<WindowedKey, EntityBundle> supplier = () -> context
                    .getBean(ProcessNotification.class);
            String applicationName = System.getProperty("applicationName");
            streamProcessorRunner.init(topic, applicationName, supplier);
            Runtime.getRuntime().addShutdownHook(new Thread("shutdown-hook") {
                @Override
                public void run() {
                    streamProcessorRunner.close();
                }
            });
            try {
                streamProcessorRunner.run();
            } catch (Exception e) {
                LOGGER.error("Error registering with Kafka", e);
            }
        }
    }

    @PostConstruct
    public void loadSystemProperties() {
        MapPropertySource mapPropertySource = (MapPropertySource) configurableEnvironment.getPropertySources()
                .get(CRMLoaderConstants.CRMLOADER_CONFIG_PROPERTY_FILE_NAME);
        Optional.ofNullable(mapPropertySource).ifPresent(propertySource -> propertySource.getSource()
                .forEach((k, v) -> System.getProperties().putIfAbsent(k, v.toString())));
    }
}
