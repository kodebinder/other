package com.bfm.aap.privatemarkets.crm.loader.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.stream.Collectors;

import javax.validation.constraints.NotNull;

import com.google.gson.JsonParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bfm.aap.pmdx.model.InvestorAccount;
import com.bfm.aap.pmdx.model.InvestorAccountResponse;
import com.bfm.aap.pmdx.proto.util.ProtoJsonHelper;
import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMResponseStatusEnum;
import com.bfm.aap.privatemarkets.crm.loader.integration.gateway.InvestorAccountInverseProcessingGateway;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorAccountInverseMessage;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.beam2.annotation.Param;
import com.bfm.entitymaster.dto.common.Entity;

import static com.bfm.aap.privatemarkets.crm.loader.util.CRMLoaderConstants.OBJECT_MAPPER;

@Service
public class ProcessInvestorAccountNotification {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProcessInvestorAccountNotification.class);

    private final InvestorAccountInverseProcessingGateway investorAccountInverseProcessingGateway;
    private final ExecutorService processNotificationExecutorService;
    private final CRMThirdPartyMapperService crmThirdPartyMapperService;
    public static final String MODIFIED_BY = "TSG_OPS";

    @Autowired
    public ProcessInvestorAccountNotification(ExecutorService processNotificationExecutorService, CRMThirdPartyMapperService crmThirdPartyMapperService) {
        this.processNotificationExecutorService = processNotificationExecutorService;
        this.crmThirdPartyMapperService = crmThirdPartyMapperService;

        this.investorAccountInverseProcessingGateway = coreInvestorAccountInverseMessage -> {
            throw new UnsupportedOperationException("Spring Integration flow hasn't been implemented for Investor Accounts");
        };
    }

    public InvestorAccount process(Integer entityId, String modifiedBy) throws Exception {
        CRMLoaderResponse loaderResponse = investorAccountInverseProcessingGateway.mapEfrontInvestorAccount(new CoreInvestorAccountInverseMessage(entityId, modifiedBy));
        if (loaderResponse.getStatus() == CRMResponseStatusEnum.FULL_SUCCESS) {
            LOGGER.info("Processing completed for entityID : {}", entityId);
            JsonParser jsonParser = new JsonParser();
            return ProtoJsonHelper.extractFromJson(jsonParser.parse(loaderResponse.getMessage()).getAsJsonObject(), InvestorAccount.newBuilder());
        }
        throw new Exception(loaderResponse.getMessage());
    }

    public List<InvestorAccountResponse> getInvestorAccountResponsesFromFutures(List<Future<InvestorAccountResponse.Builder>> investorAccountResponseBuilderFutures) {
        List<InvestorAccountResponse> investorAccountResponses = new ArrayList<>();
        investorAccountResponseBuilderFutures
                .stream()
                .forEach(investorAccountResponseBuilderFuture -> {
                    try {
                        InvestorAccountResponse.Builder responseBuilder = investorAccountResponseBuilderFuture.get(10L, TimeUnit.SECONDS);
                        if (investorAccountResponseBuilderFuture.isDone()) {
                            investorAccountResponses.add(responseBuilder.build());
                        }
                    } catch (InterruptedException | ExecutionException | TimeoutException exception) {
                        LOGGER.error("Investor account could not be extracted from InvestorAccountFuture Object because of the error : ", exception);
                        Thread.currentThread().interrupt();
                    }
                });
        return investorAccountResponses;
    }

    @NotNull
    public List<Future<InvestorAccountResponse.Builder>> getInvestorAccountResponseFutures(@Param("efrontId") List<String> eFrontIdList) {

        Map<String, Entity> efrontEntityList = crmThirdPartyMapperService
                .getEntityThirdPartyByEfrontIdList(eFrontIdList, ThirdPartyMappingEnum.INVESTOR_ACCOUNT_INVEST.getThirdPartySource())
                .entrySet()
                .stream()
                .collect(Collectors.toMap(entry -> OBJECT_MAPPER.convertValue(entry.getKey(), String.class),
                        entry -> OBJECT_MAPPER.convertValue(entry.getValue(), Entity.class)));

        return eFrontIdList
                .stream()
                .map(eFrontId -> processNotificationExecutorService.submit(() -> {
                    InvestorAccountResponse.Builder investorAccountResponseBuilder = InvestorAccountResponse.newBuilder();
                    try {
                        LOGGER.info("Creating the proto for Investor with eFront id {}", eFrontId);
                        Entity entity = efrontEntityList.get(eFrontId);
                        int crmId = null != entity ? entity.getEntityId() : -1;
                        investorAccountResponseBuilder.setData((crmId != -1) ?
                                this.process(crmId, MODIFIED_BY) : InvestorAccount.getDefaultInstance());
                    } catch (Exception e) {
                        LOGGER.error("Investor Account Proto creation failed for efront id {} with the exception: {}", eFrontId, e);
                        investorAccountResponseBuilder.setMessage(e.getMessage());
                    } finally {
                        investorAccountResponseBuilder.getDataBuilder().setInvestorAccountId(eFrontId);
                    }
                    return investorAccountResponseBuilder;
                })).collect(Collectors.toList());
    }
}
