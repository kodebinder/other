package com.bfm.aap.privatemarkets.crm.loader.config;

import java.util.Collections;
import java.util.concurrent.TimeUnit;

import com.bfm.beam2.permission.PermissionStores;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bfm.aap.pmdx.hub.service.PrivateMarketsDXHubForgetService;
import com.bfm.aap.pmdx.hub.service.PrivateMarketsDXHubService;
import com.bfm.aap.pmdx.model.util.LibRedBlueProxy;
import com.bfm.aap.pmdx.redblue.PmdxServiceType;
import com.bfm.aap.privatemarkets.common.constant.CommonConstants;
import com.bfm.aap.privatemarkets.crm.loader.integration.service.UserCRMCoreAGUService;
import com.bfm.aap.privatemarkets.crm.loader.util.CRMLoaderConstants;
import com.bfm.beam2.BRElemConverter;
import com.bfm.beam2.Configs;
import com.bfm.beam2.server.ServiceGateway;
import com.bfm.beam2.server.ServiceGateways;
import com.bfm.beam2.ServiceProxyFactories;
import com.bfm.beam2.ServiceProxyFactory;
import com.bfm.beam2.server.bmsintegration.BmsServiceGateways;
import com.bfm.privatemarkets.beam2.util.Proto3JsonConverter;
import com.bfm.user.client.impl.RPCAwareUserServiceClient;

@Configuration
public class Beam2Config {

    public static final String APPLICATION_NAME = "PrivteMarketsCRMLoader_Client : PrivateMarketsDXHub";

    @Value("${worker.thread.count:10}")
    private int workerThreadCount;
    @Value("${timeout.seconds:120}")
    private int timeoutSeconds;

    @Bean
    public ServiceGateway serviceGateway() {
        BmsServiceGateways.BmsServiceGatewayConfig config = (new BmsServiceGateways.BmsServiceGatewayConfig())
            .name(CRMLoaderConstants.CRM_LOADER_SERVER_NAME).numberOfWorkers(workerThreadCount)
            .permissionStore(PermissionStores.bfmPermissionsSetStore());
        config.addConverterFactory(Proto3JsonConverter.factory());
        return ServiceGateways.bmsGateway(config);
    }

    /**
     * Initialize bRPC client setup of Aladdin Graph Users API
     *
     * @return RPCAwareUserServiceClient
     */
    @Bean
    public RPCAwareUserServiceClient rpcAwareUserServiceClient() {
        return new RPCAwareUserServiceClient();
    }

    @Bean
    public UserCRMCoreAGUService userCRMCoreAGUService() {
        return new UserCRMCoreAGUService(rpcAwareUserServiceClient());
    }

    @Bean(name = "privateMarketsDXHubServiceClient")
    public PrivateMarketsDXHubService getPrivateMarketsDXHubServiceClient() {
        int sourceId = LibRedBlueProxy.getSourceIdByTypeAndColor(PmdxServiceType.PRIVATEMARKETS_DX_HUB, CommonConstants.NETWORK_MODE);
        ServiceProxyFactory factory = getFactory();
        return factory.getServiceProxy(PrivateMarketsDXHubService.class, Configs.builder().setSourceId(sourceId).setTimeout(timeoutSeconds, TimeUnit.SECONDS).build());
    }

    @Bean(name = "privateMarketsDXHubForgetServiceClient")
    public PrivateMarketsDXHubForgetService getPrivateMarketsDXHubForgetServiceClient() {
        int sourceId = LibRedBlueProxy.getSourceIdByTypeAndColor(PmdxServiceType.PRIVATEMARKETS_DX_HUB, CommonConstants.NETWORK_MODE);
        ServiceProxyFactory factory = getFactory();
        return factory.getServiceProxy(PrivateMarketsDXHubForgetService.class, Configs.builder().setSourceId(sourceId).setTimeout(timeoutSeconds, TimeUnit.SECONDS).build());
    }

    private ServiceProxyFactory getFactory() {
        ServiceProxyFactories.SPFConfig config = new ServiceProxyFactories.SPFConfig()
                .setAppName(APPLICATION_NAME)
                .setTimeout(timeoutSeconds, TimeUnit.SECONDS);
        config.setBrElemConverterFactories(Collections.<BRElemConverter.Factory<?>>singletonList(Proto3JsonConverter.factory()));
        return ServiceProxyFactories.bmsServiceProxyFactory(config);
    }

}
