package com.bfm.aap.privatemarkets.crm.loader.config;

import com.bfm.aap.privatemarkets.dao.config.DatabaseConfiguration;
import com.bfm.db.JDBCTokenMapLoader;
import com.bfm.util.BFMDecodesMap;
import com.bfm.util.TokenMapLoaderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;

@Configuration
public class TokenMapLoaderFactoryConfig {

    @Autowired
    private DatabaseConfiguration databaseConfiguration;

    @PostConstruct
    public void tokenMapLoaderFactory() {
        JDBCTokenMapLoader loader = new JDBCTokenMapLoader(this.databaseConfiguration.dataSource());
        TokenMapLoaderFactory.setTokenMapLoader(BFMDecodesMap.class, loader);
    }

}
