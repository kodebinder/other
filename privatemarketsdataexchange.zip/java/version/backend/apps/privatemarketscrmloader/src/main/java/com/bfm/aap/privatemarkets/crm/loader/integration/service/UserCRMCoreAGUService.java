/**
 * 
 */
package com.bfm.aap.privatemarkets.crm.loader.integration.service;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.util.ObjectUtils;

import com.bfm.aap.pmdx.logmetrics.annotation.RecordStats;
import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMResponseStatusEnum;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreUserMessage;
import com.bfm.user.client.impl.RPCAwareUserServiceClient;
import com.blackrock.agraph.platform.identity.user.v1.User;
import com.google.protobuf.FieldMask;
import com.google.protobuf.util.FieldMaskUtil;

/**
 * @author hthakkar
 *
 */
public class UserCRMCoreAGUService {
	private static final Logger LOGGER = LoggerFactory.getLogger(UserCRMCoreAGUService.class);
	private static final String EFRONTINVESTIQID = "eFrontInvestIQID";
	
    @Autowired
    private RPCAwareUserServiceClient rpcAwareUserServiceClient;
    
   @Autowired 
   public UserCRMCoreAGUService(RPCAwareUserServiceClient rpcAwareUserServiceClient) {
	   this.rpcAwareUserServiceClient=rpcAwareUserServiceClient;
   }
    
    @RecordStats
    public Message<CoreUserMessage> mapUserByEmail(Message<CoreUserMessage> msg) {
    	LOGGER.info("eFront User passed with email {}", msg.getPayload().getUserCRM().getUserEmail());
    	msg.getPayload().setAladdinUser(rpcAwareUserServiceClient.searchUser(msg.getPayload().getUserCRM().getUserEmail()));
    	return msg; 
    }
    
    private CRMLoaderResponse mappedAladdinUser(Message<CoreUserMessage> msg) {
    	LOGGER.info("Aladdin User mapping already available for eFrontInvestIQID {} and email {}", 
    			msg.getPayload().getUserCRM().geteFrontId(), msg.getPayload().getUserCRM().getUserEmail());
        return CRMLoaderResponse.newBuilder()
            .setMessage(String.format("Aladdin User mapping already available for eFrontInvestIQID %s and email %s", 
            		msg.getPayload().getUserCRM().geteFrontId(), msg.getPayload().getUserCRM().getUserEmail()))
            .build();
    }

    @RecordStats
    public CRMLoaderResponse createUserMappingWithIQID(Message<CoreUserMessage> msg) {
    	LOGGER.info("Details of Aladdin User to be updated: {}", msg.getPayload().getAladdinUser());
    	LOGGER.info("eFrontInvestIQID which will be leveraged for mapping: {} ", msg.getPayload().getUserCRM().geteFrontId());
    	if (ObjectUtils.isEmpty(msg.getPayload().getAladdinUser().getAlternativeUserIdsMap()) 
    			|| StringUtils.isEmpty(msg.getPayload().getAladdinUser().getAlternativeUserIdsMap().get(EFRONTINVESTIQID))) {
    		FieldMask updateMask = FieldMaskUtil.fromString(User.class, "alternative_user_ids");
    		User updatedUser = User.newBuilder(msg.getPayload().getAladdinUser())
    				.putAlternativeUserIds(EFRONTINVESTIQID, msg.getPayload().getUserCRM().geteFrontId())
    				.build();
    		LOGGER.info("Updated User details: {}", updatedUser);
    		try {
    			msg.getPayload().setAladdinUser(rpcAwareUserServiceClient.updateUser(updatedUser, updateMask));
    		} catch(Exception e) {
    			LOGGER.error("Update User failed for email {} at AGU now continue mapping with EMS if enabled", 
    					msg.getPayload().getUserCRM().getUserEmail());
    		}
    		return buildLoaderResponse(msg);
    	} else {
    		return mappedAladdinUser(msg);
    	}
    }
    
    private CRMLoaderResponse buildLoaderResponse(Message<CoreUserMessage> msg) {
        CRMLoaderResponse.Builder crmResponseBuilder = CRMLoaderResponse.newBuilder();
        if (!ObjectUtils.isEmpty(msg.getPayload().getAladdinUser().getAlternativeUserIdsMap())
        		&& StringUtils.isNotEmpty(msg.getPayload().getAladdinUser().getAlternativeUserIdsMap().get(EFRONTINVESTIQID))) {
            crmResponseBuilder.setStatus(CRMResponseStatusEnum.FULL_SUCCESS);
            crmResponseBuilder.setMessage("User successfully mapped.");
            LOGGER.info("User successfully mapped.");
        } else {
            crmResponseBuilder.setStatus(CRMResponseStatusEnum.CORE_ATTRIBUTE_FAIL);
            crmResponseBuilder.setMessage("User couldn't be mapped.");
            LOGGER.info("User couldn't be mapped.");
        }
        return crmResponseBuilder.build();
    }
}
