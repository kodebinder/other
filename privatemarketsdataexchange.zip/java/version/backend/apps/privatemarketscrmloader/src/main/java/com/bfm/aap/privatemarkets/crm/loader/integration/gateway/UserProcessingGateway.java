package com.bfm.aap.privatemarkets.crm.loader.integration.gateway;

import com.bfm.aap.pmdx.model.User;
import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;

public interface UserProcessingGateway {
    CRMLoaderResponse processMapCRMUser(User user);
}
