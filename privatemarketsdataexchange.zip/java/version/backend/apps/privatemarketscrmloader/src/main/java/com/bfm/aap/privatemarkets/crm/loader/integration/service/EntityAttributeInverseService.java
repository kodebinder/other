package com.bfm.aap.privatemarkets.crm.loader.integration.service;

import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.Legal;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreCompanyInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreContactInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.util.DecodeHelper;
import com.bfm.aap.pmdx.proto.util.ProtoJsonHelper;
import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMResponseStatusEnum;
import com.bfm.aap.privatemarkets.common.crm.util.EntityMasterDecodeTableConstants;
import com.bfm.aap.privatemarkets.crm.loader.util.CRMLoaderConstants;
import com.bfm.entitymaster.dto.common.Decode;
import com.bfm.entitymaster.dto.entityattribute.EntityAttribute;
import io.netty.util.internal.StringUtil;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class EntityAttributeInverseService {

    private static final Logger LOGGER = LoggerFactory.getLogger(EntityAttributeInverseService.class);
    private static final String DEFAULT_DATE_OF_BIRTH = "1/1/1800";//TODO should be removed and replaced with correct value.

    public CRMLoaderResponse getEntityAttributesAndUpdateEfrontContact(CoreContactInverseMessage coreContactInverseMessage) {
        List<EntityAttribute> entityAttributesList = coreContactInverseMessage.getEntityAttributes();
        Contact.Builder contactBuilder = Contact.newBuilder(coreContactInverseMessage.getEfrontEntity());
        entityAttributesList = entityAttributesList.stream()
            .filter(entityAttribute ->
                entityAttribute.getAttribute().equals(CRMLoaderConstants.DATE_OF_BIRTH)
                    || entityAttribute.getAttribute().equals(CRMLoaderConstants.BIRTH_PLACE_CITY)
                    || entityAttribute.getAttribute().equals(CRMLoaderConstants.CITIZENSHIP)).collect(Collectors.toList());
        for (EntityAttribute entityAttribute : entityAttributesList) {
            populateContactEntityAttribute(entityAttribute, contactBuilder);
        }
        return CRMLoaderResponse.newBuilder()
            .setStatus(CRMResponseStatusEnum.FULL_SUCCESS)
            .setMessage(ProtoJsonHelper.convertToJson(contactBuilder.build()))
            .build();
    }

    public CRMLoaderResponse getEntityAttributesAndUpdateEfrontCompany(CoreCompanyInverseMessage coreCompanyInverseMessage) {
        Company.Builder companyBuilder = Company.newBuilder(coreCompanyInverseMessage.getEfrontEntity());

        return CRMLoaderResponse.newBuilder()
            .setStatus(CRMResponseStatusEnum.FULL_SUCCESS)
            .setMessage(ProtoJsonHelper.convertToJson(companyBuilder.build()))
            .build();
    }

    public CRMLoaderResponse getEntityAttributesAndUpdateEfrontInvestor(CoreInvestorInverseMessage coreInvestorInverseMessage) {
        List<EntityAttribute> entityAttributesList = coreInvestorInverseMessage.getEntityAttributes();

        //Set required fields under legal
        Investor.Builder investorBuilder = Investor.newBuilder(coreInvestorInverseMessage.getEfrontEntity())
            .setLegal(Legal.newBuilder().setDateOfBirth(DEFAULT_DATE_OF_BIRTH));

        entityAttributesList = entityAttributesList
                .stream()
                .filter(entityAttribute ->
                        entityAttribute.getAttribute().equals(CRMLoaderConstants.DATE_OF_BIRTH)
                                || entityAttribute.getAttribute().equals(CRMLoaderConstants.BIRTH_PLACE_COUNTRY)
                                || entityAttribute.getAttribute().equals(CRMLoaderConstants.TAX_IDENTIFICATION)
                                || entityAttribute.getAttribute().equals(CRMLoaderConstants.ERISA_INVESTOR)
                                || entityAttribute.getAttribute().equals(CRMLoaderConstants.PRIMARY_TAX_COUNTRY)
                                || entityAttribute.getAttribute().equals(CRMLoaderConstants.FATCA_STATUS)
                ).collect(Collectors.toList());

        if (CollectionUtils.isNotEmpty(entityAttributesList)) {
            entityAttributesList
                    .stream()
                    .forEach(entityAttribute -> {
                        switch (entityAttribute.getAttribute()) {
                            case CRMLoaderConstants.DATE_OF_BIRTH:
                                investorBuilder.getLegalBuilder()
                                        .setDateOfBirth(Optional.ofNullable(entityAttribute)
                                                .map(EntityAttribute::getValue)
                                                .orElse(StringUtil.EMPTY_STRING));
                                break;
                            case CRMLoaderConstants.BIRTH_PLACE_COUNTRY:
                                Optional.ofNullable(entityAttribute)
                                        .map(EntityAttribute::getValue)
                                        .ifPresent(birthPlaceCountry ->
                                                Optional.ofNullable(DecodeHelper.getDecode(EntityMasterDecodeTableConstants.COUNTRIES, birthPlaceCountry))
                                                        .map(Decode::getCode)
                                                        .ifPresent(birthPlaceCountryDecode ->
                                                                investorBuilder.getLegalBuilder().setCountryOfBirth(birthPlaceCountryDecode)));
                                break;
                            case CRMLoaderConstants.TAX_IDENTIFICATION:
                                investorBuilder.getLegalBuilder()
                                        .setTaxIdentification(Optional.ofNullable(entityAttribute)
                                                .map(EntityAttribute::getValue)
                                                .orElse(StringUtil.EMPTY_STRING));
                                break;
                            case CRMLoaderConstants.ERISA_INVESTOR:
                                investorBuilder.getLegalBuilder()
                                        .setErisaInvestor(Optional.ofNullable(entityAttribute)
                                                .map(EntityAttribute::getValue)
                                                .orElse(StringUtil.EMPTY_STRING)
                                                .equals(CRMLoaderConstants.ERISA_STATUTORY));
                                break;
                            case CRMLoaderConstants.PRIMARY_TAX_COUNTRY:
                                Optional.ofNullable(entityAttribute)
                                        .map(EntityAttribute::getValue)
                                        .ifPresent(countryCode ->
                                                Optional.ofNullable(DecodeHelper.getDecode(EntityMasterDecodeTableConstants.COUNTRIES, countryCode))
                                                        .map(Decode::getCode)
                                                        .ifPresent(countryDecode -> investorBuilder.getLegalBuilder().setTaxDomicileCountry(countryDecode)));
                                break;
                            case CRMLoaderConstants.FATCA_STATUS:
                                investorBuilder.getLegalBuilder()
                                        .getFatcaDetailsBuilder()
                                        .setStatus(Optional.ofNullable(entityAttribute)
                                                .map(EntityAttribute::getValue)
                                                .orElse(StringUtil.EMPTY_STRING));
                                break;
                        }
                    });
        }
        return CRMLoaderResponse.newBuilder()
            .setStatus(CRMResponseStatusEnum.FULL_SUCCESS)
            .setMessage(ProtoJsonHelper.convertToJson(investorBuilder.build()))
            .build();
    }

    private void populateContactEntityAttribute(EntityAttribute entityAttribute, Contact.Builder contactBuilder) {
        switch (entityAttribute.getAttribute()) {
            case CRMLoaderConstants.DATE_OF_BIRTH:
                contactBuilder.setDateOfBirth(Optional.ofNullable(entityAttribute)
                        .map(EntityAttribute::getValue)
                        .orElse(StringUtil.EMPTY_STRING));
                break;
            case CRMLoaderConstants.BIRTH_PLACE_CITY:
                contactBuilder.setBirthPlaceCity(Optional.ofNullable(entityAttribute)
                        .map(EntityAttribute::getValue)
                        .orElse(StringUtil.EMPTY_STRING));
                break;
            case CRMLoaderConstants.CITIZENSHIP:
                contactBuilder.setPrimaryCitizenship(Optional.ofNullable(entityAttribute)
                        .map(EntityAttribute::getValue)
                        .orElse(StringUtil.EMPTY_STRING));
                break;
        }
    }


}