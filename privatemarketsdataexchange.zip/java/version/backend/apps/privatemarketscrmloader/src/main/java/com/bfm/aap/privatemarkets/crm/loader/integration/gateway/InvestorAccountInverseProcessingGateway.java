package com.bfm.aap.privatemarkets.crm.loader.integration.gateway;

import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorAccountInverseMessage;

public interface InvestorAccountInverseProcessingGateway {
    CRMLoaderResponse mapEfrontInvestorAccount(CoreInvestorAccountInverseMessage coreInvestorAccountInverseMessage);
}
