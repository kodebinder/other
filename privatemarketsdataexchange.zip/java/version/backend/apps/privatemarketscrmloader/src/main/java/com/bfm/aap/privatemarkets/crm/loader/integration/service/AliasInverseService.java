package com.bfm.aap.privatemarkets.crm.loader.integration.service;

import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.Legal;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreCompanyInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreContactInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.util.DecodeHelper;
import com.bfm.aap.privatemarkets.common.crm.util.EntityMasterDecodeTableConstants;
import com.bfm.entitymaster.dto.alias.Alias;
import com.bfm.entitymaster.dto.common.Decode;
import io.netty.util.internal.StringUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import java.util.List;
import java.util.Optional;

public class AliasInverseService {

    private static final String KNOWN_AS = "AKA";
    private static final String NICKNAME = "NICKNAME";
    private static final String TREASURY_ALIAS = "TSYALIAS";
    private static final String UNAVAILABLE = "Unavailable";

    public CoreCompanyInverseMessage translateToEfrontAliases(CoreCompanyInverseMessage coreCompanyInverseMessage) {
        coreCompanyInverseMessage.setEfrontEntity(
                Company.newBuilder(coreCompanyInverseMessage.getEfrontEntity())
                        .setShortCode(coreCompanyInverseMessage.getCrmCompanyId().toString())
                        .build());

        List<com.bfm.entitymaster.dto.alias.Alias> aliases = coreCompanyInverseMessage.getAliases();
        if (CollectionUtils.isEmpty(aliases)) {
            return coreCompanyInverseMessage;
        }
        aliases.forEach(alias -> {

            String aliasType = Optional.ofNullable(alias)
                    .map(Alias::getAliasType)
                    .map(Decode::getCode)
                    .orElse("");

            String aliasTypeDecode = Optional.ofNullable(DecodeHelper.getDecode(EntityMasterDecodeTableConstants.ENTITY_ALIAS_TYPE, aliasType))
                    .map(Decode::getCode)
                    .orElse(StringUtils.EMPTY);

            switch (aliasTypeDecode) {
                case KNOWN_AS:
                    coreCompanyInverseMessage.setEfrontEntity(Company.newBuilder(coreCompanyInverseMessage.getEfrontEntity())
                        .setKnownAs(Optional.ofNullable(alias)
                            .map(Alias::getAliasName)
                            .orElse(UNAVAILABLE))
                        .build());
                    break;
//                case NICKNAME:
//                    coreCompanyInverseMessage.setEfrontEntity(Company.newBuilder(coreCompanyInverseMessage.getEfrontEntity())
//                            .setShortCode(Optional.ofNullable(alias)
//                                    .map(Alias::getAliasName)
//                                    .orElse(coreCompanyInverseMessage.getCrmCompanyId().toString()))
//                            .build());
//                    break;
//                case TREASURY_ALIAS:
//                    coreCompanyInverseMessage.setEfrontEntity(Company.newBuilder(coreCompanyInverseMessage.getEfrontEntity()).setNumber(Optional.ofNullable(alias)
//                            .map(Alias::getAliasName)
//                            .orElse(UNAVAILABLE))
//                            .build());
//                    break;

            }
        });
        return coreCompanyInverseMessage;
    }

    public CoreInvestorInverseMessage translateToEfrontAliases(CoreInvestorInverseMessage coreInvestorInverseMessage) {

        coreInvestorInverseMessage.setEfrontEntity(
                Investor.newBuilder(coreInvestorInverseMessage.getEfrontEntity())
                        .setShortCode(coreInvestorInverseMessage.getCrmInvestorId().toString())
                        .build());

        List<com.bfm.entitymaster.dto.alias.Alias> aliases = coreInvestorInverseMessage.getAliases();

        if (CollectionUtils.isEmpty(aliases)) {
            return coreInvestorInverseMessage;
        }

        Optional<Legal> legal = Optional.ofNullable(coreInvestorInverseMessage)
                .map(CoreInvestorInverseMessage::getEfrontEntity)
                .map(Investor::getLegal);

        aliases.forEach(alias -> {

            String aliasTypeCode = Optional.ofNullable(alias)
                    .map(Alias::getAliasType)
                    .map(Decode::getCode)
                    .orElse("");

            String aliasTypeDecode = Optional.ofNullable(DecodeHelper.getDecode(EntityMasterDecodeTableConstants.ENTITY_ALIAS_TYPE, aliasTypeCode))
                    .map(Decode::getCode)
                    .orElse(StringUtils.EMPTY);

            switch (aliasTypeDecode) {
                case KNOWN_AS:
                    coreInvestorInverseMessage.setEfrontEntity(
                            Investor.newBuilder(coreInvestorInverseMessage.getEfrontEntity())
                                    .setLegal(legal.map(value -> (Legal.newBuilder(value)
                                            .setLegalName(Optional.ofNullable(alias)
                                                    .map(Alias::getAliasName)
                                                    .orElse(UNAVAILABLE))
                                            .build())).orElseGet(() -> Legal.newBuilder().build())
                                    )
                                    .build()
                    );
                    break;
//                case NICKNAME:
//                    coreInvestorInverseMessage.setEfrontEntity(Investor.newBuilder(coreInvestorInverseMessage.getEfrontEntity())
//                            .setShortCode(Optional.ofNullable(alias)
//                                    .map(Alias::getAliasName)
//                                    .orElse(coreInvestorInverseMessage.getCrmInvestorId().toString()))
//                            .build());
//                    break;
            }
        });
        return coreInvestorInverseMessage;
    }

    public CoreContactInverseMessage translateToEfrontAliases(CoreContactInverseMessage coreContactInverseMessage) {

        List<com.bfm.entitymaster.dto.alias.Alias> aliases = coreContactInverseMessage.getAliases();

        if (CollectionUtils.isEmpty(aliases)) {
            return coreContactInverseMessage;
        }

        aliases.stream().forEach(alias -> {
            String aliasType = Optional.ofNullable(alias)
                    .map(Alias::getAliasType)
                    .map(Decode::getCode)
                    .orElse("");
            if (!aliasType.isEmpty()) {
                switch (DecodeHelper.getDecode(EntityMasterDecodeTableConstants.ENTITY_ALIAS_TYPE, aliasType).getCode()) {
                    case NICKNAME:
                        coreContactInverseMessage.setEfrontEntity(
                            Contact.newBuilder(coreContactInverseMessage.getEfrontEntity())
                                .setNickName(Optional.ofNullable(alias)
                                    .map(Alias::getAliasName)
                                    .orElse(StringUtil.EMPTY_STRING))
                                .build());
                        break;
                }
            }
        });
        return coreContactInverseMessage;
    }
}