package com.bfm.aap.privatemarkets.crm.loader.integration.service.impl;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.protobuf.Timestamp;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.ContactEmail;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.bfm.aap.privatemarkets.common.constant.CommonConstants;
import com.bfm.aap.privatemarkets.crm.loader.integration.service.TransformerService;
import com.bfm.aap.privatemarkets.crm.loader.mapper.AddressInverseTransformer;
import com.bfm.aap.privatemarkets.crm.loader.mapper.ContactInverseTransformer;
import com.bfm.aap.privatemarkets.crm.loader.mapper.EmailInverseTransformer;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreContactInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.util.ElectronicAddressConstants;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.entitymaster.dto.common.Address;
import com.bfm.entitymaster.dto.common.ElectronicAddress;
import com.bfm.entitymaster.dto.contact.ContactDetail;
import com.bfm.entitymaster.dto.entityrelationship.Employment;
import com.bfm.entitymaster.dto.entitythirdparty.ThirdPartyMapping;
import com.bfm.util.beans.CollectionUtils;

public class CoreContactInverseTransformerServiceImpl implements TransformerService<CoreContactInverseMessage, CoreContactInverseMessage> {

    private static final Logger LOGGER = LoggerFactory.getLogger(CoreContactInverseTransformerServiceImpl.class);

    @Autowired
    private ContactInverseTransformer contactTransformer;
    @Autowired
    private EmailInverseTransformer emailInverseTransformer;
    @Autowired
    private AddressInverseTransformer addressInverseTransformer;
    @Autowired
    private CRMThirdPartyMapperService crmThirdPartyMapperService;

    /**
     * @param coreContactInverseMessage
     * @return
     * @throws Exception
     */
    @Override
    public CoreContactInverseMessage transform(CoreContactInverseMessage coreContactInverseMessage) throws Exception {
        ContactDetail contactDetail = coreContactInverseMessage.getCrmEntity();
        Contact.Builder contactBuilder = Contact.newBuilder(
                contactTransformer.crmToEfrontTransformer(contactDetail.getContact()));

        if (!CollectionUtils.isEmpty(contactDetail.getElectronicAddressList())) {

            contactBuilder.addAllEmailList(
                    populateElectronAddressEmailType(contactDetail.getElectronicAddressList()))
                    .build();

            for (ElectronicAddress electronicAddress : contactDetail.getElectronicAddressList()) {
                populateElectronAddressWebType(contactBuilder, electronicAddress);
            }
        }

        updateContactCompanyRelationship(contactBuilder, coreContactInverseMessage);
        updateContactModifiedBy(contactBuilder, coreContactInverseMessage.getModifiedByCRMUserEntityId());
        updateModificationDateTime(contactBuilder);
        updateContactId(contactBuilder, coreContactInverseMessage.getCrmContactId());
        updateContactEntityInfo(contactBuilder);
        coreContactInverseMessage.setEfrontEntity(contactBuilder.build());

        return coreContactInverseMessage;
    }

    private List<ContactEmail> populateElectronAddressEmailType(List<ElectronicAddress> electronicAddressList) {

        List<ContactEmail> contactEmailList = new ArrayList<>();

        electronicAddressList
                .stream()
                .filter(electronicAddress -> ElectronicAddressConstants.EMAIL.equals(electronicAddress.getElectronicType().getCode()))
                .filter(ElectronicAddress :: getPrimary)
                .findFirst()
                .ifPresent(electronicAddress -> contactEmailList.add(emailInverseTransformer.eFrontToCRMTransform(electronicAddress)));

        return contactEmailList;
    }

    private void updateContactEntityInfo(Contact.Builder contactBuilder) {
        contactBuilder.setEntityInfo(EntityInfo.newBuilder()
            .setNetworkMode(CommonConstants.NETWORK_MODE)
                .setOriginTimestamp(Timestamp.newBuilder()
                        .setSeconds(Instant.now().getEpochSecond())
                        .setNanos(Instant.now().getNano())
                        .build())
                .setPrimaryData(Boolean.TRUE)//TODO check for primary or not
                .build());
    }

    private void updateContactId(Contact.Builder contactBuilder, Integer crmContactId) {
        ThirdPartyMapping thirdPartyMapping = crmThirdPartyMapperService.lookupThirdPartMapping(crmContactId, ThirdPartyMappingEnum.CONTACT_INVEST);
        if (null != thirdPartyMapping) {
            contactBuilder.setContactId(thirdPartyMapping.getThirdPartyIdentifier());
        }
    }

    private void updateModificationDateTime(Contact.Builder contactBuilder) {
        contactBuilder.setModificationDateTime(
                Timestamp.newBuilder()
                        .setSeconds(Instant.now().getEpochSecond())
                        .setNanos(Instant.now().getNano())
                        .build());
    }

    private Contact.Builder updateContactAddresses(Contact.Builder contactBuilder, List<Address> addresses) {
        if (CollectionUtils.isEmpty(addresses)) {
            return contactBuilder;
        }
        //TODO fix address issues.
        for (Address address : addresses) {
//            Contact.newBuilder(contactProto).addaddgetAddressListList().add(addressInverseTransformer.crmToEfrontTransform(address));
//            contactProto.
        }
        return contactBuilder;
    }

    private void updateContactModifiedBy(Contact.Builder contactBuilder, Integer modifiedByUserCRMId) {
        ThirdPartyMapping thirdPartyMapping = crmThirdPartyMapperService.lookupThirdPartMapping(modifiedByUserCRMId, ThirdPartyMappingEnum.CONTACT_INVEST);
        if (null != thirdPartyMapping) {
            contactBuilder.setModifiedBy(thirdPartyMapping.getThirdPartyIdentifier());
        }
    }

    /**
     * @param contactBuilder
     * @param electronicAddress
     * @return
     */
    private void populateElectronAddressWebType(Contact.Builder contactBuilder, ElectronicAddress electronicAddress) {
        if (ElectronicAddressConstants.WEB.equals(electronicAddress.getElectronicType().getCode())) {
            switch (electronicAddress.getElectronicSubType().getCode()) {
                case ElectronicAddressConstants.FACEBOOK:
                    contactBuilder.setFacebook(electronicAddress.getAddress());
                    break;
                case ElectronicAddressConstants.LINKEDIN:
                    contactBuilder.setLinkedin(electronicAddress.getAddress());
                    break;
                case ElectronicAddressConstants.TWITTER:
                    contactBuilder.setTwitter(electronicAddress.getAddress());
                    break;
                case ElectronicAddressConstants.OTHER:
                    contactBuilder.setSkype(electronicAddress.getAddress());
                    break;
                default:
                    LOGGER.info("ElectronicAddress subtype {} could not be mapped.", electronicAddress.getElectronicSubType().getCode());
                    break;
            }
        }
    }

    /**
     * @param contactBuilder
     * @param coreContactInverseMessage
     * @return
     */
    private Contact.Builder updateContactCompanyRelationship(Contact.Builder contactBuilder, CoreContactInverseMessage coreContactInverseMessage) {
        List<Employment> employers = coreContactInverseMessage.getEmployer();
        if (CollectionUtils.isEmpty(employers)) {
            LOGGER.info("No employers found for contact entityId : {}", coreContactInverseMessage.getCrmEntity());
            return contactBuilder;
        }
        employers.stream()
                .filter(employment -> {
                    return  !(Optional.ofNullable(employment)
                            .map(Employment::getFormerEmployee)
                            .orElse(false));
                })
                .findFirst()
                .ifPresent(employment -> {
                    Integer employerEntityId = employment.getEmployerEntityId();
                    ThirdPartyMapping thirdPartyMapping = crmThirdPartyMapperService.lookupThirdPartMapping(employerEntityId, ThirdPartyMappingEnum.COMPANY_INVEST);
                    String efrontEmployerEntityId = Optional.ofNullable(thirdPartyMapping)
                            .map(ThirdPartyMapping::getThirdPartyIdentifier)
                            .orElseGet(() -> StringUtils.EMPTY);
                    if (StringUtils.isNotEmpty(efrontEmployerEntityId)) {
                        contactBuilder.setCompanyId(efrontEmployerEntityId);
                    }
                });

        return contactBuilder;
    }
}