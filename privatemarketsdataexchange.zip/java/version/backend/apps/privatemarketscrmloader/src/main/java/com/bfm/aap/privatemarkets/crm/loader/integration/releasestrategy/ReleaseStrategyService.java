package com.bfm.aap.privatemarkets.crm.loader.integration.releasestrategy;

import java.util.List;

import com.bfm.aap.privatemarkets.common.crm.model.CRMChannelResponseList;

public class ReleaseStrategyService {
    private static final int CONTACT_COMPLETION_CHANNELS = 2;
    private static final int COMPANY_COMPLETION_CHANNELS = 5;
    private static final int INVESTOR_COMPLETION_CHANNELS = 3;

    public boolean checkInvestorCompletion(List<CRMChannelResponseList> responseList) {
        return checkIfComplete(responseList, INVESTOR_COMPLETION_CHANNELS);
    }

    public boolean checkCompanyCompletion(List<CRMChannelResponseList> responseList) {
        return checkIfComplete(responseList, COMPANY_COMPLETION_CHANNELS);
    }

    public boolean checkContactCompletion(List<CRMChannelResponseList> responseList) {
        return checkIfComplete(responseList, CONTACT_COMPLETION_CHANNELS);
    }

    private boolean checkIfComplete(List<CRMChannelResponseList> responseList, int channelCount) {
        return responseList.size() >= channelCount;
    }
}