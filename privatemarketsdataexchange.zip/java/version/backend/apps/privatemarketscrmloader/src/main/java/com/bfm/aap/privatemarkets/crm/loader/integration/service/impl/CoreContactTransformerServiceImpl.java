package com.bfm.aap.privatemarkets.crm.loader.integration.service.impl;

import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.ContactEmail;
import com.bfm.aap.pmdx.model.util.SchemaEnum;
import com.bfm.aap.privatemarkets.crm.loader.mapper.ContactTransformer;
import com.bfm.aap.privatemarkets.crm.loader.mapper.EmailTransformer;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreContactMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.ElectronicAddressMessage;
import com.bfm.aap.privatemarkets.crm.loader.integration.service.TransformerService;
import com.bfm.entitymaster.dto.common.ElectronicAddress;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class CoreContactTransformerServiceImpl implements TransformerService<CoreContactMessage, Contact> {

    private static final Logger LOGGER = LoggerFactory.getLogger(CoreContactTransformerServiceImpl.class);
    
    @Autowired
    private ContactTransformer contactTransformer;
    @Autowired
    private EmailTransformer emailTransformer;

    @Override
    public CoreContactMessage transform(Contact contact) {
        CoreContactMessage coreContact = new CoreContactMessage();
        coreContact.setCrmContact(contactTransformer.eFrontToCRMTransform(contact, SchemaEnum.EFRONT_CONTACT_SCHEMA));
        coreContact.setPmdxContact(contact);
        coreContact.setPrimaryEmail(createMessage(emailTransformer.eFrontToCRMTransform(getPrimaryEmail(contact.getEmailListList()), SchemaEnum.EFRONT_CONTACT_SCHEMA), 0));
        return coreContact;
    }

    private ContactEmail getPrimaryEmail(List<ContactEmail> emailList) {
        return emailList.stream()
                .filter(ContactEmail::getIsPrimary)
                .findAny()
                .orElseThrow(() -> new RuntimeException("Primary Email is mandatory for contact creation"));
    }

    private ElectronicAddressMessage createMessage(ElectronicAddress address, int linkedCRMEntityId) {
        ElectronicAddressMessage msg = new ElectronicAddressMessage();
        msg.setElectronicAddress(address);
        msg.setLinkedCRMEntityId(linkedCRMEntityId);
        return msg;
    }

    public void setContactTransformer(ContactTransformer contactTransformer) {
        this.contactTransformer = contactTransformer;
    }

    public void setEmailTransformer(EmailTransformer emailTransformer) {
        this.emailTransformer = emailTransformer;
    }
}
