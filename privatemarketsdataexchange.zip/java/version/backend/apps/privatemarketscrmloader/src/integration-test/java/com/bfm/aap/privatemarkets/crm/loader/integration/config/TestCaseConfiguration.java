package com.bfm.aap.privatemarkets.crm.loader.integration.config;

import org.springframework.context.annotation.Import;

@Import(ApplicationConfiguration.class)
public class TestCaseConfiguration {

}
