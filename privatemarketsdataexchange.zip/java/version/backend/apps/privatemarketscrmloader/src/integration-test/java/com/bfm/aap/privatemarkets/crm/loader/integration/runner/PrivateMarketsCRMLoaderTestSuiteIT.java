package com.bfm.aap.privatemarkets.crm.loader.integration.runner;

import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;

import com.bfm.aap.privatemarkets.crm.loader.integration.config.TestCaseConfiguration;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features = "classpath:features", 
				 glue = "com.bfm.aap.privatemarkets.crm.loader.integration.stepDefinition",
				 plugin = { "html:src/integration-test/resources/cucumber",
						    "json:src/integration-test/resources/cucumber/cucumber-privatemarketscrmloader.json",
						    "junit:src/integration-test/resources/cucumber/cucumber.xml",
						    "pretty:src/integration-test/resources/cucumber/cucumber-pretty.txt" },
				 tags = "not @ignore")
@ContextConfiguration(classes = TestCaseConfiguration.class)
public class PrivateMarketsCRMLoaderTestSuiteIT {

}
