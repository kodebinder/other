package com.bfm.aap.privatemarkets.crm.loader;

import java.io.IOException;
import java.util.Optional;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;
import com.bfm.aap.privatemarkets.crm.loader.api.CRMLoaderService;
import com.bfm.aap.privatemarkets.util.EntityReaderUtil;

@Disabled("Not created to be executed during app build")
@SpringJUnitConfig(PrivateMarketsCRMLoaderTest.ContextConfiguration.class)
class PrivateMarketsCRMLoaderTest {

    @BeforeAll
    public static void setUp() throws IOException {
        System.setProperty("properties", "PrivateMarketsCRMLoader.properties");
        System.setProperty("mode","BLUE");
        System.setProperty("BRS.PMDX_BASE_DIR_RED", "/Volumes/unix_home/bfm/apps/privatemarketsdataexchange/red/"); // ssh dev, ln -s /usr/local/bfm
    }

    @Configuration
    @ComponentScan({"com.bfm.aap.privatemarkets.crm.loader.api",
        "com.bfm.aap.privatemarkets.crm.loader.service",
        "com.bfm.aap.privatemarkets.crm.thirdparty.mapper"})
    @ImportResource("classpath:/spring-integration-config.xml")
    static class ContextConfiguration {

    }

    @Autowired
    private CRMLoaderService crmLoaderService;

    @Test
    public void contactTest() throws IOException {
        Optional<Contact> optionalContact = EntityReaderUtil.parseEntityFromFile(Contact.class, "contact_pinkman.json");

        if (optionalContact.isPresent()) {
            CRMLoaderResponse loaderResponse = crmLoaderService.mapCRMContact(optionalContact.get());

            loaderResponse.getStatus();
        }
    }

    @Test
    public void companyTest() throws IOException {
        Optional<Company> optionalCompany = EntityReaderUtil.parseEntityFromFile(Company.class, "company_heisenberg.json");

        if (optionalCompany.isPresent()) {
            CRMLoaderResponse loaderResponse = crmLoaderService.mapCRMCompany(optionalCompany.get());

            loaderResponse.getStatus();
        }
    }

}
