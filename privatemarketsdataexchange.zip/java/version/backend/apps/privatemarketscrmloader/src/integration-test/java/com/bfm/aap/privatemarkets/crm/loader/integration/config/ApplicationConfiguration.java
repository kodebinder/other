package com.bfm.aap.privatemarkets.crm.loader.integration.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan({ "com.bfm.aap.privatemarkets.crm.loader.integration.service",
		         "com.bfm.aap.privatemarkets.crm.loader.config" })
public class ApplicationConfiguration {

}
