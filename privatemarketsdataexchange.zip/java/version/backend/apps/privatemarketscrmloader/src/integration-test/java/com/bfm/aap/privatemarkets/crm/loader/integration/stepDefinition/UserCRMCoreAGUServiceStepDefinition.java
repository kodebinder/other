package com.bfm.aap.privatemarkets.crm.loader.integration.stepDefinition;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Map;

import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;
import com.bfm.aap.privatemarkets.crm.loader.integration.service.UserCRMCoreAGUService;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreUserMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.UserCRM;
import com.bfm.user.client.impl.RPCAwareUserServiceClient;
import com.blackrock.agraph.platform.identity.user.v1.User;
import com.blackrock.agraph.platform.identity.user.v1.User.UserProfile;

import io.cucumber.datatable.DataTable;
import io.cucumber.java8.En;

public class UserCRMCoreAGUServiceStepDefinition implements En {

	private UserCRMCoreAGUService userCRMCoreAGUService;
	private Map<String, String> validUserCache;
	private Map<String, String> invalidUserCache;
	private Message<CoreUserMessage> userMessageForSearchByEmailValidCase;
	private Message<CoreUserMessage> userMessageForSearchByEmailInvalidCase;
	private Message<CoreUserMessage> message;
	private CRMLoaderResponse crmLoaderResponse;

	private RPCAwareUserServiceClient rpcAwareUserServiceClient;

	public UserCRMCoreAGUServiceStepDefinition() {
		Before(() -> {
			rpcAwareUserServiceClient = new RPCAwareUserServiceClient();
			userCRMCoreAGUService = new UserCRMCoreAGUService(rpcAwareUserServiceClient);
		});

		Given("^eFront user valid details are provided$", (DataTable dataTable) -> {
			validUserCache = dataTable.asMap(String.class, String.class);
		});

		Given("^eFront user invalid details are provided$", (DataTable dataTable) -> {
			invalidUserCache = dataTable.asMap(String.class, String.class);
		});

		When("^we get user message for search based on email$", () -> {
			userMessageForSearchByEmailValidCase = getUserMessageForSearchByEmailValidCase(validUserCache.get("email"));
			assertNotNull(userMessageForSearchByEmailValidCase);
		});
		
		When("^we do not get user message for search based on email$", () -> {
			userMessageForSearchByEmailInvalidCase = getUserMessageForSearchByEmailInvalidCase(invalidUserCache.get("email"));
			assertNotNull(userMessageForSearchByEmailInvalidCase);
		});

		And("^we map user based on email$", () -> {
			message = userCRMCoreAGUService.mapUserByEmail(userMessageForSearchByEmailValidCase);
			assertNotNull(message);
		});
		
		And("^we are not able to map user based on email$", () -> {
			boolean hasExceptionOccurred = false;
			try {
				userCRMCoreAGUService.mapUserByEmail(userMessageForSearchByEmailInvalidCase);
			}catch(Exception e) {
				hasExceptionOccurred = true;
			}
			assertTrue(hasExceptionOccurred);
		});

		Then("^eFront user can be mapped to aladdin user via email$", () -> {
			String actual = message.getPayload().getAladdinUser().getProfile().getEmail();
			String expected = validUserCache.get("email");
			assertThat(actual).isEqualTo(expected);
		});
		
		Then("^eFront user cannot be mapped to aladdin user via email$", () -> {
			boolean hasExceptionOccurred = false;
			try {
				String email = message.getPayload().getAladdinUser().getProfile().getEmail();
				assertNotNull(email);
			}catch(Exception e) {
				hasExceptionOccurred = true;
			}
			assertTrue(hasExceptionOccurred);
		});

		When("^we create user mapping based on IQID$", () -> {
			crmLoaderResponse = userCRMCoreAGUService.createUserMappingWithIQID(
					getUserMessageForMappingWitheFrontInvestIQID(validUserCache.get("eFrontId"),
							validUserCache.get("userId"), validUserCache.get("email")));
		});

		When("^we cannot create user mapping based on IQID$", () -> {
			assertNotNull(userCRMCoreAGUService.createUserMappingWithIQID(getUserMessageForMappingWitheFrontInvestIQID(
					invalidUserCache.get("eFrontId"), invalidUserCache.get("userId"), invalidUserCache.get("email"))));
		});

		And("^we validate response returned by CRMLoader$", () -> {
			assertNotNull(crmLoaderResponse);
		});
		
		And("^we validate negative response returned by CRMLoader$", () -> {
			assertNotNull(userCRMCoreAGUService.createUserMappingWithIQID(getUserMessageForMappingWitheFrontInvestIQID(
					invalidUserCache.get("eFrontId"), invalidUserCache.get("userId"), invalidUserCache.get("email"))));
		});

		Then("^aladdin user mapping should be available$", () -> {
			String actual = crmLoaderResponse.getMessage();
			String expected = "Aladdin User mapping already available for eFrontInvestIQID 68C6CB6667474A46AFE8252EB760611T and email himanshu.thakkar@blackrock.com";
			assertThat(actual).isEqualTo(expected);
		});

		Then("^aladdin user mapping should not be available$", () -> {
			assertNotNull(
					userCRMCoreAGUService
							.createUserMappingWithIQID(
									getUserMessageForMappingWitheFrontInvestIQID(invalidUserCache.get("eFrontId"),
											invalidUserCache.get("userId"), invalidUserCache.get("email")))
							.getMessage());
		});

	}

	private Message<CoreUserMessage> getUserMessageForSearchByEmailValidCase(String email) {
		CoreUserMessage coreUserMessage = new CoreUserMessage();
		UserCRM userCRM = getUserCRMObject(validUserCache.get("eFrontId"), validUserCache.get("userId"),
				validUserCache.get("email"));
		coreUserMessage.setUserCRM(userCRM);
		return MessageBuilder.withPayload(coreUserMessage).setHeader("user", "userLogin").build();
	}
	
	private Message<CoreUserMessage> getUserMessageForSearchByEmailInvalidCase(String email) {
		CoreUserMessage coreUserMessage = new CoreUserMessage();
		UserCRM userCRM = getUserCRMObject(invalidUserCache.get("eFrontId"), invalidUserCache.get("userId"),
				invalidUserCache.get("email"));
		coreUserMessage.setUserCRM(userCRM);
		return MessageBuilder.withPayload(coreUserMessage).setHeader("user", "userLogin").build();
	}

	private UserCRM getUserCRMObject(String eFrontId, String userId, String email) {
		UserCRM userCRM = new UserCRM();
		userCRM.seteFrontId(eFrontId);
		userCRM.seteFrontUserId(userId);
		userCRM.setUserEmail(email);
		return userCRM;
	}

	private User getAladdinUserWitheFrontInvestIQID(String eFrontId, String userId, String email) {
		User user = User.newBuilder().setProfile(UserProfile.newBuilder().setEmail(email)).setId(userId)
				.putAlternativeUserIds("eFrontInvestIQID", eFrontId).build();
		return user;
	}

	private Message<CoreUserMessage> getUserMessageForMappingWitheFrontInvestIQID(String eFrontId, String userId,
			String email) {
		CoreUserMessage coreUserMessage = new CoreUserMessage();
		UserCRM userCRM = getUserCRMObject(eFrontId, userId, email);
		coreUserMessage.setUserCRM(userCRM);
		User user = getAladdinUserWitheFrontInvestIQID(eFrontId, userId, email);
		coreUserMessage.setAladdinUser(user);
		return MessageBuilder.withPayload(coreUserMessage).setHeader("user", "userLogin").build();
	}

}
