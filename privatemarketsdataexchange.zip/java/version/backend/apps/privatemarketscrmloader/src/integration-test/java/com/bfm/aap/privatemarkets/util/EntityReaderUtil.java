package com.bfm.aap.privatemarkets.util;

import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.Transaction;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.bfm.aap.pmdx.utils.gson.ProtoAdapter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.google.protobuf.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.Optional;
import java.util.stream.Collectors;

public class EntityReaderUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(EntityReaderUtil.class);

    private static final Gson gson;

    private EntityReaderUtil() {}

    static {
        GsonBuilder gsonBuilder = new GsonBuilder();
        ProtoAdapter.addTypeRegistry(EntityInfo.class);
        gson = gsonBuilder
            .registerTypeAdapter(Contact.class, new ProtoAdapter(Contact.class))
            .registerTypeAdapter(Company.class, new ProtoAdapter(Company.class))
            .registerTypeAdapter(Transaction.class, new ProtoAdapter(Transaction.class))
            .create();
    }

    public static <T extends Message> Optional<T> parseEntityFromFile(Class<T> clazz, String fileName) throws IOException {
        String content = getFileContentFromResources(fileName);

        if (clazz.isAssignableFrom(Contact.class)) {
            Type contactType = new TypeToken<Contact>() {}.getType();
            return Optional.of(gson.fromJson(content, contactType));
        } else if (clazz.isAssignableFrom(Company.class)) {
            Type companyType = new TypeToken<Company>() {}.getType();
            return Optional.of(gson.fromJson(content, companyType));
        } else
            return Optional.empty();
    }

    private static String getFileContentFromResources(String fileName) {
        try (InputStream inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName)) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            return reader.lines().collect(Collectors.joining(System.lineSeparator()));
        } catch (Exception e) {
            LOGGER.error("Failed to read file {}", fileName, e);
            throw new RuntimeException(e.getMessage());
        }
    }

}
