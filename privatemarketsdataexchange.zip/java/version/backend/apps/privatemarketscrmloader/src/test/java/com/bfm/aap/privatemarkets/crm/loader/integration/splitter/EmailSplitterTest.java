package com.bfm.aap.privatemarkets.crm.loader.integration.splitter;

import com.bfm.aap.pmdx.model.Address;
import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.ContactEmail;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.Legal;
import com.bfm.aap.pmdx.model.util.SchemaEnum;
import com.bfm.aap.privatemarkets.crm.loader.mapper.ElectronicAddressTransformer;
import com.bfm.aap.privatemarkets.crm.loader.mapper.EmailTransformer;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreCompanyMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreContactMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.ElectronicAddressMessage;
import com.bfm.entitymaster.dto.common.Decode;
import com.bfm.entitymaster.dto.common.ElectronicAddress;
import com.bfm.entitymaster.dto.common.Entity;
import com.bfm.entitymaster.dto.contact.Contact;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class EmailSplitterTest {
    @InjectMocks
    private EmailSplitter emailSplitter;
    @Mock
    EmailTransformer emailTransformer;
    @Mock
    ElectronicAddressTransformer electronicAddressTransformer;

    @Test
    public void splitAndPublish_Test_Only_One_Email() {
        Message<CoreContactMessage> msg = getContactWithJustOneEmail();
        ElectronicAddress electronicAddress = getEmailAddress("test@gmail.com", true);
        when(emailTransformer.eFrontToCRMTransform(any(ContactEmail.class), any(SchemaEnum.class))).thenReturn(electronicAddress);
        List<ElectronicAddressMessage> electronicAddressList = emailSplitter.splitAndPublishContactElectronicAddress(msg);
        assertTrue(electronicAddressList.size() == 1);
        assertTrue(electronicAddressList.get(0).getElectronicAddress().getAddress().equals("test@gmail.com"));
    }

    @Test
    public void splitAndPublish_Test_Only_One_Email_And_Twitter() {
        Message<CoreContactMessage> msg = getContactWithJustOneEmailAndTwitter();
        ElectronicAddress electronicAddress = getEmailAddress("test@gmail.com", true);

        ElectronicAddress electronicAddressWeb = getElectronicAddress("@test", false, "Twitter");

        when(emailTransformer.eFrontToCRMTransform(any(ContactEmail.class), any(SchemaEnum.class))).thenReturn(electronicAddress);
        when(electronicAddressTransformer.eFrontToCRMTransform(anyString(), anyString(), any(SchemaEnum.class))).thenReturn(electronicAddressWeb);
        List<ElectronicAddressMessage> electronicAddressList = emailSplitter.splitAndPublishContactElectronicAddress(msg);
        assertTrue(electronicAddressList.size() == 2);
    }

    @Test
    public void splitAndPublish_Test_Only_One_Email_And_Facebook() {
        Message<CoreContactMessage> msg = getContactWithJustOneEmailAndFacebook();
        ElectronicAddress electronicAddress = getEmailAddress("test@gmail.com", true);

        ElectronicAddress electronicAddressWeb = getElectronicAddress("@test", false, "Facebook");
        when(emailTransformer.eFrontToCRMTransform(any(ContactEmail.class), any(SchemaEnum.class))).thenReturn(electronicAddress);
        when(electronicAddressTransformer.eFrontToCRMTransform(anyString(), anyString(), any(SchemaEnum.class))).thenReturn(electronicAddressWeb);
        List<ElectronicAddressMessage> electronicAddressList = emailSplitter.splitAndPublishContactElectronicAddress(msg);
        assertTrue(electronicAddressList.size() == 2);
    }

    @Test
    public void splitAndPublish_Test_Only_One_Email_And_LinkedIn() {
        Message<CoreContactMessage> msg = getContactWithJustOneEmailAndLinkedIn();
        ElectronicAddress electronicAddress = getEmailAddress("test@gmail.com", true);

        ElectronicAddress electronicAddressWeb = getElectronicAddress("@test", false, "LinkedIn");

        when(emailTransformer.eFrontToCRMTransform(any(ContactEmail.class), any(SchemaEnum.class))).thenReturn(electronicAddress);
        when(electronicAddressTransformer.eFrontToCRMTransform(anyString(), anyString(), any(SchemaEnum.class))).thenReturn(electronicAddressWeb);
        List<ElectronicAddressMessage> electronicAddressList = emailSplitter.splitAndPublishContactElectronicAddress(msg);
        assertTrue(electronicAddressList.size() == 2);
    }

    @Test
    public void splitAndPublish_Test_Only_One_Email_And_Skype() {
        Message<CoreContactMessage> msg = getContactWithJustOneEmailAndSkype();
        ElectronicAddress electronicAddress = getEmailAddress("test@gmail.com", true);

        ElectronicAddress electronicAddressWeb = getElectronicAddress("@test", false, "Other");

        when(emailTransformer.eFrontToCRMTransform(any(ContactEmail.class), any(SchemaEnum.class))).thenReturn(electronicAddress);
        when(electronicAddressTransformer.eFrontToCRMTransform(anyString(), anyString(), any(SchemaEnum.class))).thenReturn(electronicAddressWeb);
        List<ElectronicAddressMessage> electronicAddressList = emailSplitter.splitAndPublishContactElectronicAddress(msg);
        assertTrue(electronicAddressList.size() == 2);
    }

    @Test
    public void splitAndPublish_Test_Only_Social_Media() {
        Message<CoreContactMessage> msg = getContactWithJustTwitter();

        ElectronicAddress electronicAddressWeb = getElectronicAddress("@test", false, "Twitter");

        when(electronicAddressTransformer.eFrontToCRMTransform(anyString(), anyString(), any(SchemaEnum.class))).thenReturn(electronicAddressWeb);
        List<ElectronicAddressMessage> electronicAddressList = emailSplitter.splitAndPublishContactElectronicAddress(msg);
        assertTrue(electronicAddressList.size() == 1);
        assertTrue(electronicAddressList.get(0).getElectronicAddress().getAddress().equals("@test"));
    }
    @Test
    public void splitAndPublishCompanyElectronicAddress_Test(){
        when(electronicAddressTransformer.eFrontToCRMTransform("test05", "Twitter", SchemaEnum.EFRONT_COMPANY_SCHEMA))
                .thenReturn(getElectronicAddress("test05", false, "Twitter"));
        when(electronicAddressTransformer.eFrontToCRMTransform("test05", "LinkedIn", SchemaEnum.EFRONT_COMPANY_SCHEMA))
                .thenReturn(getElectronicAddress("test05", false, "LinkedIn"));
        when(electronicAddressTransformer.eFrontToCRMTransform("www.test05.com", "Other", SchemaEnum.EFRONT_COMPANY_SCHEMA))
                .thenReturn(getElectronicAddress("www.test05.com", false, "Other"));
        List<ElectronicAddressMessage> electronicAddressList = emailSplitter.splitAndPublishCompanyElectronicAddress(getCompanyMsg());
        assertTrue(electronicAddressList.size() == 3);

    }
    @Test
    public void splitAndPublishInvestorElectronicAddress_Test(){
        when(electronicAddressTransformer.eFrontToCRMTransform(anyString(), anyString(), any(SchemaEnum.class)))
                .thenReturn(getElectronicAddress("www.test.com", false, "WWWOTHER"));
        List<ElectronicAddressMessage> electronicAddressList = emailSplitter.splitAndPublishInvestorElectronicAddress(getInvestorMsg());
        assertTrue(electronicAddressList.size() == 1);
        assertTrue(electronicAddressList.get(0).getElectronicAddress().getAddress().equals("www.test.com"));

    }
    private Message<CoreInvestorMessage> getInvestorMsg(){
        com.bfm.aap.pmdx.model.Address address = com.bfm.aap.pmdx.model.Address.newBuilder().setId("123").setStreet1("Street1").setStreet2("street2").setIsPrimary(true)
                .setState("WA").setAddressType("Home").setCity("Seattle").setCountry("USA").setZipCode("98101").build();
        CoreInvestorMessage msg = new CoreInvestorMessage();
        Entity entity = new Entity();
        entity.setEntityName("ABC Company");
        entity.setEntityType("O");
        entity.setEntityId(123);
        Legal legal = Legal.newBuilder().setLegalDomicileCountry("US").build();
        Investor investor = Investor.newBuilder().setName("ABC Company").setShortCode("ABC").setInvestorType("BANK")
                .setLegal(legal).setDescription("TestDescription").setWeb("www.test.com").setCompanyId("ABC").addOfficeAddressList(address).build();
        msg.setOrgEntity(entity);
        msg.setInvestor(investor);
        return MessageBuilder.withPayload(msg).build();
    }

    private Message<CoreCompanyMessage> getCompanyMsg() {
        Address address = Address.newBuilder().setId("123").setStreet1("Street1").setStreet2("street2").setIsPrimary(true)
                .setState("WA").setAddressType("Home").setCity("Seattle").setCountry("USA").setZipCode("98101").build();

        CoreCompanyMessage msg = new CoreCompanyMessage();
        Entity entity = new Entity();
        entity.setEntityName("ABC Company");
        entity.setEntityType("O");
        entity.setEntityId(123);
        msg.setCompany(Company.newBuilder().setCompanyId("444")
                .addOfficeAddressList(address)
                .setLinkedin("test05")
                .setTwitter("test05")
                .setWeb("www.test05.com")
                .setLegalFormInsight("LegalAttribute").setDescription("testDescription")
                .setName("ABC Company").setDomicile("US").setStatus("BANK").build());
        msg.setOrgEntity(entity);
        Message<CoreCompanyMessage> message = MessageBuilder.withPayload(msg).build();
        return message;
    }
    private ElectronicAddressMessage getMessage(int entityId,String address,String platform){
        ElectronicAddressMessage msg = new ElectronicAddressMessage();
        msg.setLinkedCRMEntityId(entityId);
        msg.setElectronicAddress(getElectronicAddress(address, false, platform));
        return msg;
    }
    private ElectronicAddress getElectronicAddress(String address, boolean isPrimary, String platform) {
        ElectronicAddress electronicAddressWeb = new ElectronicAddress();
        electronicAddressWeb.setAddress(address);
        electronicAddressWeb.setPrimary(isPrimary);
        electronicAddressWeb.setElectronicType(getDecode("WEB","Web"));
        electronicAddressWeb.setElectronicSubType(getDecode(platform,platform));
        return electronicAddressWeb;
    }

    private ElectronicAddress getEmailAddress(String email, boolean isPrimary) {
        ElectronicAddress electronicAddress = new ElectronicAddress();
        electronicAddress.setAddress(email);
        electronicAddress.setPrimary(isPrimary);
        electronicAddress.setElectronicType(getDecode("EMAIL","Email"));
        electronicAddress.setElectronicSubType(getDecode("PROFESSIONAL","Professional"));
        return electronicAddress;
    }


    Message<CoreContactMessage> getContactWithJustOneEmailAndTwitter() {
        Contact crmContact = new Contact();
        crmContact.setEntityId(123);

        ContactEmail email = ContactEmail.newBuilder().setEmail("test@gmail.com").setIsPrimary(true).build();
        com.bfm.aap.pmdx.model.Contact pmdxContact = com.bfm.aap.pmdx.model.Contact.newBuilder().addEmailList(email).setTwitter("@test").build();

        CoreContactMessage coreContactMessage = new CoreContactMessage();
        coreContactMessage.setCrmContact(crmContact);
        coreContactMessage.setPmdxContact(pmdxContact);

        Message<CoreContactMessage> message = MessageBuilder.withPayload(coreContactMessage).build();
        return message;
    }

    Message<CoreContactMessage> getContactWithJustOneEmailAndFacebook() {
        Contact crmContact = new Contact();
        crmContact.setEntityId(123);

        ContactEmail email = ContactEmail.newBuilder().setEmail("test@gmail.com").setIsPrimary(true).build();
        com.bfm.aap.pmdx.model.Contact pmdxContact = com.bfm.aap.pmdx.model.Contact.newBuilder().addEmailList(email).setFacebook("@test").build();

        CoreContactMessage coreContactMessage = new CoreContactMessage();
        coreContactMessage.setCrmContact(crmContact);
        coreContactMessage.setPmdxContact(pmdxContact);

        Message<CoreContactMessage> message = MessageBuilder.withPayload(coreContactMessage).build();
        return message;
    }

    Message<CoreContactMessage> getContactWithJustOneEmailAndLinkedIn() {
        Contact crmContact = new Contact();
        crmContact.setEntityId(123);

        ContactEmail email = ContactEmail.newBuilder().setEmail("test@gmail.com").setIsPrimary(true).build();
        com.bfm.aap.pmdx.model.Contact pmdxContact = com.bfm.aap.pmdx.model.Contact.newBuilder().addEmailList(email).setLinkedin("@test").build();

        CoreContactMessage coreContactMessage = new CoreContactMessage();
        coreContactMessage.setCrmContact(crmContact);
        coreContactMessage.setPmdxContact(pmdxContact);

        Message<CoreContactMessage> message = MessageBuilder.withPayload(coreContactMessage).build();
        return message;
    }

    Message<CoreContactMessage> getContactWithJustOneEmailAndSkype() {
        Contact crmContact = new Contact();
        crmContact.setEntityId(123);

        ContactEmail email = ContactEmail.newBuilder().setEmail("test@gmail.com").setIsPrimary(true).build();
        com.bfm.aap.pmdx.model.Contact pmdxContact = com.bfm.aap.pmdx.model.Contact.newBuilder().addEmailList(email).setSkype("@test").build();

        CoreContactMessage coreContactMessage = new CoreContactMessage();
        coreContactMessage.setCrmContact(crmContact);
        coreContactMessage.setPmdxContact(pmdxContact);

        Message<CoreContactMessage> message = MessageBuilder.withPayload(coreContactMessage).build();
        return message;
    }

    Message<CoreContactMessage> getContactWithJustTwitter() {
        Contact crmContact = new Contact();
        crmContact.setEntityId(123);

        com.bfm.aap.pmdx.model.Contact pmdxContact = com.bfm.aap.pmdx.model.Contact.newBuilder().setTwitter("@test").build();

        CoreContactMessage coreContactMessage = new CoreContactMessage();
        coreContactMessage.setCrmContact(crmContact);
        coreContactMessage.setPmdxContact(pmdxContact);

        Message<CoreContactMessage> message = MessageBuilder.withPayload(coreContactMessage).build();
        return message;
    }

    Message<CoreContactMessage> getContactWithJustOneEmail() {
        Contact crmContact = new Contact();
        crmContact.setEntityId(123);

        ContactEmail email = ContactEmail.newBuilder().setEmail("test@gmail.com").setIsPrimary(true).build();
        com.bfm.aap.pmdx.model.Contact pmdxContact = com.bfm.aap.pmdx.model.Contact.newBuilder().addEmailList(email).build();

        CoreContactMessage coreContactMessage = new CoreContactMessage();
        coreContactMessage.setCrmContact(crmContact);
        coreContactMessage.setPmdxContact(pmdxContact);

        Message<CoreContactMessage> message = MessageBuilder.withPayload(coreContactMessage).build();
        return message;
    }
    private Decode getDecode(String code, String decode) {
        Decode d = new Decode();
        d.setCode(code);
        d.setDecode(decode);
        return d;
    }
}
