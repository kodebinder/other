package com.bfm.aap.privatemarkets.crm.loader.integration.splitter;

import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.Legal;
import com.bfm.aap.pmdx.model.util.SchemaEnum;
import com.bfm.aap.privatemarkets.crm.loader.mapper.AliasTransformer;
import com.bfm.aap.privatemarkets.crm.loader.model.AliasMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreCompanyMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorMessage;
import com.bfm.entitymaster.dto.alias.Alias;
import com.bfm.entitymaster.dto.common.Decode;
import com.bfm.entitymaster.dto.common.Entity;
import com.google.common.collect.Iterables;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class AliasSplitterTest {
    @InjectMocks
    private AliasSplitter aliasSplitter;
    @Mock
    AliasTransformer aliasTransformer;

    @Test
    public void splitAndPublishCompanyAliases_test() {
        when(aliasTransformer.eFrontToCRMTransform("ABC", "knownAs", SchemaEnum.EFRONT_COMPANY_SCHEMA)).thenReturn(getAlias("ABC", "AKA"));
//        when(aliasTransformer.eFrontToCRMTransform("ABC", "shortCode", SchemaEnum.EFRONT_COMPANY_SCHEMA)).thenReturn(getAlias("ABC", "NICKNAME"));
//        when(aliasTransformer.eFrontToCRMTransform("123", "number", SchemaEnum.EFRONT_COMPANY_SCHEMA)).thenReturn(getAlias("123", "TSYALIAS"));
        List<AliasMessage> responses = aliasSplitter.splitAndPublishCompanyAliases(getCompanyObject());

        List<AliasMessage> aliasMessages = Arrays.asList(getAliasMessage(123, getAlias("ABC", "AKA"))
                , getAliasMessage(123, getAlias("ABC", "shortCode"))
                , getAliasMessage(123, getAlias("123", "number")));
        assertTrue(responses.size() == 1);
        Iterables.elementsEqual(aliasMessages, responses);
    }

    @Test
    public void splitAndPublishInvestorAliases_test() {
        List<AliasMessage> responses = aliasSplitter.splitAndPublishInvestorAliases(getInvestorObject());
        assertTrue(responses.size() == 0);
    }

    @Test
    public void splitAndPublishCompanyAliases_test_TwoAttribute() {
        when(aliasTransformer.eFrontToCRMTransform("ABC", "knownAs", SchemaEnum.EFRONT_COMPANY_SCHEMA)).thenReturn(getAlias("ABC", "AKA"));
//        when(aliasTransformer.eFrontToCRMTransform("ABC", "shortCode", SchemaEnum.EFRONT_COMPANY_SCHEMA)).thenReturn(getAlias("ABC", "NICKNAME"));
        List<AliasMessage> responses = aliasSplitter.splitAndPublishCompanyAliases(getCompanyObject_TwoAttributes());

        List<AliasMessage> aliasMessages = Arrays.asList(getAliasMessage(123, getAlias("ABC", "AKA"))
                , getAliasMessage(123, getAlias("ABC", "shortCode")));
        assertTrue(responses.size() == 1);
        Iterables.elementsEqual(aliasMessages, responses);
    }

    private AliasMessage getAliasMessage(int linkedEntityId, Alias a) {
        AliasMessage a1 = new AliasMessage();
        a1.setAlias(a);
        a1.setLinkedCRMEntityId(linkedEntityId);
        return a1;
    }

    private Alias getAlias(String name, String type) {
        Alias alias = new Alias();
        alias.setAliasName(name);
        alias.setAliasType(getDecode(type, type));
        return alias;
    }

    public Message<CoreCompanyMessage> getCompanyObject_TwoAttributes() {
        CoreCompanyMessage msg = new CoreCompanyMessage();
        Entity entity = new Entity();
        entity.setEntityName("ABC Company");
        entity.setEntityType("O");
        entity.setEntityId(123);
        msg.setCompany(Company.newBuilder().setName("ABC Company")
                .setKnownAs("ABC")
                .setShortCode("ABC")
                .setDomicile("US").setStatus("BANK").build());
        msg.setOrgEntity(entity);
        Message<CoreCompanyMessage> message = MessageBuilder.withPayload(msg).build();
        return message;
    }

    public Message<CoreInvestorMessage> getInvestorObject() {
        CoreInvestorMessage msg = new CoreInvestorMessage();
        Entity entity = new Entity();
        entity.setEntityName("ABC Company");
        entity.setEntityType("O");
        entity.setEntityId(123);
        Legal legal = Legal.newBuilder().setLegalDomicileCountry("US").build();
        Investor investor = Investor.newBuilder().setName("ABC Company").setShortCode("ABC").setInvestorType("BANK").setLegal(legal).setCompanyId("ABC").build();
        msg.setOrgEntity(entity);
        msg.setInvestor(investor);
        return MessageBuilder.withPayload(msg).build();
    }

    public Message<CoreCompanyMessage> getCompanyObject() {
        CoreCompanyMessage msg = new CoreCompanyMessage();
        Entity entity = new Entity();
        entity.setEntityName("ABC Company");
        entity.setEntityType("O");
        entity.setEntityId(123);
        msg.setCompany(Company.newBuilder().setName("ABC Company")
                .setKnownAs("ABC")
                .setShortCode("ABC")
                .setNumber("123")
                .setDomicile("US").setStatus("BANK").build());
        msg.setOrgEntity(entity);
        Message<CoreCompanyMessage> message = MessageBuilder.withPayload(msg).build();
        return message;
    }

    private Decode getDecode(String code, String decode) {
        Decode d = new Decode();
        d.setCode(code);
        d.setDecode(decode);
        return d;
    }
}
