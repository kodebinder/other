package com.bfm.aap.privatemarkets.crm.loader.integration.aggregator.impl;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.bfm.aap.privatemarkets.common.crm.model.CRMChannelResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMChannelResponseList;
import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMResponseStatusEnum;
import com.bfm.aap.privatemarkets.common.crm.model.EntityType;

import java.util.Arrays;
import java.util.List;

import static junit.framework.TestCase.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class OrgAggregatorServiceImplTest {
    @InjectMocks
    private OrgAggregatorServiceImpl companyAggregatorService;

    @Test
    public void aggregateAndPublishChannelResponsesTest() {
        CRMChannelResponse a1 = createCRMChannelResponse(321, 222, EntityType.ADDRESS, true);
        CRMChannelResponse e2 = createCRMChannelResponse(321, 555, EntityType.EMAIL, true);
        CRMChannelResponse at1 = createCRMChannelResponse(321, 666, EntityType.ENTITY_ATTRIBUTE, true);
        CRMChannelResponse al = createCRMChannelResponse(321, 666, EntityType.ENTITY_ALIAS, true);
        CRMChannelResponse n = createCRMChannelResponse(321, 666, EntityType.NOTE, true);

        CRMChannelResponseList adrList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{a1})).build();
        CRMChannelResponseList emList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{ e2})).build();
        CRMChannelResponseList atList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{at1})).build();
        CRMChannelResponseList alList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{al})).build();
        CRMChannelResponseList nList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{n})).build();
        List<CRMChannelResponseList> respList = Arrays.asList(new CRMChannelResponseList[]{adrList,emList,atList,alList,nList});
        CRMLoaderResponse response = companyAggregatorService.composeEndpointResponse(respList);
        assertTrue(response.getStatus().equals(CRMResponseStatusEnum.FULL_SUCCESS));
        assertTrue(response.getMessage().equals("All entities processed successfully"));
    }

    @Test
    public void aggregateAndPublishChannelResponsesTest_CorePassed() {
        CRMChannelResponse a1 = createCRMChannelResponse(321, 222, EntityType.ADDRESS, false);
        CRMChannelResponse e2 = createCRMChannelResponse(321, 555, EntityType.EMAIL, true);
        CRMChannelResponse at1 = createCRMChannelResponse(321, 666, EntityType.ENTITY_ATTRIBUTE, true);
        CRMChannelResponse al = createCRMChannelResponse(321, 666, EntityType.ENTITY_ALIAS, true);
        CRMChannelResponse n = createCRMChannelResponse(321, 666, EntityType.NOTE, true);

        CRMChannelResponseList adrList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{a1})).build();
        CRMChannelResponseList emList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{ e2})).build();
        CRMChannelResponseList atList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{at1})).build();
        CRMChannelResponseList alList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{al})).build();
        CRMChannelResponseList nList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{n})).build();
        List<CRMChannelResponseList> respList = Arrays.asList(new CRMChannelResponseList[]{adrList,emList,atList,alList,nList});
        CRMLoaderResponse response = companyAggregatorService.composeEndpointResponse(respList);
        assertTrue(response.getStatus().equals(CRMResponseStatusEnum.CORE_ATTRIBUTE_SUCCESS));
        assertTrue(response.getMessage().equals("Core attribute succeeded in processing"));
    }

    @Test
    public void aggregateAndPublishChannelResponsesTest_Only_One_Passed() {
        CRMChannelResponse a1 = createCRMChannelResponse(321, 222, EntityType.ADDRESS, true);
        CRMChannelResponse a2 = createCRMChannelResponse(321, 2225, EntityType.ADDRESS, true);
        CRMChannelResponse e2 = createCRMChannelResponse(321, 555, EntityType.EMAIL, true);
        CRMChannelResponse at1 = createCRMChannelResponse(321, 666, EntityType.ENTITY_ATTRIBUTE, true);
        CRMChannelResponse al = createCRMChannelResponse(321, 666, EntityType.ENTITY_ALIAS, true);
        CRMChannelResponse n = createCRMChannelResponse(321, 666, EntityType.NOTE, false);

        CRMChannelResponseList adrList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{a1,a2})).build();
        CRMChannelResponseList emList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{ e2})).build();
        CRMChannelResponseList atList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{at1})).build();
        CRMChannelResponseList alList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{al})).build();
        CRMChannelResponseList nList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{n})).build();
        List<CRMChannelResponseList> respList = Arrays.asList(new CRMChannelResponseList[]{adrList,emList,atList,alList,nList});
        CRMLoaderResponse response = companyAggregatorService.composeEndpointResponse(respList);
        assertTrue(response.getStatus().equals(CRMResponseStatusEnum.CORE_ATTRIBUTE_SUCCESS));
        assertTrue(response.getMessage().equals("Core attribute succeeded in processing"));
    }

    private CRMChannelResponse createCRMChannelResponse(int coreEntityId, int entityId, EntityType entityType, boolean status) {
        CRMChannelResponse response = CRMChannelResponse.newBuilder()
                .setCoreEntityId(coreEntityId)
                .setEntityId(entityId)
                .setEntityType(entityType)
                .setStatus(status).build();
        return response;
    }
}
