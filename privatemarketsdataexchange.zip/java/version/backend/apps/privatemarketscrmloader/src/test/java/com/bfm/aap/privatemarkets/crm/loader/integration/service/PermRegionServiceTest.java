package com.bfm.aap.privatemarkets.crm.loader.integration.service;

import com.bfm.aap.privatemarkets.common.crm.model.CRMChannelResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMCoreEntityTypes;
import com.bfm.aap.privatemarkets.common.crm.model.EntityType;
import com.bfm.aap.privatemarkets.permission.restrict.PermissionMappingService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PermRegionServiceTest {
    @InjectMocks
    private PermRegionService permRegionService;
    @Mock
    private PermissionMappingService permissionMappingService;

    @Test
    public void createPermissionGroupFromRegionTest() {
        when(permissionMappingService.createItemRestrictions(123, CRMCoreEntityTypes.valueOf("CONTACT"), "1234", "testUser")).thenReturn(Boolean.TRUE);
        CRMChannelResponse expectedResponse = createExpectedResponse(123, Boolean.TRUE);
        CRMChannelResponse actualResponse = permRegionService.createPermissionGroupFromRegion(123, "CONTACT", "1234", "testUser");
        assertTrue(expectedResponse.getEntityType().equals(actualResponse.getEntityType()));
        assertTrue(expectedResponse.getEntityId() == actualResponse.getEntityId());
        assertTrue(expectedResponse.getStatus() == actualResponse.getStatus());
    }


    @Test
    public void updatePermissionGroupFromRegionTest() {
        when(permissionMappingService.updateItemRestrictions(123, CRMCoreEntityTypes.valueOf("CONTACT"), "1234", "testUser")).thenReturn(Boolean.TRUE);
        CRMChannelResponse expectedResponse = createExpectedResponse(123, Boolean.TRUE);
        CRMChannelResponse actualResponse = permRegionService.updatePermissionGroupFromRegion(123, "CONTACT", "1234", "testUser");
        assertTrue(expectedResponse.getEntityType().equals(actualResponse.getEntityType()));
        assertTrue(expectedResponse.getEntityId() == actualResponse.getEntityId());
    }

    @Test
    public void getRegionByEntityIdAndTypeTest(){
        when(permissionMappingService.retrieveInvestRegionByEntityId(anyInt(),any(CRMCoreEntityTypes.class))).thenReturn("1234");
        String region = permRegionService.getRegionByEntityIdAndType(123,CRMCoreEntityTypes.CONTACT);
        assertTrue(region.equals("1234"));
    }

    private CRMChannelResponse createExpectedResponse(int entityId, Boolean response) {
        return CRMChannelResponse.newBuilder()
                .setCoreEntityId(-1)
                .setEntityId(entityId)
                .setStatus(response)
                .setEntityTypeValue(EntityType.SPG_PERMISSION_VALUE)
                .build();
    }
}
