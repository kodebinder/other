package com.bfm.aap.privatemarkets.crm.loader.integration.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMResponseStatusEnum;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreUserMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.UserCRM;
import com.bfm.user.client.impl.RPCAwareUserServiceClient;
import com.blackrock.agraph.platform.identity.user.v1.User;
import com.blackrock.agraph.platform.identity.user.v1.User.UserProfile;

import io.grpc.StatusRuntimeException;

@RunWith(MockitoJUnitRunner.class)
public class UserCRMCoreAGUServiceTest {

    @InjectMocks
    private UserCRMCoreAGUService userCRMCoreAGUService;
    @Mock
    private RPCAwareUserServiceClient rpcAwareUserServiceClient;

    @Test
    public void mapUserByEmail_Test() {
    	String userId = "hthakkar";
		String email = "himanshu.thakkar@blackrock.com";
		User user = User.newBuilder()
				.setProfile(UserProfile.newBuilder().setEmail(email))
				.setId(userId)
				.build();
        when(rpcAwareUserServiceClient.searchUser(anyString())).thenReturn(user);
        Message<CoreUserMessage> msg = userCRMCoreAGUService.mapUserByEmail(getUserMsgForSearchByEmail());
        assertEquals(email, msg.getPayload().getAladdinUser().getProfile().getEmail());
    }
    
    @Test
    public void createUserMappingWithIQID_processMapping_Test() {
    	User user = getAladdinUserWitheFrontInvestIQID();
        when(rpcAwareUserServiceClient.updateUser(any(), any())).thenReturn(user);
        CRMLoaderResponse response = userCRMCoreAGUService.createUserMappingWithIQID(
        		getUserMsgForMappingWithouteFrontInvestIQID());
        assertEquals(CRMResponseStatusEnum.FULL_SUCCESS, response.getStatus());
    }
    
    @Test
    public void createUserMappingWithIQID_processMapping_failed_Test() {
    	User user = getAladdinUserWithouteFrontInvestIQID();
        when(rpcAwareUserServiceClient.updateUser(any(), any())).thenReturn(user);
        CRMLoaderResponse response = userCRMCoreAGUService.createUserMappingWithIQID(
        		getUserMsgForMappingWithouteFrontInvestIQID());
        assertEquals(CRMResponseStatusEnum.CORE_ATTRIBUTE_FAIL, response.getStatus());
    }
    
    @Test
    public void createUserMappingWithIQID_processMapping_exception_Test() {
    	Mockito.doThrow(StatusRuntimeException.class).when(rpcAwareUserServiceClient).updateUser(any(),any());
        CRMLoaderResponse response = userCRMCoreAGUService.createUserMappingWithIQID(
        		getUserMsgForMappingWithouteFrontInvestIQID());
        assertEquals(CRMResponseStatusEnum.CORE_ATTRIBUTE_FAIL, response.getStatus());
    }

	private User getAladdinUserWithouteFrontInvestIQID() {
		String userId = "hthakkar";
		String email = "himanshu.thakkar@blackrock.com";
		User user = User.newBuilder()
				.setProfile(UserProfile.newBuilder().setEmail(email))
				.setId(userId)
				.build();
		return user;
	}
    
    @Test
    public void createUserMappingWithIQID_alreadyMapped_Test() {
    	User user = getAladdinUserWitheFrontInvestIQID();
        when(rpcAwareUserServiceClient.updateUser(any(), any())).thenReturn(user);
        CRMLoaderResponse response = userCRMCoreAGUService.createUserMappingWithIQID(
        		getUserMsgForMappingWitheFrontInvestIQID());
        assertEquals("Aladdin User mapping already available for eFrontInvestIQID 68C6CB6667474A46AFE8252EB760611T and email himanshu.thakkar@blackrock.com", 
        		response.getMessage());
    }

	private User getAladdinUserWitheFrontInvestIQID() {
		String userId = "hthakkar";
		String email = "himanshu.thakkar@blackrock.com";
		User user = User.newBuilder()
				.setProfile(UserProfile.newBuilder().setEmail(email))
				.setId(userId)
				.putAlternativeUserIds("eFrontInvestIQID", "68C6CB6667474A46AFE8252EB760611T")
				.build();
		return user;
	}
    
    private Message<CoreUserMessage> getUserMsgForSearchByEmail() {
    	CoreUserMessage msg = new CoreUserMessage();
    	UserCRM userCRM = getUserCRMObject();
        msg.setUserCRM(userCRM);
        return MessageBuilder.withPayload(msg).setHeader("user", "userLogin").build();
    }

	private UserCRM getUserCRMObject() {
		UserCRM userCRM = new UserCRM();
        userCRM.seteFrontId("68C6CB6667474A46AFE8252EB760611T");
        userCRM.setUserEmail("himanshu.thakkar@blackrock.com");
        userCRM.seteFrontUserId("HTHAKKAR");
		return userCRM;
	}
    
    private Message<CoreUserMessage> getUserMsgForMappingWithouteFrontInvestIQID() {
    	CoreUserMessage msg = new CoreUserMessage();
    	UserCRM userCRM = getUserCRMObject();
        msg.setUserCRM(userCRM);
        User user = getAladdinUserWithouteFrontInvestIQID();
		msg.setAladdinUser(user);
        return MessageBuilder.withPayload(msg).setHeader("user", "userLogin").build();
    }
    
    private Message<CoreUserMessage> getUserMsgForMappingWitheFrontInvestIQID() {
    	CoreUserMessage msg = new CoreUserMessage();
    	UserCRM userCRM = getUserCRMObject();
        msg.setUserCRM(userCRM);
        User user = getAladdinUserWitheFrontInvestIQID();
		msg.setAladdinUser(user);
        return MessageBuilder.withPayload(msg).setHeader("user", "userLogin").build();
    }

}
