package com.bfm.aap.privatemarkets.crm.loader.integration.service.impl;

import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.util.DecodeHelper;
import com.bfm.aap.privatemarkets.common.crm.model.CRMCoreEntityTypes;
import com.bfm.aap.privatemarkets.common.crm.util.EntityMasterDecodeTableConstants;
import com.bfm.aap.privatemarkets.crm.loader.integration.service.PermRegionService;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.entitymaster.dto.common.Decode;
import com.bfm.entitymaster.dto.common.Entity;
import com.bfm.entitymaster.dto.organization.OrganizationDetail;
import com.bfm.entitymaster.dto.organization.OrganizationType;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import static com.bfm.aap.privatemarkets.crm.loader.util.DecodeHelper.getDecode;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({DecodeHelper.class})
public class CoreInvestorInverseTransformerServiceImplTest {

    public static final String UNAVAILABLE = "Unavailable";

    @InjectMocks
    private CoreInvestorInverseTransformerServiceImpl coreInvestorInverseTransformerService;

    @Mock
    private CoreInvestorInverseMessage coreInvestorInverseMessage;
    @Mock
    private OrganizationDetail organizationDetail;
    @Mock
    private Entity entity;
    @Mock
    private OrganizationType organizationType;
    @Mock
    private CRMThirdPartyMapperService crmThirdPartyMapperService;
    @Mock
    private PermRegionService permRegionService;

    @BeforeClass
    public static void setUpBeforeClass() {
        System.setProperty("mode", "blue");
    }

    @Before
    public void initMocks() {
        PowerMockito.mockStatic(DecodeHelper.class);
        PowerMockito.when(getDecode(EntityMasterDecodeTableConstants.EM_INV_INVESTOR_TYPE, "BAA"))
            .thenReturn(new Decode("BAA", "BANK", 787));
        PowerMockito.when(permRegionService.getRegionByEntityIdAndType(anyInt(),any(CRMCoreEntityTypes.class))).thenReturn("1234");
    }

    @Test
    public void testTransform() {
        Mockito.when(coreInvestorInverseMessage.getOrganization()).thenReturn(organizationDetail);
        Mockito.when(organizationDetail.getOrganization()).thenReturn(entity);
        Mockito.when(entity.getEntityName()).thenReturn("investorTest");
        Mockito.when(organizationDetail.getOrganizationType()).thenReturn(organizationType);
        Mockito.when(organizationType.getOrganizationType()).thenReturn(new Decode("BAA", "Blk Alts", 786));
        when(crmThirdPartyMapperService.getLoginByEntityId(anyInt())).thenReturn("tsgops");
        CoreInvestorInverseMessage coreInvestorInverseMessage = new CoreInvestorInverseMessage();
        coreInvestorInverseMessage.setOrganization(organizationDetail);
        coreInvestorInverseMessage.setModifiedByCRMUserEntityId(12345);
        CoreInvestorInverseMessage message = coreInvestorInverseTransformerService.transform(coreInvestorInverseMessage);
        assertEquals("BANK", message.getEfrontEntity().getInvestorType());
        assertEquals("investorTest", message.getEfrontEntity().getName());
    }

    @Test
    public void testTransform_Empty() {
        Mockito.when(coreInvestorInverseMessage.getOrganization()).thenReturn(organizationDetail);
        Mockito.when(organizationDetail.getOrganization()).thenReturn(null);
        Mockito.when(organizationDetail.getOrganizationType()).thenReturn(organizationType);
        Mockito.when(organizationType.getOrganizationType()).thenReturn(null);
        Mockito.when(organizationType.getOrganizationType()).thenReturn(new Decode("BAA", "Blk Alts", 787));
        when(crmThirdPartyMapperService.getLoginByEntityId(anyInt())).thenReturn("tsgops");
        CoreInvestorInverseMessage coreInvestorInverseMessage = new CoreInvestorInverseMessage();
        coreInvestorInverseMessage.setOrganization(organizationDetail);
        coreInvestorInverseMessage.setModifiedByCRMUserEntityId(12345);
        CoreInvestorInverseMessage message = coreInvestorInverseTransformerService.transform(coreInvestorInverseMessage);
        assertEquals("BANK", message.getEfrontEntity().getInvestorType());
        assertEquals(UNAVAILABLE, message.getEfrontEntity().getName());

    }
}
