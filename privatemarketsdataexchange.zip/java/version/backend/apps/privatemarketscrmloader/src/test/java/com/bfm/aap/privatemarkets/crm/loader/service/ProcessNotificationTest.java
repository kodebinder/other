package com.bfm.aap.privatemarkets.crm.loader.service;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;

import com.google.common.util.concurrent.MoreExecutors;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.kafka.streams.processor.ProcessorContext;
import org.apache.kafka.streams.state.KeyValueStore;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import com.bfm.aap.pmdx.hub.service.PrivateMarketsDXHubForgetService;
import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.util.CircuitBreakerHelper;
import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.aap.pmdx.model.util.LibRedBlueProxy;
import com.bfm.aap.pmdx.model.util.NetworkMode;
import com.bfm.aap.pmdx.services.CompanyRequest;
import com.bfm.aap.pmdx.services.ContactRequest;
import com.bfm.aap.pmdx.services.InvestorRequest;
import com.bfm.aap.privatemarkets.crm.loader.dao.ADLRepositoryDAO;
import com.bfm.aap.privatemarkets.crm.loader.model.DataBundle;
import com.bfm.aap.privatemarkets.crm.loader.model.EntityBundle;
import com.bfm.aap.privatemarkets.crm.loader.model.EntityBundleMetadata;
import com.bfm.aap.privatemarkets.crm.loader.model.WindowedKey;
import com.bfm.aap.privatemarkets.crm.loader.util.CRMLoaderConstants;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperServiceImpl;
import com.bfm.adl.ADLResultSet;
import com.bfm.entitymaster.dto.entitythirdparty.ThirdPartyMapping;
import com.bfm.entitymaster.dto.entitythirdparty.ThirdPartySource;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({LibRedBlueProxy.class})
public class ProcessNotificationTest {

	private ProcessNotification processNotification;

	@Mock
	private ProcessContactNotification processContactNotification;
	@Mock
	private ProcessCompanyNotification processCompanyNotification;
	@Mock
	private ProcessInvestorNotification processInvestorNotification;
	@Mock
	private CRMThirdPartyMapperServiceImpl crmThirdPartyMapperService;
	@Mock
	private ADLRepositoryDAO adlRepositoryDAO;
	@Mock
	private CircuitBreakerHelper circuitBreakerHelper;
	@Mock
	private PrivateMarketsDXHubForgetService privateMarketsDXHubForgetServiceClient;

	@Mock
	private KeyValueStore<WindowedKey, EntityBundle> bundleStore;
	@Mock
	private ProcessorContext processorContext;
	@Mock
	private WindowedKey windowedKey;
	@Mock
	private ThirdPartyMapping thirdPartyMapping;
	@Mock
	private ThirdPartySource thirdPartySource;

	@Before
	public void setUp() {
		System.setProperty("mode", "blue");
		PowerMockito.mockStatic(LibRedBlueProxy.class);

		processNotification = new ProcessNotification(adlRepositoryDAO, processContactNotification, processInvestorNotification, processCompanyNotification,
			circuitBreakerHelper, privateMarketsDXHubForgetServiceClient, crmThirdPartyMapperService, null, null);
		Whitebox.setInternalState(processNotification, "streamProcessorExecutor", MoreExecutors.newDirectExecutorService());

		when(processorContext.getStateStore(CRMLoaderConstants.PMDX_STORE)).thenReturn(bundleStore);
		when(windowedKey.getChangedBy()).thenReturn(RandomStringUtils.randomAlphabetic(5));
		processNotification.init(processorContext);
	}

	@Test
	public void healthCheckStreamProcessorExecutorTest() {
		ThreadPoolExecutor streamProcessorExecutor = mock(ThreadPoolExecutor.class);
		when(streamProcessorExecutor.getQueue()).thenReturn(mock(BlockingQueue.class));
		Whitebox.setInternalState(processNotification, "streamProcessorExecutor", streamProcessorExecutor);
		processNotification.healthCheckStreamProcessorExecutor();
		verify(streamProcessorExecutor).getMaximumPoolSize();
	}

	@Test
	public void testProcess() throws Exception {
		when(LibRedBlueProxy.isCurrentInstancePrimary(any(NetworkMode.class))).thenReturn(true);

		processNotification.close();

		EntityBundle entityBundle = new EntityBundle();
		processNotification.process(windowedKey, entityBundle);

		entityBundle = new EntityBundle(null, new DataBundle());
		processNotification.process(windowedKey, entityBundle);

		verify(crmThirdPartyMapperService, never()).lookupThirdPartMapping(anyInt(), any(ThirdPartyMappingEnum.class));
	}

	@Test
	public void testProcess_on_secondary_instance() throws Exception {
		when(LibRedBlueProxy.isCurrentInstancePrimary(any(NetworkMode.class))).thenReturn(false);

		processNotification.close();

		DataBundle dataBundle = new DataBundle();
		dataBundle.setEntityId(123);
		EntityBundle entityBundle = new EntityBundle(null, dataBundle);
		processNotification.process(windowedKey, entityBundle);

		entityBundle = new EntityBundle(null, new DataBundle());
		processNotification.process(windowedKey, entityBundle);

		verify(crmThirdPartyMapperService, never()).lookupThirdPartMapping(anyInt(), any(ThirdPartyMappingEnum.class));
	}

	@Test
	public void testProcessContact_isDuplicate() throws Exception {
		when(LibRedBlueProxy.isCurrentInstancePrimary(any(NetworkMode.class))).thenReturn(true);

		EntityBundle entityBundle = createEntityBundle('P');
		Whitebox.setInternalState(processNotification, "isProcessContactNotification", true);

		when(crmThirdPartyMapperService.lookupThirdPartMapping(anyInt(), any(ThirdPartyMappingEnum.class))).thenReturn(createThirdPartyMapping());
		when(processContactNotification.process(anyInt(), anyString())).thenReturn(Contact.newBuilder().setContactId("DC12BGF56KJ78Gt5G68KKL5").build());
		when(circuitBreakerHelper.checkCircuitBreaker(any(Contact.class), any(ADLResultSet.class), any(EntityType.class))).thenReturn(false);
		when(thirdPartyMapping.getThirdPartySource()).thenReturn(thirdPartySource);
		when(thirdPartySource.getThirdPartySourceId()).thenReturn(4321);

		processNotification.process(windowedKey, entityBundle);
		verify(privateMarketsDXHubForgetServiceClient).updateContact(any(ContactRequest.class), anyInt());
	}

	@Test
	public void testProcess_Error() throws Exception {
		EntityBundle entityBundle = createEntityBundle('P');
		Whitebox.setInternalState(processNotification, "isProcessContactNotification", true);

		when(processContactNotification.process(anyInt(), anyString())).thenThrow(new Exception());

		processNotification.process(windowedKey, entityBundle);
		verify(adlRepositoryDAO, never()).fetchADLRecordInWindow(anyString(), anyString(), any(EntityType.class));
	}

	@Test
	public void testProcessCompany() throws Exception {
		when(LibRedBlueProxy.isCurrentInstancePrimary(any(NetworkMode.class))).thenReturn(true);

		EntityBundle entityBundle = createEntityBundle('O');
		Whitebox.setInternalState(processNotification, "isProcessCompanyNotification", true);
		Whitebox.setInternalState(processNotification, "isProcessInvestorNotification", true);

		when(crmThirdPartyMapperService.lookupThirdPartMapping(anyInt(), any(ThirdPartyMappingEnum.class))).thenReturn(createThirdPartyMapping());
		when(processCompanyNotification.process(anyInt(), anyString())).thenReturn(Company.getDefaultInstance());
		when(processInvestorNotification.process(anyInt(), anyString())).thenReturn(Investor.getDefaultInstance());
		when(circuitBreakerHelper.checkCircuitBreaker(any(Contact.class), any(ADLResultSet.class), any(EntityType.class))).thenReturn(true);
		when(thirdPartyMapping.getThirdPartySource()).thenReturn(thirdPartySource);
		when(thirdPartySource.getThirdPartySourceId()).thenReturn(4321);

		processNotification.process(windowedKey, entityBundle);
		verify(privateMarketsDXHubForgetServiceClient).updateCompany(any(CompanyRequest.class), anyInt());
		verify(privateMarketsDXHubForgetServiceClient).updateInvestor(any(InvestorRequest.class), anyInt());
	}

	private EntityBundle createEntityBundle(Character entityType) {
		DataBundle dataBundle = new DataBundle();
		dataBundle.setEntityId(11234);
		dataBundle.setEntityType(entityType);
		return new EntityBundle(new EntityBundleMetadata(1L), dataBundle);
	}


	private ThirdPartyMapping createThirdPartyMapping() {
		ThirdPartyMapping mapping = new ThirdPartyMapping();
		mapping.setThirdPartyIdentifier("DC12BGF56KJ78Gt5G68KKL5");
		return mapping;
	}

}