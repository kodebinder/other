/**
 * 
 */
package com.bfm.aap.privatemarkets.crm.loader.integration.router;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import com.bfm.aap.pmdx.model.User;

/**
 * @author hthakkar 	
 *
 */
@RunWith(PowerMockRunner.class)
class UserCRMCoreServiceRouterTest {
	
	@InjectMocks
	private UserCRMCoreServiceRouter userCRMCoreServiceRouter;
	
	/**
	 * Need this method for initializing UserCRMCoreServiceRouter which is MessageEndpoint
	 */
	@BeforeEach
	public void init() {
		System.setProperty("defaultWebServer", "https://dev.blackrock.com");
		userCRMCoreServiceRouter = new UserCRMCoreServiceRouter();
	}

	@Test
	void testRoute_BLK_processFromEMS() {
		Whitebox.setInternalState(userCRMCoreServiceRouter, "processUserMappingFromEMS", true);
		Whitebox.setInternalState(userCRMCoreServiceRouter, "processUserMappingFromAGU", false);
		List<String> channels = userCRMCoreServiceRouter.route(getUserObject());
		assertTrue(channels.get(0).equals("userProcessInitEMSChannel"));
	}
	
	@Test
	void testRoute_BLK_processFromAGU() {
		Whitebox.setInternalState(userCRMCoreServiceRouter, "processUserMappingFromEMS", false);
		Whitebox.setInternalState(userCRMCoreServiceRouter, "processUserMappingFromAGU", true);
		List<String> channels = userCRMCoreServiceRouter.route(getUserObject());
		assertTrue(channels.get(0).equals("userProcessInitAGUChannel"));
	}
	
	@Test
	void testRoute_BLK_processFromAGUandEMS() {
		Whitebox.setInternalState(userCRMCoreServiceRouter, "processUserMappingFromEMS", true);
		Whitebox.setInternalState(userCRMCoreServiceRouter, "processUserMappingFromAGU", true);
		List<String> channels = userCRMCoreServiceRouter.route(getUserObject());
		assertTrue(channels.get(0).equals("userProcessInitAGUChannel"));
		assertTrue(channels.get(1).equals("userProcessInitEMSChannel"));
	}
	
	@Test
	void testRoute_BLK_processFromDefaultAGU() {
		Whitebox.setInternalState(userCRMCoreServiceRouter, "processUserMappingFromEMS", false);
		Whitebox.setInternalState(userCRMCoreServiceRouter, "processUserMappingFromAGU", false);
		List<String> channels = userCRMCoreServiceRouter.route(getUserObject());
		assertTrue(channels.get(0).equals("userProcessInitAGUChannel"));
	}
	
	private User getUserObject() {
		String userId = "68C6CB6667474A46AFE8252EB760611T";
		return User.newBuilder().setUserId(userId).build();
	}

}
