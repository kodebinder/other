package com.bfm.aap.privatemarkets.crm.loader.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.powermock.reflect.Whitebox;

import com.bfm.aap.pmdx.model.InvestorAccount;
import com.bfm.aap.pmdx.model.InvestorAccountResponse;
import com.bfm.aap.pmdx.proto.util.ProtoJsonHelper;
import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMResponseStatusEnum;
import com.bfm.aap.privatemarkets.crm.loader.integration.gateway.InvestorAccountInverseProcessingGateway;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorAccountInverseMessage;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith({MockitoExtension.class})
public class ProcessInvestorAccountNotificationTest {

    @Spy
    @InjectMocks
    private ProcessInvestorAccountNotification processInvestorAccountNotification;

    @Mock
    private InvestorAccountInverseProcessingGateway investorAccountInverseProcessingGateway;

    @Mock
    private CRMThirdPartyMapperService crmThirdPartyMapperService;

    @BeforeEach
    void setUp() {
        Whitebox.setInternalState(processInvestorAccountNotification, "investorAccountInverseProcessingGateway", investorAccountInverseProcessingGateway);
    }

    @Test
    void testProcess() throws Exception {
        String user = RandomStringUtils.randomAlphabetic(5);
        CRMLoaderResponse loaderResponse = CRMLoaderResponse.newBuilder()
            .setStatus(CRMResponseStatusEnum.FULL_SUCCESS)
            .setMessage(ProtoJsonHelper.convertToJson(InvestorAccount.getDefaultInstance()))
            .build();

        when(investorAccountInverseProcessingGateway.mapEfrontInvestorAccount(any(CoreInvestorAccountInverseMessage.class))).thenReturn(loaderResponse);

        processInvestorAccountNotification.process(1234, user);

        verify(investorAccountInverseProcessingGateway).mapEfrontInvestorAccount(any(CoreInvestorAccountInverseMessage.class));
    }

    @Test
    void testProcess_failure() {
        String user = RandomStringUtils.randomAlphabetic(5);
        Exception error = new Exception("Error processing");
        CRMLoaderResponse loaderResponse = CRMLoaderResponse.newBuilder()
            .setStatus(CRMResponseStatusEnum.ERROR)
            .setMessage(error.getMessage())
            .build();

        when(investorAccountInverseProcessingGateway.mapEfrontInvestorAccount(any(CoreInvestorAccountInverseMessage.class))).thenReturn(loaderResponse);

        try {
            processInvestorAccountNotification.process(1234, user);
        } catch (Exception ex) {
            assertEquals(ex.getMessage(), error.getMessage());
        }
        verify(investorAccountInverseProcessingGateway).mapEfrontInvestorAccount(any(CoreInvestorAccountInverseMessage.class));
    }

    @Test
    public void testGetInvestorAccountResponseFutures() throws Exception {
        List<String> eFrontId = Arrays.asList("ABC12","345GD56");

        Whitebox.setInternalState(processInvestorAccountNotification, "processNotificationExecutorService", Executors.newFixedThreadPool(5 ));

        assertNotNull(processInvestorAccountNotification.getInvestorAccountResponseFutures(eFrontId));

    }

    @Test
    public void testGetInvestorAccountResponseFutures_without_crmmapping() throws Exception {
        List<String> eFrontId = Arrays.asList("ABC12","345GD56");

        Whitebox.setInternalState(processInvestorAccountNotification, "processNotificationExecutorService", Executors.newFixedThreadPool(5 ));

        assertNotNull(processInvestorAccountNotification.getInvestorAccountResponseFutures(eFrontId));
    }

    @Test
    public void testGetInvestorAccountResponseFutures_throws_exception() throws Exception {
        List<String> eFrontId = Arrays.asList("ABC12","345GD56");

        Whitebox.setInternalState(processInvestorAccountNotification, "processNotificationExecutorService", Executors.newFixedThreadPool(5 ));

        assertNotNull(processInvestorAccountNotification.getInvestorAccountResponseFutures(eFrontId));
    }

    @Test
    public void testGetInvestorAccountResponsesFromFutures(){
        Future<InvestorAccountResponse.Builder> investorAccountResponseBuilderFuture = CompletableFuture.completedFuture(InvestorAccountResponse.newBuilder());
        List<Future<InvestorAccountResponse.Builder>> investorAccountResponseBuilderFutures = new ArrayList<>();
        investorAccountResponseBuilderFutures.add(investorAccountResponseBuilderFuture);

        assertNotNull(processInvestorAccountNotification.getInvestorAccountResponsesFromFutures(investorAccountResponseBuilderFutures));
    }

    @Test
    public void testGetInvestorAccountResponsesFromFutures_throw_exception(){
        Future<InvestorAccountResponse.Builder> investorAcctResponseBuilderFuture = CompletableFuture.completedFuture(InvestorAccountResponse.newBuilder());
        List<Future<InvestorAccountResponse.Builder>> investorAccountResponseBuilderFutures = new ArrayList<>();
        investorAccountResponseBuilderFutures.add(investorAcctResponseBuilderFuture);

        assertNotNull(processInvestorAccountNotification.getInvestorAccountResponsesFromFutures(investorAccountResponseBuilderFutures));
    }
}
