package com.bfm.aap.privatemarkets.crm.loader.integration.handler;

import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMResponseStatusEnum;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.messaging.MessageHandlingException;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class GlobalErrorHandlerTest {

    @InjectMocks
    private GlobalErrorHandler globalErrorHandler;

    @Mock
    private MessageHandlingException messageHandlingException;

    @Test
    void handleErrorTest() {
        when(messageHandlingException.getMessage()).thenReturn("ERROR_MESSAGE_TEST");
        CRMLoaderResponse crmLoaderResponse = globalErrorHandler.handleError(messageHandlingException);
        assertTrue(CRMResponseStatusEnum.ERROR == crmLoaderResponse.getStatus());
    }
    
}