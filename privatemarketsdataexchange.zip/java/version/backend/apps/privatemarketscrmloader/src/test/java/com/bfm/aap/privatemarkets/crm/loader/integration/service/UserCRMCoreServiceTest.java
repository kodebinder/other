package com.bfm.aap.privatemarkets.crm.loader.integration.service;

import com.bfm.aap.privatemarkets.crm.loader.model.UserCRM;
import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMResponseStatusEnum;
import com.bfm.aap.privatemarkets.crm.loader.service.CRMLoaderCoreService;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.entitymaster.dto.contact.ContactSearchDetail;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class UserCRMCoreServiceTest {

    @InjectMocks
    private UserCRMCoreService userCRMCoreServiceTest;
    @Mock
    private CRMLoaderCoreService crmUserLoaderService;
    @Mock
    private CRMThirdPartyMapperService crmThirdPartyMapperService;

    @Test
    public void searchContactByEmail_Test() {
        ContactSearchDetail c = new ContactSearchDetail();
        c.setEntityId(123);
        List<ContactSearchDetail> searchDetails = new ArrayList<>();
        searchDetails.add(c);
        when(crmUserLoaderService.searchCRMUserEntity(anyString())).thenReturn(searchDetails);
        UserCRM u = new UserCRM();
        u.setUserEmail("test@blackrock.com");
        UserCRM userResponse = userCRMCoreServiceTest.searchContactByEmail(u);
        assertTrue(userResponse.getRetreivedCRMEntityId() == 123);
    }

    @Test
    public void searchContactByEmail_Test_Prod() {
        System.setProperty("env.name", "PROD");
        ContactSearchDetail c = new ContactSearchDetail();
        c.setEntityId(123);
        List<ContactSearchDetail> searchDetails = new ArrayList<>();
        searchDetails.add(c);
        when(crmUserLoaderService.searchCRMUserEntity(anyString())).thenReturn(searchDetails);
        UserCRM u = new UserCRM();
        u.setUserEmail("test@blackrock.com");
        UserCRM userResponse = userCRMCoreServiceTest.searchContactByEmail(u);
        assertTrue(userResponse.getRetreivedCRMEntityId() == 123);
        System.clearProperty("env.name");
    }

    @Test
    public void createThirdPartyMapping_Test() {
        when(crmThirdPartyMapperService.create(anyString(), anyInt(), any(ThirdPartyMappingEnum.class))).thenReturn("123");
        when(crmThirdPartyMapperService.lookUp(anyString(), any(ThirdPartyMappingEnum.class))).thenReturn(456);
        UserCRM u = new UserCRM();
        u.setUserEmail("test@gmail.com");
        u.seteFrontId("1234");
        CRMLoaderResponse crmLoaderResponse = userCRMCoreServiceTest.createThirdPartyMapping(u);
        assertTrue(crmLoaderResponse.getStatus() == CRMResponseStatusEnum.FULL_SUCCESS);
    }

    @Test
    public void createThirdPartyMapping_Test_No_Response() {
        when(crmThirdPartyMapperService.create(anyString(), anyInt(), any(ThirdPartyMappingEnum.class))).thenReturn(null);
        UserCRM u = new UserCRM();
        u.setUserEmail("test@gmail.com");
        u.seteFrontId("1234");
        CRMLoaderResponse crmLoaderResponse = userCRMCoreServiceTest.createThirdPartyMapping(u);
        assertTrue(crmLoaderResponse.getStatus() == CRMResponseStatusEnum.CORE_ATTRIBUTE_FAIL);
    }

    @Test
    public void findCrmEntityId_Test() {
        when(crmThirdPartyMapperService.lookUp(anyString(), any(ThirdPartyMappingEnum.class))).thenReturn(123);
        UserCRM u = new UserCRM();
        u.setUserEmail("test@gmail.com");
        u.seteFrontUserId("eFrontUser");
        u.seteFrontId("321");
        UserCRM response = userCRMCoreServiceTest.findCrmEntityId(u);
        assertTrue(response.getCrmEntityId() == 123);
    }

    @Test
    public void discardingUser_Test() {
        UserCRM u = new UserCRM();
        u.setCrmEntityId(12345);
        CRMLoaderResponse crmLoaderResponse = userCRMCoreServiceTest.discardingUser(u);
        assertTrue(crmLoaderResponse.getStatus() == CRMResponseStatusEnum.SKIPPED);
        assertEquals("User already mapped with entity 12345", crmLoaderResponse.getMessage());
    }

}
