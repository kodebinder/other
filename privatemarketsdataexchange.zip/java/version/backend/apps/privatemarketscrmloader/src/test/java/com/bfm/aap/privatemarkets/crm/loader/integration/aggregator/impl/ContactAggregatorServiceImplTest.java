package com.bfm.aap.privatemarkets.crm.loader.integration.aggregator.impl;

import com.bfm.aap.privatemarkets.common.crm.model.CRMChannelResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMChannelResponseList;
import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMResponseStatusEnum;
import com.bfm.aap.privatemarkets.common.crm.model.EntityType;
import com.google.common.collect.Iterables;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.List;

import static junit.framework.TestCase.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class ContactAggregatorServiceImplTest {

    @InjectMocks
    private ContactAggregatorServiceImpl contactAggregatorService;

    @Test
    public void aggregateAndPublishTest() {
        CRMChannelResponse a1 = createCRMChannelResponse(321, 222, EntityType.ADDRESS, true);
        CRMChannelResponse a2 = createCRMChannelResponse(321, 333, EntityType.ADDRESS, true);
        CRMChannelResponse a3 = createCRMChannelResponse(321, 444, EntityType.ADDRESS, false);
        List<CRMChannelResponse> respList = Arrays.asList(new CRMChannelResponse[]{a1, a2, a3});
        CRMChannelResponseList list = contactAggregatorService.aggregateAndPublish(respList);
        assertTrue(Iterables.elementsEqual(list.getResponseList(), respList));
    }


    @Test
    public void aggregateAndPublishSingleResponseTest() {
        CRMChannelResponse a1 = createCRMChannelResponse(321, 222, EntityType.ADDRESS, true);
        List<CRMChannelResponse> respList = Arrays.asList(new CRMChannelResponse[]{a1});
        CRMChannelResponseList list = contactAggregatorService.aggregateAndPublish(respList);
        assertTrue(Iterables.elementsEqual(list.getResponseList(), respList));
    }

    @Test
    public void aggregateAndPublishChannelResponsesTest() {
        CRMChannelResponse a1 = createCRMChannelResponse(321, 222, EntityType.ADDRESS, true);
        CRMChannelResponse a2 = createCRMChannelResponse(321, 333, EntityType.ADDRESS, true);
        CRMChannelResponse e1 = createCRMChannelResponse(321, 444, EntityType.EMAIL, true);
        CRMChannelResponse e2 = createCRMChannelResponse(321, 555, EntityType.EMAIL, true);
        CRMChannelResponse at1 = createCRMChannelResponse(321, 666, EntityType.ENTITY_ATTRIBUTE, true);
        CRMChannelResponse at2 = createCRMChannelResponse(321, 777, EntityType.ENTITY_ATTRIBUTE, true);
        CRMChannelResponseList adrList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{a1, a2})).build();
        CRMChannelResponseList emList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{e1, e2})).build();
        CRMChannelResponseList atList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{at1, at2})).build();
        List<CRMChannelResponseList> respList = Arrays.asList(new CRMChannelResponseList[]{adrList,emList,atList});
        CRMLoaderResponse response = contactAggregatorService.composeEndpointResponse(respList);
        assertTrue(response.getStatus().equals(CRMResponseStatusEnum.FULL_SUCCESS));
        assertTrue(response.getMessage().equals("All entities processed successfully"));
    }

    @Test
    public void aggregateAndPublishChannelResponsesTest_CorePassed() {
        CRMChannelResponse a1 = createCRMChannelResponse(321, 222, EntityType.ADDRESS, true);
        CRMChannelResponse a2 = createCRMChannelResponse(321, 333, EntityType.ADDRESS, false);
        CRMChannelResponse e1 = createCRMChannelResponse(321, 444, EntityType.EMAIL, true);
        CRMChannelResponse e2 = createCRMChannelResponse(321, 555, EntityType.EMAIL, true);
        CRMChannelResponse at1 = createCRMChannelResponse(321, 666, EntityType.ENTITY_ATTRIBUTE, false);
        CRMChannelResponse at2 = createCRMChannelResponse(321, 777, EntityType.ENTITY_ATTRIBUTE, true);
        CRMChannelResponseList adrList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{a1, a2})).build();
        CRMChannelResponseList emList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{e1, e2})).build();
        CRMChannelResponseList atList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{at1, at2})).build();
        List<CRMChannelResponseList> respList = Arrays.asList(new CRMChannelResponseList[]{adrList,emList,atList});
        CRMLoaderResponse response = contactAggregatorService.composeEndpointResponse(respList);
        assertTrue(response.getStatus().equals(CRMResponseStatusEnum.CORE_ATTRIBUTE_SUCCESS));
        assertTrue(response.getMessage().equals("Core attribute succeeded in processing"));
    }

    @Test
    public void aggregateAndPublishChannelResponsesTest_CorePassed_Combination() {
        CRMChannelResponse a1 = createCRMChannelResponse(321, 222, EntityType.ADDRESS, false);
        CRMChannelResponse a2 = createCRMChannelResponse(321, 333, EntityType.ADDRESS, false);
        CRMChannelResponse e1 = createCRMChannelResponse(321, 444, EntityType.EMAIL, true);
        CRMChannelResponse e2 = createCRMChannelResponse(321, 555, EntityType.EMAIL, true);
        CRMChannelResponse at1 = createCRMChannelResponse(321, 666, EntityType.ENTITY_ATTRIBUTE, true);
        CRMChannelResponse at2 = createCRMChannelResponse(321, 777, EntityType.ENTITY_ATTRIBUTE, true);
        CRMChannelResponseList adrList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{a1, a2})).build();
        CRMChannelResponseList emList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{e1, e2})).build();
        CRMChannelResponseList atList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{at1, at2})).build();
        List<CRMChannelResponseList> respList = Arrays.asList(new CRMChannelResponseList[]{adrList,emList,atList});
        CRMLoaderResponse response = contactAggregatorService.composeEndpointResponse(respList);
        assertTrue(response.getStatus().equals(CRMResponseStatusEnum.CORE_ATTRIBUTE_SUCCESS));
        assertTrue(response.getMessage().equals("Core attribute succeeded in processing"));
    }

    @Test
    public void aggregateAndPublishChannelResponsesTest_All_Failed() {
        CRMChannelResponse a1 = createCRMChannelResponse(321, 222, EntityType.ADDRESS, true);
        CRMChannelResponse a2 = createCRMChannelResponse(321, 333, EntityType.ADDRESS, false);
        CRMChannelResponse e1 = createCRMChannelResponse(321, 444, EntityType.EMAIL, true);
        CRMChannelResponse e2 = createCRMChannelResponse(321, 555, EntityType.EMAIL, false);
        CRMChannelResponse at1 = createCRMChannelResponse(321, 666, EntityType.ENTITY_ATTRIBUTE, true);
        CRMChannelResponse at2 = createCRMChannelResponse(321, 777, EntityType.ENTITY_ATTRIBUTE, true);
        CRMChannelResponseList adrList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{a1, a2})).build();
        CRMChannelResponseList emList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{e1, e2})).build();
        CRMChannelResponseList atList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{at1, at2})).build();
        List<CRMChannelResponseList> respList = Arrays.asList(new CRMChannelResponseList[]{adrList,emList,atList});
        CRMLoaderResponse response = contactAggregatorService.composeEndpointResponse(respList);
        assertTrue(response.getStatus().equals(CRMResponseStatusEnum.CORE_ATTRIBUTE_FAIL));
        assertTrue(response.getMessage().equals("All linked attributes failed to process"));
    }
    @Test
    public void aggregateAndPublishChannelResponsesTest_Relationship_failed() {
        CRMChannelResponse a1 = createCRMChannelResponse(321, 222, EntityType.ADDRESS, true);
        CRMChannelResponse a2 = createCRMChannelResponse(321, 333, EntityType.ADDRESS, true);
        CRMChannelResponse e1 = createCRMChannelResponse(321, 444, EntityType.EMAIL, true);
        CRMChannelResponse e2 = createCRMChannelResponse(321, 555, EntityType.EMAIL, true);
        CRMChannelResponse at1 = createCRMChannelResponse(321, 666, EntityType.ENTITY_ATTRIBUTE, true);
        CRMChannelResponse at2 = createCRMChannelResponse(321, 777, EntityType.ENTITY_ATTRIBUTE, true);
        CRMChannelResponse r1 = createCRMChannelResponse(321, 666, EntityType.CONTACT_COMPANY_REL, false);
        CRMChannelResponse r2 = createCRMChannelResponse(321, 777, EntityType.CONTACT_COMPANY_REL, true);
        CRMChannelResponseList adrList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{a1, a2})).build();
        CRMChannelResponseList emList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{e1, e2})).build();
        CRMChannelResponseList atList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{at1, at2})).build();
        CRMChannelResponseList rList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{r1, r2})).build();
        List<CRMChannelResponseList> respList = Arrays.asList(new CRMChannelResponseList[]{adrList,emList,atList,rList});
        CRMLoaderResponse response = contactAggregatorService.composeEndpointResponse(respList);
        assertTrue(response.getStatus().equals(CRMResponseStatusEnum.CORE_ATTRIBUTE_SUCCESS));
        assertTrue(response.getMessage().equals("Core attribute succeeded in processing"));
    }

    @Test
    public void aggregateAndPublishChannelResponsesTest_AddressMissing() {

        CRMChannelResponse e1 = createCRMChannelResponse(321, 444, EntityType.EMAIL, true);
        CRMChannelResponse e2 = createCRMChannelResponse(321, 555, EntityType.EMAIL, true);
        CRMChannelResponse at1 = createCRMChannelResponse(321, 666, EntityType.ENTITY_ATTRIBUTE, true);
        CRMChannelResponse at2 = createCRMChannelResponse(321, 777, EntityType.ENTITY_ATTRIBUTE, true);
        CRMChannelResponseList emList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{e1, e2})).build();
        CRMChannelResponseList atList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{at1, at2})).build();
        List<CRMChannelResponseList> respList = Arrays.asList(new CRMChannelResponseList[]{emList,atList});
        CRMLoaderResponse response = contactAggregatorService.composeEndpointResponse(respList);
        assertTrue(response.getStatus().equals(CRMResponseStatusEnum.FULL_SUCCESS));
        assertTrue(response.getMessage().equals("All entities processed successfully"));
    }

    private CRMChannelResponse createCRMChannelResponse(int coreEntityId, int entityId, EntityType entityType, boolean status) {
        CRMChannelResponse response = CRMChannelResponse.newBuilder()
                .setCoreEntityId(coreEntityId)
                .setEntityId(entityId)
                .setEntityType(entityType)
                .setStatus(status).build();
        return response;
    }
   /*

    @Override
    public CRMLoaderResponse aggregateAndPublishChannelResponses(List<CRMChannelResponseList> responseList) {*/
}
