package com.bfm.aap.privatemarkets.crm.loader.integration.service;

import com.bfm.aap.pmdx.model.ContactEmail;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreContactInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreContactMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.ElectronicAddressMessage;
import com.bfm.aap.privatemarkets.crm.loader.service.CRMLoaderCoreService;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.entitymaster.dto.common.Decode;
import com.bfm.entitymaster.dto.common.ElectronicAddress;
import com.bfm.entitymaster.dto.contact.Contact;
import com.bfm.entitymaster.dto.contact.ContactDetail;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import java.util.ArrayList;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ContactCRMCoreServiceTest {

    @InjectMocks
    private ContactCRMCoreService contactCRMCoreServiceTest;
    @Mock
    private CRMLoaderCoreService crmCoreService;
    @Mock
    private CRMThirdPartyMapperService crmThirdPartyMapperService;
    @Mock
    private CoreContactInverseMessage coreContactInverseMessage;

    @Test
    public void populateCRMEntityId_Test() {
        //when(crmThirdPartyMapperService.lookUp(anyString(), any(ThirdPartyMappingEnum.class))).thenReturn(123);
        when(crmThirdPartyMapperService.lookUp("CON123", ThirdPartyMappingEnum.CONTACT_INVEST)).thenReturn(123);
        when(crmThirdPartyMapperService.lookUp("USER123", ThirdPartyMappingEnum.USER_INVEST)).thenReturn(234);
        when(crmThirdPartyMapperService.getLoginByEntityId(anyInt())).thenReturn("userLogin");

        Message<CoreContactMessage> msg = contactCRMCoreServiceTest.populateCRMEntityId(getContactMsg());
        assertTrue(msg.getPayload().getCrmContact().getEntityId() == 123);
        assertTrue(msg.getPayload().getCrmContact().getFirstName().equals("FirstName"));
        assertTrue(msg.getPayload().getCrmContact().getLastName().equals("LastName"));
        assertTrue("userLogin".equalsIgnoreCase(msg.getPayload().getUser()));
    }

    @Test
    public void handleCoreContactCreate_Test() {
        Contact c = new Contact();
        c.setEntityId(123);
        c.setFirstName("FirstName");
        c.setLastName("LastName");
        when(crmCoreService.createContact(any(Contact.class), any(ElectronicAddress.class),anyString())).thenReturn(c);
        CoreContactMessage cmsg = contactCRMCoreServiceTest.handleCoreContactCreate(getContactMsg());
        assertTrue(cmsg.getCrmContact().getEntityId() == 123);
        assertTrue(cmsg.getCrmContact().getFirstName().equals("FirstName"));
        assertTrue(cmsg.getCrmContact().getLastName().equals("LastName"));
    }


    @Test
    public void handleCoreContactUpdate_Test() {
        ContactDetail mockContactDetail = new ContactDetail();
        Contact c = getContactCRM("OldFirstName", "OldLastName",
                "MiddleName", "Jr", "NickName", "Sir");
        c.setEntityId(123);
        Contact resp = getContactCRM("FirstName", "LastName",
                "MiddleName", "Jr", "NickName", "Sir");
        c.setEntityId(123);
        mockContactDetail.setContact(c);
        when(crmCoreService.getCRMUserContact(anyInt(),anyString())).thenReturn(mockContactDetail);
        when(crmCoreService.updateContact(anyInt(), any(Contact.class),anyString())).thenReturn(resp);
        CoreContactMessage response = contactCRMCoreServiceTest.handleCoreContactUpdate(getCoreContactMessage());
        assertNotNull(response);
        assertTrue(response.getCrmContact().getFirstName().equals("FirstName"));
        assertTrue(response.getCrmContact().getLastName().equals("LastName"));
    }

    
    public void popoulateEfronContact() {
        when(crmCoreService.getCRMUserContact(anyInt(), anyString())).thenReturn(mock(ContactDetail.class));
        when(crmCoreService.getEntityAttributesByEntityId(anyInt(), anyString())).thenReturn(mock(ArrayList.class));
        contactCRMCoreServiceTest.populateEfrontContact(getCoreContactInverseMessage());
    }

    private Message<CoreContactMessage> getCoreContactMessage() {
        CoreContactMessage req = getContactMsg().getPayload();
        req.getCrmContact().setEntityId(123);
        return MessageBuilder.withPayload(req).setHeader("user", "userLogin").build();
    }

    private Message<CoreContactInverseMessage> getCoreContactInverseMessage() {
        CoreContactInverseMessage msg = new CoreContactInverseMessage();
        msg.setCrmContactId(1234);
        return MessageBuilder.withPayload(msg).setHeader("user", "userLogin").build();
    }


    Message<CoreContactMessage> getContactMsg() {
        Contact crmContact = getContactCRM("FirstName", "LastName",
                "MiddleName", "Jr", "NickName", "Sir");
        ContactEmail email = ContactEmail.newBuilder().setEmail("test@gmail.com").setIsPrimary(true).build();
        ElectronicAddress ea = getEmailAddress("test@gmail.com", true);
        ElectronicAddressMessage emsg = new ElectronicAddressMessage();
        emsg.setElectronicAddress(ea);
        com.bfm.aap.pmdx.model.Contact pmdxContact =
                com.bfm.aap.pmdx.model.Contact.newBuilder()
                        .setFirstName("FirstName")
                        .setLastName("LastName")
                        .setMiddleName("MiddleName")
                        .setSuffix("Jr")
                        .setNickName("NickName")
                        .setSalutation("Sir")
                        .addEmailList(email)
                        .setContactId("CON123")
                        .setModifiedBy("USER123")
                        .build();
        CoreContactMessage coreContactMessage = new CoreContactMessage();
        coreContactMessage.setCrmContact(crmContact);
        coreContactMessage.setPmdxContact(pmdxContact);
        coreContactMessage.setPrimaryEmail(emsg);

        return MessageBuilder.withPayload(coreContactMessage).setHeader("user","userLogin").build();

    }

    private Contact getContactCRM(String firstName, String lastName,
                                  String middleName, String suffix,
                                  String nickName, String saluatation) {
        Contact crmContact = new Contact();
        crmContact.setFirstName(firstName);
        crmContact.setLastName(lastName);
        crmContact.setMiddleName(middleName);
        crmContact.setSuffix(suffix);
        crmContact.setNickName(nickName);
        crmContact.setSalutation(saluatation);
        return crmContact;
    }

    private ElectronicAddress getEmailAddress(String email, boolean isPrimary) {
        ElectronicAddress electronicAddress = new ElectronicAddress();
        electronicAddress.setAddress(email);
        electronicAddress.setPrimary(isPrimary);
        electronicAddress.setElectronicType(getEmailDecode());
        electronicAddress.setElectronicSubType(getDecode("PROFESSIONAL", "PROFESSIONAL"));
        return electronicAddress;
    }

    Decode getEmailDecode() {
        return getDecode("EMAIL", "Email");
    }

    private Decode getDecode(String code, String decode) {
        Decode d = new Decode();
        d.setCode(code);
        d.setDecode(decode);
        return d;
    }
}
