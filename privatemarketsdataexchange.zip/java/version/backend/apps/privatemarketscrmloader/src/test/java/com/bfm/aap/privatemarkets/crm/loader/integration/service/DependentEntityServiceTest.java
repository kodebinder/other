package com.bfm.aap.privatemarkets.crm.loader.integration.service;

import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.ContactEmail;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.Legal;
import com.bfm.aap.pmdx.model.util.SchemaEnum;
import com.bfm.aap.privatemarkets.crm.loader.mapper.EmploymentRelTransformer;
import com.bfm.aap.privatemarkets.crm.loader.mapper.EntityRelationshipTransformer;
import com.bfm.aap.privatemarkets.crm.loader.mapper.NoteTransformer;
import com.bfm.aap.privatemarkets.crm.loader.model.AddressMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.AliasMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreCompanyMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreContactMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.ElectronicAddressMessage;
import com.bfm.aap.privatemarkets.common.crm.model.CRMChannelResponse;
import com.bfm.aap.privatemarkets.common.crm.model.EntityType;
import com.bfm.aap.privatemarkets.common.crm.util.EntityMasterDecodeTableConstants;
import com.bfm.aap.privatemarkets.crm.loader.service.CRMLoaderCoreService;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.entitymaster.dto.alias.Alias;
import com.bfm.entitymaster.dto.common.Address;
import com.bfm.entitymaster.dto.common.Decode;
import com.bfm.entitymaster.dto.common.ElectronicAddress;
import com.bfm.entitymaster.dto.common.Entity;
import com.bfm.entitymaster.dto.contact.Contact;
import com.bfm.entitymaster.dto.entityrelationship.Employment;
import com.bfm.entitymaster.dto.entityrelationship.Relationship;
import com.bfm.entitymaster.dto.note.Note;
import com.bfm.util.BFMDate;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class DependentEntityServiceTest {

    @InjectMocks
    private DependentEntityService dependentEntityService;
    @Mock
    private CRMLoaderCoreService crmCoreService;
    @Mock
    private CRMThirdPartyMapperService crmThirdPartyMapperService;
    @Mock
    private NoteTransformer noteTransformer;
    @Mock
    private EntityRelationshipTransformer relationshipTransformer;
    @Mock
    private EmploymentRelTransformer employmentRelTransformer;

    @Test
    public void createCRMAddress_Test() {
        Address mockResponse = new Address();
        mockResponse.setAddressId(123);
        when(crmCoreService.createContactAddress(anyInt(), any(Address.class), anyString())).thenReturn(mockResponse);
        CRMChannelResponse response = dependentEntityService.createCRMAddress(getAddressMessage("street1", "street2", "street3", "Seattle", "WA", "98101", "Home", "USA", true));
        assertTrue(response.getEntityId() == 123);
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 321);
        assertTrue(response.getEntityType().name().equals(EntityType.ADDRESS.name()));
    }

    @Test
    public void createCRMAddress_Test_Null_Address() {
        Address mockResponse = new Address();
        mockResponse.setAddressId(123);
//        when(crmCoreService.createContactAddress(anyInt(), any(Address.class), anyString())).thenReturn(mockResponse);
        CRMChannelResponse response = dependentEntityService.createCRMAddress(getAddressMessage_NullAddress());
        assertTrue(response.getEntityId() == -1);
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 321);
        assertTrue(response.getEntityType().name().equals(EntityType.ADDRESS.name()));
    }

    @Test
    public void createCRMAddress_Exception_Test() {
        Address mockResponse = new Address();
        mockResponse.setAddressId(123);
        when(crmCoreService.createContactAddress(anyInt(), any(Address.class), anyString())).thenThrow(new RuntimeException("Error"));
        CRMChannelResponse response = dependentEntityService.createCRMAddress(getAddressMessage("street1", "street2", "street3", "Seattle", "WA", "98101", "Home", "USA", true));
        assertTrue(response.getEntityId() == -1);
        assertTrue(!response.getStatus());
        assertTrue(response.getCoreEntityId() == 321);
        assertTrue(response.getEntityType().name().equals(EntityType.ADDRESS.name()));
    }

    @Test
    public void createCRMAddress_Test_Exception_In_Create() {
        Address mockResponse = new Address();
        mockResponse.setAddressId(123);
        when(crmCoreService.createContactAddress(anyInt(), any(Address.class), anyString())).thenReturn(mockResponse);
        when(crmThirdPartyMapperService.create(anyString(), anyInt(), any(ThirdPartyMappingEnum.class))).thenThrow(new RuntimeException("Error"));
        CRMChannelResponse response = dependentEntityService.createCRMAddress(getAddressMessage("street1", "street2", "street3", "Seattle", "WA", "98101", "Home", "USA", true));
        assertTrue(response.getEntityId() == -1);
        assertTrue(!response.getStatus());
        assertTrue(response.getCoreEntityId() == 321);
        assertTrue(response.getEntityType().name().equals(EntityType.ADDRESS.name()));
    }

    @Test
    public void createCRMAddress_Test_Null_Response() {
        when(crmCoreService.createContactAddress(anyInt(), any(Address.class), anyString())).thenReturn(null);
        CRMChannelResponse response = dependentEntityService.createCRMAddress(getAddressMessage("street1", "street2", "street3", "Seattle", "WA", "98101", "Home", "USA", true));
        assertTrue(response.getEntityId() == -1);
        assertTrue(!response.getStatus());
        assertTrue(response.getCoreEntityId() == 321);
        assertTrue(response.getEntityType().name().equals(EntityType.ADDRESS.name()));
    }

    @Test
    public void emailCreateChannel_Test() {
        ElectronicAddress mockResponse = getEmailAddress("test@gmail.com", true);
        mockResponse.setElectronicAddressId(123);
        when(crmCoreService.createContactElectronicAddress(anyInt(), any(ElectronicAddress.class), anyString())).thenReturn(mockResponse);
        ElectronicAddressMessage msg = new ElectronicAddressMessage();
        msg.setLinkedCRMEntityId(321);
        msg.setElectronicAddress(getEmailAddress("test@gmail.com", true));
        CRMChannelResponse response = dependentEntityService.createElectronicAddress(MessageBuilder.withPayload(msg).setHeader("user", "userLogin").build());
        assertTrue(response.getEntityId() == 123);
        assertTrue(response.getStatus());
        assertTrue(response.getEntityType().name().equals(EntityType.EMAIL.name()));
    }

    @Test
    public void emailCreateChannel_Test_Exception_Response() {

        when(crmCoreService.createContactElectronicAddress(anyInt(), any(ElectronicAddress.class), anyString())).thenThrow(new RuntimeException("Error"));
        ElectronicAddressMessage msg = new ElectronicAddressMessage();
        msg.setLinkedCRMEntityId(321);
        msg.setElectronicAddress(getEmailAddress("test@gmail.com", true));
        CRMChannelResponse response = dependentEntityService.createElectronicAddress(MessageBuilder.withPayload(msg).setHeader("user", "userLogin").build());
        assertTrue(response.getCoreEntityId() == 321);
        assertTrue(response.getEntityId() == -1);
        assertTrue(!response.getStatus());
        assertTrue(response.getEntityType().name().equals(EntityType.EMAIL.name()));
    }

    @Test
    public void emailCreateChannel_Test_Null_Response() {

//        when(crmCoreService.createContactElectronicAddress(anyInt(), any(ElectronicAddress.class), anyString())).thenReturn(null);
        ElectronicAddressMessage msg = new ElectronicAddressMessage();
        msg.setLinkedCRMEntityId(321);
        msg.setElectronicAddress(getEmailAddress("test@gmail.com", true));
        CRMChannelResponse response = dependentEntityService.createElectronicAddress(MessageBuilder.withPayload(msg).build());
        assertTrue(response.getCoreEntityId() == 321);
        assertTrue(response.getEntityId() == -1);
        assertTrue(!response.getStatus());
        assertTrue(response.getEntityType().name().equals(EntityType.EMAIL.name()));
    }

    @Test
    public void populateAddressCRMEntityId_Test() {
        when(crmThirdPartyMapperService.lookUp(anyString(), any(ThirdPartyMappingEnum.class))).thenReturn(123);
        AddressMessage msg = dependentEntityService.populateAddressCRMEntityId(
                getAddressMessage("street1", "street2", "street3", "Seattle", "WA", "98101", "Home", "USA", true).getPayload());
        assertTrue(msg.getCrmAddress().getAddressId() == 123);
    }

    @Test
    public void handleAddressUpdate_Test() {
        Address mockAddress = getTransformedAddress
                ("street1", "street2", "street3", "Seattle", "WA", "98101", "Home", "USA", true);
        mockAddress.setAddressId(123);
        Address newAddress = getTransformedAddress
                ("newStreet", "street2", "street3", "Seattle", "WA", "98101", "Home", "USA", true);
        newAddress.setAddressId(123);
        Message mockAddressMessage = getAddressMessage(123);
        when(crmCoreService.getAddress(anyInt(), anyString())).thenReturn(mockAddress);
        when(crmCoreService.updateContactAddress(anyInt(), any(Address.class), anyString())).thenReturn(newAddress);
        CRMChannelResponse response = dependentEntityService.handleAddressUpdate(mockAddressMessage);
        assertTrue(response.getStatus());
        assertTrue(response.getEntityId() == 123);
        assertTrue(response.getEntityType().name().equals(EntityType.ADDRESS.name()));
    }

    @Test
    public void handleAddressUpdate_Test_Null_Address() {
        CRMChannelResponse response = dependentEntityService.handleAddressUpdate(getAddressMessage_NullAddress());
        assertTrue(response.getStatus());
        assertTrue(response.getEntityId() == -1);
        assertTrue(response.getEntityType().name().equals(EntityType.ADDRESS.name()));
    }

    @Test
    public void handleAddressUpdate_Test_Exception_Response() {
        Address mockAddress = getTransformedAddress
                ("street1", "street2", "street3", "Seattle", "WA", "98101", "Home", "USA", true);
        mockAddress.setAddressId(123);
        Address newAddress = getTransformedAddress
                ("newStreet", "street2", "street3", "Seattle", "WA", "98101", "Home", "USA", true);
        newAddress.setAddressId(123);
        Message mockAddressMessage = getAddressMessage(123);
        when(crmCoreService.getAddress(anyInt(), anyString())).thenThrow(new RuntimeException("Error"));
        CRMChannelResponse response = dependentEntityService.handleAddressUpdate(mockAddressMessage);
        assertTrue(!response.getStatus());
        assertTrue(response.getCoreEntityId() == 321);
        assertTrue(response.getEntityType().name().equals(EntityType.ADDRESS.name()));
    }

    @Test
    public void handleAddressUpdate_Test_NullResponse() {
        Address mockAddress = getTransformedAddress
                ("street1", "street2", "street3", "Seattle", "WA", "98101", "Home", "USA", true);
        mockAddress.setAddressId(123);
        Address newAddress = getTransformedAddress
                ("newStreet", "street2", "street3", "Seattle", "WA", "98101", "Home", "USA", true);
        newAddress.setAddressId(123);
        Message mockAddressMessage = getAddressMessage(123);
        when(crmCoreService.getAddress(anyInt(), anyString())).thenReturn(mockAddress);
        when(crmCoreService.updateContactAddress(anyInt(), any(Address.class), anyString())).thenReturn(null);
        CRMChannelResponse response = dependentEntityService.handleAddressUpdate(mockAddressMessage);
        assertTrue(!response.getStatus());
        assertTrue(response.getCoreEntityId() == 321);
        assertTrue(response.getEntityType().name().equals(EntityType.ADDRESS.name()));
    }

    private Message<AddressMessage> getAddressMessage(int i) {
        AddressMessage mockAddressMessage = getAddressMessage("newStreet", "street2", "street3", "Seattle", "WA", "98101", "Home", "USA", true).getPayload();
        mockAddressMessage.getCrmAddress().setAddressId(i);
        return MessageBuilder.withPayload(mockAddressMessage).setHeader("user", "userLogin").build();
    }

    @Test
    public void handleAddressUpdate_Test_NewEntry() {
        Address mockAddress = getTransformedAddress
                ("street1", "street2", "street3", "Seattle", "WA", "98101", "Home", "USA", true);
        mockAddress.setAddressId(123);
        when(crmCoreService.createContactAddress(anyInt(), any(Address.class), anyString())).thenReturn(mockAddress);
        Message mockAddressMessage = getAddressMessage(-1);
        CRMChannelResponse response = dependentEntityService.handleAddressUpdate(mockAddressMessage);
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 321);
        assertTrue(response.getEntityType().name().equals(EntityType.ADDRESS.name()));
    }

    @Test
    public void handleAddressUpdate_Test_Response_Mismatch() {
        Address mockAddress = getTransformedAddress
                ("street1", "street2", "street3", "Seattle", "WA", "98101", "Home", "USA", true);
        mockAddress.setAddressId(123);

        Message mockAddressMessage = getAddressMessage(123);
        when(crmCoreService.getAddress(anyInt(), anyString())).thenReturn(mockAddress);
        when(crmCoreService.updateContactAddress(anyInt(), any(Address.class), anyString())).thenReturn(null);
        CRMChannelResponse response = dependentEntityService.handleAddressUpdate(mockAddressMessage);
        assertTrue(!response.getStatus());
        assertTrue(response.getEntityId() == -1);
        assertTrue(response.getEntityType().name().equals(EntityType.ADDRESS.name()));
    }

    @Test
    public void handleElectronicAddressUpdate_Test() {
        List<ElectronicAddress> mockEaList = new ArrayList<>();
        mockEaList.add(getEmailAddress("test@gmail.com", true));
        mockEaList.add(getEmailAddress("test@yahoo.com", false));

        when(crmCoreService.getElectronicAddressByEntityId(anyInt(), anyString())).thenReturn(mockEaList);
        ElectronicAddress address = getEmailAddress("test@live.com", true);
        address.setElectronicAddressId(444);
        when(crmCoreService.createContactElectronicAddress(anyInt(), any(ElectronicAddress.class), anyString())).thenReturn(address);
        Message emsg = getElectronicAddressMessage();
        CRMChannelResponse response = dependentEntityService.handleElectronicAddressUpdate(emsg);
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 321);
        assertTrue(response.getEntityId() == 444);
        assertTrue(response.getEntityType().name().equals(EntityType.EMAIL.name()));
    }

    private Message<ElectronicAddressMessage> getElectronicAddressMessage() {
        ElectronicAddress ea = getEmailAddress("test@live.com", true);
        ElectronicAddressMessage emsg = new ElectronicAddressMessage();
        emsg.setElectronicAddress(ea);
        emsg.setLinkedCRMEntityId(321);
        return MessageBuilder.withPayload(emsg).setHeader("user", "userLogin").build();
    }

    @Test
    public void handleElectronicAddressUpdate_IncorrectPersistenceByAPI() {
        List<ElectronicAddress> mockEaList = new ArrayList<>();
        mockEaList.add(getEmailAddress("test@gmail.com", true));
        mockEaList.add(getEmailAddress("test@yahoo.com", false));

        when(crmCoreService.getElectronicAddressByEntityId(anyInt(), anyString())).thenReturn(mockEaList);
        ElectronicAddress address = getEmailAddress("test1@live.com", true);
        address.setElectronicAddressId(444);
        when(crmCoreService.createContactElectronicAddress(anyInt(), any(ElectronicAddress.class), anyString())).thenReturn(address);
        Message emsg = getElectronicAddressMessage();
        CRMChannelResponse response = dependentEntityService.handleElectronicAddressUpdate(emsg);
        assertTrue(!response.getStatus());
        assertTrue(response.getCoreEntityId() == 321);
        assertTrue(response.getEntityId() == -1);
        assertTrue(response.getEntityType().name().equals(EntityType.EMAIL.name()));
    }

    @Test
    public void handleElectronicAddressUpdate_Test_Exception() {
        List<ElectronicAddress> mockEaList = new ArrayList<>();
        mockEaList.add(getEmailAddress("test@gmail.com", true));
        mockEaList.add(getEmailAddress("test@yahoo.com", false));

        when(crmCoreService.getElectronicAddressByEntityId(anyInt(), anyString())).thenThrow(new RuntimeException("Error"));
        Message emsg = getElectronicAddressMessage();
        CRMChannelResponse response = dependentEntityService.handleElectronicAddressUpdate(emsg);
        assertTrue(!response.getStatus());
        assertTrue(response.getCoreEntityId() == 321);
        assertTrue(response.getEntityType().name().equals(EntityType.EMAIL.name()));
    }

    @Test
    public void handleElectronicAddressUpdate_Test_Null() {
        List<ElectronicAddress> mockEaList = new ArrayList<>();
        mockEaList.add(getEmailAddress("test@gmail.com", true));
        mockEaList.add(getEmailAddress("test@yahoo.com", false));
        when(crmCoreService.getElectronicAddressByEntityId(anyInt(), anyString())).thenReturn(mockEaList);
        when(crmCoreService.createContactElectronicAddress(anyInt(), any(ElectronicAddress.class), anyString())).thenReturn(null);
        Message emsg = getElectronicAddressMessage();
        CRMChannelResponse response = dependentEntityService.handleElectronicAddressUpdate(emsg);
        assertTrue(!response.getStatus());
        assertTrue(response.getCoreEntityId() == 321);
        assertTrue(response.getEntityType().name().equals(EntityType.EMAIL.name()));
    }

    @Test
    public void handleElectronicAddressUpdate_New_Entry() {
        ElectronicAddress address = getEmailAddress("test@live.com", true);
        address.setElectronicAddressId(444);
        when(crmCoreService.getElectronicAddressByEntityId(anyInt(), anyString())).thenReturn(null);
        when(crmCoreService.createContactElectronicAddress(anyInt(), any(ElectronicAddress.class), anyString())).thenReturn(address);
        Message emsg = getElectronicAddressMessage();
        CRMChannelResponse response = dependentEntityService.handleElectronicAddressUpdate(emsg);
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 321);
        assertTrue(response.getEntityType().name().equals(EntityType.EMAIL.name()));
    }

    @Test
    public void createCompanyAlias_Test() {
        Alias mockAlias = getAlias("KnowAs", "ShortName");
        mockAlias.setAliasId(333);
        when(crmCoreService.createEntityAliasCRM(anyInt(), any(Alias.class), anyString())).thenReturn(mockAlias);
        CRMChannelResponse response = dependentEntityService.createOrgAlias(getAliasMessage(123, getAlias("KnowAs", "ShortName")));
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == 333);
        assertTrue(response.getEntityType().name().equals(EntityType.ENTITY_ALIAS.name()));

    }

    @Test
    public void createCompanyAlias_Test_NoAliases() {
        Alias mockAlias = getAlias("KnowAs", "ShortName");
        mockAlias.setAliasId(333);
//        when(crmCoreService.createEntityAliasCRM(anyInt(), any(Alias.class), anyString())).thenReturn(null);
        CRMChannelResponse response = dependentEntityService.createOrgAlias(getAliasMessage(123, null));
        assertTrue(!response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == -1);
        assertTrue(response.getEntityType().name().equals(EntityType.ENTITY_ALIAS.name()));

    }

    @Test
    public void createCompanyAlias_Test_Exception() {
        Alias mockAlias = getAlias("KnowAs", "ShortName");
        mockAlias.setAliasId(333);
//        when(crmCoreService.createEntityAliasCRM(anyInt(), any(Alias.class), anyString())).thenThrow(new RuntimeException("Error"));
        CRMChannelResponse response = dependentEntityService.createOrgAlias(getAliasMessage(123, null));
        assertTrue(!response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == -1);
        assertTrue(response.getEntityType().name().equals(EntityType.ENTITY_ALIAS.name()));

    }

    @Test
    public void handleCompanyAliasUpdate_Test() {
        Alias oldAlias = getAlias("ABC", "AKA");
        oldAlias.setAliasId(333);
        when(crmCoreService.getEntityAliasByEntityIdCRM(anyInt(), anyString()))
                .thenReturn(Arrays.asList(oldAlias));
        Alias mockAlias = getAlias("ABCD", "AKA");
        mockAlias.setAliasId(333);
        when(crmCoreService.updateEntityAliasCRM(anyInt(), any(Alias.class), anyString())).thenReturn(mockAlias);
        CRMChannelResponse response = dependentEntityService.handleOrgAliasUpdate(getAliasMessage(123, getAlias("KnowAs", "AKA")));
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == 333);
        assertTrue(response.getEntityType().name().equals(EntityType.ENTITY_ALIAS.name()));
    }

    @Test
    public void handleCompanyAliasUpdate_Test_NewAliasInUpdate() {
        Alias oldAlias = getAlias("ABC", "AKA");
        oldAlias.setAliasId(333);
        when(crmCoreService.getEntityAliasByEntityIdCRM(anyInt(), anyString()))
                .thenReturn(null);
        Alias mockAlias = getAlias("ABCD", "AKA");
        mockAlias.setAliasId(333);
        when(crmCoreService.createEntityAliasCRM(anyInt(), any(Alias.class), anyString())).thenReturn(mockAlias);
        CRMChannelResponse response = dependentEntityService.handleOrgAliasUpdate(getAliasMessage(123, getAlias("ABCD", "AKA")));
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == 333);
        assertTrue(response.getEntityType().name().equals(EntityType.ENTITY_ALIAS.name()));
    }

    @Test
    public void handleCompanyAliasUpdate_Test_NoAliases() {
        when(crmCoreService.getEntityAliasByEntityIdCRM(anyInt(), anyString()))
                .thenReturn(null);
        Alias mockAlias = getAlias("ABCD", "AKA");
        mockAlias.setAliasId(333);
        when(crmCoreService.createEntityAliasCRM(anyInt(), any(Alias.class), anyString())).thenReturn(mockAlias);
        CRMChannelResponse response = dependentEntityService.handleOrgAliasUpdate(getAliasMessage(123, getAlias("ABCD", "AKA")));
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == 333);
        assertTrue(response.getEntityType().name().equals(EntityType.ENTITY_ALIAS.name()));
    }

    @Test
    public void handleCompanyAliasUpdate_Test_Exception() {
        when(crmCoreService.getEntityAliasByEntityIdCRM(anyInt(), anyString()))
                .thenThrow(new RuntimeException("Error"));
        Alias mockAlias = getAlias("ABCD", "AKA");
        mockAlias.setAliasId(333);
//        when(crmCoreService.createEntityAliasCRM(anyInt(), any(Alias.class), anyString())).thenReturn(mockAlias);
        CRMChannelResponse response = dependentEntityService.handleOrgAliasUpdate(getAliasMessage(123, getAlias("ABCD", "AKA")));
        assertTrue(!response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == -1);
        assertTrue(response.getEntityType().name().equals(EntityType.ENTITY_ALIAS.name()));
    }

    @Test
    public void handleCompanyDescCreateOrUpdate_testCreate() {
        when(crmCoreService.getNotesByEntityIdCRM(anyInt(), anyString())).thenReturn(null);
        when(noteTransformer.eFrontToCRMTransform(anyInt(), anyString(), anyString(), anyString(), any(SchemaEnum.class)))
                .thenReturn(getNote(123, "testDescription", "ORG_BUS_OVERVW"));
        Note mockNote = getNote(123, "testDescription", "ORG_BUS_OVERVW");
        mockNote.setNoteId(333);
        when(crmCoreService.createEntityNoteCRM(any(Note.class), anyString())).thenReturn(mockNote);
        CRMChannelResponse response = dependentEntityService.handleCompanyDescCreateOrUpdate(getCompanyMsg());
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == 333);
        assertTrue(response.getEntityType().name().equals(EntityType.NOTE.name()));
    }

    @Test
    public void handleInvestorDescCreateOrUpdate_testCreate() {
        when(crmCoreService.getNotesByEntityIdCRM(anyInt(), anyString())).thenReturn(null);
        when(noteTransformer.eFrontToCRMTransform(anyInt(), anyString(), anyString(), anyString(), any(SchemaEnum.class)))
                .thenReturn(getNote(123, "TestDescription", "ORG_BUS_OVERVW"));
        Note mockNote = getNote(123, "TestDescription", "ORG_BUS_OVERVW");
        mockNote.setNoteId(333);
        when(crmCoreService.createEntityNoteCRM(any(Note.class), anyString())).thenReturn(mockNote);
        CRMChannelResponse response = dependentEntityService.handleInvestorDescCreateOrUpdate(getInvestorMsg());
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == 333);
        assertTrue(response.getEntityType().name().equals(EntityType.NOTE.name()));
    }

    @Test
    public void handleCompanyDescCreateOrUpdate_testUpdate() {
        Note oldNote = getNote(123, "testDescriptionOld", "ORG_BUS_OVERVW");
        oldNote.setNoteId(333);
        when(crmCoreService.getNotesByEntityIdCRM(anyInt(), anyString())).thenReturn(Arrays.asList(oldNote));
        when(noteTransformer.eFrontToCRMTransform(anyInt(), anyString(), anyString(), anyString(), any(SchemaEnum.class)))
                .thenReturn(getNote(123, "testDescription", "ORG_BUS_OVERVW"));
        Note mockNote = getNote(123, "testDescription", "ORG_BUS_OVERVW");
        mockNote.setNoteId(333);
        //when(crmCoreService.createEntityNoteCRM(any(Note.class))).thenReturn(mockNote);
        when(crmCoreService.updateEntityNoteCRM(any(Note.class), anyString())).thenReturn(mockNote);
        CRMChannelResponse response = dependentEntityService.handleCompanyDescCreateOrUpdate(getCompanyMsg());
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == 333);
        assertTrue(response.getEntityType().name().equals(EntityType.NOTE.name()));
    }

    @Test
    public void handleCompanyDescCreateOrUpdate_testNoExistingNote() {
        Note oldNote = getNote(123, "testDescriptionOld", "ALTSSALESPLNBAA");
        oldNote.setNoteId(333);
        when(crmCoreService.getNotesByEntityIdCRM(anyInt(), anyString())).thenReturn(Arrays.asList(oldNote));
        when(noteTransformer.eFrontToCRMTransform(anyInt(), anyString(), anyString(), anyString(), any(SchemaEnum.class)))
                .thenReturn(getNote(123, "testDescription", "ORG_BUS_OVERVW"));
        Note mockNote = getNote(123, "testDescription", "ORG_BUS_OVERVW");
        mockNote.setNoteId(333);
        when(crmCoreService.createEntityNoteCRM(any(Note.class), anyString())).thenReturn(mockNote);
        //when(crmCoreService.updateEntityNoteCRM(any(Note.class))).thenReturn(mockNote);
        CRMChannelResponse response = dependentEntityService.handleCompanyDescCreateOrUpdate(getCompanyMsg());
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == 333);
        assertTrue(response.getEntityType().name().equals(EntityType.NOTE.name()));
    }

    @Test
    public void handleCompanyDescCreateOrUpdate_testExceptionCase() {
        Note oldNote = getNote(123, "testDescriptionOld", "ALTSSALESPLNBAA");
        oldNote.setNoteId(333);
        when(crmCoreService.getNotesByEntityIdCRM(anyInt(), anyString())).thenThrow(new RuntimeException("Error"));
        CRMChannelResponse response = dependentEntityService.handleCompanyDescCreateOrUpdate(getCompanyMsg());
        assertTrue(!response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == -1);
        assertTrue(response.getEntityType().name().equals(EntityType.NOTE.name()));
    }

    @Test
    public void handleCompanyToParentCompanyRelationshipCreateOrUpdate_Test() {
        when(crmThirdPartyMapperService.lookUp(anyString(), any(ThirdPartyMappingEnum.class))).thenReturn(345);
        when(relationshipTransformer.eFrontToCRMTransform(anyInt(), anyInt(), any(BFMDate.class), any(BFMDate.class), any(Boolean.class), anyString(), any(SchemaEnum.class)))
                .thenReturn(getRelationship(123, 678,
                        "ORG", "PARENT_COMPANY", new BFMDate(new Date()), new BFMDate(BFMDate.max_date), true));
        when(crmCoreService.getEntityRelationship(anyInt(), anyInt(), anyString(), anyString(), anyString())).thenReturn(null);
        Relationship r = getRelationship(123, 678,
                "ORG", "PARENT_COMPANY", new BFMDate(new Date()), new BFMDate(BFMDate.max_date), true);
        r.setRelationshipId(111);
        when(crmCoreService.createRelationship(any(Relationship.class), anyString())).thenReturn(r);
        CRMChannelResponse response = dependentEntityService.handleCompanyToParentCompanyRelationshipCreateOrUpdate(getCompanyMsg());
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == 111);
        assertTrue(response.getEntityType().name().equals(EntityType.COMPANY_PARENT_REL.name()));
    }


    @Test
    public void handleCompanyToSubsidiaryCompanyRelationshipCreateOrUpdate_Test() {
        when(crmThirdPartyMapperService.lookUp(anyString(), any(ThirdPartyMappingEnum.class))).thenReturn(345);
        when(relationshipTransformer.eFrontToCRMTransform(anyInt(), anyInt(), any(BFMDate.class), any(BFMDate.class), any(Boolean.class), anyString(), any(SchemaEnum.class)))
                .thenReturn(getRelationship(123, 989,
                        "ORG", "PARENT_COMPANY", new BFMDate(new Date()), new BFMDate(BFMDate.max_date), true));
        when(crmCoreService.getEntityRelationship(anyInt(), anyInt(), anyString(), anyString(), anyString())).thenReturn(null);
        Relationship r = getRelationship(123, 989,
                "ORG", "PARENT_COMPANY", new BFMDate(new Date()), new BFMDate(BFMDate.max_date), true);
        r.setRelationshipId(111);
        when(crmCoreService.createRelationship(any(Relationship.class), anyString())).thenReturn(r);
        CRMChannelResponse response = dependentEntityService.handleCompanyToSubsidiaryCompanyRelationshipCreateOrUpdate(getCompanyMsg());
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == 111);
        assertTrue(response.getEntityType().name().equals(EntityType.COMPANY_SUBSIDIARY_REL.name()));
    }

    @Test
    public void handleCompanyToSubsidiaryCompanyRelationshipCreateOrUpdate_NoThirdPartyMappingForRel_Test() {
        when(crmThirdPartyMapperService.lookUp(anyString(), any(ThirdPartyMappingEnum.class))).thenReturn(0);
        CRMChannelResponse response = dependentEntityService.handleCompanyToSubsidiaryCompanyRelationshipCreateOrUpdate(getCompanyMsg());
        assertTrue(!response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == -1);
        assertTrue(response.getEntityType().name().equals(EntityType.COMPANY_SUBSIDIARY_REL.name()));
    }

    @Test
    public void handleCompanyToParentCompanyRelationshipCreateOrUpdate_NoRels() {
        CRMChannelResponse response = dependentEntityService.handleCompanyToParentCompanyRelationshipCreateOrUpdate(getCompanyMessage_NoRel());
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == -1);
        assertTrue(response.getEntityType().name().equals(EntityType.COMPANY_PARENT_REL.name()));
    }

    @Test
    public void handleCompanyToSubsidiaryCompanyRelationshipCreateOrUpdate_NoRels() {
        CRMChannelResponse response = dependentEntityService.handleCompanyToSubsidiaryCompanyRelationshipCreateOrUpdate(getCompanyMessage_NoRel());
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == -1);
        assertTrue(response.getEntityType().name().equals(EntityType.COMPANY_SUBSIDIARY_REL.name()));
    }

    @Test
    public void handleCompanyToParentCompanyRelationshipCreateOrUpdate_NoThirdPartyMappingForRel_Test() {
        when(crmThirdPartyMapperService.lookUp(anyString(), any(ThirdPartyMappingEnum.class))).thenReturn(0);
        CRMChannelResponse response = dependentEntityService.handleCompanyToParentCompanyRelationshipCreateOrUpdate(getCompanyMsg());
        assertTrue(!response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == -1);
        assertTrue(response.getEntityType().name().equals(EntityType.COMPANY_PARENT_REL.name()));
    }

    @Test
    public void handleCompanyToParentCompanyRelationshipCreateOrUpdate_NullCreateResult_Test() {

        when(crmThirdPartyMapperService.lookUp(anyString(), any(ThirdPartyMappingEnum.class))).thenReturn(345);
        when(relationshipTransformer.eFrontToCRMTransform(anyInt(), anyInt(), any(BFMDate.class), any(BFMDate.class), any(Boolean.class), anyString(), any(SchemaEnum.class)))
                .thenReturn(getRelationship(123, 345,
                        "ORG", "PARENT_COMPANY", new BFMDate(new Date()), new BFMDate(BFMDate.max_date), true));
        when(crmCoreService.getEntityRelationship(anyInt(), anyInt(), anyString(), anyString(), anyString())).thenReturn(null);
        when(crmCoreService.createRelationship(any(Relationship.class), anyString())).thenReturn(null);
        CRMChannelResponse response = dependentEntityService.handleCompanyToParentCompanyRelationshipCreateOrUpdate(getCompanyMsg());
        assertTrue(!response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == -1);
        assertTrue(response.getEntityType().name().equals(EntityType.COMPANY_PARENT_REL.name()));
    }

    @Test
    public void handleCompanyToParentCompanyRelationshipCreateOrUpdate_Exception_Test() {

        when(crmThirdPartyMapperService.lookUp(anyString(), any(ThirdPartyMappingEnum.class))).thenReturn(345);
        when(relationshipTransformer.eFrontToCRMTransform(anyInt(), anyInt(), any(BFMDate.class), any(BFMDate.class), any(Boolean.class), anyString(), any(SchemaEnum.class)))
                .thenReturn(getRelationship(123, 345,
                        "ORG", "PARENT_COMPANY", new BFMDate(new Date()), new BFMDate(BFMDate.max_date), true));
        when(crmCoreService.getEntityRelationship(anyInt(), anyInt(), anyString(), anyString(), anyString())).thenThrow(new RuntimeException("Error"));
        // Employer relationship syn is turned off (AFA-11515)
        //        when(crmCoreService.createRelationship(any(Relationship.class), anyString())).thenReturn(null);
        CRMChannelResponse response = dependentEntityService.handleCompanyToParentCompanyRelationshipCreateOrUpdate(getCompanyMsg());
        assertTrue(!response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == -1);
        assertTrue(response.getEntityType().name().equals(EntityType.COMPANY_PARENT_REL.name()));
    }

    @Test
    public void handleCompanyToParentCompanyRelationshipCreateOrUpdate_UpdateRel_SameValue_Test() {

        when(crmThirdPartyMapperService.lookUp(anyString(), any(ThirdPartyMappingEnum.class))).thenReturn(345);
        when(relationshipTransformer.eFrontToCRMTransform(anyInt(), anyInt(), any(BFMDate.class), any(BFMDate.class), any(Boolean.class), anyString(), any(SchemaEnum.class)))
                .thenReturn(getRelationship(123, 345,
                        "ORG", "PARENT_COMPANY", new BFMDate(new Date()), new BFMDate(BFMDate.max_date), true));
        Relationship r = getRelationship(123, 345,
                "ORG", "PARENT_COMPANY", new BFMDate(new Date()), new BFMDate(BFMDate.max_date), true);
        r.setRelationshipId(111);

        when(crmCoreService.getEntityRelationship(anyInt(), anyInt(), anyString(), anyString(), anyString())).thenReturn(Arrays.asList(r));

        CRMChannelResponse response = dependentEntityService.handleCompanyToParentCompanyRelationshipCreateOrUpdate(getCompanyMsg());
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == 111);
        assertTrue(response.getEntityType().name().equals(EntityType.COMPANY_PARENT_REL.name()));
    }

    @Test
    public void handleCompanyToParentCompanyRelationshipCreateOrUpdate_UpdateRel_DifferentValue_Test() {

        when(crmThirdPartyMapperService.lookUp(anyString(), any(ThirdPartyMappingEnum.class))).thenReturn(345);
        when(relationshipTransformer.eFrontToCRMTransform(anyInt(), anyInt(), any(BFMDate.class), any(BFMDate.class), any(Boolean.class), anyString(), any(SchemaEnum.class)))
                .thenReturn(getRelationship(123, 345,
                        "ORG", "PARENT_COMPANY", new BFMDate(new Date()), new BFMDate(BFMDate.max_date), true));


        Relationship updatedRel = getRelationship(123, 345,
                "ORG", "PARENT_COMPANY", new BFMDate(new Date()), new BFMDate(BFMDate.max_date), true);
        updatedRel.setRelationshipId(111);
        Relationship r = getRelationship(123, 345,
                "ORG", "SUB", new BFMDate(new Date()), new BFMDate(BFMDate.max_date), true);
        r.setRelationshipId(111);
        when(crmCoreService.getEntityRelationship(anyInt(), anyInt(), anyString(), anyString(), anyString())).thenReturn(Arrays.asList(r));
        when(crmCoreService.updateRelationship(anyInt(), any(Relationship.class), anyString())).thenReturn(updatedRel);
        CRMChannelResponse response = dependentEntityService.handleCompanyToParentCompanyRelationshipCreateOrUpdate(getCompanyMsg());
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == 111);
        assertTrue(response.getEntityType().name().equals(EntityType.COMPANY_PARENT_REL.name()));
    }

    @Test
    public void handleCompanyToParentCompanyRelationshipCreateOrUpdate_UpdateRel_NewRelationship_Test() {

        when(crmThirdPartyMapperService.lookUp(anyString(), any(ThirdPartyMappingEnum.class))).thenReturn(345);
        when(relationshipTransformer.eFrontToCRMTransform(anyInt(), anyInt(), any(BFMDate.class), any(BFMDate.class), any(Boolean.class), anyString(), any(SchemaEnum.class)))
                .thenReturn(getRelationship(123, 345,
                        "ORG", "PARENT_COMPANY", new BFMDate(new Date()), new BFMDate(BFMDate.max_date), true));


        Relationship updatedRel = getRelationship(123, 345,
                "ORG", "PARENT_COMPANY", new BFMDate(new Date()), new BFMDate(BFMDate.max_date), true);
        updatedRel.setRelationshipId(111);
        Relationship r = getRelationship(123, 346,
                "ORG", "SUB", new BFMDate(new Date()), new BFMDate(BFMDate.max_date), true);
        r.setRelationshipId(111);
        when(crmCoreService.getEntityRelationship(anyInt(), anyInt(), anyString(), anyString(), anyString())).thenReturn(Arrays.asList(r));
        when(crmCoreService.createRelationship(any(Relationship.class), anyString())).thenReturn(updatedRel);
        CRMChannelResponse response = dependentEntityService.handleCompanyToParentCompanyRelationshipCreateOrUpdate(getCompanyMsg());
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == 111);
        assertTrue(response.getEntityType().name().equals(EntityType.COMPANY_PARENT_REL.name()));
    }

    @Test
    public void handleContactCompanyEmploymentCreateOrUpdate_Test() {
        when(crmThirdPartyMapperService.lookUp(anyString(), any(ThirdPartyMappingEnum.class))).thenReturn(345);
        when(employmentRelTransformer.eFrontToCRMTransform(anyInt(), anyInt(), any(BFMDate.class), isNull(), any(Boolean.class)
                , anyString()))
                .thenReturn(getEmployment(123, 789, new BFMDate(new Date()), new BFMDate(BFMDate.max_date), true
                        , "TestTitle"));
        when(crmCoreService.getEmployerByEntityId(anyInt(), anyString())).thenReturn(null);
        Employment r = getEmployment(123, 789, new BFMDate(new Date()), new BFMDate(BFMDate.max_date), true,
                "TestTitle");
        r.setEmploymentId(111);
        when(crmCoreService.createEmployment(any(Employment.class), anyString())).thenReturn(r);
        CRMChannelResponse response = dependentEntityService.handleContactCompanyRelationshipCreateOrUpdate(getContactMsg());
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 789);
        assertTrue(response.getEntityId() == 123);
        assertTrue(response.getEntityType().name().equals(EntityType.CONTACT_COMPANY_REL.name()));
    }

    @Test
    public void handleContactCompanyEmploymentCreateOrUpdate_NoThirdPartyMappingForRel_Test() {
        when(crmThirdPartyMapperService.lookUp(anyString(), any(ThirdPartyMappingEnum.class))).thenReturn(0);
        CRMChannelResponse response = dependentEntityService.handleContactCompanyRelationshipCreateOrUpdate(getContactMsg());
        assertTrue(!response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == -1);
        assertTrue(response.getEntityType().name().equals(EntityType.CONTACT_COMPANY_REL.name()));
    }

    @Test
    public void handleContactCompanyEmploymentCreateOrUpdate_NoRels() {
        CRMChannelResponse response = dependentEntityService.handleContactCompanyRelationshipCreateOrUpdate(getContactMsg_NoRels());
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == -1);
        assertTrue(response.getEntityType().name().equals(EntityType.CONTACT_COMPANY_REL.name()));

    }

    Message<CoreCompanyMessage> getCompanyMessage_NoRel() {
        CoreCompanyMessage msg = new CoreCompanyMessage();
        String domicile = "US";
        String status = "BANK";
        Entity entity = new Entity();
        entity.setEntityName("ABC Company");
        entity.setEntityType("O");
        entity.setEntityId(123);
        msg.setCompany(Company.newBuilder().setCompanyId("444")
                .setDescription("testDescription")
                .setModifiedBy("User")
                .setName("ABC Company").setDomicile(domicile).setStatus(status).build());
        msg.setOrgEntity(entity);
        msg.setUser("User");
        return MessageBuilder.withPayload(msg).setHeader("user", "userLogin").build();
    }

    Message<CoreContactMessage> getContactMsg_NoRels() {
        Contact crmContact = getContactCRM("FirstName", "LastName",
                "MiddleName", "Jr", "NickName", "Sir");
        ContactEmail email = ContactEmail.newBuilder().setEmail("test@gmail.com").setIsPrimary(true).build();
        ElectronicAddress ea = getEmailAddress("test@gmail.com", true);
        ElectronicAddressMessage emsg = new ElectronicAddressMessage();
        emsg.setElectronicAddress(ea);
        com.bfm.aap.pmdx.model.Contact pmdxContact =
                com.bfm.aap.pmdx.model.Contact.newBuilder()
                        .setFirstName("FirstName")
                        .setLastName("LastName")
                        .setMiddleName("MiddleName")
                        .setSuffix("Jr")
                        .setNickName("NickName")
                        .setSalutation("Sir")
                        .addEmailList(email)
                        .setContactId("CON123")
                        .setModifiedBy("USER123")
                        .setTitle("ANALYST")
                        .setPosition("TestPosition")
                        .build();
        CoreContactMessage coreContactMessage = new CoreContactMessage();
        crmContact.setEntityId(123);
        coreContactMessage.setCrmContact(crmContact);
        coreContactMessage.setPmdxContact(pmdxContact);
        coreContactMessage.setPrimaryEmail(emsg);
        coreContactMessage.setUser("User");

        return MessageBuilder.withPayload(coreContactMessage).setHeader("user", "userLogin").build();

    }

    Message<CoreContactMessage> getContactMsg() {
        Contact crmContact = getContactCRM("FirstName", "LastName",
                "MiddleName", "Jr", "NickName", "Sir");
        ContactEmail email = ContactEmail.newBuilder().setEmail("test@gmail.com").setIsPrimary(true).build();
        ElectronicAddress ea = getEmailAddress("test@gmail.com", true);
        ElectronicAddressMessage emsg = new ElectronicAddressMessage();
        emsg.setElectronicAddress(ea);
        com.bfm.aap.pmdx.model.Contact pmdxContact =
                com.bfm.aap.pmdx.model.Contact.newBuilder()
                        .setFirstName("FirstName")
                        .setLastName("LastName")
                        .setMiddleName("MiddleName")
                        .setSuffix("Jr")
                        .setNickName("NickName")
                        .setSalutation("Sir")
                        .addEmailList(email)
                        .setContactId("CON123")
                        .setModifiedBy("USER123")
                        .setCompanyId("C789")
                        .setTitle("ANALYST")
                        .setPosition("TestPosition")
                        .build();
        CoreContactMessage coreContactMessage = new CoreContactMessage();
        crmContact.setEntityId(123);
        coreContactMessage.setCrmContact(crmContact);
        coreContactMessage.setPmdxContact(pmdxContact);
        coreContactMessage.setPrimaryEmail(emsg);
        coreContactMessage.setUser("User");

        return MessageBuilder.withPayload(coreContactMessage).setHeader("user", "userLogin").build();

    }

    private Contact getContactCRM(String firstName, String lastName,
                                  String middleName, String suffix,
                                  String nickName, String saluatation) {
        Contact crmContact = new Contact();
        crmContact.setFirstName(firstName);
        crmContact.setLastName(lastName);
        crmContact.setMiddleName(middleName);
        crmContact.setSuffix(suffix);
        crmContact.setNickName(nickName);
        crmContact.setSalutation(saluatation);
        return crmContact;
    }

    private Relationship getRelationship(Integer firstEntityId, Integer secondEntityId,
                                         String categoryCode, String subCategoryCode,
                                         BFMDate startDate, BFMDate endDate, boolean primaryOrg) {
        Relationship relationship = new Relationship();
        relationship.setFirstEntityId(firstEntityId);
        relationship.setSecondEntityId(secondEntityId);
        relationship.setStartDate(startDate);
        relationship.setEndDate(endDate);
        relationship.setPrimaryOrg(primaryOrg);
        relationship.setCategory(getDecode(EntityMasterDecodeTableConstants.DX_EM_ORGANIZATION_SUB_TYPE, categoryCode));
        relationship.setSubCategory(getDecode(EntityMasterDecodeTableConstants.DX_EM_ORGANIZATION_TYPE, subCategoryCode));
        return relationship;
    }

    private Employment getEmployment(Integer employerEntityId, Integer employeeEntityId, BFMDate startDate, BFMDate endDate, boolean primaryOrg,
                                     String title) {
        Employment employment = new Employment();
        employment.setEmployerEntityId(employerEntityId);
        employment.setEmployeeEntityId(employeeEntityId);
        employment.setStartDate(startDate);
        employment.setEndDate(endDate);
        employment.setPrimaryOrg(primaryOrg);
        employment.setTitle(title);
        return employment;
    }

    private Note getNote(Integer entityId, String note, String type) {
        Note note1 = new Note();
        note1.setEntityId(entityId);
        note1.setTitle("Company Description");
        note1.setNote(note);
        note1.setType(getDecode(type, "Alts Sales Plan-BAA"));
        return note1;
    }

    private Message<CoreInvestorMessage> getInvestorMsg() {
        com.bfm.aap.pmdx.model.Address address = com.bfm.aap.pmdx.model.Address.newBuilder().setId("123").setStreet1("Street1").setStreet2("street2").setIsPrimary(true)
                .setState("WA").setAddressType("Home").setCity("Seattle").setCountry("USA").setZipCode("98101").build();
        CoreInvestorMessage msg = new CoreInvestorMessage();
        Entity entity = new Entity();
        entity.setEntityName("ABC Company");
        entity.setEntityType("O");
        entity.setEntityId(123);
        String status = "BANK";
        String domicile = "US";
        Legal legal = Legal.newBuilder().setLegalDomicileCountry(domicile).build();
        Investor investor = Investor.newBuilder().setName("ABC Company").setShortCode("ABC").setInvestorType(status)
                .setLegal(legal).setDescription("TestDescription").setCompanyId("ABC").addOfficeAddressList(address).build();
        msg.setOrgEntity(entity);
        msg.setInvestor(investor);
        return MessageBuilder.withPayload(msg).setHeader("user", "userLogin").build();
    }

    private Message<CoreCompanyMessage> getCompanyMsg() {
        CoreCompanyMessage msg = new CoreCompanyMessage();
        String domicile = "US";
        String status = "BANK";
        Entity entity = new Entity();
        entity.setEntityName("ABC Company");
        entity.setEntityType("O");
        entity.setEntityId(123);
        msg.setCompany(Company.newBuilder().setCompanyId("444")
                .setDescription("testDescription")
                .setMainContactId("C345")
                .setParentCompanyId("P678")
                .setSubsidiaryOfId("S989")
                .setModifiedBy("User")
                .setName("ABC Company").setDomicile(domicile).setStatus(status).build());
        msg.setOrgEntity(entity);
        msg.setUser("User");
        return MessageBuilder.withPayload(msg).setHeader("user", "userLogin").build();
    }

    private Message<AliasMessage> getAliasMessage(int linkedEntityId, Alias a) {
        AliasMessage a1 = new AliasMessage();
        a1.setAlias(a);
        a1.setLinkedCRMEntityId(linkedEntityId);
        return MessageBuilder.withPayload(a1).setHeader("user", "userLogin").build();
    }

    private Alias getAlias(String name, String type) {
        Alias alias = new Alias();
        alias.setAliasName(name);
        alias.setAliasType(getDecode(type, type));
        return alias;
    }

    private Message<AddressMessage> getAddressMessage_NullAddress() {
        AddressMessage msg = new AddressMessage();
        msg.setLinkedCRMEntityId(321);
        msg.setPmdxAddress(null);
        msg.setCrmAddress(null);
        return MessageBuilder.withPayload(msg).build();
    }

    private Message<AddressMessage> getAddressMessage(String street1, String street2, String street3,
                                                      String city, String state, String zipCode, String addressType, String country, boolean isPrimary) {
        com.bfm.aap.pmdx.model.Address address = com.bfm.aap.pmdx.model.Address.newBuilder().setId("123").setStreet1(street1)
                .setStreet2(street2).setIsPrimary(isPrimary)
                .setState(state).setAddressType(addressType).setCity(city).setCountry(country).setZipCode(zipCode).build();

        AddressMessage msg = new AddressMessage();
        msg.setLinkedCRMEntityId(321);
        msg.setPmdxAddress(address);
        msg.setCrmAddress(getTransformedAddress
                (street1, street2, street3, city, state, zipCode, addressType, country, isPrimary));
        return MessageBuilder.withPayload(msg).setHeader("user", "userLogin").build();
    }

    private Address getTransformedAddress(String street1, String street2, String street3, String city, String state,
                                          String zipCode, String addressType, String country, boolean isPrimary) {
        Address address = new Address();

        address.setCountry(country);
        address.setAddress3(street3);
        address.setAddressTitle(addressType);
        address.setAddress2(street2);
        address.setCity(city);
        address.setAddress1(street1);
        address.setPostalCode(zipCode);
        address.setState(state);
        address.setPrimary(isPrimary);
        Decode countryDecode = new Decode();
        countryDecode.setCode("US");
        countryDecode.setDecode("US");
        address.setCountryDecode(countryDecode);

        return address;
    }

    private ElectronicAddress getEmailAddress(String email, boolean isPrimary) {
        ElectronicAddress electronicAddress = new ElectronicAddress();
        electronicAddress.setAddress(email);
        electronicAddress.setPrimary(isPrimary);
        electronicAddress.setElectronicType(getDecode("EMAIL", "Email"));
        electronicAddress.setElectronicSubType(getDecode("PROFESSIONAL", "Professional"));
        return electronicAddress;
    }

    private Decode getDecode(String code, String decode) {
        Decode d = new Decode();
        d.setCode(code);
        d.setDecode(decode);
        return d;
    }
}