package com.bfm.aap.privatemarkets.crm.loader.integration.service;

import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.privatemarkets.crm.loader.mapper.AddressInverseTransformer;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreCompanyInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorInverseMessage;
import com.bfm.entitymaster.dto.common.Address;
import com.bfm.entitymaster.dto.organization.OrganizationDetail;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doReturn;

@RunWith(MockitoJUnitRunner.class)
public class AddressInverseServiceTest {

    @InjectMocks
    private AddressInverseService addressInverseService;
    @Mock
    private OrganizationDetail organizationDetail;
    @Mock
    private AddressInverseTransformer addressInverseTransformer;

    @Test
    public void translateToEfrontAddress_Company() {
        CoreCompanyInverseMessage coreCompanyInverseMessage = new CoreCompanyInverseMessage();
        coreCompanyInverseMessage.setEfrontEntity(Company.newBuilder().build());
        coreCompanyInverseMessage.setOrganization(organizationDetail);
        Address address = new Address(12, "test", "test", "test", "test",
            "test", "test", "test", "test", "test", "test", "test",
            false, false, false, BigDecimal.ZERO, BigDecimal.ZERO);
        doReturn(address).when(organizationDetail).getPrimaryAddress();
        doReturn(com.bfm.aap.pmdx.model.Address.newBuilder().setCity("test").build()).when(addressInverseTransformer).crmToEfrontTransform(address);
        coreCompanyInverseMessage = addressInverseService.translateToEfrontAddress(coreCompanyInverseMessage);
        assertTrue(coreCompanyInverseMessage.getEfrontEntity().getOfficeAddressList(0).getCity().equals("test"));
    }

    @Test
    public void translateToEfrontAddress_Investor() {
        CoreInvestorInverseMessage coreInvestorInverseMessage = new CoreInvestorInverseMessage();
        coreInvestorInverseMessage.setEfrontEntity(Investor.newBuilder().build());
        coreInvestorInverseMessage.setOrganization(organizationDetail);
        Address address = new Address(12, "test", "test", "test", "test",
            "test", "test", "test", "test", "test", "test", "test",
            false, false, false, BigDecimal.ZERO, BigDecimal.ZERO);
        doReturn(address).when(organizationDetail).getPrimaryAddress();
        doReturn(com.bfm.aap.pmdx.model.Address.newBuilder().setCity("test").build()).when(addressInverseTransformer).crmToEfrontTransform(address);
        coreInvestorInverseMessage = addressInverseService.translateToEfrontAddress(coreInvestorInverseMessage);
        assertTrue(coreInvestorInverseMessage.getEfrontEntity().getOfficeAddressList(0).getCity().equals("test"));
    }

    @Test
    public void testDefaultConstructor() {
        AddressInverseService addressInverseService = new AddressInverseService();
        assertNotNull(addressInverseService);
    }

}
