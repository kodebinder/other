package com.bfm.aap.privatemarkets.crm.loader.integration.service.impl;

import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.Legal;
import com.bfm.aap.privatemarkets.crm.loader.mapper.EntityTransformer;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorMessage;
import com.bfm.aap.privatemarkets.crm.loader.util.DecodeHelper;
import com.bfm.aap.privatemarkets.common.crm.util.EntityMasterDecodeTableConstants;
import com.bfm.entitymaster.dto.common.Decode;
import com.bfm.entitymaster.dto.common.Entity;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.io.IOException;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({DecodeHelper.class})
public class CoreInvestorTransformerServiceImplTest {

    @InjectMocks
    private CoreInvestorTransformerServiceImpl coreInvestorTransformerService;
    @Mock
    EntityTransformer entityTransformer;

    @Before
    public void initMocks() throws IOException {
        PowerMockito.mockStatic(DecodeHelper.class);
        PowerMockito.when(DecodeHelper.getDecode(EntityMasterDecodeTableConstants.COUNTRIES,"US"))
                .thenReturn( getDecode("US","United States"));
        PowerMockito.when(DecodeHelper.getDecode(EntityMasterDecodeTableConstants.DX_EM_ORGANIZATION_TYPE, "BANK"))
                .thenReturn( getDecode("BANK","Bank"));
        PowerMockito.when(DecodeHelper.getDecode(EntityMasterDecodeTableConstants.DX_EM_ORGANIZATION_SUB_TYPE, "UNKNOWN0"))
                .thenReturn( getDecode("UNKNOWN0","-"));
    }
    private Decode getDecode(String code, String decode) {
        Decode d = new Decode();
        d.setCode(code);
        d.setDecode(decode);
        return d;
    }

    @Test
    public void transform_Test() throws Exception {
        Entity entity = new Entity();
        entity.setEntityName("ABC Company");
        entity.setEntityType("O");
        when(entityTransformer.eFrontToCRMTransform(anyString(),anyString())).thenReturn(entity);
        CoreInvestorMessage msg = coreInvestorTransformerService.transform(getInvestorObject());
        assertTrue(msg.getOrgEntity().getEntityName().equals(entity.getEntityName()));
        assertTrue(msg.getOrgEntity().getEntityType().equals(entity.getEntityType()));
        assertTrue(msg.getOrganizationType().getOrganizationType().equals(getDecode( "BANK","Bank")));
    }
    @Test
    public void transform_Test_MissingStatus() throws Exception {
        Entity entity = new Entity();
        entity.setEntityName("ABC Company");
        entity.setEntityType("O");
        when(entityTransformer.eFrontToCRMTransform(anyString(),anyString())).thenReturn(entity);
        CoreInvestorMessage msg = coreInvestorTransformerService.transform(getInvestorObject_NoStatus());
        assertTrue(msg.getOrgEntity().getEntityName().equals(entity.getEntityName()));
        assertTrue(msg.getOrgEntity().getEntityType().equals(entity.getEntityType()));
        assertTrue(null==msg.getOrganizationType().getOrganizationType());
    }

    @Test
    public void transform_Test_No_Domicile() throws Exception {
        Entity entity = new Entity();
        entity.setEntityName("ABC Company");
        entity.setEntityType("O");
        when(entityTransformer.eFrontToCRMTransform(anyString(),anyString())).thenReturn(entity);
        CoreInvestorMessage msg = coreInvestorTransformerService.transform(getInvestorObject_No_Domicile());
        assertTrue(msg.getOrgEntity().getEntityName().equals(entity.getEntityName()));
        assertTrue(msg.getOrgEntity().getEntityType().equals(entity.getEntityType()));
        assertTrue(msg.getOrganizationType().getOrganizationType().equals(getDecode( "BANK","Bank")));
    }

    public Investor getInvestorObject(){
        String status = "BANK";
        String domicile = "US";
        Legal legal = Legal.newBuilder().setLegalDomicileCountry(domicile).build();
        return Investor.newBuilder().setName("ABC Company").setInvestorType(status).setLegal(legal).setCompanyId("ABC").build();
    }
    public Investor getInvestorObject_NoStatus(){
        String domicile = "US";
        Legal legal = Legal.newBuilder().setLegalDomicileCountry(domicile).build();
        return Investor.newBuilder().setName("ABC Company").setCompanyId("ABC").setLegal(legal).build();
    }
    public Investor getInvestorObject_No_Domicile(){
        String status = "BANK";
        return Investor.newBuilder().setName("ABC Company").setInvestorType(status).setCompanyId("ABC").build();
    }
}