package com.bfm.aap.privatemarkets.crm.loader.integration.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.privatemarkets.crm.loader.mapper.ContactInverseTransformer;
import com.bfm.aap.privatemarkets.crm.loader.mapper.EmailInverseTransformer;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreContactInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.util.ElectronicAddressConstants;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.entitymaster.dto.common.Decode;
import com.bfm.entitymaster.dto.common.ElectronicAddress;
import com.bfm.entitymaster.dto.contact.ContactDetail;
import com.bfm.entitymaster.dto.entityrelationship.Employment;

import static org.mockito.ArgumentMatchers.any;

@RunWith(MockitoJUnitRunner.class)
public class CoreContactInverseTransformerServiceImplTest {

    @Mock
    ContactInverseTransformer contactTransformer;
    @Mock
    EmailInverseTransformer emailInverseTransformer;
    @Mock
    CoreContactInverseMessage coreContactInverseMessage;
    @Mock
    private CRMThirdPartyMapperService crmThirdPartyMapperService;
    @InjectMocks
    ContactDetail contactDetail = createContactDetail();
    @InjectMocks
    private CoreContactInverseTransformerServiceImpl coreContactInverseTransformerServiceImpl = new CoreContactInverseTransformerServiceImpl();

    @BeforeClass
    public static void setUpBeforeClass() {
        System.setProperty("mode", "blue");
    }

    private ContactDetail createContactDetail() {
        ContactDetail contactDetail = new ContactDetail();
        contactDetail.setElectronicAddressList(createElectronicAddressList());
        return contactDetail;
    }

    @Test
    public void testTransform() throws Exception {
        Mockito.when(coreContactInverseMessage.getCrmEntity()).thenReturn(contactDetail);
        Mockito.when(contactTransformer.crmToEfrontTransformer(any())).thenReturn(Contact.newBuilder().build());
        Mockito.when(coreContactInverseMessage.getEmployer()).thenReturn(createEmployers());
        CoreContactInverseMessage msg = coreContactInverseTransformerServiceImpl.transform(coreContactInverseMessage);
        Assert.assertNotNull(msg);
    }

    @Test
    public void testTransform_without_company_relationship() throws Exception {
        Mockito.when(coreContactInverseMessage.getCrmEntity()).thenReturn(contactDetail);
        Mockito.when(contactTransformer.crmToEfrontTransformer(any())).thenReturn(Contact.newBuilder().build());
        CoreContactInverseMessage msg = coreContactInverseTransformerServiceImpl.transform(coreContactInverseMessage);
        Assert.assertNotNull(msg);
    }

    private List<Employment> createEmployers() {
        List<Employment> employers = new ArrayList<>();
        Employment employment = new Employment();
        employment.setEmployeeEntityId(123);
        employers.add(employment);
        return employers;
    }

    private List<ElectronicAddress> createElectronicAddressList() {
        List<com.bfm.entitymaster.dto.common.ElectronicAddress> electronicAddresses = new ArrayList<>();
        com.bfm.entitymaster.dto.common.ElectronicAddress facebook = new com.bfm.entitymaster.dto.common.ElectronicAddress();
        facebook.setAddress("test@facebook.com");
        Decode facebookTypeDecode = new Decode();
        facebookTypeDecode.setCode(ElectronicAddressConstants.WEB);
        Decode facebookSubTypeDecode = new Decode();
        facebookSubTypeDecode.setCode(ElectronicAddressConstants.FACEBOOK);
        facebook.setElectronicType(facebookTypeDecode);
        facebook.setElectronicSubType(facebookSubTypeDecode);
        electronicAddresses.add(facebook);

        com.bfm.entitymaster.dto.common.ElectronicAddress twitter = new com.bfm.entitymaster.dto.common.ElectronicAddress();
        twitter.setAddress("test@twitter.com");
        Decode twitterTypeDecode = new Decode();
        twitterTypeDecode.setCode(ElectronicAddressConstants.WEB);
        Decode twitterSubTypeDecode = new Decode();
        twitterSubTypeDecode.setCode(ElectronicAddressConstants.TWITTER);
        twitter.setElectronicType(twitterTypeDecode);
        twitter.setElectronicSubType(twitterSubTypeDecode);
        electronicAddresses.add(twitter);

        com.bfm.entitymaster.dto.common.ElectronicAddress linkedin = new com.bfm.entitymaster.dto.common.ElectronicAddress();
        linkedin.setAddress("test@linkedin.com");
        Decode linkedinTypeDecode = new Decode();
        linkedinTypeDecode.setCode(ElectronicAddressConstants.WEB);
        Decode linkedinSubTypeDecode = new Decode();
        linkedinSubTypeDecode.setCode(ElectronicAddressConstants.LINKEDIN);
        linkedin.setElectronicType(linkedinTypeDecode);
        linkedin.setElectronicSubType(linkedinSubTypeDecode);
        electronicAddresses.add(linkedin);

        com.bfm.entitymaster.dto.common.ElectronicAddress other = new com.bfm.entitymaster.dto.common.ElectronicAddress();
        other.setAddress("test@skype.com");
        Decode otherTypeDecode = new Decode();
        otherTypeDecode.setCode(ElectronicAddressConstants.WEB);
        Decode otherSubTypeDecode = new Decode();
        otherSubTypeDecode.setCode(ElectronicAddressConstants.OTHER);
        other.setElectronicType(otherTypeDecode);
        other.setElectronicSubType(otherSubTypeDecode);
        electronicAddresses.add(other);

        com.bfm.entitymaster.dto.common.ElectronicAddress defaultElectronicAddress = new com.bfm.entitymaster.dto.common.ElectronicAddress();
        defaultElectronicAddress.setAddress("test@other.com");
        Decode defaultTypeDecode = new Decode();
        defaultTypeDecode.setCode(ElectronicAddressConstants.WEB);
        Decode defaultSubTypeDecode = new Decode();
        defaultSubTypeDecode.setCode("");
        defaultElectronicAddress.setElectronicType(defaultTypeDecode);
        defaultElectronicAddress.setElectronicSubType(defaultSubTypeDecode);
        electronicAddresses.add(defaultElectronicAddress);

        com.bfm.entitymaster.dto.common.ElectronicAddress defaultElectronicAddress1 = new com.bfm.entitymaster.dto.common.ElectronicAddress();
        defaultElectronicAddress1.setAddress("test@other.com");
        Decode defaultTypeDecode1 = new Decode();
        defaultTypeDecode1.setCode("");
        defaultElectronicAddress1.setElectronicType(defaultTypeDecode1);
        electronicAddresses.add(defaultElectronicAddress1);

        return electronicAddresses;
    }
}