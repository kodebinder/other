package com.bfm.aap.privatemarkets.crm.loader.integration.service;

import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorInverseMessage;
import com.bfm.entitymaster.dto.common.Decode;
import com.bfm.entitymaster.dto.note.Note;
import com.bfm.util.BFMDate;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class NotesInverseServiceTest {

    private static final String COMPANY_DESCRIPTION = "Company Description";
    private static final String ORG_DESCRIPTION = "ORG_BUS_OVERVW";

    @InjectMocks
    private NotesInverseService notesInverseService;

    @Test
    public void testTranslateToEfrontNotes(){
        CoreInvestorInverseMessage coreInvestorInverseMessage = new CoreInvestorInverseMessage();
        coreInvestorInverseMessage.setNotes(createNotes());
        coreInvestorInverseMessage.setEfrontEntity(Investor.newBuilder().build());
        coreInvestorInverseMessage = notesInverseService.translateToEfrontNotes(coreInvestorInverseMessage);
        assertEquals(coreInvestorInverseMessage.getEfrontEntity().getDescription(),"Testing2");
    }

    private List<Note> createNotes(){
        List<Note> notes= new ArrayList<>();
        Note note = new Note(123,"Testing1",23,
                new Decode("test","test",123),"test",false,
                true,false,new BFMDate(),"user1");

        Note note1 = new Note(123,"Testing2",23,
                new Decode(ORG_DESCRIPTION,"test",123),COMPANY_DESCRIPTION,false,
                true,false,new BFMDate(),"user1");
        notes.add(note);
        notes.add(note1);
        return notes;
    }
}
