package com.bfm.aap.privatemarkets.crm.loader.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.powermock.reflect.Whitebox;

import com.bfm.aap.pmdx.model.CompanyResponse;
import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.proto.util.ProtoJsonHelper;
import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMResponseStatusEnum;
import com.bfm.aap.privatemarkets.crm.loader.integration.gateway.CompanyInverseProcessingGateway;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreCompanyInverseMessage;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@MockitoSettings(strictness = Strictness.LENIENT)
@ExtendWith({MockitoExtension.class})
public class ProcessCompanyNotificationTest {

	@Spy
	@InjectMocks
	private ProcessCompanyNotification processCompanyNotification;

	@Mock
	private CompanyInverseProcessingGateway companyInverseProcessingGateway;

	@Mock
	private CRMThirdPartyMapperService crmThirdPartyMapperService;

	@Test
	public void testProcess_success() throws Exception {
		String user = RandomStringUtils.randomAlphabetic(5);
		CRMLoaderResponse loaderResponse = CRMLoaderResponse.newBuilder()
			.setStatus(CRMResponseStatusEnum.FULL_SUCCESS)
			.setMessage(ProtoJsonHelper.convertToJson(Contact.newBuilder().setContactId("123").build()))
			.build();

		when(companyInverseProcessingGateway.processMapEfrontCompany(any(CoreCompanyInverseMessage.class))).thenReturn(loaderResponse);

		processCompanyNotification.process(1234, user);

		verify(companyInverseProcessingGateway).processMapEfrontCompany(any(CoreCompanyInverseMessage.class));
	}

	@Test()
	public void testProcess_failure() {
		String user = RandomStringUtils.randomAlphabetic(5);
		Exception error = new Exception("Error processing");
		CRMLoaderResponse loaderResponse = CRMLoaderResponse.newBuilder()
			.setStatus(CRMResponseStatusEnum.ERROR)
			.setMessage(error.getMessage())
			.build();

		when(companyInverseProcessingGateway.processMapEfrontCompany(any(CoreCompanyInverseMessage.class))).thenReturn(loaderResponse);

		try {
			processCompanyNotification.process(1234, user);
		} catch (Exception ex) {
			assertEquals(ex.getMessage(), error.getMessage());
		}
		verify(companyInverseProcessingGateway).processMapEfrontCompany(any(CoreCompanyInverseMessage.class));
	}

	@Test
	public void testGetCompanyResponseFutures() throws Exception {
		List<String> eFrontId = Arrays.asList("ABC12","345GD56");
		Whitebox.setInternalState(processCompanyNotification, "processNotificationExecutorService", Executors.newFixedThreadPool(5 ));

		assertNotNull(processCompanyNotification.getCompanyResponseFutures(eFrontId));

	}

	@Test
	public void testGetCompanyResponseFutures_withoout_crmmapping() throws Exception {
		List<String> eFrontId = Arrays.asList("ABC12","345GD56");

		Whitebox.setInternalState(processCompanyNotification, "processNotificationExecutorService", Executors.newFixedThreadPool(5 ));
		doReturn(-1).when(crmThirdPartyMapperService).lookUp(anyString(), any(ThirdPartyMappingEnum.class));

		assertNotNull(processCompanyNotification.getCompanyResponseFutures(eFrontId));
	}

	@Test
	public void testGetCompanyResponseFutures_throws_excption() throws Exception {
		List<String> eFrontId = Arrays.asList("ABC12","345GD56");

		Whitebox.setInternalState(processCompanyNotification, "processNotificationExecutorService", Executors.newFixedThreadPool(5 ));

		assertNotNull(processCompanyNotification.getCompanyResponseFutures(eFrontId));
	}

	@Test
	public void testGetCompanyResponsesFromFutures(){
		Future<CompanyResponse.Builder> companyResponseBuilderFuture = CompletableFuture.completedFuture(CompanyResponse.newBuilder());
		List<Future<CompanyResponse.Builder>> companyResponseBuilderFutures = new ArrayList<>();
		companyResponseBuilderFutures.add(companyResponseBuilderFuture);

		assertNotNull(processCompanyNotification.getCompanyResponsesFromFutures(companyResponseBuilderFutures));
	}

	@Test
	public void testGetCompanyResponsesFromFutures_throw_exception(){
		Future<CompanyResponse.Builder> companyResponseBuilderFuture = CompletableFuture.completedFuture(CompanyResponse.newBuilder());
		List<Future<CompanyResponse.Builder>> companyResponseBuilderFutures = new ArrayList<>();
		companyResponseBuilderFutures.add(companyResponseBuilderFuture);

		assertNotNull(processCompanyNotification.getCompanyResponsesFromFutures(companyResponseBuilderFutures));
	}
}