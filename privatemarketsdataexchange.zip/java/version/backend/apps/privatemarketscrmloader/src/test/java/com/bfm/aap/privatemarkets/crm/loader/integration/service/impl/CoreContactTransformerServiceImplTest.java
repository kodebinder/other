package com.bfm.aap.privatemarkets.crm.loader.integration.service.impl;

import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.ContactEmail;
import com.bfm.aap.pmdx.model.util.SchemaEnum;
import com.bfm.aap.privatemarkets.crm.loader.mapper.ContactTransformer;
import com.bfm.aap.privatemarkets.crm.loader.mapper.EmailTransformer;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreContactMessage;
import com.bfm.entitymaster.dto.common.Decode;
import com.bfm.entitymaster.dto.common.ElectronicAddress;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CoreContactTransformerServiceImplTest {
    @InjectMocks
    private CoreContactTransformerServiceImpl coreContactTransformerServiceImpl;
    @Mock
    ContactTransformer contactTransformer;
    @Mock
    EmailTransformer emailTransformer;

    @Test
    public void transform_Valid_Data_Test() throws Exception {
        com.bfm.aap.pmdx.model.Contact pmdxContact = getContactWithValidData();
        ElectronicAddress electronicAddress = getEmailAddress("test@gmail.com", true);
        when(emailTransformer.eFrontToCRMTransform(any(ContactEmail.class), any(SchemaEnum.class))).thenReturn(electronicAddress);
        when(contactTransformer.eFrontToCRMTransform(any(Contact.class),any(SchemaEnum.class))).
                thenReturn(getCRMContact("FirstName", "LastName", "NickName", "MiddleName", "Sir", "Jr"));
        CoreContactMessage msg = coreContactTransformerServiceImpl.transform(pmdxContact);
        assertTrue(msg.getCrmContact().getFirstName().equals("FirstName"));
    }

    @Test
    public void transform_Valid_Missing_Email() throws Exception {
        com.bfm.aap.pmdx.model.Contact pmdxContact = getContactWithoutEmail();
        when(contactTransformer.eFrontToCRMTransform(any(Contact.class), any(SchemaEnum.class))).
                thenReturn(getCRMContact("FirstName", "LastName", "NickName", "MiddleName", "Sir", "Jr"));
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            coreContactTransformerServiceImpl.transform(pmdxContact);
        });
        String expectedMessage = "Primary Email is mandatory for contact creation";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    private ElectronicAddress getEmailAddress(String email, boolean isPrimary) {
        ElectronicAddress electronicAddress = new ElectronicAddress();
        electronicAddress.setAddress(email);
        electronicAddress.setPrimary(isPrimary);
        electronicAddress.setElectronicType(getDecode("EMAIL", "Email"));
        electronicAddress.setElectronicSubType(getDecode("PROFESSIONAL", "Professional"));
        return electronicAddress;
    }

    private com.bfm.entitymaster.dto.contact.Contact getCRMContact(String firstName, String lastName, String nickName, String middleName, String saluatation, String suffix) {
        com.bfm.entitymaster.dto.contact.Contact contact = new com.bfm.entitymaster.dto.contact.Contact();
        contact.setFirstName(firstName);
        contact.setLastName(lastName);
        contact.setNickName(nickName);
        contact.setMiddleName(middleName);
        contact.setPrefix(getDecode(saluatation,saluatation));
        contact.setSuffix(suffix);
        return contact;
    }


    com.bfm.aap.pmdx.model.Contact getContactWithoutEmail() {
        ContactEmail email = ContactEmail.newBuilder().setEmail("test@gmail.com").setIsPrimary(true).build();
        com.bfm.aap.pmdx.model.Contact pmdxContact =
                com.bfm.aap.pmdx.model.Contact.newBuilder()
                        .setFirstName("FirstName")
                        .setLastName("LastName")
                        .setMiddleName("MiddleName")
                        .setSuffix("Jr")
                        .setNickName("NickName")
                        .setSalutation("Sir")
                        .build();
        return pmdxContact;

    }

    com.bfm.aap.pmdx.model.Contact getContactWithValidData() {
        ContactEmail email = ContactEmail.newBuilder().setEmail("test@gmail.com").setIsPrimary(true).build();
        com.bfm.aap.pmdx.model.Contact pmdxContact =
                com.bfm.aap.pmdx.model.Contact.newBuilder()
                        .setFirstName("FirstName")
                        .setLastName("LastName")
                        .setMiddleName("MiddleName")
                        .setSuffix("Jr")
                        .setNickName("NickName")
                        .setSalutation("Sir")
                        .addEmailList(email).setTwitter("@test").build();
        return pmdxContact;

    }

    private Decode getDecode(String code, String decode) {
        Decode d = new Decode();
        d.setCode(code);
        d.setDecode(decode);
        return d;
    }
}