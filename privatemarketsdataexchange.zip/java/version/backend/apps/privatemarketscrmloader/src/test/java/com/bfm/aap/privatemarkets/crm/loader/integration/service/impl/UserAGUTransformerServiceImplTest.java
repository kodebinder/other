package com.bfm.aap.privatemarkets.crm.loader.integration.service.impl;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bfm.aap.pmdx.model.User;
import com.bfm.aap.privatemarkets.crm.loader.mapper.UserTransformer;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreUserMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.UserCRM;

@RunWith(PowerMockRunner.class)
public class UserAGUTransformerServiceImplTest {

    @InjectMocks
    private UserAGUTransformerServiceImpl userAGUTransformerService;
    @Mock
    private UserTransformer userTransformer;

    @Test
    public void transform_Test() throws Exception {
        UserCRM userCRM = new UserCRM();
        userCRM.seteFrontId("68C6CB6667474A46AFE8252EB760611T");
        userCRM.setUserEmail("himanshu.thakkar@blackrock.com");
        userCRM.seteFrontUserId("68C6CB6667474A46AFE8252EB760611T");
        when(userTransformer.eFrontToCRMTransform(any())).thenReturn(userCRM);
        CoreUserMessage msg = userAGUTransformerService.transform(getUserObject());
        assertTrue(msg.getUserCRM().geteFrontId().equals(userCRM.geteFrontId()));
        assertTrue(msg.getUserCRM().getUserEmail().equals(userCRM.getUserEmail()));
        assertTrue(msg.getUserCRM().geteFrontUserId().equals(userCRM.geteFrontUserId()));
    }
    
    private User getUserObject() {
		String userId = "68C6CB6667474A46AFE8252EB760611T";
		String email = "himanshu.thakkar@blackrock.com";
		String identifier = "68C6CB6667474A46AFE8252EB760611T";
		return User.newBuilder().setEmail(email).setIdentifier(identifier).setUserId(userId).build();
	}

}