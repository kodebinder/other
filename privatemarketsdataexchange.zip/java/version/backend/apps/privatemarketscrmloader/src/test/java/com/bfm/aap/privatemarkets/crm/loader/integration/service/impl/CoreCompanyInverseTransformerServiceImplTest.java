package com.bfm.aap.privatemarkets.crm.loader.integration.service.impl;

import com.bfm.aap.privatemarkets.crm.loader.model.CoreCompanyInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.util.DecodeHelper;
import com.bfm.aap.privatemarkets.common.crm.model.CRMCoreEntityTypes;
import com.bfm.aap.privatemarkets.common.crm.util.EntityMasterDecodeTableConstants;
import com.bfm.aap.privatemarkets.crm.loader.integration.service.PermRegionService;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.entitymaster.dto.common.Decode;
import com.bfm.entitymaster.dto.common.ElectronicAddress;
import com.bfm.entitymaster.dto.common.Entity;
import com.bfm.entitymaster.dto.entitythirdparty.ThirdPartyMapping;
import com.bfm.entitymaster.dto.entitythirdparty.ThirdPartySource;
import com.bfm.entitymaster.dto.organization.OrganizationDetail;
import com.bfm.entitymaster.dto.organization.OrganizationType;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.ArrayList;
import java.util.List;

import static com.bfm.aap.privatemarkets.crm.loader.util.DecodeHelper.getDecode;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({DecodeHelper.class})
public class CoreCompanyInverseTransformerServiceImplTest {

    @InjectMocks
    private CoreCompanyInverseTransformerServiceImpl coreCompanyInverseTransformerService;
    @Mock
    private CRMThirdPartyMapperService crmThirdPartyMapperService;
    @Mock
    private ThirdPartySource thirdPartySource;
    @Mock
    private ThirdPartyMapping thirdPartyMapping;
    @Mock
    private OrganizationDetail organizationDetail;
    @Mock
    private Entity entity;
    @Mock
    private OrganizationType organizationType;
    @Mock
    private PermRegionService permRegionService;

    @BeforeClass
    public static void setUpBeforeClass() {
        System.setProperty("mode", "blue");
    }

    @Before
    public void initMocks() {
        PowerMockito.mockStatic(DecodeHelper.class);
        PowerMockito.when(getDecode(EntityMasterDecodeTableConstants.EM_INV_ORGANIZATION_TYPE, "US"))
            .thenReturn(new Decode("test", "testing", 1923));
        PowerMockito.when(getDecode(EntityMasterDecodeTableConstants.COUNTRIES, "US"))
            .thenReturn(new Decode("United States", "United", 786));
        PowerMockito.when(permRegionService.getRegionByEntityIdAndType(anyInt(),any(CRMCoreEntityTypes.class))).thenReturn("1234");
    }

    @Test
    public void testTransform() throws Exception {
        when(organizationDetail.getMasterOrganization()).thenReturn(entity);
        when(entity.getEntityId()).thenReturn(23);
        when(crmThirdPartyMapperService.lookupThirdPartMapping(anyInt(), any(ThirdPartyMappingEnum.class))).thenReturn(thirdPartyMapping);
        when(thirdPartyMapping.getThirdPartySource()).thenReturn(thirdPartySource);
        when(thirdPartySource.getThirdPartySourceId()).thenReturn(123);
        when(thirdPartyMapping.getThirdPartyIdentifier()).thenReturn("ABS123");
        when(organizationDetail.getOrganization()).thenReturn(entity);
        when(entity.getEntityName()).thenReturn("companyTest");
        when(organizationDetail.getOrganizationType()).thenReturn(organizationType);
        when(organizationType.getOrganizationType()).thenReturn(new Decode("US", "United States", 786));
        when(organizationDetail.getDomicile()).thenReturn("US");
        when(crmThirdPartyMapperService.getLoginByEntityId(anyInt())).thenReturn("tsgops");
        CoreCompanyInverseMessage coreCompanyInverseMessage = new CoreCompanyInverseMessage();
        coreCompanyInverseMessage.setOrganization(organizationDetail);
        coreCompanyInverseMessage.setElectronicAddresses(createElectronicAddress());
        coreCompanyInverseMessage.setCrmCompanyId(1234);
        coreCompanyInverseMessage.setModifiedByCRMUserLogin("tsgops");
        coreCompanyInverseMessage.setModifiedByCRMUserEntityId(7321343);
        CoreCompanyInverseMessage message = coreCompanyInverseTransformerService.transform(coreCompanyInverseMessage);
        assertTrue(message.getEfrontEntity().getTwitter().equals("test"));
    }

    private List<ElectronicAddress> createElectronicAddress() {
        List<ElectronicAddress> electronicAddresses = new ArrayList<>();
        ElectronicAddress electronicAddress1 = new ElectronicAddress(2,new Decode("WEB","test",8),
                new Decode("WWWLINKEDIN","test",9),"test",false);
        ElectronicAddress electronicAddress2 = new ElectronicAddress(2,new Decode("WEB","test",8),
                new Decode("WWWTWITTER","test",10),"test",false);
        electronicAddresses.add(electronicAddress1);
        electronicAddresses.add(electronicAddress2);
        return electronicAddresses;
    }
}

