package com.bfm.aap.privatemarkets.crm.loader.integration.releasestrategy;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.bfm.aap.privatemarkets.common.crm.model.CRMChannelResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMChannelResponseList;
import com.bfm.aap.privatemarkets.common.crm.model.EntityType;

import java.util.Arrays;

import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ReleaseStrategyServiceTest {
    @InjectMocks
    private ReleaseStrategyService releaseStrategyService;

    @Test
    public void checkInvestorCompletionTest(){
        CRMChannelResponse e1 = createCRMChannelResponse(321, 444, EntityType.EMAIL, true);
        CRMChannelResponseList emList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{e1})).build();
        CRMChannelResponseList emList2 = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{e1})).build();
        CRMChannelResponseList emList3 = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{e1})).build();
        CRMChannelResponseList emList4 = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{e1})).build();
        assertTrue(releaseStrategyService.checkInvestorCompletion(Arrays.asList(emList,emList2,emList3,emList4)));
    }
    @Test
    public void checkInvestorCompletionTest_False_Response(){
        CRMChannelResponse e1 = createCRMChannelResponse(321, 444, EntityType.EMAIL, true);
        CRMChannelResponseList emList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{e1})).build();
        assertTrue(!releaseStrategyService.checkInvestorCompletion(Arrays.asList(emList)));
    }
    @Test
    public void checkCompanyCompletionTest(){
        CRMChannelResponse e1 = createCRMChannelResponse(321, 444, EntityType.EMAIL, true);
        CRMChannelResponseList emList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{e1})).build();
        CRMChannelResponseList emList2 = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{e1})).build();
        CRMChannelResponseList emList3 = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{e1})).build();
        CRMChannelResponseList emList4 = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{e1})).build();
        assertTrue(releaseStrategyService.checkCompanyCompletion(Arrays.asList(emList,emList2,emList3,emList4,emList2,emList3,emList4)));
    }
    @Test
    public void checkContactCompletionTest(){
        CRMChannelResponse e1 = createCRMChannelResponse(321, 444, EntityType.EMAIL, true);
        CRMChannelResponseList emList = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{e1})).build();
        CRMChannelResponseList emList2 = CRMChannelResponseList.newBuilder().addAllResponse(Arrays.asList(new CRMChannelResponse[]{e1})).build();
        assertTrue(releaseStrategyService.checkContactCompletion(Arrays.asList(emList,emList2,emList2)));
    }

    private CRMChannelResponse createCRMChannelResponse(int coreEntityId, int entityId, EntityType entityType, boolean status) {
        CRMChannelResponse response = CRMChannelResponse.newBuilder()
                .setCoreEntityId(coreEntityId)
                .setEntityId(entityId)
                .setEntityType(entityType)
                .setStatus(status).build();
        return response;
    }
}
