package com.bfm.aap.privatemarkets.crm.loader.integration.service;

import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.ContactEmail;
import com.bfm.aap.pmdx.model.FatcaDetails;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.Legal;
import com.bfm.aap.privatemarkets.crm.loader.mapper.EntityAttributeTransformer;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreCompanyMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreContactMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.EntityAttributeMessage;
import com.bfm.aap.privatemarkets.common.crm.model.CRMChannelResponse;
import com.bfm.aap.privatemarkets.common.crm.model.EntityType;
import com.bfm.aap.privatemarkets.crm.loader.service.CRMLoaderCoreService;
import com.bfm.aap.privatemarkets.crm.loader.util.CRMLoaderConstants;
import com.bfm.entitymaster.dto.common.Decode;
import com.bfm.entitymaster.dto.common.Entity;
import com.bfm.entitymaster.dto.contact.Contact;
import com.bfm.entitymaster.dto.entityattribute.EntityAttribute;
import com.bfm.util.BFMDate;
import org.apache.commons.collections.CollectionUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class EntityAttributeServiceTest {

    @InjectMocks
    private EntityAttributeService entityAttributeServiceTest;
    @Mock
    private EntityAttributeTransformer entityAttributeTransformer;
    @Mock
    private CRMLoaderCoreService crmUserLoaderService;


    private Decode getDecode(String code, String decode) {
        Decode d = new Decode();
        d.setCode(code);
        d.setDecode(decode);
        return d;
    }
    @Test
    public void translateToCRMMessage_Test() {
        when(entityAttributeTransformer.eFrontToCRMTransform(anyString(), anyString(), any(BFMDate.class), any(BFMDate.class))).
                thenReturn(getEntityAttribute("birthDate","05/05/1990"));
        EntityAttributeMessage response = entityAttributeServiceTest.translateToCRMMessage(getCoreContactWithBirthDate());
        assertTrue(response.getEntityAttributeList().size() == 1);
        assertTrue(response.getEntityAttributeList().get(0).getAttribute().equals("birthDate"));
        assertTrue(response.getEntityAttributeList().get(0).getValue().equals("05/05/1990"));
    }
    @Test
    public void translateToCRMMessage_Company_Test() {
        EntityAttributeMessage response = entityAttributeServiceTest.translateToCRMMessage(getCompanyMsg());
        assertEquals(123, response.getLinkedCRMEntityId());
    }
    @Test
    public void translateToCRMMessage_Company_Test_NoAttribute() {
        when(entityAttributeTransformer.eFrontToCRMTransform(anyString(), anyString(), any(BFMDate.class), any(BFMDate.class))).
                thenReturn(getEntityAttribute("INSURANCE","INSURANCE"));
        EntityAttributeMessage response = entityAttributeServiceTest.translateToCRMMessage(getCompanyMsg_NoAttribute());
        assertTrue(CollectionUtils.isEmpty(response.getEntityAttributeList()));

    }
    private CoreCompanyMessage getCompanyMsg() {
        CoreCompanyMessage msg = new CoreCompanyMessage();
        Entity entity = new Entity();
        entity.setEntityName("ABC Company");
        entity.setEntityType("O");
        entity.setEntityId(123);
        msg.setCompany(Company.newBuilder().setCompanyId("444").setLegalForm("INSURANCE")
                .setDescription("testDescription").setName("ABC Company").setDomicile("US").setStatus("BANK").build());
        msg.setOrgEntity(entity);
        return msg;
    }
    private CoreCompanyMessage getCompanyMsg_NoAttribute() {
        CoreCompanyMessage msg = new CoreCompanyMessage();
        Entity entity = new Entity();
        entity.setEntityName("ABC Company");
        entity.setEntityType("O");
        entity.setEntityId(123);
        msg.setCompany(Company.newBuilder().setCompanyId("444").setDescription("testDescription")
                .setName("ABC Company").setDomicile("US").setStatus("BANK").build());
        msg.setOrgEntity(entity);
        return msg;
    }
    @Test
    public void translateToCRMMessage_Citizenship_Test() {
        when(entityAttributeTransformer.eFrontToCRMTransform(anyString(), anyString(), any(BFMDate.class), any(BFMDate.class))).
                thenReturn(getEntityAttribute("citizenship","UK"));
        EntityAttributeMessage response = entityAttributeServiceTest.translateToCRMMessage(getCoreContactCitizenship());
        assertTrue(response.getEntityAttributeList().size() == 1);
        assertTrue(response.getEntityAttributeList().get(0).getAttribute().equals("citizenship"));
        assertTrue(response.getEntityAttributeList().get(0).getValue().equals("UK"));
    }
    @Test
    public void translateToCRMMessage_City_Test() {
        when(entityAttributeTransformer.eFrontToCRMTransform(anyString(), anyString(), any(BFMDate.class), any(BFMDate.class))).
                thenReturn(getEntityAttribute("birthplaceCity","London"));
        EntityAttributeMessage response = entityAttributeServiceTest.translateToCRMMessage(getCoreContactBirthPlace());
        assertTrue(response.getEntityAttributeList().size() == 1);
        assertTrue(response.getEntityAttributeList().get(0).getAttribute().equals("birthplaceCity"));
        assertTrue(response.getEntityAttributeList().get(0).getValue().equals("London"));
    }
    @Test
    public void translateToCRMMessage_Null() {
        EntityAttributeMessage response = entityAttributeServiceTest.translateToCRMMessage(getCoreContactNoAttributes());
        assertTrue(response.getEntityAttributeList().size() == 0);
    }


    @Test
    public void handleEntityAttributeCreate_Test() {
        when(crmUserLoaderService.createEntityAttributes(anyInt(), anyList(), anyString())).thenReturn(getEntityAttributeList());
        Message entityAttributeMessage = getEntityAttributeMessage(getEntityAttributeList());
        CRMChannelResponse response = entityAttributeServiceTest.handleEntityAttributeCreate(entityAttributeMessage);
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == -1);
        assertTrue(response.getEntityType().name().equals(EntityType.ENTITY_ATTRIBUTE.name()));
    }

    private Message<EntityAttributeMessage> getEntityAttributeMessage(List<EntityAttribute> entityAttributeList) {
        EntityAttributeMessage entityAttributeMessage = new EntityAttributeMessage();
        entityAttributeMessage.setEntityAttributeList(entityAttributeList);
        entityAttributeMessage.setLinkedCRMEntityId(123);
        return MessageBuilder.withPayload(entityAttributeMessage).setHeader("user", "userLogin").build();
    }

    @Test
    public void handleEntityAttributeCreate_Exception_Test() {
        when(crmUserLoaderService.createEntityAttributes(anyInt(), anyList(), anyString())).thenThrow(new RuntimeException("error"));
        Message entityAttributeMessage = getEntityAttributeMessage(getEntityAttributeList());
        CRMChannelResponse response = entityAttributeServiceTest.handleEntityAttributeCreate(entityAttributeMessage);
        assertTrue(!response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == -1);
        assertTrue(response.getEntityType().name().equals(EntityType.ENTITY_ATTRIBUTE.name()));
    }
    @Test
    public void handleEntityAttributeCreate_EmptyMessage() {
        when(crmUserLoaderService.createEntityAttributes(anyInt(), anyList(), anyString())).thenThrow(new RuntimeException("error"));
        Message entityAttributeMessage = getEntityAttributeMessage(null);
        CRMChannelResponse response = entityAttributeServiceTest.handleEntityAttributeCreate(entityAttributeMessage);
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == -1);
        assertTrue(response.getEntityType().name().equals(EntityType.ENTITY_ATTRIBUTE.name()));
    }

    @Test
    public void handleEntityAttributeUpdate_Test() {
        when(crmUserLoaderService.getEntityAttributesByEntityId(anyInt(), anyString())).thenReturn(getEntityAttributeList());
        List<EntityAttribute> newAttributeList = new ArrayList<>();
        newAttributeList.add(getEntityAttribute("DOB", "05/05/1990"));
        newAttributeList.add(getEntityAttribute("citizenship", "US"));
        when(crmUserLoaderService.createEntityAttributes(anyInt(), any(List.class), anyString())).thenReturn(newAttributeList);
        EntityAttributeMessage msg = new EntityAttributeMessage();
        msg.setLinkedCRMEntityId(123);
        msg.setEntityAttributeList(newAttributeList);

        CRMChannelResponse response = entityAttributeServiceTest.handleEntityAttributeUpdate(MessageBuilder.withPayload(msg).setHeader("user", "userLogin").build());
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == -1);
        assertTrue(response.getEntityType().name().equals(EntityType.ENTITY_ATTRIBUTE.name()));
    }

    @Test
    public void handleEntityAttributeUpdate_Test_Exception_Response() {
        when(crmUserLoaderService.getEntityAttributesByEntityId(anyInt(), anyString())).thenReturn(getEntityAttributeList());
        List<EntityAttribute> newAttributeList = new ArrayList<>();
        newAttributeList.add(getEntityAttribute("DOB", "05/05/1990"));
        newAttributeList.add(getEntityAttribute("citizenship", "US"));
        when(crmUserLoaderService.createEntityAttributes(anyInt(), any(List.class), anyString())).thenThrow(new RuntimeException("Error"));
        EntityAttributeMessage msg = new EntityAttributeMessage();
        msg.setLinkedCRMEntityId(123);
        msg.setEntityAttributeList(newAttributeList);

        CRMChannelResponse response = entityAttributeServiceTest.handleEntityAttributeUpdate(MessageBuilder.withPayload(msg).build());
        assertTrue(!response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == -1);
        assertTrue(response.getEntityType().name().equals(EntityType.ENTITY_ATTRIBUTE.name()));
    }
    @Test
    public void handleEntityAttributeUpdate_Test_Null_Response() {
        when(crmUserLoaderService.getEntityAttributesByEntityId(anyInt(), anyString())).thenReturn(getEntityAttributeList());
        List<EntityAttribute> newAttributeList = new ArrayList<>();
        newAttributeList.add(getEntityAttribute("DOB", "05/05/1990"));
        newAttributeList.add(getEntityAttribute("citizenship", "US"));
        when(crmUserLoaderService.createEntityAttributes(anyInt(), any(List.class), anyString())).thenReturn(null);
        EntityAttributeMessage msg = new EntityAttributeMessage();
        msg.setLinkedCRMEntityId(123);
        msg.setEntityAttributeList(newAttributeList);

        CRMChannelResponse response = entityAttributeServiceTest.handleEntityAttributeUpdate(MessageBuilder.withPayload(msg).build());
        assertTrue(!response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == -1);
        assertTrue(response.getEntityType().name().equals(EntityType.ENTITY_ATTRIBUTE.name()));
    }
    @Test
    public void handleEntityAttributeUpdate_Test_EmptyMsg() {
        //when(crmUserLoaderService.getEntityAttributesByEntityId(anyInt())).thenReturn(getEntityAttributeList());
        when(crmUserLoaderService.createEntityAttributes(anyInt(), any(List.class), anyString())).thenReturn(null);
        EntityAttributeMessage msg = new EntityAttributeMessage();
        msg.setLinkedCRMEntityId(123);
        msg.setEntityAttributeList(null);

        CRMChannelResponse response = entityAttributeServiceTest.handleEntityAttributeUpdate(MessageBuilder.withPayload(msg).build());
        assertTrue(response.getStatus());
        assertTrue(response.getCoreEntityId() == 123);
        assertTrue(response.getEntityId() == -1);
        assertTrue(response.getEntityType().name().equals(EntityType.ENTITY_ATTRIBUTE.name()));
    }

    @Test
    public void translateToCRMMessageTest_Investor(){
        List<EntityAttribute> eaList = new ArrayList<>();
        eaList.add(getEntityAttribute(CRMLoaderConstants.TAX_IDENTIFICATION,"111"));
        eaList.add(getEntityAttribute(CRMLoaderConstants.PRIMARY_TAX_COUNTRY,"US"));
        eaList.add(getEntityAttribute(CRMLoaderConstants.ERISA_INVESTOR,CRMLoaderConstants.ERISA_STATUTORY));
        eaList.add(getEntityAttribute(CRMLoaderConstants.BIRTH_PLACE_COUNTRY,"US"));
        eaList.add(getEntityAttribute(CRMLoaderConstants.DATE_OF_BIRTH,"05/05/1990"));
        eaList.add(getEntityAttribute(CRMLoaderConstants.FATCA_STATUS,"501CORG"));


        when(entityAttributeTransformer.eFrontToCRMTransform(CRMLoaderConstants.TAX_IDENTIFICATION,"111",new BFMDate(new Date()),new BFMDate(BFMDate.max_date)))
                .thenReturn(getEntityAttribute(CRMLoaderConstants.TAX_IDENTIFICATION,"111"));
        when(entityAttributeTransformer.eFrontToCRMTransform(CRMLoaderConstants.PRIMARY_TAX_COUNTRY,"US",new BFMDate(new Date()),new BFMDate(BFMDate.max_date)))
                .thenReturn(getEntityAttribute(CRMLoaderConstants.PRIMARY_TAX_COUNTRY,"US"));
        when(entityAttributeTransformer.eFrontToCRMTransform(CRMLoaderConstants.ERISA_INVESTOR,CRMLoaderConstants.ERISA_STATUTORY,new BFMDate(new Date()),new BFMDate(BFMDate.max_date)))
                .thenReturn(getEntityAttribute(CRMLoaderConstants.ERISA_INVESTOR,CRMLoaderConstants.ERISA_STATUTORY));
        when(entityAttributeTransformer.eFrontToCRMTransform(CRMLoaderConstants.BIRTH_PLACE_COUNTRY,"US",new BFMDate(new Date()),new BFMDate(BFMDate.max_date)))
                .thenReturn(getEntityAttribute(CRMLoaderConstants.BIRTH_PLACE_COUNTRY,"US"));
        when(entityAttributeTransformer.eFrontToCRMTransform(CRMLoaderConstants.DATE_OF_BIRTH,"05/05/1990",new BFMDate(new Date()),new BFMDate(BFMDate.max_date)))
                .thenReturn(getEntityAttribute(CRMLoaderConstants.DATE_OF_BIRTH,"05/05/1990"));
        when(entityAttributeTransformer.eFrontToCRMTransform(CRMLoaderConstants.FATCA_STATUS,"501CORG",new BFMDate(new Date()),new BFMDate(BFMDate.max_date)))
                .thenReturn(getEntityAttribute(CRMLoaderConstants.FATCA_STATUS,"501CORG"));
        EntityAttributeMessage msg = entityAttributeServiceTest.translateToCRMMessage(getInvestorMsg());
        assertTrue(msg.getEntityAttributeList().size()==6);
        assertTrue(compareByAttributeByType(msg.getEntityAttributeList(),eaList,CRMLoaderConstants.TAX_IDENTIFICATION));
        assertTrue(compareByAttributeByType(msg.getEntityAttributeList(),eaList,CRMLoaderConstants.PRIMARY_TAX_COUNTRY));
        assertTrue(compareByAttributeByType(msg.getEntityAttributeList(),eaList,CRMLoaderConstants.ERISA_INVESTOR));
        assertTrue(compareByAttributeByType(msg.getEntityAttributeList(),eaList,CRMLoaderConstants.BIRTH_PLACE_COUNTRY));
        assertTrue(compareByAttributeByType(msg.getEntityAttributeList(),eaList,CRMLoaderConstants.DATE_OF_BIRTH));
        assertTrue(compareByAttributeByType(msg.getEntityAttributeList(),eaList,CRMLoaderConstants.FATCA_STATUS));
    }

    @Test
    public void translateToCRMMessageTest_Investor_MissingAttributes(){
        List<EntityAttribute> eaList = new ArrayList<>();
        eaList.add(getEntityAttribute(CRMLoaderConstants.ERISA_INVESTOR,CRMLoaderConstants.ERISA_NO));
        eaList.add(getEntityAttribute(CRMLoaderConstants.BIRTH_PLACE_COUNTRY,"US"));
        eaList.add(getEntityAttribute(CRMLoaderConstants.DATE_OF_BIRTH,"05/05/1990"));


        when(entityAttributeTransformer.eFrontToCRMTransform(CRMLoaderConstants.ERISA_INVESTOR,CRMLoaderConstants.ERISA_NO,new BFMDate(new Date()),new BFMDate(BFMDate.max_date)))
                .thenReturn(getEntityAttribute(CRMLoaderConstants.ERISA_INVESTOR,CRMLoaderConstants.ERISA_NO));
        when(entityAttributeTransformer.eFrontToCRMTransform(CRMLoaderConstants.BIRTH_PLACE_COUNTRY,"US",new BFMDate(new Date()),new BFMDate(BFMDate.max_date)))
                .thenReturn(getEntityAttribute(CRMLoaderConstants.BIRTH_PLACE_COUNTRY,"US"));
        when(entityAttributeTransformer.eFrontToCRMTransform(CRMLoaderConstants.DATE_OF_BIRTH,"05/05/1990",new BFMDate(new Date()),new BFMDate(BFMDate.max_date)))
                .thenReturn(getEntityAttribute(CRMLoaderConstants.DATE_OF_BIRTH,"05/05/1990"));

        EntityAttributeMessage msg = entityAttributeServiceTest.translateToCRMMessage(getInvestorMsg_Some_Attributes_Missing());
        assertTrue(msg.getEntityAttributeList().size()==3);
        assertTrue(compareByAttributeByType(msg.getEntityAttributeList(),eaList,CRMLoaderConstants.ERISA_INVESTOR));
        assertTrue(compareByAttributeByType(msg.getEntityAttributeList(),eaList,CRMLoaderConstants.BIRTH_PLACE_COUNTRY));
        assertTrue(compareByAttributeByType(msg.getEntityAttributeList(),eaList,CRMLoaderConstants.DATE_OF_BIRTH));
    }

    @Test
    public void translateToCRMMessageTest_Investor_Null_Legal(){
        EntityAttributeMessage msg = entityAttributeServiceTest.translateToCRMMessage(getInvestorMsg_null_legal_Object());
        assertTrue(msg.getEntityAttributeList().size()==0);

    }

    private boolean compareByAttributeByType(List<EntityAttribute> actualList,List<EntityAttribute> mockList, String attribute){
        EntityAttribute actual = actualList.stream().filter(e->e.getAttribute().equalsIgnoreCase(attribute)).findFirst().get();
        EntityAttribute mock = mockList.stream().filter(e->e.getAttribute().equalsIgnoreCase(attribute)).findFirst().get();
        return actual.getAttribute().equalsIgnoreCase(mock.getAttribute()) && actual.getValue().equalsIgnoreCase(mock.getValue());
    }

    private CoreInvestorMessage getInvestorMsg_Some_Attributes_Missing(){
        com.bfm.aap.pmdx.model.Address address = com.bfm.aap.pmdx.model.Address.newBuilder().setId("123").setStreet1("Street1").setStreet2("street2").setIsPrimary(true)
                .setState("WA").setAddressType("Home").setCity("Seattle").setCountry("USA").setZipCode("98101").build();
        CoreInvestorMessage msg = new CoreInvestorMessage();
        Entity entity = new Entity();
        entity.setEntityName("ABC Company");
        entity.setEntityType("O");
        entity.setEntityId(123);
        Legal legal = Legal.newBuilder().setLegalDomicileCountry("US")
                .setLegalDomicileTaxId("222").setLegalName("ABCLegalName")
                .setCountryOfBirth("US").setDateOfBirth("05/05/1990")
                .setTaxExemptInTaxDomicile(true).build();
        Investor investor = Investor.newBuilder().setName("ABC Company").setShortCode("ABC").setInvestorType("BANK")
                .setLegal(legal).setDescription("TestDescription").setCompanyId("ABC").addOfficeAddressList(address).build();
        msg.setOrgEntity(entity);
        msg.setInvestor(investor);
        return msg;
    }
    private CoreInvestorMessage getInvestorMsg_null_legal_Object(){
        com.bfm.aap.pmdx.model.Address address = com.bfm.aap.pmdx.model.Address.newBuilder().setId("123").setStreet1("Street1").setStreet2("street2").setIsPrimary(true)
                .setState("WA").setAddressType("Home").setCity("Seattle").setCountry("USA").setZipCode("98101").build();
        CoreInvestorMessage msg = new CoreInvestorMessage();
        Entity entity = new Entity();
        entity.setEntityName("ABC Company");
        entity.setEntityType("O");
        entity.setEntityId(123);

        Investor investor = Investor.newBuilder().setName("ABC Company").setShortCode("ABC").setInvestorType("BANK")
                .setDescription("TestDescription").setCompanyId("ABC").addOfficeAddressList(address).build();
        msg.setOrgEntity(entity);
        msg.setInvestor(investor);
        return msg;
    }

    private CoreInvestorMessage getInvestorMsg() {
        com.bfm.aap.pmdx.model.Address address = com.bfm.aap.pmdx.model.Address.newBuilder().setId("123").setStreet1("Street1").setStreet2("street2").setIsPrimary(true)
                .setState("WA").setAddressType("Home").setCity("Seattle").setCountry("USA").setZipCode("98101").build();
        CoreInvestorMessage msg = new CoreInvestorMessage();
        Entity entity = new Entity();
        entity.setEntityName("ABC Company");
        entity.setEntityType("O");
        entity.setEntityId(123);
        FatcaDetails f = FatcaDetails.newBuilder().setStatus("501CORG").build();
        Legal legal = Legal.newBuilder().setLegalDomicileCountry("US").setTaxIdentification("111")
                .setLegalDomicileTaxId("222").setLegalName("ABCLegalName").setTaxDomicileCountry("US")
                .setErisaInvestor(true).setCountryOfBirth("US").setDateOfBirth("05/05/1990")
                .setTaxExemptInTaxDomicile(true).setFatcaDetails(f).build();
        Investor investor = Investor.newBuilder().setName("ABC Company").setShortCode("ABC").setInvestorType("BANK")
                .setLegal(legal).setDescription("TestDescription").setCompanyId("ABC").addOfficeAddressList(address).build();
        msg.setOrgEntity(entity);
        msg.setInvestor(investor);
        return msg;
    }

    private List<EntityAttribute> getEntityAttributeList(){
        List<EntityAttribute> eaList = new ArrayList<>();
        eaList.add(getEntityAttribute("DOB","05/05/1990"));
        eaList.add(getEntityAttribute("citizenship","UK"));
        return eaList;
    }
    private EntityAttribute getEntityAttribute(String attribute, String value) {
        EntityAttribute entityAttribute = new EntityAttribute();

        entityAttribute.setAttribute(attribute);
        entityAttribute.setValue(value);
        entityAttribute.setStartDate(new BFMDate(new Date()));
        entityAttribute.setEndDate(new BFMDate(BFMDate.max_date));
        return entityAttribute;
    }

    private CoreContactMessage getCoreContactWithBirthDate() {
        Contact crmContact = new Contact();
        crmContact.setEntityId(123);

        ContactEmail email = ContactEmail.newBuilder().setEmail("test@gmail.com").setIsPrimary(true).build();
        com.bfm.aap.pmdx.model.Contact pmdxContact = com.bfm.aap.pmdx.model.Contact.newBuilder().setDateOfBirth("05/05/1990").addEmailList(email).build();

        CoreContactMessage coreContactMessage = new CoreContactMessage();
        coreContactMessage.setCrmContact(crmContact);
        coreContactMessage.setPmdxContact(pmdxContact);
        return coreContactMessage;
    }
    private CoreContactMessage getCoreContactCitizenship() {
        Contact crmContact = new Contact();
        crmContact.setEntityId(123);

        ContactEmail email = ContactEmail.newBuilder().setEmail("test@gmail.com").setIsPrimary(true).build();
        com.bfm.aap.pmdx.model.Contact pmdxContact = com.bfm.aap.pmdx.model.Contact.newBuilder().setPrimaryCitizenship("UK").addEmailList(email).build();

        CoreContactMessage coreContactMessage = new CoreContactMessage();
        coreContactMessage.setCrmContact(crmContact);
        coreContactMessage.setPmdxContact(pmdxContact);
        return coreContactMessage;
    }
    private CoreContactMessage getCoreContactBirthPlace() {
        Contact crmContact = new Contact();
        crmContact.setEntityId(123);

        ContactEmail email = ContactEmail.newBuilder().setEmail("test@gmail.com").setIsPrimary(true).build();
        com.bfm.aap.pmdx.model.Contact pmdxContact = com.bfm.aap.pmdx.model.Contact.newBuilder().setBirthPlaceCity("London").addEmailList(email).build();

        CoreContactMessage coreContactMessage = new CoreContactMessage();
        coreContactMessage.setCrmContact(crmContact);
        coreContactMessage.setPmdxContact(pmdxContact);
        return coreContactMessage;
    }
    private CoreContactMessage getCoreContactNoAttributes() {
        Contact crmContact = new Contact();
        crmContact.setEntityId(123);

        ContactEmail email = ContactEmail.newBuilder().setEmail("test@gmail.com").setIsPrimary(true).build();
        com.bfm.aap.pmdx.model.Contact pmdxContact = com.bfm.aap.pmdx.model.Contact.newBuilder().addEmailList(email).build();

        CoreContactMessage coreContactMessage = new CoreContactMessage();
        coreContactMessage.setCrmContact(crmContact);
        coreContactMessage.setPmdxContact(pmdxContact);
        return coreContactMessage;
    }
}