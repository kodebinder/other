package com.bfm.aap.privatemarkets.crm.loader.integration.aggregator;

import com.bfm.aap.privatemarkets.common.crm.model.CRMChannelResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMChannelResponseList;
import com.bfm.aap.privatemarkets.common.crm.model.EntityType;
import com.google.common.collect.Iterables;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static junit.framework.TestCase.assertTrue;
import static org.mockito.Mockito.spy;

public class AggregatorServiceTest {
    AggregatorService aggregatorService = spy(AggregatorService.class);
    @Test
    public void aggregateAndPublishTest() {
        CRMChannelResponse a1 = createCRMChannelResponse(321, 222, EntityType.ADDRESS, true);
        CRMChannelResponse a2 = createCRMChannelResponse(321, 333, EntityType.ADDRESS, true);
        CRMChannelResponse a3 = createCRMChannelResponse(321, 444, EntityType.ADDRESS, false);
        List<CRMChannelResponse> respList = Arrays.asList(new CRMChannelResponse[]{a1, a2, a3});
        CRMChannelResponseList list = aggregatorService.aggregateAndPublish(respList);
        assertTrue(Iterables.elementsEqual(list.getResponseList(), respList));
    }

    @Test
    public void aggregateAndPublishSingleResponseTest() {
        CRMChannelResponse a1 = createCRMChannelResponse(321, 222, EntityType.ADDRESS, true);
        CRMChannelResponseList list = aggregatorService.aggregateAndPublishSingleResponse(a1);
        assertTrue(Iterables.elementsEqual(list.getResponseList(), Arrays.asList(a1)));
    }

    private CRMChannelResponse createCRMChannelResponse(int coreEntityId, int entityId, EntityType entityType, boolean status) {
        CRMChannelResponse response = CRMChannelResponse.newBuilder()
                .setCoreEntityId(coreEntityId)
                .setEntityId(entityId)
                .setEntityType(entityType)
                .setStatus(status).build();
        return response;
    }

}
