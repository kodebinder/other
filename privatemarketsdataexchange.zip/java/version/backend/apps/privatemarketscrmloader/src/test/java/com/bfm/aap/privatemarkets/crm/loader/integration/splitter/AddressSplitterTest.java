package com.bfm.aap.privatemarkets.crm.loader.integration.splitter;

import com.bfm.aap.pmdx.model.Address;
import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.Legal;
import com.bfm.aap.pmdx.model.util.SchemaEnum;
import com.bfm.aap.privatemarkets.crm.loader.mapper.AddressTransformer;
import com.bfm.aap.privatemarkets.crm.loader.model.AddressMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreCompanyMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreContactMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorMessage;
import com.bfm.entitymaster.dto.common.Entity;
import com.bfm.entitymaster.dto.contact.Contact;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(MockitoJUnitRunner.class)
public class AddressSplitterTest {
    @InjectMocks
    private AddressSplitter addressSplitter;
    @Mock
    AddressTransformer addressTransformer;

    @Test
    public void splitAndPublish_Test_Only_One_Address() {
        when(addressTransformer.eFrontToCRMTransform(any(Address.class), any(SchemaEnum.class))).thenReturn(getTransformedAddress
            ("street1", "street2", "street3", "Seattle", "WA", "98101", "Home", "USA", true));
        List<AddressMessage> msgList = addressSplitter.splitAndPublishContactAddress(getContactWithJustOneAddress());
        assertTrue(msgList.size() == 1);
        assertTrue(msgList.get(0).getLinkedCRMEntityId() == 123);
        assertTrue(msgList.get(0).getCrmAddress().getAddress1().equals("street1"));
        assertTrue(msgList.get(0).getCrmAddress().getAddress2().equals("street2"));
        assertTrue(msgList.get(0).getCrmAddress().getAddress3().equals("street3"));
        assertTrue(msgList.get(0).getCrmAddress().getCity().equals("Seattle"));
        assertTrue(msgList.get(0).getCrmAddress().getState().equals("WA"));
        assertTrue(msgList.get(0).getCrmAddress().getPostalCode().equals("98101"));
        assertTrue(msgList.get(0).getCrmAddress().getAddressTitle().equals("Home"));
        assertTrue(msgList.get(0).getCrmAddress().getCountry().equals("USA"));
        assertTrue(msgList.get(0).getCrmAddress().getPrimary());
    }
    @Test
    public void splitAndPublishCompanyAddress_Test() {
        when(addressTransformer.eFrontToCRMTransform(any(Address.class), any(SchemaEnum.class))).thenReturn(getTransformedAddress
            ("street1", "street2", "street3", "Seattle", "WA", "98101", "Home", "USA", true));
        List<AddressMessage> msgList = addressSplitter.splitAndPublishCompanyAddress(getCompanyMsg());
        assertTrue(msgList.size() == 1);
        assertTrue(msgList.get(0).getLinkedCRMEntityId() == 123);
        assertTrue(msgList.get(0).getCrmAddress().getAddress1().equals("street1"));
        assertTrue(msgList.get(0).getCrmAddress().getAddress2().equals("street2"));
        assertTrue(msgList.get(0).getCrmAddress().getAddress3().equals("street3"));
        assertTrue(msgList.get(0).getCrmAddress().getCity().equals("Seattle"));
        assertTrue(msgList.get(0).getCrmAddress().getState().equals("WA"));
        assertTrue(msgList.get(0).getCrmAddress().getPostalCode().equals("98101"));
        assertTrue(msgList.get(0).getCrmAddress().getAddressTitle().equals("Home"));
        assertTrue(msgList.get(0).getCrmAddress().getCountry().equals("USA"));
        assertTrue(msgList.get(0).getCrmAddress().getPrimary());
    }

    @Test
    public void splitAndPublishInvestorAddress_Test() {
        when(addressTransformer.eFrontToCRMTransform(any(Address.class), any(SchemaEnum.class))).thenReturn(getTransformedAddress
            ("street1", "street2", "street3", "Seattle", "WA", "98101", "Home", "USA", true));
        List<AddressMessage> msgList = addressSplitter.splitAndPublishInvestorAddress(getInvestorMsg());
        assertTrue(msgList.size() == 1);
        assertTrue(msgList.get(0).getLinkedCRMEntityId() == 123);
        assertTrue(msgList.get(0).getCrmAddress().getAddress1().equals("street1"));
        assertTrue(msgList.get(0).getCrmAddress().getAddress2().equals("street2"));
        assertTrue(msgList.get(0).getCrmAddress().getAddress3().equals("street3"));
        assertTrue(msgList.get(0).getCrmAddress().getCity().equals("Seattle"));
        assertTrue(msgList.get(0).getCrmAddress().getState().equals("WA"));
        assertTrue(msgList.get(0).getCrmAddress().getPostalCode().equals("98101"));
        assertTrue(msgList.get(0).getCrmAddress().getAddressTitle().equals("Home"));
        assertTrue(msgList.get(0).getCrmAddress().getCountry().equals("USA"));
        assertTrue(msgList.get(0).getCrmAddress().getPrimary());
    }

    @Test
    public void splitAndPublishInvestorAddress_Test_Null_Address() {
        List<AddressMessage> msgList = addressSplitter.splitAndPublishInvestorAddress(getInvestorMsg_No_Address());
        assertTrue(msgList.size() == 0);

    }

    private Message<CoreInvestorMessage> getInvestorMsg_No_Address(){
        CoreInvestorMessage msg = new CoreInvestorMessage();
        Entity entity = new Entity();
        entity.setEntityName("ABC Company");
        entity.setEntityType("O");
        entity.setEntityId(123);
        Legal legal = Legal.newBuilder().setLegalDomicileCountry("US").build();
        Investor investor = Investor.newBuilder().setName("ABC Company").setShortCode("ABC").setInvestorType("BANK")
                .setLegal(legal).setCompanyId("ABC").build();
        msg.setOrgEntity(entity);
        msg.setInvestor(investor);
        return MessageBuilder.withPayload(msg).build();
    }
    private Message<CoreInvestorMessage> getInvestorMsg(){
        Address address = Address.newBuilder().setId("123").setStreet1("Street1").setStreet2("street2").setIsPrimary(true)
                .setState("WA").setAddressType("Home").setCity("Seattle").setCountry("USA").setZipCode("98101").build();
        CoreInvestorMessage msg = new CoreInvestorMessage();
        Entity entity = new Entity();
        entity.setEntityName("ABC Company");
        entity.setEntityType("O");
        entity.setEntityId(123);
        Legal legal = Legal.newBuilder().setLegalDomicileCountry("US").build();
        Investor investor = Investor.newBuilder().setName("ABC Company").setShortCode("ABC").setInvestorType("BANK")
                .setLegal(legal).setCompanyId("ABC").addOfficeAddressList(address).build();
        msg.setOrgEntity(entity);
        msg.setInvestor(investor);
        return MessageBuilder.withPayload(msg).build();
    }
    private Message<CoreCompanyMessage> getCompanyMsg() {
        Address address = Address.newBuilder().setId("123").setStreet1("Street1").setStreet2("street2").setIsPrimary(true)
                .setState("WA").setAddressType("Home").setCity("Seattle").setCountry("USA").setZipCode("98101").build();

        CoreCompanyMessage msg = new CoreCompanyMessage();
        Entity entity = new Entity();
        entity.setEntityName("ABC Company");
        entity.setEntityType("O");
        entity.setEntityId(123);
        msg.setCompany(Company.newBuilder().setCompanyId("444")
                .addOfficeAddressList(address).setLegalFormInsight("LegalAttribute")
                .setDescription("testDescription").setName("ABC Company").setDomicile("US").setStatus("BANK").build());
        msg.setOrgEntity(entity);
        Message<CoreCompanyMessage> message = MessageBuilder.withPayload(msg).build();
        return message;
    }
    @Test
    public void splitAndPublish_Test_With_Null_Address() {
        when(addressTransformer.eFrontToCRMTransform(any(Address.class), any(SchemaEnum.class))).thenReturn(getTransformedAddress
            ("street1", "street2", "street3", "Seattle", "WA", "98101", "Home", "USA", true));
        List<AddressMessage> msgList = addressSplitter.splitAndPublishContactAddress(getContactWithJustOneAddress());
        assertTrue(msgList.size() == 1);
        assertTrue(msgList.get(0).getLinkedCRMEntityId() == 123);
        assertTrue(msgList.get(0).getCrmAddress().getAddress1().equals("street1"));
        assertTrue(msgList.get(0).getCrmAddress().getAddress2().equals("street2"));
        assertTrue(msgList.get(0).getCrmAddress().getAddress3().equals("street3"));
        assertTrue(msgList.get(0).getCrmAddress().getCity().equals("Seattle"));
        assertTrue(msgList.get(0).getCrmAddress().getState().equals("WA"));
        assertTrue(msgList.get(0).getCrmAddress().getPostalCode().equals("98101"));
        assertTrue(msgList.get(0).getCrmAddress().getAddressTitle().equals("Home"));
        assertTrue(msgList.get(0).getCrmAddress().getCountry().equals("USA"));
        assertTrue(msgList.get(0).getCrmAddress().getPrimary());
    }

    private com.bfm.entitymaster.dto.common.Address getTransformedAddress(String street1, String street2, String street3, String city, String state,
                                                                          String zipCode, String addressType, String country, boolean isPrimary) {
        com.bfm.entitymaster.dto.common.Address address = new com.bfm.entitymaster.dto.common.Address();

        address.setCountry(country);
        address.setAddress3(street3);
        address.setAddressTitle(addressType);
        address.setAddress2(street2);
        address.setCity(city);
        address.setAddress1(street1);
        address.setPostalCode(zipCode);
        address.setState(state);
        address.setPrimary(isPrimary);

        return address;
    }

    Message<CoreContactMessage> getContactWithJustOneAddress() {
        Contact crmContact = new Contact();
        crmContact.setEntityId(123);

        Address address = Address.newBuilder().setId("123").setStreet1("Street1").setStreet2("street2").setIsPrimary(true)
                .setState("WA").setAddressType("Home").setCity("Seattle").setCountry("USA").setZipCode("98101").build();
        com.bfm.aap.pmdx.model.Contact pmdxContact = com.bfm.aap.pmdx.model.Contact.newBuilder().addAddressList(address).build();

        CoreContactMessage coreContactMessage = new CoreContactMessage();
        coreContactMessage.setCrmContact(crmContact);
        coreContactMessage.setPmdxContact(pmdxContact);

        return MessageBuilder.withPayload(coreContactMessage).build();
    }

    Message<CoreContactMessage> getContactWithNullAddress() {
        Contact crmContact = new Contact();
        crmContact.setEntityId(123);
        List<Address> addressList = new ArrayList<>();
        Address address = Address.newBuilder().setId("123").setStreet1("Street1").setStreet2("street2").setIsPrimary(true)
                .setState("WA").setAddressType("Home").setCity("Seattle").setCountry("USA").setZipCode("98101").build();
        addressList.add(address);
        addressList.add(null);

        com.bfm.aap.pmdx.model.Contact pmdxContact = com.bfm.aap.pmdx.model.Contact.newBuilder().build();
        pmdxContact.getAddressListList().addAll(addressList);

        CoreContactMessage coreContactMessage = new CoreContactMessage();
        coreContactMessage.setCrmContact(crmContact);
        coreContactMessage.setPmdxContact(pmdxContact);

        return MessageBuilder.withPayload(coreContactMessage).build();
    }
}
