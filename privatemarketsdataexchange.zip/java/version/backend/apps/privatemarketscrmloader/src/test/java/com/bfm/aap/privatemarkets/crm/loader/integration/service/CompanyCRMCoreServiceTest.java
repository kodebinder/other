package com.bfm.aap.privatemarkets.crm.loader.integration.service;

import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.privatemarkets.crm.loader.mapper.AddressInverseTransformer;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreCompanyInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreCompanyMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.service.CRMLoaderCoreService;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.entitymaster.dto.common.Address;
import com.bfm.entitymaster.dto.common.Decode;
import com.bfm.entitymaster.dto.common.Entity;
import com.bfm.entitymaster.dto.organization.OrganizationDetail;
import com.bfm.entitymaster.dto.organization.OrganizationType;
import org.apache.commons.lang.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import java.math.BigDecimal;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;


@RunWith(MockitoJUnitRunner.class)
public class CompanyCRMCoreServiceTest {
    @InjectMocks
    private CompanyCRMCoreService companyCRMCoreService;
    @Mock
    private CRMLoaderCoreService crmCoreService;
    @Mock
    private CRMThirdPartyMapperService crmThirdPartyMapperService;
    @Mock
    private OrganizationDetail organizationDetail;
    @Mock
    private AddressInverseTransformer addressInverseTransformer;
    @InjectMocks
    private AddressInverseService addressInverseService = new AddressInverseService(addressInverseTransformer);

    
    public void translateToEfrontAddress_Company() {
        CoreCompanyInverseMessage coreCompanyInverseMessage = new CoreCompanyInverseMessage();
        coreCompanyInverseMessage.setEfrontEntity(Company.newBuilder().build());
        coreCompanyInverseMessage.setOrganization(organizationDetail);
        Address address = new Address(12, "test", "test", "test", "test",
            "test", "test", "test", "test", "test", "test", "test",
            false, false, false, BigDecimal.ZERO, BigDecimal.ZERO);
        doReturn(address).when(organizationDetail).getPrimaryAddress();
        doReturn(com.bfm.aap.pmdx.model.Address.newBuilder().setCity("test").build()).when(addressInverseTransformer).crmToEfrontTransform(address);
        coreCompanyInverseMessage = addressInverseService.translateToEfrontAddress(coreCompanyInverseMessage);
        assertTrue(coreCompanyInverseMessage.getEfrontEntity().getOfficeAddressList(0).getCity().equals("test"));
    }

    
    public void translateToEfrontAddress_Investor() {
        CoreInvestorInverseMessage coreInvestorInverseMessage = new CoreInvestorInverseMessage();
        coreInvestorInverseMessage.setEfrontEntity(Investor.newBuilder().build());
        coreInvestorInverseMessage.setOrganization(organizationDetail);
        Address address = new Address(12, "test", "test", "test", "test",
            "test", "test", "test", "test", "test", "test", "test",
            false, false, false, BigDecimal.ZERO, BigDecimal.ZERO);
        doReturn(address).when(organizationDetail).getPrimaryAddress();
        doReturn(com.bfm.aap.pmdx.model.Address.newBuilder().setCity("test").build()).when(addressInverseTransformer).crmToEfrontTransform(address);
        coreInvestorInverseMessage = addressInverseService.translateToEfrontAddress(coreInvestorInverseMessage);
        assertTrue(coreInvestorInverseMessage.getEfrontEntity().getOfficeAddressList(0).getCity().equals("test"));
    }

    
    public void testDefaultConstructor() {
        AddressInverseService addressInverseService = new AddressInverseService();
        assertNotNull(addressInverseService);
    }

    @Test
    public void populateCRMEntityId_Test() {
        when(crmThirdPartyMapperService.lookUp("444", ThirdPartyMappingEnum.COMPANY_INVEST)).thenReturn(123);
        when(crmThirdPartyMapperService.lookUp("A1B2C3", ThirdPartyMappingEnum.USER_INVEST)).thenReturn(234);
        when(crmThirdPartyMapperService.getLoginByEntityId(anyInt())).thenReturn("userLogin");
        Message<CoreCompanyMessage> msg = companyCRMCoreService.populateCRMEntityId(getCompanyMsg());
        assertTrue(msg.getPayload().getOrgEntity().getEntityId() == 123);
        assertTrue("userLogin".equalsIgnoreCase(msg.getPayload().getUser()));
    }

    @Test
    public void handleCoreCompanyCreate_Test() {
        Entity entity = getEntity("ABC2 Company");
        entity.setEntityId(123);
        OrganizationDetail org = new OrganizationDetail();
        org.setOrganization(entity);
        when(crmCoreService.createOrganizationCRM(any(Entity.class),
                any(OrganizationType.class),
                any(Decode.class), anyString()))
                .thenReturn(org);
        CoreCompanyMessage cmsg = companyCRMCoreService.handleCoreCompanyCreate(getCompanyMsg());
        assertTrue(cmsg.getOrgEntity().getEntityId() == 123);
        assertTrue(cmsg.getOrgEntity().getEntityName().equals("ABC2 Company"));
    }


    private Entity getEntity(String entityName) {
        Entity entity = new Entity();
        entity.setEntityName(entityName);
        entity.setEntityType("O");
        return entity;
    }


    
    public void handleCoreCompanyUpdate_Test() {
        Entity entity = getEntity("ABC Company");
        entity.setEntityId(123);
        OrganizationDetail org = new OrganizationDetail();
        org.setOrganizationType(getOrganizationType("BANK"));
        org.setOrganization(entity);
        when(crmCoreService.getOrganizationByIdCRM(anyInt(), anyString())).thenReturn(org);
        when(crmCoreService.updateOrganizationCRM(anyInt(), any(Entity.class), any(OrganizationType.class), anyString())).thenReturn(org);
        CoreCompanyMessage response = companyCRMCoreService.handleCoreCompanyUpdate(getCoreCompanyMessage());
        assertNotNull(response);
        assertTrue(response.getOrgEntity().getEntityId() == 123);
    }

    private Message<CoreCompanyMessage> getCoreCompanyMessage() {
        CoreCompanyMessage req = getCompanyMsg().getPayload();
        req.getOrgEntity().setEntityId(123);
        return MessageBuilder.withPayload(req).setHeader("user", "userLogin").build();
    }

    @Test
    public void handleCoreCompanyUpdate_Test_DifferentType() {
        Entity entity = getEntity("ABC2 Company");
        entity.setEntityId(123);
        OrganizationDetail org = new OrganizationDetail();
        org.setOrganizationType(getOrganizationType("EXCHANGE"));
        org.setOrganization(entity);
        when(crmCoreService.getOrganizationByIdCRM(anyInt(), anyString())).thenReturn(org);
        when(crmCoreService.updateOrganizationCRM(anyInt(), any(Entity.class), any(OrganizationType.class), anyString())).thenReturn(org);
        CoreCompanyMessage response = companyCRMCoreService.handleCoreCompanyUpdate(getCoreCompanyMessage());
        assertNotNull(response);
        assertTrue(response.getOrgEntity().getEntityId() == 123);
    }

    private OrganizationType getOrganizationType(String orgType) {
        OrganizationType organizationType = new OrganizationType();
        if (StringUtils.isNotBlank(orgType)) {
            organizationType.setOrganizationType(getDecode(orgType, "Bank"));
        }
        return organizationType;
    }

    private Message<CoreCompanyMessage> getCompanyMsg() {
        CoreCompanyMessage msg = new CoreCompanyMessage();
        String domicile = "US";
        String status = "BANK";
        Entity entity = getEntity("ABC2 Company");
        msg.setCompany(Company.newBuilder().setCompanyId("444").setName("ABC Company").setDomicile(domicile).setStatus(status)
                .setModifiedBy("A1B2C3").build());
        msg.setOrgEntity(entity);
        msg.setOrganizationType(getOrganizationType("BANK"));
        msg.setCountryDecode(getDecode("US", "United States"));
        return MessageBuilder.withPayload(msg).setHeader("user", "userLogin").build();
    }

    private Decode getDecode(String code, String decode) {
        Decode d = new Decode();
        d.setCode(code);
        d.setDecode(decode);
        return d;
    }
}