package com.bfm.aap.privatemarkets.crm.loader.integration.service;

import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.Legal;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreCompanyInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreContactInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.entity.ChangeType;
import com.bfm.aap.privatemarkets.crm.loader.util.DecodeHelper;
import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMResponseStatusEnum;
import com.bfm.aap.privatemarkets.common.crm.util.EntityMasterDecodeTableConstants;
import com.bfm.aap.privatemarkets.crm.loader.util.CRMLoaderConstants;
import com.bfm.entitymaster.dto.common.Decode;
import com.bfm.entitymaster.dto.entityattribute.EntityAttribute;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

@RunWith(PowerMockRunner.class)
@PrepareForTest({DecodeHelper.class})
public class EntityAttributeInverseServiceTest {

	@InjectMocks
	private EntityAttributeInverseService entityAttributeInverseService;

	@Before
	public void initMocks() {
		mockStatic(DecodeHelper.class);
		PowerMockito.when(DecodeHelper.getDecode(EntityMasterDecodeTableConstants.COUNTRIES, "US"))
			.thenReturn(getDecode("MOCK_LGL_ENT", "LGL_ENT"));
	}

	@Test
	public void testGetEntityAttributesAndUpdateEfrontContact() {
		CoreContactInverseMessage coreContactInverseMessage = new CoreContactInverseMessage();
		coreContactInverseMessage.setEntityAttributes(createEntityAttributesListForContact());
		coreContactInverseMessage.setEfrontEntity(Contact.newBuilder().build());
		CRMLoaderResponse loaderResponse = entityAttributeInverseService
			.getEntityAttributesAndUpdateEfrontContact(coreContactInverseMessage);
		assertSame(CRMResponseStatusEnum.FULL_SUCCESS, loaderResponse.getStatus());
		assertNotNull(loaderResponse.getMessage().contains("1980/01/01"));
	}

	@Test
	public void testGetEntityAttributesAndUpdateEfrontCompany() {
		CoreCompanyInverseMessage coreCompanyInverseMessage = new CoreCompanyInverseMessage();
		List<EntityAttribute> entityAttributeList = new ArrayList<>();
		EntityAttribute entityAttribute1 = new EntityAttribute();
		entityAttribute1.setAttribute(CRMLoaderConstants.LEGAL_ENTITY_TYPE);
		entityAttribute1.setValue("MOCK_LGL_ENT");
		entityAttributeList.add(entityAttribute1);
		coreCompanyInverseMessage.setEntityAttributes(entityAttributeList);
		coreCompanyInverseMessage.setEfrontEntity(Company.newBuilder().build());
		CRMLoaderResponse loaderResponse = entityAttributeInverseService
			.getEntityAttributesAndUpdateEfrontCompany(coreCompanyInverseMessage);
		assertSame(CRMResponseStatusEnum.FULL_SUCCESS, loaderResponse.getStatus());
	}

	@Test
	public void testGetEntityAttributesAndUpdateEfrontInvestor() {
		CoreInvestorInverseMessage coreInvestorInverseMessage = new CoreInvestorInverseMessage();
		coreInvestorInverseMessage.setEntityAttributes(createEntityAttributesListForInvestor());
		coreInvestorInverseMessage.setEfrontEntity(Investor.newBuilder().setLegal(Legal.newBuilder().build()).build());
		CRMLoaderResponse loaderResponse = entityAttributeInverseService
			.getEntityAttributesAndUpdateEfrontInvestor(coreInvestorInverseMessage);
		assertSame(CRMResponseStatusEnum.FULL_SUCCESS, loaderResponse.getStatus());
	}

	@Test
	public void testEntityAttribute() {
		com.bfm.aap.privatemarkets.crm.loader.model.entity.EntityAttribute entityAttribute = new com.bfm.aap.privatemarkets.crm.loader.model.entity.EntityAttribute();
		Date date = new Date();
		entityAttribute.setAttributeCd("attributeCode");
		entityAttribute.setChangeType(ChangeType.UPDATE_INSERT);
		entityAttribute.setCreatedBy("tsgops");
		entityAttribute.setCreatedTime(date);
		entityAttribute.setEndDate(date);
		entityAttribute.setModifiedBy("tsgops");
		entityAttribute.setModifiedTime(date);
		entityAttribute.setStartDate(date);
		entityAttribute.setEntityId(1234);
		entityAttribute.setValue("value");

		Assert.assertEquals("attributeCode",entityAttribute.getAttributeCd());
		Assert.assertEquals(ChangeType.UPDATE_INSERT,entityAttribute.getChangeType());
		Assert.assertEquals("tsgops",entityAttribute.getCreatedBy());
		Assert.assertEquals(date,entityAttribute.getCreatedTime());
		Assert.assertEquals(date,entityAttribute.getEndDate());
		Assert.assertEquals("tsgops",entityAttribute.getModifiedBy());
		Assert.assertEquals(date,entityAttribute.getModifiedTime());
		Assert.assertEquals(date,entityAttribute.getStartDate());
		Assert.assertEquals("1234",String.valueOf(entityAttribute.getEntityId()));
		Assert.assertEquals("value",entityAttribute.getValue());
	}

	private List<EntityAttribute> createEntityAttributesListForInvestor() {
		List<EntityAttribute> entityAttributeList = new ArrayList<>();
		EntityAttribute entityAttribute1 = new EntityAttribute();
		entityAttribute1.setAttribute(CRMLoaderConstants.DATE_OF_BIRTH);
		entityAttribute1.setValue("1980/01/01");
		entityAttributeList.add(entityAttribute1);

		EntityAttribute entityAttribute4 = new EntityAttribute();
		entityAttribute4.setAttribute(CRMLoaderConstants.TAX_IDENTIFICATION);
		entityAttribute4.setValue("45876");
		entityAttributeList.add(entityAttribute4);

		EntityAttribute entityAttribute5 = new EntityAttribute();
		entityAttribute5.setAttribute(CRMLoaderConstants.ERISA_INVESTOR);
		entityAttribute5.setValue(CRMLoaderConstants.ERISA_STATUTORY);
		entityAttributeList.add(entityAttribute5);

		EntityAttribute entityAttribute7 = new EntityAttribute();
		entityAttribute7.setAttribute(CRMLoaderConstants.FATCA_STATUS);
		entityAttribute7.setValue("Valid");
		entityAttributeList.add(entityAttribute7);

		EntityAttribute entityAttribute8 = new EntityAttribute();
		entityAttribute8.setAttribute(CRMLoaderConstants.BIRTH_PLACE_COUNTRY);
		entityAttribute8.setValue("Test");
		entityAttributeList.add(entityAttribute8);

		EntityAttribute entityAttribute9 = new EntityAttribute();
		entityAttribute9.setAttribute(CRMLoaderConstants.PRIMARY_TAX_COUNTRY);
		entityAttribute9.setValue("US");
		entityAttributeList.add(entityAttribute9);

		return entityAttributeList;
	}

	private List<EntityAttribute> createEntityAttributesListForContact() {
		List<EntityAttribute> entityAttributeList = new ArrayList<>();
		EntityAttribute entityAttribute1 = new EntityAttribute();
		entityAttribute1.setAttribute(CRMLoaderConstants.DATE_OF_BIRTH);
		entityAttribute1.setValue("1980/01/01");
		entityAttributeList.add(entityAttribute1);

		EntityAttribute entityAttribute2 = new EntityAttribute();
		entityAttribute2.setAttribute(CRMLoaderConstants.BIRTH_PLACE_CITY);
		entityAttribute2.setValue("Kansas City");
		entityAttributeList.add(entityAttribute2);

		EntityAttribute entityAttribute3 = new EntityAttribute();
		entityAttribute3.setAttribute(CRMLoaderConstants.CITIZENSHIP);
		entityAttribute3.setValue("US");
		entityAttributeList.add(entityAttribute3);

		return entityAttributeList;
	}

	private com.bfm.entitymaster.dto.common.Decode getDecode(String code, String decode) {
		com.bfm.entitymaster.dto.common.Decode d = new Decode();
		d.setCode(code);
		d.setDecode(decode);
		return d;
	}
}