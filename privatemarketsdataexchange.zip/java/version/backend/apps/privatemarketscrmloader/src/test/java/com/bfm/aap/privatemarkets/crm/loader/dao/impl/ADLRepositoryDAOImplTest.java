package com.bfm.aap.privatemarkets.crm.loader.dao.impl;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import com.google.gson.Gson;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import com.bfm.aap.pmdx.model.util.EntityType;
import com.bfm.adl.ADLException;
import com.bfm.adl.ADLObject;
import com.bfm.adl.ADLQuery;
import com.bfm.adl.ADLRepository;
import com.bfm.adl.ADLRepositoryFactory;
import com.bfm.adl.ADLResultSet;
import com.bfm.adl.impl.ADLObjectImpl;
import com.bfm.adl.impl.schema.ADLSchema;
import com.bfm.util.BFMTimestamp;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.reset;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ADLRepositoryFactory.class})
public class ADLRepositoryDAOImplTest {

    private static final String DATAWORKSPACE_ADL_SCHEMA = "{\"loadedUnsafely\":false,\"name\":\"AlternativesDataWorkspace\",\"consistency\":\"DATACENTER\",\"scope\":\"CLIENT\",\"module\":\"ALTS\",\"ttlSeconds\":604800,\"fields\":[{\"name\":\"gUID\",\"type\":{\"template\":\"STRING\",\"args\":[]},\"nullable\":false,\"sharedInPrimaryRange\":false,\"description\":\"eFront provided gUID, unique to entity and unique across all clients\"},{\"name\":\"lastModifiedTime\",\"type\":{\"template\":\"TIMESTAMP\",\"args\":[]},\"nullable\":false,\"sharedInPrimaryRange\":false,\"description\":\"last modified time in ms, recorded by eFront\"},{\"name\":\"entityType\",\"type\":{\"template\":\"STRING\",\"args\":[]},\"nullable\":false,\"sharedInPrimaryRange\":false,\"description\":\"identifies record as entityType Portfolio, Position, or Asset\"},{\"name\":\"version\",\"type\":{\"template\":\"STRING\",\"args\":[]},\"nullable\":false,\"sharedInPrimaryRange\":false,\"description\":\"protobuff model version\"},{\"name\":\"client\",\"type\":{\"template\":\"STRING\",\"args\":[]},\"nullable\":false,\"sharedInPrimaryRange\":false,\"description\":\"will be specified by blk client_abbrev decode table\"},{\"name\":\"networkMode\",\"type\":{\"template\":\"STRING\",\"args\":[]},\"nullable\":false,\"sharedInPrimaryRange\":false,\"description\":\"identifies data for red/blue app versions\"},{\"name\":\"edxData\",\"type\":{\"template\":\"BYTES\",\"args\":[]},\"nullable\":false,\"sharedInPrimaryRange\":false,\"description\":\"protobuff encoded data\"}],\"primaryIndexName\":\"idxPrimary\",\"primaryIndex\":{\"fields\":[{\"name\":\"gUID\",\"type\":{\"template\":\"STRING\",\"args\":[]},\"nullable\":false,\"sharedInPrimaryRange\":false,\"description\":\"eFront provided gUID, unique to entity and unique across all clients\"},{\"name\":\"networkMode\",\"type\":{\"template\":\"STRING\",\"args\":[]},\"nullable\":false,\"sharedInPrimaryRange\":false,\"description\":\"identifies data for red/blue app versions\"}],\"fieldOrders\":[\"UNDEF\",\"UNDEF\"],\"inactive\":false,\"description\":\"\",\"hashCode\":-1965519512,\"fieldsBeforeRange\":[{\"name\":\"gUID\",\"type\":{\"template\":\"STRING\",\"args\":[]},\"nullable\":false,\"sharedInPrimaryRange\":false,\"description\":\"eFront provided gUID, unique to entity and unique across all clients\"},{\"name\":\"networkMode\",\"type\":{\"template\":\"STRING\",\"args\":[]},\"nullable\":false,\"sharedInPrimaryRange\":false,\"description\":\"identifies data for red/blue app versions\"}],\"fieldsBeyondRange\":[],\"fieldOrdersBeyondRange\":[]},\"secondaryIndexes\":{},\"description\":\"Last edited by: $Author: myen $\\non: $Date: 2019/07/17 13:50:03 $\\nFilename: $RCSfile: AlternativesDataWorkspace.schema,v $\\nRevision: $Revision: 1 $\\n\\nDescription\\n\\nThis repository stores serialized eFront data for the EDX system.\",\"consistencyDescription\":\"\",\"scopeDescription\":\"\",\"moduleDescription\":\"\",\"ttlDescription\":\"\",\"hashCode\":-1752938737,\"fieldsByName\":{\"gUID\":{\"name\":\"gUID\",\"type\":{\"template\":\"STRING\",\"args\":[]},\"nullable\":false,\"sharedInPrimaryRange\":false,\"description\":\"eFront provided gUID, unique to entity and unique across all clients\"},\"lastModifiedTime\":{\"name\":\"lastModifiedTime\",\"type\":{\"template\":\"TIMESTAMP\",\"args\":[]},\"nullable\":false,\"sharedInPrimaryRange\":false,\"description\":\"last modified time in ms, recorded by eFront\"},\"entityType\":{\"name\":\"entityType\",\"type\":{\"template\":\"STRING\",\"args\":[]},\"nullable\":false,\"sharedInPrimaryRange\":false,\"description\":\"identifies record as entityType Portfolio, Position, or Asset\"},\"version\":{\"name\":\"version\",\"type\":{\"template\":\"STRING\",\"args\":[]},\"nullable\":false,\"sharedInPrimaryRange\":false,\"description\":\"protobuff model version\"},\"client\":{\"name\":\"client\",\"type\":{\"template\":\"STRING\",\"args\":[]},\"nullable\":false,\"sharedInPrimaryRange\":false,\"description\":\"will be specified by blk client_abbrev decode table\"},\"networkMode\":{\"name\":\"networkMode\",\"type\":{\"template\":\"STRING\",\"args\":[]},\"nullable\":false,\"sharedInPrimaryRange\":false,\"description\":\"identifies data for red/blue app versions\"},\"edxData\":{\"name\":\"edxData\",\"type\":{\"template\":\"BYTES\",\"args\":[]},\"nullable\":false,\"sharedInPrimaryRange\":false,\"description\":\"protobuff encoded data\"}},\"fieldPositionsByName\":{\"gUID\":0,\"lastModifiedTime\":1,\"entityType\":2,\"version\":3,\"client\":4,\"networkMode\":5,\"edxData\":6},\"fileFields\":[],\"nonSecondaryIndexFields\":{},\"secondaryIndexToCorrespondingPrimaryIndexPositions\":{},\"secondaryIndexToCorrespondingSecondaryIndexPositions\":{},\"activeSecondaryIndexes\":{},\"searchCompositeIndexes\":{},\"searchIndexes\":[]}";

    private ADLRepositoryDAOImpl adlRepositoryDAO;

    @Mock
    ADLRepository adlRepository;
    @Mock
    private ADLQuery adlQuery;

    private ADLResultSet<ADLObject> adlResultSet;

    private static ADLSchema adlSchema;
    private static ADLObject adlobjectImpl;

    @BeforeClass
    public static void init() {
        //initial setup
        adlSchema = new Gson().fromJson(DATAWORKSPACE_ADL_SCHEMA, ADLSchema.class);
        adlobjectImpl = new ADLObjectImpl(adlSchema);
    }

    @Before
    public void setUp() throws ADLException {
        adlRepositoryDAO = new ADLRepositoryDAOImpl();
        reset(adlRepository);
        Whitebox.setInternalState(adlRepositoryDAO, "edxDataRepository", adlRepository);
        initObjects();
    }

    @Test
    public void fetchADLRecord() throws ADLException {
        when(adlRepository.createQuery(anyString())).thenReturn(adlQuery);
        when(adlQuery.addEqualsConstraint(anyString(), anyString())).thenReturn(adlQuery);
        when(adlQuery.addRangeConstraint(anyString(), any(BFMTimestamp.class), any(BFMTimestamp.class))).thenReturn(adlQuery);
        when(adlRepository.get(any(ADLQuery.class))).thenReturn(adlResultSet);

        ADLResultSet<ADLObject> adlObject = adlRepositoryDAO.fetchADLRecordInWindow("CRM", "BLUE", EntityType.CONTACT);
        Assert.assertNotNull(adlObject);
    }

    private void initObjects() {
        adlResultSet = new ADLResultSet<ADLObject>() {
            List<ADLObject> iterable = Arrays.asList(adlobjectImpl);
            Iterator<ADLObject> it = iterable.iterator();

            @Override
            public ADLObject getNext() {
                return it.next();
            }

            @Override
            public boolean hasNext() {
                return it.hasNext();
            }
        };
    }
}
