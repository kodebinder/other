package com.bfm.aap.privatemarkets.crm.loader.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.powermock.reflect.Whitebox;

import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.InvestorResponse;
import com.bfm.aap.pmdx.proto.util.ProtoJsonHelper;
import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMResponseStatusEnum;
import com.bfm.aap.privatemarkets.crm.loader.integration.gateway.InvestorInverseProcessingGateway;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorInverseMessage;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@MockitoSettings(strictness = Strictness.LENIENT)
@ExtendWith({MockitoExtension.class})
public class ProcessInvestorNotificationTest {

	@Spy
	@InjectMocks
	private ProcessInvestorNotification processInvestorNotification;

	@Mock
	private InvestorInverseProcessingGateway investorInverseProcessingGateway;

	@Mock
	private CRMThirdPartyMapperService crmThirdPartyMapperService;

	@Test
	public void testProcess() throws Exception {
		String user = RandomStringUtils.randomAlphabetic(5);
		CRMLoaderResponse loaderResponse = CRMLoaderResponse.newBuilder()
			.setStatus(CRMResponseStatusEnum.FULL_SUCCESS)
			.setMessage(ProtoJsonHelper.convertToJson(Investor.getDefaultInstance()))
			.build();

		when(investorInverseProcessingGateway.mapEfrontInvestor(any(CoreInvestorInverseMessage.class))).thenReturn(loaderResponse);

		processInvestorNotification.process(1234, user);

		verify(investorInverseProcessingGateway).mapEfrontInvestor(any(CoreInvestorInverseMessage.class));
	}

	@Test
	public void testProcess_failure() {
		String user = RandomStringUtils.randomAlphabetic(5);
		Exception error = new Exception("Error processing");
		CRMLoaderResponse loaderResponse = CRMLoaderResponse.newBuilder()
			.setStatus(CRMResponseStatusEnum.ERROR)
			.setMessage(error.getMessage())
			.build();

		when(investorInverseProcessingGateway.mapEfrontInvestor(any(CoreInvestorInverseMessage.class))).thenReturn(loaderResponse);

		try {
			processInvestorNotification.process(1234, user);
		} catch (Exception ex) {
			assertEquals(ex.getMessage(), error.getMessage());
		}
		verify(investorInverseProcessingGateway).mapEfrontInvestor(any(CoreInvestorInverseMessage.class));
	}

	@Test
	public void testGetInvestorResponseFutures() throws Exception {
		List<String> eFrontId = Arrays.asList("ABC12","345GD56");

		Whitebox.setInternalState(processInvestorNotification, "processNotificationExecutorService", Executors.newFixedThreadPool(5 ));

		assertNotNull(processInvestorNotification.getInvestorResponseFutures(eFrontId));

	}

	@Test
	public void testGetInvestorResponseFutures_withoout_crmmapping() throws Exception {
		List<String> eFrontId = Arrays.asList("ABC12","345GD56");

		Whitebox.setInternalState(processInvestorNotification, "processNotificationExecutorService", Executors.newFixedThreadPool(5 ));

		doReturn(-1).when(crmThirdPartyMapperService).lookUp(anyString(), any(ThirdPartyMappingEnum.class));

		assertNotNull(processInvestorNotification.getInvestorResponseFutures(eFrontId));
	}

	@Test
	public void testGetInvestorResponseFutures_throws_excption() throws Exception {
		List<String> eFrontId = Arrays.asList("ABC12","345GD56");

		Whitebox.setInternalState(processInvestorNotification, "processNotificationExecutorService", Executors.newFixedThreadPool(5 ));

		assertNotNull(processInvestorNotification.getInvestorResponseFutures(eFrontId));
	}

	@Test
	public void testGetInvestorResponsesFromFutures(){
		Future<InvestorResponse.Builder> investorResponseBuilderFuture = CompletableFuture.completedFuture(InvestorResponse.newBuilder());
		List<Future<InvestorResponse.Builder>> investorResponseBuilderFutures = new ArrayList<>();
		investorResponseBuilderFutures.add(investorResponseBuilderFuture);

		assertNotNull(processInvestorNotification.getInvestorResponsesFromFutures(investorResponseBuilderFutures));
	}

	@Test
	public void testGetInvestorResponsesFromFutures_throw_exception(){
		Future<InvestorResponse.Builder> investorResponseBuilderFuture = CompletableFuture.completedFuture(InvestorResponse.newBuilder());
		List<Future<InvestorResponse.Builder>> investorResponseBuilderFutures = new ArrayList<>();
		investorResponseBuilderFutures.add(investorResponseBuilderFuture);

		assertNotNull(processInvestorNotification.getInvestorResponsesFromFutures(investorResponseBuilderFutures));
	}
}