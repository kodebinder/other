package com.bfm.aap.privatemarkets.crm.loader.api;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.bfm.aap.pmdx.hub.service.PrivateMarketsDXHubService;
import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.CompanyResponse;
import com.bfm.aap.pmdx.model.Contact;
import com.bfm.aap.pmdx.model.ContactResponse;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.InvestorAccount;
import com.bfm.aap.pmdx.model.InvestorAccountResponse;
import com.bfm.aap.pmdx.model.InvestorResponse;
import com.bfm.aap.pmdx.model.User;
import com.bfm.aap.pmdx.model.util.EntityInfo;
import com.bfm.aap.privatemarkets.common.crm.model.CRMLoaderResponse;
import com.bfm.aap.privatemarkets.common.crm.model.CRMResponseStatusEnum;
import com.bfm.aap.privatemarkets.crm.loader.integration.gateway.CompanyProcessingGateway;
import com.bfm.aap.privatemarkets.crm.loader.integration.gateway.ContactProcessingGateway;
import com.bfm.aap.privatemarkets.crm.loader.integration.gateway.InvestorAccountProcessingGateway;
import com.bfm.aap.privatemarkets.crm.loader.integration.gateway.InvestorProcessingGateway;
import com.bfm.aap.privatemarkets.crm.loader.integration.gateway.UserProcessingGateway;
import com.bfm.aap.privatemarkets.crm.loader.service.ProcessCompanyNotification;
import com.bfm.aap.privatemarkets.crm.loader.service.ProcessContactNotification;
import com.bfm.aap.privatemarkets.crm.loader.service.ProcessInvestorAccountNotification;
import com.bfm.aap.privatemarkets.crm.loader.service.ProcessInvestorNotification;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CRMLoaderServiceTest {
    @InjectMocks
    private CRMLoaderService crmLoaderService;
    @Mock
    private UserProcessingGateway userProcessingGateway;
    @Mock
    private ContactProcessingGateway contactProcessingGateway;
    @Mock
    private CompanyProcessingGateway companyProcessingGateway;
    @Mock
    private InvestorProcessingGateway investorProcessingGateway;
    @Mock
    private InvestorAccountProcessingGateway investorAccountProcessingGateway;
    @Mock
    private CRMThirdPartyMapperService crmThirdPartyMapperService;
    @Mock
    private PrivateMarketsDXHubService privateMarketsDXHubService;
    @Mock
    private ProcessContactNotification processContactNotification;
    @Mock
    private ProcessCompanyNotification processCompanyNotification;
    @Mock
    private ProcessInvestorNotification processInvestorNotification;
    @Mock
    private ProcessInvestorAccountNotification processInvestorAccountNotification;

    @Test
    public void mapCRMUserContactTest() {
        EntityInfo e = EntityInfo.newBuilder().setPrimaryData(false).build();
        CRMLoaderResponse result = crmLoaderService.mapCRMUserContact(User.newBuilder().setEntityInfo(e).build());
        assertEquals(CRMResponseStatusEnum.SKIPPED, result.getStatus());
        verify(userProcessingGateway, never()).processMapCRMUser(any(User.class));

        e = EntityInfo.newBuilder().setPrimaryData(true).build();
        crmLoaderService.mapCRMUserContact(User.newBuilder().setEntityInfo(e).build());
        verify(userProcessingGateway).processMapCRMUser(any(User.class));
    }

    @Test
    public void mapCRMContactTest() {
        EntityInfo e = EntityInfo.newBuilder().setPrimaryData(false).build();
        CRMLoaderResponse result = crmLoaderService.mapCRMContact(Contact.newBuilder().setEntityInfo(e).build());
        assertEquals(CRMResponseStatusEnum.SKIPPED, result.getStatus());
        verify(contactProcessingGateway, never()).processMapCRMContact(any(Contact.class));

        e = EntityInfo.newBuilder().setPrimaryData(true).build();
        crmLoaderService.mapCRMContact(Contact.newBuilder().setEntityInfo(e).build());
//        verify(contactProcessingGateway).processMapCRMContact(any(Contact.class));
    }

    @Test
    public void mapCRMInvestorTest() {
        EntityInfo e = EntityInfo.newBuilder().setPrimaryData(false).build();
        CRMLoaderResponse result = crmLoaderService.mapCRMInvestor(Investor.newBuilder().setEntityInfo(e).build());
        assertEquals(CRMResponseStatusEnum.SKIPPED, result.getStatus());
        verify(investorProcessingGateway, never()).processMapCRMInvestor(any(Investor.class));

        e = EntityInfo.newBuilder().setPrimaryData(true).build();
        crmLoaderService.mapCRMInvestor(Investor.newBuilder().setEntityInfo(e).build());
//        verify(investorProcessingGateway).processMapCRMInvestor(any(Investor.class));
    }

    @Test
    public void mapCRMCompanyTest() {
        EntityInfo e = EntityInfo.newBuilder().setPrimaryData(false).build();
        CRMLoaderResponse result = crmLoaderService.mapCRMCompany(Company.newBuilder().setEntityInfo(e).build());
        assertEquals(CRMResponseStatusEnum.SKIPPED, result.getStatus());
        verify(companyProcessingGateway, never()).processMapCRMCompany(any(Company.class));

        e = EntityInfo.newBuilder().setPrimaryData(true).build();
        crmLoaderService.mapCRMCompany(Company.newBuilder().setEntityInfo(e).build());
//        verify(companyProcessingGateway).processMapCRMCompany(any(Company.class));
    }

    @Test
    public void mapCRMInvestorAccountTest() {
        EntityInfo e = EntityInfo.newBuilder().setPrimaryData(false).build();
        CRMLoaderResponse result = crmLoaderService.mapCRMInvestorAccount(InvestorAccount.newBuilder().setEntityInfo(e).build());
        assertEquals(CRMResponseStatusEnum.SKIPPED, result.getStatus());
        verify(investorAccountProcessingGateway, never()).processMapCRMInvestorAccount(any(InvestorAccount.class));

        e = EntityInfo.newBuilder().setPrimaryData(true).build();
        crmLoaderService.mapCRMCompany(Company.newBuilder().setEntityInfo(e).build());
//        verify(companyProcessingGateway).processMapCRMCompany(any(Company.class));
    }

    @Test
    public void testLoadContactsToEfront() throws Exception {
        when(processContactNotification.process(anyInt(), anyString())).thenReturn(Contact.getDefaultInstance());

        List<Integer> failedEntityIdList = new ArrayList<Integer>(Arrays.asList(1, 2, 3));
        crmLoaderService.loadContactsToEfront(failedEntityIdList, "tsgops");
        verify(processContactNotification, times(3)).process(anyInt(), anyString());
    }

    @Test
    public void testLoadCompaniesToEfront() throws Exception {
        doNothing().when(privateMarketsDXHubService).updateCompany(any(), anyInt());
        when(processCompanyNotification.process(anyInt(), anyString())).thenReturn(Company.getDefaultInstance());

        List<Integer> failedEntityIdList = new ArrayList<Integer>(Arrays.asList(1, 2, 3));
        crmLoaderService.loadCompaniesToEfront(failedEntityIdList, "tsgops");
        verify(processCompanyNotification, times(3)).process(anyInt(), anyString());
    }

    @Test
    public void testLoadInvestorsToEfront() throws Exception {
        when(processInvestorNotification.process(anyInt(), anyString())).thenReturn(Investor.getDefaultInstance());

        List<Integer> failedEntityIdList = new ArrayList<Integer>(Arrays.asList(1, 2, 3));
        crmLoaderService.loadInvestorsToEfront(failedEntityIdList, "tsgops");
        verify(processInvestorNotification, times(3)).process(anyInt(), anyString());
    }

    @Test
    public void testLoadInvestorsAccountsToEfront() throws Exception {
        when(processInvestorAccountNotification.process(anyInt(), anyString())).thenReturn(InvestorAccount.getDefaultInstance());

        //Empty List
        crmLoaderService.loadInvestorAccountsToEfront(Collections.emptyList(), "tsgops");

        List<Integer> failedEntityIdList = new ArrayList<Integer>(Arrays.asList(1, 2, 3));
        crmLoaderService.loadInvestorAccountsToEfront(failedEntityIdList, "tsgops");
        verify(processInvestorAccountNotification, times(3)).process(anyInt(), anyString());
    }

    @Test
    public void testGetContactProtos() throws Exception {
        List<String> eFrontId = Arrays.asList("ABC12", "345GD56");
        when(processContactNotification.getContactResponsesFromFutures(any(List.class))).thenReturn(createContactResponseList());
        List<ContactResponse> contactProtos = (List<ContactResponse>) crmLoaderService.getContactProtos(eFrontId);
        assertEquals(2, contactProtos.size());
    }

    @Test
    public void testGetCompanyProtos() throws Exception {
        List<String> eFrontId = Arrays.asList("ABC12", "345GD56");
        when(processCompanyNotification.getCompanyResponsesFromFutures(any(List.class))).thenReturn(createCompanyResponseList());
        List<CompanyResponse> companyProtos = (List<CompanyResponse>) crmLoaderService.getCompanyProtos(eFrontId);
        assertEquals(2, companyProtos.size());
    }

    @Test
    public void testGetInvestorProtos() throws Exception {
        List<String> eFrontId = Arrays.asList("ABC12", "345GD56");
        when(processInvestorNotification.getInvestorResponsesFromFutures(any(List.class))).thenReturn(createInvestorResponseList());
        List<InvestorResponse> investorProtos = (List<InvestorResponse>) crmLoaderService.getInvestorProtos(eFrontId);
        assertEquals(2, investorProtos.size());
    }

    @Test
    public void testGetInvestorAccountProtos() throws Exception {
        List<String> eFrontId = Arrays.asList("ABC12", "345GD56");
        when(processInvestorAccountNotification.getInvestorAccountResponsesFromFutures(any(List.class))).thenReturn(createInvestorAccountResponseList());
        List<InvestorAccountResponse> investorAccountProtos = (List<InvestorAccountResponse>) crmLoaderService.getInvestorAccountProtos(eFrontId);
        assertEquals(2, investorAccountProtos.size());
    }

    @Test
    public void testGetInvestorAccountProtos_EmptyList() throws Exception {
        List<String> eFrontId = Collections.emptyList();
        when(processInvestorAccountNotification.getInvestorAccountResponsesFromFutures(any(List.class))).thenReturn(Collections.EMPTY_LIST);
        List<InvestorAccountResponse> investorAccountProtos = (List<InvestorAccountResponse>) crmLoaderService.getInvestorAccountProtos(eFrontId);
        assertEquals(0, investorAccountProtos.size());
    }

    private List createContactResponseList() {
        List<ContactResponse> contactResponseList = new ArrayList<>();
        contactResponseList.add(ContactResponse.newBuilder().setData(Contact.newBuilder().setContactId("ABC12").setFirstName("Dummy").build()).build());
        contactResponseList.add(ContactResponse.newBuilder().setData(Contact.newBuilder().setContactId("345GD56").setFirstName("Dummy1").build()).build());
        return contactResponseList;
    }

    private List createCompanyResponseList() {
        List<CompanyResponse> companyResponseList = new ArrayList<>();
        companyResponseList.add(CompanyResponse.newBuilder().setData(Company.newBuilder().setCompanyId("ABC12").build()).build());
        companyResponseList.add(CompanyResponse.newBuilder().setData(Company.newBuilder().setCompanyId("345GD56").build()).build());
        return companyResponseList;
    }

    private List createInvestorResponseList() {
        List<InvestorResponse> investorResponseList = new ArrayList<>();
        investorResponseList.add(InvestorResponse.newBuilder().setData(Investor.newBuilder().setInvestorId("ABC12").build()).build());
        investorResponseList.add(InvestorResponse.newBuilder().setData(Investor.newBuilder().setInvestorId("345GD56").build()).build());
        return investorResponseList;
    }

    private List createInvestorAccountResponseList() {
        List<InvestorAccountResponse> investorResponseList = new ArrayList<>();
        investorResponseList.add(InvestorAccountResponse.newBuilder().setData(InvestorAccount.newBuilder().setInvestorAccountId("ABC12").build()).build());
        investorResponseList.add(InvestorAccountResponse.newBuilder().setData(InvestorAccount.newBuilder().setInvestorAccountId("345GD56").build()).build());
        return investorResponseList;
    }

}
