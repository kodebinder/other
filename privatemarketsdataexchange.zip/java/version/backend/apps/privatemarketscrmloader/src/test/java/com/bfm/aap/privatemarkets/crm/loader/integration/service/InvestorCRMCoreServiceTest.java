package com.bfm.aap.privatemarkets.crm.loader.integration.service;

import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.pmdx.model.Legal;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorMessage;
import com.bfm.aap.privatemarkets.crm.loader.service.CRMLoaderCoreService;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.enums.ThirdPartyMappingEnum;
import com.bfm.aap.privatemarkets.crm.thirdparty.mapper.service.CRMThirdPartyMapperService;
import com.bfm.entitymaster.dto.alias.Alias;
import com.bfm.entitymaster.dto.common.Decode;
import com.bfm.entitymaster.dto.common.ElectronicAddress;
import com.bfm.entitymaster.dto.common.Entity;
import com.bfm.entitymaster.dto.entityattribute.EntityAttribute;
import com.bfm.entitymaster.dto.note.Note;
import com.bfm.entitymaster.dto.organization.OrganizationDetail;
import com.bfm.entitymaster.dto.organization.OrganizationType;
import org.apache.commons.lang.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class InvestorCRMCoreServiceTest {
    @InjectMocks
    private InvestorCRMCoreService investorCRMCoreService;
    @Mock
    private CRMLoaderCoreService crmCoreService;
    @Mock
    private CRMThirdPartyMapperService crmThirdPartyMapperService;

    @Mock
    private List<EntityAttribute> entityAttribute;

    @Mock
    private List<ElectronicAddress> electronicAddresses;

    @Mock
    private List<Alias> aliases;

    @Mock
    private OrganizationDetail organizationDetail;

    @Mock
    private List<Note> notes;

    @Test
    public void populateCRMEntityId_Test() {
        when(crmThirdPartyMapperService.lookUp("222", ThirdPartyMappingEnum.INVESTOR_INVEST)).thenReturn(123);
        when(crmThirdPartyMapperService.lookUp("444", ThirdPartyMappingEnum.USER_INVEST)).thenReturn(345);
        when(crmThirdPartyMapperService.getLoginByEntityId(anyInt())).thenReturn("userLogin");
        Message<CoreInvestorMessage> msg = investorCRMCoreService.populateCRMEntityId(getInvestorMessage());
        assertTrue(msg.getPayload().getOrgEntity().getEntityId() == 123);
        assertTrue("userLogin".equalsIgnoreCase(msg.getPayload().getUser()));
    }

    @Test
    public void handleCoreInvestorCreate_Test() {
        Entity entity = this.getEntity("ABC2 Company");
        entity.setEntityId(222);
        OrganizationDetail org = new OrganizationDetail();
        org.setOrganization(entity);
        when(crmThirdPartyMapperService.lookUp(anyString(), any(ThirdPartyMappingEnum.class))).thenReturn(444);
        when(crmCoreService.createInvestorWithParentOrg(any(Entity.class),
                any(OrganizationType.class),
                any(Decode.class), anyInt(), anyString()))
                .thenReturn(org);
        CoreInvestorMessage cmsg = investorCRMCoreService.handleCoreInvestorCreate(getInvestorMessage());
        assertTrue(cmsg.getOrgEntity().getEntityId() == 222);
        assertTrue(cmsg.getOrgEntity().getEntityName().equals("ABC2 Company"));
    }

    @Test
    public void handleCoreInvestorUpdate_Test() {
        Entity entity = getEntity("ABC Company");
        entity.setEntityId(222);
        OrganizationDetail org = new OrganizationDetail();
        org.setOrganizationType(getOrganizationType("BANK"));
        org.setOrganization(entity);
        Entity masterEntity = getEntity("Master ABC Company");
        masterEntity.setEntityId(444);
        org.setMasterOrganization(masterEntity);
        when(crmCoreService.getOrganizationByIdCRM(anyInt(), anyString())).thenReturn(org);
        when(crmCoreService.updateOrganizationCRM(anyInt(), any(Entity.class), any(OrganizationType.class), anyString())).thenReturn(org);
        CoreInvestorMessage response = investorCRMCoreService.handleCoreInvestorUpdate(getCoreInvestorMessage());
        assertNotNull(response);
        assertTrue(response.getOrgEntity().getEntityId() == 222);
    }

    @Test
    public void handleCoreCompanyUpdate_Test_DifferentType() {
        Entity entity = getEntity("ABC2 Company");
        entity.setEntityId(222);
        OrganizationDetail org = new OrganizationDetail();
        org.setOrganizationType(getOrganizationType("EXCHANGE"));
        org.setOrganization(entity);
        when(crmCoreService.getOrganizationByIdCRM(anyInt(), anyString())).thenReturn(org);
        when(crmCoreService.updateOrganizationCRM(anyInt(), any(Entity.class), any(OrganizationType.class), anyString())).thenReturn(org);
        CoreInvestorMessage response = investorCRMCoreService.handleCoreInvestorUpdate(getCoreInvestorMessage());
        assertNotNull(response);
        assertTrue(response.getOrgEntity().getEntityId() == 222);
    }

    
    public void populateEfrontInvestor_Test() {
        when(crmCoreService.getEntityAttributesByEntityId(anyInt(), anyString())).thenReturn(entityAttribute);
        when(crmCoreService.getElectronicAddressByEntityId(anyInt(), anyString())).thenReturn(electronicAddresses);
        when(crmCoreService.getEntityAliasByEntityIdCRM(anyInt(), anyString())).thenReturn(aliases);
        when(crmCoreService.getOrganizationByIdCRM(anyInt(), anyString())).thenReturn(organizationDetail);
        when(crmCoreService.getNotesByEntityIdCRM(anyInt(), anyString())).thenReturn(notes);
        CoreInvestorInverseMessage coreInvestorInverseMessage = investorCRMCoreService.populateEfrontInvestor(getCoreInvestorInverseMessage());
        assertNotNull(coreInvestorInverseMessage);
        assertNotNull(coreInvestorInverseMessage.getEntityAttributes());
        assertNotNull(coreInvestorInverseMessage.getAliases());
    }

    private Message<CoreInvestorInverseMessage> getCoreInvestorInverseMessage() {
        CoreInvestorInverseMessage msg = new CoreInvestorInverseMessage();
        msg.setCrmInvestorId(12345);
        return MessageBuilder.withPayload(msg).setHeader("user", "userLogin").build();
    }

    private Message<CoreInvestorMessage> getCoreInvestorMessage() {
        CoreInvestorMessage req = getInvestorMessage().getPayload();
        req.getOrgEntity().setEntityId(222);
        return MessageBuilder.withPayload(req).setHeader("user", "userLogin").build();
    }

    private OrganizationType getOrganizationType(String orgType) {
        OrganizationType organizationType = new OrganizationType();
        if (StringUtils.isNotBlank(orgType)) {
            organizationType.setOrganizationType(getDecode(orgType, "Bank"));
        }
        return organizationType;
    }

    private Message<CoreInvestorMessage> getInvestorMessage() {
        CoreInvestorMessage msg = new CoreInvestorMessage();
        Entity entity = getEntity("ABC2 Company");
        Legal legal = Legal.newBuilder().setLegalDomicileCountry("US").build();
        msg.setInvestor(Investor.newBuilder().setCompanyId("444")
                .setInvestorType("BANK").setName("ABC Company").setInvestorId("222").setLegal(legal)
                .setModifiedBy("444")
                .build());
        msg.setOrgEntity(entity);
        msg.setOrganizationType(getOrganizationType("BANK"));
        msg.setCountryDecode(getDecode("US", "United States"));
        msg.setCrmParentCompanyEntityId(444);
        return MessageBuilder.withPayload(msg).setHeader("user", "userLogin").build();
    }

    private Decode getDecode(String code, String decode) {
        Decode d = new Decode();
        d.setCode(code);
        d.setDecode(decode);
        return d;
    }

    private Entity getEntity(String entityName) {
        Entity entity = new Entity();
        entity.setEntityName(entityName);
        entity.setEntityType("O");
        return entity;
    }
}