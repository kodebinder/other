package com.bfm.aap.privatemarkets.crm.loader.integration.service;

import com.bfm.aap.pmdx.model.Company;
import com.bfm.aap.pmdx.model.Investor;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreCompanyInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.model.CoreInvestorInverseMessage;
import com.bfm.aap.privatemarkets.crm.loader.util.DecodeHelper;
import com.bfm.aap.privatemarkets.common.crm.util.EntityMasterDecodeTableConstants;
import com.bfm.entitymaster.dto.alias.Alias;
import com.bfm.entitymaster.dto.common.Decode;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.ArrayList;
import java.util.List;

import static com.bfm.aap.privatemarkets.crm.loader.util.DecodeHelper.getDecode;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

@RunWith(PowerMockRunner.class)
@PrepareForTest({DecodeHelper.class})
public class AliasInverseServiceTest {

    private static final String KNOWN_AS = "AKA";
    private static final String NICKNAME = "NICKNAME";
    private static final String TREASURY_ALIAS = "TSYALIAS";

    @InjectMocks
    private AliasInverseService aliasInverseService;

    @Before
    public void initMocks() {
        mockStatic(DecodeHelper.class);
    }

    @Test
    public void testTranslateToEfrontAliases_Company() {
        CoreCompanyInverseMessage coreCompanyInverseMessage = new CoreCompanyInverseMessage();
        coreCompanyInverseMessage.setAliases(createAlias());
        coreCompanyInverseMessage.setEfrontEntity(Company.newBuilder().build());
        coreCompanyInverseMessage.setCrmCompanyId(12345);
        when(getDecode(EntityMasterDecodeTableConstants.ENTITY_ALIAS_TYPE, "US"))
                .thenReturn(new Decode(KNOWN_AS, "US", 12));
        coreCompanyInverseMessage = aliasInverseService.translateToEfrontAliases(coreCompanyInverseMessage);
        assertTrue(coreCompanyInverseMessage.getEfrontEntity().getKnownAs().equals("contacts"));

        when(getDecode(EntityMasterDecodeTableConstants.ENTITY_ALIAS_TYPE, "US"))
                .thenReturn(new Decode(NICKNAME, "US", 12));
        coreCompanyInverseMessage = aliasInverseService.translateToEfrontAliases(coreCompanyInverseMessage);
        assertTrue(coreCompanyInverseMessage.getEfrontEntity().getShortCode().equals("12345"));

    }

    @Test
    public void testTranslateToEfrontAliases() {
        CoreInvestorInverseMessage coreInvestorInverseMessage = new CoreInvestorInverseMessage();
        coreInvestorInverseMessage.setAliases(createAlias());
        coreInvestorInverseMessage.setEfrontEntity(Investor.newBuilder().build());
        coreInvestorInverseMessage.setCrmInvestorId(12345);
        when(getDecode(EntityMasterDecodeTableConstants.ENTITY_ALIAS_TYPE, "US"))
                .thenReturn(new Decode(KNOWN_AS, "US", 12));
        coreInvestorInverseMessage = aliasInverseService.translateToEfrontAliases(coreInvestorInverseMessage);
        assertTrue(coreInvestorInverseMessage.getEfrontEntity().getLegal().getLegalName().equals("contacts"));

        when(getDecode(EntityMasterDecodeTableConstants.ENTITY_ALIAS_TYPE, "US"))
                .thenReturn(new Decode(NICKNAME, "US", 12));
        coreInvestorInverseMessage = aliasInverseService.translateToEfrontAliases(coreInvestorInverseMessage);
        assertTrue(coreInvestorInverseMessage.getEfrontEntity().getShortCode().equals("12345"));

    }

    private List<Alias> createAlias() {
        List<Alias> aliases = new ArrayList<>();
        Alias alias = new Alias();
        alias.setAliasId(234);
        alias.setAliasName("contacts");
        alias.setAliasType(new Decode("US", KNOWN_AS, 12));
        aliases.add(alias);
        return aliases;
    }
}