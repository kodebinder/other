package com.bfm.aap.privatemarkets.crm.loader.config;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertNotNull;

class CommonConfigTest {

    CommonConfig commonConfig = new CommonConfig();

    @Test
    public void getCircuitBreakerHelperTest() {
        assertNotNull(this.commonConfig.getCircuitBreakerHelper());
    }
}