## PrivateMarketsCRMLoader

#### VM Args

##### The Standard Args

```
-DdefaultWebServer=https://dev.blackrock.com
-DAUTH_METHOD=SERVER
-Dbms.port=5000
-Dmode=Blue
-DBRS.STAT_COLLECTOR_BASE_URL=http://devcxsl001:60026/
-DapplicationName=PrivateCRMLoader
-DBRS.PMDX_BASE_DIR_BLUE=/Users/privatemarketsdataexchange/java/version/backend/libs/privatemarkets-datadictionary/src/main/resources/schema-dir
-Dspring.config.location="file:///Users/PMDX_PROPS/PrivateMarketsCRMLoader_DEV_BLUE.properties"
```

##### Optional
Override BMS Source IDs

```
-DoverrideDXCRMLoaderSourceId=167775
```