You can use Maven to change the version for this POM and its entire hierarchy as follows:
mvn versions:set -DnewVersion= -DgenerateBackupPoms=false
For example:
mvn versions:set -DnewVersion=2.3.0-SNAPSHOT -DgenerateBackupPoms=false