package com.wellpoint.pc2dash.action.medicalCostServiceDetails;

import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.service.medicalCost.ServiceCategory;

public class GetServiceCategoryResponse extends ActionResponse {
	private int id;
	private String text;
	private List<ServiceCategory> children = new ArrayList<ServiceCategory>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public List<ServiceCategory> getChildren() {
		return children;
	}

	public void setChildren(List<ServiceCategory> children) {
		this.children = children;
	}

}
