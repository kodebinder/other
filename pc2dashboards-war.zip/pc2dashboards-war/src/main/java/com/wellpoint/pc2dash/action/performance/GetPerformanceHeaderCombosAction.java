package com.wellpoint.pc2dash.action.performance;

import java.util.List;

import com.google.gson.JsonArray;
import com.google.gson.reflect.TypeToken;
import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.performance.PerformanceFilter;
import com.wellpoint.pc2dash.dto.performance.PerformanceHeaderBean;
import com.wellpoint.pc2dash.dto.performance.ProviderGrpObj;
import com.wellpoint.pc2dash.dto.tinNpi.UserAcsIndicators;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.service.performance.PerformanceHeaderCombosServiceImpl;
import com.wellpoint.pc2dash.util.JsonSerializer;


public class GetPerformanceHeaderCombosAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		PerformanceHeaderCombosServiceImpl service = new PerformanceHeaderCombosServiceImpl();
		GetPerformanceHeaderCombosRequest request = (GetPerformanceHeaderCombosRequest) actionRequest;
		ActionResponse response = new GetPerformanceHeaderCombosResponse();

		//PCMSRequest request = new HashMap<String, String>();
		//		JsonArray userAcsInfo = request.getUserAcsInfoJson();
		List<UserAcsIndicators> userAcsInfo = request.getUserAcsInfoJson();
		StringBuilder provGrpIds = new StringBuilder();

		for (int count = 0; count < userAcsInfo.size(); count++) {

			//			JsonObject obj = userAcsInfo.get(count).getAsJsonObject();
			if (userAcsInfo.size() > 0 && userAcsInfo.size() - 1 != count) {
				provGrpIds.append(userAcsInfo.get(count).getProvGrpId() + ",");
			}
			else {
				provGrpIds.append(userAcsInfo.get(count).getProvGrpId());
			}
		}

		try {

			request.setProvGrpIds(provGrpIds.toString());
			//			//request.setCmpId(request.getCmpId());
			//			request.put("authMethod", request.getAuthMethod());

			List<String> filteredProvGrpIds = filterProvGrpsByKillSwitch(request);
			provGrpIds = new StringBuilder();

			for (int count = 0; count < filteredProvGrpIds.size(); count++) {
				if (filteredProvGrpIds.size() > 0
					&& count != filteredProvGrpIds.size() - 1) {
					provGrpIds.append(filteredProvGrpIds.get(count) + ",");
				}
				else {
					provGrpIds.append(filteredProvGrpIds.get(count));
				}
			}

			request.setProvGrpIds(provGrpIds.toString());

			List<PerformanceHeaderBean> resultList = service.getData(request);
			//			List<ProviderGrpObj> performanceHeaderList = service.getBeanList(resultList);
			JsonArray performanceHeaderList = service.getBeanList(resultList);
			List<ProviderGrpObj> provGrpList =
				(List<ProviderGrpObj>) JsonSerializer.deserialize(performanceHeaderList.toString(), new TypeToken<List<ProviderGrpObj>>() {}.getType());
			List<PerformanceFilter> data = service.getPerformanceFilterList(provGrpList);

			response.setData(data);
			response.setSuccess(true);
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

		return response;
	}

}
