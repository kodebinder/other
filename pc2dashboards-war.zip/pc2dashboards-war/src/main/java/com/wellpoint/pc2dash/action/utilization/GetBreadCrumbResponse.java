package com.wellpoint.pc2dash.action.utilization;

import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.patient.BreadCrumbTreeHierarchy;

public class GetBreadCrumbResponse extends ActionResponse {

	private Collection<BreadCrumbTreeHierarchy> children = new ArrayList<BreadCrumbTreeHierarchy>();
	private String text = ".";
	private String id = "0";

	public Collection<BreadCrumbTreeHierarchy> getChildren() {
		return children;
	}

	public void setChildren(Collection<BreadCrumbTreeHierarchy> children) {
		this.children = children;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
