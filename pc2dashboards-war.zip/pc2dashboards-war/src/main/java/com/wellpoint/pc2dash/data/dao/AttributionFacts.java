package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.action.tooltip.GetPatientDetailRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.patient.AttributionHistory;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;


public class AttributionFacts extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(AttributionFacts.class);

	public boolean read(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void insert(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void update(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void delete(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public Collection<AttributionHistory> getAttributionHistory(GetPatientDetailRequest request) throws Exception {

		Collection<AttributionHistory> result = new ArrayList<AttributionHistory>();

		StringBuilder sql = new StringBuilder()
			.append("select ")
			.append("	af.atrbn_efctv_dt, ")
			.append("	af.atrbn_mthd_cd ")
			.append("from ")
			.append("	atrbn_fact af ")
			.append("	join mstr_cnsmr_fact mcf on (af.atrbn_fact_key = mcf.atrbn_fact_key) ")
			.append("	join poit_user_scrty_acs pusa on ( ")
			.append("		mcf.prov_grp_id = pusa.prov_grp_id ")
			.append("		and case ")
			.append("				when pusa.prov_org_tax_id = '0' then mcf.prov_org_tax_id ")
			.append("				else pusa.prov_org_tax_id ")
			.append("			end = mcf.prov_org_tax_id ")
			.append("	) ")
			.append("where ")
			.append("	pusa.sesn_id = ? ")
			.append("	and pusa.enttlmnt_hash_key = ? ")
			.append("	and mcf.mstr_cnsmr_dim_key = ? ")
			.append("order by ")
			.append("	af.atrbn_efctv_dt ")
			.append("with ur ");

		//		logger.debug("getAttributionHistory SQL: " + sql.toString());

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());
			ps.setString(1, request.getSessionId());
			ps.setString(2, request.getEntitlementId());
			ps.setString(3, request.getMemberKey());

			//logger.debug("sesn_id: " + request.getSessionId());
			//logger.debug("enttlmnt_hash_key: " + request.getEntitlementId());
			//logger.debug("mstr_cnsmr_dim_key: " + request.getMemberKey());

			executeQuery(logger, sql.toString());

			while (rs.next()) {

				AttributionHistory r = new AttributionHistory();
				r.setDateAttributed(getDate(rs, "atrbn_efctv_dt"));
				r.setReasonForAttributionEnd(getString(rs, "atrbn_mthd_cd"));

				result.add(r);
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get attribution history (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}
}
