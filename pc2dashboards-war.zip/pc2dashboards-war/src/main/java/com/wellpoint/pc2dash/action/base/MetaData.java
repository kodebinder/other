package com.wellpoint.pc2dash.action.base;

import java.util.ArrayList;
import java.util.Collection;

public class MetaData {

	private String reportDate;
	private String reportingPeriod;
	private String ratioColumnType;
	private Collection columns;
	private ArrayList<String> lobs; //Used in getSharedSavingsSummary - PCMSP-243
	private boolean displayIndicator;

	public String getRatioColumnType() {
		return ratioColumnType;
	}

	public void setRatioColumnType(String ratioColumnType) {
		this.ratioColumnType = ratioColumnType;
	}

	public Collection getColumns() {
		return columns;
	}

	public void setColumns(Collection columns) {
		this.columns = columns;
	}

	public String getReportingPeriod() {
		return reportingPeriod;
	}

	public void setReportingPeriod(String reportingPeriod) {
		this.reportingPeriod = reportingPeriod;
	}

	public ArrayList<String> getLobDesc() {
		return lobs;
	}

	public void setLobDesc(ArrayList<String> lobDesc) {
		this.lobs = lobDesc;
	}

	public String getReportDate() {
		return reportDate;
	}

	public void setReportDate(String reportDate) {
		this.reportDate = reportDate;
	}

	public boolean isDisplayIndicator() {
		return displayIndicator;
	}

	public void setDisplayIndicator(boolean displayIndicator) {
		this.displayIndicator = displayIndicator;
	}
	
	

}
