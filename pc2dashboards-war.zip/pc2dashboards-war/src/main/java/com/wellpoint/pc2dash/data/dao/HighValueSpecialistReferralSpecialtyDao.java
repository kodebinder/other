package com.wellpoint.pc2dash.data.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.costOpportunity.GetHighValueSpecialistReferralsSpecialtyRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.costOpportunity.HighValueSpecialistReferralsSpecialtyBean;
import com.wellpoint.pc2dash.dto.costOpportunity.MinimumCriteriaBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class HighValueSpecialistReferralSpecialtyDao extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(HighValueSpecialistReferralSpecialtyDao.class);

	private boolean displayDashes = false;
	private boolean displayDashesSummarySpl = false; //PCMSP-6867

	public List<HighValueSpecialistReferralsSpecialtyBean> getData(GetHighValueSpecialistReferralsSpecialtyRequest request, boolean exportFlag, int index, int limit)
		throws Exception {

		List<HighValueSpecialistReferralsSpecialtyBean> result = new ArrayList<HighValueSpecialistReferralsSpecialtyBean>();
		setRowCount(0);

		String dir = request.getSort().get(0).getDirection();
		String masked = "asc".equalsIgnoreCase(dir) ? String.valueOf(Integer.MAX_VALUE) : String.valueOf(Integer.MIN_VALUE); // we want masked values to always be at the bottom, so use either the biggest or smallest value, depending
		String dashesClause =
			" sum(epsd_cnt) < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_SPL_MIN_RFRL' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG') ";
		String multiplePgmCheck_10_Perc = " or  ((SUM(count(distinct smry.BNCHMRK_PCTILE_10_NBR)) over (partition by smry.SUB_MTRC_CD, smry.sub_mtrc_nm)) > 1) ";
		String multiplePgmCheck_90_Perc = " or  ((SUM(count(distinct smry.BNCHMRK_PCTILE_90_NBR)) over (partition by smry.SUB_MTRC_CD, smry.sub_mtrc_nm)) > 1) ";

		MinimumCriteriaBean minCritSpl = new MinimumCriteriaBean("EPSD_CNT", "COC_SPCLTY_CTGRY_SMRY", "COC_SPL_MIN_RFRL", null); //PCMSP-6867

		CommonQueries cq = new CommonQueries(); //PCMSP-6867
		displayDashesSummarySpl = cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request, minCritSpl); //PCMSP-6867

		String dashesClauseSummary = " or ( true = " + displayDashesSummarySpl + ") "; //PCMSP-6867

		StringBuilder query = new StringBuilder()
			.append(" select   c.* ")
			.append(" from   ( ")
			.append("   select   b.*, row_number() over( order by ")
			.append(buildSortClause(request))
			.append(" ) as row_nbr ")
			.append("   from   ( ")
			.append("     select ")
			.append("       a.specialtyName, ")
			.append("       a.specialtyCode, ")
			.append("       a.totalOpportunity, ")
			.append("       a.tenPercentImprovement, ")
			.append("       a.totalOpportunityPMPM, ")
			.append("       a.tenPercentImprovementPMPM, ")
			.append("       a.totalEpisodeCount, ")
			.append("       a.totalHighCostEpisodeCount, ")
			.append("       a.currentPerformanceRate, ")
			.append("       a.percentileBenchmark90, ")
			.append("       a.percentileBenchmark10, ")
			.append("       a.row_cnt as row_cnt, ")
			.append("       a.BNCH_90_CNT, ")
			.append("       a.BNCH_10_CNT, ")
			.append("       a.dsply_dashes ")
			.append("     from  ( ")
			.append("       select ")
			.append("       smry.sub_mtrc_nm as specialtyName, ")
			.append("       smry.sub_mtrc_cd as specialtyCode, ")
			.append(" case when ").append(dashesClause).append(dashesClauseSummary).append(" then ").append(masked)
			.append(" when sum(cost_oprtnty_amt) >= 0 then sum(cost_oprtnty_amt) else 0 end as totalOpportunity, ")
			.append(" case when ").append(dashesClause).append(dashesClauseSummary).append(" then ").append(masked)
			.append(" when sum(cost_oprtnty_10_pctag_amt) >= 0 then cast(sum(cost_oprtnty_10_pctag_amt) as decimal(18,4)) else 0 end as tenPercentImprovement, ")
			.append(" case when ").append(dashesClause).append(dashesClauseSummary).append(" then ").append(masked).append(
				" when sum(cost_oprtnty_amt) >= 0 and ILV.MEM_MNTH  > 0 then cast(sum(cost_oprtnty_amt) as decimal(18,4))/ cast(ILV.MEM_MNTH as decimal (18,4)) else 0.00 end as totalOpportunityPMPM, ")
			.append(" case when ").append(dashesClause).append(dashesClauseSummary).append(" then ").append(masked).append(
				" when sum(cost_oprtnty_10_pctag_amt) >= 0 and ILV.MEM_MNTH  > 0 then ((cast(sum(cost_oprtnty_10_pctag_amt) as decimal(18,4))/ cast( ILV.MEM_MNTH as decimal (18,4)))) else 0.00 end as tenPercentImprovementPMPM, ")
			.append(" sum(epsd_cnt) as totalEpisodeCount, ")
			.append(" sum(hcost_epsd_cnt) as totalHighCostEpisodeCount, ")
			.append(" case when ").append(dashesClause).append(dashesClauseSummary).append(" then ").append(masked).append(
				" when sum(epsd_cnt) > 0 then (100 * ( CAST(sum(hcost_epsd_cnt) as decimal(18,3)) / CAST(sum(epsd_cnt) as decimal(18,3))) ) else 0.000 end as currentPerformanceRate, ")
			.append(" case when ").append(dashesClause).append(dashesClauseSummary).append(multiplePgmCheck_90_Perc).append(" then ").append(masked)
			.append(" else max(smry.BNCHMRK_PCTILE_90_NBR) end as percentileBenchmark90, ")
			.append(" case when ").append(dashesClause).append(dashesClauseSummary).append(multiplePgmCheck_10_Perc).append(" then ").append(masked)
			.append(" else max(smry.BNCHMRK_PCTILE_10_NBR) end as percentileBenchmark10, ")
			.append(" count(*) over () as row_cnt, ")
			.append(" SUM(count(distinct smry.BNCHMRK_PCTILE_90_NBR)) over (partition by smry.SUB_MTRC_CD, smry.sub_mtrc_nm) as BNCH_90_CNT, ")
			.append(" SUM(count(distinct smry.BNCHMRK_PCTILE_10_NBR)) over (partition by smry.SUB_MTRC_CD, smry.sub_mtrc_nm) as BNCH_10_CNT, ")
			.append(" case when ").append(dashesClause).append(dashesClauseSummary).append(" then 'Y' else 'N' end as dsply_dashes  ")
			.append("       from  COC_SPCLTY_CTGRY_SMRY smry ")
			//.append("         join coc_bnchmrk_data a on smry.SUB_MTRC_CD = a.SUB_MTRC_CD ") //PCMSP- 10856
			//.append("         join pgm_dim pi on (smry.pgm_dim_key = pi.pgm_dim_key) ") //PCMSP- 10856
			//.append("           and smry.BNCHMRK_CD=a.BNCHMRK_IND_CD and SUBSTR(PI.PGM_ID,1,2)=A.MRKT_ST_CD AND A.COC_MTRC_CD='SPL' ") //PCMSP- 10856

			.append(" join (select  ")
			.append(" nvl(SUM(MM.MBR_MNTH_12_CNT),0) as MEM_MNTH ")
			.append(" FROM  PAT_SMRY_FACT PSF ")
			.append(" INNER JOIN MSTR_CNSMR_MBR_MNTH_FACT MM ON ")
			.append(" MM.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY ")
			.append(" AND MM.RCRD_STTS_CD = 'ACT' ")
			.append(" AND PSF.ATRBN_STTS_CD = 'ACTIVE' ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and psf.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and psf.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {

			query.append(" and psf.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");

		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and psf.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and psf.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}


		query.append(" ) as ILV on 1=1 ")
			.append("         join  poit_user_scrty_acs pusa on (smry.prov_grp_id = pusa.prov_grp_id and ")
			.append("           case ")
			.append("                      when    pusa.prov_org_tax_id = '0' ")
			.append("                      then    smry.prov_org_tax_id ")
			.append("                      else    pusa.prov_org_tax_id end = smry.prov_org_tax_id) ")
			.append("       where  pusa.sesn_id = ? ")
			.append("       and  pusa.enttlmnt_hash_key = ? ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and smry.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and smry.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and smry.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and smry.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and smry.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}
		if (StringUtil.isNotBlankOrFalse(request.getSpecialtyCode())) {
			query.append(" and smry.SUB_MTRC_CD in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getSpecialtyCode())
				+ ") ");
		}

		query.append("       group by ")
			.append("         smry.sub_mtrc_nm, ")
			.append("         smry.sub_mtrc_cd, ")
			.append("         ILV.MEM_MNTH ")
			.append("     ) as a ")
			.append("   ) as b ")
			.append(" ) as c ")
			.append("where  c.row_nbr between ? and ? ")
			.append(" order by   c.row_nbr  with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());

			buildPreparedStatement(request, i, exportFlag, index, limit);

			executeQuery(logger, query.toString());

			result = convertSelectedRowsToObjects(rs, request, displayDashes, exportFlag);

		}
		catch (Exception e) {

			throw new Exception("Unable to get HighValueSpecialistReferralSpecialtyDao (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;

	}

	private void buildPreparedStatement(GetHighValueSpecialistReferralsSpecialtyRequest request, int i, boolean exportFlag, int index, int limit) throws SQLException {
		int start = 0;
		int stop = 0;
		//PMPM Starts
		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		//PMPM Ends		
		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getSpecialtyCode())) {
			String[] array = request.getSpecialtyCode().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (!exportFlag) {
			start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
			stop = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
		}
		else {
			start = index;
			stop = limit;
		}
		ps.setInt(++i, start + 1);
		ps.setInt(++i, start + stop);
	}

	private List<HighValueSpecialistReferralsSpecialtyBean> convertSelectedRowsToObjects(ResultSet rs, GetHighValueSpecialistReferralsSpecialtyRequest request,
		boolean displayDashes, boolean exportFlag)
		throws SQLException {

		List<HighValueSpecialistReferralsSpecialtyBean> list = new ArrayList<HighValueSpecialistReferralsSpecialtyBean>();


		if (exportFlag) {
			while (rs.next()) {

				HighValueSpecialistReferralsSpecialtyBean item = new HighValueSpecialistReferralsSpecialtyBean();

				item.setSpecialtyName(rs.getString("specialtyName"));
				item.setSpecialtyCode(rs.getString("specialtyCode"));
				/*DEFECT 18622 STARTS 1*/
				String totlEpsdCnt = regexCommafy(rs.getString("totalEpisodeCount"));
				String totlHghCostEpsdCnt = regexCommafy(rs.getString("totalHighCostEpisodeCount"));
				item.setTotalEpisodeCount(totlEpsdCnt);
				item.setTotalHighCostEpisodeCount(totlHghCostEpsdCnt);
				/*DEFECT 18622 ENDS 1*/
				//item.setTotalEpisodeCount(rs.getString("totalEpisodeCount")); //PCMSP-6867
				//item.setTotalHighCostEpisodeCount(rs.getString("totalHighCostEpisodeCount")); //PCMSP-6867

				if (rs.getString("dsply_dashes") != null && rs.getString("dsply_dashes").equalsIgnoreCase(Constants.Y)) {
					displayDashes = true;
				}
				else {
					displayDashes = false;
				}

				if (displayDashes) {

					item.setTotalOpportunity(Constants.DASHES);
					item.setTenPercentImprovement(Constants.DASHES);
					item.setTotalOpportunityPMPM(Constants.DASHES);
					item.setTenPercentImprovementPMPM(Constants.DASHES);
					item.setCurrentPerformanceRate(Constants.DASHES);
					item.setPercentileBenchmark90(Constants.DASHES);
					item.setPercentileBenchmark10(Constants.DASHES);
					item.setSpecialtyNameInd(false);
				}
				else {
					if (rs.getString("totalOpportunity") != null) {
						item.setTotalOpportunity(StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("totalOpportunity").setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
					}
					if (rs.getString("tenPercentImprovement") != null) {
						item.setTenPercentImprovement(
							StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("tenPercentImprovement").setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
					}
					if (rs.getString("totalOpportunityPMPM") != null) {
						item.setTotalOpportunityPMPM(
							StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("totalOpportunityPMPM").setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
					}
					if (rs.getString("tenPercentImprovementPMPM") != null) {
						item.setTenPercentImprovementPMPM(
							StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("tenPercentImprovementPMPM").setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
					}

					if (rs.getString("currentPerformanceRate") != null) {
						item.setCurrentPerformanceRate((rs.getBigDecimal("currentPerformanceRate").intValue() >= 0)
							? StringUtil.convertStringToCommaBigDecimal(rs.getBigDecimal("currentPerformanceRate").setScale(2, BigDecimal.ROUND_HALF_UP).toString(), 2).concat("%")
							: Constants.DASHES);
					}
					if (rs.getString("percentileBenchmark90") != null) {
						item.setPercentileBenchmark90((rs.getShort("BNCH_90_CNT") == Constants.INT_ONE)
							? StringUtil.convertStringToCommaBigDecimal(rs.getBigDecimal("percentileBenchmark90").setScale(2, BigDecimal.ROUND_HALF_UP).toString(), 2).concat("%")
							: Constants.DASHES);
					}
					else {
						item.setPercentileBenchmark90(Constants.DASHES);
					}
					if (rs.getString("percentileBenchmark10") != null) {
						item.setPercentileBenchmark10((rs.getShort("BNCH_10_CNT") == Constants.INT_ONE)
							? StringUtil.convertStringToCommaBigDecimal(rs.getBigDecimal("percentileBenchmark10").setScale(2, BigDecimal.ROUND_HALF_UP).toString(), 2).concat("%")
							: Constants.DASHES);
					}
					else {
						item.setPercentileBenchmark10(Constants.DASHES);
					}
					item.setSpecialtyNameInd(true);
				}

				list.add(item);

				if (getRowCount() == 0) {
					setRowCount(rs.getInt("row_cnt"));
				}
				setTotalExport(rs.getInt("row_cnt"));
			}
		}
		else {
			while (rs.next()) {

				HighValueSpecialistReferralsSpecialtyBean item = new HighValueSpecialistReferralsSpecialtyBean();

				item.setSpecialtyName(rs.getString("specialtyName"));
				item.setSpecialtyCode(rs.getString("specialtyCode"));
				item.setTotalEpisodeCount(rs.getString("totalEpisodeCount")); //PCMSP-6867
				item.setTotalHighCostEpisodeCount(rs.getString("totalHighCostEpisodeCount")); //PCMSP-6867

				if (rs.getString("dsply_dashes") != null && rs.getString("dsply_dashes").equalsIgnoreCase(Constants.Y)) {
					displayDashes = true;
				}
				else {
					displayDashes = false;
				}

				if (displayDashes) {
					item.setTotalOpportunity(Constants.DASHES);
					item.setTenPercentImprovement(Constants.DASHES);
					item.setTotalOpportunityPMPM(Constants.DASHES);
					item.setTenPercentImprovementPMPM(Constants.DASHES);
					item.setCurrentPerformanceRate(Constants.DASHES);
					item.setPercentileBenchmark90(Constants.DASHES);
					item.setPercentileBenchmark10(Constants.DASHES);
					item.setSpecialtyNameInd(false);
				}
				else {
					if (rs.getString("currentPerformanceRate") != null)
						item.setCurrentPerformanceRate(rs.getBigDecimal("currentPerformanceRate").setScale(2, BigDecimal.ROUND_HALF_UP).toString());

					if (rs.getShort("BNCH_10_CNT") == Constants.INT_ONE) {
						item.setPercentileBenchmark10(rs.getBigDecimal("percentileBenchmark10").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
					}
					else {
						item.setPercentileBenchmark10(Constants.DASHES);
					}
					if (rs.getShort("BNCH_90_CNT") == Constants.INT_ONE) {
						item.setPercentileBenchmark90(rs.getBigDecimal("percentileBenchmark90").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
					}
					else {
						item.setPercentileBenchmark90(Constants.DASHES);
					}

					if (rs.getString("tenPercentImprovement") != null)
						item.setTenPercentImprovement(rs.getBigDecimal("tenPercentImprovement").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
					if (rs.getString("tenPercentImprovementPMPM") != null)
						item.setTenPercentImprovementPMPM(rs.getBigDecimal("tenPercentImprovementPMPM").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
					if (rs.getString("totalOpportunity") != null)
						item.setTotalOpportunity(rs.getBigDecimal("totalOpportunity").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
					if (rs.getString("totalOpportunityPMPM") != null)
						item.setTotalOpportunityPMPM(rs.getBigDecimal("totalOpportunityPMPM").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
					item.setSpecialtyNameInd(true);
				}

				list.add(item);

				if (getRowCount() == 0) {
					setRowCount(rs.getInt("row_cnt"));
				}

			}

		}

		return list;

	}

	private String buildSortClause(GetHighValueSpecialistReferralsSpecialtyRequest request) {

		StringBuilder query = new StringBuilder();
		String defaultColumn = " totalOpportunity ";
		String defaultSort = defaultColumn + " desc ";

		if (null != request.getSort()) {

			for (QuerySort sort : request.getSort()) {

				String dir = sort.getDirection().replaceAll("\"", "");
				String property = sort.getProperty();

				if (property.equals("specialtyName")) {
					query.append(" specialtyName " + dir + ", " + defaultSort);
				}
				else if (property.equals("specialtyCode")) {
					query.append(" specialtyCode " + dir + ", " + defaultSort);
				}
				else if (property.equals("totalOpportunity")) {
					query.append(" totalOpportunity " + dir + ", " + defaultSort);
				}
				else if (property.equals("tenPercentImprovement")) {
					query.append(" tenPercentImprovement " + dir + ", " + defaultSort);
				}
				else if (property.equals("totalOpportunityPMPM")) {
					query.append(" totalOpportunityPMPM " + dir + ", " + defaultSort);
				}
				else if (property.equals("tenPercentImprovementPMPM")) {
					query.append(" tenPercentImprovementPMPM " + dir + ", " + defaultSort);
				}
				else if (property.equals("totalEpisodeCount")) {
					query.append(" totalEpisodeCount " + dir + ", " + defaultSort);
				}
				else if (property.equals("totalHighCostEpisodeCount")) {
					query.append(" totalHighCostEpisodeCount " + dir + ", " + defaultSort);
				}
				else if (property.equals("currentPerformanceRate")) {
					query.append(" currentPerformanceRate " + dir + ", " + defaultSort);
				}
				else if (property.equals("percentileBenchmark90")) {
					query.append(" percentileBenchmark90 " + dir + ", " + defaultSort);
				}
				else if (property.equals("percentileBenchmark10")) {
					query.append(" percentileBenchmark10 " + dir + ", " + defaultSort);
				}
				else {
					query.append(defaultColumn + dir);
				}
			}

		}
		else {

		}

		return query.toString();

	}

	/*DEFECT 18622 STARTS 2*/
	private String regexCommafy(String inputNum)
    {
        String regex = "(\\d)(?=(\\d{3})+$)";
        String [] splittedNum = inputNum.split("\\.");
        if(splittedNum.length==2)
        {
            return splittedNum[0].replaceAll(regex, "$1,")+"."+splittedNum[1];
        }
        else
        {
            return inputNum.replaceAll(regex, "$1,");
        }
    }
	/*DEFECT 18622 ENDS 1*/

	@Override
	public boolean read(Dto o) throws Exception {
		
		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {
		
		
	}

	@Override
	public void update(Dto o) throws Exception {
		
		
	}

	@Override
	public void delete(Dto o) throws Exception {
		
		
	}


}
