package com.wellpoint.pc2dash.action.costOpportunity;

import java.util.List;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.data.dao.COCAverageCostPerRxDrugClassFilter;
import com.wellpoint.pc2dash.dto.pharmacy.DrugClassFilter;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.ErrorProperties;

public class GetAverageCostPerRxDrugClassFilterAction extends Action {
	
	List<DrugClassFilter> resultList;
	ActionResponse response = new GetAverageCostPerRxDrugClassFilterResponse();
	ErrorProperties err = ErrorProperties.getInstance();
	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetAverageCostPerRxDrugClassFilterAction.class);

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetAverageCostPerRxDrugClassFilterRequest request = (GetAverageCostPerRxDrugClassFilterRequest) actionRequest;
		COCAverageCostPerRxDrugClassFilter dao = new COCAverageCostPerRxDrugClassFilter();

		try {
			resultList = dao.getAverageCostPerRxDrugDetails(request);

			if (null == resultList || resultList.isEmpty()) {
				response.setMessage(err.getProperty("successNoData"));
			}
			else {
				response.setData(resultList);
				response.setMessage(err.getProperty("successful"));
			}

			response.setSuccess(true);
			return response;
		}
		catch (Exception pe) {

			logger.error("Unable to get GetDrugClassFilter.", pe);

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

	}


}
