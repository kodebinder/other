package com.wellpoint.pc2dash.data.dao;

public class DrillDownLinkSettings {

	private boolean enableDrillDownLink; // will be true if "first condition" (prov_grp_id and pgm_id have atrbn_stts_cd of 'ACTIVE') is true

	private boolean enableDrillDownQualityLink;
	private boolean enableDrillDownASALink;
	private boolean enableDrillDownAvoidableERLink;
	private boolean enableDrillDownGDRLink;
	private boolean enableDrillDownReadmissionLink;
	private boolean enableDrilldownLabLink;


	public boolean isEnableDrillDownLink() {
		return enableDrillDownLink;
	}

	public void setEnableDrillDownLink(boolean enableDrillDownLink) {
		this.enableDrillDownLink = enableDrillDownLink;
	}

	public boolean isEnableDrillDownQualityLink() {
		return enableDrillDownQualityLink;
	}

	public void setEnableDrillDownQualityLink(boolean enableDrillDownQualityLink) {
		this.enableDrillDownQualityLink = enableDrillDownQualityLink;
	}

	public boolean isEnableDrillDownASALink() {
		return enableDrillDownASALink;
	}

	public void setEnableDrillDownASALink(boolean enableDrillDownASALink) {
		this.enableDrillDownASALink = enableDrillDownASALink;
	}

	public boolean isEnableDrillDownAvoidableERLink() {
		return enableDrillDownAvoidableERLink;
	}

	public void setEnableDrillDownAvoidableERLink(boolean enableDrillDownAvoidableERLink) {
		this.enableDrillDownAvoidableERLink = enableDrillDownAvoidableERLink;
	}

	public boolean isEnableDrillDownGDRLink() {
		return enableDrillDownGDRLink;
	}

	public void setEnableDrillDownGDRLink(boolean enableDrillDownGDRLink) {
		this.enableDrillDownGDRLink = enableDrillDownGDRLink;
	}

	public boolean isEnableDrillDownReadmissionLink() {
		return enableDrillDownReadmissionLink;
	}

	public void setEnableDrillDownReadmissionLink(
		boolean enableDrillDownReadmissionLink) {
		this.enableDrillDownReadmissionLink = enableDrillDownReadmissionLink;
	}

	/**
	 * @return the enableDrilldownLabLink
	 */
	public boolean isEnableDrilldownLabLink() {
		return enableDrilldownLabLink;
	}

	/**
	 * @param enableDrilldownLabLink the enableDrilldownLabLink to set
	 */
	public void setEnableDrilldownLabLink(boolean enableDrilldownLabLink) {
		this.enableDrilldownLabLink = enableDrilldownLabLink;
	}

	public boolean isEnableDrillDownLabLink() {
		// TODO Auto-generated method stub
		return false;
	}

}
