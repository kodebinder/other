package com.wellpoint.pc2dash.action.tap.patients;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetConditionPopulationHotSpottersResponse extends ActionResponse {

}
