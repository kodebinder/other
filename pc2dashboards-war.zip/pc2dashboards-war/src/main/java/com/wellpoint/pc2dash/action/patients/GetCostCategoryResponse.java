package com.wellpoint.pc2dash.action.patients;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetCostCategoryResponse extends ActionResponse {

}
