package com.wellpoint.pc2dash.action.careOpportunities;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.careOpportunities.CareOppRatesBean;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.population.CareOpportunitiesRateExport;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.careopportunities.CareopportunitiesRateServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetCareOpportunitiesRateAction extends Action {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetCareOpportunitiesRateAction.class);

	@SuppressWarnings("unchecked")
	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		List<CareOppRatesBean> resultList = null;

		ActionResponse response = new GetCareOpportunitiesRateResponse();
		GetCareOpportunitiesRateRequest request = (GetCareOpportunitiesRateRequest) actionRequest;
		ErrorProperties err = ErrorProperties.getInstance();

		List<String> filteredProvGrpList = new ArrayList<String>();
		try {

			// preserve dataMap logic
			removeLobPgmPrefixes(request);
			prepareChronicCareGapMap(request);

			//Kill switch check on Provider groups
			if (StringUtils.isNotBlank(request.getCmpId())) {
				filteredProvGrpList = filterProvGrpsByKillSwitch(request);
			}
			//Clinical access check on provider groups
			if (null != filteredProvGrpList && filteredProvGrpList.size() > 0) {
				request.setProvGrpIdsWithoutClinicalCheck(StringUtils.join(filteredProvGrpList, ','));
				filteredProvGrpList = filterProvGrpsByClinicalInd(request, filteredProvGrpList);
			}

			CareopportunitiesRateServiceImpl service = new CareopportunitiesRateServiceImpl();
			if (null != filteredProvGrpList && !filteredProvGrpList.isEmpty()) {
				request.setProvGrpIds(StringUtils.join(filteredProvGrpList, ','));
				request.setGrpInd(Constants.GRP_IND_N);

				CommonQueries cq = new CommonQueries();
				request.setSuppression(cq.getActiveSuppressionForSelectComponents(request));
				if (!StringUtil.isExportDest(request.getDest())) {
					resultList = service.getData(request);
				}
				else {
					CareOpportunitiesRateExport ex = new CareOpportunitiesRateExport(request);
					ExportProcessor.getInstance().submit(ex);
				}
			}

			if (null != resultList && !resultList.isEmpty()) {
				response.setData(resultList);
				response.setMessage(err.getProperty("successful"));
			}
			else {
				response.setMessage(err.getProperty("successNoData"));
			}

			logger.debug("data returned");
			response.setSuccess(true);
			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}
}
