package com.wellpoint.pc2dash.action.scoreCard;

import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;

public class ExportScorecardRequest extends PerformanceManagementRequest {

	protected String composites;

	public String getComposites() {
		return composites;
	}

	public void setComposites(String composites) {
		this.composites = composites;
	}

	//	private String qualityGateRequest; // the json from the UI (i.e. qualityGateRequest:{"qualityGateInd":0,"qualityGate":"N/A","qualityScore":"N/A"})
	//	private QualityGateRequest qualityGateRequest;
	//	
	//	public String getQualityGate() {
	//		return qualityGateRequest;
	//	}
	//	public void setQualityGate(String qualityGateRequest) {
	//		this.qualityGate = qualityGateRequest;
	//	}
	//	public QualityGateRequest getQualityGateRequest() {
	//		return qualityGateRequest;
	//	}
	//	public void setQualityGateRequest(QualityGateRequest qualityGateRequest) {
	//		this.qualityGateRequest = qualityGateRequest;
	//	}

}
