package com.wellpoint.pc2dash.action.patients;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.Pc2ResponseGenerator;
import com.wellpoint.pc2dash.dto.patient.ChronicGapScoreBean;
import com.wellpoint.pc2dash.exception.PC2Exception;
import com.wellpoint.pc2dash.service.patient.ChronicGapScoreServiceImpl;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.ReferralBeanConstants;

public class GetChronicCareGapAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		ChronicGapScoreBean resultObject;
		GetChronicGapScoreRequest request = (GetChronicGapScoreRequest) actionRequest;
		GetChronicGapScoreResponse response = new GetChronicGapScoreResponse();
		ChronicGapScoreServiceImpl service = new ChronicGapScoreServiceImpl();
		ErrorProperties err = ErrorProperties.getInstance();

		try {
			buildProvGrpIdList(request);
			resultObject = service.getData(request);
			prepareResponse(resultObject, response, err);
		}
		catch (PC2Exception pe) {
			Pc2ResponseGenerator.buildErrorResponse(pe, response, pe.getErrorCode());
		}
		return response;
	}

	private void prepareResponse(ChronicGapScoreBean resultObject, GetChronicGapScoreResponse response,
		ErrorProperties err) {
		if (null != resultObject) {
			response.setText(resultObject.getText()); // Currently hardcoded to what UI expects
			response.setId(resultObject.getId()); // Currently hardcoded to what UI expects
			response.getChildren().addAll(resultObject.getChildren());
			response.setSuccess(true);
			if (resultObject.getChildren().isEmpty()) {
				response.setMessage(err.getProperty(ReferralBeanConstants.SUCCESSNODATA));
			}
			else {
				response.setMessage(err.getProperty(ReferralBeanConstants.SUCCESS));
			}
		}
		else {
			response.setMessage(err.getProperty(ReferralBeanConstants.SUCCESSNODATA));
		}
	}

}
