package com.wellpoint.pc2dash.data.dao;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;
import com.wellpoint.pc2dash.dto.scorecard.ScorecardMeasureBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;

public class MedicaidScorecardMeasureFactsDao extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(MedicaidScorecardMeasureFactsDao.class);

	public boolean read(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void insert(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void update(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void delete(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}


	/**
	 * @param entitlementId
	 * @param provGrpId
	 * @param compositeId
	 * @param subCompositeId
	 * @param msrmntPrdStrtDt
	 * @param msrmntPrdEndDt
	 * @param bslnPrdStrtDt
	 * @param bslnPrdEndDt
	 * @return
	 * @throws Exception
	 */
	public Collection<ScorecardMeasureBean> getScorecardMedicaidMeasuresQuery(PerformanceManagementRequest request) throws Exception {

		Collection<ScorecardMeasureBean> resultList = new ArrayList<ScorecardMeasureBean>();
		ScorecardMeasureBean measureBean = null;

		StringBuilder query = new StringBuilder()
			//.append(" select distinct z.* from ( " 
			.append(" select "
				+ "smhd.CMPST_DEFN_ID, "
				+ "smhd.CMPST_NM, "
				+ "   msr.MSR_DSPLY_NM, "
				+ "   msr.MSR_DIM_KEY ,"
				+ "  cosf1.MSR_NMRTR_NBR AS COSF_MSR_NMRTR_NBR,"
				+ "  cosf1.MSR_DNMNTR_NBR AS COSF_MSR_DNMNTR_NBR, "
				+ "  cpgsf1.MSR_NMRTR_NBR AS CPGSF_MSR_NMRTR_NBR, "
				+ "  cpgsf1.MSR_DNMNTR_NBR AS CPGSF_MSR_DNMNTR_NBR,"
				+ "	  EF.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT, "
				+ "	  EF.ACHVD_TRNCH_LVL_CD, "
				+ " spgmhf.TOP_X_NBR,"
				+ " smhd.CMPST_TYPE_DESC, md.mdpnl_id "
				/*+ " , rank() over (partition by ef.prov_grp_dim_key, ef.pgm_dim_key, ef.msrmnt_prd_strt_dt order by case when ef.sor_dtm > pgpa1.prov_grp_pnl_assn_trmntn_dt then 999 " 
				+" else timestampdiff(16, pgpa1.prov_grp_pnl_assn_trmntn_dt - ef.sor_dtm) end, pgpa1.prov_grp_pnl_assn_trmntn_dt desc) as pnl_rank "*/
				+ "from "
				+ " SCRCRD_PGM_MSR_HRCHY_FACT spgmhf "
				+ " INNER JOIN  ERNCNTR_FACT ef"
				+ " 			on  ef.mnth_id = spgmhf.mnth_id "
				+ " AND EF.PGM_DIM_KEY = SPGMHF.PGM_DIM_KEY "
				+ "  AND EF.MSRMNT_PRD_STRT_DT = SPGMHF.MSRMNT_PRD_STRT_DT "
				+ "  AND EF.TRNCH_DEFN_DIM_KEY = SPGMHF.TRNCH_DEFN_DIM_KEY "
				+ "      INNER JOIN SCRCRD_MSR_HRCHY_DIM smhd "
				+ "            on spgmhf.SCRCRD_MSR_HRCHY_DIM_KEY = smhd.SCRCRD_MSR_HRCHY_DIM_KEY "
				+ "      INNER JOIN MSR_DIM  msr "
				+ "            on smhd.msr_dim_key = msr.msr_dim_key"
				+ " and SPGMHF.msrmnt_prd_strt_dt >= msr.MSR_EFCTV_DT and SPGMHF.msrmnt_prd_end_dt <= msr.MSR_TRMNTN_DT"
				+ "      INNER JOIN PGM_DIM pgm "
				+ "      on spgmhf.PGM_DIM_key = pgm.PGM_DIM_KEY"
				//Release 1.9 ephc intake id 3530 ad90348
				//commented | EPHC Intake Id - 3530 | duplicate measures appearing during export
				/*+ " inner join prov_grp_pgm_lob_fact pgplf on ef.prov_grp_dim_key = pgplf.prov_grp_dim_key and ef.pgm_dim_key= pgplf.pgm_dim_key "
				+ " inner join Lob_dim ld on ld.lob_dim_key = pgplf.lob_dim_key "*/
				+ " inner join PROV_GRP_DIM as PGD on ef.prov_grp_dim_key=pgd.prov_grp_dim_key "
				/*+ " inner join "
				+"   (Select pgpa.prov_grp_dim_key, pgpa.pgm_dim_key, pgpa.mdpnl_dim_key, pgpa.PROV_GRP_PNL_ASSN_EFCTV_DT, pgpa.prov_grp_pnl_assn_trmntn_dt  "
				+"   FROM prov_grp_pnl_assn_fact pgpa "
				+"   group by pgpa.prov_grp_dim_key, pgpa.pgm_dim_key, pgpa.mdpnl_dim_key, pgpa.PROV_GRP_PNL_ASSN_EFCTV_DT, pgpa.prov_grp_pnl_assn_trmntn_dt) pgpa1 "
				+"   on pgm.PGM_DIM_KEY=pgpa1.PGM_DIM_KEY " 
				//  + " and spgmhf.msrmnt_prd_strt_dt >= pgpa1.PROV_GRP_PNL_ASSN_EFCTV_DT  "      //commented based  on the confirmation from data team since the PG can come in middle of MP
				+"   inner join prov_grp_dim pgd on pgpa1.prov_grp_dim_key=pgd.prov_grp_dim_key "
				+ " and ef.prov_grp_dim_key = pgd.prov_grp_dim_key " 
				//  +"   and pgd.prov_grp_id = ? and pgd.PROV_GRP_TRMNTN_DT >= pgpa1.prov_grp_pnl_assn_trmntn_dt "
				+ " and pgd.prov_grp_id = ?  and ( ef.msrmnt_prd_strt_dt <= pgpa1.prov_grp_pnl_assn_trmntn_dt and ef.msrmnt_prd_end_dt >= pgpa1.PROV_GRP_PNL_ASSN_EFCTV_DT ) "*/
				+ "	inner join mdpnl_dim md on 	ef.mdpnl_dim_key = md.mdpnl_dim_key "
				+ "    LEFT OUTER JOIN "
				+ "      (select cosf.PGM_DIM_key,cosf.MSRMNT_PRD_STRT_DT,cosf.SCRCRD_MSR_HRCHY_DIM_KEY,"
				+ "      cosf.MSR_NMRTR_NBR,cosf.MSR_DNMNTR_NBR, POD.PROV_ORG_DIM_KEY, pgd.PROV_GRP_DIM_KEY"
				+ "            FROM CMPLNC_ORG_SMRY_FACT cosf  "
				+ "            inner join PROV_ORG_DIM  pod"
				+ "           on cosf.PROV_ORG_DIM_KEY = pod.PROV_ORG_DIM_KEY "
				+ "                  and pod.PROV_ORG_DIM_KEY = ? " // Result of NF31: PROV_ORG_TAX_ID changed to PROV_ORG_DIM_KEY
				+ "            inner join PROV_GRP_DIM pgd "
				+ "            on cosf.PROV_GRP_DIM_KEY = pgd.PROV_GRP_DIM_KEY "
				+ "                  and pgd.PROV_GRP_ID = ? and cosf.ANLYSS_AS_OF_DT= ?) cosf1 "
				+ "      on (spgmhf.PGM_DIM_key = cosf1.PGM_DIM_key "
				+ "      and spgmhf.MSRMNT_PRD_STRT_DT = cosf1.MSRMNT_PRD_STRT_DT  "
				+ "      and spgmhf.SCRCRD_MSR_HRCHY_DIM_KEY = cosf1.SCRCRD_MSR_HRCHY_DIM_KEY ) "
				+ "    LEFT OUTER JOIN "
				+ "      (select cpgsf.MSR_NMRTR_NBR, cpgsf.MSR_DNMNTR_NBR, cpgsf.MDPNL_DIM_KEY, "
				+ "            cpgsf.SCRCRD_MSR_HRCHY_DIM_KEY,pgd.PROV_GRP_DIM_KEY, cpgsf.PGM_DIM_key, cpgsf.MSRMNT_PRD_STRT_DT "
				+ "            FROM CMPLNC_PROV_GRP_SMRY_FACT  cpgsf "
				+ "            inner join PROV_GRP_DIM pgd "
				+ "            on cpgsf.PROV_GRP_DIM_KEY = pgd.PROV_GRP_DIM_KEY "
				+ "                  and pgd.PROV_GRP_ID = ? and cpgsf.ANLYSS_AS_OF_DT= ? ) cpgsf1 "
				+ "            on (spgmhf.PGM_DIM_key = cpgsf1.PGM_DIM_key "
				+ "            and spgmhf.MSRMNT_PRD_STRT_DT = cpgsf1.MSRMNT_PRD_STRT_DT "
				+ "            and spgmhf.SCRCRD_MSR_HRCHY_DIM_KEY = cpgsf1.SCRCRD_MSR_HRCHY_DIM_KEY ) "
				+ " where "
				+ "      pgm.PGM_ID = ? "
				+ "      and smhd.CMPST_DEFN_ID = ? "
				+ "      and spgmhf.MSRMNT_PRD_STRT_DT = ? "
				+ "      and spgmhf.PGM_LOB_TYPE_CD = ? "
				+ "    and pgd.prov_grp_id = ? ");
		//		+ "		and md.MDPNL_ID=  ?	");
		/*+ " AND pgplf.lob_dim_key in ( " );
		int count = 0;
		List<String> lobDimKeys = Arrays.asList(request.get("lobDimKeys").split(","));
		for(String lobDimKey:lobDimKeys){
		count++;
		query.append(" "+new BigInteger(lobDimKey)+" ");
		if(count<lobDimKeys.size()){
		query.append(", ");
		}
		}
		query.append(" ) "); */

		if (null != Constants
			.getQuarterName(request.getMeasurementInterval())) {
			if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
				query.append(" AND ef.BSLN_SCRCRD_IND = ? ");
			}
			else {
				query.append(" AND ef.QTR_ID = ? ");
			}
		}
		else {
			//query.append(" AND spgmhf.MNTH_ID = (SELECT MAX(MNTH_ID) FROM SCRCRD_PGM_MSR_HRCHY_FACT) ");
			query.append(" AND EF.MNTH_ID = (SELECT MAX(EF.MNTH_ID) FROM ERNCNTR_FACT EF INNER JOIN "
				+ " (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT FROM SCRCRD_PGM_MSR_HRCHY_FACT WHERE "
				+ " PGM_DIM_KEY=(SELECT PGM_DIM_KEY FROM PGM_DIM WHERE PGM_ID= ? ) and MSRMNT_PRD_STRT_DT=? GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM "
				+ " ON EF.PGM_DIM_KEY=SC_PGM.PGM_DIM_KEY AND EF.MSRMNT_PRD_STRT_DT=SC_PGM.MSRMNT_PRD_STRT_DT) ");
		}
		/*query.append(" ) z where z.pnl_rank = 1 ") ;
		query.append("ORDER BY  z.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT DESC,z.TOP_X_NBR , z.CPGSF_MSR_DNMNTR_NBR DESC ");*/
		query.append("ORDER BY  EF.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT DESC,spgmhf.TOP_X_NBR , cpgsf1.MSR_DNMNTR_NBR DESC, cpgsf1.MSR_NMRTR_NBR DESC, EF.ACHVD_TRNCH_LVL_CD DESC ");

		query = StringUtil.appendWithUr(query);

		//		logger.debug("getScorecardMedicaidMeasuresQuery SQL: " + query.toString());

		try
		{
			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			prepareStatement(logger, query.toString());
			int i = 1;

			//ps.setString(i++, request.getProvGrpId());
			ps.setString(i++, request.getOrganizationId());
			ps.setString(i++, request.getProvGrpIds());
			ps.setString(i++, request.getAnalysisAsOfDt());
			ps.setString(i++, request.getProvGrpIds());
			ps.setString(i++, request.getAnalysisAsOfDt());
			ps.setString(i++, request.getProgramId());
			ps.setString(i++, request.getCompositeId());
			ps.setString(i++, request.getMeasurementPeriodStartDt());
			ps.setString(i++, request.getProgramLobTypeCd().toUpperCase());
			ps.setString(i++, request.getProvGrpIds());
			//ps.setString(i++, request.getMedicalPanelId());

			//logger.debug("provGrpId: " + request.getProvGrpId());
			//logger.debug("organizationId: " + request.getOrganizationId());
			//logger.debug("provGrpId: " + request.getProvGrpId());
			//logger.debug("analysisAsOfDt: " + request.getAnalysisAsOfDt());
			//logger.debug("provGrpId: " + request.getProvGrpId());
			//logger.debug("analysisAsOfDt: " + request.getAnalysisAsOfDt());
			//logger.debug("prgmId: " + request.getProgramId());
			//logger.debug("compositeId: " + request.getCompositeId());
			//logger.debug("msrmntStrtDt: " + request.getMeasurementPeriodStartDt());
			//logger.debug("programLobTypeCd: " + request.getProgramLobTypeCd().toUpperCase());

			if (null != Constants.getQuarterName(request
				.getMeasurementInterval())) {
				if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
					ps.setString(i++, "Y");
				}
				else {
					ps.setString(i++, Constants.getQuarterName(request
						.getMeasurementInterval()));
				}
				//logger.debug("measurementInterval: " + Constants.getQuarterName(request.getMeasurementInterval()));
			}
			if (request.getMeasurementInterval() != null && request.getMeasurementInterval().equalsIgnoreCase("0")) {
				ps.setString(i++, request.getProgramId());
				ps.setString(i++, request.getMeasurementPeriodStartDt());
				//logger.debug("prgmId: " + request.getProgramId());
			}

			executeQuery(logger, query.toString());
			while (rs.next())
			{
				measureBean = new ScorecardMeasureBean();
				if (rs.getString("CMPST_TYPE_DESC") != null) {
					measureBean.setCompTypeDesc(rs.getString("CMPST_TYPE_DESC"));
				}
				if (rs.getString("CMPST_DEFN_ID") != null) {
					measureBean.setCmpstDefnId(rs.getString("CMPST_DEFN_ID"));
				}
				if (rs.getString("CMPST_NM") != null) {
					measureBean.setCmpstNm(rs.getString("CMPST_NM"));
				}
				if (rs.getString("MSR_DIM_KEY") != null) {
					measureBean.setMsrId(rs.getString("MSR_DIM_KEY"));
				}
				if (rs.getString("MSR_DSPLY_NM") != null) {
					measureBean.setMsrDsplyNm(rs.getString("MSR_DSPLY_NM"));
				}
				//Setting values for Organization Level
				if (rs.getString("COSF_MSR_NMRTR_NBR") != null) {
					measureBean.getScorecardMeasureOrgLvl().setMsrNmrtrNbr(Integer.valueOf(rs.getInt("COSF_MSR_NMRTR_NBR")));
				}
				if (rs.getString("COSF_MSR_DNMNTR_NBR") != null) {
					measureBean.getScorecardMeasureOrgLvl().setMsrDnmntrNbr(Integer.valueOf(rs.getInt("COSF_MSR_DNMNTR_NBR")));
				}
				//Setting values for Group Level
				if (rs.getString("CPGSF_MSR_NMRTR_NBR") != null) {
					measureBean.getScorecardMeasureGrpLvl().setMsrNmrtrNbr(Integer.valueOf(rs.getString("CPGSF_MSR_NMRTR_NBR")));
				}
				if (rs.getString("CPGSF_MSR_DNMNTR_NBR") != null) {
					measureBean.getScorecardMeasureGrpLvl().setMsrDnmntrNbr(Integer.valueOf(rs.getString("CPGSF_MSR_DNMNTR_NBR")));
				}

				if (rs.getString("ACHVD_TRNCH_LVL_CD") != null) {
					measureBean.setLevelAchieved(rs.getString("ACHVD_TRNCH_LVL_CD"));
				}

				if (rs.getBigDecimal("RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT") != null) {
					measureBean.setWeight(rs.getBigDecimal("RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT"));
				}
				resultList.add(measureBean);
			}

		}
		catch (Exception e) {
			logger.error("Exception during getScorecardMedicaidMeasuresQuery", e);
		}
		finally {
			close();
		}

		return resultList;
	}

	public Collection<ScorecardMeasureBean> getScorecardMedicaidImprovementMeasuresQuery(PerformanceManagementRequest request) throws Exception {

		Collection<ScorecardMeasureBean> resultList = new ArrayList<ScorecardMeasureBean>();
		ScorecardMeasureBean measureBean = null;

		StringBuilder query = new StringBuilder();

		query.append(" select   SMHD.CMPST_DEFN_ID, SMHD.CMPST_NM,  MSR.MSR_DSPLY_NM, MSR.MSR_DIM_KEY, IPGSF.MSR_NMRTR_NBR AS CPGSF_MSR_NMRTR_NBR, ")
			.append(" IPGSF.MSR_DNMNTR_NBR AS CPGSF_MSR_DNMNTR_NBR, IPGSF.BSLN_MSR_NMRTR_NBR AS PRIOR_GRP_MSR_NMRTR_NBR,IPGSF.BSLN_MSR_DNMNTR_NBR AS PRIOR_GRP_MSR_DNMNTR_NBR, ")
			.append(" IPGSF.BSLN_RT_PCT AS CPGSF_BSLN_RT_PCT,  SPGMHF.IMPRVMNT_GAP_UPR_LMT_PCT AS HEDIS_SCORE, IPGSF.TRGT_RT_PCT AS TARGET_RATE, ")
			.append(" IPGSF.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT AS RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT,   SMHD.CMPST_TYPE_DESC");

		//PCMSP-2826 : Starts
		if (null != request.getOrganizationId()) {
			query.append(" , IPOSF1.BSLN_MSR_NMRTR_NBR AS PRIOR_ORG_MSR_NMRTR_NBR ")
				.append(" , IPOSF1.BSLN_MSR_DNMNTR_NBR AS PRIOR_ORG_MSR_DNMNTR_NBR ")
				.append(" , IPOSF1.MSR_NMRTR_NBR AS COSF_MSR_NMRTR_NBR ")
				.append(" , IPOSF1.MSR_DNMNTR_NBR AS COSF_MSR_DNMNTR_NBR ")
				.append(" , IPOSF1.BSLN_RT_PCT AS PRIOR_ORG_RT_PCT ");
		}
		//PCMSP-2826 : Ends
		query.append(" from  SCRCRD_PGM_MSR_HRCHY_FACT AS SPGMHF ")
			.append(" left join   IMPRV_PROV_GRP_SMRY_FACT AS IPGSF ON IPGSF.MNTH_ID = SPGMHF.MNTH_ID  ")
			.append(" and  IPGSF.PGM_DIM_KEY = SPGMHF.PGM_DIM_KEY  ")
			.append(" and  IPGSF.MSRMNT_PRD_STRT_DT = SPGMHF.MSRMNT_PRD_STRT_DT  ")
			.append(" and  IPGSF.SCRCRD_MSR_HRCHY_DIM_KEY = SPGMHF.SCRCRD_MSR_HRCHY_DIM_KEY ");

		//PCMSP-2826 : Starts
		if (null != request.getOrganizationId()) {
			query.append(" left join  ( SELECT * from  IMPRV_PROV_ORG_SMRY_FACT AS IPOSF INNER JOIN  ")
				.append(" PROV_ORG_DIM AS POD ON IPOSF.PROV_ORG_DIM_KEY = POD.PROV_ORG_DIM_KEY  ")
				.append(" and   POD.PROV_ORG_DIM_KEY = ? ")
				.append(" ) IPOSF1 on  ")
				.append(" IPOSF1.PGM_DIM_KEY = SPGMHF.PGM_DIM_KEY   AND IPOSF1.MNTH_ID = SPGMHF.MNTH_ID ")
				.append(" and   IPOSF1.MSRMNT_PRD_STRT_DT = SPGMHF.MSRMNT_PRD_STRT_DT ")
				.append(" and   IPOSF1.SCRCRD_MSR_HRCHY_DIM_KEY = SPGMHF.SCRCRD_MSR_HRCHY_DIM_KEY ");
		}
		//PCMSP-2826 : Ends

		query.append(" inner join   SCRCRD_MSR_HRCHY_DIM AS SMHD ON SPGMHF.SCRCRD_MSR_HRCHY_DIM_KEY = SMHD.SCRCRD_MSR_HRCHY_DIM_KEY ")
			.append(" inner join   MSR_DIM AS MSR ON SMHD.MSR_DIM_KEY = MSR.MSR_DIM_KEY ")
			.append(" and  SPGMHF.MSRMNT_PRD_STRT_DT >= MSR.MSR_EFCTV_DT ")
			.append(" and  SPGMHF.MSRMNT_PRD_END_DT <= MSR.MSR_TRMNTN_DT ")
			.append(" inner join   PGM_DIM AS PGM ON SPGMHF.PGM_DIM_KEY = PGM.PGM_DIM_KEY ")
			//Release 1.9 ephc intake id 3530 ad90348
			//commented | EPHC Intake Id - 3530 | duplicate measures appearing during export
			/*.append(" inner join   PROV_GRP_PGM_LOB_FACT AS PGPLF ON IPGSF.PROV_GRP_DIM_KEY = PGPLF.PROV_GRP_DIM_KEY ")
			.append(" and  IPGSF.PGM_DIM_KEY = PGPLF.PGM_DIM_KEY ")
			.append(" and  IPOSF1.PROV_GRP_DIM_KEY = PGPLF.PROV_GRP_DIM_KEY ")
			.append(" and   IPOSF1.PGM_DIM_KEY = PGPLF.PGM_DIM_KEY ")
			.append(" inner join   LOB_DIM AS LD ON LD.LOB_DIM_KEY = PGPLF.LOB_DIM_KEY  ")*/
			.append(" inner join   PROV_GRP_DIM as PGD on IPGSF.prov_grp_dim_key = PGD.prov_grp_dim_key ");
		//PCMSP-2826 : Starts
		if (null != request.getOrganizationId())
			query.append(" and  pgd.prov_grp_dim_key = IPOSF1.prov_grp_dim_key  ");
		//PCMSP-2826 : Ends
		query.append(" where  PGM.PGM_ID = ? ")
			.append(" and  SMHD.CMPST_DEFN_ID = ? ")
			.append(" and  SPGMHF.MSRMNT_PRD_STRT_DT = ?")
			.append(" and  IPGSF.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT > 0 ")
			.append(" and  spgmhf.PGM_LOB_TYPE_CD = ? ")
			.append(" and  pgd.prov_grp_id = ? ");
		if (null != Constants
			.getQuarterName(request.getMeasurementInterval())) {
			if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
				query.append(" AND IPGSF.BSLN_SCRCRD_IND = ? ");
			}
			else {
				query.append(" AND IPGSF.QTR_ID = ? ");
			}
		}
		else {
			query.append(" AND IPGSF.MNTH_ID = (SELECT MAX(IPGSF.MNTH_ID) FROM IMPRV_PROV_GRP_SMRY_FACT IPGSF INNER JOIN "
				+ " (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT FROM SCRCRD_PGM_MSR_HRCHY_FACT WHERE  "
				+ " PGM_DIM_KEY=(SELECT PGM_DIM_KEY FROM PGM_DIM WHERE PGM_ID= ? ) and MSRMNT_PRD_STRT_DT=? GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM "
				+ " ON IPGSF.PGM_DIM_KEY=SC_PGM.PGM_DIM_KEY AND IPGSF.MSRMNT_PRD_STRT_DT=SC_PGM.MSRMNT_PRD_STRT_DT) ");
		}
		query.append("ORDER BY IPGSF.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT DESC, ipgsf.MSR_DNMNTR_NBR DESC ");
		query = StringUtil.appendWithUr(query);

		try
		{
			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			prepareStatement(logger, query.toString());
			//PCMSP-2826 : Starts
			int placeHolderCounter = 0;

			if (null != request.getOrganizationId())
				ps.setString(++placeHolderCounter, request.getOrganizationId());

			ps.setString(++placeHolderCounter, request.getProgramId());
			ps.setString(++placeHolderCounter, request.getCompositeId());
			ps.setString(++placeHolderCounter, request.getMeasurementPeriodStartDt());
			ps.setString(++placeHolderCounter, request.getProgramLobTypeCd().toUpperCase());
			ps.setString(++placeHolderCounter, request.getProvGrpIds());
			if (null != Constants.getQuarterName(request
				.getMeasurementInterval())) {
				if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
					ps.setString(++placeHolderCounter, "Y");
				}
				else {
					ps.setString(++placeHolderCounter, Constants.getQuarterName(request
						.getMeasurementInterval()));
				}
			}
			if (request.getMeasurementInterval() != null
				&& request.getMeasurementInterval().equalsIgnoreCase("0")) {
				ps.setString(++placeHolderCounter, request.getProgramId());
				ps.setString(++placeHolderCounter, request.getMeasurementPeriodStartDt());
			}
			//PCMSP-2826 : Ends
			executeQuery(logger, query.toString());
			while (rs.next())
			{
				measureBean = new ScorecardMeasureBean();
				if (rs.getString("CMPST_TYPE_DESC") != null) {
					measureBean.setCompTypeDesc(rs.getString("CMPST_TYPE_DESC"));
				}
				if (rs.getString("CMPST_DEFN_ID") != null) {
					measureBean.setCmpstDefnId(rs.getString("CMPST_DEFN_ID"));
				}
				if (rs.getString("CMPST_NM") != null) {
					measureBean.setCmpstNm(rs.getString("CMPST_NM"));
				}
				if (rs.getString("MSR_DIM_KEY") != null) {
					measureBean.setMsrId(rs.getString("MSR_DIM_KEY"));
				}
				if (rs.getString("MSR_DSPLY_NM") != null) {
					measureBean.setMsrDsplyNm(rs.getString("MSR_DSPLY_NM"));
				}
				//Setting values for Organization Level
				if (null != request.getOrganizationId() && rs.getString("COSF_MSR_NMRTR_NBR") != null) {//PCMSP-2826
					measureBean.getScorecardMeasureOrgLvl().setMsrNmrtrNbr(Integer.valueOf(rs.getInt("COSF_MSR_NMRTR_NBR")));
				}
				if (null != request.getOrganizationId() && rs.getString("COSF_MSR_DNMNTR_NBR") != null) {//PCMSP-2826
					measureBean.getScorecardMeasureOrgLvl().setMsrDnmntrNbr(Integer.valueOf(rs.getInt("COSF_MSR_DNMNTR_NBR")));
				}
				//added as pert of 16404 - R1.7

				if (null != request.getOrganizationId() && rs.getString("PRIOR_ORG_MSR_NMRTR_NBR") != null) {//PCMSP-2826
					measureBean
						.getScorecardMeasureOrgLvl()
						.setPriorMsrNmrtrNbr(
							Integer.valueOf(rs
								.getInt("PRIOR_ORG_MSR_NMRTR_NBR")));

				}
				if (null != request.getOrganizationId() && rs.getString("PRIOR_ORG_MSR_DNMNTR_NBR") != null) {//PCMSP-2826
					measureBean
						.getScorecardMeasureOrgLvl()
						.setPriorMsrDnmntrNbr(
							Integer.valueOf(rs
								.getInt("PRIOR_ORG_MSR_DNMNTR_NBR")));

				}

				if (null != request.getOrganizationId() && rs.getBigDecimal("PRIOR_ORG_RT_PCT") != null) {//PCMSP-2826
					measureBean.getScorecardMeasureOrgLvl()
						.setPreviousOrgYearRate(
							rs.getBigDecimal("PRIOR_ORG_RT_PCT"));
				}


				// Setting values for Group Level
				if (rs.getString("CPGSF_MSR_NMRTR_NBR") != null) {
					measureBean.getScorecardMeasureGrpLvl()
						.setMsrNmrtrNbr(
							Integer.valueOf(rs
								.getString("CPGSF_MSR_NMRTR_NBR")));
				}
				if (rs.getString("CPGSF_MSR_DNMNTR_NBR") != null) {
					measureBean.getScorecardMeasureGrpLvl().setMsrDnmntrNbr(Integer.valueOf(rs.getString("CPGSF_MSR_DNMNTR_NBR")));
				}
				if (rs.getBigDecimal("CPGSF_BSLN_RT_PCT") != null) {
					measureBean.getScorecardMeasureGrpLvl().setPreviousYearRate(rs.getBigDecimal("CPGSF_BSLN_RT_PCT"));
				}

				//added as pert of 16404 - R1.7

				if (rs.getString("PRIOR_GRP_MSR_NMRTR_NBR") != null) {
					measureBean
						.getScorecardMeasureGrpLvl()
						.setPriorMsrNmrtrNbr(
							Integer.valueOf(rs
								.getString("PRIOR_GRP_MSR_NMRTR_NBR")));

				}
				if (rs.getString("PRIOR_GRP_MSR_DNMNTR_NBR") != null) {
					measureBean
						.getScorecardMeasureGrpLvl()
						.setPriorMsrDnmntrNbr(
							Integer.valueOf(rs
								.getString("PRIOR_GRP_MSR_DNMNTR_NBR")));

				}


				if (rs.getBigDecimal("HEDIS_SCORE") != null) {
					measureBean.setHedisScore(rs.getBigDecimal("HEDIS_SCORE"));
				}
				if (rs.getBigDecimal("TARGET_RATE") != null) {
					measureBean.setTargetRate(rs.getBigDecimal("TARGET_RATE"));
				}
				if (null != measureBean.getTargetRate() && null != measureBean.getScorecardMeasureGrpLvl().getMsrNmrtrNbr()
					&& null != measureBean.getScorecardMeasureGrpLvl().getMsrDnmntrNbr()
					&& !measureBean.getScorecardMeasureGrpLvl().getMsrDnmntrNbr().equals(new Integer(0))) {
					BigDecimal currRate =
						new BigDecimal(measureBean.getScorecardMeasureGrpLvl().getMsrNmrtrNbr()).divide(new BigDecimal(measureBean.getScorecardMeasureGrpLvl().getMsrDnmntrNbr()),
							4, RoundingMode.HALF_UP);
					currRate = currRate.multiply(new BigDecimal(100));
					// Changes made by Vignesh to correct Target achieved when current equals or greater than target rate
					if (currRate.compareTo(measureBean.getTargetRate()) >= 0) {
						measureBean.setTargetAchieved("Y");
					}
					else {
						measureBean.setTargetAchieved("N");
					}
				}

				resultList.add(measureBean);
			}

		}
		catch (Exception e) {
			logger.error("Exception during getScorecardMedicaidImprovementMeasuresQuery", e);
		}
		finally {
			close();
		}

		return resultList;
	}
}
