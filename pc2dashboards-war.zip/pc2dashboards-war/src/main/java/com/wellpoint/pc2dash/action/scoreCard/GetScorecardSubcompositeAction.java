package com.wellpoint.pc2dash.action.scoreCard;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.data.dao.DrillDownLinkSettings;
import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.killswitch.DrillDownLinksServiceImpl;
import com.wellpoint.pc2dash.service.scorecard.commercial.CommercialIndividualMetricScoringServiceImpl;
import com.wellpoint.pc2dash.service.scorecard.commercial.CommercialScorecardSubcompositeServiceImpl;
import com.wellpoint.pc2dash.service.scorecard.commercial.ContinousScoringCommercialScorecardServiceImpl;
import com.wellpoint.pc2dash.service.scorecard.commercial.ContionousScoringFpccCommercialSubCompositeServiceImpl;
import com.wellpoint.pc2dash.service.scorecard.commercial.EsnCommercialScorecardSubCompositeServiceImpl;
import com.wellpoint.pc2dash.service.scorecard.commercial.FpccCommercialScorecardSubCompositeServiceImpl;
import com.wellpoint.pc2dash.service.scorecard.medicaid.MedicaidScorecardSubcompositeServiceImpl;
import com.wellpoint.pc2dash.service.scorecard.medicare.EsnMedicareScorecardSubCompositeServiceImpl;
import com.wellpoint.pc2dash.service.scorecard.medicare.MedicareScorecardSubcompositeServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.DateUtil;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetScorecardSubcompositeAction extends Action {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetScorecardSubcompositeAction.class);

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		ActionResponse result = new GetScorecardCompositeResponse();
		GetScorecardSubcompositeRequest request = (GetScorecardSubcompositeRequest) actionRequest;
		ErrorProperties err = ErrorProperties.getInstance();

		List<String> filteredProvGrpList = new ArrayList<String>();
		List<String> filteredProvGrpListOnAccess = null;
		String provGrpCSVWithGrpIndY = "";
		String provGrpCSVWithGrpIndN = "";

		// Call DrillDownLinksServiceImpl and pass the resulting link settings to each sub-composite service
		DrillDownLinksServiceImpl drillDownImpl = new DrillDownLinksServiceImpl();
		DrillDownLinkSettings links = new DrillDownLinkSettings();
		try {

			Collection<Object> vals = new ArrayList<Object>();

			// preserve dataMap logic
			removeLobPgmPrefixes(request);

			//			PCMSRequest request = new HashMap<String,String>();
			//			request.put("entId",request.getEntitlementId());
			//			request.setCompositeId(request.getCompositeId());
			//			request.put("viewBy", request.getViewBy());
			//			request.put("msrmntStrtDt", request.getMeasurementPeriodStartDt());
			//			request.put("msrmntEndDt", request.getMeasurementPeriodEndDt());
			//			request.put("provGrpId", request.getProviderGroupId());
			//			request.put("provGrpDimKey", request.getProviderGroupDimKey());
			//			request.put("prgmId", request.getProgramId());
			//			/*
			//			 * Adding the programLobTypeCd parameter to the datamap
			//			 * The value is going to be the pgmLobTypCd
			//			 */
			//			request.put("programLobTypeCd", request.getProgramLobTypeCd());
			//			request.put("organizationId", request.getOrganizationId());
			//			request.put("measurementInterval", request.getMeasurementInterval());
			//			request.setCompositeType(request.getCompositeType());
			//			request.put("lob", request.getLob());
			//			request.put("lobNm", request.getLobNm());
			//			request.put("lobDimKeys", JSONUtils.removeFirstOccurenceOfCharsFromJsonString(request.getLobDimKeys(), Constants.LOB_ID_PREFIX));
			//			request.put("cmd", request.getCmd());
			//			//request.put("sessionId", request.getSessionId());
			//			//request.put("entitlementId", request.getEntitlementId());
			//			request.put("medicalPanelId", request.getMedicalPanelId());
			//
			//			if(null != request.getLobNm()){
			/**
			 * Updating the logic based on the defect WLPRD02524865 and as per the suggestion from Vishal J. to drive scorecard based on
			 * PGM_LOB_TYPE_CD and not on lob
			 * Author - AD12140
			 * Commenting the below logic
			 */

			//String lobDesc = request.get("lobNm");
			//if(null != lobDesc){
			/** 66200 Lob Desc Changes | ad87338 | START */
			//String lobName = StringUtil.lobCategoryType(lobDesc);
			/** 66200 Lob Desc Changes | ad87338 | END */

			/*if(lobName.equalsIgnoreCase(Constants.COMMERCIAL) || lobName.equalsIgnoreCase(Constants.MEDICARE)){ //To be set only for EPHC, not for FPCC
					if(null != pgmLobTypeCd && !pgmLobTypeCd.contains(Constants.FPCC_PGM_TYPE))
						if(null != request.getMeasurementInterval() && request.getMeasurementInterval().equalsIgnoreCase("12")){
							QualityIndicatorsFromRequest  qualityIndFromUi = (QualityIndicatorsFromRequest) JSONUtils.convertJSONToJavaObj(rqst.getQualityGate() ,  "com.wellpoint.pc2dash.dto.scorecard.QualityIndicatorsFromRequest");
							request.put("qualityGateInd",qualityIndFromUi.getQualityGateInd());
							request.put("qualityGate",qualityIndFromUi.getQualityGate());
							request.put("qualityScore",qualityIndFromUi.getQualityScore());
						}
				}else if(lobName.equalsIgnoreCase(Constants.MEDICAID)){
					QualityIndicatorsFromRequest  qualityIndFromUi = (QualityIndicatorsFromRequest) JSONUtils.convertJSONToJavaObj(rqst.getQualityGate() ,  "com.wellpoint.pc2dash.dto.scorecard.QualityIndicatorsFromRequest");
					request.put("qualityGateInd",qualityIndFromUi.getQualityGateInd());
					request.put("qualityGate",qualityIndFromUi.getQualityGate());
					request.put("qualityScore",qualityIndFromUi.getQualityScore());
				}*/

			//}


			//			if((null != pgmLobTypeCd) && 
			//					(pgmLobTypeCd.trim().toUpperCase().contains(Constants.COMMERCIAL.toUpperCase()) || 
			//							pgmLobTypeCd.trim().toUpperCase().contains(Constants.MEDICARE.toUpperCase())) &&
			//							(!pgmLobTypeCd.trim().toUpperCase().contains(Constants.FPCC_PGM_TYPE)) &&
			//							(null != request.getMeasurementInterval() && "12".equalsIgnoreCase(request.getMeasurementInterval()))){
			//				//To be set only for EPHC, not for FPCC
			//				QualityIndicatorsFromRequest  qualityIndFromUi = (QualityIndicatorsFromRequest) JSONUtils.convertJSONToJavaObj(rqst.getQualityGate() ,  "com.wellpoint.pc2dash.dto.scorecard.QualityIndicatorsFromRequest");
			//				request.put("qualityGateInd",qualityIndFromUi.getQualityGateInd());
			//				request.put("qualityGate",qualityIndFromUi.getQualityGate());
			//				request.put("qualityScore",qualityIndFromUi.getQualityScore());
			//			}else if(pgmLobTypeCd.trim().toUpperCase().contains(Constants.MEDICAID)){
			//				QualityIndicatorsFromRequest  qualityIndFromUi = (QualityIndicatorsFromRequest) JSONUtils.convertJSONToJavaObj(rqst.getQualityGate() ,  "com.wellpoint.pc2dash.dto.scorecard.QualityIndicatorsFromRequest");
			//				request.put("qualityGateInd",qualityIndFromUi.getQualityGateInd());
			//				request.put("qualityGate",qualityIndFromUi.getQualityGate());
			//				request.put("qualityScore",qualityIndFromUi.getQualityScore());
			//			}

			//GBD part 2
			//request.setCmpId(request.getCmpId());
			//request.setProvGrpIds(request.getProviderGroupId());
			//			request.put(Constants.USER_ACS_INFO_JSON, request.getUserAcsInfoJson());
			//Copyright msg
			//			request.put(Constants.COPYRIGHT_MSG, request.getCopyRightMsg());
			//Kill switch check on Provider groups
			if (null != request) {
				filteredProvGrpList = filterProvGrpsByKillSwitch(request);
			}

			if (null != request && null != filteredProvGrpList && filteredProvGrpList.size() > 0) {
				//Clinical & Financial access check on provider groups
				filteredProvGrpListOnAccess = filterProvGrpsByClincalFinancialInd(request, filteredProvGrpList);

			}
			if (null != request && null != filteredProvGrpList && filteredProvGrpList.size() > 0) {
				//Clinical access check on provider groups to show view members link
				List<String> clinGroups = filterProvGrpsByClinicalInd(request, filteredProvGrpList);
				if (null != clinGroups && !clinGroups.isEmpty()) {
					links = drillDownImpl.getData(request);
					request.setClinicalPharmacySuppression(true);
				}

			}

			//Group Ind Y list
			if (null != request && null != filteredProvGrpListOnAccess && filteredProvGrpListOnAccess.size() > 0) {
				provGrpCSVWithGrpIndY = prepareProvGrpCSVWithGrpInd(request, filteredProvGrpListOnAccess, Constants.GRP_IND_Y);
				provGrpCSVWithGrpIndN = prepareProvGrpCSVWithGrpInd(request, filteredProvGrpListOnAccess, Constants.GRP_IND_N);
			}

			//Group Ind Y list
			if (null != request && null != provGrpCSVWithGrpIndY && !provGrpCSVWithGrpIndY.isEmpty()) {
				request.setProvGrpIds(provGrpCSVWithGrpIndY);
				request.setGrpInd(Constants.GRP_IND_Y);
				vals = getScorecardComposites(request, links);
			}

			//Group Ind N list
			if (null != request && null != provGrpCSVWithGrpIndN && !provGrpCSVWithGrpIndN.isEmpty()) {
				request.setProvGrpIds(provGrpCSVWithGrpIndN);
				request.setGrpInd(Constants.GRP_IND_N);
				Collection<Object> values = getScorecardComposites(request, links);
				if (null != values) {
					vals.addAll(values);
				}
			}

			if (null == vals || (null != vals && vals.isEmpty())) {
				result.setMessage(err.getProperty("successNoData"));
				result.setData(vals);
				result.setTotal(0);
			}
			else {
				result.setMessage(err.getProperty("successful"));
				result.setData(vals);
				result.setTotal(vals.size());
			}


			result.setSuccess(true);

		}
		catch (Exception e) {

			result.setMessage("Unable to retrieve Scorecard composite  detail.");
			result.setSuccess(false);
			logger.error(e);
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getScorecardComposites(PerformanceManagementRequest request, DrillDownLinkSettings links) throws Exception {

		Collection<?> details = null;
		String lobDesc = request.getLobNm();
		/** Release 1.9 <UT> <AD12140> */
		String lobName = StringUtil.lobSuppressedIndicator(lobDesc);
		String pgmLobTypeCd = request.getProgramLobTypeCd();
		String measStartDate = request.getMeasurementPeriodStartDt();
		boolean isMPGreaterThan06302016 = DateUtil.dateComparator(measStartDate, Constants.NEW_GRP_ST_DT);
		//PCMSP-8503
		boolean isMPGreaterThanOrEqual01012018 = DateUtil.dateComparator(measStartDate, Constants.IND_MTRC_STRT_DT);
		/**
		 * Updating the logic based on the defect WLPRD02524865 and as per the suggestion from Vishal J. to drive scorecard based on
		 * PGM_LOB_TYPE_CD and not on lob
		 * Author - AD12140
		 * Commenting the below logic
		 */

		/*if (null != lobName && lobName.equalsIgnoreCase(Constants.COMMERCIAL)) {
			if (null != pgmLobTypeCd)
				if (pgmLobTypeCd.contains(Constants.FPCC_PGM_TYPE)) {
					FpccCommercialScorecardSubCompositeServiceImpl dao = new FpccCommercialScorecardSubCompositeServiceImpl();
					details = dao.getScorecardSubcomposites(request, links);
				} 
				else {
					CommercialScorecardSubcompositeServiceImpl dao = new CommercialScorecardSubcompositeServiceImpl();
					details = dao.getScorecardSubcomposites(request, links);
				}
		} 
		else if (null != lobName && lobName.equalsIgnoreCase(Constants.MEDICAID)) {
			MedicaidScorecardSubcompositeServiceImpl dao = new MedicaidScorecardSubcompositeServiceImpl();
			details = dao.getScorecardMedicaidSubcomposites(request, links);
		} 
		else if (null != lobName && lobName.equalsIgnoreCase(Constants.MEDICARE)) {
			MedicareScorecardSubcompositeServiceImpl dao = new MedicareScorecardSubcompositeServiceImpl();
			details = dao.getScorecardSubcomposites(request, links);
		}*/

		if (!Constants.SUPPRESSED.equalsIgnoreCase(lobName)) {
			if(null != pgmLobTypeCd && pgmLobTypeCd.trim().equalsIgnoreCase(Constants.ESN_COMMERCIAL)){
		//	if(null != pgmLobTypeCd && pgmLobTypeCd.trim().equalsIgnoreCase(Constants.COMMERCIAL)){
				EsnCommercialScorecardSubCompositeServiceImpl dao = new EsnCommercialScorecardSubCompositeServiceImpl();
				details = dao.getEsnScorecardSubcomposites(request, links);
			}
			else if (null != pgmLobTypeCd && pgmLobTypeCd.trim().toUpperCase().contains(Constants.COMMERCIAL.toUpperCase())) {
				if (pgmLobTypeCd.trim().toUpperCase().contains(Constants.FPCC_PGM_TYPE)) {
					if (request.getMeasurementPeriodStartDt() != null && isMPGreaterThan06302016) {
						ContionousScoringFpccCommercialSubCompositeServiceImpl dao = new ContionousScoringFpccCommercialSubCompositeServiceImpl();
						details = dao.getContinousScoringFpccScorecardSubcomposites(request, links);
					}
					else {
						FpccCommercialScorecardSubCompositeServiceImpl dao = new FpccCommercialScorecardSubCompositeServiceImpl();
						details = dao.getScorecardSubcomposites(request, links);
					}
				}
				else {
					if(request.getMeasurementPeriodStartDt() != null && isMPGreaterThanOrEqual01012018){
						CommercialIndividualMetricScoringServiceImpl dao = new CommercialIndividualMetricScoringServiceImpl();
						details = dao.getCommercialIndividualMetricScoring(request, links);
					}
					else if (request.getMeasurementPeriodStartDt() != null && isMPGreaterThan06302016 && !isMPGreaterThanOrEqual01012018) {
						ContinousScoringCommercialScorecardServiceImpl dao = new ContinousScoringCommercialScorecardServiceImpl();
						details = dao.getContinousScoringScorecardSubcomposites(request, links);
					}
					else {
						CommercialScorecardSubcompositeServiceImpl dao = new CommercialScorecardSubcompositeServiceImpl();
						details = dao.getScorecardSubcomposites(request, links);
					}
				}
			}
			else if (null != pgmLobTypeCd && pgmLobTypeCd.trim().toUpperCase().contains(Constants.MEDICAID.toUpperCase())) {
				MedicaidScorecardSubcompositeServiceImpl dao = new MedicaidScorecardSubcompositeServiceImpl();
				details = dao.getScorecardMedicaidSubcomposites(request, links);
			}
			else if(null != pgmLobTypeCd && pgmLobTypeCd.trim().equalsIgnoreCase(Constants.ESN_MEDICARE)){
						EsnMedicareScorecardSubCompositeServiceImpl dao = new EsnMedicareScorecardSubCompositeServiceImpl();
						details = dao.getEsnScorecardSubcomposites(request, links);
					}
			else if (null != pgmLobTypeCd && pgmLobTypeCd.trim().toUpperCase().contains(Constants.MEDICARE.toUpperCase())) {
				MedicareScorecardSubcompositeServiceImpl dao = new MedicareScorecardSubcompositeServiceImpl();
				details = dao.getScorecardSubcomposites(request, links, isMPGreaterThanOrEqual01012018);
			}
		}

		return (Collection<Object>) details;
	}

}
