package com.wellpoint.pc2dash.action.scoreCard;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.wellpoint.pc2dash.action.drilldown.GetDrillDownRequest;

public class GetEpisodeProvidersRequest extends GetDrillDownRequest{
	
	/**
	 * @return The String representation of this class as constructed via
	 *         reflection by Apache Commons ToStringBuilder.
	 */
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
