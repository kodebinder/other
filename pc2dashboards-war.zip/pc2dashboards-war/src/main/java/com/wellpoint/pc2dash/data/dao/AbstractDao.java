package com.wellpoint.pc2dash.data.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.wellpoint.pc2dash.data.Dao;
import com.wellpoint.pc2dash.data.LoggableStatement;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;


public abstract class AbstractDao implements Dao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(AbstractDao.class);
	private static final String DEFAULT_VALUE = "---";

	protected Connection cn = null;
	protected PreparedStatement ps = null;
	protected ResultSet rs = null;

	private int rowCount;
	private int totalExport;

	protected String getDate(ResultSet rs, String columnName) throws Exception {

		Date result = rs.getDate(columnName);
		SimpleDateFormat dfmt = new SimpleDateFormat("MM/dd/yyyy");

		return (result != null) ? dfmt.format(result) : DEFAULT_VALUE;
	}

	protected String getDate(ResultSet rs, String columnName, String format) throws Exception {

		Date result = rs.getDate(columnName);
		SimpleDateFormat dfmt = new SimpleDateFormat(format);

		return (result != null) ? dfmt.format(result) : DEFAULT_VALUE;
	}

	protected String getInt(ResultSet rs, String columnName) throws Exception {

		int result = rs.getInt(columnName);

		return Integer.toString(result);
	}

	protected String getString(ResultSet rs, String columnName) throws Exception {

		String result = rs.getString(columnName);
		result = (result != null) ? result.trim() : DEFAULT_VALUE;

		return (result.length() > 0) ? result : DEFAULT_VALUE;
	}

	/**
	 * "trace" should only be enabled on local machines, which will result in
	 * queries being printed with their parameters populated.
	 * 
	 * In any environments DEV and above, trace should not be enabled, which
	 * means the queries will not be printed in detailed format, for security reasons.
	 * 
	 * After this method returns, ps (the PreparedStatement) will be initialized
	 * as it is after a call to cn.prepareStatement(query);
	 */
	protected void prepareStatement(Pc2DashLogger logger, String query) throws SQLException {

		if (logger.isTraceEnabled()) {
			ps = new LoggableStatement(cn, query);
		}
		else {
			ps = cn.prepareStatement(query);
		}
	}

	/**
	 * "trace" should only be enabled on local machines, which will result in
	 * queries being printed with their parameters populated.
	 * 
	 * In any environments DEV and above, trace should not be enabled, which
	 * means the queries will not be printed in detailed format, for security reasons.
	 * 
	 * After this method returns, ps (the PreparedStatement) will be initialized
	 * as it is after a call to cn.prepareStatement(query);
	 */
	protected void prepareStatementWithKeys(Pc2DashLogger logger, String query) throws SQLException {

		if (logger.isTraceEnabled()) {
			ps = new LoggableStatement(cn, query, true);

		}
		else {
			ps = cn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);
		}
	}

	/**
	 * With the notes in prepareStatement() taken into consideration,
	 * populate the parameter markers with actual values only if "trace"
	 * is enabled.
	 * 
	 * After this method returns, rs (the ResultSet) will be populated
	 * as it is after a call to ps.executeQuery();
	 */
	protected void executeQuery(Pc2DashLogger logger, String query) throws SQLException {

		if (logger.isTraceEnabled()) {
			logger.debugPretty(((LoggableStatement) ps).getQueryString());
		}
		else {
			logger.debug(query);
		}

		rs = ps.executeQuery();
	}

	/**
	 * With the notes in prepareStatement() taken into consideration,
	 * populate the parameter markers with actual values only if "trace"
	 * is enabled.
	 * 
	 * After this method returns, the program will proceed
	 * as it does after a call to ps.executeUpdate();
	 */
	protected void executeUpdate(Pc2DashLogger logger, String query) throws SQLException {

		if (logger.isTraceEnabled()) {
			logger.debugPretty(((LoggableStatement) ps).getQueryString());
		}
		else {
			logger.debug(query);

		}
		ps.executeUpdate();

	}


	/**
	 * With the notes in prepareStatement() taken into consideration,
	 * populate the parameter markers with actual values only if "trace"
	 * is enabled.
	 * 
	 * After this method returns, the program will proceed
	 * as it does after a call to ps.execute();
	 */
	protected void execute(Pc2DashLogger logger, String query) throws SQLException {

		if (logger.isTraceEnabled()) {
			logger.debugPretty(((LoggableStatement) ps).getQueryString());
		}
		else {
			logger.debug(query);
		}

		ps.execute();
	}

	protected void close() {

		try {

			if (rs != null) {
				rs.close();
				rs = null;
			}
			if (ps != null) {
				ps.close();
				ps = null;
			}
			if (cn != null) {
				cn.close();
				cn = null;
			}
		}
		catch (Exception e) {

			logger.error("Exception logger: " + e);
		}
	}

	public int getRowCount() {
		return rowCount;
	}

	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

	public int getTotalExport() {
		return totalExport;
	}

	public void setTotalExport(int totalExport) {
		this.totalExport = totalExport;
	}
}
