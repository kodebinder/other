package com.wellpoint.pc2dash.action.scoreCard;


public class PcvQualityGateRequest {

	protected String pcvQualityGate;
	protected String pcvQualityGateInd;
	protected String pcvQualityScore;



	public String getPcvQualityGate() {
		return pcvQualityGate;
	}

	public void setPcvQualityGate(String pcvQualityGate) {
		this.pcvQualityGate = pcvQualityGate;
	}

	public String getPcvQualityGateInd() {
		return pcvQualityGateInd;
	}

	public void setPcvQualityGateInd(String pcvQualityGateInd) {
		this.pcvQualityGateInd = pcvQualityGateInd;
	}

	public String getPcvQualityScore() {
		return pcvQualityScore;
	}

	public void setPcvQualityScore(String pcvQualityScore) {
		this.pcvQualityScore = pcvQualityScore;
	}
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((pcvQualityGate == null) ? 0 : pcvQualityGate.hashCode());
		result = prime * result + ((pcvQualityGateInd == null) ? 0 : pcvQualityGateInd.hashCode());
		result = prime * result + ((pcvQualityScore == null) ? 0 : pcvQualityScore.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PcvQualityGateRequest other = (PcvQualityGateRequest) obj;
		if (pcvQualityGate == null) {
			if (other.pcvQualityGate != null)
				return false;
		}
		else if (!pcvQualityGate.equals(other.pcvQualityGate))
			return false;
		if (pcvQualityGateInd == null) {
			if (other.pcvQualityGateInd != null)
				return false;
		}
		else if (!pcvQualityGateInd.equals(other.pcvQualityGateInd))
			return false;
		if (pcvQualityScore == null) {
			if (other.pcvQualityScore != null)
				return false;
		}
		else if (!pcvQualityScore.equals(other.pcvQualityScore))
			return false;
		return true;
	}

}
