package com.wellpoint.pc2dash.data.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.tooltip.GetPatientDetailRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.patient.EligibleMeasures;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.DateUtil;
import com.wellpoint.pc2dash.util.StringUtil;


public class EligibleMeasureFacts extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(EligibleMeasureFacts.class);

	public boolean read(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void insert(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void update(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void delete(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public Collection<EligibleMeasures> getEligibleMeasures(GetPatientDetailRequest request) throws Exception {

		Collection<EligibleMeasures> result = new ArrayList<EligibleMeasures>();
		String measStartDate = request.getMeasurementPeriodStartDt();
		boolean isMPGreaterThanOrEqual01012018 = DateUtil.dateComparator(measStartDate, Constants.IND_MTRC_STRT_DT);
		// Convert from the UI date format to the DB date format		
		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
			request.setMeasurementPeriodStartDt(StringUtil.convertDate(request.getMeasurementPeriodStartDt()));
		}

		if (!StringUtils.isBlank(request.getAnalysisAsOfDt())) {
			request.setAnalysisAsOfDt(StringUtil.convertDate(request.getAnalysisAsOfDt()));
		}

		String sql = buildSql(request, isMPGreaterThanOrEqual01012018);

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			buildPreparedStatement(request, sql, isMPGreaterThanOrEqual01012018);
			executeQuery(logger, sql);
			result = convertSelectedRowsToObjects(rs);
		}
		catch (Exception e) {

			throw new Exception("Unable to get eligible measures (" + request.toString() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}

	protected String buildSql(GetPatientDetailRequest request, boolean isMPGreaterThanOrEqual01012018) {

		StringBuilder sql = new StringBuilder()
			.append("select ")
			.append(buildSharedSelectGroupByColumns())
			.append("from cmplnc_fact cf ")
			.append("    join msr_dim md_q on (cf.msr_dim_key = md_q.msr_dim_key) ")
			.append("    left join msr_dim md_co on (md_q.care_oprtnty_msr_dim_key = md_co.msr_dim_key) ")
			.append("    left join care_oprtnty_fact cof on (md_co.msr_dim_key = cof.msr_dim_key ")
			.append("        and cf.mstr_cnsmr_dim_key = cof.mstr_cnsmr_dim_key) ")
			.append("    join prov_grp_dim pgd on (cf.prov_grp_dim_key = pgd.prov_grp_dim_key) ")
			.append("    join prov_org_dim pod on (cf.prov_org_dim_key = pod.prov_org_dim_key) ")
			.append("    join scrcrd_msr_hrchy_dim smhd on (cf.scrcrd_msr_hrchy_dim_key = smhd.scrcrd_msr_hrchy_dim_key) ")
			.append("    join poit_user_scrty_acs pusa on ( ")
			.append("        pgd.prov_grp_id = pusa.prov_grp_id ")
			.append("        and case ")
			.append("                when pusa.prov_org_tax_id = '0' then pod.prov_org_tax_id ")
			.append("                else pusa.prov_org_tax_id ")
			.append("            end = pod.prov_org_tax_id ")
			.append("    ) ")
			.append("where ")
			.append("    smhd.cmpst_type_desc = ?")
			.append("    and pusa.sesn_id = ? ")
			.append("    and pusa.enttlmnt_hash_key = ? ")
			.append("    and cf.mstr_cnsmr_dim_key = ? ");
		//	.append("    and cf.mnth_id = (select max(mnth_id) from cmplnc_fact) ") // replaced by analysisAsOfDt

		if (!StringUtils.isBlank(request.getAnalysisAsOfDt())) {
			sql.append("and cf.anlyss_as_of_dt = ? ");
		}

		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
			sql.append("and cf.msrmnt_prd_strt_dt = ? ");
		}
		
		if (request.getCompositeType().equalsIgnoreCase(Constants.IMPCOMPOSITETYPE) && isMPGreaterThanOrEqual01012018 ) {
			sql.append(" and  md_q.msr_dsply_nm not like '%%" + Constants.PCV_MEASURE_NM + "%%' ");
		}

		sql
			.append("group by ")
			.append(StringUtil.stripAsAndUpperFromClause(buildSharedSelectGroupByColumns()))
			.append("order by ")
			.append("    next_clncl_due_dt ")
			.append("with ur ");

		return sql.toString();
	}

	protected String buildSharedSelectGroupByColumns() {

		StringBuilder select = new StringBuilder()
			.append("    md_q.msr_dsply_nm ")
			.append("    , nullif(cf.last_cmplnc_dt, '8888-12-31') as last_cmplnc_dt ")
			.append("    , nullif(cof.next_clncl_due_dt, '8888-12-31') as next_clncl_due_dt ")
			.append("    , coalesce(cof.care_oprtnty_stts_cd, -1) as care_oprtnty_stts_cd ")
			.append("    , cf.msr_nmrtr_nbr ");

		return select.toString();
	}

	protected void buildPreparedStatement(GetPatientDetailRequest request, String sql, boolean isMPGreaterThanOrEqual01012018) throws SQLException, ParseException {

		int i = 0;
		prepareStatement(logger, sql);
		
		if (null != request.getCompositeType()) {
			if (!request.getCompositeType().equalsIgnoreCase(Constants.IMPCOMPOSITETYPE)) {
				ps.setString(++i, request.getCompositeType());
			}
			else if(request.getCompositeType().equalsIgnoreCase(Constants.IMPCOMPOSITETYPE) && Constants.MEDICARE.equalsIgnoreCase(request.getProgramLobTypeCd())){
				ps.setString(++i, request.getCompositeType());
			}
			else{
				ps.setString(++i, "Quality");
			}
		}

		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());
		ps.setString(++i, request.getMemberKey());

		if (!StringUtils.isBlank(request.getAnalysisAsOfDt())) {
			ps.setString(++i, request.getAnalysisAsOfDt());
		}

		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
			ps.setString(++i, request.getMeasurementPeriodStartDt());
		}
	}

	protected List<EligibleMeasures> convertSelectedRowsToObjects(ResultSet rs) throws Exception {

		List<EligibleMeasures> list = new ArrayList<EligibleMeasures>();

		while (rs.next()) {

			EligibleMeasures r = new EligibleMeasures();
			r.setCareOppsDsplyNm(getString(rs, "msr_dsply_nm"));
			r.setCareOppsPrevDt(getDate(rs, "last_cmplnc_dt"));
			r.setClinicalDueDt(getDate(rs, "next_clncl_due_dt"));
			r.setCareOppsStatusCd(StringUtil.getValueOrNull(rs.getInt("care_oprtnty_stts_cd"))); // UI wants "null" if value is empty
			r.setCompliantStatusCd(rs.getInt("msr_nmrtr_nbr"));

			list.add(r);
		}

		return list;
	}
}
