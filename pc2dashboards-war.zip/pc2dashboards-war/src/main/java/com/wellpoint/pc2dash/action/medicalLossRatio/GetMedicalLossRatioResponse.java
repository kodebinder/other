package com.wellpoint.pc2dash.action.medicalLossRatio;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetMedicalLossRatioResponse extends ActionResponse {

}
