package com.wellpoint.pc2dash.data.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.costOpportunity.GetLabCountPopupRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.costOpportunity.LabCountPopupBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class LabCountPopupDao extends ServiceImpl {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(LabCountPopupDao.class);

	public List<LabCountPopupBean> getData(GetLabCountPopupRequest request, boolean exportFlag) throws Exception {

		List<LabCountPopupBean> result = new ArrayList<LabCountPopupBean>();
		setRowCount(0);

		StringBuilder query = new StringBuilder()
			.append(" select b.* from ( ")
			.append(" 	select a.*, row_number() over (order by ")
			.append(buildSortClause(request))
			.append(" ) as row_nbr ")
			.append(" 	from ( ")
			.append(" 		select lsmry.LAB_TAX_ID, lsmry.lab_nm ")
			.append(" 		from coc_lab_prov_smry lsmry ")
			.append(" 		join poit_user_scrty_acs pusa on (lsmry.prov_grp_id = pusa.prov_grp_id ")
			.append(" 			and ")
			.append(" 			case ")
			.append(" 				when   pusa.prov_org_tax_id = '0' ")
			.append(" 				then   lsmry.prov_org_tax_id ")
			.append(" 				else   pusa.prov_org_tax_id ")
			.append(" 			end = lsmry.prov_org_tax_id) ")
			.append(" 		where  ")
			.append(" 		pusa.sesn_id = ? ")
			.append(" 		and pusa.enttlmnt_hash_key = ? ")
			.append(" 		and lsmry.ip_dim_key = ? ")
			.append(" 		and parg_cd = 'NON-PAR' ");
			//PCMSP-20002
			if (StringUtil.isNotBlankOrFalse(request.getScorecardAnalysisOfDate())) {
				query.append(" and upper(lsmry.rpt_type_ind) = 'SC' ");
			}else{
				query.append(" and upper(lsmry.rpt_type_ind) = 'COC' ");
			}
			query.append(" 		group by LAB_TAX_ID, lab_nm ")
			.append(" 	) a ")
			.append(" ) b ")
			.append(" where b.row_nbr between ? and ? ")
			.append(" order by b.row_nbr ")
			.append(" with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());

			buildPreparedStatement(request, i);

			executeQuery(logger, query.toString());

			result = convertSelectedRowsToObjects(rs, request, exportFlag);

		}
		catch (Exception e) {

			throw new Exception("Unable to get LabCountPopupDao.", e);
		}
		finally {

			close();
		}

		return result;

	}

	private void buildPreparedStatement(GetLabCountPopupRequest request, int i) throws SQLException {

		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		ps.setInt(++i, Integer.parseInt(request.getIpDimKey()));

		int start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
		int limit = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
		ps.setInt(++i, start + 1);
		ps.setInt(++i, start + limit);

	}

	private List<LabCountPopupBean> convertSelectedRowsToObjects(ResultSet rs, GetLabCountPopupRequest request, boolean exportFlag) throws SQLException {

		List<LabCountPopupBean> list = new ArrayList<LabCountPopupBean>();

		while (rs.next()) {

			LabCountPopupBean item = new LabCountPopupBean();

			item.setLabName(rs.getString("lab_nm"));

			list.add(item);

		}

		return list;
	}

	private String buildSortClause(GetLabCountPopupRequest request) {

		StringBuilder query = new StringBuilder();
		String defaultColumn = " lab_nm ";
		String defaultSort = defaultColumn + " desc ";

		if (null != request.getSort()) {

			for (QuerySort sort : request.getSort()) {

				String dir = sort.getDirection().replaceAll("\"", "");
				String property = sort.getProperty();

				if (property.equals("labName")) {
					query.append(defaultColumn + dir);
				}
				else {
					query.append(defaultSort);
				}

			}

		}
		else {
			query.append(defaultSort);
		}

		return query.toString();

	}

}
