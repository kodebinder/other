package com.wellpoint.pc2dash.action.scoreCard;

import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;

public class GetScorecardSubcompositeRequest extends PerformanceManagementRequest {

	//	private String page;
	//	private String qualityGateRequest;
	//	
	//	public String getPage() {
	//		return page;
	//	}
	//	public String getQualityGate() {
	//		return qualityGateRequest;
	//	}
	//	public void setPage(String page) {
	//		this.page = page;
	//	}
	//	public void setQualityGate(String qualityGateRequest) {
	//		this.qualityGate = qualityGateRequest;
	//	}	

}
