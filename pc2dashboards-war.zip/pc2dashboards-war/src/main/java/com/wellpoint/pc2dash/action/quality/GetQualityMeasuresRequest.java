package com.wellpoint.pc2dash.action.quality;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.wellpoint.pc2dash.action.drilldown.GetDrillDownRequest;

/**
 * GetQualityMeasuresRequest's members are currently a subset of GetQualityPatientsRequest's.
 * Their common members are in GetQualityRequest.
 */
public class GetQualityMeasuresRequest extends GetDrillDownRequest {

	/**
	 * @return The String representation of this class as constructed via
	 *         reflection by Apache Commons ToStringBuilder.
	 */
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
