package com.wellpoint.pc2dash.action.base;

import static com.wellpoint.pc2dash.util.ReferralBeanConstants.SUCCESS;
import static com.wellpoint.pc2dash.util.ReferralBeanConstants.SUCCESSNODATA;

import java.util.Collection;

import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.ErrorProperties;


public class Pc2ResponseGenerator {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(Pc2ExceptionGenerator.class);
	private static final Integer ZERO = 0;

	public static ActionResponse buildErrorResponse(Exception e, ActionResponse response, String errorCode) {

		ErrorProperties err = ErrorProperties.getInstance();
		String msg = err.getProperty(errorCode);

		response.setSuccess(false);
		response.setMessage(msg);

		logger.error(msg, e);
		return response;
	}

	@SuppressWarnings("unchecked")
	public static ActionResponse buildSuccessResponse(ActionResponse response, Collection<? extends Object> vals, Integer... total) {

		ErrorProperties err = ErrorProperties.getInstance();
		String msg;
		response.setSuccess(true);
		response.setData((Collection<Object>) vals);

		if (null == vals || (null != vals && vals.isEmpty())) {

			msg = err.getProperty(SUCCESSNODATA);
			response.setMessage(msg);
			response.setTotal(ZERO);
		}
		else {

			msg = err.getProperty(SUCCESS);
			response.setMessage(msg);
			if (null != total && total.length != 0) {
				response.setTotal(total[0]);
			}
			else {
				response.setTotal(vals.size());
			}
		}

		logger.info(msg);
		return response;
	}
}
