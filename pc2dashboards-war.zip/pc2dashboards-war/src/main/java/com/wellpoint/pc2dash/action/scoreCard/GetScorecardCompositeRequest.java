package com.wellpoint.pc2dash.action.scoreCard;

import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;

public class GetScorecardCompositeRequest extends PerformanceManagementRequest {

	//	private String page;
	//
	//	public String getPage() {
	//		return page;
	//	}
	//
	//	public void setPage(String page) {
	//		this.page = page;
	//	}

}
