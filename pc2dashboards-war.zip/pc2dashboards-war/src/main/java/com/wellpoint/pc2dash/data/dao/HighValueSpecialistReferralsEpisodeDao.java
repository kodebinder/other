package com.wellpoint.pc2dash.data.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.costOpportunity.GetHighValueSpecialistReferralsEpisodeRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.costOpportunity.HighValueSpecialistReferralsEpisodeBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.DateUtil;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class HighValueSpecialistReferralsEpisodeDao extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(HighValueSpecialistReferralsEpisodeDao.class);

	public List<HighValueSpecialistReferralsEpisodeBean> getData(GetHighValueSpecialistReferralsEpisodeRequest request, boolean exportFlag, int index, int limit) throws Exception {

		List<HighValueSpecialistReferralsEpisodeBean> result = new ArrayList<HighValueSpecialistReferralsEpisodeBean>();
		setRowCount(0);

		boolean displayDashes = false;

		StringBuilder query = new StringBuilder()
			.append("select ")
			.append("	a.* ")
			.append("from ")
			.append("	( ")
			.append("		select ")
			.append("			row_number() over ( ")
			.append("				order by ")
			.append(buildSortClause(request))
			.append(" ) as row_nbr, ")
			.append(" mstr_cnsmr_dim_key, ip_dim_key, frst_nm,last_nm,brth_dt, age_nbr,gndr_cd,ip_frst_nm,ip_last_nm, memberId, ")
			.append(" episodeDesc, orgName, orgtin, epiStartDate, epiEndDate, totalEpisodeCost, specialistName, specialtyName, highCostSpecInd, ")
			.append(" count(*) over () as row_cnt ");
		if (StringUtil.isExportDest(request.getDest())) {
			query.append(" ,IP_SPCLTY_NM, ip_npi, lob_desc, psl_desc,home_plan_nm,crprt_plan_cmpny_nm ");
		}
		query.append(" from ( select distinct ")
			.append(" psf.MSTR_CNSMR_DIM_KEY AS mstr_cnsmr_dim_key, psf.ip_dim_key, upper(psf.frst_nm) as frst_nm, upper(psf.last_nm) as last_nm, ")
			.append(" nullif(psf.brth_dt, '0001-01-01') as brth_dt, psf.age_nbr,psf.gndr_cd, upper(psf.ip_frst_nm) as ip_frst_nm, ")
			.append(" upper(psf.ip_last_nm) as ip_last_nm, psf.hc_id memberId, smry.epsd_desc as episodeDesc, psf.prov_org_full_nm  as orgName , psf.prov_org_tax_id as orgtin, ")
			.append(" smry.epsd_strt_dt as epiStartDate, smry.epsd_end_dt as epiEndDate, sum(epsd_cost_amt) as totalEpisodeCost, ")
			.append(" smry.spclty_prov_nm as specialistName, smry.sub_mtrc_nm as specialtyName, max(smry.hcost_ind) as highCostSpecInd ");
		if (StringUtil.isExportDest(request.getDest())) {
			query.append(" ,psf.IP_SPCLTY_NM, psf.ip_npi, ")
				.append(" psf.lob_desc, psf.psl_desc, psf.crprt_plan_cmpny_nm,psf.home_plan_nm ");
		}
		query.append(" 	from coc_spclty_dtl_smry smry ")
			.append(" JOIN PAT_SMRY_FACT PSF ON  PSF.MSTR_CNSMR_DIM_KEY = smry.MSTR_CNSMR_DIM_KEY ")
			.append("	join poit_user_scrty_acs pusa on ( ")
			.append("		psf.prov_grp_id = pusa.prov_grp_id ")
			.append("		and case ")
			.append("				when pusa.prov_org_tax_id = '0' then psf.prov_org_tax_id ")
			.append("				else pusa.prov_org_tax_id ")
			.append("			end = psf.prov_org_tax_id ")
			.append("	) ")
			.append(" WHERE  ")
			.append(" PSF.ATRBN_STTS_CD = 'ACTIVE' ")
			.append(" and pusa.sesn_id = ? ")
			.append(" and pusa.enttlmnt_hash_key = ? ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and smry.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and smry.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and smry.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and smry.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and smry.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}
		
		if (request.isHighCostSpecialistInd()) {
			query.append(" and smry.hcost_ind = 1 ");
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getSpecialistCode())) {
			query.append(" and smry.SPCLTY_PROV_ID = ? ");
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getSpecialistName())) {
			query.append(" and upper(smry.spclty_prov_nm) like ? ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getSpecialtyCode())) {
			query.append(" and smry.SUB_MTRC_CD in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getSpecialtyCode())
				+ ") ");
		}

		query.append(" group by psf.MSTR_CNSMR_DIM_KEY , psf.ip_dim_key, upper(psf.frst_nm) , upper(psf.last_nm) ,")
			.append(" nullif(psf.brth_dt, '0001-01-01') , psf.age_nbr,psf.gndr_cd, upper(psf.ip_frst_nm) ,  upper(psf.ip_last_nm) , ")
			.append("psf.hc_id , smry.epsd_desc ,psf.prov_org_full_nm , psf.prov_org_tax_id, smry.epsd_strt_dt, smry.epsd_end_dt ,")
			.append(" smry.spclty_prov_nm , smry.sub_mtrc_nm ,SMRY.EPSD_NBR ");

		if (StringUtil.isExportDest(request.getDest())) {
			query.append(" ,psf.IP_SPCLTY_NM, psf.ip_npi, ")
				.append(" psf.lob_desc, psf.psl_desc, psf.crprt_plan_cmpny_nm, psf.home_plan_nm ");
		}
		query.append(") ) a ");

/*		if (!exportFlag) {
			query.append(" where a.row_nbr between ? and ? ");
		}
		query.append(" order by a.row_nbr  with ur ");*/
		query.append(" where a.row_nbr between ? and ? ");
		query.append(" order by a.row_nbr  with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());

			buildPreparedStatement(request, i, exportFlag, index, limit);

			executeQuery(logger, query.toString());

			result = convertSelectedRowsToObjects(rs, request, displayDashes, exportFlag);

		}
		catch (Exception e) {

			throw new Exception("Unable to get HighValueSpecialistReferralsEpisodeDao (" + request.getEntitlementId() + ").", e);
		}
		finally {

			close();
		}

		return result;

	}

	private void buildPreparedStatement(GetHighValueSpecialistReferralsEpisodeRequest request, int i, boolean exportFlag, int index, int limit) throws SQLException {
		
		int start = 0;
		int stop = 0;
		
		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getSpecialistCode())) {
			ps.setString(++i, request.getSpecialistCode());
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getSpecialistName())) {
			ps.setString(++i, "%" + request.getSpecialistName().toUpperCase() + "%");
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getSpecialtyCode())) {
			String[] array = request.getSpecialtyCode().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (!exportFlag) {
			start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
			stop = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
		}
		else {
			start = index;
			stop = limit;
		}
		ps.setInt(++i, start + 1);
		ps.setInt(++i, start + stop);

	}

	private List<HighValueSpecialistReferralsEpisodeBean> convertSelectedRowsToObjects(ResultSet rs, GetHighValueSpecialistReferralsEpisodeRequest request,
		boolean displayDashes, boolean exportFlag)
		throws SQLException {

		List<HighValueSpecialistReferralsEpisodeBean> list = new ArrayList<HighValueSpecialistReferralsEpisodeBean>();

		if (exportFlag) {
			while (rs.next()) {

				HighValueSpecialistReferralsEpisodeBean item = new HighValueSpecialistReferralsEpisodeBean();

				if (rs.getString("age_nbr") != null)
					item.setMemberAge(rs.getShort("age_nbr"));
				if (rs.getString("brth_dt") != null) {
					item.setMemberDOB(DateUtil.formatDateToMMDDYYYY(
						"yyyy-MM-dd", "M/d/yyyy", rs.getString("brth_dt")));
				}
				else {
					item.setMemberDOB(Constants.DASHES);
				}
				item.setMemberLastName(StringUtil.getValueOrDashes(rs.getString("last_nm")));
				item.setMemberFirstName(StringUtil.getValueOrDashes(rs.getString("frst_nm")));
				item.setMemberGender(StringUtil.getValueOrDashes(rs.getString("gndr_cd")));
				item.setMemberId(StringUtil.getValueOrDashes(rs.getString("memberId")));
				item.setEpisodeDescription(StringUtil.getValueOrDashes(rs.getString("episodeDesc")));

				if (rs.getString("frst_nm") != null
					&& rs.getString("last_nm") != null)
					item.setMemberFullName(StringUtil.buildFullName(
						rs.getString("frst_nm"), rs.getString("last_nm")));

				if (rs.getString("mstr_cnsmr_dim_key") != null)
					item.setMemberKey(rs.getLong("mstr_cnsmr_dim_key"));

				if (rs.getString("epiStartDate") != null) {
					item.setEpisodeStartDt(DateUtil.formatDateToMMDDYYYY(
						"yyyy-MM-dd", "M/d/yyyy", rs.getString("epiStartDate")));
				}
				else {
					item.setEpisodeStartDt(Constants.DASHES);
				}

				if (rs.getString("epiEndDate") != null) {
					item.setEpisodeEndDt(DateUtil.formatDateToMMDDYYYY(
						"yyyy-MM-dd", "M/d/yyyy", rs.getString("epiEndDate")));
				}
				else {
					item.setEpisodeEndDt(Constants.DASHES);
				}
				
				//PCMSP-13760
				/*if (!(Constants.STAR.equalsIgnoreCase(rs.getString("ip_last_nm")) || Constants.UNK.equalsIgnoreCase(rs.getString("ip_last_nm")))
					&& !(Constants.STAR.equalsIgnoreCase(rs.getString("ip_frst_nm")) || Constants.UNK.equalsIgnoreCase(rs.getString("ip_frst_nm")))) {*/
				if (!Constants.STAR.equalsIgnoreCase(rs.getString("ip_last_nm")) && !Constants.STAR.equalsIgnoreCase(rs.getString("ip_frst_nm"))) {
				//PCMSP-13760 - ends
					item.setAttributedPhysicianName(rs.getString("ip_last_nm").trim() + ", " + rs.getString("ip_frst_nm").trim());
				}
				else if (!(Constants.STAR.equalsIgnoreCase(rs.getString("ip_last_nm")) || Constants.UNK.equalsIgnoreCase(rs.getString("ip_last_nm")))) {
					item.setAttributedPhysicianName(rs.getString("ip_last_nm").trim());
				}
				else {
					item.setAttributedPhysicianName(Constants.UNK);
				}

				item.setAttributedProvNpi(StringUtil.getValueOrDashes(rs.getString("ip_npi")));
				item.setAttributedProvSpeciality(StringUtil.getValueOrDashes(rs.getString("IP_SPCLTY_NM")));
				item.setMemberProduct(StringUtil.getValueOrDashes(rs.getString("psl_desc")));
				item.setMemberLob(StringUtil.getValueOrDashes(rs.getString("lob_desc")));
				item.setMemberHomePlanParentCo(StringUtil.getValueOrDashes(rs.getString("crprt_plan_cmpny_nm")));
				item.setMemberHomePlan(StringUtil.getValueOrDashes(rs.getString("home_plan_nm")));
				item.setSpecialistName(StringUtil.getValueOrDashes(rs.getString("specialistName")));
				item.setSpecialtyName(StringUtil.getValueOrDashes(rs.getString("specialtyName")));
				if (null != rs.getString("totalEpisodeCost")) {
					item.setTotalEpisodeCost((rs.getBigDecimal("totalEpisodeCost").intValue() >= 0)
							? StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("totalEpisodeCost")
									.setScale(2, BigDecimal.ROUND_HALF_UP).toString())
							: Constants.DASHES);
				}

				//item.setOrganizationName(StringUtil.getValueOrDashes(rs.getString("orgName")));
				//Changed for release-Q1-2018/PCMSP-18748 : Starts
				if(null!= rs.getString("orgName"))
					item.setOrganizationName(rs.getString("orgName"));
				else
					item.setOrganizationName(Constants.DASHES);
				//Changed for release-Q1-2018/PCMSP-18748 : Ends;
				item.setOrganizationTin(StringUtil.getValueOrDashes(rs.getString("orgtin")));
				
				if (rs.getInt("highCostSpecInd") == 0) {
					item.setHighCostSpecialistInd(Constants.BOOL_FALSE);
				}
				else {
					item.setHighCostSpecialistInd(Constants.BOOL_TRUE);
				}

				list.add(item);

				if (getRowCount() == 0) {
					setRowCount(rs.getInt("row_cnt"));
				}
				
				setTotalExport(rs.getInt("row_cnt"));
			}
		}
		else {
			while (rs.next()) {

				HighValueSpecialistReferralsEpisodeBean item = new HighValueSpecialistReferralsEpisodeBean();

				if (rs.getString("age_nbr") != null)
					item.setMemberAge(rs.getShort("age_nbr"));
				if (rs.getString("brth_dt") != null) {
					item.setMemberDOB(DateUtil.formatDateToMMDDYYYY(
						"yyyy-MM-dd", "M/d/yyyy", rs.getString("brth_dt")));
				}
				else {
					item.setMemberDOB(Constants.DASHES);
				}
				item.setMemberLastName(StringUtil.getValueOrDashes(rs.getString("last_nm")));
				item.setMemberFirstName(StringUtil.getValueOrDashes(rs.getString("frst_nm")));
				item.setMemberGender(StringUtil.getValueOrDashes(rs.getString("gndr_cd")));
				item.setMemberId(StringUtil.getValueOrDashes(rs.getString("memberId")));
				item.setEpisodeDescription(StringUtil.getValueOrDashes(rs.getString("episodeDesc")));

				if (rs.getString("frst_nm") != null
					&& rs.getString("last_nm") != null)
					item.setMemberFullName(StringUtil.buildFullName(
						rs.getString("frst_nm"), rs.getString("last_nm")));

				if (rs.getString("mstr_cnsmr_dim_key") != null)
					item.setMemberKey(rs.getLong("mstr_cnsmr_dim_key"));

				if (rs.getString("epiStartDate") != null) {
					item.setEpisodeStartDt(DateUtil.formatDateToMMDDYYYY(
						"yyyy-MM-dd", "M/d/yyyy", rs.getString("epiStartDate")));
				}
				else {
					item.setEpisodeStartDt(Constants.DASHES);
				}

				if (rs.getString("epiEndDate") != null) {
					item.setEpisodeEndDt(DateUtil.formatDateToMMDDYYYY(
						"yyyy-MM-dd", "M/d/yyyy", rs.getString("epiEndDate")));
				}
				else {
					item.setEpisodeEndDt(Constants.DASHES);
				}

				//PCMSP-13760
				/*if (!(Constants.STAR.equalsIgnoreCase(rs.getString("ip_last_nm")) || Constants.UNK.equalsIgnoreCase(rs.getString("ip_last_nm")))
					&& !(Constants.STAR.equalsIgnoreCase(rs.getString("ip_frst_nm")) || Constants.UNK.equalsIgnoreCase(rs.getString("ip_frst_nm")))) {*/
				if (!Constants.STAR.equalsIgnoreCase(rs.getString("ip_last_nm")) && !Constants.STAR.equalsIgnoreCase(rs.getString("ip_frst_nm"))) {
				//PCMSP-13760 - ends
					item.setAttributedPhysicianName(rs.getString("ip_last_nm").trim() + ", " + rs.getString("ip_frst_nm").trim());
				}
				else if (!(Constants.STAR.equalsIgnoreCase(rs.getString("ip_last_nm")) || Constants.UNK.equalsIgnoreCase(rs.getString("ip_last_nm")))) {
					item.setAttributedPhysicianName(rs.getString("ip_last_nm").trim());
				}
				else {
					item.setAttributedPhysicianName(Constants.UNK);
				}

				//item.setOrganizationName(StringUtil.getValueOrDashes(rs.getString("orgName")));
				//Changed for release-Q1-2018/PCMSP-18748 : Starts
				if(null!= rs.getString("orgName"))
					item.setOrganizationName(rs.getString("orgName"));
				else
					item.setOrganizationName(Constants.DASHES);
				//Changed for release-Q1-2018/PCMSP-18748 : Ends;
				item.setOrganizationTin(StringUtil.getValueOrDashes(rs.getString("orgtin")));
				item.setSpecialistName(StringUtil.getValueOrDashes(rs.getString("specialistName")));
				item.setSpecialtyName(StringUtil.getValueOrDashes(rs.getString("specialtyName")));
				item.setTotalEpisodeCost(StringUtil.getValueOrDashes(rs.getString("totalEpisodeCost")));
				if (rs.getInt("highCostSpecInd") == 0) {
					item.setHighCostSpecialistInd(Constants.BOOL_FALSE);
				}
				else {
					item.setHighCostSpecialistInd(Constants.BOOL_TRUE);
				}

				list.add(item);

				if (getRowCount() == 0) {
					setRowCount(rs.getInt("row_cnt"));
				}

			}

		}

		return list;

	}

	private String buildSortClause(GetHighValueSpecialistReferralsEpisodeRequest request) {

		StringBuilder query = new StringBuilder();
		String defaultColumn = " totalEpisodeCost ";
		String defaultSort = defaultColumn + " desc ";

		if (null != request.getSort()) {

			for (QuerySort sort : request.getSort()) {

				String dir = sort.getDirection().replaceAll("\"", "");
				String property = sort.getProperty();

				if (property.equals("episodeDescription")) {
					query.append(" episodeDesc " + dir + ", " + defaultSort);
				}
				else if (property.equals("memberFullName")) {
					query.append("  last_nm " + dir + ", frst_nm " + dir);
				}
				else if (property.equals("attributedPhysicianName")) {
					query.append(" ip_last_nm " + dir + ", ip_frst_nm " + dir);
				}
				else if (property.equals("organizationName")) {
					query.append(" orgName " + dir + ", " + defaultSort);
				}
				else if (property.equals("episodeStartDt")) {
					query.append(" epiStartDate " + dir + ", " + defaultSort);
				}
				else if (property.equals("episodeEndDt")) {
					query.append(" epiEndDate " + dir + ", " + defaultSort);
				}
				else if (property.equals("specialistName")) {
					query.append(" specialistName " + dir + ", " + defaultSort);
				}
				else if (property.equals("specialtyName")) {
					query.append(" specialtyName " + dir + ", " + defaultSort);
				}
				else {
					query.append(defaultColumn + dir);
				}
			}

		}

		return query.toString();

	}

	@Override
	public boolean read(Dto o) throws Exception {
		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {
		
	}

	@Override
	public void update(Dto o) throws Exception {
		
	}

	@Override
	public void delete(Dto o) throws Exception {
		
	}

}

