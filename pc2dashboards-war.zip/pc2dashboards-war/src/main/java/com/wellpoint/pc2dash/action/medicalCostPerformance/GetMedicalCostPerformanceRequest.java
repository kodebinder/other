package com.wellpoint.pc2dash.action.medicalCostPerformance;

import com.wellpoint.pc2dash.action.medicalCostServiceDetails.GetMedicalCostServiceDetailsRequest;

public class GetMedicalCostPerformanceRequest extends GetMedicalCostServiceDetailsRequest {

}
