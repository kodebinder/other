package com.wellpoint.pc2dash.action.login;

import com.wellpoint.pc2dash.data.dto.PCMSRequest;
import com.wellpoint.pc2dash.util.StringUtil;


public class GetEntitlementRequest extends PCMSRequest {

	protected String groupId;

	public boolean isValid() {

		if (!StringUtil.isNotBlankOrFalse(this.groupId))
			return false;

		return true;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
}
