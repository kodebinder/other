package com.wellpoint.pc2dash.dao;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class IpDim implements Serializable {
	private static final long serialVersionUID = 1L;

	private long ipDimKey;

	private long crtdLoadLogKey;

	private String ipCtgryCd;

	private Date ipEfctvDt;

	private String ipFrstNm;

	private String ipId;

	private String ipLastNm;

	private String ipMidNm;

	private String ipNpi;

	private Date ipTrmntnDt;

	private String provSorCd;

	private String rcrdSttsCd;

	private Timestamp sorDtm;

	private String txnmyLvlIiCd;

	private long updtdLoadLogKey;

	// bi-directional many-to-one association to ProvGrpHrchyDim
	private List<ProvGrpHrchyDim> provGrpHrchyDims;

	// bi-directional many-to-one association to VstFact
	private List<VstFact> vstFacts;

	public IpDim() {}

	public long getIpDimKey() {
		return this.ipDimKey;
	}

	public void setIpDimKey(long ipDimKey) {
		this.ipDimKey = ipDimKey;
	}

	public long getCrtdLoadLogKey() {
		return this.crtdLoadLogKey;
	}

	public void setCrtdLoadLogKey(long crtdLoadLogKey) {
		this.crtdLoadLogKey = crtdLoadLogKey;
	}

	public String getIpCtgryCd() {
		return this.ipCtgryCd;
	}

	public void setIpCtgryCd(String ipCtgryCd) {
		this.ipCtgryCd = ipCtgryCd;
	}

	public Date getIpEfctvDt() {
		return this.ipEfctvDt;
	}

	public void setIpEfctvDt(Date ipEfctvDt) {
		this.ipEfctvDt = ipEfctvDt;
	}

	public String getIpFrstNm() {
		return this.ipFrstNm;
	}

	public void setIpFrstNm(String ipFrstNm) {
		this.ipFrstNm = ipFrstNm;
	}

	public String getIpId() {
		return this.ipId;
	}

	public void setIpId(String ipId) {
		this.ipId = ipId;
	}

	public String getIpLastNm() {
		return this.ipLastNm;
	}

	public void setIpLastNm(String ipLastNm) {
		this.ipLastNm = ipLastNm;
	}

	public String getIpMidNm() {
		return this.ipMidNm;
	}

	public void setIpMidNm(String ipMidNm) {
		this.ipMidNm = ipMidNm;
	}

	public String getIpNpi() {
		return this.ipNpi;
	}

	public void setIpNpi(String ipNpi) {
		this.ipNpi = ipNpi;
	}

	public Date getIpTrmntnDt() {
		return this.ipTrmntnDt;
	}

	public void setIpTrmntnDt(Date ipTrmntnDt) {
		this.ipTrmntnDt = ipTrmntnDt;
	}

	public String getProvSorCd() {
		return this.provSorCd;
	}

	public void setProvSorCd(String provSorCd) {
		this.provSorCd = provSorCd;
	}

	public String getRcrdSttsCd() {
		return this.rcrdSttsCd;
	}

	public void setRcrdSttsCd(String rcrdSttsCd) {
		this.rcrdSttsCd = rcrdSttsCd;
	}

	public Timestamp getSorDtm() {
		return this.sorDtm;
	}

	public void setSorDtm(Timestamp sorDtm) {
		this.sorDtm = sorDtm;
	}

	public String getTxnmyLvlIiCd() {
		return this.txnmyLvlIiCd;
	}

	public void setTxnmyLvlIiCd(String txnmyLvlIiCd) {
		this.txnmyLvlIiCd = txnmyLvlIiCd;
	}

	public long getUpdtdLoadLogKey() {
		return this.updtdLoadLogKey;
	}

	public void setUpdtdLoadLogKey(long updtdLoadLogKey) {
		this.updtdLoadLogKey = updtdLoadLogKey;
	}

	public List<ProvGrpHrchyDim> getProvGrpHrchyDims() {
		return this.provGrpHrchyDims;
	}

	public void setProvGrpHrchyDims(List<ProvGrpHrchyDim> provGrpHrchyDims) {
		this.provGrpHrchyDims = provGrpHrchyDims;
	}

	public List<VstFact> getVstFacts() {
		return this.vstFacts;
	}

	public void setVstFacts(List<VstFact> vstFacts) {
		this.vstFacts = vstFacts;
	}
}
