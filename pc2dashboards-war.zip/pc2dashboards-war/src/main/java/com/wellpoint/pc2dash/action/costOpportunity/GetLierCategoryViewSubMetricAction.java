package com.wellpoint.pc2dash.action.costOpportunity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.dto.costOpportunity.LierCategoryViewSubMetricBean;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportGridColumn;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.costOpportunity.CostOpportunityLierCategoryExport;
import com.wellpoint.pc2dash.service.costOpportunity.COCLierCategoryViewSubMetricServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetLierCategoryViewSubMetricAction extends Action {
    
    @Override
    public ActionResponse process(ActionRequest actionRequest) {
        
        List<LierCategoryViewSubMetricBean> resultList = new ArrayList<LierCategoryViewSubMetricBean>();
       
        GetLierCategoryViewSubMetricResponse response = new GetLierCategoryViewSubMetricResponse();
        GetLierCategoryViewSubMetricRequest request = (GetLierCategoryViewSubMetricRequest) actionRequest;
        ErrorProperties err = ErrorProperties.getInstance();

        COCLierCategoryViewSubMetricServiceImpl service = new COCLierCategoryViewSubMetricServiceImpl();
        List<String> grps = null;
        
        try {

            removeLobPgmPrefixes(request);
            
            if (StringUtils.isNotBlank(request.getCmpId())) {
                grps = filterProvGrpsByKillSwitch(request);
            }

            if (null != grps && !grps.isEmpty()) {
                request.setProvGrpIdsWithoutClinicalCheck(StringUtils.join(grps, ','));
                grps = filterProvGrpsByClincalFinancialInd(request, grps);
                request.setProvGrpIds(CollectionUtils.isNotEmpty(grps) ? StringUtils.join(grps, ',') : Constants.DASHES);
            }
            
            CommonQueries cq = new CommonQueries();
			request.setTapId(request.getMetricViewId());// TO re-use available tap framework.
			request.setSuppression(cq.getActiveSuppressionForSelectComponents(request));
			
			MetaData metaData = new MetaData();
			metaData.setReportingPeriod(cq.getReportingPeriodForCostOpportunity(Constants.LOW_INTENSITY_ER));
			metaData.setReportDate(cq.getReportDateForCostOpportunity(Constants.LOW_INTENSITY_ER));
			
            if (StringUtil.isExportDest(request.getDest())) {
            	request.setReportingPeriod(metaData.getReportingPeriod());
            	request.setReportDate(metaData.getReportDate());
            	List<ExportGridColumn> columns = service.buildExportGridColumns(request);
            	CostOpportunityLierCategoryExport exp = new CostOpportunityLierCategoryExport(request, columns);
				ExportProcessor.getInstance().submit(exp);
            }
            else {

                if (null != grps && !grps.isEmpty()) {
                	request.setHasLIERDrilldownInd(isUserClinical(request) && !isComponentSuppressed(request, "er-visits"));
                    resultList = service.getData(request);
                    
                    if (null == resultList || resultList.isEmpty()) {
                        response.setMessage(err.getProperty("successNoData"));
                    }
                    else {
                        response.setMetaData(metaData);
                        response.setMessage(err.getProperty("successful"));
                        response.setData(resultList);
                        response.setTotal(service.getRowCount());
                    }
                }
            }

            response.setSuccess(true);
            return response;
        }
        catch (Exception pe) {

            Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
            return pce.checkException(pe, response);
        }
    
    }

}
