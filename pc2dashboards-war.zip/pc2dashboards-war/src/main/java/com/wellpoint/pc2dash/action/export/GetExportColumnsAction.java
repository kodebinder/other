package com.wellpoint.pc2dash.action.export;

import java.util.List;
import java.util.Map;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.data.dao.AppProperties;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportColumn;
import com.wellpoint.pc2dash.service.export.ExportColumnsServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetExportColumnsAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetExportColumnsRequest request = (GetExportColumnsRequest) actionRequest;
		GetExportColumnsResponse response = new GetExportColumnsResponse();
		ErrorProperties err = ErrorProperties.getInstance();

		ExportColumnsServiceImpl service = new ExportColumnsServiceImpl();

		try {

			removeLobPgmPrefixes(request);
			prepareChronicCareGapMap(request);

			CommonQueries cq = new CommonQueries();

			request.setUnsuppressedLOBsTotalCost(getLOBsWithoutTotalCostSuppressed(request));

			// 240046
			// MKT is a special case: since we don't ever populate PCMSRequest's "market" field,
			// and since there will only ever be 1 MKT per login,
			// and since we need it for export column suppression, 
			// populate it now with the first 2 characters of provGrpIds.
			if (StringUtil.isNotBlankOrFalse(request.getProvGrpIds())) {
				request.setMarket(request.getProvGrpIds().substring(0, 2));
			}
			request.setSuppression(cq.getActiveSuppressionForSelectComponents(request));

			List<ExportColumn> resultList = service.getData(request);

            if (null == resultList) {
              response.setMessage(err.getProperty("successNoData"));
            } else if (resultList.isEmpty()) {
              response.setMessage(err.getProperty("successNoData"));
            }
			else {
				// Retrieve the metaData (properties that start with either "pdf" or "export",
				// until we have a more reliable way of distinguishing them)
				AppProperties props = new AppProperties();
				Map<String, String> metaData = props.getPropertiesRelatedToExport(request);

				response.setMessage(err.getProperty("successful"));
				response.setChildren(resultList);
				response.setMetaData(metaData);
			}

		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

		response.setId("root");
		response.setText(".");
		response.setSuccess(true);
		return response;

	}


}
