package com.wellpoint.pc2dash.action.scoreCard;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.scorecard.commercial.CommercialScorecardCompositeServiceImpl;
import com.wellpoint.pc2dash.service.scorecard.commercial.EsnCommercialScorecardCompositeServiceImpl;
import com.wellpoint.pc2dash.service.scorecard.commercial.FpccCommercialScorecardCompositeServiceImpl;
import com.wellpoint.pc2dash.service.scorecard.medicaid.MedicaidScorecardCompositeServiceImpl;
import com.wellpoint.pc2dash.service.scorecard.medicare.EsnMedicareScorecardCompositeServiceImpl;
import com.wellpoint.pc2dash.service.scorecard.medicare.MedicareScorecardCompositeServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetScorecardCompositeAction extends Action {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetScorecardCompositeAction.class);

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		ActionResponse result = new GetScorecardCompositeResponse();
		GetScorecardCompositeRequest request = (GetScorecardCompositeRequest) actionRequest;
		ErrorProperties err = ErrorProperties.getInstance();

		try {

			Collection<Object> vals = new ArrayList<Object>();
			// preserve dataMap logic
			removeLobPgmPrefixes(request);
			/*
			 * String entId = rqst.getEntitlementId(); vals =
			 * getScorecardComposites(entId);
			 */
			//PCMSRequest request = new HashMap<String, String>();
			// request.put("entId",rqst.getEntitlementId());
			// request.setCompositeId(rqst.getCompositeId());
			//			request.put("viewBy", request.getViewBy());
			//			request.put("msrmntStrtDt", request.getMeasurementPeriodStartDt());
			//			request.put("msrmntEndDt", request.getMeasurementPeriodEndDt());
			//			request.put("provGrpId", request.getProviderGroupId());
			//			request.put("provGrpDimKey", request.getProviderGroupDimKey());
			//			request.put("measurementInterval", request.getMeasurementInterval());
			//			request.put("prgmId", request.getProgramId());
			/*
			 * Adding the programLobTypeCd parameter to the datamap
			 * The value is going to be the pgmLobTypCd
			 */
			//			request.put("programLobTypeCd", request.getProgramLobTypeCd());
			//			request.put("lob", request.getLob());
			//			request.put("lobNm", request.getLobNm());
			//			request.put("lobDimKeys", JSONUtils.removeFirstOccurenceOfCharsFromJsonString(request.getLobDimKeys(), Constants.LOB_ID_PREFIX));
			//			request.setCompositeType(request.getCompositeType());
			/*request.put("measurementInterval",
					Constants.getQuarterName(rqst.getMeasurementInterval()));*/
			/*
			 * SimpleDateFormat sdf = new SimpleDateFormat();
			 * sdf.applyPattern("MM/dd/yyyy"); Date date =
			 * sdf.parse("31/12/2013");
			 */
			//GBD part 2
			//request.setCmpId(request.getCmpId());
			//request.setProvGrpIds(request.getProviderGroupId());
			//			request.put(Constants.USER_ACS_INFO_JSON, request.getUserAcsInfoJson());

			//Copyright msg
			//			request.put(Constants.COPYRIGHT_MSG, request.getCopyRightMsg());

			//request.put("sessionId", request.getSessionId());
			//request.put("entitlementId", request.getEntitlementId());
			//TODO fix to be verified; throwing a parse Exception on "false" date

			/*
			 * Date uiDate = sdf.parse("00/00/0000"); if(null !=
			 * rqst.getMeasurementPeriodStartDt() &&
			 * !(rqst.getMeasurementPeriodStartDt().equalsIgnoreCase("false")))
			 * uiDate = sdf.parse(rqst.getMeasurementPeriodStartDt());
			 */

			// Do not show data before 31/12/2013. This is a temporary check.
			SimpleDateFormat sdf = new SimpleDateFormat();
			sdf.applyPattern("dd/MM/yyyy");
			Date currentDate = sdf.parse("31/12/2013");
			Date uiDate = sdf.parse(request.getMeasurementPeriodStartDt());

			if (!currentDate.before(uiDate)) {
				result.setMessage(err.getProperty("successNoData"));
				result.setData(vals);
				result.setTotal(0);
				result.setSuccess(true);
			}
			else {

				List<String> filteredProvGrpList = new ArrayList<String>();
				List<String> filteredProvGrpListOnAccess = null;
				String provGrpCSVWithGrpIndY = "";
				String provGrpCSVWithGrpIndN = "";

				//Kill switch check on Provider groups
				if (null != request) {
					filteredProvGrpList = filterProvGrpsByKillSwitch(request);
				}

				if (null != request && null != filteredProvGrpList && filteredProvGrpList.size() > 0) {
					//Clinical & Financial access check on provider groups
					filteredProvGrpListOnAccess = filterProvGrpsByClincalFinancialInd(request, filteredProvGrpList);

				}

				if (null != request && null != filteredProvGrpListOnAccess && filteredProvGrpListOnAccess.size() > 0) {
					provGrpCSVWithGrpIndY = prepareProvGrpCSVWithGrpInd(request, filteredProvGrpListOnAccess, Constants.CLINICAL_IND_Y);
					provGrpCSVWithGrpIndN = prepareProvGrpCSVWithGrpInd(request, filteredProvGrpListOnAccess, Constants.CLINICAL_IND_N);
				}

				//Group Ind Y list
				if (null != request && null != provGrpCSVWithGrpIndY && !provGrpCSVWithGrpIndY.isEmpty()) {
					request.setProvGrpIds(provGrpCSVWithGrpIndY);
					request.setGrpInd(Constants.GRP_IND_Y);
					vals = getScorecardComposites(request);
				}

				//Group Ind N list
				if (null != request && null != provGrpCSVWithGrpIndN && !provGrpCSVWithGrpIndN.isEmpty()) {
					request.setProvGrpIds(provGrpCSVWithGrpIndN);
					request.setGrpInd(Constants.GRP_IND_N);
					Collection<Object> values = getScorecardComposites(request);
					if (null != values) {
						vals.addAll(values);
					}
				}
				if (null == vals || (null != vals && vals.isEmpty())) {
					result.setMessage(err.getProperty("successNoData"));
					result.setData(vals);
					result.setTotal(0);
				}
				else {
					result.setMessage(err.getProperty("successful"));
					result.setData(vals);
					result.setTotal(vals.size());
				}

				result.setSuccess(true);
			}
		}
		catch (Exception e) {

			logger.error("Unable to retrieve Scorecard composite  detail.", e);

			result.setMessage("Unable to retrieve Scorecard composite  detail.");
			result.setSuccess(false);
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getScorecardComposites(PerformanceManagementRequest request) throws Exception {

		Collection<?> details = null;
		String lobDesc = request.getLobNm();
		/** Release 1.9 <UT> <AD12140> */
		String lobName = StringUtil.lobSuppressedIndicator(lobDesc);
		String pgmLobTypeCd = request.getProgramLobTypeCd();

		/**
		 * Updating the logic based on the defect WLPRD02524865 and as per the suggestion from Vishal J. to drive scorecard based on
		 * PGM_LOB_TYPE_CD and not on lob
		 * Author - AD12140
		 * Commenting the below logic
		 */
		/*if(null != lobName && lobName.equalsIgnoreCase(Constants.COMMERCIAL)){
			if(null != pgmLobTypeCd)
				if(pgmLobTypeCd.contains(Constants.FPCC_PGM_TYPE)){
					FpccCommercialScorecardCompositeServiceImpl dao = new FpccCommercialScorecardCompositeServiceImpl();
					details = dao.getFpccScorecardComposites(request);
				}else{
					CommercialScorecardCompositeServiceImpl dao = new CommercialScorecardCompositeServiceImpl();
					details = dao.getScorecardComposites(request);
				}
		}
		else if(null != lobName && lobName.equalsIgnoreCase(Constants.MEDICAID)){
			MedicaidScorecardCompositeServiceImpl dao = new MedicaidScorecardCompositeServiceImpl();
			details = dao.getScorecardComposites(request);
		}
		else if(null != lobName && lobName.equalsIgnoreCase(Constants.MEDICARE)){
			MedicareScorecardCompositeServiceImpl dao = new MedicareScorecardCompositeServiceImpl();
			if(null != pgmLobTypeCd){
				if(pgmLobTypeCd.contains(Constants.FPCC_PGM_TYPE))
					details = dao.getFpccMedicareScorecardComposites(request);
				else 
					details = dao.getEphcMedicareScorecardComposites(request);
			}
		}*/

		if (!Constants.SUPPRESSED.equalsIgnoreCase(lobName)) {
			
			if (null != pgmLobTypeCd && pgmLobTypeCd.trim().equalsIgnoreCase(Constants.ESN_COMMERCIAL)) {
			//if (null != pgmLobTypeCd && pgmLobTypeCd.trim().equalsIgnoreCase(Constants.COMMERCIAL)) {
				EsnCommercialScorecardCompositeServiceImpl dao = new EsnCommercialScorecardCompositeServiceImpl();
					details = dao.getEsnScorecardComposites(request);
			}
			else if (null != pgmLobTypeCd && pgmLobTypeCd.trim().toUpperCase().contains(Constants.COMMERCIAL.toUpperCase())) {
				if (pgmLobTypeCd.trim().toUpperCase().contains(Constants.FPCC_PGM_TYPE)) {
					FpccCommercialScorecardCompositeServiceImpl dao = new FpccCommercialScorecardCompositeServiceImpl();
					details = dao.getFpccScorecardComposites(request);
				}
				else {
					CommercialScorecardCompositeServiceImpl dao = new CommercialScorecardCompositeServiceImpl();
					details = dao.getScorecardComposites(request);
				}
			}
			else if (null != pgmLobTypeCd && pgmLobTypeCd.trim().toUpperCase().contains(Constants.MEDICAID.toUpperCase())) {
				MedicaidScorecardCompositeServiceImpl dao = new MedicaidScorecardCompositeServiceImpl();
				details = dao.getScorecardComposites(request);
			}
			else if (null != pgmLobTypeCd && pgmLobTypeCd.trim().equalsIgnoreCase(Constants.ESN_MEDICARE)) {
					EsnMedicareScorecardCompositeServiceImpl dao = new EsnMedicareScorecardCompositeServiceImpl();
						details = dao.getEsnScorecardComposites(request);
				}
			else if (null != pgmLobTypeCd && pgmLobTypeCd.trim().toUpperCase().contains(Constants.MEDICARE.toUpperCase())) {
				MedicareScorecardCompositeServiceImpl dao = new MedicareScorecardCompositeServiceImpl();
				if (pgmLobTypeCd.trim().toUpperCase().contains(Constants.FPCC_PGM_TYPE)) {
					details = dao.getFpccMedicareScorecardComposites(request);
				}
				else {
					details = dao.getEphcMedicareScorecardComposites(request);
				}
			}
		}


		return (Collection<Object>) details;
	}

}
