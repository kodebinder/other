package com.wellpoint.pc2dash.dao;

import java.io.Serializable;
import java.sql.Timestamp;

public class ClnclMsrHrchyDim implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long clnclMsrHrchyDimKey;

	private Long crtdLoadLogKey;

	private String msrSprsIndCd;

	private String intrvntnTypeNm;

	private String prmryCndtnNm;

	private String prmryCndtnShrtNm;

	private String rcrdSttsCd;

	private Timestamp sorDtm;

	private Long updtdLoadLogKey;

	// bi-directional many-to-one association to MsrDim
	private MsrDim msrDim;

	public ClnclMsrHrchyDim() {}

	public Long getClnclMsrHrchyDimKey() {
		return this.clnclMsrHrchyDimKey;
	}

	public void setClnclMsrHrchyDimKey(Long clnclMsrHrchyDimKey) {
		this.clnclMsrHrchyDimKey = clnclMsrHrchyDimKey;
	}

	public Long getCrtdLoadLogKey() {
		return this.crtdLoadLogKey;
	}

	public void setCrtdLoadLogKey(Long crtdLoadLogKey) {
		this.crtdLoadLogKey = crtdLoadLogKey;
	}

	public String getIntrvntnTypeNm() {
		return this.intrvntnTypeNm;
	}

	public void setIntrvntnTypeNm(String intrvntnTypeNm) {
		this.intrvntnTypeNm = intrvntnTypeNm;
	}

	public String getPrmryCndtnNm() {
		return this.prmryCndtnNm;
	}

	public void setPrmryCndtnNm(String prmryCndtnNm) {
		this.prmryCndtnNm = prmryCndtnNm;
	}

	public String getPrmryCndtnShrtNm() {
		return prmryCndtnShrtNm;
	}

	public void setPrmryCndtnShrtNm(String prmryCndtnShrtNm) {
		this.prmryCndtnShrtNm = prmryCndtnShrtNm;
	}

	public String getRcrdSttsCd() {
		return this.rcrdSttsCd;
	}

	public void setRcrdSttsCd(String rcrdSttsCd) {
		this.rcrdSttsCd = rcrdSttsCd;
	}

	public Timestamp getSorDtm() {
		return this.sorDtm;
	}

	public void setSorDtm(Timestamp sorDtm) {
		this.sorDtm = sorDtm;
	}

	public Long getUpdtdLoadLogKey() {
		return this.updtdLoadLogKey;
	}

	public void setUpdtdLoadLogKey(Long updtdLoadLogKey) {
		this.updtdLoadLogKey = updtdLoadLogKey;
	}

	public MsrDim getMsrDim() {
		return this.msrDim;
	}

	public void setMsrDim(MsrDim msrDim) {
		this.msrDim = msrDim;
	}

	public String getMsrSprsIndCd() {
		return msrSprsIndCd;
	}

	public void setMsrSprsIndCd(String msrSprsIndCd) {
		this.msrSprsIndCd = msrSprsIndCd;
	}

}
