package com.wellpoint.pc2dash.data.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.tooltip.GetPatientDetailRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.patient.CMDMPrograms;
import com.wellpoint.pc2dash.dto.patient.ProgramDetails;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;

public class CMDMFacts extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(CMDMFacts.class);

	/**
	 * This method will only be called for exports that filtered over CMDM Programs.
	 * We need to use the list of selected programs from the UI.
	 * 
	 * @param ids
	 * @return program names as a comma-separated list
	 * @throws Exception
	 */
	public String getCMDMProgramNamesForExportHeader(String ids) {
		String result = "";

		try {
			String sql = "select cd_val_nm from cd_dim where cd_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(ids)
				+ ") with ur ";

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			prepareStatement(logger, sql);

			int i = 0;
			if (StringUtil.isNotBlankOrFalse(ids)) {
				String[] array = ids.split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			executeQuery(logger, sql);

			while (rs.next()) {
				result += ", " + getString(rs, "cd_val_nm");
			}
			result = result.substring(2); // remove leading comma and space

		}
		catch (Exception e) {
			logger.info("Exception during getCMDMProgramNamesForExportHeader (" + ids + "). Returning empty string.", e);
			return "";
		}
		finally {

			close();
		}

		return result;
	}

	/**
	 * This method will only be called for exports that filtered over CMDM Statuses/Reasons.
	 * No need to go to the DB for this - parse the reason from the type-status-reason id.
	 * 
	 * @param ids (i.e. "CM-Closed-GOALS_MET,CM-Active-ENGAGED,DM-Closed-GOALS_MET,DM-Active-ENGAGED")
	 * @return reasons as a comma-separated list
	 */
	public String getCMDMStatusReasonsForExportHeader(String ids) {
		String delim = ",";
		String[] array = ids.split(delim);
		ArrayList<String> statuses = new ArrayList<String>();

		for (String id : array) {
			String[] reasonArray = StringUtil.parseUniqueStatusReasonId(id);
			String type = reasonArray[0];
			String status = reasonArray[1];
			String reason = StringUtil.capitalizeWords(reasonArray[2]);

			String element = "";
			if (listContains(statuses, type)) {
				if (listContains(statuses, type, status)) {
					element = " (" + reason + ")";
				}
				else {
					element = status + " (" + reason + ")";
				}
				if (reason.trim().contains("Not Triggered")) { // Do not show child for Not Triggered.
					element = status;
				}
			}
			else if (reason.trim().contains("Not Triggered")) { // Do not show child for Not Triggered.
				element = type + ": " + status;
			}
			else {
				element = type + ": " + status + " (" + reason + ")";
			}

			statuses.add(element);
		}

		String header = StringUtils.join(statuses, delim + " ");

		header = header.replace("),  (", ", "); // note the two space characters between the ), and (

		return header;
	}

	public boolean listContains(List<String> list, String type, String needle) {
		boolean containsType = false;
		for (String s : list) {
			if (s.contains(type)) { // once containsType has been set to true, do not revert to false
				containsType = true;
			}
			if (containsType && s.contains(needle + " ")) { // space character ensures comparison against the status and not the reason (Closed, for instance, can be both status and reason)
				return true;
			}
		}
		return false;
	}

	public boolean listContains(List<String> list, String needle) {
		for (String s : list) {
			if (s.contains(needle)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Remnants from the original query - pulled up here to clean up the current query a bit.
	 * Fields that aren't being selected:
	 * // .append("mcd.mstr_cnsmr_dim_key, ")
	 * // .append("mcd.last_nm, ")
	 * // .append("mcd.frst_nm, ")
	 * // .append("cdf.crmgt_dm_fact_key, ")
	 * // .append("cdf.hlth_pgm_creat_dt, ")
	 * // .append("cdf.hlth_pgm_end_dt, ")
	 * // .append("cdf.pgm_case_clsfctn_cd_dim_key, ")
	 * // .append("cdf.pgm_stts_rsn_cd_dim_key, ")
	 * // .append("cdf.hlth_pgm_stts_cd_dim_key ")
	 * Fields that aren't being used for sorting:
	 * // .append("cdf.pgm_case_type_cd asc, ")
	 * // .append("cd_status.cd_val_nm asc, ")
	 * // .append("cd_status_dm.cd_val_nm asc, ")
	 * 
	 * R1.5: Structure change to account for IHM Care Coordination: AP56, CP34, CO19, & SC92
	 * Another side effect of IHM user stories is that we're now selecting from psf and left joining to cdf.
	 */
	public Collection<CMDMPrograms> getCMDMPrograms(GetPatientDetailRequest request) throws Exception {

		Collection<CMDMPrograms> result = new ArrayList<CMDMPrograms>();

		StringBuilder sql = new StringBuilder()
			//			.append("select ")
			//				.append("coalesce(cd_name.cd_val_nm,'---') as program_name, ")
			//				.append("coalesce(cd_status.cd_val_nm, '---') as program_status, ")
			//				.append("coalesce(cd_reason.cd_val_nm, '---') as program_status_reason, ")
			//				.append("coalesce(cdf.pgm_case_type_cd, '---') as pgm_case_type_cd, ")
			//				.append("psf.ihm_ind_cd, ")
			//				.append("psf.ihm_pgm_nm ")
			//			.append("from ")
			//			.append("pat_smry_fact psf ")
			//				.append("left join crmgt_dm_fact cdf on (cdf.mstr_cnsmr_dim_key = psf.mstr_cnsmr_dim_key) ")
			//				.append("left join cd_dim cd_name on (cd_name.cd_dim_key = cdf.pgm_case_clsfctn_cd_dim_key) ")
			//				.append("left join cd_dim cd_status on (cd_status.cd_dim_key = cdf.hlth_pgm_stts_cd_dim_key) ")
			//				.append("left join cd_dim cd_reason on (cd_reason.cd_dim_key = cdf.pgm_stts_rsn_cd_dim_key) ")
			//				.append("join poit_user_scrty_acs pusa on ( ")
			//				.append("	psf.prov_grp_id = pusa.prov_grp_id ")
			//				.append("	and case ")
			//				.append("			when pusa.prov_org_tax_id = '0' then psf.prov_org_tax_id ")
			//				.append("			else pusa.prov_org_tax_id ")
			//				.append("		end = psf.prov_org_tax_id ")
			//				.append(") ")
			//			.append("where ")
			//				.append("pusa.sesn_id = ? ")
			//				.append("and pusa.enttlmnt_hash_key = ? ")
			//				.append("and psf.mstr_cnsmr_dim_key = ? ")
			//			.append("order by ")
			//				.append("cdf.hlth_pgm_end_dt desc ")
			//			.append("with ur ");

			/** PCMSP-2993, AF21144 */
			.append("select ")
			.append(" coalesce(pcg.PGM_NM,'---') as PROGRAM_NAME, ")
			.append(" coalesce(pcg.PGM_STTS_DESC,'---') as PROGRAM_STATUS, ")
			.append(" coalesce(pcg.PGM_STTS_RSN_DESC,'---') as PROGRAM_STATUS_REASON, ")
			.append(" coalesce(pcg.PGM_TYPE_CD,'---') as PGM_CASE_TYPE_CD, ")
			.append(" psf.ihm_ind_cd, ")
			.append(" psf.ihm_pgm_nm ")
			.append(" from ")
			.append(" PAT_SMRY_FACT psf ")
			.append(" left join PAT_CLNCL_PGM pcg on (pcg.PAT_ID = psf.mstr_cnsmr_dim_key) ")
			.append(" join poit_user_scrty_acs pusa on ( ")
			.append("	psf.prov_grp_id = pusa.prov_grp_id ")
			.append("	and case ")
			.append("			when pusa.prov_org_tax_id = '0' then psf.prov_org_tax_id ")
			.append("			else pusa.prov_org_tax_id ")
			.append("		end = psf.prov_org_tax_id ")
			.append(") ")
			.append("where ")
			.append("psf.atrbn_stts_cd = 'ACTIVE'")
			.append("and pusa.sesn_id = ? ")
			.append("and pusa.enttlmnt_hash_key = ? ")
			.append("and psf.mstr_cnsmr_dim_key = ? ")
			.append("with ur ");

		String sqlString = sql.toString();

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sqlString);

			ps.setString(1, request.getSessionId());
			ps.setString(2, request.getEntitlementId());
			ps.setString(3, request.getMemberKey());

			executeQuery(logger, sqlString);

			result = convertSelectedRowsToObjects();
		}
		catch (Exception e) {

			throw new Exception("Unable to get CMDM programs (" + request.toString() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}

	protected Collection<CMDMPrograms> convertSelectedRowsToObjects() throws SQLException {

		Collection<CMDMPrograms> list = new ArrayList<CMDMPrograms>();
		boolean cmExists = false;
		boolean dmExists = false;
		boolean ihmExists = false;
		String ihmEmployerName = "";

		while (rs.next()) {

			CMDMPrograms item = new CMDMPrograms();
			item.setTypeCode(rs.getString("pgm_case_type_cd").trim());

			List<ProgramDetails> details = new ArrayList<ProgramDetails>();

			ProgramDetails detail = new ProgramDetails();
			detail.setDetailType("Program");
			detail.setDetailValue(rs.getString("program_name"));
			details.add(detail);

			detail = new ProgramDetails();
			detail.setDetailType("Status");
			detail.setDetailValue(rs.getString("program_status"));
			details.add(detail);

			detail = new ProgramDetails();
			detail.setDetailType("Status Reason");
			detail.setDetailValue(rs.getString("program_status_reason"));
			details.add(detail);

			item.setDetails(details);

			// Before adding a CM, make sure there's not already a CM;
			// Same for DM. The business only wants one of each for now,
			// and it should be the one with the most recent end date.
			// The sort is handled in the query.
			if (item.getTypeCode().equalsIgnoreCase("CM") && !cmExists) {
				item.setProgramType("Case Management");
				list.add(item);
				cmExists = true;
			}
			else if (item.getTypeCode().equalsIgnoreCase("DM") && !dmExists) {
				item.setProgramType("Disease Management");
				list.add(item);
				dmExists = true;
			}

			if (rs.getString("ihm_ind_cd").equalsIgnoreCase("Y") && !ihmExists) {
				ihmExists = true;
				ihmEmployerName = rs.getString("ihm_pgm_nm");
			}
		}

		if (ihmExists) {
			CMDMPrograms item = new CMDMPrograms();

			List<ProgramDetails> details = new ArrayList<ProgramDetails>();

			ProgramDetails detail = new ProgramDetails();
			detail.setDetailType("Employer Name");
			detail.setDetailValue(ihmEmployerName);
			details.add(detail);

			item.setDetails(details);
			item.setProgramType("IHM Care Coordination");

			list.add(item);
		}

		return list;
	}

	@Override
	public boolean read(Dto o) throws Exception {

		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {


	}

	@Override
	public void update(Dto o) throws Exception {


	}

	@Override
	public void delete(Dto o) throws Exception {


	}

}
