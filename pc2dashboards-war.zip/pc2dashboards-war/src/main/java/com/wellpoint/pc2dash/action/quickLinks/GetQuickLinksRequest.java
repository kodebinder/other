package com.wellpoint.pc2dash.action.quickLinks;

import com.wellpoint.pc2dash.data.dto.PCMSRequest;

public class GetQuickLinksRequest extends PCMSRequest {

	protected String cpcEntitlementId;
	protected String requestUrl;

	public String getCpcEntitlementId() {
		return cpcEntitlementId;
	}

	public void setCpcEntitlementId(String cpcEntitlementId) {
		this.cpcEntitlementId = cpcEntitlementId;
	}

	public String getRequestUrl() {
		return requestUrl;
	}

	public void setRequestUrl(String requestUrl) {
		this.requestUrl = requestUrl;
	}

}
