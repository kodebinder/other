package com.wellpoint.pc2dash.action.costOpportunity;

import com.wellpoint.pc2dash.data.dto.PopulationManagementRequest;

public class GetSpecialityRxSocDrugDetailsRequest extends PopulationManagementRequest{

	private boolean hasDetailsDrilldownInd = false;

	public boolean isHasDetailsDrilldownInd() {
		return hasDetailsDrilldownInd;
	}

	public void setHasDetailsDrilldownInd(boolean hasDetailsDrilldownInd) {
		this.hasDetailsDrilldownInd = hasDetailsDrilldownInd;
	}
	
	
}
