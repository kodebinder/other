package com.wellpoint.pc2dash.data.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.quality.GetQualityProvidersRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.careOpportunities.Provider;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QueryConstants;
import com.wellpoint.pc2dash.util.StringUtil;

public class MedicaidQualityProviders extends GeneralProviders {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(MedicaidQualityProviders.class);

	public List<Provider> getMedicaidQualityProviders(GetQualityProvidersRequest request) throws Exception {
		setExport(StringUtil.isExport(request));
		setRowCount(0);

		List<Provider> result = new ArrayList<Provider>();
		String sql = buildSql(request);

		try {
			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			buildPreparedStatement(request, sql);
			executeQuery(logger, sql);
			result = convertSelectedRowsToObjects(rs, request);

		}
		catch (Exception e) {
			throw new Exception("Exception during getMedicaidQualityProviders (" + request.toString() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}

	protected String buildSql(GetQualityProvidersRequest request) {
		StringBuilder sql = new StringBuilder()
			.append("select a.* ")
			.append("from ( ")
			.append("select row_number() over (order by %s) as rank, ")
			.append(buildSharedSelectGroupByColumns(request))
			.append(", coalesce(nullif(upper(ip.ip_last_nm), 'UNK'), '*') as ip_last_nm ")
			.append(", coalesce(nullif(upper(ip.ip_frst_nm), 'UNK'), '*') as ip_frst_nm ")
			// the columns below aren't used in the group by clause, so they've been excluded from buildSharedSelectGroupByColumns()
			.append(", sum(cisf.msr_nmrtr_nbr) as cmplnt_cnt ")
			.append(", sum(cisf.msr_dnmntr_nbr - cisf.msr_nmrtr_nbr) as non_cmplnt_cnt ")
			.append(", sum(cisf.msr_dnmntr_nbr) as ttl_qlty_msrs ")
			.append(", count(*) over () as row_cnt "); // total rows, without a separate query

		// add to from and where clauses as necessary (adding some by default, since they're very likely to be required)

		StringBuilder from = new StringBuilder("from cmplnc_ip_smry_fact cisf ");
		from.append("join msr_dim md on (cisf.msr_dim_key = md.msr_dim_key) ");
		from.append("join scrcrd_msr_hrchy_dim smhd on (cisf.scrcrd_msr_hrchy_dim_key = smhd.scrcrd_msr_hrchy_dim_key) ");
		from.append("join prov_org_dim pod on (cisf.prov_org_dim_key = pod.prov_org_dim_key) ");
		from.append("join prov_grp_dim pgd on (cisf.prov_grp_dim_key = pgd.prov_grp_dim_key) "); // moved here when the POIT clause was added
		from.append("join ip_dim ip on (cisf.ip_dim_key = ip.ip_dim_key) ");
		from.append("join prov_grp_hrchy_dim pghd on (cisf.prov_grp_dim_key = pghd.prov_grp_dim_key ");
		from.append("and cisf.prov_org_dim_key = pghd.prov_org_dim_key ");
		from.append("and cisf.ip_dim_key = pghd.ip_dim_key ) ");
		//from.append("and pghd.prov_grp_hrchy_trmntn_dt>=current_date) ");

		StringBuilder where = new StringBuilder("where ");

		// POIT clause
		//if (doPoitTableJoin(request.getGrpInd())) {
		from.append(getPoitTableJoin());

		where.append(getPoitTableWhere());
		//	}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) { // populated if the Organization filter is applied

			where.append("and pghd.ip_dim_key in (" // NF31 (no longer psf.prov_grp_hrchy_dim_key)
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys())
				+ ") "); // provDimKeys
		}
		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			where.append(" and pod.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}

		if (!StringUtils.isBlank(request.getProgramId())) {
			from.append("join pgm_dim pd on (cisf.pgm_dim_key = pd.pgm_dim_key) ");

			where.append("and pd.pgm_id = ? "); // programId
		}

		if (!StringUtils.isBlank(request.getCompositeId())) {

			where.append("and smhd.cmpst_defn_id = ? "); // CompositeId
		}

		if (StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys())) {

			where.append("and md.msr_id in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getQualityMeasureKeys())
				+ ") "); // qualityMeasureKeys (not smhd.msr_dim_key)
		}

		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {

			where.append("and cisf.msrmnt_prd_strt_dt = ? "); // measurementPeriodStartDt
			where.append("and cisf.ANLYSS_AS_OF_DT = ? ");
		}

		if (!StringUtils.isBlank(request.getProvGrpIds())) {

			where.append("and pgd.prov_grp_id = ? ");
		}

		/*if (!StringUtil.isBlank(request.getLobDimKeys())) {
			from.append("join prov_grp_pgm_lob_fact as pgplf on (pd.pgm_dim_key = pgplf.pgm_dim_key ")
					.append("	and pgd.prov_grp_dim_key = pgplf.prov_grp_dim_key ")
					.append(" and pgplf.prov_grp_pgm_lob_efctv_dt <= current_date ")
					//.append(" and pgplf.prov_grp_pgm_lob_trmntn_dt >= current_date) ");
		    from.append("left join lob_dim as ld on (pgplf.lob_dim_key = ld.lob_dim_key) ");
		    
		    where.append("and (ld.lob_dim_key in (" 
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getLobDimKeys()) 
					+ ") or (ld.lob_dim_key is null)) ");
		}*/
		
		/** AF21144 | PCMSP-473 export change start*/
		if(isExport()){
			where.append(" and CISF.IP_DIM_KEY in (")
			.append(" select cisf2.IP_DIM_KEY ")
			.append(" from CMPLNC_IP_SMRY_FACT cisf2 ")
			.append(" join msr_dim md2 on md2.msr_dim_key = cisf2.msr_dim_key ")
			.append(" where md2.msr_id in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getQualityMeasureKeys())
				+ ") ")
			.append(" and cisf2.msrmnt_prd_strt_dt = ? ")
			.append(" and cisf2.anlyss_as_of_dt = ? ")
			.append(" group by cisf2.IP_DIM_KEY  ")
			.append(QueryConstants.qualityMeasureToggleQuery(request, "cisf2"))
			.append(")");
		}
		/** end*/

		where = StringUtil.removeFirstOccurenceWithinString(where, "and");

		sql.append(from).append(where);

		sql
			.append("group by ")
			.append(StringUtil.stripAsAndUpperFromClause(buildSharedSelectGroupByColumns(request)))
			.append(", upper(ip.ip_last_nm) ")
			.append(", upper(ip.ip_frst_nm) ");

		/** AF21144 | PCMSP-473 */
		if(!isExport())
			sql.append(QueryConstants.qualityMeasureToggleQuery(request, "cisf"));

		sql.append(") a ");

		// format the sql string differently depending on whether we're displaying or exporting the grid
		boolean limited = isLimited(request);
		ArrayList<Object> paramList = new ArrayList<Object>();

		paramList.add(getSortClause(request));

		if (limited && !isExport()) {
			sql.append("where rank between %d and %d "); // start limit (placeholders must be used only for column values)
			paramList.add(Integer.parseInt(request.getStart()) + 1);
			paramList.add(Integer.parseInt(request.getStart()) + Integer.parseInt(request.getLimit()));
		}

		sql.append("with ur");

		String sqlString = String.format(sql.toString(), paramList.toArray());

		return sqlString;
	}

	protected void buildPreparedStatement(GetQualityProvidersRequest request, String sql) throws SQLException {
		int i = 0;
		prepareStatement(logger, sql);

		// same order of null checks as buildSql() to make sure markers are populated correctly
		//if (doPoitTableJoin(request.getGrpInd())) {			
		ps.setString(++i, request.getSessionId());

		ps.setString(++i, request.getEntitlementId());
		//	}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) { // populated if the Organization filter is applied
			String[] array = request.getProvDimKeys().split(",");
			String loggedProvDimKeys = "";
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
				loggedProvDimKeys += "," + StringUtil.parseProviderId(item);
			}
			StringUtils.replaceOnce(loggedProvDimKeys, ",", "");
		}
		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (!StringUtils.isBlank(request.getProgramId())) {
			ps.setString(++i, request.getProgramId());
		}

		if (!StringUtils.isBlank(request.getCompositeId())) {
			ps.setString(++i, request.getCompositeId());
		}

		if (StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys())) {
			String[] array = request.getQualityMeasureKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
			ps.setString(++i, request.getMeasurementPeriodStartDt());

			//adding analysis as of date to be in sync with utilization patients -- Varun
			CommonQueries cq = new CommonQueries();
			//String aaod = cq.selectAAODOther(request.getProgramId(), request.getMeasurementPeriodStartDt());
			String aaod = cq.selectAAODOther(request.getProgramId(), request.getMeasurementPeriodStartDt(), request.getProvGrpIds()); //PCMSP-13914
			ps.setString(++i, aaod);
		}

		if (!StringUtils.isBlank(request.getProvGrpIds())) {
			ps.setString(++i, request.getProvGrpIds());
		}

		/*if (!StringUtil.isBlank(request.getLobDimKeys())) {
			String[] array = request.getLobDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}*/

		/** AF21144 | PCMSP-473 start */
		if(isExport()){
			if (StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys())) {
				String[] array = request.getQualityMeasureKeys().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}
			if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
				ps.setString(++i, request.getMeasurementPeriodStartDt());

				//adding analysis as of date to be in sync with utilization patients -- Varun
				CommonQueries cq = new CommonQueries();
				//String aaod = cq.selectAAODOther(request.getProgramId(), request.getMeasurementPeriodStartDt());
				String aaod = cq.selectAAODOther(request.getProgramId(), request.getMeasurementPeriodStartDt(), request.getProvGrpIds()); //PCMSP-13914
				ps.setString(++i, aaod);
			}
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys()) && Constants.AND_OPERATOR.equalsIgnoreCase(request.getQualityMeasureKeysToggle())) {
			int msr_count = request.getQualityMeasureKeys().split(",").length;
			if (msr_count > 1)
				ps.setInt(++i, msr_count);
			else
				ps.setInt(++i, 0);
		}
		else
			ps.setInt(++i, 0);
		/** end */

	}

}
