package com.wellpoint.pc2dash.action.costOpportunity;

import com.wellpoint.pc2dash.data.dto.PopulationManagementRequest;

public class GetAverageCostPerRxDetailTotalRequest extends PopulationManagementRequest {
	
	private String drugClassKeys;

    public String getDrugClassKeys() {
        return drugClassKeys;
    }

    public void setDrugClassKeys(String drugClassKeys) {
        this.drugClassKeys = drugClassKeys;
    }
}
