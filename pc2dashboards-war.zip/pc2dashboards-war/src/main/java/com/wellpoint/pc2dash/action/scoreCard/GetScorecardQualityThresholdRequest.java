package com.wellpoint.pc2dash.action.scoreCard;

import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;

//import com.wellpoint.pc2dash.dto.scorecard.QualityIndicatorsFromRequest;

/**
 * @author AD34782
 *
 */
public class GetScorecardQualityThresholdRequest extends PerformanceManagementRequest {

	private String mdcdQltyScorEfctvDt;
	private String mdcdQltyScorTrmntnDt;

	//	private String page;
	//	private QualityIndicatorsFromRequest qualityGateRequest;

	public String getMdcdQltyScorEfctvDt() {
		return mdcdQltyScorEfctvDt;
	}

	public String getMdcdQltyScorTrmntnDt() {
		return mdcdQltyScorTrmntnDt;
	}

	//	public String getPage() {
	//		return page;
	//	}
	//	public QualityIndicatorsFromRequest getQualityGate() {
	//		return qualityGateRequest;
	//	}
	public void setMdcdQltyScorEfctvDt(String mdcdQltyScorEfctvDt) {
		this.mdcdQltyScorEfctvDt = mdcdQltyScorEfctvDt;
	}

	public void setMdcdQltyScorTrmntnDt(String mdcdQltyScorTrmntnDt) {
		this.mdcdQltyScorTrmntnDt = mdcdQltyScorTrmntnDt;
	}
	//	public void setPage(String page) {
	//		this.page = page;
	//	}
	//	public void setQualityGate(QualityIndicatorsFromRequest qualityGateRequest) {
	//		this.qualityGate = qualityGateRequest;
	//	}

}
