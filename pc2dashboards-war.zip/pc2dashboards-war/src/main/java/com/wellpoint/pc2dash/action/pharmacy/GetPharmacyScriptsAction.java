package com.wellpoint.pc2dash.action.pharmacy;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.data.dao.PharmacyScriptsGridDao;
import com.wellpoint.pc2dash.data.dto.AuditEntry;
import com.wellpoint.pc2dash.dto.pharmacy.PharmacyScriptsGrid;
import com.wellpoint.pc2dash.dto.suppression.Column;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportGridColumn;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.population.PharmacyScriptsExport;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;


public class GetPharmacyScriptsAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetPharmacyScriptsRequest request = (GetPharmacyScriptsRequest) actionRequest;
		GetPharmacyScriptsResponse response = new GetPharmacyScriptsResponse();
		ErrorProperties err = ErrorProperties.getInstance();

		List<PharmacyScriptsGrid> resultList = new ArrayList<PharmacyScriptsGrid>();
		PharmacyScriptsGridDao dao = new PharmacyScriptsGridDao();
		List<String> grps = null;

		try {

			removeLobPgmPrefixes(request);

			/**
			 * R1.92 | Checking whether attested
			 * 
			 * @author AC94408
			 */
			Boolean isattest = isAttested(request);

			if (StringUtils.isNotBlank(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			if (null != grps && !grps.isEmpty()) {
				request.setProvGrpIdsWithoutClinicalCheck(StringUtils.join(grps, ','));
				grps = filterProvGrpsByClinicalInd(request, grps);
				request.setProvGrpIds(StringUtils.join(grps, ','));
			}

			if (StringUtil.isExportDest(request.getDest())) {

				List<ExportGridColumn> columns = dao.buildExportGridColumns(request);
				PharmacyScriptsExport exp = new PharmacyScriptsExport(request, columns);

				ExportProcessor.getInstance().submit(exp);

				response.setSuccess(true); // 250491
			}
			else { // UI request

				if (null != grps && !grps.isEmpty() && isattest) {

					resultList = dao.getScriptsGridDetails(request);
					CommonQueries cq = new CommonQueries();

					MetaData metaData = buildMetaData(request, dao);
					metaData.setReportingPeriod(cq.getReportingPeriodForPharmacy());

					Column aaPhSc = new Column();
					aaPhSc.setColumnId(Constants.PHRMCY_ALWD_AMT_COLUMN); // "pm-ph-scriptgridpanel-allowedAmount"
					aaPhSc.setHidden(false);
					aaPhSc.setHideable(true);

					metaData.getColumns().add(aaPhSc);

					if (null == resultList || resultList.isEmpty()) {

						response.setMessage(err.getProperty("successNoData"));
					}
					else {

						response.setMetaData(metaData);
						response.setMessage(err.getProperty("successful"));
						response.setData(resultList);
						response.setTotal(dao.getRowCount());
					}
					response.setSuccess(true);
				}
				else if (grps.isEmpty() && isattest) {
					response.setSuccess(true);
				}
				else {
					response.setSuccess(false);
				}
			}

			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}

	/**
	 * R1.92 | Checking whether attested
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 * @author AC94408
	 */
	private boolean isAttested(GetPharmacyScriptsRequest request) throws Exception {

		AuditEntry dto = new AuditEntry();
		dto.setUserId(request.getUserId());
		dto.setSessionId(request.getSessionId());
		dto.setPatientId("-1");
		dto.setAccessType(Constants.PHARMACY_SCRIPTS);

		return dto.read();
	}
}
