package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.action.tooltip.GetPatientDetailRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.utilization.GdrDrugDetails;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;

public class GDRDrugDetailsFacts extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GDRDrugDetailsFacts.class);

	public Collection<GdrDrugDetails> getGDRDrugDetails(GetPatientDetailRequest request) throws Exception {

		Collection<GdrDrugDetails> result = new ArrayList<GdrDrugDetails>();

		/**
		 * AD12140 - R1.8
		 * Changing the Table from prov_grp_hrchy_dim to ip_dim to pick NPI_TYPE_CD
		 * Removed the left join for prov_grp_hrchy_dim
		 */

		StringBuilder sql = new StringBuilder()
			.append(" select distinct ")
			.append(" pcf.CLM_ADJSTMNT_Key, pcf.RX_FILLED_DT,pcf.LBL_NM,udf.CNDTN_CTGRY_NM,pcf.DAYS_SPLY_NBR, ")
			.append(" pcf.PRSCRBR_IP_DIM_KEY,pcf.APRVD_CPAY_AMT,pcf.DSPNSD_BRND_GNRC_IND,ip.ip_frst_nm,ip.ip_last_nm, ip.NPI_TYPE_CD ")
			.append(" from CMPLNC_UM_DTL_FACT udf ")
			.append(" JOIN CLM_PHRMCY_UM_XREF xref ON xref.CMPLNC_UM_DTL_FACT_KEY = udf.CMPLNC_UM_DTL_FACT_KEY and udf.MSTR_CNSMR_DIM_KEY = xref.MSTR_CNSMR_DIM_KEY ")
			.append(" JOIN PHRMCY_CLM_FACT PCF ON (PCF.PHRMCY_CLM_FACT_KEY = xref.PHRMCY_CLM_FACT_KEY) ")
			.append(" JOIN MSR_DIM MD ON (MD.MSR_DIM_KEY = udf.MSR_DIM_KEY) ")
			.append(" left join IP_DIM AS IP ON (IP.IP_DIM_KEY = PCF.PRSCRBR_IP_DIM_KEY) ")
			//changes done to use current date instead of max(sor_dtm)
			/*.append("	join ( ")
			.append("		select ")
			.append("			cast(max(sor_dtm) - 15 months - (day(max(sor_dtm)) - 1) days as date) as strt_dt, ")
			.append("			cast(max(sor_dtm) as date) as end_dt ")
			.append("		from ")
			.append("			glbl_fltr_smry_fact ")
			.append("	) dt on ( ")
			.append("		1=1 ")
			.append("	) ")*/
			.append(" where ")
			.append(" udf.MSTR_CNSMR_DIM_KEY = ? ")
			.append("	and udf.clm_line_srvc_strt_dt >= (current_date - day(current_date) day +1 day) - 15 MONTHS ");
		/*.append("		dt.strt_dt and ")
		.append("		dt.end_dt ");*/
		//As per Tiffany's email these records should not be filtered based on any criteria
		/*
		 * WLPRD02145939 - The following if clause for the phrmcyMsrIds will be added only for the single measure drilldown scenario
		 * The aggregate level drill down scenario has to display the information for all drug class/measures
		 */
		if (null != request.getMeasureName() && request.getMeasureName().equalsIgnoreCase(Constants.GDR)) {
			if (StringUtil.isNotBlankOrFalse(request.getPhrmcyMsrIds())) {
				sql.append(" and md.msr_id in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getPhrmcyMsrIds())
					+ ") ");
			}
		}

		//Vignesh- Changes to resolve duplicate records in the GDR drug details pop-up		
		if (null != request && null != request.getMeasurementPeriodStartDt()) {
			sql.append(" and udf.msrmnt_prd_strt_dt = ? ");
		}

		/*
		if(StringUtil.isNotBlankOrFalse(request.getPhrmcyFullNms())){
			sql.append( " and trim(PCF.BRND_NM) in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getPhrmcyFullNms())
					+ ") ");
		}*/
		sql.append(" order by ")
			.append(" pcf.RX_FILLED_DT desc ");



		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, sql.toString());
			ps.setString(++i, request.getMemberKey());

			if (null != request.getMeasureName() && request.getMeasureName().equalsIgnoreCase(Constants.GDR)) {
				if (StringUtil.isNotBlankOrFalse(request.getPhrmcyMsrIds())) {
					String[] array = request.getPhrmcyMsrIds().split(",");
					for (String item : array) {
						ps.setString(++i, item.trim());
					}
				}
			}

			//Vignesh- Changes to resolve duplicate records in the GDR drug details pop-up		
			if (null != request && null != request.getMeasurementPeriodStartDt()) {
				ps.setString(++i, request.getMeasurementPeriodStartDt());
			}
			/*
			if (StringUtil.isNotBlankOrFalse(request.getPhrmcyFullNms())) {
				String[] array = request.getPhrmcyFullNms().split(",");
				for (String item : array) {
					ps.setString(++i, item.trim());
				}
			}*/

			executeQuery(logger, sql.toString());

			while (rs.next()) {

				GdrDrugDetails r = new GdrDrugDetails();
				if (rs.getDate("RX_FILLED_DT") != null) {
					r.setFillDate(getDate(rs, "RX_FILLED_DT"));
				}
				if (rs.getString("LBL_NM") != null) {
					r.setDrugName(getString(rs, "LBL_NM"));
				}
				if (rs.getString("CNDTN_CTGRY_NM") != null) {
					r.setDrugClass(getString(rs, "CNDTN_CTGRY_NM"));
				}
				if (rs.getBigDecimal("DAYS_SPLY_NBR") != null) {
					Integer ds = rs.getBigDecimal("DAYS_SPLY_NBR").intValue();
					r.setDaysSupply(ds.toString());
				}
				String firstName = getString(rs, "ip_frst_nm");
				String lastName = getString(rs, "ip_last_nm");
				String npiTypeCd = getString(rs, "NPI_TYPE_CD") != null ? rs.getString("NPI_TYPE_CD") : "1";
				if (firstName == null) {
					firstName = "*";
				}
				if (lastName == null) {
					lastName = "*";
				}
				
				//PCMSP-13760
				//r.setProviderName(StringUtil.buildProviderName(lastName, firstName, npiTypeCd));
				
				if (!Constants.STAR.equalsIgnoreCase(lastName) && !Constants.STAR.equalsIgnoreCase(firstName)) {
					r.setProviderName(lastName + ", " + firstName);
				}
				else if (!Constants.STAR.equalsIgnoreCase(lastName)) {
					r.setProviderName(lastName);
				}
				else {
					r.setProviderName(Constants.UNK);
				}
				//PCMSP-13760 - ends
				
				if (rs.getBigDecimal("APRVD_CPAY_AMT") != null) {
					r.setPatientCost("$" + rs.getBigDecimal("APRVD_CPAY_AMT").toString());
				}
				if (rs.getString("DSPNSD_BRND_GNRC_IND") != null) {
					r.setGenericInd(rs.getString("DSPNSD_BRND_GNRC_IND").trim().equalsIgnoreCase("G") ? 1 : 0);
				}

				result.add(r);
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get GDRDrugDetails (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}

	@Override
	public boolean read(Dto o) throws Exception {

		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {


	}

	@Override
	public void update(Dto o) throws Exception {


	}

	@Override
	public void delete(Dto o) throws Exception {


	}

}
