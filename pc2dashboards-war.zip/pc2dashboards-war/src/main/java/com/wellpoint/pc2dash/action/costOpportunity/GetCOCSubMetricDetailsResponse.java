package com.wellpoint.pc2dash.action.costOpportunity;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetCOCSubMetricDetailsResponse extends ActionResponse {
	
	private Boolean totalRow = Boolean.FALSE;

	public Boolean getTotalRow() {
		return totalRow;
	}

	public void setTotalRow(Boolean totalRow) {
		this.totalRow = totalRow;
	}

}
