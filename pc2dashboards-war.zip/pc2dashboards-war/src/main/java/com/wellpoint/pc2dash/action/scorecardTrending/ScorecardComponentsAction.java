package com.wellpoint.pc2dash.action.scorecardTrending;

import java.util.Collection;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.scorecardTrending.ScorecardTrendingFiltersServiceImpl;
import com.wellpoint.pc2dash.util.ErrorProperties;


/**
 * Class to handle the request to populate the Scorecard Components based
 * selection made for Metric, Level, Type in Scorecard Trending Reports Tab
 * 
 * @author ad91912
 */
public class ScorecardComponentsAction extends Action {
	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(ScorecardTrendingFilterAction.class);

	@SuppressWarnings({"unchecked"})
	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		ScorecardTrendingFiltersServiceImpl stFilterService = new ScorecardTrendingFiltersServiceImpl();
		ScorecardComponentsRequest request = (ScorecardComponentsRequest) actionRequest;
		ActionResponse result = new ScorecardTrendingFilterResponse();
		ErrorProperties err = ErrorProperties.getInstance();
		Collection<Object> vals = null;
		try {
			//			Map<String, String> dataMap = new HashMap<String,String>();
			//			dataMap.put("programId", reqObj.getProgramId());
			//			dataMap.put("measurementPeriodStartDt", reqObj.getMeasurementPeriodStartDt());
			//			dataMap.put("providerGroupId", reqObj.getProviderGroupId());
			//			dataMap.put("lob", reqObj.getLob());
			//			dataMap.put("programLobTypeCd", reqObj.getProgramLobTypeCd());
			//			dataMap.put("metric", reqObj.getMetric());
			//			dataMap.put("level", reqObj.getLevel());
			//			dataMap.put("type", reqObj.getType());
			//			dataMap.put("sessionId", reqObj.getSessionId());
			//			dataMap.put("entitlementId", reqObj.getEntitlementId());
			vals = stFilterService.getData(request);
			if (null == vals || (null != vals && vals.isEmpty())) {
				result.setMessage(err.getProperty("successNoData"));
				result.setData(vals);
				result.setTotal(0);
			}
			else {
				result.setMessage(err.getProperty("successful"));
				result.setData(vals);
				result.setTotal(vals.size());
			}

			result.setSuccess(true);
		}
		catch (Exception e) {
			logger.error("Unable to retrieve Scorecard composite  detail.", e);

			result.setMessage("Unable to retrieve Scorecard composite  detail.");
			result.setSuccess(false);
		}
		return result;
	}
}
