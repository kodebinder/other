package com.wellpoint.pc2dash.action.utilization;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.action.quality.GetQualityAction;
import com.wellpoint.pc2dash.action.quality.GetQualityResponse;
import com.wellpoint.pc2dash.data.dao.UtilizationBrandFormularyPatients;
import com.wellpoint.pc2dash.data.dao.UtilizationGDRPatients;
import com.wellpoint.pc2dash.data.dao.UtilizationPatients;
import com.wellpoint.pc2dash.dto.patient.Patient;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportGridColumn;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.scorecard.DrillDownChartExport;
import com.wellpoint.pc2dash.export.scorecard.commercial.UtilizationPatientExport;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;


public class GetUtilizationPatientsAction extends GetQualityAction {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetUtilizationPatientsRequest request = (GetUtilizationPatientsRequest) actionRequest;
		GetQualityResponse response = new GetQualityResponse();
		List<String> grps = new ArrayList<String>();
		List<Patient> resultList = new ArrayList<Patient>();

		try {

			request = (GetUtilizationPatientsRequest) cleanRequest(request);
			UtilizationPatients dao = new UtilizationPatients();
			UtilizationGDRPatients daoGDR = new UtilizationGDRPatients();
			//PCMSP-8461 STARTS 1
			UtilizationBrandFormularyPatients daoBrandFormulary = new UtilizationBrandFormularyPatients();
			//PCMSP-8461 ENDS 1
			if (StringUtils.isNotBlank(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			if (null != grps && grps.size() > 0) {
				grps = filterProvGrpsByClinicalInd(request, grps);
			}

			/*
			 * Determine whether Action Center is suppressed - it'll play a part in deciding whether to display
			 * the "i" icon in all of the Clinical Programs columns in Population Management and
			 * Performance Management drill-downs.
			 */
			CommonQueries cq = new CommonQueries();
			request.setGroupsWithActionCenterSuppressed(cq.getGroupsWithComponentSuppressed(request, Constants.AC_RF_CARDCONTAINER));
			List<ExportGridColumn> columns = new ArrayList<ExportGridColumn>();
			List<String> columnNames = new ArrayList<String>();
			if (StringUtil.isExport(request)) {
				columns = dao.buildExportGridColumns(request);;
				columnNames = buildColumnNameList(columns);
			}

			/**
			 * Updating the logic based on the defect WLPRD02524865 and as per the suggestion from Vishal J. to drive scorecard based on
			 * PGM_LOB_TYPE_CD and not on lob
			 */
			String pgmLobTypeCode = request.getProgramLobTypeCd() == null ? null : request.getProgramLobTypeCd().toUpperCase();

			// RA Action Menu Suppression
			prepareRASuppressionCond(request);

			// R1.9|LPR Suppression 61461|AD91912
			prepareLPRSuppressionCond(request);

			if (null != grps && !grps.isEmpty()) {

				request.setProvGrpIds(StringUtils.join(grps, ','));
				request.setGrpInd(Constants.GRP_IND_N);

				if (StringUtil.isJson(request)) {

					/**
					 * Updating the logic based on the defect WLPRD02524865 and as per the suggestion from Vishal J. to drive scorecard based on
					 * PGM_LOB_TYPE_CD and not on lob
					 */
					if (StringUtils.isNotBlank(pgmLobTypeCode)
						&& pgmLobTypeCode.contains(Constants.COMMERCIAL.toUpperCase())
						&& request.getMeasureName().contains(Constants.GDR)) {
						resultList.addAll(daoGDR.getUtilizationGDRPatients(request, columnNames));
						response.setTotal(daoGDR.getRowCount()); // calculates total without another query
					}
					//PCMSP-8461 STARTS 2
					else if (StringUtils.isNotBlank(pgmLobTypeCode)
						&& pgmLobTypeCode.contains(Constants.COMMERCIAL.toUpperCase())
						&& request.getMeasureName().contains(Constants.FRMLY)) {
						resultList.addAll(daoBrandFormulary.getUtilizationBrandFormularyPatients(request, columnNames));
						response.setTotal(daoBrandFormulary.getRowCount()); // calculates total without another query
					}
					//PCMSP-8461 ENDS 2
					else {
						resultList.addAll(dao.getUtilizationPatients(request, columnNames));
						response.setTotal(dao.getRowCount()); // calculates total without another query	
					}

					MetaData metaData = buildMetaData(request, daoGDR);
					response.setMetaData(metaData);

					response.setMessage(StringUtil.buildMessage(resultList.isEmpty()));
					response.setData(resultList);
				}
				else {
					if (StringUtil.isChartExport(request.getChartImageData())) {
						DrillDownChartExport exp = new DrillDownChartExport(request, Constants.PATIENT);
						ExportProcessor.getInstance().submit(exp);
					}
					else {
						UtilizationPatientExport exp = new UtilizationPatientExport(request, columns);
						ExportProcessor.getInstance().submit(exp);
					}
				}
			}

			response.setSuccess(true);
		}
		catch (Exception e) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(e, response);
		}

		return response;
	}
}
