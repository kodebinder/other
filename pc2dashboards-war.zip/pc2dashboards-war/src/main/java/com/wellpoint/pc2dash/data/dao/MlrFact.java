package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.action.tooltip.GetMLRRangesRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.performance.medicalLossRatio.MlrRanges;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;

public class MlrFact extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(MlrFact.class);

	public boolean read(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void insert(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void update(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void delete(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public Collection<MlrRanges> getMLRRanges(GetMLRRangesRequest request) throws Exception {
		ArrayList<MlrRanges> result = new ArrayList<MlrRanges>();
		StringBuilder query = new StringBuilder()
			.append(" SELECT PTNTL_TYPE_MIN_PCT , ")
			.append(" PTNTL_TYPE_MAX_PCT , PTNTL_TYPE_PTNTL_PCT ")
			.append(" FROM ")
			.append(" MLR_FACT AS M JOIN PSL_DIM AS P ON (M.PSL_DIM_KEY = P.PSL_DIM_KEY ")
			.append(" AND P.PSL_GRP_NM IN ( '").append(Constants.HMO + "' , '" + Constants.PPO).append("') ) ")
			.append(" JOIN LOB_DIM AS L ON (M.LOB_DIM_KEY = L.LOB_DIM_KEY) JOIN PGM_DIM AS PGM ON (M.PGM_DIM_KEY = PGM.PGM_DIM_KEY) ")
			.append(" WHERE L.LOB_DESC = ? AND PGM.PGM_ID = ? AND M.PROV_GRP_DIM_KEY = ? ")
			.append(" AND M.MSRMNT_PRD_STRT_DT = ? AND M.MSRMNT_PRD_END_DT = ? and m.intrvl_mnth_cnt = ? ")
			.append(" GROUP BY PTNTL_TYPE_MIN_PCT ,PTNTL_TYPE_MAX_PCT , PTNTL_TYPE_PTNTL_PCT ");
		try {
			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			prepareStatement(logger, query.toString());
			int i = 0;
			ps.setString(++i, request.getLob());
			ps.setString(++i, request.getProgramId());
			ps.setLong(++i, Long.parseLong(request.getProviderGroupDimKey()));
			ps.setString(++i, StringUtil.convertDate(request.getMeasurementPeriodStartDt()));
			ps.setString(++i, StringUtil.convertDate(request.getMeasurementPeriodEndDt()));
			ps.setString(++i, request.getMeasurementInterval());
			executeQuery(logger, query.toString());
			while (rs.next()) {
				MlrRanges mlRa = new MlrRanges();
				mlRa.setMlrMin(rs.getString("PTNTL_TYPE_MIN_PCT"));
				mlRa.setMlrMax(rs.getString("PTNTL_TYPE_MAX_PCT"));
				mlRa.setPotential(rs.getString("PTNTL_TYPE_PTNTL_PCT"));
				result.add(mlRa);
			}
		}
		catch (Exception e) {
			throw new Exception("Unable to get MlrRanges", e);
		}
		finally {
			close();
		}
		return result;
	}
}
