package com.wellpoint.pc2dash.action.patients;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.patient.CareOpportunitiesFilterJson;
import com.wellpoint.pc2dash.dto.tinNpi.UserAcsIndicators;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.service.patient.PatientCareOpportunitiesServiceImpl;
import com.wellpoint.pc2dash.util.ErrorProperties;

public class GetPatientCareOpportunitiesAction extends Action {

	List<CareOpportunitiesFilterJson> resultList;
	ErrorProperties err = ErrorProperties.getInstance();
	List<String> filteredProvGrpList = new ArrayList<String>();

	ActionResponse response = new GetPatientCareOpportunitiesResponse();

	@SuppressWarnings("unchecked")
	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		GetPatientCareOpportunitiesRequest request = (GetPatientCareOpportunitiesRequest) actionRequest;
		PatientCareOpportunitiesServiceImpl pC2Service = new PatientCareOpportunitiesServiceImpl();
		try {
			//PCMSRequest request = getDataMap(request);
			//Clinical access check on provider groups
			//			filteredProvGrpList = JSONUtils.getProviderListFromJsonString(request.get(Constants.USER_ACS_INFO_JSON));
			for (UserAcsIndicators u : request.getUserAcsInfoJson()) {
				filteredProvGrpList.add(u.getProvGrpId());
			}
			if (null != request && !filteredProvGrpList.isEmpty()) {
				filteredProvGrpList = filterProvGrpsByClinicalInd(request, filteredProvGrpList);
			}

			if (null != filteredProvGrpList && !filteredProvGrpList.isEmpty()) {
				request.setFilteredProvGrpIds(StringUtils.join(filteredProvGrpList, ','));
				resultList = pC2Service.getData(request);
			}

			if (null != resultList && !resultList.isEmpty()) {
				ArrayList<CareOpportunitiesFilterJson> careOppList = (ArrayList<CareOpportunitiesFilterJson>) pC2Service.getBeanList(resultList);

				response = populateResponse(careOppList);

				response.setMessage(err.getProperty("successful"));
			}
			response.setSuccess(true);// Made changes for PCMSP-3234 as a valid scnerio defect was raised.
			/*else {
				response.setMessage(err.getProperty("successNoData"));
			}*/
			return response;
		}
		catch (Exception pe) {
			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}

	private ActionResponse populateResponse(ArrayList<CareOpportunitiesFilterJson> careOppList) {
		((GetPatientCareOpportunitiesResponse) (response)).getChildren().addAll(careOppList);
		return response;
	}

	/**
	 * Populates and return a data Map with the request parmeters, which further used by services
	 * 
	 * @param request
	 * @return
	 * @throws JsonException
	 */
	//	public Map<String, String> getDataMap(GetPatientCareOpportunitiesRequest request) throws JsonException{
	//		//PCMSRequest request = new HashMap<String, String>();
	//		
	//		if(request != null){
	//			//request.put("provGrpId", request.getProvGrpId());
	//			request.put(Constants.USER_ACS_INFO_JSON, request.getUserAcsInfoJson());
	//			//request.setProvGrpIds(request.getProvGrpIds());
	//		}
	//		return request;
	//	}

}
