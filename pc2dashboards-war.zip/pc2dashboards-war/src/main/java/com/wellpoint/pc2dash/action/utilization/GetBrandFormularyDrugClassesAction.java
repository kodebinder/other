package com.wellpoint.pc2dash.action.utilization;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.quality.GetQualityAction;
import com.wellpoint.pc2dash.dto.patient.TreeHierarchy;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.service.scorecard.commercial.UtilizationBrandFormularyFilterServiceImpl;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetBrandFormularyDrugClassesAction extends GetQualityAction {

	GetBrandFormularyDrugClassesResponse response = new GetBrandFormularyDrugClassesResponse();

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetBrandFormularyDrugClassesRequest request = (GetBrandFormularyDrugClassesRequest) actionRequest;
		List<TreeHierarchy> resultList = new ArrayList<TreeHierarchy>();

		try {
			request = (GetBrandFormularyDrugClassesRequest) cleanRequest(request);

			if (StringUtil.isJson(request)) {

				UtilizationBrandFormularyFilterServiceImpl service = new UtilizationBrandFormularyFilterServiceImpl();
				resultList.addAll(service.getFilter(request));

				if(CollectionUtils.isEmpty(resultList)) {
					response.setMessage(StringUtil.buildMessage(resultList.isEmpty()));
				} else {
					response.getChildren().addAll(resultList);
					response.setTotal(resultList.size());
					response.setMessage(StringUtil.buildMessage(resultList.isEmpty()));
				}

				response.setSuccess(true);
			}

		}
		catch (Exception e) {
			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(e, response);
		}

		return response;
	}

}
