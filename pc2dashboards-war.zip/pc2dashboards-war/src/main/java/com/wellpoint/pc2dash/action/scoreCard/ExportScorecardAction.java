package com.wellpoint.pc2dash.action.scoreCard;

import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.scorecard.ScorecardExport;
import com.wellpoint.pc2dash.util.StringUtil;


public class ExportScorecardAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		ExportScorecardRequest request = (ExportScorecardRequest) actionRequest;
		ExportScorecardResponse response = new ExportScorecardResponse();

		try {

			// preserve dataMap logic
			removeLobPgmPrefixes(request);

			List<String> filteredProvGrpList = new ArrayList<String>(); // Kill switch check on Provider groups
			if (StringUtil.isNotBlankOrFalse(request.getCmpId())) {
				filteredProvGrpList = filterProvGrpsByKillSwitch(request);
			}

			// Financial access check on provider groups
			if (null != filteredProvGrpList && filteredProvGrpList.size() > 0) {
				filteredProvGrpList = filterProvGrpsByClincalFinancialInd(request, filteredProvGrpList);
			}

			if (StringUtil.isExportDest(request.getDest())) {

				ScorecardExport exp = new ScorecardExport(request);
				ExportProcessor.getInstance().submit(exp);
			}

			response.setSuccess(true);

			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}
}
