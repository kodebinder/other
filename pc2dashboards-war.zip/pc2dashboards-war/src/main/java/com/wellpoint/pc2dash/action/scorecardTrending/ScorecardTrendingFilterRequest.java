package com.wellpoint.pc2dash.action.scorecardTrending;


public class ScorecardTrendingFilterRequest extends ScorecardTrendingRequest {

}
