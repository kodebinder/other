package com.wellpoint.pc2dash.data.dao;

import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.data.dto.AuditEntry;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;


public class AuditEntries extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(AuditEntries.class);

	@Override
	public boolean read(Dto o) throws Exception {

		boolean result = false;

		AuditEntry entry = (AuditEntry) o;

		StringBuilder sql = new StringBuilder()
			.append("select ")
			.append("  user_id, ")
			.append("  sesn_id, ")
			.append("  mstr_cnsmr_dim_key, ")
			.append("  user_actn_cd, ")
			.append("  user_rspns_txt, ")
			.append("  ip_adrs_txt, ")
			.append("  rcrd_creat_dtm ")
			.append("from ")
			.append("  aplctn_attstn_audt ")
			.append("where ")
			.append("  user_id = ? ")
			.append("  and sesn_id = ? ")
			.append("  and mstr_cnsmr_dim_key = ? ");
		
		if("-1".equals(entry.getPatientId()))
			sql.append("  and user_actn_cd = ? ");
		
		sql.append("with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());
			ps.setString(1, entry.getUserId());
			ps.setString(2, entry.getSessionId());
			ps.setString(3, entry.getPatientId());
			
			if("-1".equals(entry.getPatientId()))
				ps.setString(4, entry.getAccessType());

			executeQuery(logger, sql.toString());

			if (rs.next()) {

				entry.setReferenceId(rs.getString("user_rspns_txt"));
				entry.setIpAddress(rs.getString("ip_adrs_txt"));
				entry.setDateTime(rs.getDate("rcrd_creat_dtm"));

				result = true;
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to read audit entry.", e);
		}
		finally {

			close();
		}

		return result;
	}

	@Override
	public void insert(Dto o) throws Exception {

		AuditEntry entry = (AuditEntry) o;

		StringBuilder sql = new StringBuilder()
			.append("insert into aplctn_attstn_audt ( ")
			.append("  user_id, ")
			.append("  sesn_id, ")
			.append("  mstr_cnsmr_dim_key, ")
			.append("  mcid, ")
			.append("  user_actn_cd, ")
			.append("  user_rspns_txt, ")
			.append("  ip_adrs_txt, ")
			.append("  rcrd_creat_dtm ")
			.append(") ");
		/** R1.92 | checking whether request is for Pharmacy Scripts View | Start **/
		if (entry.getAccessType().equalsIgnoreCase(Constants.PHARMACY_SCRIPTS) || entry.getAccessType().equalsIgnoreCase(Constants.LAB_DETAILS)
			|| entry.getAccessType().equalsIgnoreCase(Constants.GDR) || entry.getAccessType().equalsIgnoreCase(Constants.RX_DETAILS)) { //added for PCMSP-4479   //PCMSP-18518
			sql.append(" values ( ")
				.append("	?, ")
				.append("	?, ")
				.append("	'-1', ")
				.append("	'-1', ")
				.append("	?, ")
				.append("	?, ")
				.append("	?, ")
				.append("	? ")
				.append("   ) ");
		}
		/** R1.92 | checking whether request is for Pharmacy Scripts View | End **/
		else {
			sql.append("select ")
				.append("	? as user_id, ")
				.append("	? as sesn_id, ")
				.append("	mstr_cnsmr_dim_key, ")
				.append("	mcid, ")
				.append("	? as user_actn_cd, ")
				.append("	? as user_rspns_txt, ")
				.append("	? as ip_adrs_txt, ")
				.append("	? as rcrd_creat_dtm ")
				.append("from ")
				.append("	mstr_cnsmr_dim ")
				.append("where ")
				.append("	mstr_cnsmr_dim_key = ? ");
		}
		sql.append("with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());
			ps.setString(1, entry.getUserId());
			ps.setString(2, entry.getSessionId());
			ps.setString(3, entry.getAccessType());
			ps.setString(4, entry.getReferenceId());
			ps.setString(5, entry.getIpAddress());
			ps.setTimestamp(6, new java.sql.Timestamp(entry.getDateTime().getTime()));
			/** R1.92 | checking whether request is for Pharmacy Scripts View | Start **/
			if (!entry.getAccessType().equalsIgnoreCase(Constants.PHARMACY_SCRIPTS) && !entry.getAccessType().equalsIgnoreCase(Constants.LAB_DETAILS)
				&& !entry.getAccessType().equalsIgnoreCase(Constants.GDR) && !entry.getAccessType().equalsIgnoreCase(Constants.RX_DETAILS)) { //added for PCMSP-4479   //PCMSP-18518
				ps.setString(7, entry.getPatientId());
			}
			/** R1.92 | checking whether request is for Pharmacy Scripts View | End **/

			executeUpdate(logger, sql.toString());
		}
		catch (Exception e) {

			throw new Exception("Unable to insert audit entry.", e);
		}
		finally {

			close();
		}
	}

	@Override
	public void update(Dto o) throws Exception {

	}

	@Override
	public void delete(Dto o) throws Exception {

	}

}
