package com.wellpoint.pc2dash.data.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.costOpportunity.GetHighValueSpecialistReferralsSpecialistRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.costOpportunity.HighValueSpecialistReferralsSpecialistBean;
import com.wellpoint.pc2dash.dto.costOpportunity.MinimumCriteriaBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class HighValueSpecialistReferralsSpecialistDao extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger
		.getLogger(HighValueSpecialistReferralsSpecialistDao.class);

	public List<HighValueSpecialistReferralsSpecialistBean> getData(
		GetHighValueSpecialistReferralsSpecialistRequest request, boolean exportFlag, int index, int limit) throws Exception {

		List<HighValueSpecialistReferralsSpecialistBean> result = new ArrayList<HighValueSpecialistReferralsSpecialistBean>();
		setRowCount(0);

		MinimumCriteriaBean minCrit = new MinimumCriteriaBean("epsd_cnt", "coc_spclty_ctgry_smry", "COC_SPL_MIN_RFRL", null); //PCMSP - 6867
		MinimumCriteriaBean minCritSpclty = new MinimumCriteriaBean("epsd_cnt", "coc_spclty_ctgry_smry", "COC_SPL_MIN_RFRL", "sub_mtrc_nm"); //PCMSP-6867


		CommonQueries cq = new CommonQueries();
		boolean displayDashes = cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request, minCrit);
		boolean displayDashesSpclty = cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request, minCritSpclty); //PCMSP-6867

		StringBuilder query = new StringBuilder()

			.append(" select    c.* ")
			.append(" from   ( ")
			.append(" select   b.*, row_number() over( order by ")
			.append(buildSortClause(request))
			.append(" ) as row_nbr ")
			.append(" from    ( ")
			.append(" select ")
			.append(" a.SUB_MTRC_CD, ")
			.append(" a.SUB_MTRC_NM, ")
			.append(" a.SPCLTY_PROV_ID, ")
			.append(" a.SPCLTY_PROV_NM, ")
			.append(" a.SPCLTY_PROV_GRP_NM, ")
			.append(" a.EPISODE_COUNT, ")
			.append(" a.EPISODE_COST_AMT, ")
			.append(" a.TOTALOPPORTUNITY, ")
			.append(" a.highCostSpecialistInd, ")
			.append(" a.providerId, ")
			.append(" a.row_cnt ")
			.append(" from   ( ")
			.append(" select ")
			.append(" smry.SUB_MTRC_CD as SUB_MTRC_CD, ")
			.append(" smry.SUB_MTRC_NM as SUB_MTRC_NM, ")
			.append(" smry.SPCLTY_PROV_ID as SPCLTY_PROV_ID, ")
			.append(" smry.SPCLTY_PROV_NM as SPCLTY_PROV_NM, ")
			.append(" smry.SPCLTY_PROV_GRP_NM as SPCLTY_PROV_GRP_NM, ")
			.append(" case")
			.append(" when  sum(smry.epsd_cnt) >= 0 then  sum(epsd_cnt) else  0 end as EPISODE_COUNT, ")
			.append(" case")
			.append(" when  sum(smry.epsd_cost_amt)>= 0 then  sum(epsd_cost_amt) else  0.000 end as EPISODE_COST_AMT, ")
			.append(" case")
			.append(" when  sum(smry.cost_oprtnty_amt) >= 0 then  sum(cost_oprtnty_amt) else  0.000 end as TOTALOPPORTUNITY, ")
			.append(" case when sum(HCOST_EPSD_CNT)>0 then 'Y' else 'N' end as highCostSpecialistInd, ")
			.append(" LISTAGG(smry.IP_DIM_KEY, '_') WITHIN GROUP(ORDER BY smry.IP_DIM_KEY) as providerId ,")
			.append(" count(*) over () as row_cnt ")
			.append(" from   COC_SPCLTY_CTGRY_SMRY smry ")
			.append("         join  poit_user_scrty_acs pusa on (smry.prov_grp_id = pusa.prov_grp_id and ")
			.append("           case ")
			.append("                      when    pusa.prov_org_tax_id = '0' ")
			.append("                      then    smry.prov_org_tax_id ")
			.append("                      else    pusa.prov_org_tax_id end = smry.prov_org_tax_id) ")
			.append("       where  pusa.sesn_id = ? ")
			.append("       and  pusa.enttlmnt_hash_key = ? ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and smry.prov_grp_id in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(
				StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and smry.pgm_dim_key in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(
				StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and smry.lob_desc in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(
				StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and smry.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and smry.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys()) + ") ");
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getSpecialtyCode())) {
			query.append(" and smry.SUB_MTRC_CD in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getSpecialtyCode())
				+ ") ");
		}

		query.append(" group by ")
			.append(" smry.SUB_MTRC_CD , ")
			.append(" smry.SUB_MTRC_NM , ")
			.append(" smry.SPCLTY_PROV_ID , ").append(" smry.SPCLTY_PROV_NM , ").append(" smry.SPCLTY_PROV_GRP_NM ")
			.append("     ) as a ")
			.append("   ) as b ")
			.append(" ) as c ");
			/*if(!exportFlag){
			query.append(" where  c.row_nbr between ? and ? ");
			}
			query.append(" order by   c.row_nbr  with ur ");*/
			query.append(" where  c.row_nbr between ? and ? ");
			query.append(" order by   c.row_nbr  with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());

			buildPreparedStatement(request, i, exportFlag, index, limit);

			executeQuery(logger, query.toString());

			result = convertSelectedRowsToObjects(rs, request, displayDashes, displayDashesSpclty, exportFlag);

		}
		catch (Exception e) {

			throw new Exception("Unable to get HighValueSpecialistReferralSpecialistDao (" + request.getEntitlementId()
				+ ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;

	}

	private void buildPreparedStatement(GetHighValueSpecialistReferralsSpecialistRequest request, int i,
		boolean exportFlag, int index, int limit) throws SQLException {

		int start = 0;
		int stop = 0;
		
		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getSpecialtyCode())) {
			String[] array = request.getSpecialtyCode().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (!exportFlag) {
			start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
			stop = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
		}
		else {
			start = index;
			stop = limit;
		}
		ps.setInt(++i, start + 1);
		ps.setInt(++i, start + stop);

	}

	private List<HighValueSpecialistReferralsSpecialistBean> convertSelectedRowsToObjects(ResultSet rs,
		GetHighValueSpecialistReferralsSpecialistRequest request, boolean displayDashes, boolean displayDashesSpclty, boolean exportFlag)
		throws SQLException {

		List<HighValueSpecialistReferralsSpecialistBean> list = new ArrayList<HighValueSpecialistReferralsSpecialistBean>();

		while (rs.next()) {

			HighValueSpecialistReferralsSpecialistBean item = new HighValueSpecialistReferralsSpecialistBean();

			if (null != rs.getString("SUB_MTRC_CD")) {
				item.setSpecialtyCode(rs.getString("SUB_MTRC_CD"));

			}
			if (null != rs.getString("SUB_MTRC_NM")) {
				item.setSpecialtyName(rs.getString("SUB_MTRC_NM"));

			}
			if (null != rs.getString("SPCLTY_PROV_ID")) {
				item.setSpecialistCode(rs.getString("SPCLTY_PROV_ID"));

			}
			if (null != rs.getString("SPCLTY_PROV_NM")) {
				item.setSpecialistName(rs.getString("SPCLTY_PROV_NM"));

			}
			if (null != rs.getString("SPCLTY_PROV_GRP_NM")) {
				item.setSpecialistGroupName(rs.getString("SPCLTY_PROV_GRP_NM"));

			}
			if (null != rs.getString("highCostSpecialistInd")) {
				item.setHighCostSpecialistInd(rs.getString("highCostSpecialistInd").equals(Constants.Y) ? Constants.BOOL_TRUE : Constants.BOOL_FALSE);
			}
			if (null != rs.getString("providerId")) {
				item.setProviderId(rs.getString("providerId"));
			}

			if (exportFlag) {
				if (null != rs.getString("EPISODE_COUNT")) {
					item.setTotalEpisodeCount(StringUtil.convertIntWithCommaToString(rs.getInt("EPISODE_COUNT")));

				}
				if (null != rs.getString("EPISODE_COST_AMT")) {
					item.setTotalEpisodeCost(StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("EPISODE_COST_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString()));

				}
			}
			else {
				if (null != rs.getString("EPISODE_COUNT")) {
					item.setTotalEpisodeCount(rs.getString("EPISODE_COUNT"));
				}
				if (null != rs.getString("EPISODE_COST_AMT")) {
					item.setTotalEpisodeCost(rs.getString("EPISODE_COST_AMT"));

				}
			}
			/*PCMSP-20354 STARTS 1*/
			/*
			if (displayDashes || displayDashesSpclty) { //PCMSP - 6867
				item.setCostOpportunity(Constants.DASHES);
			}*/
			if (exportFlag) {
				if (null != rs.getString("TOTALOPPORTUNITY")) {
					if (displayDashes || displayDashesSpclty) {
						if ((Integer.parseInt(rs.getString("EPISODE_COUNT")) < Constants.HVSR_MIN_EPSD_CNT )) {
							item.setCostOpportunity(Constants.DASHES);
						}else {
							item.setCostOpportunity((rs.getBigDecimal("TOTALOPPORTUNITY").intValue() >= 0)
									? StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("TOTALOPPORTUNITY")
											.setScale(2, BigDecimal.ROUND_HALF_UP).toString())
									: Constants.DASHES);
						}
					} else {
						if ((Integer.parseInt(rs.getString("EPISODE_COUNT")) < Constants.HVSR_MIN_EPSD_CNT )) {
							item.setCostOpportunity(Constants.DASHES);
						}else {
							item.setCostOpportunity((rs.getBigDecimal("TOTALOPPORTUNITY").intValue() >= 0)
									? StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("TOTALOPPORTUNITY")
											.setScale(2, BigDecimal.ROUND_HALF_UP).toString())
									: Constants.DASHES);
						}
					}
				} else {
					item.setCostOpportunity(Constants.DASHES);
				}
			} else {
				if (null != rs.getString("TOTALOPPORTUNITY")) {
					if (displayDashes || displayDashesSpclty) {
						if ((Integer.parseInt(rs.getString("EPISODE_COUNT")) < Constants.HVSR_MIN_EPSD_CNT)) {
							item.setCostOpportunity(Constants.DASHES);
						}else {
							item.setCostOpportunity(rs.getString("TOTALOPPORTUNITY"));
						}
					} else {
						if ((Integer.parseInt(rs.getString("EPISODE_COUNT")) < Constants.HVSR_MIN_EPSD_CNT)) {
							item.setCostOpportunity(Constants.DASHES);
						}else {
							item.setCostOpportunity(rs.getString("TOTALOPPORTUNITY"));
						}
					}
				} else {
						item.setCostOpportunity(Constants.DASHES);
				}
			}
			/*PCMSP-20354 ENDS 1*/
			item.setHasEpisodesDrilldownInd(request.isHasEpisodesDrilldownInd());
			list.add(item);
			if (getRowCount() == 0) {
				setRowCount(rs.getInt("row_cnt"));
			}
			if (exportFlag) {
				setTotalExport(rs.getInt("row_cnt"));
			}
		}

		return list;

	}

	private String buildSortClause(GetHighValueSpecialistReferralsSpecialistRequest request) {

		StringBuilder query = new StringBuilder();
		String defaultColumn = " TOTALOPPORTUNITY ";
		String defaultSort = defaultColumn + " desc ";

		if (null != request.getSort()) {

			for (QuerySort sort : request.getSort()) {

				String dir = sort.getDirection().replaceAll("\"", "");
				String property = sort.getProperty();

				if (property.equals("specialtyName")) {
					query.append(" SUB_MTRC_NM " + dir + ", " + defaultSort);
				}
				else if (property.equals("specialistName")) {
					query.append(" SPCLTY_PROV_NM " + dir + ", " + defaultSort);
				}
				else if (property.equals("specialistGroupName")) {
					query.append(" SPCLTY_PROV_GRP_NM " + dir + ", " + defaultSort);
				}
				else if (property.equals("totalEpisodeCount")) {
					query.append(" EPISODE_COUNT " + dir + ", " + defaultSort);
				}
				else if (property.equals("totalEpisodeCost")) {
					query.append(" EPISODE_COST_AMT " + dir + ", " + defaultSort);
				}
				else if (property.equals("costOpportunity")) {
					query.append(" TOTALOPPORTUNITY " + dir + ", " + defaultSort);
				}
				else {
					query.append(defaultColumn + dir);
				}
			}

		}
		else {

		}

		return query.toString();

	}

	@Override
	public boolean read(Dto o) throws Exception {
		
		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {
		
		
	}

	@Override
	public void update(Dto o) throws Exception {
		
		
	}

	@Override
	public void delete(Dto o) throws Exception {
		
		
	}

}