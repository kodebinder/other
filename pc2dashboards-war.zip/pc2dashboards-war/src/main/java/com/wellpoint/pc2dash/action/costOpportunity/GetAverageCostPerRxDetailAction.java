package com.wellpoint.pc2dash.action.costOpportunity;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.data.dto.AuditEntry;
import com.wellpoint.pc2dash.dto.costOpportunity.AverageCostPerRxDetailBean;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportGridColumn;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.costOpportunity.CostOpportunityAverageCostPerRxDetailExport;
import com.wellpoint.pc2dash.service.costOpportunity.AverageCostPerRxDetailServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetAverageCostPerRxDetailAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		List<AverageCostPerRxDetailBean> resultList = null;

		GetAverageCostPerRxDetailRequest request = (GetAverageCostPerRxDetailRequest) actionRequest;
		GetAverageCostPerRxDetailResponse response = new GetAverageCostPerRxDetailResponse();
		ErrorProperties err = ErrorProperties.getInstance();
		AverageCostPerRxDetailServiceImpl service = new AverageCostPerRxDetailServiceImpl();


		List<String> grps = null;

		try {

			removeLobPgmPrefixes(request);
			
			Boolean isattest = isAttested(request); //PCMSP-18518

			if (StringUtils.isNotBlank(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			if (null != grps && !grps.isEmpty()) {
				request.setProvGrpIdsWithoutClinicalCheck(StringUtils.join(grps, ','));
				grps = filterProvGrpsByClinicalInd(request, grps);
				request.setProvGrpIds(CollectionUtils.isNotEmpty(grps) ? StringUtils.join(grps, ',') : Constants.DASHES);
			}

			CommonQueries cq = new CommonQueries();
			request.setTapId(request.getMetricViewId());
			request.setSuppression(cq.getActiveSuppressionForSelectComponents(request));
			
			MetaData metaData = new MetaData();
			metaData.setReportingPeriod(cq.getReportingPeriodForCostOpportunity(Constants.AVERAGE_COST_PER_RX));
			metaData.setReportDate(cq.getReportDateForCostOpportunity(Constants.AVERAGE_COST_PER_RX));

			if (StringUtil.isExportDest(request.getDest())) {
            	request.setReportingPeriod(metaData.getReportingPeriod());
            	request.setReportDate(metaData.getReportDate());
				List<ExportGridColumn> columns = service.buildExportGridColumns(request);
				CostOpportunityAverageCostPerRxDetailExport exp = new CostOpportunityAverageCostPerRxDetailExport(request, columns);

				ExportProcessor.getInstance().submit(exp);
		        response.setSuccess(true);// Added for release-2.4.0-PCMSP-18613	
			}
			else {

				if (null != grps && !grps.isEmpty() && isattest) {

					resultList = service.getData(request);

					if (null == resultList || resultList.isEmpty()) {
						response.setMessage(err.getProperty("successNoData"));
					}
					else {
						response.setMetaData(metaData);
						response.setMessage(err.getProperty("successful"));
						response.setData(resultList);
						response.setTotal(service.getNoOfRecords());
					}
					response.setSuccess(true);
				}
				else if (grps.isEmpty() && isattest) {
					response.setSuccess(true);
				}
				else {
					response.setSuccess(false);
				}
			}
			
			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}
	
	//PCMSP-18518
	private boolean isAttested(GetAverageCostPerRxDetailRequest request) throws Exception {

		AuditEntry dto = new AuditEntry();
		dto.setUserId(request.getUserId());
		dto.setSessionId(request.getSessionId());
		dto.setPatientId("-1");
		dto.setAccessType(Constants.RX_DETAILS);

		return dto.read();
	}
}