package com.wellpoint.pc2dash.action.perfSummTickers;

import com.wellpoint.pc2dash.data.dto.PCMSRequest;

public class GetCommercialTickersRequest extends PCMSRequest {

}
