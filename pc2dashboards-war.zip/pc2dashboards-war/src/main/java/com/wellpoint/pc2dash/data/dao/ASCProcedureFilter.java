package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.costOpportunity.GetASCProcedureFilterRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.costOpportunity.ASCProcedureFilterBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;

public class ASCProcedureFilter extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(ASCProcedureFilter.class);

	public List<ASCProcedureFilterBean> getASCProcedureDetails(GetASCProcedureFilterRequest request) throws Exception {

		List<ASCProcedureFilterBean> result = new ArrayList<ASCProcedureFilterBean>();

		StringBuilder sql = new StringBuilder()
			.append(" select smry.sub_mtrc_cd as sub_mtrc_cd, smry.sub_mtrc_nm as sub_mtrc_nm ")
			.append(" from ")
			.append(" coc_asc_ctgry_smry smry ")
			.append(" group by smry.sub_mtrc_cd, smry.sub_mtrc_nm ")
			.append(" order by smry.sub_mtrc_nm ")
			.append(" with ur ");


		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			prepareStatement(logger, sql.toString());
			executeQuery(logger, sql.toString());

			while (rs.next()) {

				ASCProcedureFilterBean json = new ASCProcedureFilterBean();

				if (rs.getString("sub_mtrc_cd") != null) {
					json.setProcedureCode(rs.getString("sub_mtrc_cd"));
				}
				if (rs.getString("sub_mtrc_nm") != null) {
					json.setProcedureName(rs.getString("sub_mtrc_nm"));
				}

				result.add(json);
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get ASCProcedureFilter (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}

	@Override
	public boolean read(Dto o) throws Exception {

		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {


	}

	@Override
	public void update(Dto o) throws Exception {


	}

	@Override
	public void delete(Dto o) throws Exception {


	}

}
