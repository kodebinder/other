package com.wellpoint.pc2dash.action.patients;

import java.util.List;

import com.wellpoint.pc2dash.data.dto.PCMSRequest;
import com.wellpoint.pc2dash.dto.savedFilters.PatientFilter;


public class PatientSearchRequest extends PCMSRequest {

	protected List<PatientFilter> filter;
	protected String memberFirstName;
	protected String memberGender;
	protected String memberId;
	protected String memberLastName;

	public List<PatientFilter> getFilter() {
		return filter;
	}

	public void setFilter(List<PatientFilter> filter) {
		this.filter = filter;
	}

	public String getMemberFirstName() {
		return memberFirstName;
	}

	public void setMemberFirstName(String memberFirstName) {
		this.memberFirstName = memberFirstName;
	}

	public String getMemberGender() {
		return memberGender;
	}

	public void setMemberGender(String memberGender) {
		this.memberGender = memberGender;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getMemberLastName() {
		return memberLastName;
	}

	public void setMemberLastName(String memberLastName) {
		this.memberLastName = memberLastName;
	}

}
