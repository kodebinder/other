package com.wellpoint.pc2dash.action.medicalLossRatio;

import com.wellpoint.pc2dash.action.medicalCostServiceDetails.GetMedicalCostServiceDetailsRequest;

public class GetMedicalLossRatioRequest extends GetMedicalCostServiceDetailsRequest {
	private String pgmName;
	private String medicalPanelName;
	private String fundgSrcPoolCd;
	private String provGrpName;

	public String getPgmName() {
		return pgmName;
	}

	public void setPgmName(String pgmName) {
		this.pgmName = pgmName;
	}

	public String getMedicalPanelName() {
		return medicalPanelName;
	}

	public void setMedicalPanelName(String medicalPanelName) {
		this.medicalPanelName = medicalPanelName;
	}


	public String getFundgSrcPoolCd() {
		return fundgSrcPoolCd;
	}


	public void setFundgSrcPoolCd(String fundgSrcPoolCd) {
		this.fundgSrcPoolCd = fundgSrcPoolCd;
	}


	public String getProvGrpName() {
		return provGrpName;
	}


	public void setProvGrpName(String provGrpName) {
		this.provGrpName = provGrpName;
	}

}
