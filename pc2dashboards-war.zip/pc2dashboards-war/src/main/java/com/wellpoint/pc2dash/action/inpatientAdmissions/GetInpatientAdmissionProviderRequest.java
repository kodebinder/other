package com.wellpoint.pc2dash.action.inpatientAdmissions;

import com.wellpoint.pc2dash.data.dto.PopulationManagementRequest;

public class GetInpatientAdmissionProviderRequest extends PopulationManagementRequest {
	
}
