package com.wellpoint.pc2dash.data;


public interface Dao {

	public boolean read(Dto o) throws Exception;

	public void insert(Dto o) throws Exception;

	public void update(Dto o) throws Exception;

	public void delete(Dto o) throws Exception;
}
