package com.wellpoint.pc2dash.action.base;

import com.wellpoint.pc2dash.logging.Pc2DashLogger;


public class Pc2ActionFactory {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(Pc2ActionFactory.class);
	static Pc2ActionFactory instance = null;

	/**
	 * private constructor to ensure singleton
	 */
	private Pc2ActionFactory() {

	}

	/**
	 * used to return instance
	 * 
	 * @return
	 */
	public static Pc2ActionFactory getInstance() {
		if (instance == null) {
			instance = new Pc2ActionFactory();
		}
		return instance;
	}

	/**
	 * returns a concrete Action class based on the concreteClassName
	 * 
	 * @param concreteClassName
	 * @return
	 * @throws Exception
	 */
	public Action makeAction(String concreteClassName) throws Exception {
		return (Action) makeClass(concreteClassName);
	}

	/**
	 * returns a concrete ActionRequest class based on the concreteClassName
	 * 
	 * @param concreteClassName
	 * @return
	 * @throws Exception
	 */
	public ActionRequest makeActionRequest(String concreteClassName) throws Exception {
		return (ActionRequest) makeClass(concreteClassName);
	}

	/**
	 * returns a concrete ActionResponse class based on the concreteClassName
	 * 
	 * @param concreteClassName
	 * @return
	 * @throws Exception
	 */
	public ActionResponse makeActionResponse(String concreteClassName) throws Exception {
		return (ActionResponse) makeClass(concreteClassName);
	}

	/**
	 * private method instantiates the class based on the concreteClassName
	 * 
	 * @param concreteClassName
	 * @return
	 * @throws Exception
	 */
	private Object makeClass(String concreteClassName) throws Exception {

		Object br = null;
		Class<?> cls = null;

		if (concreteClassName == null) {
			throw new Exception("Class Not Found:" + concreteClassName);
		}

		try {

			try {

				cls = Class.forName(concreteClassName);
			}
			catch (ClassNotFoundException e) {

				ClassLoader cl = getClass().getClassLoader();

				if (cl != null) {

					try {
						cls = cl.loadClass(concreteClassName);
					}
					catch (ClassNotFoundException ee) {
						logger.error("Class not found exception : " + ee);
						throw new Exception("Class not found: " + concreteClassName + ", check the action.properties file to see if it is defined", e);
					}
				}
			}

			if (cls != null) {
				br = cls.newInstance();
			}
		}
		catch (InstantiationException e) {
			throw new Exception("Could not instantiate Class: " + concreteClassName, e);
		}
		catch (IllegalAccessException e) {
			throw new Exception("Could not access Toolkit: " + concreteClassName, e);
		}
		return br;
	}
}
