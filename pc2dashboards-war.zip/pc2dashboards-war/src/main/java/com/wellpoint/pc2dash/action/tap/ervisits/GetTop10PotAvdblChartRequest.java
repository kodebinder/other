package com.wellpoint.pc2dash.action.tap.ervisits;

import com.wellpoint.pc2dash.data.dto.PopulationManagementRequest;

public class GetTop10PotAvdblChartRequest extends PopulationManagementRequest {

}
