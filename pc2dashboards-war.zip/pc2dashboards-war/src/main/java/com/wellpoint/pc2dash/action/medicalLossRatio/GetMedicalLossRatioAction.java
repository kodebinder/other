package com.wellpoint.pc2dash.action.medicalLossRatio;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.performance.medicalLossRatio.MlrConstrDto;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.performance.MedicalLossRatioExport;
import com.wellpoint.pc2dash.service.medicalCost.MedicalLossRatioServiceImpl;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;


public class GetMedicalLossRatioAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetMedicalLossRatioRequest request = (GetMedicalLossRatioRequest) actionRequest;
		ActionResponse response = new GetMedicalLossRatioResponse();
		ErrorProperties err = ErrorProperties.getInstance();

		MedicalLossRatioServiceImpl service = new MedicalLossRatioServiceImpl();
		List<String> grps = new ArrayList<String>();

		List<Map<String, String>> medicalLossRatioList = new ArrayList<Map<String, String>>();
		List<MlrConstrDto> resultList = null;
		int totalRecords = 0;

		try {

			// Kill switch check on Provider groups
			if (StringUtil.isNotBlankOrFalse(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			// Clinical access check on provider groups
			if (null != grps && !grps.isEmpty()) {
				grps = filterProvGrpsByFinancialInd(request, grps);
				//request.setProvGrpIds(StringUtils.join(grps, ','));
			}
			request.setProvGrpIds(StringUtils.join(grps, ','));

			if (null == request.getDest() || request.getDest().equalsIgnoreCase("json")) {

				resultList = service.getData(request);
				//following code is used to add the missing product if any to the resultList 

				if (resultList != null && !resultList.isEmpty()) {
					String[] products = request.getProducts().split(",");
					int count = 0;
					int j;
					for (int i = 0; i < products.length; i++) {
						for (j = 0; j < resultList.size(); j++) {
							if (products[i].equalsIgnoreCase(resultList.get(j).getPslDesc())) {
								count++;
							}
						}
						if (count == 0) {
							MlrConstrDto itemB = new MlrConstrDto();
							itemB.setPslDesc(products[i].toLowerCase().trim());
							resultList.add(itemB);
						}
					}
				}
				medicalLossRatioList = (List<Map<String, String>>) service.getBeanList(resultList);
				totalRecords = service.getTotalRecords();

				response.setData(medicalLossRatioList);
				response.setTotal(totalRecords);

				if (null == resultList || (null != resultList && resultList.isEmpty())) {
					response.setMessage(err.getProperty("successNoData"));
				}
				else {
					response.setMessage(err.getProperty("successful"));
				}
			}

			if (StringUtil.isExportDest(request.getDest())) {

				MedicalLossRatioExport exp = new MedicalLossRatioExport(request);
				ExportProcessor.getInstance().submit(exp);
			}

			response.setSuccess(true);
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

		return response;
	}
}
