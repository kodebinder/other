package com.wellpoint.pc2dash.data.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.drilldown.GetDrillDownRequest;
import com.wellpoint.pc2dash.action.quality.GetQualityPatientsRequest;
import com.wellpoint.pc2dash.dto.patient.EligibleMeasures;
import com.wellpoint.pc2dash.dto.patient.Patient;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.DateUtil;
import com.wellpoint.pc2dash.util.QueryConstants;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.ReferralBeanConstants;
import com.wellpoint.pc2dash.util.StringUtil;

public class GeneralPatients extends Quality {

	protected String buildSharedSelectGroupByColumns(GetDrillDownRequest request, List<String> columnsForExport) {

		StringBuilder select = new StringBuilder()
			.append(" psf.last_nm ")
			.append(", psf.frst_nm ")
			.append(", psf.hc_id ")
			.append(", psf.brth_dt ")
			.append(", psf.age_nbr ")
			.append(", psf.gndr_cd ")
			.append(", psf.mbr_adrs_txt ")
			.append(", psf.mbr_city_nm ")
			.append(", psf.mbr_st_cd ")
			.append(", psf.mbr_zip_cd ")
			.append(", psf.phone_nbr ")
			.append(", psf.psl_grp_nm as prod_cf_cd ")
			.append(", psf.lob_desc ")
			.append(", psf.psl_desc ")
			.append(", psf.lob_nm ")
			.append(", psf.mstr_cnsmr_dim_key ")
			.append(", psf.prov_grp_hrchy_dim_key ")
			.append(", psf.ip_npi ")
			.append(", psf.ip_last_nm ")
			.append(", psf.ip_frst_nm ")
			.append(", psf.ip_type_cd ")
			.append(", psf.prov_org_full_nm ")
			.append(", psf.prov_grp_id ")
			.append(", psf.dseas_cndtn_cnt ")
			.append(", psf.hot_spotr_chrnc_ind_cd ")
			.append(", psf.hot_spotr_readmsn_ind_cd ")
			.append(", psf.hot_spotr_gap_scor_trnd_ind_cd ")
			.append(", psf.hot_spotr_gap_scor_nbr ")
			.append(", psf.new_atrbd_mbr_ind_cd ")
			.append(", psf.inpat_authrzn_ind_cd ")
			.append(", psf.ihm_ind_cd")
			.append(", psf.ihm_pgm_nm")
			.append(", psf.cm_pgm_cnt ")
			.append(", psf.dm_pgm_cnt ")
			.append(", psf.prsptv_wgtd_risk_nbr ")
			.append(", psf.prsptv_wgtd_risk_chng_pct ")
			.append(", psf.prov_org_tax_id as org_tin ")
			.append(", psf.crprt_plan_cmpny_nm ")
			.append(", psf.home_plan_nm ")
			.append(", psf.atrbn_stts_cd ")
			.append(", psf.prov_grp_dim_key ")
			.append(", psf.prov_org_dim_key ")
			.append(", psf.ip_dim_key ")
			.append(", psf.ooa_ind_cd,coalesce(ref.sent_rfrl_cnt, 0) as sent_referral_count")
			.append(", coalesce(ref.recvd_rfrl_cnt, 0) as rcvd_referral_count")
			.append(", case when  coalesce(ref.rfrl_cnt, 0) > 0 then  1 else  0 end as has_referrals")
			.append(", psf.lpr_ind_cd ")
			.append(", psf.pgm_id ")
			.append(", psf.lob_ctgry_nm ")
			// AF00030 made changes for PCMSP-1038
			.append("   , psf.high_risk_ind_cd ")
			.append(" , psf.phrmcy_hlth_srvcs_ind ");

		if (columnsForExport != null && columnsForExport.contains("Attributed Provider")) {
			select.append(", psf.IP_SPCLTY_NM")
				.append(", psf.ip_adrs_txt ")
				.append(", psf.ip_city_nm ")
				.append(", psf.ip_st_cd ")
				.append(", psf.ip_zip_cd ");
		}

		if (null != request.getMeasureName() && request.getMeasureName().equals(Constants.LIER)) {
			select.append(", cf.low_intnsty_er_vst_cnt ");
		}

		if (null != request.getMeasureName() && request.getMeasureName().equals(Constants.ASA)) {
			select.append(", cf.ambltry_snsitv_vst_cnt ");
		}

		if (null != request.getMeasureName() && request.getMeasureName().equals(Constants.RAR)) {
			select.append(", cf.totl_readmsn_cnt ");
			select.append(" ,cf.indx_readmsn_cnt ");
		}

		if (null != request.getMeasureName() && request.getMeasureName().contains(Constants.GDR)) {
			select.append(", CX.GDR_CNT ");
		}
		// PCMSP-8461 : Starts 1
		if (null != request.getMeasureName() && request.getMeasureName().contains(Constants.FRMLY)) {
			select.append(", CX.GDR_CNT ");
		}
		// PCMSP-8461 : Ends 1
		if (isExport() && null != columnsForExport) {

			if (columnsForExport.contains(Constants.MEASURES)) {
				select.append(QueryConstants.buildMeasuresExportColumnNames());
			}

			/*
			 * Earlier : CM/DM not applicable for FPCC
			 * Changing it back after updated requirement to include CM/DM for FPCC
			 * Removing the if clause
			 */
			if (columnsForExport.contains(Constants.CMDMPrograms)) {
				select.append(QueryConstants.buildCmDmExportColumnNames());
			}

			if (columnsForExport.contains(Constants.VISIT_DETAIL)) {
				select.append(QueryConstants.buildAvdbleErVisitsExportColumnNames());
			}

			if (columnsForExport.contains(Constants.ADMIT_DETAIL)) {
				select.append(QueryConstants.buildASAdmitsExportColumnNames());
			}

			if (columnsForExport.contains(Constants.FILL_DETAIL)) {
				select.append(QueryConstants.buildGDRFillDetailsExportColumnNames());
			}
		}

		return select.toString();
	}

	/**
	 * Sub-select costs less than joins, and all Quality queries select that column
	 * 
	 * @return "non_adhrnc_qlty_msr_nbr" column sub-select
	 */
	protected String buildNonAdherenceQualityMeasureNumberSubSelect() {
		StringBuilder select = new StringBuilder()
			.append(", (select coalesce(count(distinct cf.msr_dim_key), 0) ")
			.append(" from cmplnc_fact cf ")
			.append(" inner join scrcrd_msr_hrchy_dim smhd on cf.scrcrd_msr_hrchy_dim_key = smhd.scrcrd_msr_hrchy_dim_key ")
			.append(" where ")
			.append(" smhd.cmpst_type_desc = ? ")
			.append(" and cf.anlyss_as_of_dt = ? ")
			.append(" and cf.msr_nmrtr_nbr = 0 ")
			.append(" and cf.rcrd_stts_cd <> 'DEL' ")
			.append(" and cf.msrmnt_prd_strt_dt = ? ")
			.append(" and cf.mstr_cnsmr_dim_key = psf.mstr_cnsmr_dim_key ")
			.append(") as non_adhrnc_qlty_msr_nbr ");

		return select.toString();
	}
	
	/**
	 * Sub-select costs less than joins, and all Quality queries select that column
	 * 
	 * @return "non_adhrnc_qlty_msr_nbr" column sub-select
	 */
	protected String buildNonAdherenceImprovementQualityMeasureNumberSubSelect(GetQualityPatientsRequest request) {
		StringBuilder select = new StringBuilder()
			.append(", (select coalesce(count(distinct cf.msr_dim_key), 0) ")
			.append(" from cmplnc_fact cf ")
			.append(" inner join scrcrd_msr_hrchy_dim smhd on cf.scrcrd_msr_hrchy_dim_key = smhd.scrcrd_msr_hrchy_dim_key ")
			.append("join msr_dim md on (smhd.msr_dim_key = md.msr_dim_key) ")
			.append(" where ")
			.append(" smhd.cmpst_type_desc = ? ")
			.append(" and cf.anlyss_as_of_dt = ? ")
			.append(" and cf.msr_nmrtr_nbr = 0 ")
			.append(" and cf.rcrd_stts_cd <> 'DEL' ")
			.append(" and cf.msrmnt_prd_strt_dt = ? ")
			.append(" and cf.mstr_cnsmr_dim_key = psf.mstr_cnsmr_dim_key ");
		if ((request.getProgramLobTypeCd().equalsIgnoreCase(Constants.MEDICARE) || request.getProgramLobTypeCd().equalsIgnoreCase(Constants.FPCC_MEDICARE)) && request.getCompositeType().equalsIgnoreCase(Constants.IMPCOMPOSITETYPE)) {
			select.append(" and  md.msr_dsply_nm not like ? ");
		}
		
			select.append(") as non_adhrnc_qlty_msr_nbr ");

		return select.toString();
	}

	/**
	 * CommercialImprovementQualityPatients' and MedicaidImprovementQualityPatients' join clauses are identical except for
	 * the MSR_TYPE_CD value, which will be set using ps.setString() in buildPreparedStatement()
	 * 
	 * @return String
	 */
	protected String buildImprovementJoins(GetQualityPatientsRequest request) {
		StringBuilder from = new StringBuilder();
		from.append(" join ( ");
		from.append(" 	select ");
		from.append(" 		qlty.msr_dim_key as qlty_msr_dim_key ");
		from.append(" 		, imprv.msr_dsply_nm ");
		/**
		 * Changed the alias from which CARE_OPRTNTY_MSR_DIM_KEY is getting picked | IMPRV -> QLTY
		 * Based on suggestions by Data team, dated 05-May-16 to fix defect WLPRD02576052
		 * Release 1.9 <DF WLPRD02576052> <AD12140>
		 */
		from.append(" 		, qlty.care_oprtnty_msr_dim_key ");
		from.append(" 		, imprv.msr_dim_key as imp_msr_dim_key ");
		from.append(" 		, imprv.msr_id ");
		from.append(" 		, qlty.scrcrd_msr_hrchy_dim_key ");
		from.append(" 		, imprv.cmpst_defn_id ");
		from.append(" 		, qlty.msrmnt_prd_strt_dt ");
		from.append(" 		, imprv.pgm_dim_key ");
		from.append(" 	from ");
		from.append(" 		(select ");
		from.append(" 			a.msr_dim_key ");
		from.append(" 			, a.msr_id ");
		/**
		 * Picking up CARE_OPRTNTY_MSR_DIM_KEY from QLTY
		 * Based on suggestions by Data team, dated 05-May-16 to fix defect WLPRD02576052
		 * Release 1.9 <DF WLPRD02576052> <AD12140>
		 */
		from.append(" 			, a.care_oprtnty_msr_dim_key ");
		from.append(" 			, a.rule_id ");
		from.append(" 			, c.pgm_dim_key ");
		from.append(" 			, c.msrmnt_prd_strt_dt ");
		from.append(" 			, b.scrcrd_defn_id ");
		from.append(" 			, c.scrcrd_msr_hrchy_dim_key ");
		from.append(" 		from msr_dim as a ");
		from.append(" 			join scrcrd_msr_hrchy_dim b on a.msr_dim_key = b.msr_dim_key ");
		from.append(" 				and a.msr_type_cd = ? ");
		from.append(" 			inner join scrcrd_pgm_msr_hrchy_fact as c on b.scrcrd_msr_hrchy_dim_key = c.scrcrd_msr_hrchy_dim_key ");
		from.append(" 				and b.cmpst_type_desc = ? ");
		from.append(" 		where c.mnth_id = ( ");
		from.append(" 			select ");
		from.append(" 				max(ipgsf.mnth_id) ");
		from.append(" 			from imprv_prov_grp_smry_fact ipgsf ");
		from.append(" 				inner join ");
		from.append(" 					(select ");
		from.append(" 						pgm_dim_key ");
		from.append(" 						, msrmnt_prd_strt_dt ");
		from.append(" 					from scrcrd_pgm_msr_hrchy_fact ");
		from.append(" 							where ");
		from.append(" 								pgm_dim_key = (select pgm_dim_key from pgm_dim where pgm_id = ? )");
		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
			from.append(" and MSRMNT_PRD_STRT_DT=? ");
		}

		from.append(" 					group by ");
		from.append(" 						pgm_dim_key ");
		from.append(" 						, msrmnt_prd_strt_dt ");
		from.append(" 				) sc_pgm ");
		from.append(" 				on ipgsf.pgm_dim_key = sc_pgm.pgm_dim_key ");
		from.append(" 					and ipgsf.msrmnt_prd_strt_dt = sc_pgm.msrmnt_prd_strt_dt ");
		from.append(" 		) ");
		from.append(" 		group by ");
		from.append(" 			a.msr_dim_key ");
		from.append(" 			, a.msr_id ");
		/**
		 * Picking up CARE_OPRTNTY_MSR_DIM_KEY from QLTY, thus adding it in group by
		 * Based on suggestions by Data team, dated 05-May-16 to fix defect WLPRD02576052
		 * Release 1.9 <DF WLPRD02576052> <AD12140>
		 */
		from.append(" 			, a.care_oprtnty_msr_dim_key ");
		from.append(" 			, a.rule_id ");
		from.append(" 			, c.pgm_dim_key ");
		from.append(" 			, c.msrmnt_prd_strt_dt ");
		from.append(" 			, b.scrcrd_defn_id ");
		from.append(" 			, c.scrcrd_msr_hrchy_dim_key ");
		from.append(" 		) as qlty ");
		from.append(" 		inner join ( ");
		from.append(" 			select ");
		from.append(" 				a.msr_dim_key ");
		from.append(" 				, a.msr_dsply_nm ");
		from.append(" 				, a.care_oprtnty_msr_dim_key ");
		from.append(" 				, a.msr_id ");
		from.append(" 				, a.rule_id ");
		from.append(" 				, b.cmpst_defn_id ");
		from.append(" 				, c.pgm_dim_key ");
		from.append(" 				, c.msrmnt_prd_strt_dt ");
		from.append(" 				, b.scrcrd_defn_id ");
		from.append(" 				, c.scrcrd_msr_hrchy_dim_key ");
		from.append(" 			from msr_dim as a ");
		from.append(" 				join scrcrd_msr_hrchy_dim b on a.msr_dim_key = b.msr_dim_key ");
		from.append(" 					and a.msr_type_cd = ? ");
		from.append(" 				inner join scrcrd_pgm_msr_hrchy_fact as c on b.scrcrd_msr_hrchy_dim_key = c.scrcrd_msr_hrchy_dim_key ");
		from.append(" 					and b.cmpst_type_desc = ? ");
		from.append(" 				inner join pgm_dim pgm on c.pgm_dim_key = pgm.pgm_dim_key ");
		from.append(" 			where ");
		from.append(" 				b.cmpst_defn_id = ? ");
		from.append(" 				and pgm.pgm_id = ? ");
		from.append(" 				and c.mnth_id = ( ");
		from.append(" 					select max(ipgsf.mnth_id) ");
		from.append(" 					from imprv_prov_grp_smry_fact ipgsf ");
		from.append(" 						inner join ");
		from.append(" 							(select ");
		from.append(" 								pgm_dim_key ");
		from.append(" 								, msrmnt_prd_strt_dt ");
		from.append(" 							from scrcrd_pgm_msr_hrchy_fact ");
		from.append(" 							where ");
		from.append(" 										pgm_dim_key = (select pgm_dim_key from pgm_dim where pgm_id= ? ) ");
		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
			from.append(" and MSRMNT_PRD_STRT_DT=? ");
		}

		from.append(" 							group by ");
		from.append(" 								pgm_dim_key ");
		from.append(" 								, msrmnt_prd_strt_dt ");
		from.append(" 						) sc_pgm ");
		from.append(" 						on ipgsf.pgm_dim_key = sc_pgm.pgm_dim_key ");
		from.append(" 							and ipgsf.msrmnt_prd_strt_dt = sc_pgm.msrmnt_prd_strt_dt ");
		from.append(" 				) ");
		from.append(" 			group by ");
		from.append(" 				a.msr_dim_key ");
		from.append(" 				, a.msr_dsply_nm ");
		from.append(" 				, a.care_oprtnty_msr_dim_key ");
		from.append(" 				, a.msr_id ");
		from.append(" 				, a.rule_id ");
		from.append(" 				, b.cmpst_defn_id ");
		from.append(" 				, c.pgm_dim_key ");
		from.append(" 				, c.msrmnt_prd_strt_dt ");
		from.append(" 				, b.scrcrd_defn_id ");
		from.append(" 				, c.scrcrd_msr_hrchy_dim_key ");
		from.append(" 		) as imprv ");
		from.append(" 		on qlty.rule_id = imprv.rule_id ");
		from.append(" 			and imprv.scrcrd_defn_id = qlty.scrcrd_defn_id ");
		from.append(" 			and qlty.msrmnt_prd_strt_dt = imprv.msrmnt_prd_strt_dt ");
		from.append(" 			and qlty.pgm_dim_key = imprv.pgm_dim_key ");
		from.append(" 	group by ");
		from.append(" 		qlty.msr_dim_key ");
		from.append(" 		, imprv.msr_dsply_nm ");
		/**
		 * Picking up CARE_OPRTNTY_MSR_DIM_KEY from QLTY, thus changing the group by
		 * Based on suggestions by Data team, dated 05-May-16 to fix defect WLPRD02576052
		 * Release 1.9 <DF WLPRD02576052> <AD12140>
		 */
		from.append(" 		, qlty.care_oprtnty_msr_dim_key ");
		from.append(" 		, imprv.msr_dim_key ");
		from.append(" 		, imprv.msr_id ");
		from.append(" 		, qlty.scrcrd_msr_hrchy_dim_key ");
		from.append(" 		, imprv.cmpst_defn_id ");
		from.append(" 		, qlty.msrmnt_prd_strt_dt ");
		from.append(" 		, imprv.pgm_dim_key ");
		from.append(" 	) md_q ");
		from.append(" 	on  (cf.scrcrd_msr_hrchy_dim_key = md_q.scrcrd_msr_hrchy_dim_key ");
		from.append(" 		and md_q.cmpst_defn_id = ? ");
		from.append(" 		and cf.msr_dim_key = md_q.qlty_msr_dim_key ");
		from.append(" 		and cf.msrmnt_prd_strt_dt = md_q.msrmnt_prd_strt_dt) ");

		return from.toString();
	}

	protected List<Patient> convertSelectedRowsToObjects(ResultSet rs, GetDrillDownRequest request, List<String> columnsForExport) throws Exception {
		List<Patient> list = new ArrayList<Patient>();
		String memberRiskRating = Constants.DASHES;
		String memberHomePlan;
		BigDecimal memRiskRating = BigDecimal.ZERO;

		while (rs.next()) {
			Patient item = new Patient();



			item.setProvGrpId(rs.getString("prov_grp_id"));
			item.setProvGrpDimKey(rs.getLong("prov_grp_dim_key"));
			item.setProvOrgDimKey(rs.getLong("prov_org_dim_key"));
			item.setIpDimKey(rs.getLong("ip_dim_key"));
			item.setProviderId(rs.getLong("prov_grp_hrchy_dim_key")); // instead of ip.ip_dim_key
			
			//PCMSP-13760
			/*item.setAttributedPhysicianName(
					//					added to populate the provider name using first last and type code -- Sumit
					StringUtil.buildProviderName(rs.getString("ip_last_nm"), rs.getString("ip_frst_nm"), rs.getString("ip_type_cd")));*/
			
			if (!Constants.STAR.equalsIgnoreCase(rs.getString("ip_last_nm")) && !Constants.STAR.equalsIgnoreCase(rs.getString("ip_frst_nm"))) {
				item.setAttributedPhysicianName(rs.getString("ip_last_nm") + ", " + rs.getString("ip_frst_nm"));
			}
			else if (!Constants.STAR.equalsIgnoreCase(rs.getString("ip_last_nm"))) {
				item.setAttributedPhysicianName(rs.getString("ip_last_nm"));
			}
			else {
				item.setAttributedPhysicianName(Constants.UNK);
			}
			//PCMSP-13760 - ends
			
			item.setOrganizationName(rs.getString("prov_org_full_nm"));
			item.setOrgTin(rs.getString("org_tin"));

			item.setMemberId(rs.getString("hc_id"));
			item.setMemberAge(rs.getShort("age_nbr"));
			item.setMemberDOB(DateUtil.formatDateToMMDDYYYY("yyyy-MM-dd",
				"M/d/yyyy", rs.getString("brth_dt")));

			//Readmission
			if (null != request.getMeasureName() && request.getMeasureName().equals(Constants.RAR)) {
				item.setTotalIndexAdmissions(rs.getString("indx_readmsn_cnt"));
				item.setTotalNumberOfReadmissions(rs.getString("totl_readmsn_cnt"));
			}
			//AD88636	
			// 170987: Referrals require first/last name to be set to populate the pop up
			//			if (isExport()) {
			item.setMemberLastName(
				StringUtil.getValueOrDashes(rs.getString("last_nm")));
			item.setMemberFirstName(
				StringUtil.getValueOrDashes(rs.getString("frst_nm")));
			//			}else
			//			{
			item.setMemberFullName(
				StringUtil.buildFullName(rs.getString("frst_nm"), rs.getString("last_nm")));
			//			}
			item.setMemberGender(rs.getString("gndr_cd"));

			if (isExport()) {
				item.setMbrAdrsCity(rs.getString("mbr_City_Nm").trim());
				item.setMbrAdrsState(rs.getString("mbr_st_cd").trim());
				item.setMbrAdrsStreet(rs.getString("mbr_adrs_txt").trim());
				item.setMbrAdrsZipCd(rs.getString("mbr_zip_cd").trim());

				item.setMbrAdrsCity(!item.getMbrAdrsCity().equals("*") ? item
					.getMbrAdrsCity() : Constants.DASHES);
				item.setMbrAdrsState(!item.getMbrAdrsState().equals("*") ? item
					.getMbrAdrsState() : Constants.DASHES);
				item.setMbrAdrsStreet(!item.getMbrAdrsStreet().equals("*") ? item
					.getMbrAdrsStreet() : Constants.DASHES);
				item.setMbrAdrsZipCd(!item.getMbrAdrsZipCd().equals("*") ? item
					.getMbrAdrsZipCd() : Constants.DASHES);

				item.setMemberFullAddress(StringUtil.appendAddress(
					item.getMbrAdrsStreet(), item.getMbrAdrsCity(),
					item.getMbrAdrsState(), item.getMbrAdrsZipCd()));
			}
			item.setMemberPhoneNumber(StringUtil.buildPhoneNumber(rs.getString("phone_nbr")));
			memberRiskRating = rs.getString("prsptv_wgtd_risk_nbr");
			if (!Constants.DASHES.equalsIgnoreCase(StringUtil.getValueOrDashes(memberRiskRating)) && rs.getBigDecimal("prsptv_wgtd_risk_nbr").compareTo(BigDecimal.ZERO) > 0) {
				memRiskRating = new BigDecimal(memberRiskRating).setScale(2, BigDecimal.ROUND_HALF_UP);
				item.setMemberRiskRating(memRiskRating.toString());
			}
			else {
				item.setMemberRiskRating(Constants.DASHES);
			}
			item.setMemberRiskRatingInd(StringUtil.buildMemberRiskRatingInd(rs.getBigDecimal("prsptv_wgtd_risk_chng_pct"))); // note that the column is prsptv_wgtd_risk_chng_pct, but the calculated field is MemberRiskRatingInd
			item.setMemberKey(rs.getLong("mstr_cnsmr_dim_key"));
			if (null == request.getMeasureName()) {
				item.setMeasuresNonCompliantScorecard(rs.getInt("non_adhrnc_qlty_msr_nbr")); // selected column used to be called msrs_non_cmplnt_scrcd
			}

			// UI prefers 1/0
			item.setNewPatientInd(StringUtil.convertIndicator(rs.getString("new_atrbd_mbr_ind_cd")));
			item.setInpatientInd(StringUtil.convertIndicator(rs.getString("inpat_authrzn_ind_cd")));
			item.setHotspotterChronicInd(StringUtil.convertIndicator(rs.getString("hot_spotr_chrnc_ind_cd")));

			//AF00030 made changes for PCMSP-1038

			item.setHighRiskRxInd(null != rs.getString("high_risk_ind_cd") && (("E".equalsIgnoreCase(rs.getString("high_risk_ind_cd"))) || ("P".equalsIgnoreCase(rs.getString("high_risk_ind_cd"))) 
					|| ("B".equalsIgnoreCase(rs.getString("high_risk_ind_cd"))) || ("Y".equalsIgnoreCase(rs.getString("phrmcy_hlth_srvcs_ind")))) ? 1 : 0);
			item.setHighRiskRxIndCd(rs.getString("high_risk_ind_cd"));

			item.setHotspotterReadmitInd(StringUtil.convertIndicator(rs.getString("hot_spotr_readmsn_ind_cd")));

			item.setHotspotterChronicBhInd(StringUtil.convertIndicatorForBH(rs.getString("hot_spotr_chrnc_ind_cd")));
			item.setHotspotterChronicBhNewToViewInd(StringUtil.convertIndicatorForBhNewToView(rs.getString("hot_spotr_chrnc_ind_cd")));
			// export needs more data than the UI
			if (isExport()) {
				item.setProviderNPI(rs.getString("ip_npi"));

				//				AP22613
				if (columnsForExport.contains("Attributed Provider")) {
					if (null != rs.getString("IP_SPCLTY_NM") && !rs.getString("IP_SPCLTY_NM").trim().equals("*"))
						item.setProvSpcltyDefn(rs.getString("IP_SPCLTY_NM"));
					if (rs.getString("ip_adrs_txt") != null && !rs.getString("ip_adrs_txt").trim().equals("*"))
					{
						item.setProviderStreet(rs.getString("ip_adrs_txt"));
					}
					else {
						item.setProviderStreet(Constants.DASHES);
					}
					if (rs.getString("ip_city_nm") != null && !rs.getString("ip_city_nm").trim().equals("*"))
					{
						item.setProviderCity(rs.getString("ip_city_nm"));
					}
					else {
						item.setProviderCity(Constants.DASHES);
					}
					if (rs.getString("ip_st_cd") != null && !rs.getString("ip_st_cd").trim().equals("*"))
					{
						item.setProviderState(rs.getString("ip_st_cd"));
					}
					else {
						item.setProviderState(Constants.DASHES);
					}
					if (rs.getString("ip_zip_cd") != null && !rs.getString("ip_zip_cd").trim().equals("*"))
					{
						item.setProviderZipCode(rs.getString("ip_zip_cd"));
					}
					else {
						item.setProviderZipCode(Constants.DASHES);
					}
				}

				item.setNewPatientYN(StringUtil.convertIndicatorForExport(rs.getString("new_atrbd_mbr_ind_cd")));
				item.setInpatientYN(StringUtil.convertIndicatorForExport(rs.getString("inpat_authrzn_ind_cd")));
				item.setHotspotterChronicYN(StringUtil.convertIndicatorForExport(rs.getString("hot_spotr_chrnc_ind_cd")));
				item.setHotspotterReadmitYN(StringUtil.convertIndicatorForExport(rs.getString("hot_spotr_readmsn_ind_cd")));
				/** 57008 CHRONIC_CARE_GAP changes| ad87338 | START */
				//AF00030 changes included for PCMSP-1042
				prepareChronicRiskForExportReFactored(rs, columnsForExport, item);
				/** 57008 CHRONIC_CARE_GAP changes| ad87338 | END */
				if (columnsForExport.contains(Constants.MEASURES)) {
					EligibleMeasures measures = new EligibleMeasures();
					measures.setCareOppsDsplyNm(getString(rs, "msr_dsply_nm"));
					measures.setMeasureStatus(StringUtil.convertMeasureStatus(rs.getString("msr_nmrtr_nbr")));
					measures.setCareOppsPrevDt(getDate(rs, "last_cmplnc_dt"));
					measures.setClinicalDueDt(getDate(rs, "next_clncl_due_dt"));
					measures.setCareOppsStatus(StringUtil.convertCareOppsStatus(rs.getString("care_oprtnty_stts_cd"))); // uses getValueOrDashes()
					item.setEligibleMeasures(measures);
				}

				/*
				 * Earlier : CM/DM not applicable for FPCC
				 * Changing it back after updated requirement to include CM/DM for FPCC
				 * Removing the if clause
				 */
				if (columnsForExport.contains(Constants.CMDMPrograms)) {

					item.setCmdmProgram(QueryConstants.buildCmDmProgramsFromResultSet(rs));
				}

				if (columnsForExport.contains("Eligibility")) {
					item.setCrprtPlanCmpnyNm(!rs.getString("crprt_plan_cmpny_nm").equalsIgnoreCase("*") ? rs.getString("crprt_plan_cmpny_nm") : Constants.DASHES);
					item.setHomePlanNm(!rs.getString("home_plan_nm").equalsIgnoreCase("*") ? rs.getString("home_plan_nm") : Constants.DASHES);



				}

				if (columnsForExport.contains(Constants.CONDITION_DETAILS)) {
					if (null != rs.getString("disease_conditions") && !"".equalsIgnoreCase(rs.getString("disease_conditions").trim()))
						item.setConditionDetails(rs.getString("disease_conditions"));
					else
						item.setConditionDetails(Constants.DASHES);
				}

				if (columnsForExport.contains(Constants.VISIT_DETAIL)) {
					item.setErVisitDetailsForExport(QueryConstants.buildAvdbleErVisitsFromResultset(rs));
				}

				if (columnsForExport.contains(Constants.ADMIT_DETAIL)) {
					item.setAmbltrySenstvAdmtsForExport(QueryConstants.buildASAdmitsFromResultset(rs));
				}

				if (columnsForExport.contains(Constants.FILL_DETAIL)) {
					item.setGdrFillDetailsForExport(QueryConstants.buildGdrFillDetailsFromResultset(rs));
				}

			}
			/** 58594, 66200 PSL Desc Changes | ad87338 | START */
			item.setLineOfBusiness(StringUtil.getValueOrDashes(rs.getString("lob_desc")));
			item.setProduct(StringUtil.getValueOrDashes(rs.getString("psl_desc")));
			/** 58594 PSL Desc Changes | ad87338 | END */
			//			item.setHlthPgmCnt(rs.getShort("hlth_pgm_cnt")); // Selecting the fields separately so we can calculate the total based on Action Center suppression
			item.setHlthPgmCnt(String.valueOf(StringUtil.calculateHlthPgmCnt(rs.getInt("cm_pgm_cnt"), rs.getInt("dm_pgm_cnt"), rs.getInt("sent_referral_count"),
				rs.getInt("rcvd_referral_count"), item.getProvGrpId(), request.getGroupsWithActionCenterSuppressed())));
			item.setIhmIndCd(rs.getString("ihm_ind_cd"));
			item.setActiveProgramsInd(Integer.parseInt(item.getHlthPgmCnt()) > 0 || "Y".equalsIgnoreCase(item.getIhmIndCd()));
			item.setTotalNumberOfConditions(rs.getString("dseas_cndtn_cnt"));
			/** 57008 CHRONIC_CARE_GAP changes| ad87338 | START */
			String hotSpotterGapScore = String.valueOf(rs.getInt("hot_spotr_gap_scor_nbr"));
			if (hotSpotterGapScore != null && !hotSpotterGapScore.equals(Constants.MINUS_ONE)) {
				item.setHotspotterGapScore(hotSpotterGapScore);
				item.setHasHotspotterGapScoreInd(Boolean.TRUE);
				String hotSptrGapScoreTrndInd = rs.getString("hot_spotr_gap_scor_trnd_ind_cd");
				if (hotSptrGapScoreTrndInd != null && !hotSptrGapScoreTrndInd.trim().equals("*")
					&& !"N".equalsIgnoreCase(hotSptrGapScoreTrndInd.trim())) {
					item.setHotspotterGapScoreInd(hotSptrGapScoreTrndInd.equals("U") ? 1 : 0);
				}
			}
			else {
				item.setHotspotterGapScore(Constants.DASHES);
			}
			/** 57008 CHRONIC_CARE_GAP changes| ad87338 | END */
			if (null != request.getMeasureName() && request.getMeasureName().equals(Constants.LIER)) {
				item.setAvoidableErVisitsCnt(rs.getShort("low_intnsty_er_vst_cnt"));
				/*
				 * Hard coding right now - as per discussion; data is not available as of now. 
				 * For the iteration purposes, hard coding the JSON parameter to 100 to reflect on the UI
				 * 04th January 2016 - Following the RTM Update, Cost of Visits not to be shown on Patient View, hence commenting the following setter
				 */
				//item.setCostOfAvoidableErVisits((isExport() ? "$" : "") + "100");
			}
			if (null != request.getMeasureName() && request.getMeasureName().equals(Constants.ASA)) {
				item.setTotalNumberOfAmbulatoryAdmits(rs.getShort("ambltry_snsitv_vst_cnt"));
				/*
				 * Hard coding right now - as per discussion; data is not available as of now. 
				 * For the iteration purposes, hard coding the JSON parameter to 100 to reflect on the UI
				 * 04th January 2016 - Following the RTM Update, Cost of Admits not to be shown on Patient View, hence commenting the following setter
				 */
				//item.setCostOfAmbulatoryAdmits((isExport() ? "$" : "") + "100");
			}
			if (null != request.getMeasureName() && request.getMeasureName().equals(Constants.GDR_AGG)) {
				item.setTotalNumberOfBrandRxDispensed(rs.getShort("GDR_CNT"));
				/*
				 * Hard coding right now - as per discussion; data is not available as of now. 
				 * For the iteration purposes, hard coding the JSON parameter to 100 to reflect on the UI
				 */
				/*
				 * Descoped from R1.7 - 12/9/2015 
				 */
				//item.setCostOfBrandDrugs((isExport() ? "$" : "") + "100");
			}
			if (null != request.getMeasureName() && request.getMeasureName().equals(Constants.GDR)) {
				item.setTotalNumberOfBrandRxDispensed(rs.getShort("gdr_cnt"));

			}
			//PCMSP-8461-8463 : Starts 2
			if (null != request.getMeasureName() && request.getMeasureName().equals(Constants.FRMLY_AGG)) {
				item.setTotalNonFormularyBrandRxDispensed(rs.getString("GDR_CNT"));				
			}
			if (null != request.getMeasureName() && request.getMeasureName().equals(Constants.FRMLY)) {
				item.setTotalNonFormularyBrandRxDispensed(rs.getString("gdr_cnt"));

			}
			//PCMSP-8461-8463 : Ends 2
			/*//For export only
			if(isExport() && ((null != request.getMeasureName() && request.getMeasureName().equals(Constants.LIER)) || (null != request.getMeasureName() && request.getMeasureName().equals(Constants.RAR)) ||
					(null != request.getMeasureName() && request.getMeasureName().equals(Constants.ASA)))){
				if(null != rs.getString("CNDTN_CTGRY_NM"))
					item.setCndtnCtgryNm(rs.getString("CNDTN_CTGRY_NM"));
			}*/
			memberHomePlan =
				(!rs.getString("crprt_plan_cmpny_nm").equalsIgnoreCase("*") ? rs.getString("crprt_plan_cmpny_nm") : Constants.DASHES) + " - "
					+ (!rs.getString("home_plan_nm").equalsIgnoreCase("*") ? rs.getString("home_plan_nm") : Constants.DASHES);
			item.setMemberHomePlan((memberHomePlan).equalsIgnoreCase("--- - ---") ? Constants.DASHES : memberHomePlan);
			item.setAttributionStatus(rs.getString("atrbn_stts_cd"));

			// User Story 52549

			/*boolean isSuppressed = false;
			String precedenceChckString = Constants.DASHES;
			if (request.getPrecedenceChckString() != null){
				precedenceChckString = request.getPrecedenceChckString();
			}

			if ((request.getAcMenuLinksGrpInd() != null && request.getAcMenuLinksGrpInd().contains(request.getProvGrpId().toString()))) {
				isSuppressed = true;
			}
			if ((request.getActionCenterLobNm() != null && request.getActionCenterLobNm().contains(request.getLobIds().toString()))) {
				isSuppressed = true;
			}
			if (request.getActionCenterMarket() != null
					&& request.getActionCenterMarket().startsWith(
							request.getProvGrpId().substring(0, 2))
					&& !precedenceChckString.contains(request.getProvGrpId())) {
				isSuppressed = true;
			}
			
			if (!isSuppressed) {
				String ooa_ind_cd = rs.getString("ooa_ind_cd");
			if(ooa_ind_cd!=null){
				if (ooa_ind_cd.equals("N")) {
					item.getActions().add(ReferralBeanConstants.ACTIONOOIND);
				
				    }
				}
			String has_rfrl = rs.getString("has_referrals");
			if(has_rfrl!=null){
				if(has_rfrl.equalsIgnoreCase("1")) {
					item.getActions().add(ReferralBeanConstants.ACTIONRFRLCNT);
				}
			  }
			}*/

			// RA - Action menu Suppression
			boolean isACMenuSuppressed = false;
			boolean isACRecRefSuppressed = false;
			List<String> acSuppressedLOBs = null;
			List<String> suppressedPgm = null;
			// AC Menu - Suppression
			if (request.getAcSuppressedLOBs() != null) {
				acSuppressedLOBs = Arrays.asList(request.getAcSuppressedLOBs().split(Constants.COMMA));
			}
			
			if (request.getSuppressedPGM() != null) {
				suppressedPgm = Arrays.asList(request.getSuppressedPGM().split(Constants.COMMA));
			}
			if ((null != request.getProvGrpIdSentRfrls()
				&& !request.getProvGrpIdSentRfrls().contains(null != rs.getString("prov_grp_id") ? rs.getString("prov_grp_id") : Constants.BLANK)) //Group/Market level
				|| (null != acSuppressedLOBs
				&& acSuppressedLOBs.contains(null != rs.getString("lob_ctgry_nm") ? rs.getString("lob_ctgry_nm") : Constants.BLANK))
				|| (null != suppressedPgm && suppressedPgm.contains(null != rs.getString("PGM_ID") ? rs.getString("PGM_ID") : Constants.BLANK))) { //LOB level
				isACMenuSuppressed = true;
			}

			// AC Received Referrals - Suppression
			if (request.getAcRecRefSuppressedLOBs() != null) {
				acSuppressedLOBs = Arrays.asList(request.getAcRecRefSuppressedLOBs().split(Constants.COMMA));
			}
			if (request.getAceRecRefSuppressedPgms() != null) {
				suppressedPgm = Arrays.asList(request.getAceRecRefSuppressedPgms().split(Constants.COMMA));
			}
			if ((null != request.getProvGrpIdRcvdRfrls()
				&& !request.getProvGrpIdRcvdRfrls().contains(null != rs.getString("prov_grp_id") ? rs.getString("prov_grp_id") : Constants.BLANK)) //Group/Market level
				|| (null != acSuppressedLOBs
				&& acSuppressedLOBs.contains(null != rs.getString("lob_ctgry_nm") ? rs.getString("lob_ctgry_nm") : Constants.BLANK))
				|| (null != suppressedPgm && suppressedPgm.contains(null != rs.getString("PGM_ID") ? rs.getString("PGM_ID") : Constants.BLANK))) { //LOB level
				isACRecRefSuppressed = true;
			}

			if ("Y".equalsIgnoreCase(request.getShowAll()) || !isACMenuSuppressed) {
				String ooa_ind_cd = rs.getString("ooa_ind_cd");
				if (ooa_ind_cd != null) {
					if (Constants.N.equalsIgnoreCase(ooa_ind_cd)) {
						item.getActions().add(ReferralBeanConstants.ACTIONOOIND);
					}
				}
				String has_rfrl = rs.getString("has_referrals");
				if (has_rfrl != null) {
					if (!isACRecRefSuppressed && "1".equalsIgnoreCase(has_rfrl)) {
						item.getActions().add(ReferralBeanConstants.ACTIONRFRLCNT);
					}
				}
			}

			item.setLprInd(!Constants.STAR.equals(rs.getString("lpr_ind_cd")) ? rs.getString("lpr_ind_cd") : "N");

			if (!"Y".equalsIgnoreCase(request.getShowAll())) {

				List<String> lprSuppressedLOBs = null;
				if (request.getLprSuppressedLOBs() != null) {
					lprSuppressedLOBs = Arrays.asList(request.getLprSuppressedLOBs().split(","));
				}
				List<String> lprSuppressedPGMs = null;
				if (request.getLprSuppressedPGMs() != null) {
					lprSuppressedPGMs = Arrays.asList(request.getLprSuppressedPGMs().split(","));
				}

				if ((request.getLprActiveProviders() != null && !request.getLprActiveProviders().contains(rs.getString("prov_grp_id")))
					|| (lprSuppressedLOBs != null && lprSuppressedLOBs.contains(rs.getString("lob_ctgry_nm")))
					|| (lprSuppressedPGMs != null && lprSuppressedPGMs.contains(rs.getString("pgm_id")))) {
					item.setLprInd("N");
				}
			}
			/*8463 STARTS 1*/
			if(isExport() && null != request.getMeasureName() && (request.getMeasureName().equals(Constants.FRMLY) || request.getMeasureName().equals(Constants.FRMLY_AGG)) ){
				//1. FILL_DATE
				if (rs.getDate("RX_FILLED_DT") != null) {
					item.setFillDate(getDate(rs, "RX_FILLED_DT"));
				}
				//2. DRUG_NAME
				if (rs.getString("LBL_NM") != null) {
					item.setDrugName(getString(rs, "LBL_NM").replaceAll("\\s+", " "));
				}
				//3. THERAPEUTIC_CLASS
				if (rs.getString("CD_VAL_NM") != null) {
					item.setTherapeuticClass(getString(rs, "CD_VAL_NM"));
				}
				//4. DRUG_CLASS
				if (rs.getString("DRUG_CLS_NM") != null) {
					item.setDrugClass(getString(rs, "DRUG_CLS_NM"));
				}
				//5. DAYS_SUPPLY
				if (rs.getBigDecimal("DAYS_SPLY_NBR") != null) {
					Integer ds = rs.getBigDecimal("DAYS_SPLY_NBR").intValue();
					item.setDaysSupply(ds.toString());
				}
				
				//6. PRESCRIBING PROVIDER 1
				String firstName = getString(rs, "prscrbr_frst_nm");
				String lastName = getString(rs, "prscrbr_last_nm");
				
				if (firstName == null) {
					firstName = "*";
				}
				if (lastName == null) {
					lastName = "*";
				}
				
				//6. PRESCRIBING PROVIDER 2
				if (Constants.UNK.equalsIgnoreCase(firstName)&& Constants.UNK.equalsIgnoreCase(lastName)){
				  item.setPrescribingProviderName(Constants.UNK);
                }else  if (!Constants.STAR.equalsIgnoreCase(lastName) && !Constants.STAR.equalsIgnoreCase(firstName)) {
					item.setPrescribingProviderName(lastName + ", " + firstName);
				}
				else if (!Constants.STAR.equalsIgnoreCase(lastName)) {
					item.setPrescribingProviderName(lastName);
				}
				else {
					item.setPrescribingProviderName(Constants.UNK);
				}
				
				//7. PATIENT COST SHARE
				if (rs.getString("APRVD_CPAY_AMT") != null) {
					item.setPatientCost(StringUtil.convertStringToDecimalCurrency(rs.getString("APRVD_CPAY_AMT")));
				}
				if (rs.getString("DSPNSD_BRND_GNRC_IND") != null) {
					item.setGenericInd(rs.getString("DSPNSD_BRND_GNRC_IND").trim().equalsIgnoreCase("G") ? 1 : 0);
				}

				
				//8. FORMULARY NAME				
				if (rs.getString("FRMLRY_NM") != null) {
					item.setFormularyName(getString(rs, "FRMLRY_NM"));
				}
				
				//9. HOT SPOTTER GAP SCORE 
				hotSpotterGapScore = String.valueOf(rs.getInt("hot_spotr_gap_scor_nbr"));
				if (hotSpotterGapScore != null && !hotSpotterGapScore.equals(Constants.MINUS_ONE)) {
					item.setHotspotterGapScore(hotSpotterGapScore);
					item.setHotSpotterGapScore(hotSpotterGapScore);
					item.setHasHotspotterGapScoreInd(Boolean.TRUE);
					item.setHasHotSpotterGapScoreInd(Boolean.TRUE);
					String hotSptrGapScoreTrndInd = rs.getString("hot_spotr_gap_scor_trnd_ind_cd");
					if (hotSptrGapScoreTrndInd != null && !hotSptrGapScoreTrndInd.trim().equals("*")
						&& !"N".equalsIgnoreCase(hotSptrGapScoreTrndInd.trim())) {
						item.setHotspotterGapScoreInd(hotSptrGapScoreTrndInd.equals("U") ? 1 : 0);
						item.setHotSpotterGapScoreInd(hotSptrGapScoreTrndInd.equals("U") ? 1 : 0);
					}
				}
				else {
					item.setHotspotterGapScore(Constants.DASHES);
				}
				
				//10. TOTAL NON FORMULARY BRAND DRUGS DISPENSED
				if (null != request.getMeasureName() && (request.getMeasureName().equals(Constants.FRMLY) || request.getMeasureName().equals(Constants.FRMLY))) {
					item.setTotalNonFormularyBrandRxDispensed(rs.getString("gdr_cnt"));
				}
				
				//11. MEMBER AGE
				if (rs.getString("age_nbr") != null) {
					item.setMembersAge(getString(rs, "age_nbr"));
				}
				
				//12.HOME PLAN
				if(rs.getString("home_plan_nm")!=null){
					item.setMemberHomePlan(!rs.getString("home_plan_nm").equalsIgnoreCase("*") ? rs.getString("home_plan_nm") : Constants.DASHES);
					item.setHomePlanNm(!rs.getString("home_plan_nm").equalsIgnoreCase("*") ? rs.getString("home_plan_nm") : Constants.DASHES);
				}
				
			}
			/*8463 ENDS 1*/
			list.add(item);

			setRowCount(rs.getInt("row_cnt"));
		}

		return list;
	}

	/**
	 * 
	 * @param column name from UI, sort direction
	 * @return column name for DB, sort direction (in case of member full name,
	 *         direction needs to be applied to both first/last name columns)
	 */
	protected String getSortClause(GetDrillDownRequest request) {
		String query = "";
		
		HashMap<String, String> map = new HashMap<String, String>();

		for (QuerySort sort : request.getSort()) {
			
			String direction = sort.getDirection();
			String column = sort.getProperty();

			map.put("measuresNonCompliantScorecard"
				, ", non_adhrnc_qlty_msr_nbr " + direction); // used to be: count(cf.msr_nmrtr_nbr); after that, was: count(distinct cf.msr_dim_key)

			map.put("memberFullName"
				, ", upper(psf.last_nm) " + direction + ", upper(psf.frst_nm) " + direction);

			map.put("attributedPhysicianName"
				, ", upper(psf.ip_last_nm) " + direction + ", upper(psf.ip_frst_nm) " + direction);

			map.put("organizationName"
				, ", upper(psf.prov_org_full_nm) " + direction);

			map.put("memberRiskRating"
				, ", case when psf.prsptv_wgtd_risk_nbr<0 then 1 else 0 end, "
					+ " psf.prsptv_wgtd_risk_nbr  " + direction);

			map.put("totalNumberOfConditions"
				, ", psf.dseas_cndtn_cnt " + direction);

			map.put("avoidableErVisitsCnt"
				, ", cf.low_intnsty_er_vst_cnt " + direction);

			map.put("totalNumberOfAmbulatoryAdmits"
				, ", cf.ambltry_snsitv_vst_cnt " + direction);

			map.put("totalNumberOfBrandRxDispensed"
				, ", CX.GDR_CNT " + direction);
			//PCMSP-8461 STARTS 1
			map.put("totalNonFormularyBrandRxDispensed"
					, ", CX.GDR_CNT " + direction);
			//PCMSP-8461 ENDS 1
			map.put("totalNumberOfReadmissions"
				, ", totl_readmsn_cnt " + direction);
			map.put("totalIndexAdmissions"
				, ", indx_readmsn_cnt " + direction);

			map.put("hotspotterGapScore"
				, ", case when psf.hot_spotr_gap_scor_nbr<0 then 1 else 0 end, "
					+ " psf.hot_spotr_gap_scor_nbr " + direction);

			query += " " + map.get(column) + " ";
		}

		query = StringUtils.replaceOnce(query, ",", "");
		return query;
	}

	/**
	 * 
	 * @param column name from UI, sort direction
	 * @return column name for DB, sort direction (in case of member full name,
	 *         direction needs to be applied to both first/last name columns)
	 */
	protected String getSortClauseForQualityExport(GetDrillDownRequest request) {
		String query = "";
		String defaultSort = ", psf.last_nm asc, psf.frst_nm asc ";
		/*
		 * Adding the default sort for the patient hover records for Eligible Measures
		 * As confirmed by SIT - Snehasmita , sort should be on lastCmplncDt for the hover records for a patient
		 */
		defaultSort += ", msr.last_cmplnc_dt ";
		
		HashMap<String, String> map = new HashMap<String, String>();

		for (QuerySort sort : request.getSort()) {
			
			String direction = sort.getDirection();
			String column = sort.getProperty();

			map.put("measuresNonCompliantScorecard"
				, "non_adhrnc_qlty_msr_nbr " + direction + defaultSort); // used to be: count(cf.msr_nmrtr_nbr); after that, was: count(distinct cf.msr_dim_key)

			//For memberFullName, only one additional lastCmplncDt is needed hence, adding it separately 
			map.put("memberFullName"
				, "upper(psf.last_nm) " + direction + ", upper(psf.frst_nm) " + direction + ", msr.last_cmplnc_dt ");

			map.put("attributedPhysicianName"
				, "upper(psf.ip_last_nm) " + direction + ", upper(psf.ip_frst_nm) " + direction + defaultSort);

			map.put("organizationName"
				, "upper(psf.prov_org_full_nm) " + direction + defaultSort);

			map.put("memberRiskRating"
				, "case when psf.prsptv_wgtd_risk_nbr<0 then 1 else 0 end, "
					+ " psf.prsptv_wgtd_risk_nbr  " + direction + defaultSort);

			map.put("totalNumberOfConditions"
				, "psf.dseas_cndtn_cnt " + direction + defaultSort);

			map.put("hotspotterGapScore"
				, " case when psf.hot_spotr_gap_scor_nbr<0 then 1 else 0 end, "
					+ " psf.hot_spotr_gap_scor_nbr " + direction + defaultSort);

			query += " " + map.get(column) + " ";
		}

		return query;
	}

	/**
	 * 
	 * @param column name from UI, sort direction
	 * @return column name for DB, sort direction (in case of member full name,
	 *         direction needs to be applied to both first/last name columns)
	 *         in case of export the default sort will be on patient last name first name
	 */
	protected String getSortClauseForUtilizationExport(GetDrillDownRequest request) {
		String query = "";
		String defaultSort = ", psf.last_nm asc, psf.frst_nm asc ";
		
		HashMap<String, String> map = new HashMap<String, String>();

		for (QuerySort sort : request.getSort()) {
			String direction = sort.getDirection();
			String column = sort.getProperty();

			/*
			 * Enforcing the order of the visit/admit details within a particular patient
			 */
			String hoverSort = "";
			if (request.getMeasureName().equalsIgnoreCase(Constants.LIER))
				hoverSort = ", vsf.vst_strt_dt desc ";
			else if (request.getMeasureName().equalsIgnoreCase(Constants.ASA) || request.getMeasureName().equalsIgnoreCase(Constants.RAR))
				hoverSort = ", vsf.admt_dt desc ";
			else if (request.getMeasureName().contains(Constants.GDR))
				hoverSort = ", gdr.rx_filled_dt desc ";
			else if (request.getMeasureName().contains(Constants.FRMLY))
				hoverSort = ", pop.rx_filled_dt desc ";
			map.put("memberFullName"
				, "upper(psf.last_nm) " + direction + ", upper(psf.frst_nm) " + direction + hoverSort);

			map.put("attributedPhysicianName"
				, "upper(psf.ip_last_nm) " + direction + ", upper(psf.ip_frst_nm) " + direction + defaultSort + hoverSort);

			map.put("organizationName"
				, "upper(psf.prov_org_full_nm) " + direction + defaultSort + hoverSort);

			map.put("memberRiskRating"
				, "case when psf.prsptv_wgtd_risk_nbr<0 then 1 else 0 end, "
					+ " psf.prsptv_wgtd_risk_nbr  " + direction + defaultSort + hoverSort);

			map.put("totalNumberOfConditions"
				, "psf.dseas_cndtn_cnt " + direction + defaultSort + hoverSort);

			map.put("avoidableErVisitsCnt"
				, "cf.low_intnsty_er_vst_cnt " + direction + defaultSort + hoverSort);

			map.put("totalNumberOfAmbulatoryAdmits"
				, "cf.ambltry_snsitv_vst_cnt " + direction + defaultSort + hoverSort);

			map.put("totalNumberOfBrandRxDispensed"
				, "CX.GDR_CNT " + direction + defaultSort + hoverSort);

			map.put("totalNumberOfReadmissions"
				, "totl_readmsn_cnt " + direction + defaultSort + hoverSort);
			map.put("totalIndexAdmissions"
				, "indx_readmsn_cnt " + direction + defaultSort + hoverSort);
			map.put("hotspotterGapScore"
				, " case when psf.hot_spotr_gap_scor_nbr<0 then 1 else 0 end, "
					+ " psf.hot_spotr_gap_scor_nbr " + direction + defaultSort + hoverSort);
			map.put("totalNonFormularyBrandRxDispensed"
				, "CX.GDR_CNT " + direction + defaultSort + hoverSort);
			query += " " + map.get(column) + " ";
		}

		return query;
	}

}
