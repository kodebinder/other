package com.wellpoint.pc2dash.action.scoreCard;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.data.dto.PCMSRequest;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.scorecard.ScorecardOrganizationServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;

public class GetScorecardOrganizationsAction extends Action {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetScorecardOrganizationsAction.class);

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetScorecardOrganizationsResponse result = new GetScorecardOrganizationsResponse();
		GetScorecardOrganizationsRequest request = (GetScorecardOrganizationsRequest) actionRequest;
		ErrorProperties err = ErrorProperties.getInstance();

		List<String> filteredProvGrpList = new ArrayList<String>();
		String provGrpCSVWithGrpIndY = "";
		String provGrpCSVWithGrpIndN = "";

		try {


			Collection<Object> vals = new ArrayList<Object>();

			// preserve dataMap logic
			removeLobPgmPrefixes(request);

			//			PCMSRequest request = new HashMap<String,String>();
			//			//request.put("entId",rqst.getEntitlementId());
			//			request.put("prgmId", request.getProgramId());
			//			request.put("provGrpId", request.getProviderGroupId());
			//			request.put("grpInd", request.getGrpInd());
			//			//request.put("sessionId", request.getSessionId());
			//			request.put("entId", request.getEntitlementId());
			//			request.put("lobDimKeys", JSONUtils.removeFirstOccurenceOfCharsFromJsonString(request.getLobDimKeys(), Constants.LOB_ID_PREFIX));
			//			 //GBD part 2
			//			//request.setCmpId(request.getCmpId());
			//			request.setProvGrpIds(request.getProviderGroupId());
			//			request.put(Constants.USER_ACS_INFO_JSON, request.getUserAcsInfoJson());


			//Kill switch check on Provider groups
			if (null != request) {
				filteredProvGrpList = filterProvGrpsByKillSwitch(request);
			}

			//Financial access check on provider groups
			/*
			 * Changing the check from clinical to financial due to the defect WLPRD02122481
			 */
			if (null != request && null != filteredProvGrpList && filteredProvGrpList.size() > 0) {
				filteredProvGrpList = filterProvGrpsByClincalFinancialInd(request, filteredProvGrpList);
			}

			//Group Ind Y list
			if (null != request && null != filteredProvGrpList && filteredProvGrpList.size() > 0) {
				provGrpCSVWithGrpIndY = prepareProvGrpCSVWithGrpInd(request, filteredProvGrpList, Constants.GRP_IND_Y);
				provGrpCSVWithGrpIndN = prepareProvGrpCSVWithGrpInd(request, filteredProvGrpList, Constants.GRP_IND_N);
			}

			//Group Ind Y list
			if (null != request && null != provGrpCSVWithGrpIndY && !provGrpCSVWithGrpIndY.isEmpty()) {
				request.setProvGrpIds(provGrpCSVWithGrpIndY);
				request.setGrpInd(Constants.GRP_IND_Y);
				vals = getScorecardOrganizations(request);
			}

			//Group Ind N list
			if (null != request && null != provGrpCSVWithGrpIndN && !provGrpCSVWithGrpIndN.isEmpty()) {
				request.setProvGrpIds(provGrpCSVWithGrpIndN);
				request.setGrpInd(Constants.GRP_IND_N);
				Collection<Object> values = getScorecardOrganizations(request);
				if (null != values) {
					vals.addAll(values);
				}
			}
			if (vals == null || (null != vals && vals.isEmpty())) {
				result.setMessage(err.getProperty("successNoData"));
			}
			else {
				result.setMessage(err.getProperty("successful"));
				result.setData(vals);
				result.setTotal(vals.size());
			}

			result.setSuccess(true);

		}
		catch (Exception e) {

			//result.setMessage("Unable to retrieve Scorecard composite  detail.");
			result.setSuccess(false);
			logger.error(e);
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getScorecardOrganizations(PCMSRequest request) throws Exception {

		ScorecardOrganizationServiceImpl dao = new ScorecardOrganizationServiceImpl();
		Collection<?> details = dao.getScorecardOrganizations(request);

		return (Collection<Object>) details;
	}

}
