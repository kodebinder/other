package com.wellpoint.pc2dash.action.inactivePatients;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetInactivePatientsResponse extends ActionResponse {

}
