package com.wellpoint.pc2dash.data.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.costOpportunity.GetLabProviderCountPopupRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.costOpportunity.LabProviderCountPopupBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;

public class LabProviderCountPopupDao extends ServiceImpl {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(LabProviderCountPopupDao.class);

	public List<LabProviderCountPopupBean> getData(GetLabProviderCountPopupRequest request, boolean exportFlag) throws Exception {

		List<LabProviderCountPopupBean> result = new ArrayList<LabProviderCountPopupBean>();
		setRowCount(0);

		StringBuilder query = new StringBuilder()
			.append(" select  iplsmry.PROV_DSPLY_NM,iplsmry.ip_dim_key ")
			.append(" 		from coc_lab_prov_smry iplsmry ")
			.append(" 		join poit_user_scrty_acs pusa on (iplsmry.prov_grp_id = pusa.prov_grp_id ")
			.append(" 			and ")
			.append(" 			case ")
			.append(" 				when   pusa.prov_org_tax_id = '0' ")
			.append(" 				then   iplsmry.prov_org_tax_id ")
			.append(" 				else   pusa.prov_org_tax_id ")
			.append(" 			end = iplsmry.prov_org_tax_id) ")
			.append(" 		where  ")
			.append(" 		pusa.sesn_id = ? ")
			.append(" 		and pusa.enttlmnt_hash_key = ? ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and iplsmry.PROV_GRP_ID in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and iplsmry.PGM_DIM_KEY in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and iplsmry.LOB_DESC in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and iplsmry.IP_DIM_KEY in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and iplsmry.PROV_ORG_DIM_KEY in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getLabName())) {
			query.append(" and iplsmry.LAB_NM in ( ? )");
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getLabTaxId())) {
			query.append(" and iplsmry.lab_tax_id in ( ? )");
				
		}

		if (StringUtil.isNotBlankOrFalse(request.getNetworkStatus())) {
			query.append(" and iplsmry.parg_cd in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getNetworkStatus())
				+ ") ");
		}
		
		//PCMSP-20002
		if (StringUtil.isNotBlankOrFalse(request.getScorecardAnalysisOfDate())) {
			query.append(" and upper(iplsmry.rpt_type_ind) = 'SC' ");
		}else{
			query.append(" and upper(iplsmry.rpt_type_ind) = 'COC' ");
		}

		query.append(" 	group by  iplsmry.PROV_DSPLY_NM,iplsmry.ip_dim_key   ")
			.append(" order by iplsmry.PROV_DSPLY_NM asc ")
			.append(" with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());

			buildPreparedStatement(request, i);

			executeQuery(logger, query.toString());

			result = convertSelectedRowsToObjects(rs, request, exportFlag);

		}
		catch (Exception e) {

			throw new Exception("Unable to get LabProviderCountPopupDao.", e);
		}
		finally {

			close();
		}

		return result;

	}

	private void buildPreparedStatement(GetLabProviderCountPopupRequest request, int i) throws SQLException {

		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}
		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getLabName())) {
			ps.setString(++i, request.getLabName());
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getLabTaxId())) {
			ps.setString(++i, request.getLabTaxId());				
		}

		if (StringUtil.isNotBlankOrFalse(request.getNetworkStatus())) {
			String[] array = request.getNetworkStatus().split(",");
			for (String item : array) {
				ps.setString(++i, item.trim());
			}
		}

	}

	private List<LabProviderCountPopupBean> convertSelectedRowsToObjects(ResultSet rs, GetLabProviderCountPopupRequest request, boolean exportFlag) throws SQLException {

		List<LabProviderCountPopupBean> list = new ArrayList<LabProviderCountPopupBean>();

		while (rs.next()) {

			LabProviderCountPopupBean item = new LabProviderCountPopupBean();

			if (rs.getString("PROV_DSPLY_NM") != null) {
				item.setAttributedPhysicianName(rs.getString("PROV_DSPLY_NM"));
			}
			else {
				item.setAttributedPhysicianName(Constants.DASHES);
			}

			list.add(item);

		}

		return list;
	}


}
