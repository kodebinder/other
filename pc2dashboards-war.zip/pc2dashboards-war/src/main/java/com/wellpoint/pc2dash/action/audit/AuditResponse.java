package com.wellpoint.pc2dash.action.audit;

import com.wellpoint.pc2dash.action.base.ActionResponse;


public class AuditResponse extends ActionResponse {

}
