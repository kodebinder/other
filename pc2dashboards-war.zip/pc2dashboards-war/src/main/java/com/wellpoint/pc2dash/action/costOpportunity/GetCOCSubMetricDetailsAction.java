package com.wellpoint.pc2dash.action.costOpportunity;

import java.util.ArrayList;
import java.util.List;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.dto.costOpportunity.COCRxDrugDetailBean;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.costOpportunity.COCRxDrugDetailsExport;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.costOpportunity.COCSubMetricDetailsServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetCOCSubMetricDetailsAction extends Action {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetCOCSubMetricDetailsAction.class);

	public ActionResponse process(ActionRequest actionRequest) {

		ActionResponse response = new GetCOCSubMetricDetailsResponse();
		GetCOCAverageRxDrugDetailsRequest request = (GetCOCAverageRxDrugDetailsRequest) actionRequest;
		ErrorProperties err = ErrorProperties.getInstance();

		COCSubMetricDetailsServiceImpl service = new COCSubMetricDetailsServiceImpl();
		List<String> filteredProvGrpList = new ArrayList<String>();
		List<COCRxDrugDetailBean> beanData = null;

		try {


			String typeCd = request.getTypeCd();


			removeLobPgmPrefixes(request);
			if (StringUtils.isNotBlank(request.getCmpId())) {
				filteredProvGrpList = filterProvGrpsByKillSwitch(request);
			}


			if (null != filteredProvGrpList && !filteredProvGrpList.isEmpty()) {
				request.setProvGrpIdsWithoutClinicalCheck(StringUtils.join(filteredProvGrpList, ','));
				filteredProvGrpList = filterProvGrpsByClincalFinancialInd(request, filteredProvGrpList);
				request.setProvGrpIds(CollectionUtils.isNotEmpty(filteredProvGrpList) ? StringUtils.join(filteredProvGrpList, ',') : Constants.DASHES);
				request.setGrpInd(Constants.GRP_IND_N);

				CommonQueries cq = new CommonQueries();
				//request.setTapId(request.getMetricViewId());// TO re-use available tap framework.
				request.setSuppression(cq.getActiveSuppressionForSelectComponents(request));
				
				MetaData metaData = new MetaData();
				metaData.setReportingPeriod(cq.getReportingPeriodForCostOpportunity(Constants.AVERAGE_COST_PER_RX));
				metaData.setReportDate(cq.getReportDateForCostOpportunity(Constants.AVERAGE_COST_PER_RX));

				if (null != typeCd && typeCd.equalsIgnoreCase(Constants.COST_PER_RX)) {

					if (StringUtil.isExportDest(request.getDest())) {
		            	request.setReportingPeriod(metaData.getReportingPeriod());
		            	request.setReportDate(metaData.getReportDate());
						COCRxDrugDetailsExport ex = new COCRxDrugDetailsExport(request);
						ExportProcessor.getInstance().submit(ex);
					}
					else {
						beanData = service.getData(request, Constants.BOOL_FALSE);
						if (null == beanData || beanData.isEmpty()) {
							response.setMessage(err.getProperty("successNoData"));
						}
						else {
							response.setMetaData(metaData);
							response.setMessage(err.getProperty("successful"));
							response.setData(beanData);

						}
					}

				}

			}
			logger.debug("success");
			response.setSuccess(true);
			return response;

		}
		catch (Exception e) {

			logger.error("Unable to retrieve Coc Average Cost Rx Drug Details.", e);

			response.setMessage("Unable to retrieve Coc Average Cost Rx Drug Details.");
			response.setSuccess(false);
		}

		return response;
	}

}
