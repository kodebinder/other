package com.wellpoint.pc2dash.data.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.costOpportunity.GetAmbulatorySurgeryDetailRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.costOpportunity.AmbulatorySurgeryDetailBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.DateUtil;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class AmbulatorySurgeryDetailDao extends ServiceImpl {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(AmbulatorySurgeryDetailDao.class);

	public List<AmbulatorySurgeryDetailBean> getData(GetAmbulatorySurgeryDetailRequest request, boolean exportFlag, int index, int limit) throws Exception {

		List<AmbulatorySurgeryDetailBean> result = new ArrayList<AmbulatorySurgeryDetailBean>();

		setRowCount(0);

		StringBuilder query = new StringBuilder()
			.append(" select  a.* ")
			.append(" from  ( ")
			.append(" 	select ")
			.append(" 		row_number() over ( order by ")
			.append(buildSortClause(request))
			.append(" ) as rank, ")
			.append(" 		dtl.mstr_cnsmr_dim_key AS memberId, ")
			.append(" 		upper(psf.frst_nm) as memberFirstName, ")
			.append(" 		upper(psf.last_nm) as memberLastName, ")
			.append(" 		nullif(psf.brth_dt, '0001-01-01') as memberDOB, ")
			.append(" 		psf.age_nbr as memberAge, ")
			.append(" 		psf.gndr_cd as memberGender, ")
			.append(" 		psf.prov_org_dim_key, ")
			.append(" 		psf.ip_dim_key, ")
			.append(" 		upper(psf.ip_frst_nm) as ip_frst_nm, ")
			.append(" 		upper(psf.ip_last_nm) as ip_last_nm, ")
			.append(" 		psf.prov_org_full_nm as organizationName, ")
			.append(" psf.IP_SPCLTY_NM, ")
			.append(" psf.ip_npi, ")
			.append(" psf.lob_desc, ")
			.append(" psf.psl_desc, ")
			.append(" psf.crprt_plan_cmpny_nm, ")
			.append(" psf.home_plan_nm, ")
			.append(" psf.prov_org_tax_id as organizationTin, ")
			.append(" 		upper(dtl.fclty_nm) as facilityName, ")
			.append(" 		dtl.fclty_type_cd as facilityType, ")
			.append(" 		dtl.clm_line_srvc_strt_dt as serviceDt, ")
			.append(" 		dtl.sub_mtrc_nm as procedureType, ")
			.append(" 		dtl.prmry_proc as primaryProcedure, ")
			.append("       dtl.HCOST_IND as highCostFacilityInd, ")
			.append("       NVL(dtl.SRGN_NM,'UNK') as renderingSurgeon, ") //Changes made for PCMCP-21803
			.append("       NVL(dtl.SRGN_BSNS_NM,'UNK') as surgeonGroup, ") //Changes made for PCMCP-21803
			.append(" 		count(*) over () as row_cnt ")
			.append(" 	from  coc_asc_dtl_smry dtl ")
			.append(" 	join  pat_smry_fact psf on   (psf.PROV_GRP_ID=dtl.PROV_GRP_ID ")
			.append("   and psf.mstr_cnsmr_dim_key = dtl.mstr_cnsmr_dim_key ")
			.append("	and psf.pgm_dim_key=dtl.pgm_dim_key  and dtl.IP_DIM_KEY=psf.IP_DIM_KEY ")
			.append("	and  dtl.prov_org_dim_key =psf.prov_org_dim_key ")
			.append("	and dtl.LOB_DESC=psf.LOB_DESC) ")
			.append(" 	join  poit_user_scrty_acs pusa on ( dtl.prov_grp_id = pusa.prov_grp_id ")
			.append(" 			and ")
			.append(" 		case ")
			.append(" 				when  pusa.prov_org_tax_id = '0' ")
			.append(" 				then  dtl.prov_org_tax_id ")
			.append(" 				else  pusa.prov_org_tax_id end = dtl.prov_org_tax_id ) ")
			.append(" 	where ")
			.append(" 		psf.atrbn_stts_cd = 'ACTIVE' ")
			.append(" 		and pusa.sesn_id = ? ")
			.append(" 		and  pusa.enttlmnt_hash_key = ? ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and dtl.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and dtl.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and dtl.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and dtl.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and dtl.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getFacilityName())) { // PCMSP-8512
			query.append(" and  upper(dtl.fclty_nm) like ? ");
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getSurgeonGroupName())) {  // PCMSP-21810
			query.append(" and  upper(dtl.SRGN_BSNS_NM) like ? ");
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getFacilityTaxId())) {
			query.append(" and  dtl.FCLTY_TAX_ID = ? ");
		}

		// Changes for PCMSP-7421 - Procedure Filter
		if (StringUtil.isNotBlankOrFalse(request.getProcedureCode())) {
			query.append(" and dtl.SUB_MTRC_CD in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProcedureCode())
				+ ") ");
		}

		query.append(" ) a ");
		/*if (!exportFlag) {
			query.append(" where a.rank between ? and ? ");
		}*/
		query.append(" where a.rank between ? and ? ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());

			buildPreparedStatement(request, i, exportFlag, index, limit);

			executeQuery(logger, query.toString());

			result = convertSelectedRowsToObjects(rs, request, exportFlag);

		}
		catch (Exception e) {

			throw new Exception("Unable to get AmbulatorySurgeryDetailDao (" + request.getEntitlementId() + ").", e);
		}
		finally {

			close();
		}

		return result;

	}

	private void buildPreparedStatement(GetAmbulatorySurgeryDetailRequest request, int i, boolean exportFlag, int index, int limit) throws SQLException {
		
		int start = 0;
		int stop = 0;
		
		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getFacilityName())) { // PCMSP-8512
			ps.setString(++i, "%" + request.getFacilityName().toUpperCase() + "%");
		}

		if (StringUtil.isNotBlankOrFalse(request.getFacilityTaxId())) {
			ps.setString(++i, request.getFacilityTaxId());
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getSurgeonGroupName())) {   // PCMSP-21810
			ps.setString(++i, request.getSurgeonGroupName().toUpperCase());
		}

		if (StringUtil.isNotBlankOrFalse(request.getProcedureCode())) { // PCMSP-7421
			String[] array = request.getProcedureCode().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}
		
		if (!exportFlag) {
			start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
			stop = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
		}
		else {
			start = index;
			stop = limit;
		}
		ps.setInt(++i, start + 1);
		ps.setInt(++i, start + stop);

	}

	private List<AmbulatorySurgeryDetailBean> convertSelectedRowsToObjects(ResultSet rs, GetAmbulatorySurgeryDetailRequest request, boolean exportFlag)
		throws SQLException {

		List<AmbulatorySurgeryDetailBean> list = new ArrayList<AmbulatorySurgeryDetailBean>();

		if (exportFlag) {
			while (rs.next()) {
				AmbulatorySurgeryDetailBean item = new AmbulatorySurgeryDetailBean();

				//PCMSP-13760
				//Changed for release-Q1-2018/PCMSP-18421 : Starts
				item.setAttributedPhysicianName(CommonQueries.getFilteredProviderName(rs.getString("ip_frst_nm"),rs.getString("ip_last_nm")));				
				//Changed for release-Q1-2018/PCMSP-18421 : Ends
				//PCMSP-13760 - ends
				
				item.setProviderId(StringUtil.buildUniqueProviderId(rs.getString("ip_dim_key"), rs.getString("prov_org_dim_key")));

				if (rs.getShort("memberAge") != 0) {
					item.setMemberAge(rs.getShort("memberAge"));
				}
				if (null != rs.getString("memberDOB")) {
					item.setMemberDOB(DateUtil.formatDateToMMDDYYYY("yyyy-MM-dd", "M/d/yyyy", rs.getString("memberDOB")));
				}
				if (null != rs.getString("memberFirstName")) {
					item.setMemberFirstName(rs.getString("memberFirstName"));
				}
				if (null != rs.getString("memberLastName")) {
					item.setMemberLastName(rs.getString("memberLastName"));
				}
				item.setMemberFullName(StringUtil.buildFullName(item.getMemberFirstName(), item.getMemberLastName()));
				if (null != rs.getString("memberGender")) {
					item.setMemberGender(rs.getString("memberGender"));
				}
				if (null != rs.getString("memberId")) {
					item.setMemberId(rs.getString("memberId"));
					item.setMemberKey(rs.getInt("memberId"));
				}
				if (null != rs.getString("facilityName")) {
					item.setFacilityName(rs.getString("facilityName"));
				}
				if (null != rs.getString("facilityType")) {
					item.setFacilityType(rs.getString("facilityType"));
				}
				if (null != rs.getString("organizationName")) {
					item.setOrganizationName(rs.getString("organizationName"));
				}
				if (null != rs.getString("organizationTin")) {
					item.setOrganizationTin(rs.getString("organizationTin"));
				}
				if (null != rs.getString("primaryProcedure")) {
					item.setPrimaryProcedure(rs.getString("primaryProcedure"));
				}
				if (null != rs.getString("serviceDt")) {
					item.setServiceDt(DateUtil.formatDateToMMDDYYYY("yyyy-MM-dd", "M/d/yyyy", rs.getString("serviceDt")));
				}
				if (null != rs.getString("procedureType")) {
					item.setProcedureType(rs.getString("procedureType"));
				}

				if (null != rs.getString("highCostFacilityInd")) {
					item.setHighCostFacilityInd(Constants.Y.equals(rs.getString("highCostFacilityInd")) ? Constants.BOOL_TRUE : Constants.BOOL_FALSE);
				}

				item.setAttributedProvNpi(StringUtil.getValueOrDashes(rs.getString("ip_npi")));
				item.setAttributedProvSpeciality(StringUtil.getValueOrDashes(rs.getString("IP_SPCLTY_NM")));
				item.setMemberLob(StringUtil.getValueOrDashes(rs.getString("lob_desc")));
				item.setMemberProduct(StringUtil.getValueOrDashes(rs.getString("psl_desc")));
				item.setMemberHomePlanParentCo(StringUtil.getValueOrDashes(rs.getString("crprt_plan_cmpny_nm")));
				item.setMemberHomePlan(StringUtil.getValueOrDashes(rs.getString("home_plan_nm")));


				list.add(item);

				if (getRowCount() == 0) {
					setRowCount(rs.getInt("row_cnt"));
				}
				setTotalExport(rs.getInt("row_cnt"));  
			}

		}
		else {
			while (rs.next()) {

				AmbulatorySurgeryDetailBean item = new AmbulatorySurgeryDetailBean();

				//PCMSP-13760
				//Changed for release-Q1-2018/PCMSP-18421 : Starts
				item.setAttributedPhysicianName(CommonQueries.getFilteredProviderName(rs.getString("ip_frst_nm"),rs.getString("ip_last_nm")));				
				//Changed for release-Q1-2018/PCMSP-18421 : Ends
				//PCMSP-13760 - ends
				
				item.setProviderId(StringUtil.buildUniqueProviderId(rs.getString("ip_dim_key"), rs.getString("prov_org_dim_key")));

				if (rs.getShort("memberAge") != 0) {
					item.setMemberAge(rs.getShort("memberAge"));
				}
				if (null != rs.getString("memberDOB")) {
					item.setMemberDOB(DateUtil.formatDateToMMDDYYYY("yyyy-MM-dd", "M/d/yyyy", rs.getString("memberDOB")));
				}
				if (null != rs.getString("memberFirstName")) {
					item.setMemberFirstName(rs.getString("memberFirstName"));
				}
				if (null != rs.getString("memberLastName")) {
					item.setMemberLastName(rs.getString("memberLastName"));
				}
				item.setMemberFullName(StringUtil.buildFullName(item.getMemberFirstName(), item.getMemberLastName()));
				if (null != rs.getString("memberGender")) {
					item.setMemberGender(rs.getString("memberGender"));
				}
				if (null != rs.getString("memberId")) {
					item.setMemberId(rs.getString("memberId"));
					item.setMemberKey(rs.getInt("memberId"));
				}
				if (null != rs.getString("facilityName")) {
					item.setFacilityName(rs.getString("facilityName"));
				}
				if (null != rs.getString("facilityType")) {
					item.setFacilityType(rs.getString("facilityType"));
				}
				if (null != rs.getString("organizationName")) {
					item.setOrganizationName(rs.getString("organizationName"));
				}
				if (null != rs.getString("primaryProcedure")) {
					item.setPrimaryProcedure(rs.getString("primaryProcedure"));
				}
				if (null != rs.getString("serviceDt")) {
					item.setServiceDt(DateUtil.formatDateToMMDDYYYY("yyyy-MM-dd", "M/d/yyyy", rs.getString("serviceDt")));
				}
				if (null != rs.getString("procedureType")) {
					item.setProcedureType(rs.getString("procedureType"));
				}

				if (null != rs.getString("highCostFacilityInd")) {
					item.setHighCostFacilityInd(Constants.Y.equals(rs.getString("highCostFacilityInd")) ? Constants.BOOL_TRUE : Constants.BOOL_FALSE);
				}
				
				if (null != rs.getString("renderingSurgeon")) {	                   //Changes made for PCMCP-21803
					item.setRenderingSurgeon(rs.getString("renderingSurgeon"));
				}
				if (null != rs.getString("surgeonGroup")) {                        //Changes made for PCMCP-21803
					item.setSurgeonGroup(rs.getString("surgeonGroup"));
				}
				
				list.add(item);

				if (getRowCount() == 0) {
					setRowCount(rs.getInt("row_cnt"));
				}

			}
		}

		return list;

	}

	private String buildSortClause(GetAmbulatorySurgeryDetailRequest request) {

		StringBuilder query = new StringBuilder();
		String defaultColumn = "  psf.last_nm asc, psf.frst_nm ";
		String defaultSort = defaultColumn + " asc ";

		if (null != request.getSort()) {

			for (QuerySort sort : request.getSort()) {

				String dir = sort.getDirection().replaceAll("\"", "");
				String property = sort.getProperty();

				if (property.equals("facilityName")) {
					query.append(" upper(dtl.fclty_nm) " + dir + ", " + defaultSort);
				}
				else if (property.equals("facilityType")) {
					query.append(" dtl.fclty_type_cd " + dir + ", " + defaultSort);
				}
				else if (property.equals("organizationName")) {
					query.append(" psf.prov_org_full_nm " + dir + ", " + defaultSort);
				}
				else if (property.equals("serviceDt")) {
					query.append(" dtl.clm_line_srvc_strt_dt " + dir + ", " + defaultSort);
				}
				else if (property.equals("procedureType")) {
					query.append(" dtl.sub_mtrc_nm " + dir + ", " + defaultSort);
				}
				else if (property.equals("attributedPhysicianName")) {
					query.append(" psf.ip_last_nm " + dir + ", psf.ip_frst_nm " + dir);
				}
				else if (property.equals("primaryProcedure")) {
					query.append(" dtl.prmry_proc " + dir + ", " + defaultSort);
				}
				else if (property.equals("surgeonGroup")) {                            //Changes made for PCMCP-21803
					query.append(" dtl.SRGN_BSNS_NM " + dir + ", " + defaultSort);
				}
				else if (property.equals("renderingSurgeon")) {                        //Changes made for PCMCP-21803
					query.append(" dtl.SRGN_NM " + dir + ", " + defaultSort);
				}
				
				else {
					query.append("  psf.last_nm " + dir + ", psf.frst_nm " + dir);
				}
			}

		}
		else {

		}

		return query.toString();

	}



}
