package com.wellpoint.pc2dash.action.costOpportunity;

import java.util.List;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.tap.TapReportsBean;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.service.tap.TapReportsServiceImpl;
import com.wellpoint.pc2dash.util.ErrorProperties;

public class GetCostOpportunityViewsAction extends Action {
	
	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		
		List<TapReportsBean> results = null;
		
		GetCostOpportunityViewsRequest request = (GetCostOpportunityViewsRequest) actionRequest;
		GetCostOpportunityViewsResponse response = new GetCostOpportunityViewsResponse();
		ErrorProperties err = ErrorProperties.getInstance();
		
	    /* CodeReusability from TapReportsServiceImpl class to get views name, value and sortNumber */ 
		TapReportsServiceImpl service = new TapReportsServiceImpl();
		
		try {

			results = service.getData(request);

			if (null != results && !results.isEmpty()) {

				response.setData(results);
				response.setMessage(err.getProperty("successful"));
				response.setTotal(1);
			}
			else {

				response.setMessage(err.getProperty("successNoData"));
			}

			response.setSuccess(true);
			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}
}
