package com.wellpoint.pc2dash.action.costOpportunity;

import java.util.List;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.costOpportunity.LabProviderCountPopupBean;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.service.costOpportunity.LabProviderCountPopupServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetLabProviderCountPopupAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		List<LabProviderCountPopupBean> resultList = null;

		GetLabProviderCountPopupRequest request = (GetLabProviderCountPopupRequest) actionRequest;
		GetLabProviderCountPopupResponse response = new GetLabProviderCountPopupResponse();
		ErrorProperties err = ErrorProperties.getInstance();
		LabProviderCountPopupServiceImpl service = new LabProviderCountPopupServiceImpl();

		try {
			
			removeLobPgmPrefixes(request);
			if (StringUtil.isExportDest(request.getDest())) {
				// TODO Future Sprint
			}
			else {

				resultList = service.getData(request, Constants.BOOL_FALSE);

				if (null == resultList || resultList.isEmpty()) {
					response.setMessage(err.getProperty("successNoData"));
				}
				else {
					response.setMessage(err.getProperty("successful"));
					response.setData(resultList);
					response.setTotal(service.getNoOfRecords());
				}
			}

			response.setSuccess(true);
			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

	}

}
