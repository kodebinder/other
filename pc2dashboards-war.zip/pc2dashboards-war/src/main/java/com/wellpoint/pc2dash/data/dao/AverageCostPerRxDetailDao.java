package com.wellpoint.pc2dash.data.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.costOpportunity.GetAverageCostPerRxDetailRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.costOpportunity.AverageCostPerRxDetailBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.DateUtil;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class AverageCostPerRxDetailDao extends ServiceImpl {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(AverageCostPerRxDetailDao.class);
	
	private static boolean isHeader = false;

	public List<AverageCostPerRxDetailBean> getData(GetAverageCostPerRxDetailRequest request, boolean exportFlag, int index, int limit) throws Exception {

		List<AverageCostPerRxDetailBean> result = new ArrayList<AverageCostPerRxDetailBean>();
		setRowCount(0);

		boolean displayDashes = false;
		

		StringBuilder query = new StringBuilder()
			.append("select ")
			.append("	a.*, sum(ttl_rx_cnt) over () as ttl_cnt ")
			.append("from ")
			.append("	( ")
			.append("		select ")
			.append("			row_number() over ( ")
			.append(" order by ")
			.append(buildSortClause(request))
			.append(" ) as row_nbr, ")
			.append(" mstr_cnsmr_dim_key, frst_nm, last_nm, brth_dt, age_nbr, gndr_cd, memberId, sum(ttl_rx_cnt) as ttl_rx_cnt, ")
		    .append(" drug_clss, drug_nm, drug_cd, ip_frst_nm, ip_last_nm, organizationName, organizationTin, prscrbr_dsply_nm, max(rx_filled_dt) as last_fill_dt, ")
			.append(" count(*) over () as row_cnt ");
		if (StringUtil.isExportDest(request.getDest())) {
			query.append(" ,IP_SPCLTY_NM, ip_npi, lob_desc, psl_desc,home_plan_nm,crprt_plan_cmpny_nm ");
		}
		query.append(" from ( select ")
			.append(" psf.mstr_cnsmr_dim_key as mstr_cnsmr_dim_key, upper(psf.frst_nm) as frst_nm, upper(psf.last_nm) as last_nm, nullif(psf.brth_dt, '0001-01-01') as brth_dt, ")
			.append(" psf.age_nbr, psf.gndr_cd, psf.hc_id as memberid, sum(smry.rx_cnt) as ttl_rx_cnt, smry.sub_mtrc_nm as drug_clss, smry.drug_nm,smry.sub_mtrc_cd as drug_cd, psf.ip_frst_nm, ")
			.append(" psf.ip_last_nm, psf.prov_org_full_nm  as organizationName, psf.prov_org_tax_id as organizationTin, smry.prscrbr_dsply_nm, smry.rx_filled_dt ");
		if (StringUtil.isExportDest(request.getDest())) {
			query.append(" ,psf.IP_SPCLTY_NM, psf.ip_npi, ")
				.append(" psf.lob_desc, psf.psl_desc, psf.crprt_plan_cmpny_nm,psf.home_plan_nm ");
		}
		query.append(" 	from coc_rx_dtl_smry as smry ")
			.append(" join pat_smry_fact as psf on (psf.mstr_cnsmr_dim_key = smry.mstr_cnsmr_dim_key) ")
			.append("	join poit_user_scrty_acs pusa on ( ")
			.append("		psf.prov_grp_id = pusa.prov_grp_id ")
			.append("		and case ")
			.append("				when pusa.prov_org_tax_id = '0' then psf.prov_org_tax_id ")
			.append("				else pusa.prov_org_tax_id ")
			.append("			end = psf.prov_org_tax_id ")
			.append("	) ")
			.append(" where  ")
			.append(" pusa.sesn_id = ? ")
			.append(" and pusa.enttlmnt_hash_key = ? ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and smry.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and smry.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and smry.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and smry.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and smry.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}
		
		// PCMSP-16136 - Code change for having absolute search instead of like search
		if (StringUtil.isNotBlankOrFalse(request.getDrugName())) {
			query.append(" and upper(smry.drug_nm) = ? ");
		}
		
		/** PCMSP-21970 - Code change for having drill down search from drug detail to detail view
		 * since drug name for brand category drugs in detail view was changed to actual name, business wanted taht if they drill down to detail view using the brand category
		 * in drug detail view, it should filter all drugs related to the category. hence the absolute search implemented using PCMSP-16136 wont work in this scenario.
		 */
		if (StringUtil.isNotBlankOrFalse(request.getDrugCtgryName())) {
			query.append(" and upper(smry.drug_ctgry_nm) = ? ");
		}
				
        
        if (StringUtil.isNotBlankOrFalse(request.getDrugClassKeys())) {
            query.append(" and smry.SUB_MTRC_CD in ("
                + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getDrugClassKeys())
                + ") ");
        }

		 query.append(" and  psf.ATRBN_STTS_CD = 'ACTIVE' ")//PCMSP-17916
			.append(" group by psf.mstr_cnsmr_dim_key, upper(psf.frst_nm), upper(psf.last_nm), nullif(psf.brth_dt, '0001-01-01'), ")
		    .append(" psf.age_nbr, psf.gndr_cd, psf.hc_id, smry.sub_mtrc_nm, smry.drug_nm, smry.sub_mtrc_cd ,psf.ip_frst_nm, ")
			.append(" psf.ip_last_nm, psf.prov_org_full_nm, psf.prov_org_tax_id, smry.prscrbr_dsply_nm, smry.rx_filled_dt ");

		if (StringUtil.isExportDest(request.getDest())) {
			query.append(" ,psf.IP_SPCLTY_NM, psf.ip_npi, ")
				.append(" psf.lob_desc, psf.psl_desc, psf.crprt_plan_cmpny_nm, psf.home_plan_nm ");
		}
		query.append(") ")
		.append(" group by mstr_cnsmr_dim_key, frst_nm, last_nm, brth_dt, age_nbr, gndr_cd, memberid, ")
		.append(" drug_clss, drug_nm, drug_cd ,ip_frst_nm, ip_last_nm, organizationName, organizationTin, prscrbr_dsply_nm ");

		if (StringUtil.isExportDest(request.getDest())) {
			query.append(" ,IP_SPCLTY_NM, ip_npi, lob_desc, psl_desc,home_plan_nm,crprt_plan_cmpny_nm ");
		}
		query.append(") a ");

		/*if (!exportFlag) {
			query.append(" where a.row_nbr between ? and ? ");
		}*/
		query.append(" where a.row_nbr between ? and ? ");
		query.append(" order by a.row_nbr ")
		.append(" with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());

			buildPreparedStatement(request, i, exportFlag, index, limit);

			executeQuery(logger, query.toString());

			result = convertSelectedRowsToObjects(rs, request, displayDashes, exportFlag);

		}
		catch (Exception e) {

			throw new Exception("Unable to get AverageCostPerRxDetailDao (" + request.getEntitlementId() + ").", e);
		}
		finally {

			close();
		}

		return result;

	}

	private void buildPreparedStatement(GetAverageCostPerRxDetailRequest request, int i, boolean exportFlag, int index, int limit) throws SQLException {
		
		int start = 0;
		int stop = 0;
		
		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getDrugName())) {
			ps.setString(++i, request.getDrugName().toUpperCase());
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getDrugCtgryName())) {
			ps.setString(++i, request.getDrugCtgryName().toUpperCase());
		}        
		
        if (StringUtil.isNotBlankOrFalse(request.getDrugClassKeys())) {
            String[] array = request.getDrugClassKeys().split(",");
            for (String item : array) {
                ps.setString(++i, item);
            }
        }

		if (!exportFlag) {
			start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
			stop = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
		}
		else {
			start = index;
			stop = limit;
		}
		ps.setInt(++i, start + 1);
		ps.setInt(++i, start + stop);

	}

	private List<AverageCostPerRxDetailBean> convertSelectedRowsToObjects(ResultSet rs, GetAverageCostPerRxDetailRequest request,
		boolean displayDashes, boolean exportFlag)
		throws SQLException {

		List<AverageCostPerRxDetailBean> list = new ArrayList<AverageCostPerRxDetailBean>();
		String totalRx = request.getTotalScripts();

		if (exportFlag) {
			while (rs.next()) {
				
				setTotalExport(rs.getInt("row_cnt"));   

				AverageCostPerRxDetailBean item = new AverageCostPerRxDetailBean();

				if (null != rs.getString("last_nm")) {
					item.setMemberLastName(StringUtil.getValueOrDashes(rs.getString("last_nm")));
				}
				if(null != rs.getString("frst_nm")){
					item.setMemberFirstName(StringUtil.getValueOrDashes(rs.getString("frst_nm")));
				}
				if (null != rs.getString("age_nbr")){
					item.setMemberAge(rs.getString("age_nbr"));
				}
				if (null != rs.getString("brth_dt")) {
					item.setMemberDOB(DateUtil.formatDateToMMDDYYYY("yyyy-MM-dd", "M/d/yyyy", rs.getString("brth_dt")));
				}else {
					item.setMemberDOB(Constants.DASHES);
				}
				if (null != rs.getString("gndr_cd")) {
					item.setMemberGender(StringUtil.getValueOrDashes(rs.getString("gndr_cd")));
				}
				if (null != rs.getString("memberId")){
					item.setMemberId(StringUtil.getValueOrDashes(rs.getString("memberId")));
				}
				if(null != rs.getString("lob_desc")){
					item.setMemberLob(StringUtil.getValueOrDashes(rs.getString("lob_desc")));
				}
				if(null != rs.getString("psl_desc")){
					item.setMemberProduct(StringUtil.getValueOrDashes(rs.getString("psl_desc")));
				}
				if(null != rs.getString("crprt_plan_cmpny_nm")){
					item.setMemberHomePlanParentCo(StringUtil.getValueOrDashes(rs.getString("crprt_plan_cmpny_nm")));
				}
				if(null != rs.getString("home_plan_nm")){
					item.setMemberHomePlanName(StringUtil.getValueOrDashes(rs.getString("home_plan_nm")));
				}
				if(null != rs.getString("drug_clss")){
					item.setDrugClass(StringUtil.getValueOrDashes(rs.getString("drug_clss")));
				}
				if(null != rs.getString("drug_nm")){
					item.setDrugName(StringUtil.getValueOrDashes(rs.getString("drug_nm")));
				}
				if(null != rs.getString("ttl_rx_cnt")){
					item.setTotalScripts(StringUtil.getValueOrDashes(rs.getString("ttl_rx_cnt")));
				}

				
				//Changed for release-Q1-2018/PCMSP-18421 : Starts
				item.setAttributedPhysicianName(CommonQueries.getFilteredProviderName(rs.getString("ip_frst_nm"),rs.getString("ip_last_nm")));				
				//Changed for release-Q1-2018/PCMSP-18421 : Ends
				
				if(null != rs.getString("ip_npi")){
					item.setAttributedProvNpi(StringUtil.getValueOrDashes(rs.getString("ip_npi")));
				}
				if(null != rs.getString("IP_SPCLTY_NM")){
					item.setAttributedProvSpeciality(StringUtil.getValueOrDashes(rs.getString("IP_SPCLTY_NM")));
				}
				/*if(null != rs.getString("organizationName")) {
					item.setOrganizationName(rs.getString("organizationName"));
				}*/
				//Changed for release-Q1-2018/PCMSP-18748 : Starts
				if(null!= rs.getString("organizationName"))
					item.setOrganizationName(rs.getString("organizationName"));
				else
					item.setOrganizationName(Constants.DASHES);
				//Changed for release-Q1-2018/PCMSP-18748 : Ends;
				if(null != rs.getString("organizationTin")) {
					item.setOrganizationTin(rs.getString("organizationTin"));
				}
				if(null != rs.getString("prscrbr_dsply_nm")){ 
					//PCMSP-16149- defect fix to have UNK displayed instead of '---'
					item.setPrescribingProvider(rs.getString("prscrbr_dsply_nm"));
				}
				if (null != rs.getString("last_fill_dt")) {
					item.setLastFillDate(DateUtil.formatDateToMMDDYYYY("yyyy-MM-dd", "M/d/yyyy", rs.getString("last_fill_dt")));
				}
				else {
					item.setLastFillDate(Constants.DASHES);
				}

				list.add(item);

				if (getRowCount() == 0) {
					setRowCount(rs.getInt("row_cnt"));
				}
			}
			if(!isHeader) {
			AverageCostPerRxDetailBean jsonResultAfterLoop = new AverageCostPerRxDetailBean();
			jsonResultAfterLoop.setSummaryRow("true");
			jsonResultAfterLoop.setMemberLastName("TOTAL");
			jsonResultAfterLoop.setTotalScripts(StringUtil.convertStringToCommaBigDecimal(totalRx, 0));
			list.add(0, jsonResultAfterLoop);
			isHeader = true;
			}
		}
		else {
			while (rs.next()) {

				AverageCostPerRxDetailBean item = new AverageCostPerRxDetailBean();

				if (rs.getString("age_nbr") != null)
					item.setMemberAge(rs.getString("age_nbr"));
				if (rs.getString("brth_dt") != null) {
					item.setMemberDOB(DateUtil.formatDateToMMDDYYYY(
						"yyyy-MM-dd", "M/d/yyyy", rs.getString("brth_dt")));
				}
				else {
					item.setMemberDOB(Constants.DASHES);
				}
				item.setMemberLastName(StringUtil.getValueOrDashes(rs.getString("last_nm")));
				item.setMemberFirstName(StringUtil.getValueOrDashes(rs.getString("frst_nm")));
				item.setMemberGender(StringUtil.getValueOrDashes(rs.getString("gndr_cd")));
				item.setMemberId(StringUtil.getValueOrDashes(rs.getString("memberId")));

				if (rs.getString("frst_nm") != null
					&& rs.getString("last_nm") != null)
					item.setMemberFullName(StringUtil.buildFullName(
						rs.getString("frst_nm"), rs.getString("last_nm")));

				if (rs.getString("mstr_cnsmr_dim_key") != null)
					item.setMemberKey(rs.getLong("mstr_cnsmr_dim_key"));

				//Changed for release-Q1-2018/PCMSP-18421 : Starts
				item.setAttributedPhysicianName(CommonQueries.getFilteredProviderName(rs.getString("ip_frst_nm"),rs.getString("ip_last_nm")));				
				//Changed for release-Q1-2018/PCMSP-18421 : Ends

				item.setDrugClass(StringUtil.getValueOrDashes(rs.getString("drug_clss")));
				item.setDrugName(StringUtil.getValueOrDashes(rs.getString("drug_nm")));
				item.setTotalScripts(StringUtil.getValueOrDashes(rs.getString("ttl_rx_cnt")));
				//item.setOrganizationName(StringUtil.getValueOrDashes(rs.getString("organizationName")));
				//Changed for release-Q1-2018/PCMSP-18748 : Starts
				if(null!= rs.getString("organizationName"))
					item.setOrganizationName(rs.getString("organizationName"));
				else
					item.setOrganizationName(Constants.DASHES);
				//Changed for release-Q1-2018/PCMSP-18748 : Ends;
				item.setPrescribingProvider(rs.getString("prscrbr_dsply_nm"));//PCMSP-16149- defect fix to have UNK displayed instead of '---'
				if (rs.getString("last_fill_dt") != null) {
					item.setLastFillDate(DateUtil.formatDateToMMDDYYYY(
						"yyyy-MM-dd", "M/d/yyyy", rs.getString("last_fill_dt")));
				}
				else {
					item.setLastFillDate(Constants.DASHES);
				}

				list.add(item);

				if (getRowCount() == 0) {
					setRowCount(rs.getInt("row_cnt"));
				}
			}
		}

		return list;
	}

	private String buildSortClause(GetAverageCostPerRxDetailRequest request) {

		StringBuilder query = new StringBuilder();
		String defaultColumn = " sum(ttl_rx_cnt) ";
		String defaultSort = defaultColumn + " desc ";

		if (null != request.getSort()) {

			for (QuerySort sort : request.getSort()) {

				String dir = sort.getDirection().replaceAll("\"", "");
				String property = sort.getProperty();

				if (property.equals("memberFullName")) {
					query.append(" last_nm " + dir + ", frst_nm " + dir);
				}
				else if (property.equals("drugClass")) {
					query.append(" drug_clss " + dir + ", " + defaultSort);
				}
				else if (property.equals("drugName")) {
					query.append(" drug_nm " + dir + ", " + defaultSort);
				}
				else if (property.equals("attributedPhysicianName")) {
					query.append(" ip_last_nm " + dir + ", ip_frst_nm " + dir);
				}
				else if (property.equals("organizationName")) {
					query.append(" organizationName " + dir + ", " + defaultSort);
				}
				else if (property.equals("prescribingProvider")) {
					query.append(" prscrbr_dsply_nm " + dir + ", " + defaultSort);
				}
				else if (property.equals("lastFillDate")) {
					query.append(" max(rx_filled_dt) " + dir + ", " + defaultSort);
				}
				else {
					query.append(defaultColumn + dir);
				}
			}
		}
		return query.toString();
	}
}