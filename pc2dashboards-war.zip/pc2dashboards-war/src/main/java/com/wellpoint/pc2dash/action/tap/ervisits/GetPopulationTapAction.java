package com.wellpoint.pc2dash.action.tap.ervisits;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.tap.ervisits.PopulationTapBean;
import com.wellpoint.pc2dash.dto.tap.ervisits.PopulationTapMetadata;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.service.tap.ervisits.PopulationTapServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetPopulationTapAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetPopulationTapRequest request = (GetPopulationTapRequest) actionRequest;
		GetPopulationTapResponse response = new GetPopulationTapResponse();
		ErrorProperties err = ErrorProperties.getInstance();

		PopulationTapServiceImpl service = new PopulationTapServiceImpl();
		List<String> grps = null;

		try {

			removeLobPgmPrefixes(request);
			prepareChronicCareGapMap(request);

			if (StringUtils.isNotBlank(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			// Clinical access check on provider groups
			if (null != grps && !grps.isEmpty()) {

				request.setProvGrpIdsWithoutClinicalCheck(StringUtils.join(grps, ','));
				grps = filterProvGrpsByClinicalInd(request, grps);
				request.setProvGrpIds(StringUtils.join(grps, ','));
			}

			/*
			 * Need to populate HCC/Total Cost suppression values for the chart, so the chart/grid
			 * queries can be kept in sync.
			 */
			CommonQueries cq = new CommonQueries();
			request.setGroupsWithActionCenterSuppressed(cq.getGroupsWithComponentSuppressed(request, Constants.AC_RF_CARDCONTAINER));
			request.setSuppression(cq.getActiveSuppressionForSelectComponents(request));
			request.setUnsuppressedLOBsTotalCost(getLOBsWithoutTotalCostSuppressed(request));

			if (null != grps && !grps.isEmpty()) {

				if (StringUtil.isExportDest(request.getDest())) {
					//To Be Coded - When Export component comes into picture
				}
				else {

					List<PopulationTapBean> results = service.getTAPReportData(request);
					
					if (null != results && !results.isEmpty()) {
						
						//PopulationTapMetadata metadata = service.getERcost(request);

						response.setData(results);
						//response.setMetaData(metadata);
						response.setMessage(err.getProperty("successful"));
						response.setTotal(results.size());
					}
					else {
						response.setMessage(err.getProperty("successNoData"));
						//PopulationTapMetadata result = new PopulationTapMetadata();
						//result.setErVisitCost(Constants.NA);
						//response.setMetaData(result);
					}
				}
			}

			response.setSuccess(true);
			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

	}

}
