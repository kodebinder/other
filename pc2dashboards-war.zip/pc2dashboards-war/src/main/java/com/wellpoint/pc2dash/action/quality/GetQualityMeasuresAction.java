package com.wellpoint.pc2dash.action.quality;

import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.data.dao.MedicaidQualityMeasures;
import com.wellpoint.pc2dash.data.dao.QualityMeasures;
import com.wellpoint.pc2dash.dto.quality.QualityMeasure;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.DateUtil;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetQualityMeasuresAction extends GetQualityAction {

	GetQualityMeasuresResponse response = new GetQualityMeasuresResponse();
	List<QualityMeasure> resultList = new ArrayList<QualityMeasure>();

	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		GetQualityMeasuresRequest request = (GetQualityMeasuresRequest) actionRequest;
		List<String> filteredProvGrpList = new ArrayList<String>();
		
		try {
			String measStartDate = request.getMeasurementPeriodStartDt();
			boolean isMPGreaterThanOrEqual01012018 = DateUtil.dateComparator(measStartDate, Constants.IND_MTRC_STRT_DT);
			request = (GetQualityMeasuresRequest) cleanRequest(request);
			
			//			//PCMSRequest request = getDataMap((GetDrillDownRequest) actionRequest);
			//Kill switch check on Provider groups
			if (null != request) {
				filteredProvGrpList = filterProvGrpsByKillSwitch(request);
			}

			// Clinical access check on provider groups
			if (null != filteredProvGrpList
				&& filteredProvGrpList.size() > 0) {
				filteredProvGrpList = filterProvGrpsByClinicalInd(request, filteredProvGrpList);
			}

			if (filteredProvGrpList.contains(request.getProvGrpIds().trim())) {
				if ((request.getProgramLobTypeCd().equalsIgnoreCase(Constants.MEDICARE) || request.getProgramLobTypeCd().equalsIgnoreCase(Constants.FPCC_MEDICARE)) && request.getCompositeType().equalsIgnoreCase(Constants.IMPCOMPOSITETYPE) && isMPGreaterThanOrEqual01012018) {
					QualityMeasures dao1 = new QualityMeasures();
					resultList = dao1.getQualityMeasures(request);
				}
				else if (request.getProgramLobTypeCd().equalsIgnoreCase(Constants.MEDICAID) || request.getCompositeType().equalsIgnoreCase(Constants.IMPCOMPOSITETYPE)) {
					MedicaidQualityMeasures dao2 = new MedicaidQualityMeasures();
					resultList = dao2.getImprovementQualityMeasures(request);
				}
				if (!request.getProgramLobTypeCd().equalsIgnoreCase(Constants.MEDICAID) && !request.getCompositeType().equalsIgnoreCase(Constants.IMPCOMPOSITETYPE)) {
					QualityMeasures dao1 = new QualityMeasures();
					resultList = dao1.getQualityMeasures(request);
				}
				
			}


			if (null == resultList || (null != resultList && resultList.isEmpty())) {
				response.setMessage(StringUtil.buildMessage(Boolean.TRUE));
			}
			else {
				response.setMessage(StringUtil.buildMessage(Boolean.FALSE));
				//response.setData(resultList); // TODO For 2.0, when UI is ready, remove the data element - it is redundant ("children" already contains the data) and UI requested that it be removed
				response.setTotal(resultList.size()); // calculates total without another query
			}

			response.setSuccess(true); // based on GetCareOpportunitiesPatientAction.process(), MW never returns "false"
			response.setText("."); // Currently hardcoded to what UI expects
			response.getChildren().addAll(resultList);

		}
		catch (Exception e) {
			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(e, response);
		}

		return response;
	}

}
