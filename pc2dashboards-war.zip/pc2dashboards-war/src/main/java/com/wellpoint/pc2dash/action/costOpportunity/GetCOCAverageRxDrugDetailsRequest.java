package com.wellpoint.pc2dash.action.costOpportunity;

import com.wellpoint.pc2dash.data.dto.PopulationManagementRequest;

public class GetCOCAverageRxDrugDetailsRequest extends PopulationManagementRequest {

	protected String subMetricId;
	protected String category;
	private String subMetricData;
	private String drugClassKeys;
	private boolean hasDetailsDrilldownInd = false;

    public String getDrugClassKeys() {
        return drugClassKeys;
    }

    public void setDrugClassKeys(String drugClassKeys) {
        this.drugClassKeys = drugClassKeys;
    }

	public String getSubMetricId() {
		return subMetricId;
	}

	public void setSubMetricId(String subMetricId) {
		this.subMetricId = subMetricId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSubMetricData() {
		return subMetricData;
	}

	public void setSubMetricData(String subMetricData) {
		this.subMetricData = subMetricData;
	}

	public boolean isHasDetailsDrilldownInd() {
		return hasDetailsDrilldownInd;
	}

	public void setHasDetailsDrilldownInd(boolean hasDetailsDrilldownInd) {
		this.hasDetailsDrilldownInd = hasDetailsDrilldownInd;
	}

}
