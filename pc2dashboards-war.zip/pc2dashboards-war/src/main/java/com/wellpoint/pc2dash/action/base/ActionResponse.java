package com.wellpoint.pc2dash.action.base;


public class ActionResponse {

	private boolean success;
	private Object data;
	private int total;
	private int exportTotal;
	private String message;
	private Object metaData;

	public boolean getSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getExportTotal() {
		return exportTotal;
	}

	public void setExportTotal(int exportTotal) {
		this.exportTotal = exportTotal;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object getMetaData() {
		return metaData;
	}

	public void setMetaData(Object metaData) {
		this.metaData = metaData;
	}
}
