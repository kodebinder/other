package com.wellpoint.pc2dash.action.costOpportunity;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.dto.costOpportunity.SpecialtyRxSoCProviderBean;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportGridColumn;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.costOpportunity.SpecialtyRxSoCProviderExport;
import com.wellpoint.pc2dash.service.costOpportunity.SpecialtyRxSoCProviderServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetSpecialtyRxSoCProviderAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		List<SpecialtyRxSoCProviderBean> resultList = null;

		GetSpecialtyRxSoCProviderRequest request = (GetSpecialtyRxSoCProviderRequest) actionRequest;
		GetSpecialtyRxSoCProviderResponse response = new GetSpecialtyRxSoCProviderResponse();
		ErrorProperties err = ErrorProperties.getInstance();
		SpecialtyRxSoCProviderServiceImpl service = new SpecialtyRxSoCProviderServiceImpl();


		List<String> grps = null;

		try {

			removeLobPgmPrefixes(request);

			if (StringUtils.isNotBlank(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			if (null != grps && !grps.isEmpty()) {
				request.setProvGrpIdsWithoutClinicalCheck(StringUtils.join(grps, ','));
				grps = filterProvGrpsByClincalFinancialInd(request, grps);
				request.setProvGrpIds(CollectionUtils.isNotEmpty(grps) ? StringUtils.join(grps, ',') : Constants.DASHES);
			}

			CommonQueries cq = new CommonQueries();
			request.setTapId(request.getMetricViewId());
			request.setSuppression(cq.getActiveSuppressionForSelectComponents(request));

			MetaData metaData = new MetaData();
			metaData.setReportingPeriod(cq.getReportingPeriodForCostOpportunity(Constants.SPCLTY_RX_SOC));
			metaData.setReportDate(cq.getReportDateForCostOpportunity(Constants.SPCLTY_RX_SOC));



			if (StringUtil.isExportDest(request.getDest())) {

				request.setReportingPeriod(metaData.getReportingPeriod());
				request.setReportDate(metaData.getReportDate());
				List<ExportGridColumn> columns = service.buildExportGridColumns(request);
				SpecialtyRxSoCProviderExport exp = new SpecialtyRxSoCProviderExport(request, columns);

				ExportProcessor.getInstance().submit(exp);

			}
			else {

				if (null != grps && !grps.isEmpty()) {
					
					request.setHasDetailsDrilldownInd(isUserClinical(request));
					resultList = service.getData(request);

					if (null == resultList || resultList.isEmpty()) {
						response.setMessage(err.getProperty("successNoData"));
					}
					else {
						response.setMetaData(metaData);
						response.setMessage(err.getProperty("successful"));
						response.setData(resultList);
						response.setTotal(service.getNoOfRecords());
					}
				}
			}

			response.setSuccess(true);
			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

	}

}
