package com.wellpoint.pc2dash.dao;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class CareOprtntyFact implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long careOprtntyFactKey;

	private Date anlyssAsOfDt;

	private String careOprtntySttsCd;

	private String cmplncIndCd;

	private Long crtdLoadLogKey;

	private String elgbltyIndCd;

	private Date lastCmplncDt;

	private String careoppVstDueNbr;

	private BigDecimal mnthId;

	private Date nextClnclDueDt;

	private String rcrdSttsCd;

	private Timestamp sorDtm;

	private Long updtdLoadLogKey;

	//bi-directional many-to-one association to MsrDim
	private MsrDim msrDim;

	private Long pgmDim;
	
	private String expPdcPct;
	

	public Long getPgmDim() {
		return pgmDim;
	}

	public void setPgmDim(Long pgmDim) {
		this.pgmDim = pgmDim;
	}

	public CareOprtntyFact() {}

	public Long getCareOprtntyFactKey() {
		return this.careOprtntyFactKey;
	}

	public void setCareOprtntyFactKey(Long careOprtntyFactKey) {
		this.careOprtntyFactKey = careOprtntyFactKey;
	}

	public Date getAnlyssAsOfDt() {
		return this.anlyssAsOfDt;
	}

	public void setAnlyssAsOfDt(Date anlyssAsOfDt) {
		this.anlyssAsOfDt = anlyssAsOfDt;
	}

	public String getCareOprtntySttsCd() {
		return this.careOprtntySttsCd;
	}

	public void setCareOprtntySttsCd(String careOprtntySttsCd) {
		this.careOprtntySttsCd = careOprtntySttsCd;
	}

	public String getCmplncIndCd() {
		return this.cmplncIndCd;
	}

	public void setCmplncIndCd(String cmplncIndCd) {
		this.cmplncIndCd = cmplncIndCd;
	}

	public Long getCrtdLoadLogKey() {
		return this.crtdLoadLogKey;
	}

	public void setCrtdLoadLogKey(Long crtdLoadLogKey) {
		this.crtdLoadLogKey = crtdLoadLogKey;
	}

	public String getElgbltyIndCd() {
		return this.elgbltyIndCd;
	}

	public void setElgbltyIndCd(String elgbltyIndCd) {
		this.elgbltyIndCd = elgbltyIndCd;
	}

	public Date getLastCmplncDt() {
		return this.lastCmplncDt;
	}

	public void setLastCmplncDt(Date lastCmplncDt) {
		this.lastCmplncDt = lastCmplncDt;
	}

	public BigDecimal getMnthId() {
		return this.mnthId;
	}

	public void setMnthId(BigDecimal mnthId) {
		this.mnthId = mnthId;
	}

	public Date getNextClnclDueDt() {
		return this.nextClnclDueDt;
	}

	public void setNextClnclDueDt(Date nextClnclDueDt) {
		this.nextClnclDueDt = nextClnclDueDt;
	}

	public String getRcrdSttsCd() {
		return this.rcrdSttsCd;
	}

	public void setRcrdSttsCd(String rcrdSttsCd) {
		this.rcrdSttsCd = rcrdSttsCd;
	}

	public Timestamp getSorDtm() {
		return this.sorDtm;
	}

	public void setSorDtm(Timestamp sorDtm) {
		this.sorDtm = sorDtm;
	}

	public Long getUpdtdLoadLogKey() {
		return this.updtdLoadLogKey;
	}

	public void setUpdtdLoadLogKey(Long updtdLoadLogKey) {
		this.updtdLoadLogKey = updtdLoadLogKey;
	}

	public MsrDim getMsrDim() {
		return this.msrDim;
	}

	public void setMsrDim(MsrDim msrDim) {
		this.msrDim = msrDim;
	}

	public String getCareoppVstDueNbr() {
		return careoppVstDueNbr;
	}

	public void setCareoppVstDueNbr(String careoppVstDueNbr) {
		this.careoppVstDueNbr = careoppVstDueNbr;
	}

	public String getExpPdcPct() {
		return expPdcPct;
	}

	public void setExpPdcPct(String expPdcPct) {
		this.expPdcPct = expPdcPct;
	}
	
}
