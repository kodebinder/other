package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.data.dto.PCMSRequest;
import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;
import com.wellpoint.pc2dash.dto.scorecard.ScorecardCompositeBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;

public class MedicaidScorecardByCompositeFactsDao extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(MedicaidScorecardByCompositeFactsDao.class);

	public boolean read(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void insert(Dto o) throws Exception {
		throw new Exception("Not implemented");

	}

	public void update(Dto o) throws Exception {
		throw new Exception("Not implemented");

	}

	public void delete(Dto o) throws Exception {
		throw new Exception("Not implemented");

	}

	public Collection<ScorecardCompositeBean> getScorecardComposites(PerformanceManagementRequest request) throws Exception {

		Collection<ScorecardCompositeBean> result = new ArrayList<ScorecardCompositeBean>();
		StringBuilder sql = new StringBuilder();

		sql = createQueryForImprovement(request)
			.append(" UNION ")
			.append(createQueryForQuality(request));
		sql = StringUtil.appendWithUr(sql);


		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());
			int i = 1;
			ps.setString(i++, request.getProgramId());
			ps.setString(i++, request.getMeasurementPeriodStartDt());
			ps.setString(i++, request.getProvGrpIds());
			ps.setString(i++, request.getProgramLobTypeCd().toUpperCase());

			if (request.getMeasurementInterval() != null && request.getMeasurementInterval().equalsIgnoreCase("0")) {
				ps.setString(i++, request.getProvGrpIds());
				ps.setString(i++, request.getProgramId());
				ps.setString(i++, request.getMeasurementPeriodStartDt());
				ps.setString(i++, request.getProgramId());

			}

			ps.setString(i++, request.getProgramId());
			ps.setString(i++, request.getMeasurementPeriodStartDt());
			ps.setString(i++, request.getProvGrpIds());
			ps.setString(i++, request.getProgramLobTypeCd().toUpperCase());


			if (request.getMeasurementInterval() != null && request.getMeasurementInterval().equalsIgnoreCase("0")) {
				ps.setString(i++, request.getProvGrpIds());
				ps.setString(i++, request.getProgramId());
				ps.setString(i++, request.getMeasurementPeriodStartDt());
				ps.setString(i++, request.getProgramId());

			}

			executeQuery(logger, sql.toString());
			ScorecardCompositeBean sc;
			while (rs.next()) {
				sc = new ScorecardCompositeBean();
				sc.setCompositeId(getString(rs, "cmpst_defn_id"));
				sc.setCompositeName(getString(rs, "cmpst_nm"));
				sc.setCompositeTypeDesc(getString(rs, "cmpst_type_desc"));
				sc.setSsavUpsdDstrbnPct(getString(rs, "ssav"));
				sc.setErncntrPct(getString(rs, "erncntr"));
				sc.setQualityGate(getString(rs, "qlty_gate_thrshld_pct"));
				sc.setQualityScore(getString(rs, "qlty_scor_pct"));
				sc.setQualityGateInd(getString(rs, "qlty_gate_ind"));

				result.add(sc);
			}
		}
		catch (Exception e) {
			logger.error(e);
		}
		finally {

			close();
		}

		return result;
	}

	public StringBuilder createQueryForQuality(PCMSRequest request) {

		StringBuilder sql = new StringBuilder()
			.append("select cmpst_nm, cmpst_defn_id, cmpst_type_desc, erncntr, ssav , qlty_gate_thrshld_pct, qlty_scor_pct, qlty_gate_ind as ssav from ( ")
			.append("select ")
			.append(" smhd.cmpst_nm, ")
			.append(" smhd.cmpst_defn_id, ")
			.append(" smhd.cmpst_type_desc, ")
			.append(" sum(ef.rdstrbtd_erncntr_pct) as erncntr, ")
			.append(" ef.qlty_gate_thrshld_pct, ")
			.append(" ef.qlty_scor_pct, ")
			.append(" ef.qlty_gate_ind, ")
			.append(" sum(ef.rdstrbtd_ssav_upsd_dstrbtn_pct) as ssav, ")
			.append(" smhd.sub_cmpst_nm ")
			.append(" from ")
			.append(" erncntr_fact ef ")
			.append(" join pgm_dim pgm on ( ")
			.append(" ef.pgm_dim_key = pgm.pgm_dim_key ")
			.append(" ) ")
			.append(" join prov_grp_dim pg on ( ")
			.append(" ef.prov_grp_dim_key = pg.prov_grp_dim_key ")
			.append(" ) ")
			.append(" join scrcrd_pgm_msr_hrchy_fact spmhf on ( ")
			.append(" ef.pgm_dim_key = spmhf.pgm_dim_key  and ")
			.append(" ef.trnch_defn_dim_key = spmhf.trnch_defn_dim_key and ")
			.append(" ef.mnth_id = spmhf.mnth_id and ")
			.append(" ef.msrmnt_prd_strt_dt = spmhf.msrmnt_prd_strt_dt ")
			.append(" ) ")
			.append(" join scrcrd_msr_hrchy_dim smhd on ( ")
			.append(" spmhf.scrcrd_msr_hrchy_dim_key = smhd.scrcrd_msr_hrchy_dim_key ")
			.append(" ) ")
			.append(" where ")
			.append(" pgm.pgm_id = ? and ")
			.append(" ef.msrmnt_prd_strt_dt = ? and ")
			.append(" pg.prov_grp_id = ? and ")
			.append(" smhd.cmpst_type_desc in ( 'Quality') and ")
			.append(" spmhf.pgm_lob_type_cd = ? ");

		if (null != Constants.getQuarterName(request
			.getMeasurementInterval())) {
			if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
				sql.append(" AND ef.BSLN_SCRCRD_IND = 'Y' ");
			}
			else {
				sql.append(" AND ef.QTR_ID = '"
					+ Constants.getQuarterName(request
						.getMeasurementInterval()) + "' ");
			}
		}
		else {
			sql.append(" AND EF.MNTH_ID = (SELECT MAX(EF.MNTH_ID) FROM ERNCNTR_FACT EF INNER JOIN "
				+ " (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT FROM SCRCRD_PGM_MSR_HRCHY_FACT WHERE  ");
			//+" PGM_DIM_KEY=(SELECT PGM_DIM_KEY FROM PROV_GRP_PGM_LOB_FACT WHERE PGM_ID = ? and PGM_PG_TRMNTN_DT > CURRENT_DATE GROUP BY PGM_DIM_KEY) "
			sql.append(" 		 PGM_DIM_KEY = (SELECT PGM_DIM_KEY FROM PROV_GRP_PGM_LOB_FACT A ");
			sql.append(" 		inner join   PROV_GRP_DIM B ON A.PROV_GRP_DIM_KEY=B.PROV_GRP_DIM_KEY and  B.PROV_GRP_ID = ?");
			sql.append("		WHERE A.PGM_ID = ? and A.PGM_PG_TRMNTN_DT > CURRENT_DATE GROUP BY A.PGM_DIM_KEY) "
				+ " and  MSRMNT_PRD_STRT_DT = ? "
				+ "GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM "
				+ " ON EF.PGM_DIM_KEY=SC_PGM.PGM_DIM_KEY AND EF.MSRMNT_PRD_STRT_DT=SC_PGM.MSRMNT_PRD_STRT_DT) "
				+ " and (select max(ef.mnth_id)MAX_MON from ERNCNTR_FACT ef join PGM_DIM pd on ef.pgm_dim_key = pd.pgm_dim_key where pd.pgm_id = ? ) <=  INT(TO_CHAR(ef.msrmnt_prd_strt_dt + 15 months, 'YYYYMM')) ");
		}
		sql.append(" group by smhd.CMPST_NM ,smhd.CMPST_DEFN_ID, smhd.CMPST_TYPE_DESC,smhd.sub_cmpst_nm, ef.qlty_gate_thrshld_pct, ef.qlty_scor_pct, ef.qlty_gate_ind ")
			.append(" order by smhd.CMPST_NM")
			.append(") group by cmpst_nm,cmpst_defn_id, cmpst_type_desc, qlty_gate_thrshld_pct, qlty_scor_pct, qlty_gate_ind, erncntr, ssav ");

		return sql;
	}


	public StringBuilder createQueryForImprovement(PCMSRequest request) {
		StringBuilder sql = new StringBuilder()
			.append("select cmpst_nm, cmpst_defn_id, cmpst_type_desc, sum(erncntr) as erncntr, sum(ssav) as ssav, qlty_gate_thrshld_pct, qlty_scor_pct, qlty_gate_ind from ( ")
			.append("select ")
			.append(" ipgsf.rdstrbtd_erncntr_pct as erncntr, ")
			.append(" ipgsf.rdstrbtd_ssav_upsd_dstrbtn_pct as ssav, ")
			.append(" smhd.cmpst_nm, ")
			.append(" smhd.cmpst_defn_id, ")
			.append(" ef.qlty_gate_thrshld_pct, ")
			.append(" ef.qlty_scor_pct, ")
			.append(" ef.qlty_gate_ind, ")
			.append(" smhd.cmpst_type_desc ")
			.append(" from ")
			.append(" imprv_prov_grp_smry_fact ipgsf ")
			.append(" join erncntr_fact ef on ( ")
			.append(" IPGSF.MNTH_ID = EF.MNTH_ID and ")
			.append(" ef.pgm_dim_key = ipgsf.pgm_dim_key and ")
			.append(" ef.prov_grp_dim_key = ipgsf.prov_grp_dim_key and ")
			.append(" ipgsf.msrmnt_prd_strt_dt = ef.msrmnt_prd_strt_dt ")
			.append(" ) ")
			.append(" join pgm_dim pgm on ( ")
			.append(" ipgsf.pgm_dim_key = pgm.pgm_dim_key ")
			.append(" ) ")
			.append(" join prov_grp_dim pg on ( ")
			.append(" ipgsf.prov_grp_dim_key = pg.prov_grp_dim_key ")
			.append(" ) ")
			.append(" join scrcrd_pgm_msr_hrchy_fact spmhf on ( ")
			.append(" ipgsf.pgm_dim_key = spmhf.pgm_dim_key  and ")
			.append(" ipgsf.mnth_id = spmhf.mnth_id and ")
			.append(" ipgsf.msrmnt_prd_strt_dt = spmhf.msrmnt_prd_strt_dt ")
			.append(" ) ")
			.append(" join scrcrd_msr_hrchy_dim smhd on ( ")
			.append(" spmhf.scrcrd_msr_hrchy_dim_key = smhd.scrcrd_msr_hrchy_dim_key and ")
			.append(" ipgsf.scrcrd_msr_hrchy_dim_key = smhd.scrcrd_msr_hrchy_dim_key ")
			.append(" ) ")
			.append(" where ")
			.append(" pgm.pgm_id = ? and ")
			.append(" ipgsf.msrmnt_prd_strt_dt = ? and ")
			.append(" pg.prov_grp_id = ?   ")
			.append(" and  spmhf.pgm_lob_type_cd = ? ");

		if (null != Constants.getQuarterName(request
			.getMeasurementInterval())) {
			if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
				sql.append(" AND ipgsf.BSLN_SCRCRD_IND = 'Y' ");
			}
			else {
				sql.append(" AND ipgsf.QTR_ID = '"
					+ Constants.getQuarterName(request
						.getMeasurementInterval()) + "' ");
			}
		}
		else {
			sql.append(" AND ipgsf.MNTH_ID = (SELECT MAX(IPGSF.MNTH_ID) FROM IMPRV_PROV_GRP_SMRY_FACT IPGSF INNER JOIN "
				+ " (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT FROM SCRCRD_PGM_MSR_HRCHY_FACT WHERE  ");
			//+" PGM_DIM_KEY=(SELECT PGM_DIM_KEY FROM PROV_GRP_PGM_LOB_FACT WHERE PGM_ID = ? and PGM_PG_TRMNTN_DT > CURRENT_DATE GROUP BY PGM_DIM_KEY) "
			sql.append(" 		 PGM_DIM_KEY = (SELECT PGM_DIM_KEY FROM PROV_GRP_PGM_LOB_FACT A ");
			sql.append(" 		inner join   PROV_GRP_DIM B ON A.PROV_GRP_DIM_KEY=B.PROV_GRP_DIM_KEY and  B.PROV_GRP_ID = ?");
			sql.append("		WHERE A.PGM_ID = ? and A.PGM_PG_TRMNTN_DT > CURRENT_DATE GROUP BY A.PGM_DIM_KEY) "
				+ "  and  MSRMNT_PRD_STRT_DT = ? "
				+ " GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM "
				+ " ON IPGSF.PGM_DIM_KEY=SC_PGM.PGM_DIM_KEY AND IPGSF.MSRMNT_PRD_STRT_DT=SC_PGM.MSRMNT_PRD_STRT_DT) ");
			//+" and (select max(ef.mnth_id)MAX_MON from IMPRV_PROV_GRP_SMRY_FACT ef join PGM_DIM pd on ef.pgm_dim_key = pd.pgm_dim_key where pd.pgm_id = ? ) <=  INT(TO_CHAR(ef.msrmnt_prd_strt_dt + 15 months, 'YYYYMM')) " );
			sql.append(" and (select max(ef.mnth_id)MAX_MON from ERNCNTR_FACT ef join PGM_DIM pd on ef.pgm_dim_key = pd.pgm_dim_key where pd.pgm_id = ? ) <=  INT(TO_CHAR(ef.msrmnt_prd_strt_dt + 15 months, 'YYYYMM')) ");
		}
		sql.append(
			" group by smhd.CMPST_NM ,smhd.CMPST_DEFN_ID, smhd.CMPST_TYPE_DESC,ipgsf.rdstrbtd_erncntr_pct,ipgsf.rdstrbtd_ssav_upsd_dstrbtn_pct,smhd.msr_dim_key, ef.qlty_gate_thrshld_pct, ef.qlty_scor_pct, ef.qlty_gate_ind ")
			.append(") group by cmpst_nm,cmpst_defn_id, cmpst_type_desc, qlty_gate_thrshld_pct, qlty_scor_pct, qlty_gate_ind");

		return sql;
	}

}
