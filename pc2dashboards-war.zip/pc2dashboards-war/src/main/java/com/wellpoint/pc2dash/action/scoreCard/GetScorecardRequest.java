package com.wellpoint.pc2dash.action.scoreCard;

import com.wellpoint.pc2dash.data.dto.PCMSRequest;

public class GetScorecardRequest extends PCMSRequest {

}
