package com.wellpoint.pc2dash.action.tooltip;

import com.wellpoint.pc2dash.data.dto.PopulationManagementRequest;

public class GetTherapeuticClassesToolTipRequest extends PopulationManagementRequest {

	private String drugClassCode;

	/**
	 * @return the drugClassCode
	 */
	public String getDrugClassCode() {
		return drugClassCode;
	}

	/**
	 * @param drugClassCode the drugClassCode to set
	 */
	public void setDrugClassCode(String drugClassCode) {
		this.drugClassCode = drugClassCode;
	}



}
