package com.wellpoint.pc2dash.action.base;


public class ActionRequest {

	String userId;
	String json;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getJson() {
		return json;
	}

	public void setJson(String json) {
		this.json = json;
	}
}
