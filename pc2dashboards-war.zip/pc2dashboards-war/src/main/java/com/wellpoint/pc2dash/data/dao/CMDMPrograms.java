package com.wellpoint.pc2dash.data.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.cmdm.GetCMDMProgramsRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.patient.cmdm.CMDMFilter;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;

public class CMDMPrograms extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(CMDMPrograms.class);
	private static final String CASE_MGMT_SET_NM = "Case Mgmnt PGM name"; // cd_dim.cd_set_nm
	private static final String DISEASE_MGMT_SET_NM = "Dseas Mgmnt PGM name"; // cd_dim.cd_set_nm

	public List<CMDMFilter> getCMDMPrograms(GetCMDMProgramsRequest request) throws Exception {
		List<CMDMFilter> result = new ArrayList<CMDMFilter>();

		String sql = "select "
			+ " cd.cd_dim_key "
			+ ", cd.cd_set_nm "
			+ ", cd.cd_val_nm "
			+ " from cd_dim cd "
			+ " where cd.cd_set_nm in (?,?) "
			+ " group by "
			+ " cd.cd_dim_key "
			+ ", cd.cd_set_nm "
			+ ", cd.cd_val_nm "
			+ " order by cd.cd_val_nm "
			+ " with ur ";

		try {
			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, sql);
			ps.setString(++i, CASE_MGMT_SET_NM);
			ps.setString(++i, DISEASE_MGMT_SET_NM);

			executeQuery(logger, sql);
			result = convertSelectedRowsToObjects();

		}
		catch (Exception e) {
			throw new Exception("Exception during getCMDMPrograms (" + request.toString() + ").", e);
		}
		finally {

			close();
		}

		return result;

	}

	/**
	 * 3 levels: Root --> CM/DM branches --> Program name
	 */
	protected List<CMDMFilter> convertSelectedRowsToObjects() throws SQLException {
		// Prepare to store the CM/DM programs (will populate in the while loop)
		List<CMDMFilter> cmPrograms = new ArrayList<CMDMFilter>();
		List<CMDMFilter> dmPrograms = new ArrayList<CMDMFilter>();

		// Build the CM branch and the DM branch so they exist at decision time in the while loop 
		// (2nd level)
		List<CMDMFilter> cmBranch = new ArrayList<CMDMFilter>();
		CMDMFilter cmRoot = new CMDMFilter();
		cmRoot.setId("1"); // arbitrary
		cmRoot.setText("Case Management (CM)");
		cmRoot.setLeaf(false);
		cmRoot.setChildren(cmPrograms);
		cmBranch.add(cmRoot);

		List<CMDMFilter> dmBranch = new ArrayList<CMDMFilter>();
		CMDMFilter dmRoot = new CMDMFilter();
		dmRoot.setId("2"); // arbitrary
		dmRoot.setText("Disease Management (DM)");
		dmRoot.setLeaf(false);
		dmRoot.setChildren(dmPrograms);
		dmBranch.add(dmRoot);

		// Build the Program nodes (3rd level)
		// Prepare to store the various items and their ids/texts
		CMDMFilter program = null;
		while (rs.next()) {
			program = new CMDMFilter();
			program.setId(rs.getString("cd_dim_key"));
			program.setText(rs.getString("cd_val_nm"));
			program.setLeaf(true);
			program.setChildren(new ArrayList<CMDMFilter>()); // UI wants it empty, but not null

			if (rs.getString("cd_set_nm").equalsIgnoreCase(CASE_MGMT_SET_NM)) {
				cmPrograms.add(program);
			}
			else {
				dmPrograms.add(program);
			}
		}

		// Build the "children" of the root node (1st level - to be assigned in the Action class)
		List<CMDMFilter> rootChildren = new ArrayList<CMDMFilter>();
		rootChildren.addAll(cmBranch);
		rootChildren.addAll(dmBranch);

		return rootChildren;
	}

	@Override
	public boolean read(Dto o) throws Exception {

		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {


	}

	@Override
	public void update(Dto o) throws Exception {


	}

	@Override
	public void delete(Dto o) throws Exception {


	}


}
