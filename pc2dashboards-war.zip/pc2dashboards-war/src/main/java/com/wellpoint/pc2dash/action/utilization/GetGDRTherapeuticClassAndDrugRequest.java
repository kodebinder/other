package com.wellpoint.pc2dash.action.utilization;

import com.wellpoint.pc2dash.action.drilldown.GetDrillDownRequest;

public class GetGDRTherapeuticClassAndDrugRequest extends GetDrillDownRequest {
	protected String subCompositeName;

	public String getSubCompositeName() {
		return subCompositeName;
	}

	public void setSubCompositeName(String subCompositeName) {
		this.subCompositeName = subCompositeName;
	}



}
