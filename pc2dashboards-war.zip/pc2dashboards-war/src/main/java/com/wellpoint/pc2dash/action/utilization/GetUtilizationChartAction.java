package com.wellpoint.pc2dash.action.utilization;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.quality.GetQualityAction;
import com.wellpoint.pc2dash.action.quality.GetQualityResponse;
import com.wellpoint.pc2dash.data.dao.UtilizationCharts;
import com.wellpoint.pc2dash.data.dao.UtilizationGDRCharts;
import com.wellpoint.pc2dash.data.dao.UtilizationNFCRCharts;
import com.wellpoint.pc2dash.dto.drillDown.DrillDownChart;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetUtilizationChartAction extends GetQualityAction {

	ActionResponse response = new GetQualityResponse();

	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		GetUtilizationChartRequest request = (GetUtilizationChartRequest) actionRequest;
		List<String> filteredProvGrpList = new ArrayList<String>();
		List<DrillDownChart> resultList = new ArrayList<DrillDownChart>();

		try {
			request = (GetUtilizationChartRequest) cleanRequest(request);

			if (StringUtil.isJson(request)) {

				//PCMSRequest request = getDataMap((GetDrillDownRequest) actionRequest);
				//Kill switch check on Provider groups
				if (null != request) {
					filteredProvGrpList = filterProvGrpsByKillSwitch(request);
				}

				//Clinical access check on provider groups
				if (null != request && null != filteredProvGrpList && filteredProvGrpList.size() > 0) {
					filteredProvGrpList = filterProvGrpsByClinicalInd(request, filteredProvGrpList);
				}


				if (null != filteredProvGrpList && !filteredProvGrpList.isEmpty()) {
					request.setProvGrpIds(StringUtils.join(filteredProvGrpList, ','));
					request.setGrpInd(Constants.GRP_IND_N);

					/**
					 * Release 1.9 <DF WLPRD02524865> <AD12140> | START
					 * Updating the logic based on the defect WLPRD02524865 and as per the suggestion from Vishal J. to drive scorecard based on
					 * PGM_LOB_TYPE_CD and not on lob
					 */
					String pgmLobTypeCode = request.getProgramLobTypeCd() == null ? null : request.getProgramLobTypeCd().toUpperCase();

					if (StringUtils.isNotBlank(pgmLobTypeCode)
						&& pgmLobTypeCode.contains(Constants.COMMERCIAL.toUpperCase())
						)
					/** Release 1.9 <DF WLPRD02524865> <AD12140> | END */
					{
						if (request.getMeasureName().contains(Constants.GDR)) {
							UtilizationGDRCharts dao = new UtilizationGDRCharts();
							resultList.addAll(dao.getUtilizationGDRChart(request));
						}
						else if (request.getMeasureName().contains(Constants.NFCR)) {
							UtilizationNFCRCharts dao = new UtilizationNFCRCharts();
							resultList.addAll(dao.getUtilizationNFCRChart(request));
						}
						else {
							UtilizationCharts dao = new UtilizationCharts();
							resultList.addAll(dao.getUtilizationChart(request));
						}

					}
					else
					{
						UtilizationCharts dao = new UtilizationCharts();
						resultList.addAll(dao.getUtilizationChart(request));
					}
				}

				response.setData(resultList);
				if (null == resultList || (null != resultList && resultList.isEmpty())) {
					response.setMessage(StringUtil.buildMessage(resultList.isEmpty()));
				}
				else {
					response.setTotal(resultList.size()); // calculates total without another query
					response.setMessage(StringUtil.buildMessage(resultList.isEmpty()));
				}

				response.setSuccess(true); // based on GetCareOpportunitiesPatientAction.process(), MW never returns "false"
			}
			// TODO else if for getDest() of xls?

		}
		catch (Exception e) {
			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(e, response);
		}

		return response;
	}

}
