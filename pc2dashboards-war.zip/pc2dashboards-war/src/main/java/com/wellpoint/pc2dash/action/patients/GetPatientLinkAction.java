package com.wellpoint.pc2dash.action.patients;

import com.google.gson.JsonObject;
import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.data.dao.Patients;
import com.wellpoint.pc2dash.data.dto.AuditEntry;
import com.wellpoint.pc2dash.data.dto.PatientLink;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.saml.LprConfig;
import com.wellpoint.pc2dash.saml.SamlResponse;
import com.wellpoint.pc2dash.util.CommonQueries;


public class GetPatientLinkAction extends Action {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetPatientLinkAction.class);

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetPatientLinkRequest request = (GetPatientLinkRequest) actionRequest;
		GetPatientLinkResponse response = new GetPatientLinkResponse();

		try {

			if (!request.isValid()) {
				throw new Exception("Missing required fields.");
			}

			Patients dao = new Patients();
			String mcId = dao.getMcId(request);

			LprConfig cfg = new LprConfig();
			cfg.setUserId(request.getUserId());
			cfg.setFirstName(request.getFirstName());
			cfg.setLastName(request.getLastName());
			cfg.setMemberId(mcId);
			cfg.setAttested(CommonQueries.checkAttestation(request));

			SamlResponse saml = new SamlResponse(cfg);

			PatientLink link = new PatientLink();
			//link.setAttested(cfg.isAttested()); Commented out the code to support new UI for attestation
			link.setUrl(cfg.getEndpoint());
			link.setToken(saml.encode());

			JsonObject jsonObject = new JsonObject();
			jsonObject.addProperty("attested", cfg.isAttested());
			//R2.0 | AC94408 | Added for Attest Logic
			response.setMetaData(jsonObject);

			response.setData(link);
			response.setSuccess(true);
		}
		catch (Exception e) {

			logger.error("Unable to create SAML response.", e);

			response.setMessage("Unable to get patient link.");
			response.setSuccess(false);
		}

		return response;
	}

}
