package com.wellpoint.pc2dash.action.dashboard;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetTickersForHomePageActionResponse extends ActionResponse {

}
