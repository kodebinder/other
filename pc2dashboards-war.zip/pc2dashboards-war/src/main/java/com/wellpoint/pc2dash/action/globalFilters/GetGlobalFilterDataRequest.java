package com.wellpoint.pc2dash.action.globalFilters;

import com.wellpoint.pc2dash.data.dto.PCMSRequest;

public class GetGlobalFilterDataRequest extends PCMSRequest {

}
