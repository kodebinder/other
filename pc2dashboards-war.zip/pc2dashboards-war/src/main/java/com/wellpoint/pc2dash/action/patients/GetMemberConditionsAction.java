package com.wellpoint.pc2dash.action.patients;

import java.util.List;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.patient.MemberConditions;
import com.wellpoint.pc2dash.dto.tinNpi.UserAcsIndicators;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.service.patient.MemberConditionServiceImpl;
import com.wellpoint.pc2dash.util.ErrorProperties;

public class GetMemberConditionsAction extends Action {
	List<MemberConditions> resultList;
	ActionResponse response = new GetMemberConditionsResponse();
	ErrorProperties err = ErrorProperties.getInstance();

	@SuppressWarnings("unchecked")
	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		//PCMSRequest request = new HashMap<String, String>();
		MemberConditionServiceImpl pC2Service = new MemberConditionServiceImpl();
		GetMemberConditionsRequest request = (GetMemberConditionsRequest) actionRequest;
		//		JsonArray userAcsInfo = request.getUserAcsInfoJson();
		List<UserAcsIndicators> userAcsInfo = request.getUserAcsInfoJson();

		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < userAcsInfo.size(); i++) {
			if (i != userAcsInfo.size() - 1) {
				sb.append(userAcsInfo.get(i).getProvGrpId()).append(',');
			}
			else {
				sb.append(userAcsInfo.get(i).getProvGrpId());
			}
		}

		request.setProvGrpIds(sb.toString());
		try {
			resultList = pC2Service.getData(request);

			response.setData(resultList);
			response.setSuccess(true);
			if (resultList.isEmpty()) {
				response.setMessage(err.getProperty("successNoData"));
			}
			else {
				response.setMessage(err.getProperty("successful"));
			}
			return response;
		}
		catch (Exception pe) {
			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}
}
