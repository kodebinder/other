package com.wellpoint.pc2dash.action.dashboard;

import com.wellpoint.pc2dash.data.dto.PopulationManagementRequest;

public class GetRefreshFrequencyRequest extends PopulationManagementRequest {

	protected String view;

	public String getView() {
		return view;
	}

	public void setView(String view) {
		this.view = view;
	}
}
