package com.wellpoint.pc2dash.action.perfSummTickers;

import java.util.ArrayList;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetCommercialTickersAction extends Action {

	ActionResponse commercialTickersRespObj = new GetCommercialTickersResponse();

	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		commercialTickersRespObj.setMessage("No functionality");
		commercialTickersRespObj.setData(new ArrayList());
		commercialTickersRespObj.setSuccess(true);
		return commercialTickersRespObj;
	}

}
