package com.wellpoint.pc2dash.action.inactivePatients;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.dto.patient.MstrCnsmrFactAndOthers;
import com.wellpoint.pc2dash.exception.PC2Exception;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportGridColumn;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.population.InactivePatientExport;
import com.wellpoint.pc2dash.service.inactivePatients.InactivePatientsServiceImpl;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;


public class GetInactivePatientsAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetInactivePatientsRequest request = (GetInactivePatientsRequest) actionRequest;
		GetInactivePatientsResponse response = new GetInactivePatientsResponse();
		InactivePatientsServiceImpl service = new InactivePatientsServiceImpl();
		ErrorProperties err = ErrorProperties.getInstance();

		List<String> grps = null;

		try {

			removeLobPgmPrefixes(request);

			if (StringUtils.isNotBlank(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			prepareRASuppressionCond(request);
			prepareLPRSuppressionCond(request);

			if (null != grps && !grps.isEmpty()) {

				request.setProvGrpIdsWithoutClinicalCheck(StringUtils.join(grps, ','));
				grps = filterProvGrpsByClinicalInd(request, grps);
				request.setProvGrpIds(StringUtils.join(grps, ','));
			}

			if (null != grps && !grps.isEmpty()) {

				if (StringUtil.isExportDest(request.getDest())) {

					processExportData(request, service);
				}
				else {

				    processNonExportData(request, response, service, err);
				}
			}

			response.setSuccess(true);
			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}

  /**
   * @param request
   * @param response
   * @param service
   * @param err
   * @throws Exception
   */
  private void processNonExportData(GetInactivePatientsRequest request,
      GetInactivePatientsResponse response, InactivePatientsServiceImpl service,
      ErrorProperties err) throws Exception {
    List<MstrCnsmrFactAndOthers> resultList = service.getData(request);
MetaData metaData = buildMetaData(request, service);

if (null != resultList && !resultList.isEmpty()) {

    response.setData(service.getBeanList(resultList, request));
    response.setMetaData(metaData);
    response.setMessage(err.getProperty("successful"));
    response.setTotal(service.getRowCount());
}
else {

    response.setMessage(err.getProperty("successNoData"));
}
  }

  /**
   * @param request
   * @param service
   * @throws PC2Exception
   */
  private void processExportData(GetInactivePatientsRequest request,
      InactivePatientsServiceImpl service) throws PC2Exception {
    List<ExportGridColumn> columns = service.buildExportGridColumns(request);
    InactivePatientExport exp = new InactivePatientExport(request, columns);

    ExportProcessor.getInstance().submit(exp);
  }
}
