package com.wellpoint.pc2dash.action.dashboard;



import com.wellpoint.pc2dash.data.dto.PCMSRequest;


public class GetTickersForHomePageActionRequest extends PCMSRequest {

}
