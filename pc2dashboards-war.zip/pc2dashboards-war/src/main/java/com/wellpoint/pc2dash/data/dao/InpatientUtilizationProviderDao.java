package com.wellpoint.pc2dash.data.dao;

import com.wellpoint.pc2dash.data.Dto;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.costOpportunity.GetInpatientUtilizationProviderRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.costOpportunity.InpatientUtilizationProviderBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class InpatientUtilizationProviderDao extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(InpatientUtilizationProviderDao.class);

	@Override
	public boolean read(Dto o) throws Exception {

		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {


	}

	@Override
	public void update(Dto o) throws Exception {


	}

	@Override
	public void delete(Dto o) throws Exception {


	}

	public List<InpatientUtilizationProviderBean> getData(GetInpatientUtilizationProviderRequest request, boolean exportFlag, int index, int limit) throws Exception {

		List<InpatientUtilizationProviderBean> result = new ArrayList<InpatientUtilizationProviderBean>();
		setRowCount(0);



		StringBuilder query =
			new StringBuilder()
				.append(" select c.* ")
				.append(" from( ")
				.append(" select   b.*, row_number() over( order by  ")
				.append(buildSortClause(request))
				.append(" ) as row_nbr ")
				.append(" from( ")
				.append(" select ")
				.append(" a.provider_frst_nm, ")
				.append(" a.provider_last_nm, ")
				.append(" a.IPDIMKEY, ")
				.append(" a.PROVORGDIMKEY, ")
				.append(" a.OrganizationName, ")
				.append(" a.PROV_ORG_TAX_ID, ")
				.append(" a.IP_NPI, ")
				.append(" a.IP_SPCLTY_NM, ")
				.append(" a.tot_ip_day, ")
				.append(" a.members_with_condition, ")
				.append(" a.total_admissions, ")
				.append(" a.average_length_stay, ")
				/*.append(" a.curr_perf_rate, ")
				.append(" a.days_ovr_bnchmrk, ")
				.append(" a.admit_abv_bnchmrk, ")
				.append(" a.lngth_abv_bnchmrk, ")*/
				.append(" a.row_cnt as row_cnt ")
				.append(" from(  ")
				.append(" SELECT SMRY.IP_FRST_NM as provider_frst_nm, ")
				.append(" SMRY.IP_LAST_NM as provider_last_nm, ")
				.append(" SMRY.IP_DIM_KEY as IPDIMKEY, ")
				.append(" SMRY.PROV_ORG_DIM_KEY as PROVORGDIMKEY, ")
				.append(" SMRY.PROV_ORG_FULL_NM as OrganizationName, ")
				.append(" SMRY.PROV_ORG_TAX_ID as PROV_ORG_TAX_ID, ")
				.append(" SMRY.IP_NPI IP_NPI, ")
				.append(" cd.cd_val_nm IP_SPCLTY_NM, ")
				.append(" sum(SMRY.TC_INPAT_DAY_CNT)  as tot_ip_day, ")
				/*.append(
					"  case when sum(SMRY.MBR_MNTH_CNT)>0 then (cast (sum(SMRY.INPAT_DAY_CNT) as decimal(18,4)) / cast( sum(SMRY.MBR_MNTH_CNT) as decimal(18,4)))*12000 else 0.00 end as curr_perf_rate , ")
				.append(" sum(SMRY.DAY_OVER_BNCHMRK) as days_ovr_bnchmrk, ")
				.append(" sum(SMRY.ADMT_ABV_BNCHMRK) as admit_abv_bnchmrk, ")
				.append(" sum(SMRY.LGTH_STAY_ABV_BNCHMRK) as lngth_abv_bnchmrk, ")*/
				.append(" SUM(SMRY.MBR_CNDTN_CNT) as members_with_condition, ")
				.append(" SUM(SMRY.ADMT_CNT) as total_admissions, ")
				.append(" (CASE WHEN SUM(SMRY.ADMT_CNT) >0 THEN (SUM(SMRY.TC_INPAT_DAY_CNT) / CAST (SUM(SMRY.ADMT_CNT) AS decimal (18,1))) ELSE 0.0 END ) as average_length_stay, ") 
				.append(" count(*) over () as row_cnt ")
				.append(" FROM COC_IP_UTL_CTGRY_SMRY AS SMRY ")
				.append(" join   IP_DIM ip on ( ip.ip_dim_key = smry.ip_dim_key ) ")
				.append(" join  cd_dim cd on ( cd.cd_dim_key = ip.SPCLTY_CD_DIM_KEY) ")
				.append(" join  poit_user_scrty_acs pusa on (smry.prov_grp_id = pusa.prov_grp_id ")
				.append(" and case when    pusa.prov_org_tax_id = '0' ")
				.append(" then    smry.prov_org_tax_id  ")
				.append(" else    pusa.prov_org_tax_id end = smry.prov_org_tax_id) ")
				.append(" where  pusa.sesn_id = ?  ")
				.append(" and  pusa.enttlmnt_hash_key = ? ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and smry.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and smry.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and smry.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and smry.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and smry.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}

		//PCMSP-12621 : Starts
		if (StringUtil.isNotBlankOrFalse(request.getCategoryCode())) {
			query.append(" and smry.SUB_MTRC_CD in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getCategoryCode())
				+ ") ");
		}
		//PCMSP-12621 : Ends

		query.append(" group by SMRY.IP_FRST_NM, ")
			.append(" SMRY.IP_LAST_NM, ")
			.append(" SMRY.PROV_ORG_DIM_KEY, ")
			.append(" SMRY.IP_DIM_KEY, ")
			.append(" SMRY.PROV_ORG_TAX_ID, ")
			.append(" SMRY.PROV_ORG_FULL_NM, ")
			.append(" SMRY.IP_NPI, ")
			.append(" cd.cd_val_nm) ")
			.append(" a)b)c ")
			.append(" where c.row_nbr between ? ")
			.append(" and ? ")
			.append(" order by c.row_nbr  with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());

			buildPreparedStatement(request, i, exportFlag, index, limit);

			executeQuery(logger, query.toString());

			result = convertSelectedRowsToObjects(rs, request, false, exportFlag);

		}
		catch (Exception e) {

			throw new Exception("Unable to get InpatientUtilizationProviderDao (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;

	}


	private void buildPreparedStatement(GetInpatientUtilizationProviderRequest request, int i, boolean exportFlag, int index, int limit) throws SQLException {

		int start = 0;
		int stop = 0;

		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		//PCMSP-12621 : Starts
		if (StringUtil.isNotBlankOrFalse(request.getCategoryCode())) {
			String[] array = request.getCategoryCode().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		//PCMSP-12621 : Ends


		if (!exportFlag) {
			start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
			stop = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
		}
		else {
			start = index;
			stop = limit;
		}
		ps.setInt(++i, start + 1);
		ps.setInt(++i, start + stop);

	}

	private List<InpatientUtilizationProviderBean> convertSelectedRowsToObjects(ResultSet rs, GetInpatientUtilizationProviderRequest request, boolean displayDashes,
		boolean exportFlag)
		throws SQLException {

		List<InpatientUtilizationProviderBean> list = new ArrayList<InpatientUtilizationProviderBean>();
		if (exportFlag) {
			while (rs.next()) {
				InpatientUtilizationProviderBean item = new InpatientUtilizationProviderBean();
				//Changed for release-Q1-2018/PCMSP-18421 : Starts
				item.setAttributedPhysicianName(CommonQueries.getFilteredProviderName(rs.getString("provider_frst_nm"),rs.getString("provider_last_nm")));				
				//Changed for release-Q1-2018/PCMSP-18421 : Ends
				if (rs.getString("IP_NPI") != null) {
					item.setAttributedProvNpi(StringUtil.getValueOrDashes(rs.getString("IP_NPI")));
				}
				if (rs.getString("IP_SPCLTY_NM") != null) {
					item.setAttributedProvSpeciality(StringUtil.getValueOrDashes(rs.getString("IP_SPCLTY_NM")));
				}

				item.setProviderId(StringUtil.buildUniqueProviderId(rs.getString("ipDimKey"), rs.getString("provOrgDimKey")));

				if (rs.getString("OrganizationName") != null) {
					item.setOrganizationName(rs.getString("OrganizationName"));
				}
				if (null != rs.getString("PROV_ORG_TAX_ID")) {
					item.setOrgTin(rs.getString("PROV_ORG_TAX_ID"));
				}

				if (rs.getString("tot_ip_day") != null) {
					item.setTotalInpatientDays(StringUtil.convertStringToCommaBigDecimal(
						rs.getBigDecimal("tot_ip_day").setScale(0, BigDecimal.ROUND_HALF_UP).toString(), 0));
				}
				
				/*if (rs.getString("curr_perf_rate") != null) {
					item.setCurrentPerformanceRate(StringUtil.convertStringToCommaBigDecimal(
						rs.getBigDecimal("curr_perf_rate").setScale(2, BigDecimal.ROUND_HALF_UP).toString(), 2));
				}
				if (rs.getString("days_ovr_bnchmrk") != null) {
					item.setDaysOverBenchmark(StringUtil.convertStringToCommaBigDecimal(
						rs.getBigDecimal("days_ovr_bnchmrk").setScale(0, BigDecimal.ROUND_HALF_UP).toString(), 0));
				}
				if (rs.getString("admit_abv_bnchmrk") != null) {
					item.setNumberOfAdmitsAboveBenchmark(StringUtil.convertStringToCommaBigDecimal(
						rs.getBigDecimal("admit_abv_bnchmrk").setScale(0, BigDecimal.ROUND_HALF_UP).toString(), 0));
				}

				if (null != rs.getBigDecimal("lngth_abv_bnchmrk")) {
					item.setLengthOfStayAboveBenchmark(
						StringUtil.convertStringToCommaBigDecimal(rs.getBigDecimal("lngth_abv_bnchmrk").setScale(0, BigDecimal.ROUND_HALF_UP).toString(), 0));
				}*/
				
				if (rs.getString("members_with_condition") != null) {
					item.setMembersWithCondition(StringUtil.convertStringToCommaBigDecimal(
						rs.getBigDecimal("members_with_condition").setScale(0, BigDecimal.ROUND_HALF_UP).toString(), 0));
				}
				if (rs.getString("total_admissions") != null) {
					item.setTotalAdmissions(StringUtil.convertStringToCommaBigDecimal(
						rs.getBigDecimal("total_admissions").setScale(0, BigDecimal.ROUND_HALF_UP).toString(), 0));
				}
				if (rs.getString("average_length_stay") != null) {
					item.setAverageLengthOfStay(StringUtil.convertStringToCommaBigDecimal(
						rs.getBigDecimal("average_length_stay").setScale(1, BigDecimal.ROUND_HALF_UP).toString(), 1));
				}
				list.add(item);

				if (getRowCount() == 0) {
					setRowCount(rs.getInt("row_cnt"));
				}
				setTotalExport(rs.getInt("row_cnt"));
			}
		}
		else {
			while (rs.next()) {

				InpatientUtilizationProviderBean item = new InpatientUtilizationProviderBean();

				//Changed for release-Q1-2018/PCMSP-18421 : Starts
				item.setAttributedPhysicianName(CommonQueries.getFilteredProviderName(rs.getString("provider_frst_nm"),rs.getString("provider_last_nm")));				
				//Changed for release-Q1-2018/PCMSP-18421 : Ends
				item.setProviderId(StringUtil.buildUniqueProviderId(rs.getString("ipDimKey"), rs.getString("provOrgDimKey")));
				
				if (null != rs.getString("OrganizationName")) {
					item.setOrganizationName(rs.getString("OrganizationName"));
				}

				if (null != rs.getString("PROV_ORG_TAX_ID")) {
					item.setOrgTin(rs.getString("PROV_ORG_TAX_ID"));
				}

				if (null != rs.getString("tot_ip_day")) {
					item.setTotalInpatientDays(rs.getString("tot_ip_day"));
				}

				/*if (null != rs.getString("curr_perf_rate")) {
					item.setCurrentPerformanceRate((rs.getString("curr_perf_rate")));
				}

				if (null != rs.getString("days_ovr_bnchmrk")) {
					item.setDaysOverBenchmark(rs.getString("days_ovr_bnchmrk"));
				}

				if (null != rs.getString("admit_abv_bnchmrk")) {
					item.setNumberOfAdmitsAboveBenchmark(rs.getString("admit_abv_bnchmrk"));
				}

				if (null != rs.getString("lngth_abv_bnchmrk")) {
					item.setLengthOfStayAboveBenchmark(rs.getString("lngth_abv_bnchmrk"));
				}*/
				
				if (null != rs.getString("members_with_condition")) {
					item.setMembersWithCondition(rs.getString("members_with_condition"));
				}
				
				if (null != rs.getString("total_admissions")) {
					item.setTotalAdmissions(rs.getString("total_admissions"));
				}
				
				if (null != rs.getString("average_length_stay")) {
					item.setAverageLengthOfStay(StringUtil.convertStringToCommaBigDecimal(
						rs.getBigDecimal("average_length_stay").setScale(1, BigDecimal.ROUND_HALF_UP).toString(), 1));
				}
				
				item.setHasDetailsDrilldownInd(request.isHasDetailsDrilldownInd());
				list.add(item);

				if (getRowCount() == 0) {
					setRowCount(rs.getInt("row_cnt"));
				}

			}
		}
		return list;

	}

	private String buildSortClause(GetInpatientUtilizationProviderRequest request) {

		StringBuilder query = new StringBuilder();
		//changed for PCMSP-16222 : Starts
		//String defaultColumn = " provider_last_nm ASC,  provider_frst_nm ";
		//String defaultSort = defaultColumn + " ASC ";
		String defaultColumn = " tot_ip_day ";
		String defaultSort = defaultColumn + " DESC ";
		
		//changed for PCMSP-16222 : Ends

		if (null != request.getSort()) {

			for (QuerySort sort : request.getSort()) {

				String dir = sort.getDirection().replaceAll("\"", "");
				String property = sort.getProperty();

				if (property.equals("attributedPhysicianName")) {
					query.append(" provider_last_nm " + dir + ", " + " provider_frst_nm " + dir + ", " + defaultSort);
				}
				else if (property.equals("organizationName")) {
					query.append(" OrganizationName " + dir + ", " + defaultSort);
				}
				else if (property.equals("totalInpatientDays")) {
					query.append(" tot_ip_day " + dir );
				}
				/*else if (property.equals("currentPerformanceRate")) {
					query.append(" curr_perf_rate " + dir + ", " + defaultSort);
				}
				else if (property.equals("daysOverBenchmark")) {
					query.append(" days_ovr_bnchmrk " + dir + ", " + defaultSort);
				}
				else if (property.equals("numberOfAdmitsAboveBenchmark")) {
					query.append(" admit_abv_bnchmrk " + dir + ", " + defaultSort);
				}
				else if (property.equals("lengthOfStayAboveBenchmark")) {
					query.append(" lngth_abv_bnchmrk " + dir + ", " + defaultSort);
				}*/
				else if (property.equals("membersWithCondition")) {
					query.append(" members_with_condition " + dir + ", " + defaultSort);
				}
				else if (property.equals("totalAdmissions")) {
					query.append(" total_admissions " + dir + ", " + defaultSort);
				}
				else if (property.equals("averageLengthOfStay")) {
					query.append(" average_length_stay " + dir + ", " + defaultSort);
				}
				else {
					query.append(defaultSort);
				}
			}

		}
		else {
			query.append(defaultSort);
		}

		return query.toString();

	}

}
