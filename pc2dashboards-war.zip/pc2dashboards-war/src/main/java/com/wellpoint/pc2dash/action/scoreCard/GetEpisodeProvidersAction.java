package com.wellpoint.pc2dash.action.scoreCard;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.data.dao.EpisodesProvidersDao;
import com.wellpoint.pc2dash.dto.scorecard.EpisodesPatientGrid;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportGridColumn;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.scorecard.commercial.EpisodeProvidersExport;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetEpisodeProvidersAction extends Action{

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetEpisodeProvidersRequest request = (GetEpisodeProvidersRequest) actionRequest;
		ActionResponse response = new GetEpisodeProvidersResponse();
		ErrorProperties err = ErrorProperties.getInstance();

		List<EpisodesPatientGrid> resultList = new ArrayList<EpisodesPatientGrid>();
		EpisodesProvidersDao dao = new EpisodesProvidersDao();
		List<String> grps = null;

		try {

			removeLobPgmPrefixes(request);

			if (StringUtils.isNotBlank(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}
			
			


			if (null != grps && grps.size() > 0) {
				grps = filterProvGrpsByClinicalInd(request, grps);
			}

			// RA Action Menu Suppression
			prepareRASuppressionCond(request);

			// R1.9|LPR Suppression 61461|AD91912
			prepareLPRSuppressionCond(request);

			/*
			 * Determine whether Action Center is suppressed - it'll play a part in deciding whether to display
			 * the "i" icon in all of the Clinical Programs columns in Population Management and
			 * Performance Management drill-downs.
			 */
			CommonQueries cq = new CommonQueries();
			request.setGroupsWithActionCenterSuppressed(cq.getGroupsWithComponentSuppressed(request, Constants.AC_RF_CARDCONTAINER));

			if (StringUtil.isExportDest(request.getDest())) {

				List<ExportGridColumn> columns = dao.buildExportGridColumns(request);
				EpisodeProvidersExport exp = new EpisodeProvidersExport(request, columns);
				ExportProcessor.getInstance().submit(exp);

			}
			else {

				if (null != grps && !grps.isEmpty()) {

					resultList = dao.getProviderGrid(request, Constants.BOOL_FALSE, 0, 0);

					MetaData metaData = buildMetaData(request, dao);

					if (null == resultList || resultList.isEmpty()) {
						response.setMessage(err.getProperty("successNoData"));
					}
					else {
						response.setMetaData(metaData);
						response.setMessage(err.getProperty("successful"));
						response.setData(resultList);
						response.setTotal(dao.getRowCount());
					}
				}
			}

			response.setSuccess(true);
			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

	}

}
