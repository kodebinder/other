package com.wellpoint.pc2dash.data.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.costOpportunity.GetCostOpportunityLabProviderRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.costOpportunity.CostOpportunityLabProviderBean;
import com.wellpoint.pc2dash.dto.costOpportunity.MinimumCriteriaBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class CostOpportunityLabProviderDao extends ServiceImpl {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(CostOpportunityLabProviderDao.class);

	public List<CostOpportunityLabProviderBean> getData(GetCostOpportunityLabProviderRequest request, boolean exportFlag, int index, int limit) throws Exception {

		List<CostOpportunityLabProviderBean> result = new ArrayList<CostOpportunityLabProviderBean>();
		MinimumCriteriaBean minCrit = new MinimumCriteriaBean("unit_cnt", "coc_lab_prov_smry", "COC_LAB_MIN_LABS", null); // TODO If a change to this logic is requested, see AmbulatorySurgeryProviderDao for an example
		setRowCount(0);
		
		CommonQueries cq = new CommonQueries();
		boolean displayDashes = cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request, minCrit);
		//PCMSP-10846 Minimum Criteria for Minimum Criteria
		String dashesClause = " sum(lsmry.unit_cnt) < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LAB_MIN_LABS' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG') "; 
		String dir = request.getSort().get(0).getDirection();
		String masked = "asc".equalsIgnoreCase(dir) ? String.valueOf(Integer.MAX_VALUE) : String.valueOf(Integer.MIN_VALUE); // we want masked values to always be at the bottom, so use either the biggest or smallest value, depending

		StringBuilder query = new StringBuilder()
			.append("select  b.* ")
			.append("from  ( ")
			.append("	select  a.*, ")
			.append("	row_number() over( order by ")
			.append(buildSortClause(request))
			.append(" ) as row_nbr ")
			.append("	from  ( ")
			.append("		select  ilv.prov_name, ")
			.append("			ilv.ip_dim_key, ")
			.append("			ilv.prov_org_dim_key, ")
			.append("			ilv.org_name, ")
			.append("           ilv.IP_SPCLTY_NM, ilv.ip_npi, ilv.PROV_ORG_TAX_ID, ")
			.append(" case when ilv.unit_count < 0 then 0.000 else ilv.unit_count end ").append(" as unit_count, ")
			.append(" case when ilv.percent_standard_rate < 0 then 0.000 else (ilv.percent_standard_rate)*100 end ").append(" as percent_standard_rate, ")
			.append(" case when ilv.non_par_lab_count < 0 then 0 else ilv.non_par_lab_count end ").append(" as non_par_lab_count, ") // PCMSP-8627
			.append(" case when ilv.total_lab_count < 0 then 0.000 else ilv.total_lab_count end ").append(" as total_lab_count, ")
			.append(" case when ilv.member_count < 0 then 0.000 else ilv.member_count end ").append(" as member_count, ")
			.append(" case when dsply_dashes = 'Y' then ").append(masked).append(" else ( ")
			.append(getMaskedOrActualValue(displayDashes, masked, " case when ilv.cost_opportunity < 0 then 0.000 else ilv.cost_opportunity end  ")).append(" ) end as cost_opportunity ")
			.append("			, ilv.row_cnt as row_cnt, dsply_dashes ")
			.append("		from ( ")
			.append("			select ")
			.append("				lsmry.prov_dsply_nm as prov_name ")
			.append("				, lsmry.ip_dim_key as ip_dim_key ")
			.append("				, lsmry.prov_org_dim_key as prov_org_dim_key ")
			.append("				, lsmry.prov_org_full_nm as org_name ")
			.append("				, sum(lsmry.unit_cnt) as unit_count ")
			.append("               , cd.cd_val_nm as IP_SPCLTY_NM, lsmry.ip_npi, lsmry.PROV_ORG_TAX_ID ")
			.append("				, case when  sum(lsmry.stndrd_rt_amt) > 0 then cast(sum(lsmry.totl_alwd_amt) as decimal(18,3))/cast(sum(lsmry.stndrd_rt_amt) as decimal(18,3)) else 0.000 end as percent_standard_rate ")
			//.append("				, sum(case when parg_cd = 'NON-PAR' then 1 else 0 end) as non_par_lab_count ")
			.append("               , count(distinct LSMRY1.LAB_TAX_ID) AS NON_PAR_LAB_COUNT ")
			.append("				, count(distinct lsmry.LAB_TAX_ID) as total_lab_count ")
			.append("				, sum(lsmry.mbr_cnt) as member_count ")
			.append("				, sum(lsmry.cost_oprtnty_amt) as cost_opportunity ")
			.append("				, count(*) over () as row_cnt, ")
			.append(" case when ")
			.append(dashesClause)
			.append(" then 'Y' else 'N' end as dsply_dashes ")
			.append("			from coc_lab_prov_smry lsmry ")
			.append("           LEFT JOIN COC_LAB_PROV_SMRY AS LSMRY1 ")
			.append("                   ON (LSMRY.PROV_GRP_DIM_KEY=LSMRY1.PROV_GRP_DIM_KEY ")
			.append("                  AND LSMRY.PROV_ORG_DIM_KEY = LSMRY1.PROV_ORG_DIM_KEY ")
			.append("                  AND LSMRY.PGM_DIM_KEY = LSMRY1.PGM_DIM_KEY ")
			.append("                  AND LSMRY.LOB_DIM_KEY = LSMRY1.LOB_DIM_KEY ")
			.append("                  AND LSMRY.IP_DIM_KEY = LSMRY1.IP_DIM_KEY ")
			.append("                  AND LSMRY.IP_NPI = LSMRY1.IP_NPI ")
			.append("                  AND LSMRY.CPT_CD = LSMRY1.CPT_CD ")
			.append("                  AND LSMRY.LAB_TAX_ID = LSMRY1.LAB_TAX_ID ")
			.append("                  and LSMRY.PROV_GRP_ID = LSMRY1.PROV_GRP_ID  ")
			.append("                  AND LSMRY.LOB_DESC = LSMRY1.LOB_DESC ")                              
			.append("                  AND LSMRY1.PARG_CD = 'NON-PAR') ")
			.append("           join  IP_DIM ip on ( ip.ip_dim_key = lsmry.ip_dim_key ) ")
			.append("           join  cd_dim cd on ( cd.cd_dim_key = ip.SPCLTY_CD_DIM_KEY) ")
			.append("			join poit_user_scrty_acs pusa on (lsmry.prov_grp_id = pusa.prov_grp_id ")
			.append("				and ")
			.append("				case ")
			.append("					when   pusa.prov_org_tax_id = '0' ")
			.append("					then   lsmry.prov_org_tax_id ")
			.append("					else   pusa.prov_org_tax_id ")
			.append("				end = lsmry.prov_org_tax_id) ")
			.append("			where	")
			.append("	 			pusa.sesn_id = ? ")
			.append("				and pusa.enttlmnt_hash_key = ? ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and lsmry.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and lsmry.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and lsmry.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and lsmry.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and lsmry.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}
		//PCMSP-20002
		if (StringUtil.isNotBlankOrFalse(request.getScorecardAnalysisOfDate())) {
			query.append(" and upper(lsmry.rpt_type_ind) = 'SC' ");
		}else{
			query.append(" and upper(lsmry.rpt_type_ind) = 'COC' ");
		}
		
		query.append("			group by lsmry.prov_dsply_nm, lsmry.ip_dim_key, lsmry.prov_org_dim_key, lsmry.prov_org_full_nm, lsmry.PROV_ORG_TAX_ID, lsmry.ip_npi, cd_val_nm  ")
			.append("		) as ilv ")
			.append("	) as a ")
			.append(") as b ");
		
		/*if (!exportFlag) {
			query.append("where  b.row_nbr between ? and ? ");
		}
		query.append("order by  b.row_nbr  with ur ");
		*/
		query.append("where  b.row_nbr between ? and ? ");
		query.append("order by  b.row_nbr  with ur ");
		
		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());

			buildPreparedStatement(request, i, exportFlag, index, limit);

			executeQuery(logger, query.toString());

			result = convertSelectedRowsToObjects(rs, request, displayDashes, exportFlag);

		}
		catch (Exception e) {

			throw new Exception("Unable to get CostOpportunityLabProviderDao (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;

	}

	private void buildPreparedStatement(GetCostOpportunityLabProviderRequest request, int i, boolean exportFlag, int index, int limit) throws SQLException {
		
		int start = 0;
		int stop = 0;
		
		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}
		
		if (!exportFlag) {
			start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
			stop = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
		}
		else {
			start = index;
			stop = limit;
		}
		ps.setInt(++i, start + 1);
		ps.setInt(++i, start + stop);

	}

	private List<CostOpportunityLabProviderBean> convertSelectedRowsToObjects(ResultSet rs, GetCostOpportunityLabProviderRequest request, boolean displayDashes, boolean exportFlag) throws SQLException {

		List<CostOpportunityLabProviderBean> list = new ArrayList<CostOpportunityLabProviderBean>();

		while (rs.next()) {

			CostOpportunityLabProviderBean item = new CostOpportunityLabProviderBean();

			item.setAttributedPhysicianName(rs.getString("prov_name"));
			item.setIpDimKey(rs.getString("ip_dim_key"));
			item.setProviderId(StringUtil.buildUniqueProviderId(item.getIpDimKey(), rs.getString("prov_org_dim_key")));
			item.setOrganizationName(rs.getString("org_name"));
			
				if (exportFlag) {
					
					setTotalExport(rs.getInt("row_cnt"));   
					if(!displayDashes && (rs.getString("dsply_dashes") != null && rs.getString("dsply_dashes").equalsIgnoreCase(Constants.N))){
						item.setCostOpportunity(StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("cost_opportunity").setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
					}else{
						item.setCostOpportunity(Constants.DASHES);
					}
					item.setDetailsCount(StringUtil.convertIntWithCommaToString(rs.getInt("member_count")));
					item.setNonParticipatingLabCount(StringUtil.convertIntWithCommaToString(rs.getInt("non_par_lab_count")));
					item.setStdRate(rs.getBigDecimal("percent_standard_rate").setScale(2, BigDecimal.ROUND_HALF_UP).toString() + "%");
					item.setTotalLabCount(StringUtil.convertIntWithCommaToString(rs.getInt("total_lab_count")));
					item.setUnitCount(StringUtil.convertIntWithCommaToString(rs.getInt("unit_count")));
					item.setAttributedProvNpi(StringUtil.getValueOrDashes(rs.getString("ip_npi")));
					item.setAttributedProvSpeciality(StringUtil.getValueOrDashes(rs.getString("IP_SPCLTY_NM")));
					item.setOrgTin(rs.getString("PROV_ORG_TAX_ID"));
				}
				else {
					if(!displayDashes && (rs.getString("dsply_dashes") != null && rs.getString("dsply_dashes").equalsIgnoreCase(Constants.N))){
					item.setCostOpportunity(rs.getString("cost_opportunity"));
					}else{
						item.setCostOpportunity(Constants.DASHES);
					}
					item.setDetailsCount(rs.getString("member_count"));
					item.setNonParticipatingLabCount(rs.getString("non_par_lab_count"));
					item.setStdRate(rs.getString("percent_standard_rate"));
					item.setTotalLabCount(rs.getString("total_lab_count"));
					item.setUnitCount(rs.getString("unit_count"));
				}
				item.setHasDetailsDrilldownInd(request.isHasDetailsDrilldownInd());

			list.add(item);
			
			if (getRowCount() == 0) { // PCMSP-8613
				setRowCount(rs.getInt("row_cnt"));
			}

		}

		return list;

	}

	private String buildSortClause(GetCostOpportunityLabProviderRequest request) {

		StringBuilder query = new StringBuilder();
		String defaultColumn = " cost_opportunity ";
		String defaultSort = defaultColumn + " desc ";

		if (null != request.getSort()) {

			for (QuerySort sort : request.getSort()) {

				String dir = sort.getDirection().replaceAll("\"", "");
				String property = sort.getProperty();

				if (property.equals("attributedPhysicianName")) {
					query.append(" prov_name " + dir + ", " + defaultSort);
				}
				else if (property.equals("organizationName")) {
					query.append(" org_name " + dir + ", " + defaultSort);					
				}
				else if (property.equals("unitCount")) {
					query.append(" unit_count " + dir + ", " + defaultSort);
				}
				else if (property.equals("stdRate")) {
					query.append(" percent_standard_rate " + dir + ", " + defaultSort);					
				}
				else if (property.equals("nonParticipatingLabCount")) {
					query.append(" non_par_lab_count " + dir + ", " + defaultSort);					
				}
				else if (property.equals("totalLabCount")) {
					query.append(" total_lab_count " + dir + ", " + defaultSort);					
				}
				else if (property.equals("detailsCount")) {
					query.append(" member_count " + dir + ", " + defaultSort);					
				}
				else {
					query.append(defaultColumn + dir);
				}
			}

		}
		else {

		}

		return query.toString();

	}
	
	private String getMaskedOrActualValue(boolean displayDashes, String maskedValue, String columnName) {
		
		String value;
		
		if (displayDashes) {			
			value = maskedValue;			
		}
		else {			
			value = columnName;			
		}
		
		return value;
		
	}

}
