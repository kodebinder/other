package com.wellpoint.pc2dash.action.costOpportunity;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.data.dto.AuditEntry;
import com.wellpoint.pc2dash.dto.costOpportunity.CostOpportunityLabDetailsBean;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportGridColumn;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.costOpportunity.CostOpportunityLabDetailsExport;
import com.wellpoint.pc2dash.service.costOpportunity.CostOpportunityLabDetailsServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetCostOpportunityLabDetailsAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		List<CostOpportunityLabDetailsBean> resultList = null;

		GetCostOpportunityLabDetailsRequest request = (GetCostOpportunityLabDetailsRequest) actionRequest;
		GetCostOpportunityLabDetailsResponse response = new GetCostOpportunityLabDetailsResponse();
		ErrorProperties err = ErrorProperties.getInstance();
		CostOpportunityLabDetailsServiceImpl service = new CostOpportunityLabDetailsServiceImpl();

		List<String> grps = null;

		try {

			removeLobPgmPrefixes(request);
			
			Boolean isattest = isAttested(request);

			if (StringUtils.isNotBlank(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			if (null != grps && !grps.isEmpty()) {
				request.setProvGrpIdsWithoutClinicalCheck(StringUtils.join(grps, ','));
				grps = filterProvGrpsByClinicalInd(request, grps);
				request.setProvGrpIds(CollectionUtils.isNotEmpty(grps) ? StringUtils.join(grps, ',') : Constants.DASHES);
			}

			CommonQueries cq = new CommonQueries();
			request.setTapId(request.getMetricViewId());
			request.setSuppression(cq.getActiveSuppressionForSelectComponents(request));
			
			MetaData metaData = new MetaData();
			metaData.setReportDate(cq.getReportDateForCostOpportunity(Constants.LABORATORY_SITE_OF_SERVICE));
			if(!request.isScorecardDrilldownInd()){
			metaData.setReportingPeriod(cq.getReportingPeriodForCostOpportunity(Constants.LABORATORY_SITE_OF_SERVICE));
			}else{
				if(StringUtil.isNotBlankOrFalse(request.getScorecardReportingPeriod()) && request.getScorecardReportingPeriod() != null)
				metaData.setReportingPeriod((Constants.SC_LAB_REPORTING_PERIOD).concat(request.getScorecardReportingPeriod()));
			}
			if (StringUtil.isExportDest(request.getDest())) {
            	request.setReportingPeriod(metaData.getReportingPeriod());
            	request.setReportDate(metaData.getReportDate());
				List<ExportGridColumn> columns = service.buildExportGridColumns(request);
				CostOpportunityLabDetailsExport exp = new CostOpportunityLabDetailsExport(request, columns);
				ExportProcessor.getInstance().submit(exp);
			}
			else {

				if (null != grps && !grps.isEmpty() && isattest) {

					resultList = service.getData(request);

					if (null == resultList || resultList.isEmpty()) {
						response.setMessage(err.getProperty("successNoData"));
					}
					else {
						response.setMetaData(metaData);
						response.setMessage(err.getProperty("successful"));
						response.setData(resultList);
						response.setTotal(service.getNoOfRecords());
					}
				}else if (grps.isEmpty() && isattest) {
					response.setSuccess(true);
				}
				else {
					response.setSuccess(false);
				}
			}
			response.setSuccess(true);
			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

	}
	
	private boolean isAttested(GetCostOpportunityLabDetailsRequest request) throws Exception {

		AuditEntry dto = new AuditEntry();
		dto.setUserId(request.getUserId());
		dto.setSessionId(request.getSessionId());
		dto.setPatientId("-1");
		dto.setAccessType(Constants.LAB_DETAILS);

		return dto.read();
	}

}
