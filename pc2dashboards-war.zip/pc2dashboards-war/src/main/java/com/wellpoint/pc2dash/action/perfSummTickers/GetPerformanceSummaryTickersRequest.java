package com.wellpoint.pc2dash.action.perfSummTickers;

import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;

public class GetPerformanceSummaryTickersRequest extends PerformanceManagementRequest {

	protected String lobs;

	public String getLobs() {
		return lobs;
	}

	public void setLobs(String lobs) {
		this.lobs = lobs;
	}

}
