package com.wellpoint.pc2dash.action.communications;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetCommunicationsResponse extends ActionResponse {

}
