package com.wellpoint.pc2dash.dao;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class VstFact implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long vstFactKey;
	private BigDecimal admsnHourNbr;
	private String admsnTypeCd;
	private Long admtgDiagCdDimKey;
	private BigDecimal alwdAmt;
	private String ambltrySnsitvIndCd;
	private String clmNbr;
	private Long crtdLoadLogKey;
	private String dayLongNm;
	private String drgCd;
	private Long dschrgDiagCdDimKey;
	private BigDecimal losCnt;
	private Long othrDiag1CdDimKey;
	private String othrDiag1;
	private String othrDiag1Id;
	private Long othrDiag2CdDimKey;
	private String othrDiag2;
	private String othrDiag2Id;
	private Long othrDiag3CdDimKey;
	private String othrDiag3;
	private String othrDiag3Id;
	private String prmryProcCd;
	private Long prncplDiagCdDimKey;
	private String prncplDiag;
	private String prncplDiagId;
	private String ptntlAvdblIndCd;
	private String rcrdSttsCd;
	private Timestamp sorDtm;
	private String srcClmLineProvId;
	private Long srvcTypeCdDimKey;
	private Long tosLvl3CdDimKey;
	private Long updtdLoadLogKey;
	private String mbrKey;
	private String fcltyNm;
	private Date vstEndDt;
	private Date vstStrtDt;
	private IpDim ipDim;
	private String newToViewInd;

	// Inpatient Admissions
	private Date admtDt;
	private Date dschrgDt;
	private String ambltrySnsitvInpatInd;
	private String readmsnInpatInd;
	private String newToViewInpatInd;


	public Long getVstFactKey() {
		return vstFactKey;
	}

	public void setVstFactKey(Long vstFactKey) {
		this.vstFactKey = vstFactKey;
	}

	public BigDecimal getAdmsnHourNbr() {
		return admsnHourNbr;
	}

	public void setAdmsnHourNbr(BigDecimal admsnHourNbr) {
		this.admsnHourNbr = admsnHourNbr;
	}

	public String getAdmsnTypeCd() {
		return admsnTypeCd;
	}

	public void setAdmsnTypeCd(String admsnTypeCd) {
		this.admsnTypeCd = admsnTypeCd;
	}

	public Long getAdmtgDiagCdDimKey() {
		return admtgDiagCdDimKey;
	}

	public void setAdmtgDiagCdDimKey(Long admtgDiagCdDimKey) {
		this.admtgDiagCdDimKey = admtgDiagCdDimKey;
	}

	public BigDecimal getAlwdAmt() {
		return alwdAmt;
	}

	public void setAlwdAmt(BigDecimal alwdAmt) {
		this.alwdAmt = alwdAmt;
	}

	public String getAmbltrySnsitvIndCd() {
		return ambltrySnsitvIndCd;
	}

	public void setAmbltrySnsitvIndCd(String ambltrySnsitvIndCd) {
		this.ambltrySnsitvIndCd = ambltrySnsitvIndCd;
	}

	public String getClmNbr() {
		return clmNbr;
	}

	public void setClmNbr(String clmNbr) {
		this.clmNbr = clmNbr;
	}

	public Long getCrtdLoadLogKey() {
		return crtdLoadLogKey;
	}

	public void setCrtdLoadLogKey(Long crtdLoadLogKey) {
		this.crtdLoadLogKey = crtdLoadLogKey;
	}

	public String getDayLongNm() {
		return dayLongNm;
	}

	public void setDayLongNm(String dayLongNm) {
		this.dayLongNm = dayLongNm;
	}

	public String getDrgCd() {
		return drgCd;
	}

	public void setDrgCd(String drgCd) {
		this.drgCd = drgCd;
	}

	public Long getDschrgDiagCdDimKey() {
		return dschrgDiagCdDimKey;
	}

	public void setDschrgDiagCdDimKey(Long dschrgDiagCdDimKey) {
		this.dschrgDiagCdDimKey = dschrgDiagCdDimKey;
	}

	public BigDecimal getLosCnt() {
		return losCnt;
	}

	public void setLosCnt(BigDecimal losCnt) {
		this.losCnt = losCnt;
	}

	public Long getOthrDiag1CdDimKey() {
		return othrDiag1CdDimKey;
	}

	public void setOthrDiag1CdDimKey(Long othrDiag1CdDimKey) {
		this.othrDiag1CdDimKey = othrDiag1CdDimKey;
	}

	public Long getOthrDiag2CdDimKey() {
		return othrDiag2CdDimKey;
	}

	public void setOthrDiag2CdDimKey(Long othrDiag2CdDimKey) {
		this.othrDiag2CdDimKey = othrDiag2CdDimKey;
	}

	public Long getOthrDiag3CdDimKey() {
		return othrDiag3CdDimKey;
	}

	public void setOthrDiag3CdDimKey(Long othrDiag3CdDimKey) {
		this.othrDiag3CdDimKey = othrDiag3CdDimKey;
	}

	public String getPrmryProcCd() {
		return prmryProcCd;
	}

	public void setPrmryProcCd(String prmryProcCd) {
		this.prmryProcCd = prmryProcCd;
	}

	public Long getPrncplDiagCdDimKey() {
		return prncplDiagCdDimKey;
	}

	public void setPrncplDiagCdDimKey(Long prncplDiagCdDimKey) {
		this.prncplDiagCdDimKey = prncplDiagCdDimKey;
	}

	public String getPtntlAvdblIndCd() {
		return ptntlAvdblIndCd;
	}

	public void setPtntlAvdblIndCd(String ptntlAvdblIndCd) {
		this.ptntlAvdblIndCd = ptntlAvdblIndCd;
	}

	public String getRcrdSttsCd() {
		return rcrdSttsCd;
	}

	public void setRcrdSttsCd(String rcrdSttsCd) {
		this.rcrdSttsCd = rcrdSttsCd;
	}

	public Timestamp getSorDtm() {
		return sorDtm;
	}

	public void setSorDtm(Timestamp sorDtm) {
		this.sorDtm = sorDtm;
	}

	public String getSrcClmLineProvId() {
		return srcClmLineProvId;
	}

	public void setSrcClmLineProvId(String srcClmLineProvId) {
		this.srcClmLineProvId = srcClmLineProvId;
	}

	public Long getSrvcTypeCdDimKey() {
		return srvcTypeCdDimKey;
	}

	public void setSrvcTypeCdDimKey(Long srvcTypeCdDimKey) {
		this.srvcTypeCdDimKey = srvcTypeCdDimKey;
	}

	public Long getTosLvl3CdDimKey() {
		return tosLvl3CdDimKey;
	}

	public void setTosLvl3CdDimKey(Long tosLvl3CdDimKey) {
		this.tosLvl3CdDimKey = tosLvl3CdDimKey;
	}

	public Long getUpdtdLoadLogKey() {
		return updtdLoadLogKey;
	}

	public void setUpdtdLoadLogKey(Long updtdLoadLogKey) {
		this.updtdLoadLogKey = updtdLoadLogKey;
	}

	public String getMbrKey() {
		return mbrKey;
	}

	public void setMbrKey(String mbrKey) {
		this.mbrKey = mbrKey;
	}

	public String getFcltyNm() {
		return fcltyNm;
	}

	public void setFcltyNm(String fcltyNm) {
		this.fcltyNm = fcltyNm;
	}

	public Date getVstEndDt() {
		return vstEndDt;
	}

	public void setVstEndDt(Date vstEndDt) {
		this.vstEndDt = vstEndDt;
	}

	public Date getVstStrtDt() {
		return vstStrtDt;
	}

	public void setVstStrtDt(Date vstStrtDt) {
		this.vstStrtDt = vstStrtDt;
	}

	public IpDim getIpDim() {
		return ipDim;
	}

	public void setIpDim(IpDim ipDim) {
		this.ipDim = ipDim;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getOthrDiag1() {
		return othrDiag1;
	}

	public void setOthrDiag1(String othrDiag1) {
		this.othrDiag1 = othrDiag1;
	}

	public String getOthrDiag2() {
		return othrDiag2;
	}

	public void setOthrDiag2(String othrDiag2) {
		this.othrDiag2 = othrDiag2;
	}

	public String getOthrDiag3() {
		return othrDiag3;
	}

	public void setOthrDiag3(String othrDiag3) {
		this.othrDiag3 = othrDiag3;
	}

	public String getPrncplDiag() {
		return prncplDiag;
	}

	public void setPrncplDiag(String prncplDiag) {
		this.prncplDiag = prncplDiag;
	}

	public String getOthrDiag1Id() {
		return othrDiag1Id;
	}

	public void setOthrDiag1Id(String othrDiag1Id) {
		this.othrDiag1Id = othrDiag1Id;
	}

	public String getOthrDiag2Id() {
		return othrDiag2Id;
	}

	public void setOthrDiag2Id(String othrDiag2Id) {
		this.othrDiag2Id = othrDiag2Id;
	}

	public String getOthrDiag3Id() {
		return othrDiag3Id;
	}

	public void setOthrDiag3Id(String othrDiag3Id) {
		this.othrDiag3Id = othrDiag3Id;
	}

	public String getPrncplDiagId() {
		return prncplDiagId;
	}

	public void setPrncplDiagId(String prncplDiagId) {
		this.prncplDiagId = prncplDiagId;
	}

	/**
	 * @return the newToViewInd
	 */
	public String getNewToViewInd() {
		return newToViewInd;
	}

	/**
	 * @param newToViewInd the newToViewInd to set
	 */
	public void setNewToViewInd(String newToViewInd) {
		this.newToViewInd = newToViewInd;
	}

	public Date getAdmtDt() {
		return admtDt;
	}

	public void setAdmtDt(Date admtDt) {
		this.admtDt = admtDt;
	}

	public Date getDschrgDt() {
		return dschrgDt;
	}

	public void setDschrgDt(Date dschrgDt) {
		this.dschrgDt = dschrgDt;
	}

	public String getAmbltrySnsitvInpatInd() {
		return ambltrySnsitvInpatInd;
	}

	public void setAmbltrySnsitvInpatInd(String ambltrySnsitvInpatInd) {
		this.ambltrySnsitvInpatInd = ambltrySnsitvInpatInd;
	}

	public String getReadmsnInpatInd() {
		return readmsnInpatInd;
	}

	public void setReadmsnInpatInd(String readmsnInpatInd) {
		this.readmsnInpatInd = readmsnInpatInd;
	}

	public String getNewToViewInpatInd() {
		return newToViewInpatInd;
	}

	public void setNewToViewInpatInd(String newToViewInpatInd) {
		this.newToViewInpatInd = newToViewInpatInd;
	}
}
