package com.wellpoint.pc2dash.action.patients;

import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.patient.CareOpportunitiesFilterJson;

public class GetPatientCareOpportunitiesResponse extends ActionResponse {

	private Collection<CareOpportunitiesFilterJson> children = new ArrayList<CareOpportunitiesFilterJson>();
	private String text = ".";

	public Collection<CareOpportunitiesFilterJson> getChildren() {
		return children;
	}

	public void setChildren(Collection<CareOpportunitiesFilterJson> children) {
		this.children = children;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
}
