package com.wellpoint.pc2dash.action.tooltip;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.ra.compIntegrator.dto.CaseOwnerDtlJson;
import com.wellpoint.pc2dash.ra.compIntegrator.dto.CaseOwnerForm;
import com.wellpoint.pc2dash.ra.compIntegrator.service.ViewFormServiceImpl;

public class GetReferralCaseOwnerDetailAction extends Action{

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetReferralCaseOwnerDetailAction.class);
	
	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		// TODO Auto-generated method stub
		ActionResponse response = new GetReferralCaseOwnerDetailsResponse();
		GetReferralCaseOwnerDetailRequest request = (GetReferralCaseOwnerDetailRequest) actionRequest;
		ViewFormServiceImpl service = new ViewFormServiceImpl();
		ErrorProperties err = ErrorProperties.getInstance();
		
		try{
			
			if(request != null){
				String referralId = request.getReferralId();
				if(referralId != null){
					CaseOwnerForm caseOwner = service.getCaseOwnerDetails(request);
					CaseOwnerDtlJson caseOwnerJson = new CaseOwnerDtlJson();
					if (null == caseOwner) {
						
						response.setMessage(err.getProperty("successNoData"));
					}
					else {
						
						if(caseOwner.getFirstName() != null){
							String ownerName = caseOwner.getFirstName();
							if (caseOwner.getLastName() != null) ownerName += " "+caseOwner.getLastName();
							caseOwnerJson.setOwnerName(ownerName);
						}
						else {
							caseOwnerJson.setOwnerName(caseOwner.getLastName() != null ? caseOwner.getLastName() : null);
						}
						
						if(caseOwner.getContactNo() != null){
							String contactNo = caseOwner.getContactNo();
							if (caseOwner.getExtNo() != null) contactNo += " <i>Ext "+caseOwner.getExtNo()+"</i>";
							caseOwnerJson.setContactNo(contactNo);
						}
						else {
							if (caseOwner.getExtNo() != null)  caseOwnerJson.setContactNo(" <i>Ext "+caseOwner.getExtNo()+"</i>");
							
						}
						
						caseOwnerJson.setRole(caseOwner.getRoleName());
						caseOwnerJson.setEmail(caseOwner.getEmail());
						
						response.setData(caseOwnerJson);
						response.setMessage(err.getProperty("successful"));
						response.setTotal(service.getRowCount());
					}
				}
			}
			
			response.setSuccess(true);
		}
		catch (Exception e) {

			logger.error("Unable to retrieve case owner detail.", e);
			
			response.setMessage("Unable to retrieve case owner detail.");
			response.setSuccess(false);
		}
		
		return response;
	}

	

}
