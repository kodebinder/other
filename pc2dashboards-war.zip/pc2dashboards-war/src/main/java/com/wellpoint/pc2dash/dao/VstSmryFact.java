package com.wellpoint.pc2dash.dao;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

public class VstSmryFact implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long vstSmryFactKey;
	private Long crtdLoadLogKey;
	private Date lastVstDt;
	private Short mnthlyVstNbr;
	private String rcrdSttsCd;
	private Long srvcTypeCdDimKey;
	private Timestamp sorDtm;
	private Long updtdLoadLogKey;
	private Short vstNbr;
	private String visitTypeName; // ER, Urgent Care, Inpatient, Outpatient, Attributed PCP

	public Long getVstSmryFactKey() {
		return this.vstSmryFactKey;
	}

	public void setVstSmryFactKey(Long vstSmryFactKey) {
		this.vstSmryFactKey = vstSmryFactKey;
	}

	public Long getCrtdLoadLogKey() {
		return this.crtdLoadLogKey;
	}

	public void setCrtdLoadLogKey(Long crtdLoadLogKey) {
		this.crtdLoadLogKey = crtdLoadLogKey;
	}

	public Date getLastVstDt() {
		return this.lastVstDt;
	}

	public void setLastVstDt(Date lastVstDt) {
		this.lastVstDt = lastVstDt;
	}

	public Short getMnthlyVstNbr() {
		return this.mnthlyVstNbr;
	}

	public void setMnthlyVstNbr(Short mnthlyVstNbr) {
		this.mnthlyVstNbr = mnthlyVstNbr;
	}

	public String getRcrdSttsCd() {
		return this.rcrdSttsCd;
	}

	public void setRcrdSttsCd(String rcrdSttsCd) {
		this.rcrdSttsCd = rcrdSttsCd;
	}

	public Long getSrvcTypeCdDimKey() {
		return srvcTypeCdDimKey;
	}

	public void setSrvcTypeCdDimKey(Long srvcTypeCdDimKey) {
		this.srvcTypeCdDimKey = srvcTypeCdDimKey;
	}

	public Timestamp getSorDtm() {
		return this.sorDtm;
	}

	public void setSorDtm(Timestamp sorDtm) {
		this.sorDtm = sorDtm;
	}

	public Long getUpdtdLoadLogKey() {
		return this.updtdLoadLogKey;
	}

	public void setUpdtdLoadLogKey(Long updtdLoadLogKey) {
		this.updtdLoadLogKey = updtdLoadLogKey;
	}

	public Short getVstNbr() {
		return this.vstNbr;
	}

	public void setVstNbr(Short vstNbr) {
		this.vstNbr = vstNbr;
	}

	public String getVisitTypeName() {
		return visitTypeName;
	}

	public void setVisitTypeName(String visitTypeName) {
		this.visitTypeName = visitTypeName;
	}
}
