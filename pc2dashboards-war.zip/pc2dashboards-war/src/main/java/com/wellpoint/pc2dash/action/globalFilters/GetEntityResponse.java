package com.wellpoint.pc2dash.action.globalFilters;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetEntityResponse extends ActionResponse {

}
