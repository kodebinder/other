package com.wellpoint.pc2dash.action.patients;

import com.wellpoint.pc2dash.data.dto.PCMSRequest;

public class GetPatientCareOpportunitiesRequest extends PCMSRequest {

	protected String filteredProvGrpIds;

	public String getFilteredProvGrpIds() {
		return filteredProvGrpIds;
	}

	public void setFilteredProvGrpIds(String filteredProvGrpIds) {
		this.filteredProvGrpIds = filteredProvGrpIds;
	}

}
