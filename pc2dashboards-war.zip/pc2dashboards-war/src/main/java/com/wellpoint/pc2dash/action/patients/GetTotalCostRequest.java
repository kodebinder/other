package com.wellpoint.pc2dash.action.patients;

import com.wellpoint.pc2dash.data.dto.PCMSRequest;

public class GetTotalCostRequest extends PCMSRequest {

}
