package com.wellpoint.pc2dash.action.patients;

import java.lang.reflect.InvocationTargetException;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.dto.patient.MstrCnsmrFactAndOthers;
import com.wellpoint.pc2dash.dto.patient.Patient;
import com.wellpoint.pc2dash.dto.savedFilters.PatientFilter;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.service.patient.PatientSearchService;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;


public class PatientSearchAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		PatientSearchRequest request = (PatientSearchRequest) actionRequest;
		PatientSearchResponse response = new PatientSearchResponse();
		PatientSearchService service = new PatientSearchService();
		ErrorProperties err = ErrorProperties.getInstance();

		try {

			List<String> grps = null;
			removeLobPgmPrefixes(request);
			updateRequest(request);

			grps = filterProvGrpsByKillSwitch(request); // dataMap had an existence check for the key here, which is now unnecessary

			if (null != grps && !grps.isEmpty()) {

				grps = filterProvGrpsByClinicalInd(request, grps);
				request.setProvGrpIds(StringUtils.join(grps, ','));

				prepareRASuppressionCond(request);
				prepareLPRSuppressionCond(request);

				/*
				 * Determine whether Action Center is suppressed - it'll play a part in deciding whether to display
				 * the "i" icon in all of the Clinical Programs columns in Population Management and
				 * Performance Management drill-downs.
				 */
				CommonQueries cq = new CommonQueries();
				request.setGroupsWithActionCenterSuppressed(cq.getGroupsWithComponentSuppressed(request, Constants.AC_RF_CARDCONTAINER));
				request.setSuppression(cq.getActiveSuppressionForSelectComponents(request));
				List<MstrCnsmrFactAndOthers> resultList = service.getData(request);
				List<Patient> patientList = service.getBeanList(resultList, request);
				MetaData metaData = buildMetaData(request, service);

				if (!resultList.isEmpty()) {

					response.setData(patientList);
					response.setMetaData(metaData);
					response.setMessage(err.getProperty("successful"));
					response.setTotal(service.getRowCount());
				}
				else {

					response.setMessage(err.getProperty("successNoData"));
				}
			}

			response.setSuccess(true);
			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}

	private void updateRequest(PatientSearchRequest request) throws IllegalAccessException, InvocationTargetException {

		if (request != null) {

			if (null != request.getFilter()) {

				List<PatientFilter> filters = request.getFilter();
				Iterator<PatientFilter> i = filters.iterator();
				while (i.hasNext()) {
					//for (JsonElement filter : filters) {
					PatientFilter objPaitentFilter = i.next();
					//JsonObject j = new JsonObject();

					String key = objPaitentFilter.getProperty().replaceAll("\"", "");//j.get("property").toString().replaceAll("\"", "");
					String val = objPaitentFilter.getValue().replaceAll("\"", "");//i.next()j.get("value").toString().replaceAll("\"", "");

					if (StringUtils.isNotBlank(val)) {
						BeanUtils.setProperty(request, key, val);
					}
				}
			}
		}
	}

	//	private Map<String, String> getDataMap(PatientSearchRequest request) {
	//
	//		Map<String, String> data = new HashMap<String, String>();
	//
	//		if (request != null) {
	//
	//			data.put("sessionId", request.getSessionId());
	//			data.put("entitlementId", request.getEntitlementId());
	//
	//			data.setProvGrpIds( request.getProvGrpIds());
	//			data.put(Constants.USER_ACS_INFO_JSON, request.getUserAcsInfoJson());
	//			data.put(Constants.CMP_ID, request.getCmpId());
	//
	//			data.setStart(request.getStart());
	//			data.setLimit(request.getLimit());
	//
	//			if (null != request.getSort()) {
	//
	//				JsonArray sorters = JSONUtils.buildJsonArray(request.getSort());
	//				JsonObject j = (JsonObject) sorters.get(0);
	//				String key = j.get("property").toString().replaceAll("\"", "");
	//				String val = j.get("direction").toString().replaceAll("\"", "");
	//
	//				data.put("sortParameter", key);
	//				data.put("sortDirection", val.toLowerCase());
	//			}
	//
	//			if (null != request.getFilter()) {
	//
	//				JsonArray filters = JSONUtils.buildJsonArray(request.getFilter());
	//
	//				for (JsonElement filter : filters) {
	//
	//					JsonObject j = (JsonObject) filter;
	//					String key = j.get("property").toString().replaceAll("\"", "");
	//					String val = j.get("value").toString().replaceAll("\"", "");
	//
	//					if (!val.equals("")) {
	//						data.put(key, val);
	//					}
	//				}
	//			}
	//		}
	//
	//		return data;
	//	}
}
