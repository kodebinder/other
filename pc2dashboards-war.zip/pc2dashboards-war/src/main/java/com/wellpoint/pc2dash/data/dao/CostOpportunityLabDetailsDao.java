package com.wellpoint.pc2dash.data.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.costOpportunity.GetCostOpportunityLabDetailsRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.costOpportunity.CostOpportunityLabDetailsBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.DateUtil;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class CostOpportunityLabDetailsDao extends ServiceImpl {


	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(CostOpportunityLabDetailsDao.class);

	public List<CostOpportunityLabDetailsBean> getData(GetCostOpportunityLabDetailsRequest request, boolean exportFlag, int index, int limit) throws Exception {

		List<CostOpportunityLabDetailsBean> result = new ArrayList<CostOpportunityLabDetailsBean>();
		setRowCount(0);

		StringBuilder query = new StringBuilder()
			.append("select ")
			.append("	a.* ")
			.append("from ")
			.append("	( ")
			.append("		select ")
			.append("			row_number() over ( ")
			.append("				order by ")
			.append(buildSortClause(request))
			.append(" ) as rank, ")
			.append(
				" mstr_cnsmr_dim_key, ip_dim_key, frst_nm,last_nm,brth_dt, age_nbr,gndr_cd,ip_frst_nm,ip_last_nm,CPT_CD,unit_cnt,CPT_DESC,lab_nm,clm_line_srvc_strt_dt,count(*) over () as row_cnt ");
		if (StringUtil.isExportDest(request.getDest())) {
			query.append(" ,IP_SPCLTY_NM, prov_org_full_nm,ip_npi,hc_id,phone_nbr, lob_ctgry_nm, lob_desc, psl_desc, psl_grp_nm, crprt_plan_cmpny_nm,home_plan_nm ");
		}
		query.append(" from ( select  ")
			.append(" psf.MSTR_CNSMR_DIM_KEY AS mstr_cnsmr_dim_key, psf.ip_dim_key, upper(psf.frst_nm) as frst_nm, upper(psf.last_nm) as last_nm, ")
			.append(" nullif(psf.brth_dt, '0001-01-01') as brth_dt, psf.age_nbr,psf.gndr_cd, upper(psf.ip_frst_nm) as ip_frst_nm, ")
			.append(
				" upper(psf.ip_last_nm) as ip_last_nm,cocdtl.CPT_CD as CPT_CD, cocdtl.UNIT_CNT as unit_cnt, cocdtl.CPT_DESC as CPT_DESC,cocdtl.lab_nm,cocdtl.clm_line_srvc_strt_dt  ");
		if (StringUtil.isExportDest(request.getDest())) {
			query.append(
				" ,psf.IP_SPCLTY_NM, upper(psf.prov_org_full_nm) as prov_org_full_nm,psf.ip_npi,psf.hc_id, psf.phone_nbr, psf.lob_ctgry_nm, psf.lob_desc, psf.psl_desc, psf.psl_grp_nm, psf.crprt_plan_cmpny_nm,psf.home_plan_nm ");
		}
		query.append(" from COC_LAB_CLM_DTL_SMRY cocdtl  ")
			.append(" JOIN PAT_SMRY_FACT PSF ON  PSF.MSTR_CNSMR_DIM_KEY = cocdtl.MSTR_CNSMR_DIM_KEY and psf.prov_org_dim_key = cocdtl.prov_org_dim_key ") // PCMSP-12641
			.append("	join poit_user_scrty_acs pusa on ( ")
			.append("		psf.prov_grp_id = pusa.prov_grp_id ")
			.append("		and case ")
			.append("				when pusa.prov_org_tax_id = '0' then psf.prov_org_tax_id ")
			.append("				else pusa.prov_org_tax_id ")
			.append("			end = psf.prov_org_tax_id ")
			.append("	) ")
			.append(" WHERE  ")
			.append(" PSF.ATRBN_STTS_CD = 'ACTIVE' ")
			.append(" and pusa.sesn_id = ? ")
			.append(" and pusa.enttlmnt_hash_key = ? ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and cocdtl.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and cocdtl.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and cocdtl.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and psf.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and psf.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getMemberKey())) {
			query.append(" and psf.mstr_cnsmr_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getMemberKey()) + ") ");
		}

		if (request.getLabName() != null && !request.getLabName().equalsIgnoreCase("false")) {
			query.append(" and upper(cocdtl.LAB_NM) like (" + "'%" + request.getLabName().trim().toUpperCase().replaceAll("\\s+","%") + "%'" + ") ");
		}

		if (request.getLabTaxId() != null && !request.getLabTaxId().equalsIgnoreCase("false")) {
			query.append(" and upper(cocdtl.LAB_TIN) =  '" + request.getLabTaxId().trim() + "'");
		}
		
		//PCMSP-20002
		if (StringUtil.isNotBlankOrFalse(request.getScorecardAnalysisOfDate())) {
			query.append(" and cocdtl.CLM_LINE_SRVC_STRT_DT BETWEEN  ADD_MONTHS(( TO_DATE(?, 'MM/dd/yyyy') + 1 day), - 15) AND ADD_MONTHS(TO_DATE(?, 'MM/dd/yyyy') , - 3) "); // SC
			
		}else{
			query.append(" and cocdtl.CLM_LINE_SRVC_STRT_DT BETWEEN  (current_date - day(current_date) day +1 day) - 12 MONTHS  AND  current_date - day(current_date) day ");  // COC
		}

		query.append(") ) a ");

		/*if (!exportFlag) {
			query.append("where  a.rank between ? and ? ");
		}
		query.append(" order by a.rank ");*/
		
		query.append(" where a.rank between ? and ? ");
		query.append(" order by a.rank ");
		

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());

			buildPreparedStatement(request, i, exportFlag, index, limit);

			executeQuery(logger, query.toString());

			result = convertSelectedRowsToObjects(rs, request, exportFlag);


		}
		catch (Exception e) {

			throw new Exception("Unable to get CostOpportunityLabDetailsDao (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}
		return result;

	}

	private void buildPreparedStatement(GetCostOpportunityLabDetailsRequest request, int i, boolean exportFlag, int index, int limit) throws SQLException {

		int start = 0;
		int stop = 0;
		
		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getMemberKey())) {
			String[] array = request.getMemberKey().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}
		
		if(StringUtil.isNotBlankOrFalse(request.getScorecardAnalysisOfDate())){
			ps.setString(++i, request.getScorecardAnalysisOfDate());
			ps.setString(++i, request.getScorecardAnalysisOfDate());
		}

		if (!exportFlag) {
			start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
			stop = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
		}
		else {
			start = index;
			stop = limit;
		}
		ps.setInt(++i, start + 1);
		ps.setInt(++i, start + stop);

	}

	private List<CostOpportunityLabDetailsBean> convertSelectedRowsToObjects(ResultSet rs, GetCostOpportunityLabDetailsRequest request, boolean exportFlag)
		throws SQLException {
		List<CostOpportunityLabDetailsBean> list = new ArrayList<CostOpportunityLabDetailsBean>();

		while (rs.next()) {

			CostOpportunityLabDetailsBean item = new CostOpportunityLabDetailsBean();



			if (exportFlag) {
				
				setTotalExport(rs.getInt("row_cnt"));   
				
				//PCMSP-12154 : Starts
				if (rs.getString("unit_cnt") != null) {
					item.setUnitCount(rs.getString("unit_cnt"));
				}
				else {
					item.setUnitCount(Constants.DASHES);
				}
				//PCMSP-12154 : Ends
				if (rs.getString("cpt_cd") != null) {
					item.setCptCode(rs.getString("cpt_cd"));
				}
				else {
					item.setCptCode(Constants.DASHES);
				}
				if (rs.getString("cpt_desc") != null) {
					item.setCptDesc(rs.getString("cpt_desc"));
				}
				else {
					item.setCptDesc(Constants.DASHES);
				}
				item.setMemberLastName(StringUtil.getValueOrDashes(rs.getString("last_nm")));
				item.setMemberFirstName(StringUtil.getValueOrDashes(rs.getString("frst_nm")));
				if (rs.getString("age_nbr") != null) {
					item.setMemberAge(rs.getShort("age_nbr"));
				}
				if (rs.getString("brth_dt") != null) {
					item.setMemberDOB(DateUtil.formatDateToMMDDYYYY(
						"yyyy-MM-dd", "M/d/yyyy", rs.getString("brth_dt")));
				}
				else {
					item.setMemberDOB(Constants.DASHES);
				}
				item.setMemberGender(StringUtil.getValueOrDashes(rs.getString("gndr_cd")));
				if (rs.getString("LAB_NM") != null) {
					item.setLabName(rs.getString("LAB_NM").replaceAll("\\s+"," "));
				}
				else {
					item.setLabName(Constants.DASHES);
				}
				if (rs.getString("clm_line_srvc_strt_dt") != null) {
					item.setServiceDt(DateUtil.formatDateToMMDDYYYY(
						"yyyy-MM-dd", "M/d/yyyy", rs.getString("clm_line_srvc_strt_dt")));
				}
				else {
					item.setServiceDt(Constants.DASHES);
				}
				
				//Changed for release-Q1-2018/PCMSP-18421 : Starts
				item.setAttributedPhysicianName(CommonQueries.getFilteredProviderName(rs.getString("ip_frst_nm"),rs.getString("ip_last_nm")));				
				//Changed for release-Q1-2018/PCMSP-18421 : Ends
				
				item.setAttributedProvNpi(StringUtil.getValueOrDashes(rs.getString("ip_npi")));
				item.setAttributedProvSpeciality(StringUtil.getValueOrDashes(rs.getString("IP_SPCLTY_NM")));
				item.setMemberProduct(StringUtil.getValueOrDashes(rs.getString("psl_desc")));
				item.setMemberLob(StringUtil.getValueOrDashes(rs.getString("lob_desc")));
				item.setMemberHomePlanParentCo(StringUtil.getValueOrDashes(rs.getString("crprt_plan_cmpny_nm")));
				item.setMemberHomePlan(StringUtil.getValueOrDashes(rs.getString("home_plan_nm")));
				item.setMemberId(StringUtil.getValueOrDashes(rs.getString("hc_id")));
			}
			else {

				if (rs.getString("age_nbr") != null)
					item.setMemberAge(rs.getShort("age_nbr"));
				if (rs.getString("brth_dt") != null) {
					item.setMemberDOB(DateUtil.formatDateToMMDDYYYY(
						"yyyy-MM-dd", "M/d/yyyy", rs.getString("brth_dt")));
				}
				else {
					item.setMemberDOB(Constants.DASHES);
				}
				item.setMemberLastName(StringUtil.getValueOrDashes(rs.getString("last_nm")));
				item.setMemberFirstName(StringUtil.getValueOrDashes(rs.getString("frst_nm")));
				if (rs.getString("frst_nm") != null
					&& rs.getString("last_nm") != null)
					item.setMemberFullName(StringUtil.buildFullName(
						rs.getString("frst_nm"), rs.getString("last_nm")));
				item.setMemberGender(StringUtil.getValueOrDashes(rs.getString("gndr_cd")));
				if (rs.getString("mstr_cnsmr_dim_key") != null)
					item.setMemberKey(rs.getLong("mstr_cnsmr_dim_key"));


				//Changed for release-Q1-2018/PCMSP-18421 : Starts
				item.setAttributedPhysicianName(CommonQueries.getFilteredProviderName(rs.getString("ip_frst_nm"),rs.getString("ip_last_nm")));				
				//Changed for release-Q1-2018/PCMSP-18421 : Ends
				
				//PCMSP-12154 : Starts
				if (rs.getString("unit_cnt") != null) {
					item.setUnitCount(rs.getString("unit_cnt"));
				}
				else {
					item.setUnitCount(Constants.DASHES);
				}
				//PCMSP-12154 : Ends

				if (rs.getString("cpt_cd") != null) {
					item.setCptCode(rs.getString("cpt_cd"));
				}
				else {
					item.setCptCode(Constants.DASHES);
				}
				if (rs.getString("cpt_desc") != null) {
					item.setCptDesc(rs.getString("cpt_desc"));
				}
				else {
					item.setCptDesc(Constants.DASHES);
				}
				if (rs.getString("LAB_NM") != null) {
					item.setLabName(rs.getString("LAB_NM").replaceAll("\\s+"," "));
				}
				else {
					item.setLabName(Constants.DASHES);
				}
				//Commenting the below part as UI expects mm/dd/yyyy format, Fix for PCMSP-13504 which was causing issues in UI date library while formatting 
				/*if (rs.getString("clm_line_srvc_strt_dt") != null) {
					item.setServiceDt(rs.getString("clm_line_srvc_strt_dt"));
				}*/ 
				if (null != rs.getString("clm_line_srvc_strt_dt")) {
					item.setServiceDt(DateUtil.formatDateToMMDDYYYY("yyyy-MM-dd", "M/d/yyyy", rs.getString("clm_line_srvc_strt_dt")));
				}
				else {
					item.setServiceDt(Constants.DASHES);
				}
			}


			list.add(item);

			if (getRowCount() == 0) {
				setRowCount(rs.getInt("row_cnt"));
			}

		}

		return list;
	}

	private String buildSortClause(GetCostOpportunityLabDetailsRequest request) {

		StringBuilder query = new StringBuilder();

		for (QuerySort sort : request.getSort()) {
			String dir = sort.getDirection().replaceAll("\"", "");
			String property = sort.getProperty();

			if (property.equals("unitCount")) {//PCMSP-12154
				query.append(" UNIT_CNT " + dir);
			}			
			else if (property.equals("cptCode")) {
				query.append(" CPT_CD " + dir);
			}
			else if (property.equals("cptDesc")) {
				query.append(" CPT_DESC " + dir);
			}
			else if (property.equals("memberFullName")) {
				query.append("  last_nm " + dir + ", frst_nm " + dir);
			}
			else if (property.equals("labName")) {
				query.append(" lab_nm " + dir);
			}
			else if (property.equals("serviceDt")) {
				query.append(" clm_line_srvc_strt_dt " + dir);
			}
			else if (property.equals("attributedPhysicianName")) {
				query.append(" ip_last_nm " + dir + ", ip_frst_nm " + dir);
			}

		}

		return query.toString();
	}



}
