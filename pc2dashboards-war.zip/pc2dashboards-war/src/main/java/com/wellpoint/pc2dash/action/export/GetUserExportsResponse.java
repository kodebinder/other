package com.wellpoint.pc2dash.action.export;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetUserExportsResponse extends ActionResponse {


}
