package com.wellpoint.pc2dash.action.medicalCostServiceDetails;

import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;

public class GetMedicalCostServiceDetailsRequest extends PerformanceManagementRequest {
	protected boolean addHighCost;
	protected boolean isMLR;
	protected String highCostMembers;
	protected String mcpDrilldownRxCondition;
	protected String products;
	protected String productSwimLane;
	protected boolean showMI;
	protected boolean showProductSwimLane;
	protected String reportType;
	//Used for Export
	private String programNm;

	public String getProgramNm() {
		return programNm;
	}

	public void setProgramNm(String programNm) {
		this.programNm = programNm;
	}

	public boolean isAddHighCost() {
		return addHighCost;
	}

	public void setAddHighCost(boolean addHighCost) {
		this.addHighCost = addHighCost;
	}

	public String getHighCostMembers() {
		return highCostMembers;
	}

	public void setHighCostMembers(String highCostMembers) {
		this.highCostMembers = highCostMembers;
	}

	public String getMcpDrilldownRxCondition() {
		return mcpDrilldownRxCondition;
	}

	public void setMcpDrilldownRxCondition(String mcpDrilldownRxCondition) {
		this.mcpDrilldownRxCondition = mcpDrilldownRxCondition;
	}

	public String getProducts() {
		return products;
	}

	public void setProducts(String products) {
		this.products = products;
	}

	public String getProductSwimLane() {
		return productSwimLane;
	}

	public void setProductSwimLane(String productSwimLane) {
		this.productSwimLane = productSwimLane;
	}

	public boolean isShowMI() {
		return showMI;
	}

	public void setShowMI(boolean showMI) {
		this.showMI = showMI;
	}

	public boolean isShowProductSwimLane() {
		return showProductSwimLane;
	}

	public void setShowProductSwimLane(boolean showProductSwimLane) {
		this.showProductSwimLane = showProductSwimLane;
	}


	public boolean isMLR() {
		return isMLR;
	}


	public void setMLR(boolean isMLR) {
		this.isMLR = isMLR;
	}

	public String getReportType() {
		return reportType;
	}

	public void setReportType(String reportType) {
		this.reportType = reportType;
	}

}
