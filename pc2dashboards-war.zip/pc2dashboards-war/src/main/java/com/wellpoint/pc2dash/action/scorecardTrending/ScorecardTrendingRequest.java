package com.wellpoint.pc2dash.action.scorecardTrending;

import java.util.List;

import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;
import com.wellpoint.pc2dash.dto.scorecardTrending.SCTrendingChartDataPoints;
//import com.wellpoint.pc2dash.dto.scorecardTrending.ScorecardTrendLevelObj;
//import com.wellpoint.pc2dash.dto.scorecardTrending.ScorecardTrendSeriesObj;


public class ScorecardTrendingRequest extends PerformanceManagementRequest {

	protected String calcCD;
	//protected List<ScorecardTrendLevelObj> chartLevels;
	//protected List<ScorecardTrendSeriesObj> chartSeries;
	protected String chartLevels;
	protected String chartSeries;
	protected List<SCTrendingChartDataPoints> exportChartList;
	protected String groupBy;
	protected String level;
	protected String maxPercentage;
	protected String minPercentage;
	protected String measureIntervalName;
	protected String metric;
	protected String organization;
	protected String programName;
	protected String scorecardComponent;
	protected String scorecardComponentName;
	protected String selectedOrganization;
	protected String tickInterval;
	protected String trendChartLegendCds;
	protected String type;
	protected String providerGroupName;

	//	protected String provOrgDimKey;
	//	protected String provOrgName;

	public String getCalcCD() {
		return calcCD;
	}

	/*public List<ScorecardTrendLevelObj> getChartLevels() {
		return chartLevels;
	}*/

	/*public List<ScorecardTrendSeriesObj> getChartSeries() {
		return chartSeries;
	}*/

	public List<SCTrendingChartDataPoints> getExportChartList() {
		return exportChartList;
	}

	public String getMaxPercentage() {
		return maxPercentage;
	}

	public String getMinPercentage() {
		return minPercentage;
	}

	public String getTickInterval() {
		return tickInterval;
	}

	public String getTrendChartLegendCds() {
		return trendChartLegendCds;
	}

	public void setCalcCD(String calcCD) {
		this.calcCD = calcCD;
	}

	/*public void setChartLevels(List<ScorecardTrendLevelObj> chartLevels) {
		this.chartLevels = chartLevels;
	}*/

	/*public void setChartSeries(List<ScorecardTrendSeriesObj> chartSeries) {
		this.chartSeries = chartSeries;
	}*/

	public void setExportChartList(List<SCTrendingChartDataPoints> exportChartList) {
		this.exportChartList = exportChartList;
	}

	public void setMaxPercentage(String maxPercentage) {
		this.maxPercentage = maxPercentage;
	}

	public void setMinPercentage(String minPercentage) {
		this.minPercentage = minPercentage;
	}

	public void setTickInterval(String tickInterval) {
		this.tickInterval = tickInterval;
	}

	public void setTrendChartLegendCds(String trendChartLegendCds) {
		this.trendChartLegendCds = trendChartLegendCds;
	}

	public String getGroupBy() {
		return groupBy;
	}

	public void setGroupBy(String groupBy) {
		this.groupBy = groupBy;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getMeasureIntervalName() {
		return measureIntervalName;
	}

	public void setMeasureIntervalName(String measureIntervalName) {
		this.measureIntervalName = measureIntervalName;
	}

	public String getMetric() {
		return metric;
	}

	public void setMetric(String metric) {
		this.metric = metric;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public String getScorecardComponent() {
		return scorecardComponent;
	}

	public void setScorecardComponent(String scorecardComponent) {
		this.scorecardComponent = scorecardComponent;
	}

	public String getScorecardComponentName() {
		return scorecardComponentName;
	}

	public void setScorecardComponentName(String scorecardComponentName) {
		this.scorecardComponentName = scorecardComponentName;
	}

	public String getSelectedOrganization() {
		return selectedOrganization;
	}

	public void setSelectedOrganization(String selectedOrganization) {
		this.selectedOrganization = selectedOrganization;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getChartLevels() {
		return chartLevels;
	}

	public void setChartLevels(String chartLevels) {
		this.chartLevels = chartLevels;
	}

	public String getChartSeries() {
		return chartSeries;
	}

	public void setChartSeries(String chartSeries) {
		this.chartSeries = chartSeries;
	}


	public String getProviderGroupName() {
		return providerGroupName;
	}


	public void setProviderGroupName(String providerGroupName) {
		this.providerGroupName = providerGroupName;
	}

	/*	public String getProvOrgDimKey() {
			return provOrgDimKey;
		}

		public void setProvOrgDimKey(String provOrgDimKey) {
			this.provOrgDimKey = provOrgDimKey;
		}*/

	/*public String getProvOrgName() {
		return provOrgName;
	}

	public void setProvOrgName(String provOrgName) {
		this.provOrgName = provOrgName;
	}*/


}
