package com.wellpoint.pc2dash.action.patients;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.patient.OrgHierarchyWrapper;
import com.wellpoint.pc2dash.dto.patient.TreeHierarchy;
import com.wellpoint.pc2dash.dto.tinNpi.UserAcsIndicators;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.service.patient.OrganizationServiceImpl;
import com.wellpoint.pc2dash.util.ErrorProperties;

//import edu.emory.mathcs.backport.java.util.Collections;


public class GetPatientOrganizationAction extends Action {

	List<OrgHierarchyWrapper> resultList;
	ActionResponse response = new GetPatientOrganizationResponse();

	@SuppressWarnings("unchecked")
	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetPatientOrganizationRequest request = (GetPatientOrganizationRequest) actionRequest;

		OrganizationServiceImpl pC2Service = new OrganizationServiceImpl();
		List<TreeHierarchy> orgHierarchyList = new ArrayList<TreeHierarchy>();
		ErrorProperties err = ErrorProperties.getInstance();

		try {

			//PCMSRequest request = getDataMap(request);
			List<String> provGrpListFromRequest = new ArrayList<String>();
			//			provGrpListFromRequest = JSONUtils.getProviderListFromJsonString(request.get(Constants.USER_ACS_INFO_JSON));
			for (UserAcsIndicators u : request.getUserAcsInfoJson()) {
				provGrpListFromRequest.add(u.getProvGrpId());
			}

			if (null != provGrpListFromRequest && !provGrpListFromRequest.isEmpty()) {

				request.setProvGrpIds(StringUtils.join(provGrpListFromRequest, ','));

				resultList = pC2Service.getData(request);
				orgHierarchyList = pC2Service.getBeanList(resultList);

				//				Collections.sort(orgHierarchyList);
			}

			response = populateResponse(orgHierarchyList);
			response.setSuccess(true);

			if (resultList.isEmpty()) {
				response.setMessage(err.getProperty("successNoData"));
			}
			else {
				response.setMessage(err.getProperty("successful"));
			}

			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}

	private ActionResponse populateResponse(List<TreeHierarchy> orgHierarchyList) {

		((GetPatientOrganizationResponse) (response)).getChildren().addAll(orgHierarchyList);
		return response;
	}

	/**
	 * Populates and return a data Map with the request parameters, which further used by services
	 * 
	 * @param request
	 * @return
	 * @throws JsonException
	 */
	//	public Map<String, String> getDataMap(GetPatientOrganizationRequest request) throws JsonException{
	//
	//		//PCMSRequest request = new HashMap<String, String>();
	//
	//		if (request != null) {
	//
	//			//request.put("sessionId", request.getSessionId());
	//			//request.put("entitlementId", request.getEntitlementId());
	//			request.put("grpInd", request.getGrpInd());
	//			request.put(Constants.USER_ACS_INFO_JSON, request.getUserAcsInfoJson());
	//		}
	//
	//		return request;
	//	}
}
