package com.wellpoint.pc2dash.action.login;

import com.wellpoint.pc2dash.action.base.ActionResponse;


public class GetEntitlementResponse extends ActionResponse {

}
