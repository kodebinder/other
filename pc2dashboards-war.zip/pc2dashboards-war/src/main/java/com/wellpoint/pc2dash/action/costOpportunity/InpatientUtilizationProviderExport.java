package com.wellpoint.pc2dash.action.costOpportunity;

import java.util.List;
import java.util.Map;

import com.wellpoint.pc2dash.export.AbstractExport;
import com.wellpoint.pc2dash.export.ExportGridColumn;
import com.wellpoint.pc2dash.export.JasperPrintObjectBuilder;

import com.wellpoint.pc2dash.export.costOpportunity.InpatientUtilizationProviderDataSource;
import com.wellpoint.pc2dash.export.costOpportunity.InpatientUtilizationProviderReporter;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.globalFilters.GlobalFilterDataFetchService;
import com.wellpoint.pc2dash.util.Constants;

import net.sf.dynamicreports.jasper.builder.JasperReportBuilder;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JasperPrint;

public class InpatientUtilizationProviderExport extends AbstractExport {
	private static final Pc2DashLogger LOG = Pc2DashLogger.getLogger(InpatientUtilizationProviderExport.class);
	private static final String EXPORT_TITLE = "Inpatient_Utilization_Provider";

	private List<ExportGridColumn> columns;
	private GetInpatientUtilizationProviderRequest request;

	public InpatientUtilizationProviderExport(GetInpatientUtilizationProviderRequest request, List<ExportGridColumn> columns) {

		this.request = request;
		this.columns = columns;

		try {
			init(request);
		}
		catch (Exception e) {
			LOG.error("Unable to initialize export (" + EXPORT_TITLE + ")", e);
		}
	}

	@Override
	public String getTitle() {
		return EXPORT_TITLE;
	}

	@Override
	public void process() throws Exception {
		JasperReportBuilder jasperReportBuilderObj = new JasperReportBuilder();

		GlobalFilterDataFetchService globalFilterDataFetchService = new GlobalFilterDataFetchService();
		Map<String, Map<String, String>> globalFilterMaps = globalFilterDataFetchService.getCostOpportunityExportDataForGlobalFilter(request.getProvGrpIdsWithoutClinicalCheck(),
			request.getProgramIds(),
			request.getLobIds(), Constants.FLTR_IP_UTL);

		JRDataSource dataSource = new InpatientUtilizationProviderDataSource(request, getExportLimit());


		jasperReportBuilderObj = InpatientUtilizationProviderReporter.buildReportLayout(
			columns,
			request,
			globalFilterMaps,
			dataSource);

		JasperPrint printer = JasperPrintObjectBuilder.getPrintObject(jasperReportBuilderObj);
		writeOutput(printer, request.getDest());



	}

}
