package com.wellpoint.pc2dash.action.tap.patients;

import com.wellpoint.pc2dash.data.dto.PopulationManagementRequest;

public class GetChronicCareGapsChartRequest extends PopulationManagementRequest {

}
