package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.scoreCard.GetEpisodePatientsToolTipRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.scorecard.EpisodesPatientGrid;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;

public class EpisodesPatientsToolTipDao extends ServiceImpl{


	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(EpisodesPatientsToolTipDao.class);


	public List<EpisodesPatientGrid> getPatientGrid(GetEpisodePatientsToolTipRequest request) throws Exception {


		List<EpisodesPatientGrid> result = new ArrayList<EpisodesPatientGrid>();
		setRowCount(0);

		StringBuilder sql = new StringBuilder()
			.append("select ")
			.append(" a.* ")
			.append("from ( ")
			.append("select ")
			.append(" row_number() over ( ")
			.append(" order by ")
			.append("totalEpisodeCount desc")
			.append("	) as rank , count(*) over () as row_cnt,etgCondition,facilityAllowedAmount,anciliaryIPAllowedAmount,managementAllowedAmount,anciliaryOPAllowedAmount,surgeryAllowedAmount,pharmacyAllowedAmount,totalEpisodeCount ")
			.append("from ")
			.append("	( ")
			.append("select ")
			.append(" etgConditionCd,etgCondition,sum(facilityAllowedAmount) as facilityAllowedAmount,sum(anciliaryIPAllowedAmount) as anciliaryIPAllowedAmount,sum(managementAllowedAmount) as managementAllowedAmount,sum(anciliaryOPAllowedAmount) as anciliaryOPAllowedAmount,sum(surgeryAllowedAmount) as surgeryAllowedAmount,sum(pharmacyAllowedAmount) as pharmacyAllowedAmount, count(totalEpisodeCount) as totalEpisodeCount ");
		sql.append(" from  ")
			.append(" ( ")
			.append(" select ETG.ETG_BASE_CLS_CD as etgConditionCd,UPPER(ETG.ETG_BASE_CLS_DESC) as etgCondition, ");
		sql.append(" ETG.ANLZD_FCLTY_ALWD_AMT as facilityAllowedAmount,ETG.ANLZD_ANCLRY_INPAT_ALWD_AMT as anciliaryIPAllowedAmount,ETG.ANLZD_MNGMNT_ALWD_AMT as managementAllowedAmount,ETG.ANLZD_ANCLRY_OUTPAT_ALWD_AMT as anciliaryOPAllowedAmount,ETG.ANLZD_SRGRY_ALWD_AMT as surgeryAllowedAmount,ETG.ANLZD_PHRMCY_ALWD_AMT as pharmacyAllowedAmount, ETG.EPSD_NBR as totalEpisodeCount ");
		sql.append(" from  ")
			.append(" SCRCRD_ESN_ETG_MCID_FACT ETG  ")
			.append(" JOIN PAT_SMRY_FACT PSF ON  PSF.MSTR_CNSMR_DIM_KEY = ETG.MSTR_CNSMR_DIM_KEY and PSF.prov_grp_dim_key = ETG.prov_grp_dim_key")
			.append(" and PSF.ip_dim_key = ETG.ip_dim_key ") // and PSF.prov_org_dim_key = ETG.prov_org_dim_key")
			.append("	join poit_user_scrty_acs pusa on ( ")
			.append("		psf.prov_grp_id = pusa.prov_grp_id ")
			.append("		and case ")
			.append("				when pusa.prov_org_tax_id = '0' then psf.prov_org_tax_id ")
			.append("				else pusa.prov_org_tax_id ")
			.append("			end = psf.prov_org_tax_id ")
			.append("	) ")
			.append("  WHERE ");
		sql.append("  PSF.ATRBN_STTS_CD = 'ACTIVE' ")
			.append(" and pusa.sesn_id = ? ")
			.append(" and pusa.enttlmnt_hash_key = ? ");
		
		sql = addAgeFilter(request, sql, "psf");

		if (StringUtil.isNotBlankOrFalse(request.getProvGrpIds())) {
			sql.append(" and psf.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvGrpIds()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProgramId())) {
			sql.append(" and psf.pgm_id in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProgramId()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getLobNm())) {
			/** 66200 PSL Desc Changes | ad87338 | START */
			sql.append(" and psf.lob_ctgry_nm in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getLobNm()) + ") ");
			/** 66200 PSL Desc Changes | ad87338 | END */
		}

		// Organization filter
		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			sql.append(" and psf.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			sql.append(" and psf.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getMemberKey())) {
			sql.append(" and psf.mstr_cnsmr_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getMemberKey())
				+ ") ");
		}
		
		sql.append(" group by 	ETG.ETG_BASE_CLS_CD ,UPPER(ETG.ETG_BASE_CLS_DESC), ETG.ANLZD_FCLTY_ALWD_AMT,ETG.ANLZD_ANCLRY_INPAT_ALWD_AMT,ETG.ANLZD_MNGMNT_ALWD_AMT,ETG.ANLZD_ANCLRY_OUTPAT_ALWD_AMT,ETG.ANLZD_SRGRY_ALWD_AMT,ETG.ANLZD_PHRMCY_ALWD_AMT,ETG.EPSD_NBR  ) ");
		sql.append(" group by  etgConditionCd,etgCondition) PatientToolTip ) a  ");

		// Do not apply the limit if the request is for export
		//if (!StringUtil.isExportDest(request.getDest())
		//	&& StringUtils.isNotBlank(request.getStart()) && StringUtils.isNotBlank(request.getLimit())) {
			sql.append(" where a.rank between ? and ? ");
		//}

		sql.append(" order by a.rank ");
		sql.append(" with ur ");



		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, sql.toString());

			
			ps.setString(++i, request.getSessionId());
			ps.setString(++i, request.getEntitlementId());

			// Group Ids
			if (StringUtil.isNotBlankOrFalse(request.getProvGrpIds())) {
				String[] array = request.getProvGrpIds().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// Program filters
			if (StringUtil.isNotBlankOrFalse(request.getProgramId())) {
				String[] array = request.getProgramId().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// LOB filters
			if (StringUtil.isNotBlankOrFalse(request.getLobNm())) {
				String[] array = request.getLobNm().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// Organization filter
			if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
				String[] array = request.getProvDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, StringUtil.parseProviderId(item));
				}
			}
			if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
				String[] array = request.getOrgDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}
			
			if (StringUtil.isNotBlankOrFalse(request.getMemberKey())) {
				ps.setString(++i, request.getMemberKey());
			}

			// Do not apply the limit if the request is for export
			//if (!StringUtil.isExportDest(request.getDest())
			//	&& StringUtils.isNotBlank(request.getStart()) && StringUtils.isNotBlank(request.getLimit())) {
				int start = Integer.parseInt(request.getStart());
				int limit = Integer.parseInt(request.getLimit());
				ps.setInt(++i, start + 1);
				ps.setInt(++i, start + limit);
			//}

			executeQuery(logger, sql.toString());

			while (rs.next()) {

				EpisodesPatientGrid jsonResult = new EpisodesPatientGrid();

				
				if (rs.getString("etgCondition") != null){
					jsonResult.setEtgCondition(rs.getString("etgCondition"));
				}else{
					jsonResult.setEtgCondition(Constants.DASHES);
				}
				if (rs.getString("totalEpisodeCount") != null) {
					jsonResult.setTotalEpisodeCount(rs.getString("totalEpisodeCount"));
				}else{
					jsonResult.setTotalEpisodeCount(Constants.DASHES);
				}
				if (rs.getString("facilityAllowedAmount") != null) {
					jsonResult.setFacilityAllowedAmount(rs.getString("facilityAllowedAmount"));
				}else{
					jsonResult.setFacilityAllowedAmount(Constants.DASHES);
				}
				if (rs.getString("anciliaryIPAllowedAmount") != null) {
					jsonResult.setAnciliaryIPAllowedAmount(rs.getString("anciliaryIPAllowedAmount"));
				}else{
					jsonResult.setAnciliaryIPAllowedAmount(Constants.DASHES);
				}
				if (rs.getString("managementAllowedAmount") != null) {
					jsonResult.setManagementAllowedAmount(rs.getString("managementAllowedAmount"));
				}else{
					jsonResult.setManagementAllowedAmount(Constants.DASHES);
				}
				if (rs.getString("anciliaryOPAllowedAmount") != null) {
					jsonResult.setAnciliaryOPAllowedAmount(rs.getString("anciliaryOPAllowedAmount"));
				}else{
					jsonResult.setAnciliaryOPAllowedAmount(Constants.DASHES);
				}
				if (rs.getString("surgeryAllowedAmount") != null) {
					jsonResult.setSurgeryAllowedAmount(rs.getString("surgeryAllowedAmount"));
				}else{
					jsonResult.setSurgeryAllowedAmount(Constants.DASHES);
				}
				if (rs.getString("pharmacyAllowedAmount") != null) {
					jsonResult.setPharmacyAllowedAmount(rs.getString("pharmacyAllowedAmount"));
				}else{
					jsonResult.setPharmacyAllowedAmount(Constants.DASHES);
				}

				setRowCount(rs.getInt("row_cnt"));

				result.add(jsonResult);
			}
			//	setRowCount(rs.getInt("row_cnt"));
		}
		catch (Exception e) {

			throw new Exception("Unable to get EpisodesPatientToolTip(" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;

	}


}
