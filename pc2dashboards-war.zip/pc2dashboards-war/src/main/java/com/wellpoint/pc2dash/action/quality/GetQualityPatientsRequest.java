package com.wellpoint.pc2dash.action.quality;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.wellpoint.pc2dash.action.drilldown.GetDrillDownRequest;

public class GetQualityPatientsRequest extends GetDrillDownRequest {
	//	private String memberFullNameQuery;
	//	private String memberFirstName; // populated by GetQualityPatientsAction.cleanRequest()
	//	private String memberLastName; // populated by GetQualityPatientsAction.cleanRequest()

	//	public String getMemberFullNameQuery() {
	//		return memberFullNameQuery;
	//	}
	//	public void setMemberFullNameQuery(String memberFullNameQuery) {
	//		this.memberFullNameQuery = memberFullNameQuery;
	//	}
	//	public String getMemberFirstName() {
	//		return memberFirstName;
	//	}
	//	public void setMemberFirstName(String memberFirstName) {
	//		this.memberFirstName = memberFirstName;
	//	}
	//	public String getMemberLastName() {
	//		return memberLastName;
	//	}
	//	public void setMemberLastName(String memberLastName) {
	//		this.memberLastName = memberLastName;
	//	}

	/**
	 * @return The String representation of this class as constructed via
	 *         reflection by Apache Commons ToStringBuilder.
	 */
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
