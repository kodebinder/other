package com.wellpoint.pc2dash.data.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.costOpportunity.GetAmbulatorySurgeryProcedureRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.costOpportunity.AmbulatorySurgeryProcedureBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class AmbulatorySurgeryProcedureDao extends ServiceImpl {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(AmbulatorySurgeryProcedureDao.class);

	private boolean displayDashes = false;

	public List<AmbulatorySurgeryProcedureBean> getData(GetAmbulatorySurgeryProcedureRequest request, boolean exportFlag, int index, int limit) throws Exception {

		List<AmbulatorySurgeryProcedureBean> result = new ArrayList<AmbulatorySurgeryProcedureBean>();
		setRowCount(0);

		String dir = request.getSort().get(0).getDirection();
		String masked = "asc".equalsIgnoreCase(dir) ? String.valueOf(Integer.MAX_VALUE) : String.valueOf(Integer.MIN_VALUE); // we want masked values to always be at the bottom, so use either the biggest or smallest value, depending
		String dashesClause =
			" sum(srgry_cnt) < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_ASC_MIN_TOTL_SRGRY' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG') ";
		String multiplePgmCheck_10_Perc = " or  ((SUM(count(distinct BNCHMRK_PCTILE_10_NBR)) over (partition by procedureCode, procedureType)) > 1) ";
		String multiplePgmCheck_90_Perc = " or  ((SUM(count(distinct BNCHMRK_PCTILE_90_NBR)) over (partition by procedureCode, procedureType)) > 1) ";

		StringBuilder query =
			new StringBuilder()
				.append(" select   c.* ")
				.append(" from   ( ")
				.append("   select   b.*, row_number() over( order by ")
				.append(buildSortClause(request))
				.append(" ) as row_nbr ")
				.append("   from   ( ")
				.append("     select ")
				.append("       a.procedureType, ")
				.append("       a.procedureCode, ")
				.append("       a.totalOpportunity, ")
				.append("       a.tenPercentImprovement, ")
				.append("       a.totalOpportunityPMPM, ")
				.append("       a.tenPercentImprovementPMPM, ")
				.append("       a.totalSurgeryCount, ")
				.append("       a.totalHighCostSurgeryCount, ")
				.append("       a.currentPerformanceRate, ")
				.append("       a.percentileBenchmark90, ")
				.append("       a.percentileBenchmark10, ")
				.append("       a.row_cnt as row_cnt, ")
				.append("       a.BNCH_90_CNT, ")
				.append("       a.BNCH_10_CNT, ")
				.append("       a.dsply_dashes ")
				.append("     from  ( ")
				.append("       select ")
				.append("         procedureType, ")
				.append("         procedureCode, ")
				.append(" case when ")
				.append(dashesClause)
				.append(" then ")
				.append(masked)
				.append(" when sum(cost_oprtnty_amt) >= 0 then sum(cost_oprtnty_amt) else 0.00 end as totalOpportunity, ")

				/*.append("  when  sum(HCOST_SITE_CASE_CNT) ")
				.append("  *(case when sum(CMAD_HCOST_SITE_NBR) <= 0 then 0 else cast(sum(HCOST_SITE_TOTL_AMT) as decimal(18, 5))/sum(CMAD_HCOST_SITE_NBR) end ")
				.append("  -case when sum(CMAD_LOW_COST_SITE_NBR) <= 0  then 0 else cast(sum(LOW_COST_SITE_TOTL_AMT) as decimal(18, 5))/sum(CMAD_LOW_COST_SITE_NBR) end ) ")
				.append("  *sum(CASE_MIX_ADJSTMNT_FCTR)/sum(CASE_MIX_ADJSTMNT_SRGRY_CNT) >= 0 ")
				.append("  then  ")
				.append("  sum(HCOST_SITE_CASE_CNT)")
				.append(" *(case when sum(CMAD_HCOST_SITE_NBR) <= 0 then 0 else cast(sum(HCOST_SITE_TOTL_AMT) as decimal(18, 5))/sum(CMAD_HCOST_SITE_NBR) end ")
				.append(" -case when sum(CMAD_LOW_COST_SITE_NBR) <= 0 then 0 else cast(sum(LOW_COST_SITE_TOTL_AMT) as decimal(18, 5))/sum(CMAD_LOW_COST_SITE_NBR) end)")
				.append(" *sum(CASE_MIX_ADJSTMNT_FCTR)/sum(CASE_MIX_ADJSTMNT_SRGRY_CNT) ")
				 .append(" else  0 end as totalOpportunity, ")*/

				.append(" case when ")
				.append(dashesClause)
				.append(" then ")
				.append(masked)
				.append(" when sum(cost_oprtnty_amt) >= 0 then CAST((sum(COST_OPRTNTY_AMT) * 0.1) as decimal(18,4)) else 0.00 end  as tenPercentImprovement, ")

				/* .append("  when  0.1 * sum(HCOST_SITE_CASE_CNT) ")
				.append("  *(case when sum(CMAD_HCOST_SITE_NBR) <= 0 then 0 else cast(sum(HCOST_SITE_TOTL_AMT) as decimal(18, 5))/sum(CMAD_HCOST_SITE_NBR) end ")
				.append("  -case when sum(CMAD_LOW_COST_SITE_NBR) <= 0  then 0 else cast(sum(LOW_COST_SITE_TOTL_AMT) as decimal(18, 5))/sum(CMAD_LOW_COST_SITE_NBR) end) ")
				.append("  *sum(CASE_MIX_ADJSTMNT_FCTR)/sum(CASE_MIX_ADJSTMNT_SRGRY_CNT) >= 0 ")
				.append(" then  0.1 * sum(HCOST_SITE_CASE_CNT) ")
				.append("  *(case when sum(CMAD_HCOST_SITE_NBR) <= 0 then 0 else cast(sum(HCOST_SITE_TOTL_AMT) as decimal(18, 5))/sum(CMAD_HCOST_SITE_NBR) end ")
				.append("  -case when sum(CMAD_LOW_COST_SITE_NBR) <= 0 then 0 else cast(sum(LOW_COST_SITE_TOTL_AMT) as decimal(18, 5))/sum(CMAD_LOW_COST_SITE_NBR) end) ")
				.append("   *sum(CASE_MIX_ADJSTMNT_FCTR)/sum(CASE_MIX_ADJSTMNT_SRGRY_CNT) ")
				 .append("   else  0 end as tenPercentImprovement,  ")*/

				.append(" case when ")
				.append(dashesClause)
				.append(" then ")
				.append(masked)
				.append(" when sum(cost_oprtnty_amt) >= 0 and MEM_MNTH > 0 then cast(sum(cost_oprtnty_amt) as decimal(18,4))/ cast(MEM_MNTH as decimal (18,4)) else 0.00 end as totalOpportunityPMPM, ")

				/* .append("  when  sum(HCOST_SITE_CASE_CNT) ")
				.append("   *(case when sum(CMAD_HCOST_SITE_NBR) <= 0 then 0 else cast(sum(HCOST_SITE_TOTL_AMT) as decimal(18, 5))/sum(CMAD_HCOST_SITE_NBR) end ")
				.append("    -case when sum(CMAD_LOW_COST_SITE_NBR) <= 0  then 0 else cast(sum(LOW_COST_SITE_TOTL_AMT) as decimal(18, 5))/sum(CMAD_LOW_COST_SITE_NBR) end) ")
				.append("    *sum(CASE_MIX_ADJSTMNT_FCTR)/sum(CASE_MIX_ADJSTMNT_SRGRY_CNT) >= 0  ")
				.append("  and  MEM_MNTH > 0  ")
				 .append("   then  cast(sum(HCOST_SITE_CASE_CNT) ")
				.append("    *(case when sum(CMAD_HCOST_SITE_NBR) <= 0 then 0 else cast(sum(HCOST_SITE_TOTL_AMT) as decimal(18, 5))/sum(CMAD_HCOST_SITE_NBR) end ")
				.append("    -case when sum(CMAD_LOW_COST_SITE_NBR) <= 0  then 0 else cast(sum(LOW_COST_SITE_TOTL_AMT) as decimal(18, 5))/sum(CMAD_LOW_COST_SITE_NBR) end) ")
				.append("    *sum(CASE_MIX_ADJSTMNT_FCTR)/sum(CASE_MIX_ADJSTMNT_SRGRY_CNT) as decimal(18,4))/ cast( MEM_MNTH as decimal (18,4)) ")
				.append("  else  0.00 end as totalOpportunityPMPM,  ")*/

				.append(" case when ")
				.append(dashesClause)
				.append(" then ")
				.append(masked)
				.append(" when sum(cost_oprtnty_amt) >= 0 and MEM_MNTH > 0 then ((cast(sum(cost_oprtnty_amt) as decimal(18,4))/ cast(MEM_MNTH as decimal (18,4))) * 0.1) else 0.00 end as tenPercentImprovementPMPM, ")

				/* .append("  when  0.1 * sum(HCOST_SITE_CASE_CNT) ")
				.append("   *(case when sum(CMAD_HCOST_SITE_NBR) <= 0 then 0 else cast(sum(HCOST_SITE_TOTL_AMT) as decimal(18, 5))/sum(CMAD_HCOST_SITE_NBR) end ")
				.append("   -case when sum(CMAD_LOW_COST_SITE_NBR) <= 0  then 0 else cast(sum(LOW_COST_SITE_TOTL_AMT) as decimal(18, 5))/sum(CMAD_LOW_COST_SITE_NBR) end) ")
				.append("   *sum(CASE_MIX_ADJSTMNT_FCTR)/sum(CASE_MIX_ADJSTMNT_SRGRY_CNT) >= 0  ")
				.append(" and  MEM_MNTH > 0 ")
				 .append(" then  ((cast(0.1 * sum(HCOST_SITE_CASE_CNT) ")
				.append("  *(case when sum(CMAD_HCOST_SITE_NBR) <= 0 then 0 else cast(sum(HCOST_SITE_TOTL_AMT) as decimal(18, 5))/sum(CMAD_HCOST_SITE_NBR) end ")
				.append("  -case when sum(CMAD_LOW_COST_SITE_NBR) <= 0  then 0 else cast(sum(LOW_COST_SITE_TOTL_AMT) as decimal(18, 5))/sum(CMAD_LOW_COST_SITE_NBR) end) ")
				.append(" *sum(CASE_MIX_ADJSTMNT_FCTR)/sum(CASE_MIX_ADJSTMNT_SRGRY_CNT) as decimal(18,4))/ cast( MEM_MNTH as decimal (18,4)))) ")
				.append(" else  0.00 end as tenPercentImprovementPMPM, ")*/

				.append(" sum(srgry_cnt) as totalSurgeryCount, ")
				.append(" sum(HSRGRY_CNT) as totalHighCostSurgeryCount, ")
				.append(" case when ")
				.append(dashesClause)
				.append(" then ")
				.append(masked)
				.append(
					" when sum(srgry_cnt) > 0 then (100 * CAST(sum(HSRGRY_CNT) as decimal(18,4)) / CAST(sum(srgry_cnt) as decimal(18,4))) else 0.00 end as currentPerformanceRate, ")
				.append(" case when ")
				.append(dashesClause)
				.append(multiplePgmCheck_90_Perc)
				.append(" then ")
				.append(masked)
				.append(" else max(BNCHMRK_PCTILE_90_NBR) end as percentileBenchmark90, ")
				.append(" case when ")
				.append(dashesClause)
				.append(multiplePgmCheck_10_Perc)
				.append(" then ")
				.append(masked)
				.append(" else max(BNCHMRK_PCTILE_10_NBR) end as percentileBenchmark10, ")
				.append(" count(*) over () as row_cnt, ")
				.append(" case when ")
				.append(dashesClause)
				.append(" then ")
				.append(masked)
				.append(" else SUM(count(distinct BNCHMRK_PCTILE_90_NBR)) over (partition by procedureCode, procedureType) end as BNCH_90_CNT, ")
				.append(" case when ")
				.append(dashesClause)
				.append(" then ")
				.append(masked)
				.append(" else SUM(count(distinct BNCHMRK_PCTILE_10_NBR)) over (partition by procedureCode, procedureType) end as BNCH_10_CNT, ")
				.append(" case when ")
				.append(dashesClause)
				.append(" then 'Y' else 'N' end as dsply_dashes from ( ")

				/*changed now*/.append("  select  smry.sub_mtrc_nm as procedureType,  smry.sub_mtrc_cd as procedureCode,  sum(COST_OPRTNTY_AMT) as COST_OPRTNTY_AMT, ")
				/*.append(" sum(HCOST_SITE_CASE_CNT) as HCOST_SITE_CASE_CNT,  ")
				.append(" sum(HCOST_SITE_TOTL_AMT) as HCOST_SITE_TOTL_AMT,  ")
				.append(" sum(LOW_COST_SITE_TOTL_AMT) as LOW_COST_SITE_TOTL_AMT,  ")
				.append(" sum(CASE_MIX_ADJSTMNT_FCTR) as CASE_MIX_ADJSTMNT_FCTR,  ")
				.append(" sum(CASE_MIX_ADJSTMNT_SRGRY_CNT) as CASE_MIX_ADJSTMNT_SRGRY_CNT,  ")
				.append(" sum(CMAD_HCOST_SITE_NBR) as CMAD_HCOST_SITE_NBR,  ")
				.append(" sum(CMAD_LOW_COST_SITE_NBR) as CMAD_LOW_COST_SITE_NBR,  ")*/
				/*change complete*/.append(" sum(srgry_cnt) as srgry_cnt, ")
				.append(" ILV.MEM_MNTH as MEM_MNTH , ")

				/*.append(" select smry.sub_mtrc_nm as procedureType, ")
				.append(" smry.sub_mtrc_cd as procedureCode, ")
				.append(" sum(HCOST_SITE_CASE_CNT)*(sum(HCOST_SITE_TOTL_AMT)-sum(LOW_COST_SITE_TOTL_AMT))*sum(CASE_MIX_ADJSTMNT_FCTR)/sum(CASE_MIX_ADJSTMNT_SRGRY_CNT) as cost_oprtnty_amt, ") // per Sathish
				.append(" 0.1*sum(HCOST_SITE_CASE_CNT)*(sum(HCOST_SITE_TOTL_AMT)-sum(LOW_COST_SITE_TOTL_AMT))*sum(CASE_MIX_ADJSTMNT_FCTR)/sum(CASE_MIX_ADJSTMNT_SRGRY_CNT) as cost_oprtnty_10_pctag_amt, ") // per Sathish
				.append(" sum(mbr_mnth_cnt) as mbr_mnth_cnt,")
				.append(" sum(srgry_cnt) as srgry_cnt, "*/

				.append(" case when hcost_ind = 'Y' then sum(srgry_cnt) else 0 end as HSRGRY_CNT, smry.BNCHMRK_PCTILE_90_NBR, smry.BNCHMRK_PCTILE_10_NBR ")
				.append("       from  coc_asc_ctgry_smry smry ")

				.append(" join (select  ")
				.append(" nvl(SUM(MM.MBR_MNTH_12_CNT),0) as MEM_MNTH ")
				.append(" FROM  PAT_SMRY_FACT PSF ")
				.append(" INNER JOIN MSTR_CNSMR_MBR_MNTH_FACT MM ON ")
				.append(" MM.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY ")
				.append(" AND MM.RCRD_STTS_CD = 'ACT' ")
				.append(" AND PSF.ATRBN_STTS_CD = 'ACTIVE' ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and psf.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and psf.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and psf.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and psf.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and psf.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}



		query.append(" ) as ILV on 1=1 ")

			.append("         join  poit_user_scrty_acs pusa on (smry.prov_grp_id = pusa.prov_grp_id and ")
			.append("           case ")
			.append("                      when    pusa.prov_org_tax_id = '0' ")
			.append("                      then    smry.prov_org_tax_id ")
			.append("                      else    pusa.prov_org_tax_id end = smry.prov_org_tax_id) ")
			.append("       where  pusa.sesn_id = ? ")
			.append("       and  pusa.enttlmnt_hash_key = ? ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and smry.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and smry.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and smry.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and smry.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and smry.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}

		// Changes for PCMSP-7421 - Procedure Filter
		if (StringUtil.isNotBlankOrFalse(request.getProcedureCode())) {
			query.append(" and smry.SUB_MTRC_CD in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProcedureCode())
				+ ") ");
		}

		query.append("       group by ")
			.append("         smry.sub_mtrc_nm, ")
			.append("         smry.sub_mtrc_cd, ")
			.append("         smry.hcost_ind, ")
			.append("         smry.BNCHMRK_PCTILE_90_NBR, ")
			.append("         smry.BNCHMRK_PCTILE_10_NBR, ILV.MEM_MNTH ) ")
			.append(" group by procedureType,procedureCode, MEM_MNTH")
			.append("     ) as a ")
			.append("   ) as b ")
			.append(" ) as c ");

		/*if (!exportFlag) {
			query.append("where  c.row_nbr between ? and ? ");
		}
		query.append(" order by   c.row_nbr  with ur ");*/
		query.append("where  c.row_nbr between ? and ? ");
		query.append(" order by   c.row_nbr  with ur ");



		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());

			buildPreparedStatement(request, i, exportFlag, index, limit);

			executeQuery(logger, query.toString());

			result = convertSelectedRowsToObjects(rs, request, displayDashes, exportFlag);

		}
		catch (Exception e) {

			throw new Exception("Unable to get AmbulatorySurgeryProcedureDao (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;

	}

	private void buildPreparedStatement(GetAmbulatorySurgeryProcedureRequest request, int i, boolean exportFlag, int index, int limit) throws SQLException {

		//For PMPM Starts
		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}
		//For PMPM Ends
		int start = 0;
		int stop = 0;

		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProcedureCode())) { // PCMSP-7421
			String[] array = request.getProcedureCode().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (!exportFlag) {
			start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
			stop = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
		}
		else {
			start = index;
			stop = limit;
		}
		ps.setInt(++i, start + 1);
		ps.setInt(++i, start + stop);

	}

	private List<AmbulatorySurgeryProcedureBean> convertSelectedRowsToObjects(ResultSet rs, GetAmbulatorySurgeryProcedureRequest request, boolean displayDashes, boolean exportFlag)
		throws SQLException {

		List<AmbulatorySurgeryProcedureBean> list = new ArrayList<AmbulatorySurgeryProcedureBean>();


		if (exportFlag) {
			while (rs.next()) {

				AmbulatorySurgeryProcedureBean item = new AmbulatorySurgeryProcedureBean();

				item.setProcedureType(rs.getString("procedureType"));
				item.setProcedureCode(rs.getString("procedureCode"));
				item.setTotalSurgeryCount(rs.getString("totalSurgeryCount"));
				item.setTotalHighCostSurgeryCount(rs.getString("totalHighCostSurgeryCount"));

				if (rs.getString("dsply_dashes") != null && rs.getString("dsply_dashes").equalsIgnoreCase(Constants.Y)) {
					displayDashes = true;
				}
				else {
					displayDashes = false;
				}

				if (displayDashes) {

					item.setTotalOpportunity(Constants.DASHES);
					item.setTenPercentImprovement(Constants.DASHES);
					item.setTotalOpportunityPMPM(Constants.DASHES);
					item.setTenPercentImprovementPMPM(Constants.DASHES);
					item.setCurrentPerformanceRate(Constants.DASHES);
					item.setPercentileBenchmark90(Constants.DASHES);
					item.setPercentileBenchmark10(Constants.DASHES);
					item.setProcedureTypeInd(false);
				}
				else {
					if (rs.getString("totalOpportunity") != null) {
						item.setTotalOpportunity(StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("totalOpportunity").setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
					}
					if (rs.getString("tenPercentImprovement") != null) {
						item.setTenPercentImprovement(
							StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("tenPercentImprovement").setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
					}
					if (rs.getString("totalOpportunityPMPM") != null) {
						item.setTotalOpportunityPMPM(
							StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("totalOpportunityPMPM").setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
					}
					if (rs.getString("tenPercentImprovementPMPM") != null) {
						item.setTenPercentImprovementPMPM(
							StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("tenPercentImprovementPMPM").setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
					}

					if (rs.getString("currentPerformanceRate") != null) {
						item.setCurrentPerformanceRate(
							StringUtil.convertStringToCommaBigDecimal(rs.getBigDecimal("currentPerformanceRate").setScale(2, BigDecimal.ROUND_HALF_UP).toString(), 2).concat("%"));
					}

					if (rs.getShort("BNCH_10_CNT") == Constants.INT_ONE) {
						item.setPercentileBenchmark10(
							StringUtil.convertStringToCommaBigDecimal(rs.getBigDecimal("percentileBenchmark10").setScale(2, BigDecimal.ROUND_HALF_UP).toString(), 2).concat("%"));
					}
					else {
						item.setPercentileBenchmark10(Constants.DASHES);
					}
					if (rs.getShort("BNCH_90_CNT") == Constants.INT_ONE) {
						item.setPercentileBenchmark90(
							StringUtil.convertStringToCommaBigDecimal(rs.getBigDecimal("percentileBenchmark90").setScale(2, BigDecimal.ROUND_HALF_UP).toString(), 2).concat("%"));
					}
					else {
						item.setPercentileBenchmark90(Constants.DASHES);
					}

					item.setProcedureTypeInd(true);
				}

				list.add(item);

				if (getRowCount() == 0) {
					setRowCount(rs.getInt("row_cnt"));
				}
				setTotalExport(rs.getInt("row_cnt"));   

			}
		}
		else {
			while (rs.next()) {

				AmbulatorySurgeryProcedureBean item = new AmbulatorySurgeryProcedureBean();

				item.setProcedureType(rs.getString("procedureType"));
				item.setProcedureCode(rs.getString("procedureCode"));
				item.setTotalSurgeryCount(rs.getString("totalSurgeryCount"));
				item.setTotalHighCostSurgeryCount(rs.getString("totalHighCostSurgeryCount"));

				if (rs.getString("dsply_dashes") != null && rs.getString("dsply_dashes").equalsIgnoreCase(Constants.Y)) {
					displayDashes = true;
				}
				else {
					displayDashes = false;
				}

				if (displayDashes) {
					item.setCurrentPerformanceRate(Constants.DASHES);
					item.setPercentileBenchmark10(Constants.DASHES);
					item.setPercentileBenchmark90(Constants.DASHES);
					item.setTenPercentImprovement(Constants.DASHES);
					item.setTenPercentImprovementPMPM(Constants.DASHES);
					item.setTotalOpportunity(Constants.DASHES);
					item.setTotalOpportunityPMPM(Constants.DASHES);
					item.setProcedureTypeInd(false);
				}
				else {
					item.setCurrentPerformanceRate(rs.getString("currentPerformanceRate"));
					if (rs.getShort("BNCH_10_CNT") == Constants.INT_ONE) {
						item.setPercentileBenchmark10(rs.getString("percentileBenchmark10"));
					}
					else {
						item.setPercentileBenchmark10(Constants.DASHES);
					}
					if (rs.getShort("BNCH_90_CNT") == Constants.INT_ONE) {
						item.setPercentileBenchmark90(rs.getString("percentileBenchmark90"));
					}
					else {
						item.setPercentileBenchmark90(Constants.DASHES);
					}
					item.setTenPercentImprovement(rs.getString("tenPercentImprovement"));
					item.setTenPercentImprovementPMPM(rs.getString("tenPercentImprovementPMPM"));
					item.setTotalOpportunity(rs.getString("totalOpportunity"));
					item.setTotalOpportunityPMPM(rs.getString("totalOpportunityPMPM"));
					item.setProcedureTypeInd(true);
				}

				list.add(item);

				if (getRowCount() == 0) {
					setRowCount(rs.getInt("row_cnt"));
				}

			}

		}

		return list;

	}

	private String buildSortClause(GetAmbulatorySurgeryProcedureRequest request) {

		StringBuilder query = new StringBuilder();
		String defaultColumn = " totalOpportunity ";
		String defaultSort = defaultColumn + " desc ";

		if (null != request.getSort()) {

			for (QuerySort sort : request.getSort()) {

				String dir = sort.getDirection().replaceAll("\"", "");
				String property = sort.getProperty();

				if (property.equals("procedureType")) {
					query.append(" procedureType " + dir + ", " + defaultSort);
				}
				else if (property.equals("procedureCode")) {
					query.append(" procedureCode " + dir + ", " + defaultSort);
				}
				else if (property.equals("totalOpportunity")) {
					query.append(" totalOpportunity " + dir + ", " + defaultSort);
				}
				else if (property.equals("tenPercentImprovement")) {
					query.append(" tenPercentImprovement " + dir + ", " + defaultSort);
				}
				else if (property.equals("totalOpportunityPMPM")) {
					query.append(" totalOpportunityPMPM " + dir + ", " + defaultSort);
				}
				else if (property.equals("tenPercentImprovementPMPM")) {
					query.append(" tenPercentImprovementPMPM " + dir + ", " + defaultSort);
				}
				else if (property.equals("totalSurgeryCount")) {
					query.append(" totalSurgeryCount " + dir + ", " + defaultSort);
				}
				else if (property.equals("totalHighCostSurgeryCount")) {
					query.append(" totalHighCostSurgeryCount " + dir + ", " + defaultSort);
				}
				else if (property.equals("currentPerformanceRate")) {
					query.append(" currentPerformanceRate " + dir + ", " + defaultSort);
				}
				else if (property.equals("percentileBenchmark90")) {
					query.append(" percentileBenchmark90 " + dir + ", " + defaultSort);
				}
				else if (property.equals("percentileBenchmark10")) {
					query.append(" percentileBenchmark10 " + dir + ", " + defaultSort);
				}
				else {
					query.append(defaultColumn + dir);
				}
			}

		}
		else {

		}

		return query.toString();

	}

	/*private String getMaskedOrActualValue(boolean displayDashes, String maskedValue, String columnName) {
	
		String value;
	
		if (displayDashes) {
			value = maskedValue;
		}
		else {
			value = columnName;
		}
	
		return value;
	
	}*/

}
