package com.wellpoint.pc2dash.action.costOpportunity;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetCostOpportunityAverageCostPerRxDrugDetailTotalResponse extends ActionResponse {

}
