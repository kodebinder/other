package com.wellpoint.pc2dash.data.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;
import com.wellpoint.pc2dash.dto.scorecard.ScorecardSubcompositeBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.DateUtil;
import com.wellpoint.pc2dash.util.StringUtil;


public class MedicaidScorecardBySubcompositeFactsDao extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(MedicaidScorecardBySubcompositeFactsDao.class);

	public Collection<ScorecardSubcompositeBean> getScorecardMedicaidMeasures(PerformanceManagementRequest request) throws Exception {

		Collection<ScorecardSubcompositeBean> result = new ArrayList<ScorecardSubcompositeBean>();

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			request.getCompositeId();
			String cmpstTypeDesc = request.getCompositeType();
			Set<String> subCmpstDefnIdWithGroup = new HashSet<String>();
			String scrngLvlCd;
			String subCmpstDefnId;
			String qrtrId = null;
			Map<String, Set<String>> scrngLvlMap = new HashMap<String, Set<String>>();

			String improvement = "Improvement";
			if (cmpstTypeDesc.equalsIgnoreCase(improvement)) {

				StringBuilder sql = new StringBuilder();
				sql.append("SELECT DISTINCT ms.MSR_DSPLY_NM , ")
					.append("ms.MSR_DIM_KEY , ")
					.append("ms.MSR_ID , ")
					.append("ipgsf.SCORG_LVL_CD , ")
					.append("ipgsf.TRGT_RT_PCT , ")
					.append("ipgsf.CURNT_CMPLNC_RT_PCT , ")
					.append("ipgsf.RDSTRBTD_ERNCNTR_PCT , ")
					.append("ipgsf.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT , ")
					.append("smhd.SUB_CMPST_NM , ")
					.append("smhd.CMPST_DEFN_ID,")
					.append("smhd.SUB_CMPST_DEFN_ID,")
					.append("ipgsf.MSR_DNMNTR_NBR, ")
					.append("ipgsf.ANLYSS_AS_OF_DT ")
					.append("FROM ")
					.append("IMPRV_PROV_GRP_SMRY_FACT ipgsf ")
					.append("join SCRCRD_MSR_HRCHY_DIM smhd on ( ")
					.append(" ipgsf.SCRCRD_MSR_HRCHY_DIM_KEY = smhd.SCRCRD_MSR_HRCHY_DIM_KEY ")
					.append(" ) ")
					.append("join SCRCRD_PGM_MSR_HRCHY_FACT spmhf on ( ")
					.append(" ipgsf.PGM_DIM_KEY = spmhf.PGM_DIM_KEY AND  ")
					.append(" ipgsf.SCRCRD_MSR_HRCHY_DIM_KEY = spmhf.SCRCRD_MSR_HRCHY_DIM_KEY AND  ")
					.append(" ipgsf.MSRMNT_PRD_STRT_DT = spmhf.MSRMNT_PRD_STRT_DT ")
					.append(" ) ")
					.append("join MSR_DIM ms on (")
					.append(" smhd.MSR_DIM_KEY = ms.MSR_DIM_KEY AND ")
					.append(" ipgsf.MSR_DIM_KEY = ms.MSR_DIM_KEY ")
					.append(" ) ")
					.append("join PGM_DIM pgm on ( ")
					.append(" ipgsf.PGM_DIM_KEY = pgm.PGM_DIM_KEY ")
					.append(" ) ")
					.append("join PROV_GRP_DIM pg on ( ")
					.append(" ipgsf.PROV_GRP_DIM_KEY = pg.PROV_GRP_DIM_KEY ")
					.append(" ) ")
					//Release 1.9 ephc intake id 3530 ad90348
					//commented | EPHC Intake Id - 3530 | duplicate measures appearing during export
					/*	.append("join prov_grp_pgm_lob_fact pgplf on ( ")
						.append(" ipgsf.prov_grp_dim_key = pgplf.prov_grp_dim_key and ") 
						.append(" ipgsf.pgm_dim_key = pgplf.pgm_dim_key ")
						.append(" ) ")
						.append("join lob_dim ld on ( ")
						.append(" ld.lob_dim_key = PGPLF.LOB_DIM_KEY ")
						.append(" ) ")*/
					.append(" WHERE ")
					.append(" pg.PROV_GRP_ID = ? AND  ")
					.append("  pgm.PGM_ID = ? AND  ")
					.append(" ipgsf.MSRMNT_PRD_STRT_DT = ? AND  ")
					.append(" smhd.CMPST_DEFN_ID = ? AND  ")
					.append(" spmhf.pgm_lob_type_cd = ? ");

				if (null != Constants.getQuarterName(request
					.getMeasurementInterval())) {
					if ("1".equalsIgnoreCase(request
						.getMeasurementInterval())) {
						sql.append(" AND ipgsf.BSLN_SCRCRD_IND = ? ");
					}
					else {
						sql.append("  AND ipgsf.QTR_ID = ? ");
					}
				}
				else {
					sql.append(" AND ipgsf.MNTH_ID = (SELECT MAX(IPGSF.MNTH_ID) FROM IMPRV_PROV_GRP_SMRY_FACT IPGSF INNER JOIN "
						+ " (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT FROM SCRCRD_PGM_MSR_HRCHY_FACT WHERE  "
						+ " PGM_DIM_KEY=(SELECT PGM_DIM_KEY FROM PGM_DIM WHERE PGM_ID= ? ) "
						+ "  and  MSRMNT_PRD_STRT_DT = ? "
						+ "GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM "
						+ " ON IPGSF.PGM_DIM_KEY=SC_PGM.PGM_DIM_KEY AND IPGSF.MSRMNT_PRD_STRT_DT=SC_PGM.MSRMNT_PRD_STRT_DT) ");
				}

				sql.append(" Order By ipgsf.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT DESC , ipgsf.MSR_DNMNTR_NBR DESC ");
				sql = StringUtil.appendWithUr(sql);

				if (cn != null) {

					ScorecardSubcompositeBean subcompositeBean;

					prepareStatement(logger, sql.toString());
					ps.setString(1, request.getProvGrpIds());
					ps.setString(2, request.getProgramId());
					ps.setString(3, request.getMeasurementPeriodStartDt());
					ps.setString(4, request.getCompositeId());
					ps.setString(5, request.getProgramLobTypeCd().toUpperCase());

					if (null != Constants.getQuarterName(request
						.getMeasurementInterval())) {
						if ("1".equalsIgnoreCase(request
							.getMeasurementInterval())) {
							ps.setString(6, "Y");
						}
						else {
							ps.setString(6, Constants.getQuarterName(request
								.getMeasurementInterval()));
						}
					}
					else {
						ps.setString(6, request.getProgramId());
						ps.setString(7, request.getMeasurementPeriodStartDt());
					}

					executeQuery(logger, sql.toString());

					if (null != rs) {

						while (rs.next()) {

							subcompositeBean = new ScorecardSubcompositeBean();
							subcompositeBean.setCompositeId(getString(rs, "CMPST_DEFN_ID"));
							subcompositeBean.setMsrDimKey(rs.getString("MSR_DIM_KEY"));
							subcompositeBean.setMsrId(getString(rs, "MSR_ID"));
							subcompositeBean.setScoreLevel(getString(rs, "SCORG_LVL_CD"));
							subcompositeBean.setMsrNm(getString(rs, "MSR_DSPLY_NM"));
							subcompositeBean.setTrgtRtPct(getString(rs, "TRGT_RT_PCT"));
							subcompositeBean.setCurntCmplncRtPct(getString(rs, "CURNT_CMPLNC_RT_PCT"));
							subcompositeBean.setRdstrbtdErncntrpct(getString(rs, "RDSTRBTD_ERNCNTR_PCT"));
							subcompositeBean.setRdstrbtdSsavUpsdDstrbnPct(getString(rs, "RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT"));
							subcompositeBean.setMsrDnmntrNbr(getString(rs, "MSR_DNMNTR_NBR"));
							subcompositeBean.setAnalysisAsOfDt(DateUtil.formatDateToMMDDYYYY("yyyy-MM-dd", "MM/dd/yyyy", rs.getDate("ANLYSS_AS_OF_DT").toString()));
							subcompositeBean.setSubcmpstDefnId(rs.getString("SUB_CMPST_DEFN_ID"));

							result.add(subcompositeBean);
						}
					}
				}
				else {
					throw new Exception("Unable to establish the connection");
				}
			}
			else {

				if (request.getViewBy().equalsIgnoreCase("scoringLevels")) {

					if (cn != null) {

						StringBuilder sql = new StringBuilder();
						sql.append("SELECT DISTINCT ")
							.append("case ")
							.append("when ef.BSLN_SCRCRD_IND='Y' then 'Q0' else ef.qtr_id end as QTR_ID, ")
							.append(" ef.SCORG_LVL_CD, smhd.SUB_CMPST_DEFN_ID ")
							.append("FROM ")
							.append("ERNCNTR_FACT ef ")
							.append("join PGM_DIM pg on ( ")
							.append("ef.PGM_DIM_KEY = pg.PGM_DIM_KEY ")
							.append(" ) ")
							.append("join PROV_GRP_DIM pgd on ( ")
							.append("ef.PROV_GRP_DIM_KEY = pgd.PROV_GRP_DIM_KEY ")
							.append(" ) ")
							.append("join SCRCRD_PGM_MSR_HRCHY_FACT spmhf on ( ")
							.append("ef.trnch_defn_dim_key = spmhf.trnch_defn_dim_key and ")
							.append("pg.PGM_DIM_KEY = spmhf.PGM_DIM_KEY ")
							.append(" ) ")
							.append("join SCRCRD_MSR_HRCHY_DIM smhd on ( ")
							.append("spmhf.SCRCRD_MSR_HRCHY_DIM_KEY = smhd.SCRCRD_MSR_HRCHY_DIM_KEY ")
							.append(" ) ")
							.append("WHERE ")
							.append("pgd.PROV_GRP_ID = ? AND ")
							.append("pg.PGM_ID = ? AND ")
							.append("ef.MSRMNT_PRD_STRT_DT = ?  AND ")
							.append("smhd.CMPST_DEFN_ID = ? ");

						if (null != Constants.getQuarterName(request
							.getMeasurementInterval())) {
							if ("1".equalsIgnoreCase(request
								.getMeasurementInterval())) {
								sql.append(" AND ef.BSLN_SCRCRD_IND = ? ");
							}
							else {
								sql.append(" AND ef.QTR_ID = ? ");
							}
						}
						else {
							sql.append(" AND EF.MNTH_ID = (SELECT MAX(EF.MNTH_ID) FROM ERNCNTR_FACT EF INNER JOIN "
								+ " (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT FROM SCRCRD_PGM_MSR_HRCHY_FACT  WHERE "
								+ " PGM_DIM_KEY=(SELECT PGM_DIM_KEY FROM PGM_DIM WHERE PGM_ID= ? ) "
								+ "  and  MSRMNT_PRD_STRT_DT = ? "
								+ "GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM "
								+ " ON EF.PGM_DIM_KEY=SC_PGM.PGM_DIM_KEY AND EF.MSRMNT_PRD_STRT_DT=SC_PGM.MSRMNT_PRD_STRT_DT) ");
						}

						sql.append(" GROUP BY ef.QTR_ID, ef.BSLN_SCRCRD_IND, EF.SCORG_LVL_CD, SUB_CMPST_DEFN_ID ");
						sql = StringUtil.appendWithUr(sql);

						prepareStatement(logger, sql.toString());
						ps.setString(1, request.getProvGrpIds());
						ps.setString(2, request.getProgramId());
						ps.setString(3, request.getMeasurementPeriodStartDt());
						ps.setString(4, request.getCompositeId());

						if (null != Constants.getQuarterName(request
							.getMeasurementInterval())) {
							if ("1".equalsIgnoreCase(request
								.getMeasurementInterval())) {
								ps.setString(5, "Y");
							}
							else {
								ps.setString(5, Constants
									.getQuarterName(request
										.getMeasurementInterval()));
							}
						}
						else {
							ps.setString(5, request.getProgramId());
							ps.setString(6, request.getMeasurementPeriodStartDt());
						}

						executeQuery(logger, sql.toString());

						while (rs.next()) {

							scrngLvlCd = getString(rs, "SCORG_LVL_CD");
							subCmpstDefnId = getString(rs, "SUB_CMPST_DEFN_ID");
							qrtrId = getString(rs, "QTR_ID");

							if (scrngLvlCd.equalsIgnoreCase("G")) {
								subCmpstDefnIdWithGroup.add(subCmpstDefnId);
							}
						}

						scrngLvlMap.put("G", subCmpstDefnIdWithGroup);
					}
				}

				StringBuilder sql = new StringBuilder();

				if (request.getViewBy().equalsIgnoreCase("organization")) {

					sql = new StringBuilder();
					sql.append(" SELECT DISTINCT cosf1.SUB_CMPST_RT_PCT , "
						+ "cosf1.SUB_CMPST_DNMNTR_NBR ,  cosf1.MSR_DNMNTR_NBR , "
						+ "cosf1.RT_PCT , cosf1.RISK_ADJSTMNT_FCTR , ef.RDSTRBTD_ERNCNTR_PCT ,  ef.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT , "
						+ "'O' as SCORG_LVL_CD , td.TRNCH_CTGRY_CD , td.TRNCH_CUT_LOW_PCT ,td.TRNCH_CUT_HIGH_PCT , "
						+ "td.TRNCH_SVNGS_PTNTL_PCT , smhd.SUB_CMPST_NM , smhd.CMPST_DEFN_ID , "
						+ "smhd.SUB_CMPST_DEFN_ID , msr.MSR_DSPLY_NM, msr.MSR_DIM_KEY ,msr.MSR_ID, cosf1.RISK_ADJSTMNT_FCTR ,"
						+ " td.trnch_defn_dtl_dim_key, td.trnch_cut_ordr_cd , TD.TRNCH_CUT_TYPE_CD , ef.ANLYSS_AS_OF_DT , spgmhf.TOP_X_NBR"
						//							ad91912 - CR to display medicare improvement measures even if the org dnmntr is null/0
						+ ", ef.TRNCH_LVL_DNMNTR_NBR as GRP_DNMNTR_NBR "

						+ " FROM "
						+ " ERNCNTR_FACT ef "
						+ " inner join SCRCRD_PGM_MSR_HRCHY_FACT spgmhf "
						+ " on ef.PGM_DIM_KEY = spgmhf.PGM_DIM_KEY "
						+ " AND ef.MSRMNT_PRD_STRT_DT = spgmhf.MSRMNT_PRD_STRT_DT"
						+ " AND ef.trnch_defn_dim_key = spgmhf.trnch_defn_dim_key ");

					sql.append(" AND ef.MNTH_ID = spgmhf.MNTH_ID ");

					sql.append(" inner join SCRCRD_MSR_HRCHY_DIM smhd "
						+ " on spgmhf.SCRCRD_MSR_HRCHY_DIM_KEY = smhd.SCRCRD_MSR_HRCHY_DIM_KEY "
						+ " inner join MSR_DIM msr on smhd.MSR_DIM_KEY = msr.MSR_DIM_KEY "
						+ " and SPGMHF.msrmnt_prd_strt_dt >= msr.MSR_EFCTV_DT and SPGMHF.msrmnt_prd_end_dt <= msr.MSR_TRMNTN_DT "
						+ " inner join PROV_GRP_DIM pg on ef.PROV_GRP_DIM_KEY = pg.PROV_GRP_DIM_KEY  "
						+ " inner join PGM_DIM pgm on ef.PGM_DIM_KEY = pgm.PGM_DIM_KEY "
						+ " inner join TRNCH_DEFN_DTL_DIM td on ef.TRNCH_DEFN_DIM_KEY = td.TRNCH_DEFN_DIM_KEY"
						//Release 1.9 ephc intake id 3530 ad90348
						//commented | EPHC Intake Id - 3530 | duplicate measures appearing during export
						/*+ " inner join prov_grp_pgm_lob_fact pgplf on ef.prov_grp_dim_key = pgplf.prov_grp_dim_key and ef.pgm_dim_key= pgplf.pgm_dim_key "
						+ " inner join Lob_dim ld on ld.lob_dim_key = pgplf.lob_dim_key "
						*/
						+ " and (CASE WHEN EF.MSRMNT_PRD_END_DT < CURRENT_DATE THEN EF.MSRMNT_PRD_END_DT "
						+ " WHEN CURRENT_DATE <= EF.MSRMNT_PRD_END_DT AND CURRENT_DATE >=EF.MSRMNT_PRD_STRT_DT THEN CURRENT_DATE "
						+ " WHEN EF.MSRMNT_PRD_STRT_DT > CURRENT_DATE THEN EF.MSRMNT_PRD_STRT_DT END) >= TD.TRNCH_DEFN_DTL_DIM_EFCTV_DT "
						+ " AND "
						+ " (CASE WHEN EF.MSRMNT_PRD_END_DT < CURRENT_DATE THEN EF.MSRMNT_PRD_END_DT "
						+ " WHEN CURRENT_DATE <= EF.MSRMNT_PRD_END_DT AND CURRENT_DATE >=EF.MSRMNT_PRD_STRT_DT THEN CURRENT_DATE "
						+ " WHEN EF.MSRMNT_PRD_STRT_DT > CURRENT_DATE THEN EF.MSRMNT_PRD_STRT_DT END) <=TD.TRNCH_DEFN_DTL_DIM_TRMNTN_DT "


						+ " left outer join "
						+ " (select cosf.SUB_CMPST_DNMNTR_NBR , cosf.SUB_CMPST_RT_PCT, cosf.MSR_DNMNTR_NBR ,cosf.RT_PCT ,"
						+ " cosf.RISK_ADJSTMNT_FCTR , cosf.scrcrd_msr_hrchy_dim_key, COSF.MSRMNT_PRD_STRT_DT, cosf.MSR_DIM_KEY,cosf.ANLYSS_AS_OF_DT"
						+ " from CMPLNC_ORG_SMRY_FACT cosf"
						+ " inner join PROV_ORG_DIM po on cosf.PROV_ORG_DIM_KEY = po.PROV_ORG_DIM_KEY AND po.PROV_ORG_DIM_KEY = ?" // Result of NF31: PROV_ORG_TAX_ID changed to PROV_ORG_DIM_KEY
						+ " inner join PROV_GRP_DIM pg on cosf.PROV_GRP_DIM_KEY = pg.PROV_GRP_DIM_KEY  AND pg.PROV_GRP_ID = ?"
						+ " inner join PGM_DIM pgm on cosf.PGM_DIM_key = pgm.PGM_DIM_key AND pgm.PGM_ID= ?"
						+ " ) cosf1 "
						+ " on spgmhf.SCRCRD_MSR_HRCHY_DIM_KEY = cosf1.SCRCRD_MSR_HRCHY_DIM_KEY "
						+ " AND cosf1.MSRMNT_PRD_STRT_DT = ef.MSRMNT_PRD_STRT_DT  "
						+ " AND msr.MSR_DIM_KEY = cosf1.MSR_DIM_KEY "
						+ " AND ef.ANLYSS_AS_OF_DT = cosf1.ANLYSS_AS_OF_DT "
						+ " WHERE "
						+ " pg.PROV_GRP_ID = ? "
						+ " AND pgm.PGM_ID= ? "
						+ " AND ef.MSRMNT_PRD_STRT_DT = ?  "
						+ " AND smhd.CMPST_DEFN_ID = ? "
						+ " AND spgmhf.pgm_lob_type_cd = ? ");

					if (null != Constants.getQuarterName(request
						.getMeasurementInterval())) {
						if ("1".equalsIgnoreCase(request
							.getMeasurementInterval())) {
							sql.append(" AND ef.BSLN_SCRCRD_IND = ? ");
						}
						else {
							sql.append(" AND ef.QTR_ID = ? ");
						}
					}
					else {
						sql.append(" AND EF.MNTH_ID = (SELECT MAX(EF.MNTH_ID) FROM ERNCNTR_FACT EF INNER JOIN "
							+ " (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT FROM SCRCRD_PGM_MSR_HRCHY_FACT WHERE  "
							+ " PGM_DIM_KEY=(SELECT PGM_DIM_KEY FROM PGM_DIM WHERE PGM_ID= ? ) "
							+ "  and  MSRMNT_PRD_STRT_DT = ? "
							+ "GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM "
							+ " ON EF.PGM_DIM_KEY=SC_PGM.PGM_DIM_KEY AND EF.MSRMNT_PRD_STRT_DT=SC_PGM.MSRMNT_PRD_STRT_DT) ");
					}

					if (request.getMeasurementInterval().equalsIgnoreCase("12")) {
						sql.append("  AND TD.TRNCH_CUT_TYPE_CD =   CASE WHEN EF.QTR_ID IN ('Q1','Q2','Q3') THEN 'NONADJD' ELSE TD.TRNCH_CUT_TYPE_CD END ");
					}
					else if (request.getMeasurementInterval().equalsIgnoreCase("0")) {
						if (null != qrtrId && qrtrId.equalsIgnoreCase("Q4")) {
							sql.append("  AND TD.TRNCH_CUT_TYPE_CD =   CASE WHEN EF.QTR_ID IN ('Q1','Q2','Q3') THEN 'NONADJD' ELSE TD.TRNCH_CUT_TYPE_CD END ");
						}
						else {
							sql.append("AND TD.TRNCH_CUT_TYPE_CD = 'NONADJD' ");
						}
					}
					else {
						sql.append("AND TD.TRNCH_CUT_TYPE_CD = 'NONADJD' ");
					}

					sql.append(" Order By ef.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT DESC ,spgmhf.TOP_X_NBR ,cosf1.MSR_DNMNTR_NBR DESC, TD.TRNCH_CUT_TYPE_CD ,cosf1.RT_PCT ASC,msr.MSR_DIM_KEY , td.TRNCH_CTGRY_CD ");
					sql = StringUtil.appendWithUr(sql);

					if (cn != null) {

						prepareStatement(logger, sql.toString());
						ps.setString(1, request.getOrganizationId());
						ps.setString(2, request.getProvGrpIds());
						ps.setString(3, request.getProgramId());
						ps.setString(4, request.getProvGrpIds());
						ps.setString(5, request.getProgramId());
						ps.setString(6, request.getMeasurementPeriodStartDt());
						ps.setString(7, request.getCompositeId());
						ps.setString(8, request.getProgramLobTypeCd().toUpperCase());

						if (null != Constants.getQuarterName(request
							.getMeasurementInterval())) {
							if ("1".equalsIgnoreCase(request
								.getMeasurementInterval())) {
								ps.setString(9, "Y");
							}
							else {
								ps.setString(9, Constants
									.getQuarterName(request
										.getMeasurementInterval()));
							}
						}
						else {
							ps.setString(9, request.getProgramId());
							ps.setString(10, request.getMeasurementPeriodStartDt());
						}

						executeQuery(logger, sql.toString());

						List<ScorecardSubcompositeBean> tempList = prepareSubCompositeBeanList(rs);
						result.addAll(tempList);
					}
					else {
						throw new Exception("Unable to establish the connection");
					}
				}

				if (request.getViewBy().equalsIgnoreCase("group") || null != scrngLvlMap && scrngLvlMap.keySet().size() > 0 && scrngLvlMap.keySet().contains("G")
					&& scrngLvlMap.get("G").size() > 0) {

					sql = new StringBuilder();
					sql.append(" SELECT DISTINCT cgsf1.SUB_CMPST_RT_PCT , cgsf1.SUB_CMPST_DNMNTR_NBR ,"
						+ " cgsf1.MSR_DNMNTR_NBR , cgsf1.MSR_NMRTR_NBR, cgsf1.RT_PCT , cgsf1.RISK_ADJSTMNT_FCTR , "
						+ " ef.RDSTRBTD_ERNCNTR_PCT ,  ef.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT ,"
						+ " 'G' as SCORG_LVL_CD , td.TRNCH_CTGRY_CD , td.TRNCH_CUT_LOW_PCT , td.TRNCH_CUT_HIGH_PCT ,td.TRNCH_SVNGS_PTNTL_PCT ,"
						+ " smhd.SUB_CMPST_NM , msr.MSR_DIM_KEY ,msr.MSR_ID, smhd.CMPST_DEFN_ID , smhd.SUB_CMPST_DEFN_ID,"
						+ " ef.ANLYSS_AS_OF_DT , td.trnch_defn_dtl_dim_key, td.trnch_cut_ordr_cd , TD.TRNCH_CUT_TYPE_CD , msr.MSR_DSPLY_NM , spgmhf.TOP_X_NBR "
						+ ", ef.TRNCH_LVL_DNMNTR_NBR as GRP_DNMNTR_NBR "
						+ " FROM ERNCNTR_FACT ef "
						+ " inner join SCRCRD_PGM_MSR_HRCHY_FACT spgmhf on ef.MSRMNT_PRD_STRT_DT = spgmhf.MSRMNT_PRD_STRT_DT "
						+ "AND ef.TRNCH_DEFN_DIM_KEY = spgmhf.TRNCH_DEFN_DIM_KEY "
						+ "AND ef.PGM_DIM_KEY = spgmhf.PGM_DIM_KEY ");

					sql.append(" AND ef.MNTH_ID = spgmhf.MNTH_ID ");

					sql.append(" inner join SCRCRD_MSR_HRCHY_DIM smhd on spgmhf.SCRCRD_MSR_HRCHY_DIM_KEY = smhd.SCRCRD_MSR_HRCHY_DIM_KEY "
						+ " inner join MSR_DIM msr on  smhd.MSR_DIM_KEY = msr.MSR_DIM_KEY "
						+ " and SPGMHF.msrmnt_prd_strt_dt >= msr.MSR_EFCTV_DT and SPGMHF.msrmnt_prd_end_dt <= msr.MSR_TRMNTN_DT "
						+ " inner join PGM_DIM pgm on ef.PGM_DIM_KEY = pgm.PGM_DIM_KEY "
						+ " inner join PROV_GRP_DIM pg on ef.PROV_GRP_DIM_KEY = pg.PROV_GRP_DIM_KEY "
						+ " inner join TRNCH_DEFN_DTL_DIM td on ef.TRNCH_DEFN_DIM_KEY = td.TRNCH_DEFN_DIM_KEY "
						//Release 1.9 ephc intake id 3530 ad90348
						//commented | EPHC Intake Id - 3530 | duplicate measures appearing during export
						/*+ " inner join prov_grp_pgm_lob_fact pgplf on ef.prov_grp_dim_key = pgplf.prov_grp_dim_key and ef.pgm_dim_key= pgplf.pgm_dim_key "
						+ " inner join Lob_dim ld on ld.lob_dim_key = pgplf.lob_dim_key "
						*/+ " and (CASE WHEN EF.MSRMNT_PRD_END_DT < CURRENT_DATE THEN EF.MSRMNT_PRD_END_DT "
						+ " WHEN CURRENT_DATE <= EF.MSRMNT_PRD_END_DT AND CURRENT_DATE >=EF.MSRMNT_PRD_STRT_DT THEN CURRENT_DATE "
						+ " WHEN EF.MSRMNT_PRD_STRT_DT > CURRENT_DATE THEN EF.MSRMNT_PRD_STRT_DT END) >= TD.TRNCH_DEFN_DTL_DIM_EFCTV_DT "
						+ " AND "
						+ " (CASE WHEN EF.MSRMNT_PRD_END_DT < CURRENT_DATE THEN EF.MSRMNT_PRD_END_DT "
						+ " WHEN CURRENT_DATE <= EF.MSRMNT_PRD_END_DT AND CURRENT_DATE >=EF.MSRMNT_PRD_STRT_DT THEN CURRENT_DATE "
						+ " WHEN EF.MSRMNT_PRD_STRT_DT > CURRENT_DATE THEN EF.MSRMNT_PRD_STRT_DT END) <=TD.TRNCH_DEFN_DTL_DIM_TRMNTN_DT "
						+ " left outer join "
						+ " (select cgsf.SUB_CMPST_RT_PCT , cgsf.SUB_CMPST_DNMNTR_NBR , cgsf.MSR_DNMNTR_NBR , cgsf.MSR_NMRTR_NBR , "
						+ " cgsf.RT_PCT , cgsf.RISK_ADJSTMNT_FCTR ,"
						+ " cgsf.ANLYSS_AS_OF_DT, cgsf.PROV_GRP_DIM_KEY, cgsf.PGM_DIM_KEY, "
						+ " cgsf.MSRMNT_PRD_STRT_DT, cgsf.MSR_DIM_KEY, cgsf.SCRCRD_MSR_HRCHY_DIM_KEY"
						+ " from CMPLNC_PROV_GRP_SMRY_FACT cgsf "
						+ " inner join PROV_GRP_DIM PG ON  cgsf.PROV_GRP_DIM_KEY = pg.PROV_GRP_DIM_KEY AND PG.PROV_GRP_ID=? "
						+ " INNER JOIN PGM_DIM PGM ON CGSF.PGM_DIM_KEY = PGM.PGM_DIM_KEY AND pgm.PGM_ID=? "
						+ " )cgsf1 ON "
						+ " ef.ANLYSS_AS_OF_DT = cgsf1.ANLYSS_AS_OF_DT AND "
						+ " cgsf1.PROV_GRP_DIM_KEY = ef.PROV_GRP_DIM_KEY AND "
						+ " cgsf1.PGM_DIM_KEY = ef.PGM_DIM_KEY AND  "
						+ " cgsf1.MSRMNT_PRD_STRT_DT = ef.MSRMNT_PRD_STRT_DT AND "
						+ " smhd.SCRCRD_MSR_HRCHY_DIM_KEY = cgsf1.SCRCRD_MSR_HRCHY_DIM_KEY AND "
						+ " smhd.MSR_DIM_KEY = cgsf1.MSR_DIM_KEY "
						+ "  where "
						+ " pg.PROV_GRP_ID = ? AND "
						+ "  pgm.PGM_ID= ? AND "
						+ "  ef.MSRMNT_PRD_STRT_DT =  ? AND "
						+ "  smhd.CMPST_DEFN_ID = ? "
						+ " AND spgmhf.pgm_lob_type_cd = ? ");

					if (null != Constants.getQuarterName(request
						.getMeasurementInterval())) {
						if ("1".equalsIgnoreCase(request
							.getMeasurementInterval())) {
							sql.append(" AND ef.BSLN_SCRCRD_IND = ? ");
						}
						else {
							sql.append(" AND ef.QTR_ID = ? ");
						}
					}
					else {
						sql.append(" AND EF.MNTH_ID = (SELECT MAX(EF.MNTH_ID) FROM ERNCNTR_FACT EF INNER JOIN "
							+ " (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT FROM SCRCRD_PGM_MSR_HRCHY_FACT WHERE  "
							+ " PGM_DIM_KEY=(SELECT PGM_DIM_KEY FROM PGM_DIM WHERE PGM_ID= ? ) "
							+ "  and  MSRMNT_PRD_STRT_DT = ? "
							+ " GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM "
							+ " ON EF.PGM_DIM_KEY=SC_PGM.PGM_DIM_KEY AND EF.MSRMNT_PRD_STRT_DT=SC_PGM.MSRMNT_PRD_STRT_DT) ");
					}

					if (request.getMeasurementInterval().equalsIgnoreCase("12")) {
						sql.append("  AND TD.TRNCH_CUT_TYPE_CD =   CASE WHEN EF.QTR_ID IN ('Q1','Q2','Q3') THEN 'NONADJD' ELSE TD.TRNCH_CUT_TYPE_CD END ");
					}
					else if (request.getMeasurementInterval().equalsIgnoreCase("0")) {
						if (null != qrtrId && qrtrId.equalsIgnoreCase("Q4")) {
							sql.append("  AND TD.TRNCH_CUT_TYPE_CD =   CASE WHEN EF.QTR_ID IN ('Q1','Q2','Q3') THEN 'NONADJD' ELSE TD.TRNCH_CUT_TYPE_CD END ");
						}
						else {
							sql.append("AND TD.TRNCH_CUT_TYPE_CD = 'NONADJD' ");
						}
					}
					else {
						sql.append("AND TD.TRNCH_CUT_TYPE_CD = 'NONADJD' ");
					}

					Set<String> subCmpstIdList = null;
					if (null != scrngLvlMap && scrngLvlMap.keySet().size() > 0 && scrngLvlMap.containsKey("G")) {

						subCmpstIdList = scrngLvlMap.get("G");

						if (subCmpstIdList.size() > 0) {

							sql.append(" AND smhd.SUB_CMPST_DEFN_ID in ( ");
							Integer counter = 0;

							for (String s : subCmpstIdList) {
								if (counter == 0) {
									sql.append(" ? ");
								}
								else {
									sql.append(", ? ");
								}
								counter++;
							}
							sql.append(')');
						}
						else {
							sql.append(" AND smhd.SUB_CMPST_DEFN_ID in ('null') ");
						}
					}

					sql.append(" Order By ef.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT DESC , spgmhf.TOP_X_NBR , cgsf1.MSR_DNMNTR_NBR DESC , cgsf1.MSR_NMRTR_NBR DESC, TD.TRNCH_CUT_TYPE_CD , cgsf1.RT_PCT ASC, msr.MSR_DIM_KEY , td.TRNCH_CTGRY_CD ");
					sql = StringUtil.appendWithUr(sql);

					if (cn != null) {

						prepareStatement(logger, sql.toString());
						ps.setString(1, request.getProvGrpIds());
						ps.setString(2, request.getProgramId());
						ps.setString(3, request.getProvGrpIds());
						ps.setString(4, request.getProgramId());
						ps.setString(5, request.getMeasurementPeriodStartDt());
						ps.setString(6, request.getCompositeId());
						ps.setString(7, request.getProgramLobTypeCd().toUpperCase());

						int i = 8;

						if (null != Constants.getQuarterName(request
							.getMeasurementInterval())) {
							if ("1".equalsIgnoreCase(request
								.getMeasurementInterval())) {
								ps.setString(i++, "Y");
							}
							else {
								ps.setString(i++, Constants
									.getQuarterName(request
										.getMeasurementInterval()));
							}
						}
						else {
							ps.setString(i++, request.getProgramId());
							ps.setString(i++, request.getMeasurementPeriodStartDt());
						}

						if (null != scrngLvlMap && scrngLvlMap.keySet().size() > 0 && scrngLvlMap.containsKey("G") && null != subCmpstIdList && subCmpstIdList.size() > 0) {
							for (String s : subCmpstIdList) {
								ps.setString(i++, s);
							}
						}

						executeQuery(logger, sql.toString());

						List<ScorecardSubcompositeBean> tempList = prepareSubCompositeBeanList(rs);
						result.addAll(tempList);
					}
					else {
						throw new Exception("Unable to establish the connection");
					}
				}
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get Scorecard By Subcomposite details (" + request.getEntitlementId() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}

	private List<ScorecardSubcompositeBean> prepareSubCompositeBeanList(ResultSet rs) throws SQLException, Exception {

		List<ScorecardSubcompositeBean> subCompositeList = new ArrayList<ScorecardSubcompositeBean>();
		ScorecardSubcompositeBean subcompositeBean = null;

		while (rs.next()) {

			subcompositeBean = new ScorecardSubcompositeBean();
			subcompositeBean.setCompositeId(rs.getString("CMPST_DEFN_ID"));
			subcompositeBean.setMsrDsplyNm(rs.getString("MSR_DSPLY_NM"));
			subcompositeBean.setMsrDimKey(rs.getString("MSR_DIM_KEY"));
			subcompositeBean.setMsrId(rs.getString("MSR_ID"));
			subcompositeBean.setScoreLevel(rs.getString("SCORG_LVL_CD"));
			subcompositeBean.setSubcmpstDefnId(rs.getString("SUB_CMPST_DEFN_ID"));
			subcompositeBean.setSubCmpstNm(rs.getString("SUB_CMPST_NM"));
			subcompositeBean.setRdstrbtdErncntrpct(rs.getString("RDSTRBTD_ERNCNTR_PCT"));
			subcompositeBean.setRdstrbtdSsavUpsdDstrbnPct(rs.getString("RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT"));
			subcompositeBean.setSubCmpstDnmntrNbr(rs.getString("SUB_CMPST_DNMNTR_NBR"));
			subcompositeBean.setSubCmpstRtPct(rs.getString("SUB_CMPST_RT_PCT"));
			subcompositeBean.setTrnchCtgryCd(rs.getString("TRNCH_CTGRY_CD"));
			subcompositeBean.setTrnchCutLowPct(rs.getString("TRNCH_CUT_LOW_PCT"));
			subcompositeBean.setTrnchCutHighPct(rs.getString("TRNCH_CUT_HIGH_PCT"));
			subcompositeBean.setTrnchSvngsPtntlPct(rs.getString("TRNCH_SVNGS_PTNTL_PCT"));
			subcompositeBean.setMsrDnmntrNbr(rs.getString("MSR_DNMNTR_NBR"));
			subcompositeBean.setRtPct(rs.getString("RT_PCT"));
			subcompositeBean.setAnalysisAsOfDt(DateUtil.formatDateToMMDDYYYY("yyyy-MM-dd", "MM/dd/yyyy", rs.getDate("ANLYSS_AS_OF_DT").toString()));
			subcompositeBean.setRiskAdjFactor(rs.getString("RISK_ADJSTMNT_FCTR"));
			subcompositeBean.setTrnchOrderCd(rs.getString("TRNCH_CUT_ORDR_CD"));
			subcompositeBean.setGrpDnmntrNbr(rs.getString("GRP_DNMNTR_NBR"));
			subCompositeList.add(subcompositeBean);
		}

		return subCompositeList;
	}

	@Override
	public boolean read(Dto o) throws Exception {

		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {


	}

	@Override
	public void update(Dto o) throws Exception {


	}

	@Override
	public void delete(Dto o) throws Exception {


	}
}
