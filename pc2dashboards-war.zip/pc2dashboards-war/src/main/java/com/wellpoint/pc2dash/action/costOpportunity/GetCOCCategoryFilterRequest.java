package com.wellpoint.pc2dash.action.costOpportunity;

import com.wellpoint.pc2dash.data.dto.PopulationManagementRequest;

public class GetCOCCategoryFilterRequest extends PopulationManagementRequest {

}
