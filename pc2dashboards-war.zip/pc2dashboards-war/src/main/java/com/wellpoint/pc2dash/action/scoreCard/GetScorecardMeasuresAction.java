package com.wellpoint.pc2dash.action.scoreCard;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.scorecard.commercial.CommercialScorecardMeasuresServiceImpl;
import com.wellpoint.pc2dash.service.scorecard.commercial.EsnCommercialScorecardMeasuresServiceImpl;
import com.wellpoint.pc2dash.service.scorecard.commercial.FpccCommercialScorecardMeasuresServiceImpl;
import com.wellpoint.pc2dash.service.scorecard.medicaid.MedicaidScorecardMeasuresServiceImpl;
import com.wellpoint.pc2dash.service.scorecard.medicare.EsnMedicareScorecardMeasuresServiceImpl;
import com.wellpoint.pc2dash.service.scorecard.medicare.MedicareScorecardMeasuresServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;


public class GetScorecardMeasuresAction extends Action {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetScorecardMeasuresAction.class);
	ActionResponse response = new GetScorecardMeasuresResponse();

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetScorecardMeasuresRequest request = (GetScorecardMeasuresRequest) actionRequest;
		List<String> filteredProvGrpList = new ArrayList<String>();
		String provGrpCSVWithGrpIndY = "";
		String provGrpCSVWithGrpIndN = "";
		Collection<Object> vals = new ArrayList<Object>();
		MetaData metadata = null;
		ErrorProperties err = ErrorProperties.getInstance();

		try {
			//			request = getDataMap(request);
			// preserve dataMap logic
			removeLobPgmPrefixes(request);

			//Kill switch check on Provider groups
			if (null != request) {
				filteredProvGrpList = filterProvGrpsByKillSwitch(request);
			}

			//Clinical access check on provider groups
			if (null != request && null != filteredProvGrpList && filteredProvGrpList.size() > 0) {
				filteredProvGrpList = filterProvGrpsByClincalFinancialInd(request, filteredProvGrpList);
			}

			//Group Ind Y list
			if (null != request && null != filteredProvGrpList && filteredProvGrpList.size() > 0) {
				provGrpCSVWithGrpIndY = prepareProvGrpCSVWithGrpInd(request, filteredProvGrpList, Constants.GRP_IND_Y);
				provGrpCSVWithGrpIndN = prepareProvGrpCSVWithGrpInd(request, filteredProvGrpList, Constants.GRP_IND_N);
			}

			//Group Ind Y list
			if (null != request && null != provGrpCSVWithGrpIndY && !provGrpCSVWithGrpIndY.isEmpty()) {
				request.setProvGrpIds(provGrpCSVWithGrpIndY);
				request.setGrpInd(Constants.GRP_IND_Y);
				vals = getScorecardMeasures(request);
			}

			//Group Ind N list
			if (null != request && null != provGrpCSVWithGrpIndN && !provGrpCSVWithGrpIndN.isEmpty()) {
				request.setProvGrpIds(provGrpCSVWithGrpIndN);
				request.setGrpInd(Constants.GRP_IND_N);
				Collection<Object> values = getScorecardMeasures(request);
				if (null != values) {
					vals.addAll(values);
				}
			}
			//			PCMSP-241,243
			metadata = getMetaDataInfo(request);
			response.setMetaData(metadata);
			if (null == vals || (null != vals && vals.isEmpty())) {
				response.setMessage(err.getProperty("successNoData"));
				response.setData(vals);
				response.setTotal(0);
			}
			else {
				response.setMessage(err.getProperty("successful"));
				response.setData(vals);
				response.setTotal(vals.size());
			}

			response.setSuccess(true);

			return response;

		}
		catch (Exception pe) {

			logger.error("Unable to retrieve Scorecard composite  detail.", pe);

			response.setMessage("Unable to retrieve Scorecard composite  detail.");
			response.setSuccess(false);
			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}

	private MetaData getMetaDataInfo(GetScorecardMeasuresRequest request) {
		MetaData metadata = new MetaData();
		metadata.setRatioColumnType(StringUtil.getRatioAdherentType(request));
		metadata.setColumns(StringUtil.getMeasureColumns(request));
		return metadata;
	}

	//	private Map<String, String> getDataMap(GetScorecardMeasuresRequest request) throws Exception{
	//		//PCMSRequest request = new HashMap<String, String>();
	//		
	//		if(request != null){
	//			request.put("prgmId", request.getProgramId());
	//			/*
	//			 * Adding the programLobTypeCd parameter to the datamap
	//			 * The value is going to be the pgmLobTypCd
	//			 */
	//			request.put("programLobTypeCd", request.getProgramLobTypeCd());
	//			request.put("provGrpId", request.getProviderGroupId());
	//			request.setCompositeId(request.getCompositeId());
	//			request.put("msrmntStrtDt", request.getMeasurementPeriodStartDt());
	//			request.put("organizationId", request.getOrganizationId());
	//			request.put("analysisAsOfDt", request.getAnalysisAsOfDt());
	//			request.put("measurementInterval", request.getMeasurementInterval());
	//			if(request.getSubCompositeId() != null && !request.getSubCompositeId().equalsIgnoreCase("null") ){
	//			request.put("subCompositeId", request.getSubCompositeId());
	//			}
	//			request.put("lob", request.getLob());
	//			request.put("lobNm", request.getLobNm());
	//			request.put("lobDimKeys", JSONUtils.removeFirstOccurenceOfCharsFromJsonString(request.getLobDimKeys(), Constants.LOB_ID_PREFIX));
	//			
	//			//Added to include perf grid for Improvement composite for Medicaid
	//			request.setCompositeType(request.getCompositeType());
	//			request.put("medicalPanelId", request.getMedicalPanelId());
	//			
	//			 //GBD part 2
	//			//request.setCmpId(request.getCmpId());
	//			request.setProvGrpIds(request.getProviderGroupId());
	//			request.put(Constants.USER_ACS_INFO_JSON, request.getUserAcsInfoJson());
	//		}
	//		
	//		return request;
	//	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getScorecardMeasures(PerformanceManagementRequest request) throws Exception {

		Collection<?> details = null;
		String lobDesc = request.getLobNm();
		/** Release 1.9 <UT> <AD12140> */
		String lobName = StringUtil.lobSuppressedIndicator(lobDesc);
		String pgmLobTypeCd = request.getProgramLobTypeCd();

		/**
		 * Updating the logic based on the defect WLPRD02524865 and as per the suggestion from Vishal J. to drive scorecard based on
		 * PGM_LOB_TYPE_CD and not on lob
		 * Author - AD12140
		 * Commenting the below logic
		 */

		/*if(null != lobName && lobName.equalsIgnoreCase(Constants.COMMERCIAL)){
			if(null != pgmLobTypeCd)
				if(pgmLobTypeCd.contains(Constants.FPCC_PGM_TYPE)){ //FPCC
					FpccCommercialScorecardMeasuresServiceImpl dao = new FpccCommercialScorecardMeasuresServiceImpl();
					details = dao.getScorecardMeasures(request);
				}else{ //EPHC
					CommercialScorecardMeasuresServiceImpl dao = new CommercialScorecardMeasuresServiceImpl();
					details = dao.getScorecardMeasures(request);
				}
		}
		else if(null != lobName && lobName.equalsIgnoreCase(Constants.MEDICAID)){
			MedicaidScorecardMeasuresServiceImpl dao = new MedicaidScorecardMeasuresServiceImpl();
			if(null != request.getCompositeType() && "Improvement".equalsIgnoreCase(request.getCompositeType()))
				details = dao.getScorecardMedicaidImprovementMeasures(request);
			else
				details = dao.getScorecardMedicaidMeasures(request);
		}
		else if(null != lobName && lobName.equalsIgnoreCase(Constants.MEDICARE)){
			MedicareScorecardMeasuresServiceImpl dao = new MedicareScorecardMeasuresServiceImpl();
			details = dao.getScorecardMeasures(request);
		}*/

		if (!Constants.SUPPRESSED.equalsIgnoreCase(lobName)) {
			if (null != pgmLobTypeCd && pgmLobTypeCd.trim().toUpperCase().contains(Constants.ESN_COMMERCIAL.toUpperCase())) { // Changes for ESN Scorecard May 2018 Release
				EsnCommercialScorecardMeasuresServiceImpl dao = new EsnCommercialScorecardMeasuresServiceImpl();
				details = dao.getEsnScorecardMeasures(request);
			}
			else if (null != pgmLobTypeCd && pgmLobTypeCd.trim().toUpperCase().contains(Constants.ESN_MEDICARE.toUpperCase())) { // Changes for ESN Medicare Scorecard July 2018 Release
				EsnMedicareScorecardMeasuresServiceImpl dao = new EsnMedicareScorecardMeasuresServiceImpl();
				details = dao.getEsnMedicareScorecardMeasures(request);
			}
			else if (null != pgmLobTypeCd && pgmLobTypeCd.trim().toUpperCase().contains(Constants.COMMERCIAL.toUpperCase())) {
				if (pgmLobTypeCd.trim().toUpperCase().contains(Constants.FPCC_PGM_TYPE)) { //FPCC
					FpccCommercialScorecardMeasuresServiceImpl dao = new FpccCommercialScorecardMeasuresServiceImpl();
					details = dao.getScorecardMeasures(request);
				}
				else { //EPHC
					CommercialScorecardMeasuresServiceImpl dao = new CommercialScorecardMeasuresServiceImpl();
					details = dao.getScorecardMeasures(request);
				}
			}
			else if (null != pgmLobTypeCd && pgmLobTypeCd.trim().toUpperCase().contains(Constants.MEDICAID.toUpperCase())) {
				MedicaidScorecardMeasuresServiceImpl dao = new MedicaidScorecardMeasuresServiceImpl();
				if (null != request.getCompositeType() && Constants.MEDICAID_IMPROVEMENT.equalsIgnoreCase(request.getCompositeType()))
					details = dao.getScorecardMedicaidImprovementMeasures(request);
				else
					details = dao.getScorecardMedicaidMeasures(request);
			}
			else if (null != pgmLobTypeCd && pgmLobTypeCd.trim().toUpperCase().contains(Constants.MEDICARE.toUpperCase())) {
				MedicareScorecardMeasuresServiceImpl dao = new MedicareScorecardMeasuresServiceImpl();
				details = dao.getScorecardMeasures(request);
			}
		}

		return (Collection<Object>) details;
	}
}
