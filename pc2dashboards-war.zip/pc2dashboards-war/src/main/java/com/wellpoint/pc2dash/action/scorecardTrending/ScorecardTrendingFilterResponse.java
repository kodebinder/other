package com.wellpoint.pc2dash.action.scorecardTrending;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class ScorecardTrendingFilterResponse extends ActionResponse {

}
