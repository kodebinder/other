package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;
import com.wellpoint.pc2dash.dto.medicalCostBaseline.McbSmryDto;
import com.wellpoint.pc2dash.exception.PC2Exception;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;

public class MedicalCostBaselineSmryDAO extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(MedicalCostBaselineSmryDAO.class);

	@Override
	public boolean read(Dto o) throws Exception {
		
		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {
		

	}

	@Override
	public void update(Dto o) throws Exception {
		

	}

	@Override
	public void delete(Dto o) throws Exception {
		

	}

	public List<McbSmryDto> getMCBMetricData(PerformanceManagementRequest request) throws PC2Exception {
		List<McbSmryDto> resultList = new ArrayList<McbSmryDto>();
		try {
			StringBuilder query = new StringBuilder();

			query.append("SELECT ")
				.append("  MTRC_CD ")
				.append(", MTRC_NM ")
				.append(", PHRMCY_IND ")
				.append(", PSL_ID ")
				.append(", PG_PROD_NBR ")
				.append(", PROD_MDCL_NBR ")
				.append(", RSKCRDR_MTHD_CD ")
				.append(", DWNSD_RISK_IND ")
				.append(", PG_IND ")
				.append(", ap.APLCTN_PRPTY_VAL_TXT ")
				.append(" FROM ")
				.append(" MCB_SMRY_FACT mcbsf")
				.append(" join LOB_DIM lob on (mcbsf.LOB_DIM_KEY = lob.LOB_DIM_KEY)")
				.append(" left join APLCTN_PRPTY ap on (ap.APLCTN_PRPTY_NM = CONCAT(CONCAT('MCB',mcbsf.MTRC_CD),trim(mcbsf.RSKCRDR_MTHD_CD)) and ap.APLCTN_PRPTY_OWNR_NM = 'MCB_CONFIG') ")
				.append(" WHERE ")
				.append(" mcbsf.MSRMNT_PRD_STRT_DT = ? ")
				.append(" AND mcbsf.MSRMNT_PRD_END_DT = ? ")
				.append(" AND mcbsf.PROV_GRP_ID = ? ") // switched from PROV_GRP_DIM_KEY for suppression purposes
				.append(" AND mcbsf.PGM_ID = ? ")
				.append(" AND lob.LOB_DESC = ? ")
				.append(" AND mcbsf.MDPNL_ID = ? ")
				.append(" AND mcbsf.ACTV_IND = 'Y' ");
			

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			prepareStatement(logger, query.toString());
			
			int i = 0;
			ps.setString(++i, StringUtil.convertDate(request.getMeasurementPeriodStartDt()));
			ps.setString(++i, StringUtil.convertDate(request.getMeasurementPeriodEndDt()));
//			ps.setString(++i, request.getFundingPool());
			ps.setString(++i, request.getProvGrpIds());
			ps.setString(++i, request.getProgramId());
			ps.setString(++i, request.getLobNm());			
			ps.setString(++i, request.getMedicalPanelId());
			
			executeQuery(logger, query.toString());
			
			while(rs.next()){
				McbSmryDto mcbDto = new McbSmryDto();
				mcbDto.setMetricCd(rs.getString("MTRC_CD"));
				mcbDto.setMetricNm(rs.getString("MTRC_NM"));
				mcbDto.setPhrmcyInd(rs.getString("PHRMCY_IND"));
				mcbDto.setPslId(rs.getString("PSL_ID"));
				mcbDto.setPgProdNbr(rs.getBigDecimal("PG_PROD_NBR"));
				mcbDto.setProdMedNbr(rs.getBigDecimal("PROD_MDCL_NBR"));
				mcbDto.setRskcrdrMthdCd(rs.getString("RSKCRDR_MTHD_CD"));
				mcbDto.setDwnsdRiskInd(rs.getString("DWNSD_RISK_IND"));
				mcbDto.setPgInd(rs.getString("PG_IND"));
				mcbDto.setTotalMeasureToolTip(rs.getString("APLCTN_PRPTY_VAL_TXT"));
				resultList.add(mcbDto);
			}
		}
		catch (Exception e) {

			logger.error("Unable to get MCB data.", e);
		}
		finally {

			close();
		}
		return resultList;
	}

	
	/*public String getProgramName(GetMedicalCostBaselineRequest request) throws PC2Exception {

		String pgmNm = null;

		try {
			StringBuilder query = new StringBuilder();

			query.append("SELECT DISTINCT ")
			.append(" PGM_NM ")
			.append(" FROM ")
			.append(" PGM_DIM ")
			.append(" WHERE ")
			.append(" PGM_ID = ? ")
			.append(" WITH UR ");

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			prepareStatement(logger, query.toString());

			int i = 0;
			ps.setString(++i, request.getProgramId());

			executeQuery(logger, query.toString());

			while(rs.next()){
				if(null != rs.getString("PGM_NM")){
					pgmNm = (rs.getString("PGM_NM"));
				}
			}
		}
		catch (Exception e) {

			logger.error("Unable to get Program Name for Export Header", e);
		}
		finally {

			close();
		}
		return pgmNm;
	}*/
}
