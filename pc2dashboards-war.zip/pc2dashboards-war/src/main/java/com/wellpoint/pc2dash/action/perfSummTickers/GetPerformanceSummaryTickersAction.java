package com.wellpoint.pc2dash.action.perfSummTickers;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.performance.summary.SummaryConstructorClass;
import com.wellpoint.pc2dash.dto.performance.summary.SummaryObject;
import com.wellpoint.pc2dash.dto.performance.summary.TickersBean;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.service.summary.PerformanceSummaryTickersServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;

public class GetPerformanceSummaryTickersAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		ActionResponse response = new GetPerformanceSummaryTickersResponse();
		//PCMSRequest request = new HashMap<String, String>();
		//PCMSP-243
		SummaryObject summaryObject;
		ArrayList<String> lobDescs = new ArrayList<String>();
		List<SummaryConstructorClass> resultList = null;
		PerformanceSummaryTickersServiceImpl service = new PerformanceSummaryTickersServiceImpl();
		GetPerformanceSummaryTickersRequest request = (GetPerformanceSummaryTickersRequest) actionRequest;
		List<String> filteredProvGrpList = new ArrayList<String>();
		String provGrpCSVWithGrpIndY = "";
		String provGrpCSVWithGrpIndN = "";
		ArrayList<TickersBean> finalTickersList = new ArrayList<TickersBean>();
		ErrorProperties err = ErrorProperties.getInstance();

		try {
			//			request = getDataMap(request);

			// Kill switch check on Provider groups
			if (StringUtils.isNotBlank(request.getCmpId())) {
				filteredProvGrpList = filterProvGrpsByKillSwitch(request);
			}

			// Clinical access check on provider groups
			if (null != filteredProvGrpList && filteredProvGrpList.size() > 0) {
				filteredProvGrpList = filterProvGrpsByFinancialInd(request, filteredProvGrpList);
			}

			// Group Ind Y list
			if (null != filteredProvGrpList && filteredProvGrpList.size() > 0) {
				provGrpCSVWithGrpIndY = prepareProvGrpCSVWithGrpInd(request, filteredProvGrpList, Constants.GRP_IND_Y);
				provGrpCSVWithGrpIndN = prepareProvGrpCSVWithGrpInd(request, filteredProvGrpList, Constants.GRP_IND_N);
			}

			// Group Ind Y list
			if (null != provGrpCSVWithGrpIndY && !provGrpCSVWithGrpIndY.isEmpty()) {
				request.setProvGrpIds(provGrpCSVWithGrpIndY);
				request.setGrpInd(Constants.GRP_IND_Y);
				//PCMSP-243
				//resultList = service.getData(request);
				summaryObject = service.getData(request);
				resultList = summaryObject.getResults();
				lobDescs = new ArrayList<String>(summaryObject.getUniqueLobDesc());
				finalTickersList = (ArrayList<TickersBean>) service.getBeanList(resultList, request, lobDescs);
			}

			// Group Ind N list
			if (null != provGrpCSVWithGrpIndN && !provGrpCSVWithGrpIndN.isEmpty()) {
				request.setProvGrpIds(provGrpCSVWithGrpIndN);
				request.setGrpInd(Constants.GRP_IND_N);
				//PCMSP-243
				//resultList = service.getData(request);
				summaryObject = service.getData(request);
				resultList = summaryObject.getResults();
				lobDescs = new ArrayList<String>(summaryObject.getUniqueLobDesc());
				finalTickersList.addAll((ArrayList<TickersBean>) service.getBeanList(resultList, request, lobDescs));
			}

			if (null == resultList || (null != resultList && resultList.isEmpty())) {
				response.setMessage(err.getProperty("successNoData"));
			}
			else {
				response.setMessage(err.getProperty("successful"));
				response.setData(finalTickersList);
			}

			response.setSuccess(true);

		}
		catch (Exception pe) {
			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

		return response;

	}

	//	private Map<String, String> getDataMap(GetPerformanceSummaryTickersRequest perfTickerRequest) {
	//		//PCMSRequest request = new HashMap<String, String>();
	//		request.put("lob", perfTickerRequest.getLob());
	//		request.put("programId", perfTickerRequest.getProgramId());
	//		request.put("provGrpDimKey", perfTickerRequest.getProviderGroupDimKey());
	//		request.put("measurementPeriodStartDt", perfTickerRequest.getMeasurementPeriodStartDt());
	//		request.put("measurementPeriodEndDt", perfTickerRequest.getMeasurementPeriodEndDt());
	//		request.put("measurementInterval", perfTickerRequest.getMeasurementInterval());
	//		request.put("lobs", perfTickerRequest.getLobs());
	//		// GBD part 2
	//		request.setCmpId(perfTickerRequest.getCmpId());
	//		request.setProvGrpIds(perfTickerRequest.getProviderGroupId());
	//		request.put(Constants.USER_ACS_INFO_JSON, perfTickerRequest.getUserAcsInfoJson());
	//
	//		request.put("sessionId", perfTickerRequest.getSessionId());
	//		request.put("entitlementId", perfTickerRequest.getEntitlementId());
	//		request.put("msrmntStrtDt",
	//				perfTickerRequest.getMeasurementPeriodStartDt());
	//		request.put("provGrpId", perfTickerRequest.getProvGrpId());
	//		return request;
	//	}

}
