package com.wellpoint.pc2dash.action.erVisits;

import com.wellpoint.pc2dash.data.dto.PopulationManagementRequest;

public class GetErVisitRequest extends PopulationManagementRequest {
	
	boolean isERCostAvailableInd;

	public boolean isERCostAvailableInd() {
		return isERCostAvailableInd;
	}

	public void setERCostAvailableInd(boolean isERCostAvailableInd) {
		this.isERCostAvailableInd = isERCostAvailableInd;
	}


}
