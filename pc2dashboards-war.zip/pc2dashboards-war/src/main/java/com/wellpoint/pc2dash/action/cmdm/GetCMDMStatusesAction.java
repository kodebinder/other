package com.wellpoint.pc2dash.action.cmdm;

import java.util.List;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.data.dao.CMDMStatuses;
import com.wellpoint.pc2dash.dto.patient.cmdm.CMDMFilter;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetCMDMStatusesAction extends Action {

	GetCMDMFiltersResponse response = new GetCMDMFiltersResponse();

	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		GetCMDMStatusesRequest request = (GetCMDMStatusesRequest) actionRequest;

		try {
			// Pass the Request to the DAO (no need to populate a HashMap)
			CMDMStatuses dao = new CMDMStatuses();
			List<CMDMFilter> resultList = dao.getCMDMStatusesAndReasons(request);
			response.setMessage(StringUtil.buildMessage(resultList.isEmpty()));
			response.setSuccess(true); // based on GetCareOpportunitiesPatientAction.process(), MW never returns "false"
			response.setText("."); // Currently hardcoded to what UI expects
			response.setId(0); // Currently hardcoded to what UI expects
			response.getChildren().addAll(resultList);

		}
		catch (Exception e) {
			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(e, response);
		}

		return response;
	}

}
