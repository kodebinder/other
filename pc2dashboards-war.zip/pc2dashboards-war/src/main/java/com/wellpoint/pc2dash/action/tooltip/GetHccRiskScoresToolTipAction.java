package com.wellpoint.pc2dash.action.tooltip;

import java.util.Collection;

import com.google.gson.JsonObject;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.data.dao.HccRiskScoreMedicareAndCommercialFacts;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;

public class GetHccRiskScoresToolTipAction extends GetPatientDetailAction {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetHccRiskScoresToolTipAction.class);

	public ActionResponse process(ActionRequest actionRequest) {

		ActionResponse result = new GetPatientDetailResponse();
		GetPatientDetailRequest request = (GetPatientDetailRequest) actionRequest;
		ErrorProperties err = ErrorProperties.getInstance();

		//Added for Attest Logic : Starts
		boolean attested = false;
		try {
			attested = new HccRiskScoreMedicareAndCommercialFacts().checkAttestation(request);
		}
		catch (Exception e) {
			attested = false;
			logger.error("Unable to retrieve audit entry.", e);
		}
		//Added for Attest Logic : Ends

		try {

			Collection<Object> vals;

			String typeCd = request.getTypeCd();
			String cmd = request.getCmd();
			String lob = request.getLineOfBusiness();

			if (typeCd.equalsIgnoreCase("documentationGaps") && cmd.equalsIgnoreCase("getClinicalDocumentationGaps")) {
				logger.info("Documentation Gaps cmd : " + cmd + "typeCd : " + typeCd + "Lob : " + lob);
				vals = getCoolerKingOrMedicarePopupDetails(request);
			}
			else {
				throw new Exception("Invalid detail type (" + typeCd + ") or Invalid LOB (" + lob + ") or Invalid cmd (" + cmd + ")");
			}
			
			if(lob != null && (lob.toUpperCase().contains(Constants.MEDICAID.toUpperCase())
							|| lob.toUpperCase().contains(Constants.MEDICARE.toUpperCase())
							|| lob.toUpperCase().contains(Constants.FPCC_MEDICARE.toUpperCase())
							|| lob.toUpperCase().contains(Constants.COMMERCIAL.toUpperCase())
							|| lob.toUpperCase().contains(Constants.FPCC_COMMERCIAL.toUpperCase())
							|| lob.toUpperCase().contains(Constants.UNICARE.toUpperCase()))){
				attested = true;
			}

			result.setMessage(err.getProperty("successful"));
			result.setData(vals);
			result.setTotal(vals.size());
			result.setSuccess(true);
			JsonObject jsonObject = new JsonObject();
			jsonObject.addProperty("attested", attested);
			result.setMetaData(jsonObject);//Added for Attest Logic

		}
		catch (Exception e) {

			logger.error("Unable to retrieve patient detail.", e);

			result.setMessage("Unable to retrieve patient detail.");
			result.setSuccess(false);
		}

		return result;
	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getCoolerKingOrMedicarePopupDetails(GetPatientDetailRequest request) throws Exception {

		HccRiskScoreMedicareAndCommercialFacts dao = new HccRiskScoreMedicareAndCommercialFacts();
		Collection<?> details = dao.getCoolerKingOrMedicarePopupDetails(request);

		return (Collection<Object>) details;
	}


}
