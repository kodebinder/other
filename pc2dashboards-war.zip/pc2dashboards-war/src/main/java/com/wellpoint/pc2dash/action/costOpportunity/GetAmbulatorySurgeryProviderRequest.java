package com.wellpoint.pc2dash.action.costOpportunity;

import com.wellpoint.pc2dash.data.dto.PopulationManagementRequest;

public class GetAmbulatorySurgeryProviderRequest extends PopulationManagementRequest {

	private boolean hasDetailsDrilldownInd;

	public boolean isHasDetailsDrilldownInd() {
		return hasDetailsDrilldownInd;
	}

	public void setHasDetailsDrilldownInd(boolean hasDetailsDrilldownInd) {
		this.hasDetailsDrilldownInd = hasDetailsDrilldownInd;
	}
}
