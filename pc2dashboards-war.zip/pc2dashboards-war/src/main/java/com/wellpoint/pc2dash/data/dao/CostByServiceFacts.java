package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;

import com.wellpoint.pc2dash.action.tooltip.GetPatientDetailRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.patient.ServiceCost;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;


public class CostByServiceFacts extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(CostByServiceFacts.class);

	public boolean read(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void insert(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void update(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void delete(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public Collection<ServiceCost> getCostByService(GetPatientDetailRequest request) throws Exception {

		ArrayList<ServiceCost> result = new ArrayList<ServiceCost>();
		StringBuilder sql = new StringBuilder()
			.append("select pct.cost_ctgry_type_cd ,pct.cost_amt ,pct.vst_cnt ")
			.append(" from pat_cost_type pct ")
			.append(" join pat_smry_fact psf on (pct.pat_id = psf.mstr_cnsmr_dim_key) ")
			.append("	join poit_user_scrty_acs pusa on ( ")
			.append("		psf.prov_grp_id = pusa.prov_grp_id ")
			.append("		and case ")
			.append("				when  pusa.prov_org_tax_id = '0' then  psf.prov_org_tax_id ")
			.append("				else pusa.prov_org_tax_id ")
			.append("			end = psf.prov_org_tax_id ")
			.append("	) ")
			.append("where ")
			.append("	pusa.sesn_id = ? ")
			.append("	and pusa.enttlmnt_hash_key = ? ")
			.append("	and pct.pat_id = ? ")
			.append("with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());
			ps.setString(1, request.getSessionId());
			ps.setString(2, request.getEntitlementId());
			ps.setString(3, request.getMemberKey());

			executeQuery(logger, sql.toString());
			HashSet<String> ctgryCodes = new HashSet<String>();

			ServiceCost scPa;
			while (rs.next()) {
				scPa = new ServiceCost();
				scPa.setCategory(rs.getString("cost_ctgry_type_cd"));
				ctgryCodes.add(rs.getString("cost_ctgry_type_cd").trim());
				scPa.setAmount(StringUtil.costSepByDel(rs.getLong("cost_amt"), ","));
				if (rs.getString("vst_cnt") != null)
				{
					scPa.setCostEvents(rs.getString("vst_cnt"));
				}
				else
				{
					scPa.setCostEvents("0");
				}
				result.add(scPa);
			}

			if (!ctgryCodes.contains("Inpatient"))
			{
				scPa = new ServiceCost();
				scPa.setCategory("Inpatient");
				scPa.setAmount(StringUtil.costSepByDel(0L, ","));
				scPa.setCostEvents("0");
				result.add(scPa);
			}
			if (!ctgryCodes.contains("Outpatient"))
			{
				scPa = new ServiceCost();
				scPa.setCategory("Outpatient");
				scPa.setAmount(StringUtil.costSepByDel(0L, ","));
				scPa.setCostEvents("0");
				result.add(scPa);
			}
			if (!ctgryCodes.contains("Professional"))
			{
				scPa = new ServiceCost();
				scPa.setCategory("Professional");
				scPa.setAmount(StringUtil.costSepByDel(0L, ","));
				scPa.setCostEvents("0");
				result.add(scPa);
			}
			if (!ctgryCodes.contains("Pharmacy"))
			{
				scPa = new ServiceCost();
				scPa.setCategory("Pharmacy");
				scPa.setAmount(StringUtil.costSepByDel(0L, ","));
				scPa.setCostEvents("0");
				result.add(scPa);
			}

			Collections.sort(result, new Comparator<ServiceCost>() {

				@Override
				public int compare(ServiceCost paramT1, ServiceCost paramT2) {

					return (paramT1.getCategory().compareTo(paramT2.getCategory()));

				}
			});
		}
		catch (Exception e) {

			throw new Exception("Unable to get CostByService (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}



		return result;
	}
}
