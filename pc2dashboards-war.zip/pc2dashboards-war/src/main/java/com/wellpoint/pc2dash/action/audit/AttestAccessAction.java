package com.wellpoint.pc2dash.action.audit;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.data.dto.AuditEntry;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;


public class AttestAccessAction extends Action {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(AttestAccessAction.class);

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		AuditRequest request = (AuditRequest) actionRequest;
		AuditResponse response = new AuditResponse();

		try {

			if (!request.isValid()) {
				throw new Exception("Missing required fields.");
			}

			AuditEntry ae = new AuditEntry();
			ae.setUserId(request.getUserId());
			ae.setSessionId(request.getSessionId());
			ae.setPatientId(request.getPatientId());
			ae.setAccessType(request.getAccessType());
			
			if (!ae.read()) {

				ae.setReferenceId(request.getReferenceId());
				ae.setIpAddress(request.getIpAddress());
				ae.setDateTime(new Date());

				ae.save();
			}

			Map<String, Boolean> result = new HashMap<String, Boolean>();
			result.put("attested", Boolean.TRUE);

			response.setData(result);
			response.setMessage("Access has been attested.");
			response.setSuccess(true);
		}
		catch (Exception e) {

			logger.error("Unable to save audit entry.", e);

			response.setMessage("Unable to attest access.");
			response.setSuccess(false);
		}

		return response;
	}
}
