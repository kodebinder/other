package com.wellpoint.pc2dash.action.export;

import com.wellpoint.pc2dash.data.dto.PCMSRequest;


public class GetUserExportsRequest extends PCMSRequest {

	public boolean isValid() {

		/*
		 * Required fields are already baked in.
		*/

		return true;
	}
}
