package com.wellpoint.pc2dash.action.utilization;

public class GetUtilizationChartResponse {

}
