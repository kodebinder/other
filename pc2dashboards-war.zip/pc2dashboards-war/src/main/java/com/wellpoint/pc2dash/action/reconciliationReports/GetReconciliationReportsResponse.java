package com.wellpoint.pc2dash.action.reconciliationReports;

import java.util.Collection;

import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.patient.TreeHierarchy;

public class GetReconciliationReportsResponse extends ActionResponse {

	private Collection<TreeHierarchy> children;

	public Collection<TreeHierarchy> getChildren() {
		return children;
	}

	public void setChildren(Collection<TreeHierarchy> children) {
		this.children = children;
	}

}
