package com.wellpoint.pc2dash.data.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.wellpoint.pc2dash.action.costOpportunity.GetCostOpportunitySummaryRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.dto.AppProperty;
import com.wellpoint.pc2dash.dto.costOpportunity.CostOpportunityBean;
import com.wellpoint.pc2dash.dto.costOpportunity.MinimumCriteriaBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class CostOpportunitySummaryFactsDao extends ServiceImpl {
	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(CostOpportunitySummaryFactsDao.class);
	private boolean displayDashIndicator = false; // PCMSP-6858
	private boolean displayBenchMark = false; // PCMSP-6858
	private boolean displayDashesRx = false; //PCMSP-15224
	private boolean displayDashesLab = false;//PCMSP-6866
	private boolean displayDashesAsc = false;//PCMSP-6864
	private boolean displayDashesSpl = false;//PCMSP-10329
	private boolean displayDashesEbc = false;//PCMSP-6868
	private boolean displayDashesipUtil = false; //PCMSP-6869
	private boolean displayDashesSoc = false; //PCMSP-18550
	private boolean isSocSuppressed = false;
	private boolean displayDashesNonPref = false;
	private boolean displayDashesNonPrefInd = false;

	public List<CostOpportunityBean> getCOCSummarydata(GetCostOpportunitySummaryRequest request, boolean exportFlag) throws Exception {

		Map<String, Boolean> minimumCriteriaMap = new HashMap<String, Boolean>(); //PCMSP-6869

		List<CostOpportunityBean> resultList = new ArrayList<CostOpportunityBean>();
		MinimumCriteriaBean minCritRx = new MinimumCriteriaBean("TOTL_SCRPT_NBR", "COC_RX_CTGRY_SMRY", Constants.COC_RX_PARAM, null);//PCMSP-15224
		MinimumCriteriaBean minCritLab = new MinimumCriteriaBean("unit_cnt", "coc_lab_prov_smry", "COC_LAB_MIN_LABS", null);
		MinimumCriteriaBean minCritAsc = new MinimumCriteriaBean("srgry_cnt", "coc_asc_ctgry_smry", "COC_ASC_MIN_TOTL_SRGRY", null);
		MinimumCriteriaBean minCritSpl = new MinimumCriteriaBean("EPSD_CNT", "COC_SPCLTY_CTGRY_SMRY", "COC_SPL_MIN_RFRL", null);//PCMSP-10329
		MinimumCriteriaBean minCritebc = new MinimumCriteriaBean("MBR_ELGBL_SLCT_SRVC_CNT"/*"MBR_SPCFD_SRVC_CNT"*/, "COC_EBC_CTGRY_SMRY", "COC_EBC_MIN_TOTL_EVNT", null);//PCMSP-18378
		MinimumCriteriaBean minCritipUtil = new MinimumCriteriaBean("MBR_CNDTN_CNT", "COC_IP_UTL_CTGRY_SMRY", "COC_IP_UTL_MIN_TOTL_EVNT", null);//PCMSP-6869
		MinimumCriteriaBean minCritSoc = new MinimumCriteriaBean("TOTL_CLMS_NBR", "COC_SOC_PROV_DRUG_SMRY", "COC_SOC_MIN_TOTL_CLM", null); //PCMSP-18550
		

		// Use CostOpportunityAverageCostPerRxDao.getAverageCostPerRxDetails() as a template
		String dir = request.getSort().get(0).getDirection();
		String masked = "asc".equalsIgnoreCase(dir) ? String.valueOf(Integer.MAX_VALUE) : String.valueOf(Integer.MIN_VALUE); // we want masked values to always be at the bottom, so use either the biggest or smallest value, depending

		CommonQueries cq = new CommonQueries();
		if (null != request.getAppPrptyList()) {
			for (AppProperty a : request.getAppPrptyList()) {
				if(a.getComment().equals(Constants.COC_RX)){
					request.setTapId(a.getValue());
					displayDashesRx = cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request, minCritRx); //PCMSP-15224
				}
				else if(a.getComment().equals(Constants.COC_LAB)){
					request.setTapId(a.getValue());
					displayDashesLab = cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request, minCritLab); // PCMSP-6866
				}
				else if(a.getComment().equals(Constants.COC_ASC)){
					request.setTapId(a.getValue());
					displayDashesAsc = cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request, minCritAsc); // PCMSP-6964
				}
				else if(a.getComment().equals(Constants.COC_SPL)){
					request.setTapId(a.getValue());
					displayDashesSpl = cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request, minCritSpl); // PCMSP-10329
				}
				else if(a.getComment().equals(Constants.COC_EBC)){
					request.setTapId(a.getValue());
					displayDashesEbc = cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request, minCritebc); // PCMSP-6868
				}
				else if(a.getComment().equals(Constants.COC_IP)){
					request.setTapId(a.getValue());
					displayDashesipUtil = cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request, minCritipUtil); // PCMSP-6869
				}
				else if(a.getComment().equals(Constants.COC_SOC)){
					request.setTapId(a.getValue());
					displayDashesSoc = cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request, minCritSoc); //PCMSP-18550
					displayDashesNonPref=cq.displayDashesBasedOnNonPrefClmCriteria(request);
				}
			}
		}
		
		request.setTapId(request.getMetricViewId());

		//PCMSP-6869 : Starts
		minimumCriteriaMap.put("displayDashesRx", displayDashesRx);//PCMSP-15224
		minimumCriteriaMap.put("displayDashesLab", displayDashesLab);
		minimumCriteriaMap.put("displayDashesAsc", displayDashesAsc);
		minimumCriteriaMap.put("displayDashesSpl", displayDashesSpl);
		minimumCriteriaMap.put("displayDashesEbc", displayDashesEbc);
		minimumCriteriaMap.put("displayDashesipUtil", displayDashesipUtil);
		minimumCriteriaMap.put("displayDashesSoc", displayDashesSoc); //PCMSP-18550
		//PCMSP-6869 Ends
		minimumCriteriaMap.put("displayDashesNonPref",displayDashesNonPref);

		StringBuilder dashesClause = new StringBuilder()
			.append(" case  when (a.MTRC_CD = '" + Constants.COC_LIER + "' and MEM_MNTH < (")
			.append(" select  APLCTN_PRPTY_VAL_TXT from  APLCTN_PRPTY where  APLCTN_PRPTY_NM=   ")
			.append(" '" + Constants.COC_LIER_PARAM + "' ) )")
			.append(" or (a.MTRC_CD = '" + Constants.COC_RX + "' and true = " + displayDashesRx + ") ") //PCMSP-15224
			.append(" or (a.MTRC_CD = '" + Constants.COC_LAB + "' and true = " + displayDashesLab + ") ") // PCMSP-8660
			.append(" or (a.MTRC_CD = '" + Constants.COC_ASC + "' and true = " + displayDashesAsc + ") ") // PCMSP-8684
			.append(" or (a.MTRC_CD = '" + Constants.COC_SPL + "' and true = " + displayDashesSpl + ") ") // PCMSP-10329
			.append(" or (a.MTRC_CD = '" + Constants.COC_EBC + "' and true = " + displayDashesEbc + ") ") // PCMSP-6868
			.append(" or (a.MTRC_CD = '" + Constants.COC_IP + "' and true = " + displayDashesipUtil + ") ") // PCMSP-6869
			.append(" or (a.MTRC_CD = '" + Constants.COC_SOC + "' and true = " + displayDashesSoc + ") ") //PCMSP-18550
			.append(" then ")
			.append(masked);
	
		StringBuilder bnchMarkPerfRateZeroClause= new StringBuilder(" when b.BNCHMRK_90_PCTILE_AMT <= 0 and b.CURR_PERF_RATE <=0  ");
		StringBuilder bnchMarklessPerfRateClause= new StringBuilder(" when b.BNCHMRK_90_PCTILE_AMT > b.CURR_PERF_RATE then 0.00 ");

		StringBuilder query = new StringBuilder()
			/*PCMSP-19357 CHANGE 1*/
			.append(" select d.* from (")
			.append(" select c.*, ")
			.append(" row_number() over (  ")
			.append(" 	order by   ")
			.append(buildSortClause(request))
			
			.append(" ) as row_nbr ")
			.append(" from  ( ") 
			.append(" select b.MTRC_CD, ")
			.append(" b. MTRC_NM, ")

			.append(" case ") .append(bnchMarkPerfRateZeroClause).append(" and b.COST_OPRTNTY_AMT != ").append(masked).append("  then 0.00 " )
			.append(bnchMarklessPerfRateClause)
			.append(" else b.COST_OPRTNTY_AMT end as COST_OPRTNTY_AMT,  ")

			.append(" case ") .append(bnchMarkPerfRateZeroClause).append(" and b.COST_OPRTNTY_10_PCTAG_AMT != ").append(masked).append("  then 0.00 " )
			.append(bnchMarklessPerfRateClause)
			.append(" else b.COST_OPRTNTY_10_PCTAG_AMT end as COST_OPRTNTY_10_PCTAG_AMT,  ")

			.append(" case ") .append(bnchMarkPerfRateZeroClause).append(" and b.PMPM_OPRTNTY_AMT != ").append(masked).append("  then 0.00 " )
			.append(bnchMarklessPerfRateClause)
			.append(" else b.PMPM_OPRTNTY_AMT end as PMPM_OPRTNTY_AMT,  ")

			.append(" case ") .append(bnchMarkPerfRateZeroClause).append(" and b.PMPM_OPRTNTY_10_PCTAG_AMT != ").append(masked).append("  then 0.00 " )
			.append(bnchMarklessPerfRateClause)
			.append(" else b.PMPM_OPRTNTY_10_PCTAG_AMT end as PMPM_OPRTNTY_10_PCTAG_AMT,  ")

			.append(" case ") .append(bnchMarkPerfRateZeroClause).append(" and b.CURR_PERF_RATE != ").append(masked).append("  then 0.00 " )
			.append(" else b.CURR_PERF_RATE end as CURR_PERF_RATE,  ")

			.append(" case ") .append(bnchMarkPerfRateZeroClause).append(" and b.BNCHMRK_90_PCTILE_AMT != ").append(masked).append("  then 0.00 " )
			.append(" else b.BNCHMRK_90_PCTILE_AMT end as BNCHMRK_90_PCTILE_AMT,  ")

			.append(" b.DISPLAY_IND,  ")
			.append(" b.MULTIGROUPSCENARIO,  ")

			.append(" case   	when b.BNCHMRK_90_PCTILE_AMT<=0 or  multiGroupScenario ='Y' then ")
			.append(masked)
			.append(" when b.BNCHMRK_90_PCTILE_AMT > 0 and  b.CURR_PERF_RATE >=0   ")
			.append(" then cast(b.CURR_PERF_RATE as decimal(18,4))/cast(b.BNCHMRK_90_PCTILE_AMT as decimal(18,4))  ")
			.append(" else 0.00 end  as actualBenchmarkRatio	  ")
			.append(" ,case   	when b.BNCHMRK_90_PCTILE_AMT<=0 then 'Y' else 'N' end as isBenchmark0 ")
			.append(" ,b.ROW_CNT ")
			/*PCMSP-19357 CHANGE 1*/
			
			.append(" from ( ")
			.append(" select ")
			.append(" a.MTRC_CD, ")
			.append(" a.MTRC_NM, ")

			.append(dashesClause)
			.append(" when a.MTRC_CD = '" + Constants.COC_SOC + "' and true = "+displayDashesNonPref+" then "+ masked)
			.append(
				" WHEN MTRC_CD = 'ASC' THEN MAX(ASC_TOTAL)  WHEN MTRC_CD = 'SOC' THEN MAX(SOC_TOTAL) when  sum(a.COST_OPRTNTY_AMT) < 0 then  0.00 else  sum(a.COST_OPRTNTY_AMT) end as COST_OPRTNTY_AMT, ")

			.append(dashesClause)
			.append(" when a.MTRC_CD = '" + Constants.COC_SOC + "' and true = "+displayDashesNonPref+" then "+ masked)
			.append(" WHEN MTRC_CD IN ('" + Constants.COC_LAB + "','" + Constants.COC_IP
				+ "') THEN (CASE WHEN SUM(COST_OPRTNTY_AMT) >= 0 THEN CAST ((SUM(COST_OPRTNTY_AMT) * 0.1) AS decimal (18,3)) ELSE 0.00 END) ")
			.append(" WHEN MTRC_CD IN ('" + Constants.COC_ASC + "') THEN (CASE WHEN MAX(ASC_TOTAL) >= 0 THEN CAST ((MAX(ASC_TOTAL) * 0.1) AS decimal (18,3)) ELSE 0.00 END) ")

			.append(" WHEN MTRC_CD IN ('" + Constants.COC_SOC + "') THEN (CASE WHEN MAX(SOC_TOTAL) >= 0 THEN CAST ((MAX(SOC_TOTAL) * 0.1) AS decimal (18,3)) ELSE 0.00 END) ") //PCMSP-18556
			.append("  when a.MTRC_CD in ('" + Constants.COC_RX + "','" + Constants.COC_LIER + "','" + Constants.COC_SOC + "','" + Constants.COC_SPL + "','" + Constants.COC_EBC
				+ "') then ( ") // PCMSP- 9696,PCMSP-10329,PCMSP-18541
			.append("  case  when  sum(a.COST_OPRTNTY_10_PCTAG_AMT) <0 then  0.00 else sum(a.COST_OPRTNTY_10_PCTAG_AMT) end ) ")
			.append("  end as COST_OPRTNTY_10_PCTAG_AMT, ")


			.append(dashesClause)
			.append(" when a.MTRC_CD = '" + Constants.COC_SOC + "' and true = "+displayDashesNonPref+" then "+ masked)
			
			.append(" WHEN MTRC_CD IN ('" + Constants.COC_RX + "','" + Constants.COC_LAB + "','" + Constants.COC_SPL + "','" + Constants.COC_IP + "','" + Constants.COC_EBC
				+ "') THEN (CASE WHEN SUM(COST_OPRTNTY_AMT) >= 0 AND MEM_MNTH > 0 THEN CAST (SUM(COST_OPRTNTY_AMT) AS decimal (18,4)) / CAST (MEM_MNTH AS decimal (18,4)) ELSE 0.00 END) ")
			.append(" WHEN MTRC_CD IN ('" + Constants.COC_ASC
				+ "')  THEN (CASE WHEN MAX(ASC_TOTAL) >= 0 AND MEM_MNTH > 0 THEN CAST (MAX(ASC_TOTAL) AS decimal (18,4)) / CAST (MEM_MNTH AS decimal (18,4)) ELSE 0.00 END) ")
			.append(" WHEN MTRC_CD IN ('" + Constants.COC_SOC
				+ "')  THEN (CASE WHEN MAX(SOC_TOTAL) >= 0 AND MEM_MNTH > 0 THEN CAST (MAX(SOC_TOTAL) AS decimal (18,4)) / CAST (MEM_MNTH AS decimal (18,4)) ELSE 0.00 END) ") //PCMSP-18556
			.append(" WHEN MTRC_CD = '" + Constants.COC_LIER
				+ "' THEN (CASE WHEN SUM(COST_OPRTNTY_AMT) >= 0 AND MEM_MNTH > 0 THEN (CAST (SUM(COST_OPRTNTY_AMT) AS Decimal (18,4)) / CAST (MEM_MNTH AS decimal (18,4))) ELSE 0.00 END) ")

			.append(" end as PMPM_OPRTNTY_AMT, ")

			.append(dashesClause)
			.append(" when a.MTRC_CD = '" + Constants.COC_SOC + "' and true = "+displayDashesNonPref+" then "+ masked)
			.append(" WHEN MTRC_CD IN ('" + Constants.COC_LAB + "','" + Constants.COC_IP
				+ "') THEN (CASE WHEN SUM(COST_OPRTNTY_AMT) >= 0 AND MEM_MNTH > 0 THEN (CAST (SUM(COST_OPRTNTY_AMT) AS decimal (18,4)) / CAST (MEM_MNTH AS decimal (18,4)) * 0.1) ELSE 0.00 END) ")
			.append(" WHEN MTRC_CD IN ('" + Constants.COC_ASC
				+ "') THEN (CASE WHEN MAX(ASC_TOTAL) >= 0 AND MEM_MNTH > 0 THEN (CAST (MAX(ASC_TOTAL) AS decimal (18,4)) / CAST (MEM_MNTH AS decimal (18,4)) * 0.1) ELSE 0.00 END) ")
			.append(" WHEN MTRC_CD IN ('" + Constants.COC_SOC
				+ "') THEN (CASE WHEN MAX(SOC_TOTAL) >= 0 AND MEM_MNTH > 0 THEN (CAST (MAX(SOC_TOTAL) AS decimal (18,4)) / CAST (MEM_MNTH AS decimal (18,4)) * 0.1) ELSE 0.00 END) ") //PCMSP-18556
			.append(" when a.MTRC_CD in ('" + Constants.COC_LIER + "') then ( ")
			.append(
				" case  when  sum(a.COST_OPRTNTY_10_PCTAG_AMT) >= 0 and MEM_MNTH > 0 then (cast (sum(a.COST_OPRTNTY_10_PCTAG_AMT) as Decimal(18,4)) / cast(MEM_MNTH as decimal(18,4))) else 0.00  end ) ")
			.append(" when a.MTRC_CD in ('" + Constants.COC_RX + "','" + Constants.COC_SPL + "','" + Constants.COC_EBC + "') then ( ") // PCMSP- 9696,PCMSP-10329 , PCMSP-18541
			.append(
				" case  when  sum(a.COST_OPRTNTY_10_PCTAG_AMT) >= 0 and MEM_MNTH > 0 then (cast (sum(a.COST_OPRTNTY_10_PCTAG_AMT) as Decimal(18,4)) / cast(MEM_MNTH as decimal(18,4))) else 0.00  end ) ")
			.append(" end as PMPM_OPRTNTY_10_PCTAG_AMT, ")

			.append(dashesClause)
			//Changed for PCMSP-17266 : Starts
			.append(" when a.MTRC_CD in ( '" + Constants.COC_IP + "') then ( ")
			.append(" case when max(a.IP_PERF_RATE) > 0 then max(IP_PERF_RATE) else 0.00 end ) ")
			//Changed for PCMSP-17266 Ends
			.append(" when a.MTRC_CD in ( '" + Constants.COC_RX + "') then ( ")
			.append("  case  when  sum(a.PRFRMN_RT_DNMNTR_NBR)>0 and  sum(a.PRFRMN_RT_NMRTR_NBR) > 0 then ")
			.append(" (cast (sum(a.PRFRMN_RT_NMRTR_NBR) as Decimal(18,3)) / cast(sum(a.PRFRMN_RT_DNMNTR_NBR) as decimal(18,3))) else 0.00 end) ") // Added "else 0.00" for proper sorting
			.append(" when a.MTRC_CD in ( '" + Constants.COC_EBC + "') then ( ")
			.append("  case  when  sum(a.PRFRMN_RT_DNMNTR_NBR)>0 and  sum(a.PRFRMN_RT_NMRTR_NBR) > 0 then ")
			.append(" ((cast (sum(a.PRFRMN_RT_NMRTR_NBR) as Decimal(18,3)) / cast(sum(a.PRFRMN_RT_DNMNTR_NBR) as decimal(18,3)))*1000) else 0.00 end) ") // Added "else 0.00" for proper sorting
			.append(" when a.MTRC_CD = '" + Constants.COC_LAB + "' then ( ")
			.append("  case  when  sum(a.PRFRMN_RT_DNMNTR_NBR)>0 and  sum(a.PRFRMN_RT_NMRTR_NBR) > 0 then ")
			.append(" ((cast (sum(a.PRFRMN_RT_NMRTR_NBR) as Decimal(18,3)) / cast(sum(a.PRFRMN_RT_DNMNTR_NBR) as decimal(18,3)))*100) else 0.00 end) ") // Added "else 0.00" for proper sorting
			.append(" when a.MTRC_CD in ('" + Constants.COC_LIER + "') then ( ")
			.append("  case  when  sum(a.PRFRMN_RT_DNMNTR_NBR)>0 and  MEM_MNTH > 0 then ")

			.append(" ((cast (sum(a.PRFRMN_RT_NMRTR_NBR) as Decimal(18,3)) / cast(sum(a.PRFRMN_RT_DNMNTR_NBR) as decimal(18,3)))*12000) else 0.00 end) ") // Added "else 0.00" for proper sorting
			.append(" when a.MTRC_CD in ('" + Constants.COC_ASC + "','" + Constants.COC_SPL + "') then ( ")// PCMSP-18541

			.append("  case  when  sum(a.PRFRMN_RT_DNMNTR_NBR)>0 and  sum(a.PRFRMN_RT_NMRTR_NBR) > 0 then ")
			.append(" (cast (sum(a.PRFRMN_RT_NMRTR_NBR) as Decimal(18,3)) / cast(sum(a.PRFRMN_RT_DNMNTR_NBR) as decimal(18,3)) * 100) else 0.00 end) ") // PCMSP- 9696
			.append(" when a.MTRC_CD in ('" + Constants.COC_SOC + "') then ( ") // PCMSP-18556
			.append("  case  when  max(totalClmsCnt)>0 and  max(nonPrefSiteClmsCnt) > 0 then ")
			.append(" (cast (max(nonPrefSiteClmsCnt) as Decimal(18,3)) / cast(max(totalClmsCnt) as decimal(18,3)) * 100) else 0.00 end) ")
			.append(" else  0.00  end as CURR_PERF_RATE, ")

			
			// Note that the display_ind logic in the block below is the opposite of the dashesClause logic at the beginning of the method. A display_ind of "N" will result in masking.
			// Note that Lab display logic is handled separately (displayDashesLab).
			.append(" case  when a.MTRC_CD = 'LIER' ")
			.append(" and  MEM_MNTH >= ( select   APLCTN_PRPTY_VAL_TXT ") 
			.append(" from   APLCTN_PRPTY  where   APLCTN_PRPTY_NM=    'COC_LIER_MIN_TOTL_SCRPT' )  then  'Y' ") 
			.append(" when   a.MTRC_CD NOT IN ('LIER')  then  'Y'  else  'N' end as display_ind, ")

			.append(" max(a.multiGroupScenario) as multiGroupScenario, ")

			.append(dashesClause).append(" when  (upper(a.multiGroupScenario) = 'Y') then ").append(masked).append(" when max(a.BNCHMRK_90_PCTILE_AMT) < 0 then ").append(masked)
			.append(" else max(a.BNCHMRK_90_PCTILE_AMT) end as BNCHMRK_90_PCTILE_AMT, ")
			.append(
				" max(NONPREFSITECLMSCNT) as NONPREFSITECLMSCNT,  max(TOTALCLMSCNT) as TOTALCLMSCNT,  ")

			.append(" count(*) over () as row_cnt ")
			.append(" from  ( ( select ") // PCMSP-17266
			.append(" SMRY.MTRC_CD,   ")
			.append(" SMRY.MTRC_NM,   ")
			.append("  0.00 as SOC_TOTAL, ") //PCMSP-18556 - SOC changes
			.append("  0 as NONPREFSITECLMSCNT, ")
			.append("  0 as TOTALCLMSCNT, ")
			.append(" MAX(ASC_OPP.ASC_TOTAL) AS ASC_TOTAL, sum( case when SMRY.COST_OPRTNTY_AMT < 0 then 0 else SMRY.COST_OPRTNTY_AMT end ) as COST_OPRTNTY_AMT, ") // PCMSP-10719
			.append(" sum(SMRY.COST_OPRTNTY_10_PCTAG_AMT) as COST_OPRTNTY_10_PCTAG_AMT,   ")
			//.append(" sum(SMRY.PMPM_OPRTNTY_AMT) as PMPM_OPRTNTY_AMT,   ")
			//.append(" sum(SMRY.PMPM_OPRTNTY_10_PCTAG_AMT)  PMPM_OPRTNTY_10_PCTAG_AMT,   ")
			.append(" SMRY.BNCHMRK_90_PCTILE_AMT as BNCHMRK_90_PCTILE_AMT,   ")
			.append(" sum(SMRY.PRFRMN_RT_DNMNTR_NBR) as PRFRMN_RT_DNMNTR_NBR, ")
			.append(" sum(SMRY.PRFRMN_RT_NMRTR_NBR) as PRFRMN_RT_NMRTR_NBR,  ")
			.append(
				" case  when  count(*) over (PARTITION BY SMRY.MTRC_CD)<=1 then  'N' else  'Y' end as multiGroupScenario,sum(SMRY.MBR_MNTH_CNT) as  MBR_MNTH_CNT, ILV.MEM_MNTH as MEM_MNTH ")
			.append(" ,0.00 as IP_PERF_RATE ") //Added for PCMSP-17266
			.append(" from ")
			.append(" COC_OPRTNTY_SMRY SMRY")

			.append(" join (select  ")
			.append(" nvl(SUM(MM.MBR_MNTH_12_CNT),0) as MEM_MNTH ")
			.append(" FROM  PAT_SMRY_FACT PSF ")
			.append(" INNER JOIN MSTR_CNSMR_MBR_MNTH_FACT MM ON ")
			.append(" MM.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY ")
			.append(" AND MM.RCRD_STTS_CD = 'ACT' ")
			/*Change recommended by Shakthi from Data Team*/
			.append(" WHERE PSF.ATRBN_STTS_CD = 'ACTIVE' ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and psf.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and psf.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {

			query.append(" and psf.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");

		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and psf.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and psf.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}


		query.append(" ) as ILV on 1=1 ")
			.append(" join poit_user_scrty_acs pusa on ( ")
			.append(" SMRY.prov_grp_id = pusa.prov_grp_id ")
			.append(" and ")
			.append(" case ")
			.append(" when  pusa.prov_org_tax_id = '0' then  SMRY.prov_org_tax_id ")
			.append(" else  pusa.prov_org_tax_id ")
			.append(" end = SMRY.prov_org_tax_id ")
			.append("	) ")

			.append(" LEFT OUTER JOIN ( ")
			.append("                 SELECT SUM(case when TOTALOPPORTUNITY < 0 then 0 else TOTALOPPORTUNITY end) AS ASC_TOTAL ")
			.append(" FROM ( SELECT PROCEDURETYPE, PROCEDURECODE,CASE WHEN SUM(COST_OPRTNTY_AMT) < 0 then 0.00 else SUM(COST_OPRTNTY_AMT) ")
			.append(" END AS TOTALOPPORTUNITY FROM ( ")
			.append("  SELECT ASMRY.SUB_MTRC_NM AS PROCEDURETYPE, ")
			.append("    ASMRY.SUB_MTRC_CD AS PROCEDURECODE, CASE WHEN SUM(COST_OPRTNTY_AMT) < 0 then 0.00 else SUM(COST_OPRTNTY_AMT) end as  COST_OPRTNTY_AMT ")

			.append(" FROM ")
			.append(" COC_ASC_CTGRY_SMRY AS ASMRY  where ");


		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append("  ASMRY.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and ASMRY.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and ASMRY.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and ASMRY.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and ASMRY.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}

		query.append(" GROUP BY ASMRY.SUB_MTRC_NM, ")
			.append(" ASMRY.SUB_MTRC_CD ) ")

			.append(" GROUP BY  PROCEDURETYPE, ")
			.append(" PROCEDURECODE) AS A ")
			.append(" ) AS ASC_OPP  ")
			.append(" ON 1=1 ")
			.append("  where ")
			.append("	 pusa.sesn_id = ? ")
			.append("	and pusa.enttlmnt_hash_key = ? ");

		if (null != request.getAppPrptyList()) {
			StringBuilder mtrc = new StringBuilder();

			for (AppProperty a : request.getAppPrptyList()) {
				StringBuilder temp = new StringBuilder();
				boolean suppressed = false;
				request.setTapId(a.getValue());
				if (StringUtil.isNotBlankOrFalse(a.getComment()) && !Constants.COC_IP.equals(a.getComment())) {
					temp.append(" or ( SMRY.MTRC_CD = ? ");
					if (!StringUtil.isSuppressedTAPGRPsEmpty(request)
						&& (request.getSuppressionForKey(request.getTapId()).getSuppressedGRPs().size() - StringUtil.hasAllSuppression(request) > 0)) {
						if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) && !StringUtil.getUnsuppressedValuesForTapId(request, "GRP").equalsIgnoreCase("---")) {
							temp.append(" and SMRY.prov_grp_id in (" +
								StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ")
								.append(" and SMRY.pgm_dim_key in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProgramIds()) + ") ")
								.append(" and SMRY.lob_desc in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getLobIds()) + ") ");
						}
						else {
							suppressed = true;
							if (a.getComment().equalsIgnoreCase(Constants.COC_SOC))
								isSocSuppressed = true;
							a.setComment("");
						}
					}
					else if (!StringUtil.isSuppressedTAPMKTEmpty(request)) {
						if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "MKT")) && !StringUtil.getUnsuppressedValuesForTapId(request, "MKT").equalsIgnoreCase("---")) {
							temp.append(" and SMRY.prov_grp_id in (" +
								StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "MKT")) + ") ")
								.append(" and SMRY.pgm_dim_key in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProgramIds()) + ") ")
								.append(" and SMRY.lob_desc in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getLobIds()) + ") ");
						}
						else {
							suppressed = true;
							if (a.getComment().equalsIgnoreCase(Constants.COC_SOC))
								isSocSuppressed = true;
							a.setComment("");
						}
					}
					else if (!StringUtil.isSuppressedTAPPGMsEmpty(request)) {
						if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) && !StringUtil.getUnsuppressedValuesForTapId(request, "PGM").equalsIgnoreCase("---")) {
							temp.append(" and SMRY.prov_grp_id in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvGrpIds()) + ") ")
								.append(" and SMRY.pgm_dim_key in ("
									+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ")
								.append(" and SMRY.lob_desc in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getLobIds()) + ") ");
						}
						else {
							suppressed = true;
							if (a.getComment().equalsIgnoreCase(Constants.COC_SOC))
								isSocSuppressed = true;
							a.setComment("");
						}
					}
					else if (!StringUtil.isSuppressedTAPLOBsEmpty(request)) {
						if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) && !StringUtil.getUnsuppressedValuesForTapId(request, "LOB").equalsIgnoreCase("---")) {
							temp.append(" and SMRY.prov_grp_id in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvGrpIds()) + ") ")
								.append(" and SMRY.pgm_dim_key in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProgramIds()) + ") ")
								.append(" and SMRY.lob_desc in ("
									+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
						}
						else {
							suppressed = true;
							if (a.getComment().equalsIgnoreCase(Constants.COC_SOC))
								isSocSuppressed = true;
							a.setComment("");
						}
					}
					else if (!StringUtil.isSuppressedTAPALLEmpty(request)) {
						if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "ALL")) && !StringUtil.getUnsuppressedValuesForTapId(request, "ALL").equalsIgnoreCase("---")) {
							temp.append(" and SMRY.prov_grp_id in (" +
								StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "ALL")) + ") ")
								.append(" and SMRY.pgm_dim_key in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProgramIds()) + ") ")
								.append(" and SMRY.lob_desc in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getLobIds()) + ") ");
						}
						else {
							suppressed = true;
							if (a.getComment().equalsIgnoreCase(Constants.COC_SOC))
								isSocSuppressed = true;
							a.setComment("");
						}
					}
					else {
						if (StringUtil.isNotBlankOrFalse(request.getProvGrpIds())) {
							temp.append(" and SMRY.prov_grp_id in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvGrpIds()) + ") ");
						}
						if (StringUtil.isNotBlankOrFalse(request.getProgramIds())) {
							temp.append(" and SMRY.pgm_dim_key in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProgramIds()) + ") ");
						}
						if (StringUtil.isNotBlankOrFalse(request.getLobIds())) {
							temp.append(" and SMRY.lob_desc in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getLobIds()) + ") ");
						}
					}


					// Organization filter
					if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
						temp.append(" and SMRY.ip_dim_key in ("
							+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
					}

					if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
						temp.append(" and SMRY.prov_org_dim_key in ("
							+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
							+ ") ");
					}
					if (!suppressed) {
						mtrc.append(temp + " ) ");
					}

				}
			}

			if (StringUtils.isNotEmpty(mtrc.toString())) {
				StringUtil.removeFirstOccurenceWithinString(mtrc, "or");
				query.append(" and ( " + mtrc + " ) ");
			}
			else {
				return new ArrayList<CostOpportunityBean>();
			}
		}
		else {
			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
				query.append(" and SMRY.prov_grp_id in (" +
					StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
			}

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
				query.append(" and SMRY.pgm_dim_key in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
			}

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
				query.append(" and SMRY.lob_desc in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
			}

			// Organization filter
			if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
				query.append(" and SMRY.ip_dim_key in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
			}

			if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
				query.append(" and SMRY.prov_org_dim_key in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
					+ ") ");
			}
		}

		query.append(" group by  SMRY.MTRC_CD, SMRY.MTRC_NM ,SMRY.BNCHMRK_90_PCTILE_AMT, ILV.MEM_MNTH")

			//Changes for PCMSP-17266 : Started
			.append(" )	union( ")
			.append(" select   'IP' as MTRC_CD ")
			.append(" ,'Inpatient Utilization' as MTRC_NM ")
			.append(" , 0.00 as SOC_TOTAL ") // PCMSP-18556 --SOC changes
			.append(" , 0 as NONPREFSITECLMSCNT ")
			.append(" , 0 as TOTALCLMSCNT ")
			.append(" , 0.00 as ASC_TOTAL ")
			.append(" , sum(totalOpportunity) as COST_OPRTNTY_AMT ")
			.append(" , sum(totalOpportunity)*0.1 as COST_OPRTNTY_10_PCTAG_AMT  ")
			//Changed for PCMSP-19356 : Starts
			.append(" , case when  TOTL_MEMBER> 0 and sum(EXPECTED_DAYS) >0 then "  )
			.append(" (cast(sum(EXPECTED_DAYS) as decimal(18,4))/cast(TOTL_MEMBER as decimal(18,4)))*1000 ")
			.append(" else 0.00 end as BNCHMRK_90_PCTILE_AMT ")		
			//Changed for PCMSP-19356 : Ends
			.append(" , 0.00 as PRFRMN_RT_DNMNTR_NBR ")
			.append(" , 0.00 as PRFRMN_RT_NMRTR_NBR ")
			.append(" , case 	when   count(*) over (PARTITION BY 'IP')<=1 then   'N'	else   'Y' end as multiGroupScenario ")
			.append(" , 0.00 as MBR_MNTH_CNT ")
			.append(" , MEM_MNTH as MEM_MNTH ")			
			//Changed for PCMSP-19356 : Starts
			.append(" ,case when 	sum(TC_INPAT_DAY_CNT) >0 and TOTL_MEMBER>0  ")
			.append(" then 	(cast(sum(TC_INPAT_DAY_CNT) as decimal(18,4)) / cast(TOTL_MEMBER as decimal(18,4)))*1000 ")
			.append(" else 0.00 end as IP_PERF_RATE ")
			//Changed for PCMSP-19356 : Ends
			.append(" from( ")
			.append(" select   C.CATEGORYCODE as categoryCode  ")
			.append(" ,C.CATEGORY as category ")
			.append(
				" ,case when  C.Days_Over_Benchmark > 0 and   C.Allowed_cost_per_day > 0 then  cast(C.Days_Over_Benchmark as decimal(18,4)) * cast(C.Allowed_cost_per_day as decimal(18,4))else  0.00 end as totalOpportunity ")
			.append(" ,C.MEM_MNTH as MEM_MNTH  ")
			//Changed for PCMSP-19356 : Starts
			.append(" , C.TOTL_MEMBER AS TOTL_MEMBER ") 
			.append(" , TC_INPAT_DAY_CNT ")
			.append(" ,(TC_INPAT_DAY_CNT - DAYS_OVER_BENCHMARK) AS EXPECTED_DAYS " )
			//Changed for PCMSP-19356 : Ends	
			.append(" from   (  ")
			.append(" select     B.CATEGORYCODE ")
			.append(" ,B.CATEGORY  	")
			.append(" ,case  when  B.TC_INPAT_DAY_CNT > B.Days_At_Benchmark then  (B.TC_INPAT_DAY_CNT - B.Days_At_Benchmark) else  0 end as Days_Over_Benchmark ")
			.append(" ,B.Allowed_cost_per_day ")
			.append(" ,B.MEM_MNTH ")
			.append(" ,B.TOTL_MEMBER ")// Added for PCMSP-19356
			.append(" ,B.TC_INPAT_DAY_CNT ")
			.append(" ,TOT_MBR_CNDTN_CNT ")
			.append(" from    ( ")
			.append(" SELECT CATEGORYCODE, ")
			.append(" CATEGORY, ")
			.append(" SVRTY_ADJSTMNT, ")
			.append(" BNCHMRK_PCTILE_90_NBR, ")
			.append(" CASE WHEN MBR_CNDTN_CNT > 0 AND SVRTY_ADJSTMNT > 0 AND BNCH_90_CNT = 1 ")
			.append(" THEN CAST (((CAST (BNCHMRK_PCTILE_90_NBR AS DECIMAL (18,4)) * CAST (MBR_CNDTN_CNT AS DECIMAL (18,4))) / 1000) AS DECIMAL (18,4)) * CAST (SVRTY_ADJSTMNT AS DECIMAL (18,4)) ") 
			.append(" ELSE 0.0 END AS DAYS_AT_BENCHMARK, ")
			.append(" MBR_CNDTN_CNT, ")
			.append(" TC_INPAT_DAY_CNT, ")
			.append(" ALLOWED_COST_PER_DAY, ")
			.append(" SVRTY_SCR_NBR, ")
			.append(" MEM_MNTH,  ")
			.append(" TOTL_MEMBER,  ")
			.append(" A.MBR_CNDTN_CNT TOT_MBR_CNDTN_CNT,  ")
			.append(" SUM(SVRTY_SCR_NBR) OVER () AS TOT_SVRTY_SCR_NBR, ")
			.append(" SUM(EPSD_CNT) OVER () AS TOT_EPSD_CNT,  ")
			.append(
				" (select BNCHMRK_PCTILE_90_NBR  from COC_BNCHMRK_DATA  where   COC_MTRC_CD = 'IP_SVRTY' and SUB_MTRC_CD = 'SMRY' and RCRD_STTS_CD ='ACT' ) as TOT_SVRTY_BNCHMRK ")
			.append(" from    ( ")
			.append(" SELECT ")
			.append("  		TRIM(IPSMRY.SUB_MTRC_CD) AS CATEGORYCODE, ")
			.append(" 		TRIM(IPSMRY.SUB_MTRC_NM) AS CATEGORY, ")
			.append("        CASE WHEN SUM(IPSMRY.MBR_CNDTN_CNT) > 0 ")
			.append(
				"       	 THEN CAST (CAST (SUM(IPSMRY.SVRTY_SCR_NBR) AS decimal (18,4)) / CAST (SUM(IPSMRY.EPSD_CNT) AS decimal (18,4)) AS decimal (18,4)) / CAST (MAX(IPSMRY.SVRTY_BNCHMRK) AS decimal (18,4)) ")
			.append("  ELSE 0.00 END AS SVRTY_ADJSTMNT, ")
			.append("  CASE WHEN SUM(IPSMRY.TC_INPAT_DAY_CNT) > 0 ")
			.append("  THEN CAST (SUM(IPSMRY.TOTL_ALWD_AMT) AS decimal (18,4)) / CAST (SUM(IPSMRY.TC_INPAT_DAY_CNT) AS decimal (18,4)) ")
			.append("  ELSE 0.00 END AS ALLOWED_COST_PER_DAY, ")
			.append("  CASE WHEN SUM(IPSMRY.ADMT_CNT) > 0  ")
			.append("  THEN CAST (SUM(IPSMRY.TC_INPAT_DAY_CNT) AS decimal (18,4)) / CAST (SUM(IPSMRY.ADMT_CNT) AS decimal (18,4)) ")
			.append("  ELSE 0.00 END AS AVG_LOS, ")
			.append("  CAST (SUM(IPSMRY.SVRTY_SCR_NBR) AS decimal (18,4)) AS SVRTY, ")
			.append("  CAST (SUM(IPSMRY.MBR_CNDTN_CNT) AS decimal (18,4)) AS MBR_CNDTN_CNT, ")
			.append("  CAST (MAX(IPSMRY.SVRTY_BNCHMRK) AS decimal (18,4)) AS SVRTY_BNCMRK, ")
			.append("  CAST (MAX(IPSMRY.BNCHMRK_PCTILE_90_NBR) AS decimal (18,4)) AS BNCHMRK_PCTILE_90_NBR, ")
			.append(" CAST (SUM(IPSMRY.TC_INPAT_DAY_CNT) AS decimal (18,4)) AS TC_INPAT_DAY_CNT, ")
			.append(" CAST (SUM(IPSMRY.TOTL_ALWD_AMT) AS decimal (18,4)) AS TOTL_ALWD_AMT, ")
			.append(" CAST (SUM(IPSMRY.SVRTY_SCR_NBR) AS decimal (18,4)) AS SVRTY_SCR_NBR, ")
			.append("  CAST (SUM(IPSMRY.EPSD_CNT) AS decimal (18,4)) AS EPSD_CNT,  ")
			.append("  SUM(COUNT(DISTINCT IPSMRY.BNCHMRK_PCTILE_90_NBR)) OVER ( PARTITION BY IPSMRY.SUB_MTRC_CD,IPSMRY.SUB_MTRC_NM) AS BNCH_90_CNT, ")
			.append("  ILV.MEM_MNTH,  ")
			.append("   ILV.TOTL_MEMBER")// Added for PCMSP-19356
			.append(" from  COC_IP_UTL_CTGRY_SMRY AS IPSMRY  ")
			.append(" join   (  ")
			.append(" select     nvl(SUM(MM.MBR_MNTH_12_CNT),0) as MEM_MNTH ")
			.append("  , count(distinct psf.MSTR_CNSMR_DIM_KEY) as totl_member ")
			.append(" from    PAT_SMRY_FACT PSF ")
			.append(" left join     MSTR_CNSMR_MBR_MNTH_FACT MM ON  MM.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY  ")
			.append(" and   MM.RCRD_STTS_CD = 'ACT' ")
			.append(" where   PSF.ATRBN_STTS_CD = 'ACTIVE'    ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and psf.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and psf.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {

			query.append(" and psf.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");

		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and psf.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and psf.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}

		query.append(" ) as ILV on 1=1 ")
			 .append(" join   poit_user_scrty_acs pusa on (IPSMRY.prov_grp_id = pusa.prov_grp_id ")
			 .append(" and   case  when     pusa.prov_org_tax_id = '0'     ")
			 .append(" then     IPSMRY.prov_org_tax_id ")
			 .append(" else     pusa.prov_org_tax_id end = IPSMRY.prov_org_tax_id) ")
			 .append(" where   pusa.sesn_id = ? ")
			 .append(" and   pusa.enttlmnt_hash_key = ? ");

		if (null != request.getAppPrptyList()) {
			StringBuilder mtrc = new StringBuilder();

			for (AppProperty a : request.getAppPrptyList()) {
				StringBuilder temp = new StringBuilder();
				boolean suppressed = false;
				request.setTapId(a.getValue());
				if (StringUtil.isNotBlankOrFalse(a.getComment()) && Constants.COC_IP.equals(a.getComment())) {
					temp.append(" or   ");

					if (!StringUtil.isSuppressedTAPGRPsEmpty(request)
						&& (request.getSuppressionForKey(request.getTapId()).getSuppressedGRPs().size() - StringUtil.hasAllSuppression(request) > 0)) {
						if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) && !StringUtil.getUnsuppressedValuesForTapId(request, "GRP").equalsIgnoreCase("---")) {
							temp.append(" and IPSMRY.prov_grp_id in (" +
								StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ")
								.append(" and IPSMRY.pgm_dim_key in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProgramIds()) + ") ")
								.append(" and IPSMRY.lob_desc in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getLobIds()) + ") ");
						}
						else {
							suppressed = true;
							if (a.getComment().equalsIgnoreCase(Constants.COC_SOC))
								isSocSuppressed = true;
							a.setComment("");
						}
					}
					else if (!StringUtil.isSuppressedTAPMKTEmpty(request)) {
						if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "MKT")) && !StringUtil.getUnsuppressedValuesForTapId(request, "MKT").equalsIgnoreCase("---")) {
							temp.append(" and IPSMRY.prov_grp_id in (" +
								StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "MKT")) + ") ")
								.append(" and IPSMRY.pgm_dim_key in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProgramIds()) + ") ")
								.append(" and IPSMRY.lob_desc in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getLobIds()) + ") ");
						}
						else {
							suppressed = true;
							if (a.getComment().equalsIgnoreCase(Constants.COC_SOC))
								isSocSuppressed = true;
							a.setComment("");
						}
					}
					else if (!StringUtil.isSuppressedTAPPGMsEmpty(request)) {
						if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) && !StringUtil.getUnsuppressedValuesForTapId(request, "PGM").equalsIgnoreCase("---")) {
							temp.append(" and IPSMRY.prov_grp_id in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvGrpIds()) + ") ")
								.append(" and IPSMRY.pgm_dim_key in ("
									+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ")
								.append(" and IPSMRY.lob_desc in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getLobIds()) + ") ");
						}
						else {
							suppressed = true;
							if (a.getComment().equalsIgnoreCase(Constants.COC_SOC))
								isSocSuppressed = true;
							a.setComment("");
						}
					}
					else if (!StringUtil.isSuppressedTAPLOBsEmpty(request)) {
						if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) && !StringUtil.getUnsuppressedValuesForTapId(request, "GRP").equalsIgnoreCase("---")) {
							temp.append(" and IPSMRY.prov_grp_id in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvGrpIds()) + ") ")
								.append(" and IPSMRY.pgm_dim_key in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProgramIds()) + ") ")
								.append(" and IPSMRY.lob_desc in ("
									+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
						}
						else {
							suppressed = true;
							if (a.getComment().equalsIgnoreCase(Constants.COC_SOC))
								isSocSuppressed = true;
							a.setComment("");
						}
					}
					else if (!StringUtil.isSuppressedTAPALLEmpty(request)) {
						if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "ALL")) && !StringUtil.getUnsuppressedValuesForTapId(request, "GRP").equalsIgnoreCase("---")) {
							temp.append(" and IPSMRY.prov_grp_id in (" +
								StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "ALL")) + ") ")
								.append(" and IPSMRY.pgm_dim_key in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProgramIds()) + ") ")
								.append(" and IPSMRY.lob_desc in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getLobIds()) + ") ");
						}
						else {
							suppressed = true;
							if (a.getComment().equalsIgnoreCase(Constants.COC_SOC))
								isSocSuppressed = true;
							a.setComment("");
						}

					}
					else {
						if (StringUtil.isNotBlankOrFalse(request.getProvGrpIds())) {
							temp.append(" and IPSMRY.prov_grp_id in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvGrpIds()) + ") ");
						}
						if (StringUtil.isNotBlankOrFalse(request.getProgramIds())) {
							temp.append(" and IPSMRY.pgm_dim_key in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProgramIds()) + ") ");
						}
						if (StringUtil.isNotBlankOrFalse(request.getLobIds())) {
							temp.append(" and IPSMRY.lob_desc in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getLobIds()) + ") ");
						}
					}


					// Organization filter
					if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
						temp.append(" and IPSMRY.ip_dim_key in ("
							+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
					}

					if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
						temp.append(" and IPSMRY.prov_org_dim_key in ("
							+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
							+ ") ");
					}
					if (!suppressed) {
						mtrc.append(temp);
					}

				}
			}

			if (StringUtils.isNotEmpty(mtrc.toString())) {
				StringUtil.removeFirstOccurenceWithinString(mtrc, "or");
				query.append(mtrc);
			}
			else {
				return new ArrayList<CostOpportunityBean>();
			}
		}

		else {
			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
				query.append(" and SMRY.prov_grp_id in (" +
					StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
			}

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
				query.append(" and SMRY.pgm_dim_key in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
			}

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
				query.append(" and SMRY.lob_desc in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
			}

			// Organization filter
			if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
				query.append(" and SMRY.ip_dim_key in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
			}

			if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
				query.append(" and SMRY.prov_org_dim_key in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
					+ ") ");
			}
		}

		query.append(" group by  IPSMRY.SUB_MTRC_CD, IPSMRY.SUB_MTRC_NM,ILV.MEM_MNTH,ILV.totl_member) as A) as B) as C) ")// Added for PCMSP-19356
			.append(" group by MEM_MNTH, TOTL_MEMBER ) "); // Added for PCMSP-19356

		//Changes for PCMSP-17266 : Ends

		// <-- Changes for PCMSP-18556 - SOC summary view calculation begins-->
		if (!isSocSuppressed) {
			query.append(" UNION ( ")
				.append(" select  D.MTRC_CD, ")
				.append(" D.MTRC_NM,     ")
				.append(" D.TOTALOPPORTUNITYSOC AS SOC_TOTAL,  ")
				.append(" D.NON_PREF_SITE_CLMS_CNT as nonPrefSiteClmsCnt,  ")
				.append(" D.TOTAL_CLAIM_COUNT as totalClmsCnt,    ")
				.append(" 0.00 as ASC_TOTAL, 0.00 as COST_OPRTNTY_AMT,  ")
				.append(" 0.00 as COST_OPRTNTY_10_PCTAG_AMT,    ")
				.append(" D.BNCHMRK_PCTILE_90_NBR as BNCHMRK_PCTILE_90_NBR,  ")
				.append(" 0.00 as PRFRMN_RT_DNMNTR_NBR ,  ")
				.append(" 0.00 as PRFRMN_RT_NMRTR_NBR  ,   ")
				.append(" case when    D.BNCHMRK_PCTILE_90_NBR = " + masked + " then    'Y' else    'N' end as multiGroupScenario,  ")
				.append(" 0 as MBR_MNTH_CNT ,  ")
				.append(" D.MEM_MNTH as MEM_MNTH   ")
				.append(" , 0.00 as IP_PERF_RATE   ")
				.append(" from  (  ")
				.append(" select  'SOC' as MTRC_CD  , ")
				.append(" 'Specialty Rx Site of Care' as MTRC_NM,  ")
				.append(" MEM_MNTH,  ")
				.append(" BNCHMRK_PCTILE_90_NBR,   ")
				.append(" TOTALOPPORTUNITYSOC, ")
				.append(" C.NON_PREF_SITE_CLMS_CNT ,  ")
				.append(" C.TOTAL_CLAIM_COUNT  ")
				.append(" from  (   ")
				.append(" select  max(ILV.MEM_MNTH) as MEM_MNTH, ")
				.append(" max(CBD.BNCHMRK_PCTILE_90_NBR) as BNCHMRK_PCTILE_90_NBR,  	 ")
				.append(" sum(SOCSMRY.TOTL_CLMS_NBR) as TOTAL_CLAIM_COUNT,  ")
				.append(" sum(SOCSMRY.NON_PRFRD_SITE_CLMS_NBR) as NON_PREF_SITE_CLMS_CNT,  ")
				.append(" case when sum(nvl(COST_OPRTNTY_AMT,0))>0 then sum(nvl(COST_OPRTNTY_AMT,0)) else 0.00 end as TOTALOPPORTUNITYSOC	")
				.append(" FROM ")
				.append(" COC_SOC_PROV_DRUG_SMRY AS SOCSMRY ")

				.append(" join   (  ")
				.append(" select     nvl(SUM(MM.MBR_MNTH_12_CNT),0) as MEM_MNTH ")
				.append(" from    PAT_SMRY_FACT PSF ")
				.append(" inner join     MSTR_CNSMR_MBR_MNTH_FACT MM ON  MM.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY  ")
				.append(" and   MM.RCRD_STTS_CD = 'ACT' ")
				.append(" and   PSF.ATRBN_STTS_CD = 'ACTIVE'    ");

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
				query.append(" and psf.prov_grp_id in (" +
					StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
			}

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
				query.append(" and psf.pgm_dim_key in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
			}

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {

				query.append(" and psf.lob_desc in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");

			}

			if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
				query.append(" and psf.ip_dim_key in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
			}

			if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
				query.append(" and psf.prov_org_dim_key in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
					+ ") ");
			}

			query.append(" ) as ILV on 1=1 ")
				.append(" join   (  ")
				.append(" select distinct case when count(*) over (PARTITION BY COC_MTRC_CD)<= 1 then BNCHMRK_PCTILE_90_NBR else ")
				.append(masked)
				.append("   end as BNCHMRK_PCTILE_90_NBR ")
				.append(" from (select distinct BNCHMRK_PCTILE_90_NBR, COC_MTRC_CD ")
				.append(" from COC_BNCHMRK_DATA where COC_MTRC_CD =  'SOC' and SUB_MTRC_CD = 'SMRY' and RCRD_STTS_CD = 'ACT'  ")
				.append(" and BNCHMRK_IND_CD = 'R' ")
				.append(" and upper(trim(MRKT_ST_CD)) in ")
				.append(" (select distinct SUBSTR(PGM_ID,1,2) from PGM_DIM ");

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
				query.append(" where pgm_dim_key in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
			}

			query.append(" )) ) as CBD on 1=1 ")
				.append(" join   poit_user_scrty_acs pusa on (SOCSMRY.prov_grp_id = pusa.prov_grp_id ")
				.append(" and   case  when     pusa.prov_org_tax_id = '0'     ")
				.append(" then     SOCSMRY.prov_org_tax_id ")
				.append(" else     pusa.prov_org_tax_id end = SOCSMRY.prov_org_tax_id) ")
				.append(" where   pusa.sesn_id = ? ")
				.append(" and   pusa.enttlmnt_hash_key = ? ");

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
				query.append(" and SOCSMRY.prov_grp_id in (" +
					StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
			}

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
				query.append(" and SOCSMRY.pgm_dim_key in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
			}

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
				query.append(" and SOCSMRY.lob_desc in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
			}

			if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
				query.append(" and SOCSMRY.ip_dim_key in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
			}

			if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
				query.append(" and SOCSMRY.prov_org_dim_key in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
					+ ") ");
			}

			query.append(" ) C ) D )") ;				
		}
		// <--- Changes for PCMSP-18556 - SOC summary view calculation ENDS ---->
		query.append(" )  a ")
			.append(" group by a.MTRC_CD, a.MTRC_NM,a.multiGroupScenario,MEM_MNTH ) b ")
			.append(" ) c ")
			/*PCMSP-19357 CHANGE 2*/
			.append(" ) d ")
			.append(" where d.row_nbr between ? and ? ")
			.append(" order by d.row_nbr ")
			/*PCMSP-19357 CHANGE 2*/
			.append(" with ur ");

		try {
			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());
			request.setTapId(request.getMetricViewId());

			//PMPM Starts
			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
				String[] array = request.getProvDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, StringUtil.parseProviderId(item));
				}
			}

			if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
				String[] array = request.getOrgDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			//PMPM Ends	


			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
				String[] array = request.getProvDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, StringUtil.parseProviderId(item));
				}
			}

			if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
				String[] array = request.getOrgDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			ps.setString(++i, request.getSessionId());
			ps.setString(++i, request.getEntitlementId());


			if (null != request.getAppPrptyList()) {
				for (AppProperty a : request.getAppPrptyList()) {
					request.setTapId(a.getValue());
					if (StringUtil.isNotBlankOrFalse(a.getComment()) && !Constants.COC_IP.equals(a.getComment())) {
						ps.setString(++i, a.getComment());

						if (!StringUtil.isSuppressedTAPGRPsEmpty(request)
							&& (request.getSuppressionForKey(request.getTapId()).getSuppressedGRPs().size() - StringUtil.hasAllSuppression(request) > 0)) {
							if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
								String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
								array = request.getProgramIds().split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
								array = request.getLobIds().split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
							}
						}
						else if (!StringUtil.isSuppressedTAPMKTEmpty(request)) {
							if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "MKT"))) {
								String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "MKT").split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
								array = request.getProgramIds().split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
								array = request.getLobIds().split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
							}
						}
						else if (!StringUtil.isSuppressedTAPPGMsEmpty(request)) {
							if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
								String[] array = request.getProvGrpIds().split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
								array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
								array = request.getLobIds().split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
							}
						}
						else if (!StringUtil.isSuppressedTAPLOBsEmpty(request)) {
							if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
								String[] array = request.getProvGrpIds().split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
								array = request.getProgramIds().split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
								array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
							}
						}
						else if (!StringUtil.isSuppressedTAPALLEmpty(request)) {
							if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "ALL"))) {
								String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "ALL").split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
								array = request.getProgramIds().split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
								array = request.getLobIds().split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
							}
						}
						else {

							String[] array = request.getProvGrpIds().split(",");

							if (StringUtil.isNotBlankOrFalse(request.getProvGrpIds())) {
								for (String item : array) {
									ps.setString(++i, item);
								}
							}

							if (StringUtil.isNotBlankOrFalse(request.getProgramIds())) {
								array = request.getProgramIds().split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
							}

							if (StringUtil.isNotBlankOrFalse(request.getLobIds())) {
								array = request.getLobIds().split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
							}
						}

						// Organization filter
						if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
							String[] array = request.getProvDimKeys().split(",");
							for (String item : array) {
								ps.setString(++i, StringUtil.parseProviderId(item));
							}
						}
						if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
							String[] array = request.getOrgDimKeys().split(",");
							for (String item : array) {
								ps.setString(++i, item);
							}
						}
					}
				}
			}
			else {
				if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
					String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
					for (String item : array) {
						ps.setString(++i, item);
					}
				}

				if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
					String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
					for (String item : array) {
						ps.setString(++i, item);
					}
				}

				if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
					String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
					for (String item : array) {
						ps.setString(++i, item);
					}
				}

				if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
					String[] array = request.getProvDimKeys().split(",");
					for (String item : array) {
						ps.setString(++i, StringUtil.parseProviderId(item));
					}
				}

				if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
					String[] array = request.getOrgDimKeys().split(",");
					for (String item : array) {
						ps.setString(++i, item);
					}
				}
			}

			//PCMSP-17266 Starts
			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
				String[] array = request.getProvDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, StringUtil.parseProviderId(item));
				}
			}

			if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
				String[] array = request.getOrgDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}
			
			ps.setString(++i, request.getSessionId());
			ps.setString(++i, request.getEntitlementId());


			if (null != request.getAppPrptyList()) {
				for (AppProperty a : request.getAppPrptyList()) {
					request.setTapId(a.getValue());
					if (StringUtil.isNotBlankOrFalse(a.getComment()) && Constants.COC_IP.equals(a.getComment())) {

						if (!StringUtil.isSuppressedTAPGRPsEmpty(request)
							&& (request.getSuppressionForKey(request.getTapId()).getSuppressedGRPs().size() - StringUtil.hasAllSuppression(request) > 0)) {
							if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
								String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
								array = request.getProgramIds().split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
								array = request.getLobIds().split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
							}
						}
						else if (!StringUtil.isSuppressedTAPMKTEmpty(request)) {
							if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "MKT"))) {
								String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "MKT").split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
								array = request.getProgramIds().split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
								array = request.getLobIds().split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
							}
						}
						else if (!StringUtil.isSuppressedTAPPGMsEmpty(request)) {
							if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
								String[] array = request.getProvGrpIds().split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
								array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
								array = request.getLobIds().split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
							}
						}
						else if (!StringUtil.isSuppressedTAPLOBsEmpty(request)) {
							if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
								String[] array = request.getProvGrpIds().split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
								array = request.getProgramIds().split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
								array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
							}
						}
						else if (!StringUtil.isSuppressedTAPALLEmpty(request)) {
							if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "ALL"))) {
								String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "ALL").split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
								array = request.getProgramIds().split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
								array = request.getLobIds().split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
							}
						}
						else {

							String[] array = request.getProvGrpIds().split(",");

							if (StringUtil.isNotBlankOrFalse(request.getProvGrpIds())) {
								for (String item : array) {
									ps.setString(++i, item);
								}
							}

							if (StringUtil.isNotBlankOrFalse(request.getProgramIds())) {
								array = request.getProgramIds().split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
							}

							if (StringUtil.isNotBlankOrFalse(request.getLobIds())) {
								array = request.getLobIds().split(",");
								for (String item : array) {
									ps.setString(++i, item);
								}
							}
						}

						// Organization filter
						if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
							String[] array = request.getProvDimKeys().split(",");
							for (String item : array) {
								ps.setString(++i, StringUtil.parseProviderId(item));
							}
						}
						if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
							String[] array = request.getOrgDimKeys().split(",");
							for (String item : array) {
								ps.setString(++i, item);
							}
						}
					}
				}
			}
			else {
				if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
					String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
					for (String item : array) {
						ps.setString(++i, item);
					}
				}

				if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
					String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
					for (String item : array) {
						ps.setString(++i, item);
					}
				}

				if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
					String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
					for (String item : array) {
						ps.setString(++i, item);
					}
				}

				if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
					String[] array = request.getProvDimKeys().split(",");
					for (String item : array) {
						ps.setString(++i, StringUtil.parseProviderId(item));
					}
				}

				if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
					String[] array = request.getOrgDimKeys().split(",");
					for (String item : array) {
						ps.setString(++i, item);
					}
				}
			}

			// <-- PCMSP-18556 - SOC Changes begins-->
			if (!isSocSuppressed) {
				if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
					String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
					for (String item : array) {
						ps.setString(++i, item);
					}
				}

				if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
					String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
					for (String item : array) {
						ps.setString(++i, item);
					}
				}

				if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
					String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
					for (String item : array) {
						ps.setString(++i, item);
					}
				}

				if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
					String[] array = request.getProvDimKeys().split(",");
					for (String item : array) {
						ps.setString(++i, StringUtil.parseProviderId(item));
					}
				}

				if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
					String[] array = request.getOrgDimKeys().split(",");
					for (String item : array) {
						ps.setString(++i, item);
					}
				}

				if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
					String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
					for (String item : array) {
						ps.setString(++i, item);
					}
				}

				ps.setString(++i, request.getSessionId());
				ps.setString(++i, request.getEntitlementId());


				if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
					String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
					for (String item : array) {
						ps.setString(++i, item);
					}
				}

				if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
					String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
					for (String item : array) {
						ps.setString(++i, item);
					}
				}

				if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
					String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
					for (String item : array) {
						ps.setString(++i, item);
					}
				}

				if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
					String[] array = request.getProvDimKeys().split(",");
					for (String item : array) {
						ps.setString(++i, StringUtil.parseProviderId(item));
					}
				}

				if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
					String[] array = request.getOrgDimKeys().split(",");
					for (String item : array) {
						ps.setString(++i, item);
					}
				}
			}
			//<----PCMSP-18556 - SOC Changes END ---->

			//PCMSP-17266 Ends
			int start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
			int limit = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
			ps.setInt(++i, start + 1);
			ps.setInt(++i, start + limit);

			executeQuery(logger, query.toString());
			resultList = convertSelectedRowsToObjects(rs, request, exportFlag, minimumCriteriaMap);

		}
		catch (Exception e) {
			throw new Exception("Exception during CostOpportunitySummaryServiceImpl (" + request.toString() + ").", e);
		}
		finally {

			close();
		}

		return resultList;
	}



	private String buildSortClause(GetCostOpportunitySummaryRequest request) {
		StringBuilder query = new StringBuilder();
		String defaultSort = ", MTRC_NM asc ";

		if (null != request.getSort()) {
			for (QuerySort sort : request.getSort()) {

				String dir = sort.getDirection().replaceAll("\"", "");
				String property = sort.getProperty();

				if (property.equals("metricName")) {
					query.append("  MTRC_NM " + dir);
				}
				else if (property.equals("totalOpportunity")) {
					query.append(" COST_OPRTNTY_AMT " + dir + defaultSort);
				}
				else if (property.equals("tenPercentImprovement")) {
					query.append(" COST_OPRTNTY_10_PCTAG_AMT " + dir + defaultSort);
				}
				else if (property.equals("totalOpportunityPMPM")) {
					query.append(" PMPM_OPRTNTY_AMT " + dir + defaultSort);
				}
				else if (property.equals("tenPercentImprovementPMPM")) {
					query.append(" PMPM_OPRTNTY_10_PCTAG_AMT " + dir + defaultSort);
				}
				else if (property.equals("currentPerformanceRate")) {
					query.append(" CURR_PERF_RATE " + dir + defaultSort);
				}
				else if (property.equals("percentileBenchmark90")) {
					query.append(" BNCHMRK_90_PCTILE_AMT " + dir + defaultSort);
				}
				/*PCMSP-19357 CHANGE START 3*/
				else if (property.equals("actualBenchmarkRatio")) {
					query.append(" actualBenchmarkRatio " + dir + defaultSort);
				}
				/*PCMSP-19357 CHANGE ENDS 3*/
				else {
					query.append(" MTRC_NM asc ");
				}
			}
		}
		else {
			query.append(" MTRC_NM asc ");
		}
		return query.toString();
	}



	/**
	 * Convert resultset into object
	 * 
	 * @param rs
	 * @param request
	 * @return
	 * @throws Exception
	 */
	private List<CostOpportunityBean> convertSelectedRowsToObjects(
		ResultSet rs, GetCostOpportunitySummaryRequest request, boolean exportFlag, Map<String, Boolean> minimumCriteriaMap) throws Exception {

		List<CostOpportunityBean> results = new ArrayList<CostOpportunityBean>();
		BigDecimal perfRate = BigDecimal.ZERO;
		//PCMSP-6869 : Starts
		boolean displayDashesRx = minimumCriteriaMap.get("displayDashesRx");//PCMSP-15224
		boolean displayDashesLab = minimumCriteriaMap.get("displayDashesLab");
		boolean displayDashesAsc = minimumCriteriaMap.get("displayDashesAsc");
		boolean displayDashesSpl = minimumCriteriaMap.get("displayDashesSpl");
		boolean displayDashesEbc = minimumCriteriaMap.get("displayDashesEbc");
		boolean displayDashesipUtil = minimumCriteriaMap.get("displayDashesipUtil");
		//PCMSP-6869 : Ends
		boolean displayDashesSoc = minimumCriteriaMap.get("displayDashesSoc");
		boolean displayDashesNonPref = minimumCriteriaMap.get("displayDashesNonPref");


		if (exportFlag) {
			while (rs.next()) {
				CostOpportunityBean item = new CostOpportunityBean();

				if (rs.getString("display_ind") != null && rs.getString("display_ind").equals(Constants.N))
					displayDashIndicator = true;
				else
					displayDashIndicator = false;

				if (rs.getString("multiGroupScenario") != null && rs.getString("multiGroupScenario").equals(Constants.N))
					displayBenchMark = true;
				else
					displayBenchMark = false;


				if (rs.getString("MTRC_NM") != null) {
					item.setMetricName(rs.getString("MTRC_NM"));

					if (rs.getString("MTRC_CD").equalsIgnoreCase(Constants.COC_RX) && displayDashesRx) //PCMSP-15224
						displayDashIndicator = true;

					//Added for PCMSP-6866 : Starts
					if (rs.getString("MTRC_NM").equalsIgnoreCase(Constants.LAB_SITE_SRVC) && displayDashesLab)
						displayDashIndicator = true;
					//Added for PCMSP-6866 : Ends

					if (rs.getString("MTRC_CD").equalsIgnoreCase(Constants.COC_ASC) && displayDashesAsc) //PCMSP-8684
						displayDashIndicator = true;

					if (rs.getString("MTRC_CD").equalsIgnoreCase(Constants.COC_SPL) && displayDashesSpl) //PCMSP-11099
						displayDashIndicator = true;

					if (rs.getString("MTRC_CD").equalsIgnoreCase(Constants.COC_EBC) && displayDashesEbc) //PCMSP-6868
						displayDashIndicator = true;

					if (rs.getString("MTRC_CD").equalsIgnoreCase(Constants.COC_IP) && displayDashesipUtil) //PCMSP-6869
						displayDashIndicator = true;

					if (rs.getString("MTRC_CD").equalsIgnoreCase(Constants.COC_SOC) && displayDashesSoc) //PCMSP-18550
						displayDashIndicator = true;
					if (rs.getString("MTRC_CD").equalsIgnoreCase(Constants.COC_SOC) && displayDashesNonPref)
						displayDashesNonPrefInd = true;
					else
						displayDashesNonPrefInd = false;

				}
				
					if (rs.getBigDecimal("COST_OPRTNTY_AMT") != null) {
						item.setTotalOpportunity((displayDashIndicator || displayDashesNonPrefInd) ? Constants.DASHES
								: StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("COST_OPRTNTY_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
						
					}
					if (rs.getBigDecimal("COST_OPRTNTY_10_PCTAG_AMT") != null) {
						item.setTenPercentImprovement((displayDashIndicator || displayDashesNonPrefInd) ? Constants.DASHES : StringUtil.convertStringToDecimalCurrency(
								rs.getBigDecimal("COST_OPRTNTY_10_PCTAG_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString()));					
					}
					if (rs.getBigDecimal("PMPM_OPRTNTY_AMT") != null) {
						item.setTotalOpportunityPMPM((displayDashIndicator || displayDashesNonPrefInd) ? Constants.DASHES
								: StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("PMPM_OPRTNTY_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
						}
					if (rs.getBigDecimal("PMPM_OPRTNTY_10_PCTAG_AMT") != null) {
						item.setTenPercentImprovementPMPM((displayDashIndicator || displayDashesNonPrefInd) ? Constants.DASHES : StringUtil.convertStringToDecimalCurrency(
								rs.getBigDecimal("PMPM_OPRTNTY_10_PCTAG_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
						}
				
				/*if (rs.getBigDecimal("PRFRMN_RT_NMRTR_NBR") != null && rs.getBigDecimal("PRFRMN_RT_DNMNTR_NBR") != null) {
					perfRate = rs.getBigDecimal("PRFRMN_RT_NMRTR_NBR").divide(rs.getBigDecimal("PRFRMN_RT_DNMNTR_NBR"), 2, BigDecimal.ROUND_HALF_UP);*/
				if (rs.getBigDecimal("CURR_PERF_RATE") != null) {
					perfRate = rs.getBigDecimal("CURR_PERF_RATE");
					if (rs.getString("MTRC_NM") != null && (Constants.AVG_COST_PER_RX).equalsIgnoreCase(rs.getString("MTRC_NM"))) {
						item.setCurrentPerformanceRate(
							displayDashIndicator ? Constants.DASHES : StringUtil.convertStringToDecimalCurrency(perfRate.setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
					}
					else if (rs.getString("MTRC_CD") != null
						&& ((Constants.COC_ASC).equalsIgnoreCase(rs.getString("MTRC_CD")) || (Constants.COC_SPL).equalsIgnoreCase(rs.getString("MTRC_CD"))
							|| (Constants.COC_LAB).equalsIgnoreCase(rs.getString("MTRC_CD")))) {//PCMSP-10329, PCMSP-12412, PCMSP-18694
						item.setCurrentPerformanceRate(
							displayDashIndicator ? Constants.DASHES
								: StringUtil.convertStringToCommaBigDecimal(perfRate.setScale(2, BigDecimal.ROUND_HALF_UP).toString(), 2).concat("%"));
					}
					else if (rs.getString("MTRC_CD") != null && ((Constants.COC_SOC).equalsIgnoreCase(rs.getString("MTRC_CD")))) {
						/*if (rs.getBigDecimal("TOTALCLMSCNT") != null && rs.getInt("TOTALCLMSCNT") <= 0) {
							item.setCurrentPerformanceRate(Constants.DASHES);
						}
						else {*/
							item.setCurrentPerformanceRate(
								displayDashIndicator ? Constants.DASHES
									: StringUtil.convertStringToCommaBigDecimal(perfRate.setScale(2, BigDecimal.ROUND_HALF_UP).toString(), 2).concat("%"));
						//}
					}
					else {
						item.setCurrentPerformanceRate(
							displayDashIndicator ? Constants.DASHES : StringUtil.convertStringToCommaBigDecimal(perfRate.setScale(2, BigDecimal.ROUND_HALF_UP).toString(), 2));
					}
				}
				if (rs.getBigDecimal("BNCHMRK_90_PCTILE_AMT") != null) {

					if (BigDecimal.ZERO.compareTo(rs.getBigDecimal("BNCHMRK_90_PCTILE_AMT")) <= 0) {//Production Defect - PCMSP-19226

						if (rs.getString("MTRC_NM") != null && ((Constants.AVG_COST_PER_RX).equalsIgnoreCase(rs.getString("MTRC_NM")) || 
																(Constants.COC_EBC.equalsIgnoreCase(rs.getString("MTRC_CD"))))) { /** US-21592 - EBC 90th % */
							item.setPercentileBenchmark90((displayDashIndicator || !displayBenchMark) ? Constants.DASHES
								: StringUtil.convertStringToCommaBigDecimal(rs.getBigDecimal("BNCHMRK_90_PCTILE_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString(),2));
						}
						/**US-21592 - added the logic for EBC 90th % in above case.*/
//						else if (rs.getString("MTRC_CD") != null
//							&& (Constants.COC_EBC.equalsIgnoreCase(rs.getString("MTRC_CD")))) { //PCMSP-18609
//							item.setPercentileBenchmark90(Constants.DASHES);
//						}
						else if (rs.getString("MTRC_CD") != null
							&& ((Constants.COC_ASC).equalsIgnoreCase(rs.getString("MTRC_CD")) || (Constants.COC_SPL).equalsIgnoreCase(rs.getString("MTRC_CD"))

								|| (Constants.COC_LAB).equalsIgnoreCase(rs.getString("MTRC_CD")) || (Constants.COC_SOC).equalsIgnoreCase(rs.getString("MTRC_CD")))) {//PCMSP-10329, PCMSP-12412, PCMSP-18694
							item.setPercentileBenchmark90((displayDashIndicator || !displayBenchMark) ? Constants.DASHES
								: StringUtil.convertStringToCommaBigDecimal(rs.getBigDecimal("BNCHMRK_90_PCTILE_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString(), 2)
									.concat("%"));

						}
						else {
							item.setPercentileBenchmark90((displayDashIndicator || !displayBenchMark) ? Constants.DASHES
								: StringUtil.convertStringToCommaBigDecimal(rs.getBigDecimal("BNCHMRK_90_PCTILE_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString(), 2));
						}

					}
					else {
						item.setPercentileBenchmark90(Constants.DASHES);
					}

				}
				
				/*PCMSP-19357 CHANGE START 4*/
				if (rs.getBigDecimal("actualBenchmarkRatio") != null &&  null!= rs.getString("isBenchmark0") &&   rs.getString("isBenchmark0").equals(Constants.N)) {
					item.setActualBenchmarkRatio((!displayBenchMark || displayDashIndicator) ? Constants.DASHES
							: StringUtil.convertStringToCommaBigDecimal(rs.getBigDecimal("actualBenchmarkRatio").setScale(2, BigDecimal.ROUND_HALF_UP).toString(), 2));
				}else{
					item.setActualBenchmarkRatio(Constants.DASHES);
				}
				/*PCMSP-19357 CHANGE ENDS 4*/
				/*//PCMSP-21260 EXPORT If CurrentPerformanceRate OR 90thPercentileBenchmark equals null or --- then TotalOpportunity will be displayed --- in UI and Export
				
				if (item.getCurrentPerformanceRate()==null 
						|| item.getPercentileBenchmark90()==null
						|| item.getCurrentPerformanceRate().equalsIgnoreCase(Constants.DASHES) 
						|| item.getPercentileBenchmark90().equalsIgnoreCase(Constants.DASHES)){
					item.setTotalOpportunity(Constants.DASHES);
					item.setTenPercentImprovement(Constants.DASHES);
					item.setTotalOpportunityPMPM(Constants.DASHES);
					item.setTenPercentImprovementPMPM(Constants.DASHES);
					item.setCurrentPerformanceRate(Constants.DASHES);
					item.setPercentileBenchmark90(Constants.DASHES);
					item.setActualBenchmarkRatio(Constants.DASHES);
				}
				
			//PCMSP-21260 EXPORT If CurrentPerformanceRate OR 90thPercentileBenchmark equals 0.00 then TotalOpportunity will be displayed 0.00 in UI and Export
				else if(item.getCurrentPerformanceRate().equalsIgnoreCase("0.00") || item.getPercentileBenchmark90().equalsIgnoreCase("0.00")){
						item.setTotalOpportunity(StringUtil.convertStringToDecimalCurrency(Constants.DOUBLE_SCALE_ZERO));
						item.setTenPercentImprovement(StringUtil.convertStringToDecimalCurrency(Constants.DOUBLE_SCALE_ZERO));
						item.setTotalOpportunityPMPM(StringUtil.convertStringToDecimalCurrency(Constants.DOUBLE_SCALE_ZERO));
						item.setTenPercentImprovementPMPM(StringUtil.convertStringToDecimalCurrency(Constants.DOUBLE_SCALE_ZERO));
						item.setCurrentPerformanceRate(Constants.DOUBLE_SCALE_ZERO);
						item.setPercentileBenchmark90(Constants.DOUBLE_SCALE_ZERO);
						item.setActualBenchmarkRatio(Constants.DOUBLE_SCALE_ZERO);
					}	
				
			//PCMSP-21260 EXPORT If CurrentPerformanceRate is less than to 90thPercentileBenchmark and actualBenchmarkratio not equal to 1 then TotalOpportunity will be displayed 0.00 in UI and Export
				else if ((item.getCurrentPerformanceRate() !=null && item.getPercentileBenchmark90() !=null && rs.getBigDecimal("CURR_PERF_RATE").compareTo(rs.getBigDecimal("BNCHMRK_90_PCTILE_AMT")) < 0 && !item.getActualBenchmarkRatio().equalsIgnoreCase("1.00"))){
					item.setTotalOpportunity(StringUtil.convertStringToDecimalCurrency(Constants.DOUBLE_SCALE_ZERO));
					item.setTenPercentImprovement(StringUtil.convertStringToDecimalCurrency(Constants.DOUBLE_SCALE_ZERO));
					item.setTotalOpportunityPMPM(StringUtil.convertStringToDecimalCurrency(Constants.DOUBLE_SCALE_ZERO));
					item.setTenPercentImprovementPMPM(StringUtil.convertStringToDecimalCurrency(Constants.DOUBLE_SCALE_ZERO));
				}
					
			//PCMSP-21260 EXPORT If CurrentPerformanceRate is greater than 90thPercentileBenchmark then calculated TotalOpportunity will be displayed  in UI and Export	
*/
				results.add(item);
			}
		}
		else {
			while (rs.next()) {
				CostOpportunityBean item = new CostOpportunityBean();

				if (rs.getString("display_ind") != null && rs.getString("display_ind").equals(Constants.N))
					displayDashIndicator = true;
				else
					displayDashIndicator = false;

				if (rs.getString("multiGroupScenario") != null && rs.getString("multiGroupScenario").equals(Constants.N))
					displayBenchMark = true;
				else
					displayBenchMark = false;

				if (rs.getString("MTRC_NM") != null) {
					item.setMetricName(rs.getString("MTRC_NM"));
					//Added for PCMSP-6866 : Starts
					if (rs.getString("MTRC_NM").equalsIgnoreCase(Constants.LAB_SITE_SRVC) && displayDashesLab)
						displayDashIndicator = true;
					//Added for PCMSP-6866 : Ends

					if (rs.getString("MTRC_CD").equalsIgnoreCase(Constants.COC_ASC) && displayDashesAsc) //PCMSP-8684
						displayDashIndicator = true;

					if (rs.getString("MTRC_CD").equalsIgnoreCase(Constants.COC_SPL) && displayDashesSpl) //PCMSP-11099
						displayDashIndicator = true;

					if (rs.getString("MTRC_CD").equalsIgnoreCase(Constants.COC_EBC) && displayDashesEbc) //PCMSP-6868
						displayDashIndicator = true;

					if (rs.getString("MTRC_CD").equalsIgnoreCase(Constants.COC_IP) && displayDashesipUtil) //PCMSP-6869
						displayDashIndicator = true;

					if (rs.getString("MTRC_CD").equalsIgnoreCase(Constants.COC_SOC) && displayDashesSoc) //PCMSP-18550
						displayDashIndicator = true;
					if (rs.getString("MTRC_CD").equalsIgnoreCase(Constants.COC_SOC) && displayDashesNonPref)
						displayDashesNonPrefInd = true;
					else
						displayDashesNonPrefInd = false;

				}
				
				
					if (rs.getBigDecimal("COST_OPRTNTY_AMT") != null) {
						
						item.setTotalOpportunity((displayDashIndicator || displayDashesNonPrefInd) ? Constants.DASHES : rs.getBigDecimal("COST_OPRTNTY_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
					
					}
					if (rs.getBigDecimal("COST_OPRTNTY_10_PCTAG_AMT") != null) {
						
							item.setTenPercentImprovement(
								(displayDashIndicator || displayDashesNonPrefInd) ? Constants.DASHES : rs.getBigDecimal("COST_OPRTNTY_10_PCTAG_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
						
					}
					if (rs.getBigDecimal("PMPM_OPRTNTY_AMT") != null) {
						item.setTotalOpportunityPMPM(
							(displayDashIndicator || displayDashesNonPrefInd) ? Constants.DASHES : rs.getBigDecimal("PMPM_OPRTNTY_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
						
					}
					if (rs.getBigDecimal("PMPM_OPRTNTY_10_PCTAG_AMT") != null) {					
							item.setTenPercentImprovementPMPM(
								(displayDashIndicator || displayDashesNonPrefInd) ? Constants.DASHES : rs.getBigDecimal("PMPM_OPRTNTY_10_PCTAG_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
						
					}
				
				/*if (rs.getBigDecimal("PRFRMN_RT_NMRTR_NBR") != null && rs.getBigDecimal("PRFRMN_RT_DNMNTR_NBR") != null) {
					perfRate = rs.getBigDecimal("PRFRMN_RT_NMRTR_NBR").divide(rs.getBigDecimal("PRFRMN_RT_DNMNTR_NBR"), 2, BigDecimal.ROUND_HALF_UP);*/
				if (rs.getBigDecimal("CURR_PERF_RATE") != null) {
					perfRate = rs.getBigDecimal("CURR_PERF_RATE");

					if (rs.getString("MTRC_CD") != null && ((Constants.COC_SOC).equalsIgnoreCase(rs.getString("MTRC_CD")))) {
						/*if (rs.getBigDecimal("TOTALCLMSCNT") != null && rs.getInt("TOTALCLMSCNT") <= 0) {
							item.setCurrentPerformanceRate(Constants.DASHES);
						}
						else {*/
							item.setCurrentPerformanceRate(displayDashIndicator ? Constants.DASHES : perfRate.setScale(2, BigDecimal.ROUND_HALF_UP).toString());
						//}
					}
					else {
						item.setCurrentPerformanceRate(displayDashIndicator ? Constants.DASHES : perfRate.setScale(2, BigDecimal.ROUND_HALF_UP).toString());
					}
				}
				if (rs.getBigDecimal("BNCHMRK_90_PCTILE_AMT") != null) {
					if (BigDecimal.ZERO.compareTo(rs.getBigDecimal("BNCHMRK_90_PCTILE_AMT")) <= 0) {//Production Defect - PCMSP-19226
//						if (rs.getString("MTRC_CD") != null
//							&& ( Constants.COC_EBC.equalsIgnoreCase(rs.getString("MTRC_CD")))) { //PCMSP-18609
//
//							item.setPercentileBenchmark90(Constants.DASHES);
//						}
//						else {
							item.setPercentileBenchmark90((displayDashIndicator || !displayBenchMark) ? Constants.DASHES
								: rs.getBigDecimal("BNCHMRK_90_PCTILE_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
//						}

					}
					else {

						item.setPercentileBenchmark90(Constants.DASHES);
					}
				}
				/*PCMSP-19357 CHANGE 5 STARTS*/
				if (rs.getBigDecimal("actualBenchmarkRatio") != null &&  null!= rs.getString("isBenchmark0") &&   rs.getString("isBenchmark0").equals(Constants.N)) {
					item.setActualBenchmarkRatio((!displayBenchMark || displayDashIndicator) ? Constants.DASHES
							: rs.getBigDecimal("actualBenchmarkRatio").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
				
				}else{
					item.setActualBenchmarkRatio(Constants.DASHES);
				}
				/*PCMSP-19357 CHANGE 5 ENDS*/
			/*//PCMSP-21260 UI If CurrentPerformanceRate OR 90thPercentileBenchmark equals null or --- then TotalOpportunity will be displayed --- in UI and Export
				
				if (item.getCurrentPerformanceRate()==null 
						|| item.getPercentileBenchmark90()==null
						|| item.getCurrentPerformanceRate().equalsIgnoreCase(Constants.DASHES) 
						|| item.getPercentileBenchmark90().equalsIgnoreCase(Constants.DASHES)){
					item.setTotalOpportunity(Constants.DASHES);
					item.setTenPercentImprovement(Constants.DASHES);
					item.setTotalOpportunityPMPM(Constants.DASHES);
					item.setTenPercentImprovementPMPM(Constants.DASHES);
					item.setCurrentPerformanceRate(Constants.DASHES);
					item.setPercentileBenchmark90(Constants.DASHES);
					item.setActualBenchmarkRatio(Constants.DASHES);
				}
			//PCMSP-21260 UI If CurrentPerformanceRate OR 90thPercentileBenchmark equals 0.00 then TotalOpportunity will be displayed 0.00 in UI and Export
				else if(item.getCurrentPerformanceRate().equalsIgnoreCase("0.00") || item.getPercentileBenchmark90().equalsIgnoreCase("0.00")){
						item.setTotalOpportunity(Constants.DOUBLE_SCALE_ZERO);
						item.setTenPercentImprovement(Constants.DOUBLE_SCALE_ZERO);
						item.setTotalOpportunityPMPM(Constants.DOUBLE_SCALE_ZERO);
						item.setTenPercentImprovementPMPM(Constants.DOUBLE_SCALE_ZERO);
						item.setCurrentPerformanceRate(Constants.DOUBLE_SCALE_ZERO);
						item.setPercentileBenchmark90(Constants.DOUBLE_SCALE_ZERO);
						item.setActualBenchmarkRatio(Constants.DOUBLE_SCALE_ZERO);
					}	
			//PCMSP-21260 UI If CurrentPerformanceRate is less than to 90thPercentileBenchmark and actualBenchmarkratio not equal to 1 then TotalOpportunity will be displayed 0.00 in UI and Export
				else if ((item.getCurrentPerformanceRate() !=null && item.getPercentileBenchmark90() !=null && rs.getBigDecimal("CURR_PERF_RATE").compareTo(rs.getBigDecimal("BNCHMRK_90_PCTILE_AMT")) < 0 && !item.getActualBenchmarkRatio().equalsIgnoreCase("1.00"))){
					item.setTotalOpportunity(Constants.DOUBLE_SCALE_ZERO);
					item.setTenPercentImprovement(Constants.DOUBLE_SCALE_ZERO);
					item.setTotalOpportunityPMPM(Constants.DOUBLE_SCALE_ZERO);
					item.setTenPercentImprovementPMPM(Constants.DOUBLE_SCALE_ZERO);
				}
					
			//PCMSP-21260 UI If CurrentPerformanceRate is greater than 90thPercentileBenchmark then calculated TotalOpportunity will be displayed  in UI and Export	
*/
				if (rs.getString("MTRC_NM") != null && (Constants.AVG_COST_PER_RX).equalsIgnoreCase(rs.getString("MTRC_NM"))) {
					item.setDataFormat(Constants.DATA_FORMAT_FOR_RX);
				}
				else if (rs.getString("MTRC_CD").equalsIgnoreCase(Constants.COC_ASC) || rs.getString("MTRC_CD").equalsIgnoreCase(Constants.COC_SPL)

					|| rs.getString("MTRC_NM").equalsIgnoreCase(Constants.LAB_SITE_SRVC) || rs.getString("MTRC_CD").equalsIgnoreCase(Constants.COC_SOC)) {//PCMSP-10329, PCMSP-18541

					item.setDataFormat(Constants.DATA_FORMAT_FOR_ASC_PERF_RATE);
				}
				else {
					item.setDataFormat(Constants.DATA_FORMAT);
				}

				results.add(item);
			}

		}

		return results;
	}

}
