package com.wellpoint.pc2dash.action.utilization;

import com.wellpoint.pc2dash.action.drilldown.GetDrillDownRequest;

public class GetPrescribingPhysicianRequest extends GetDrillDownRequest {

}
