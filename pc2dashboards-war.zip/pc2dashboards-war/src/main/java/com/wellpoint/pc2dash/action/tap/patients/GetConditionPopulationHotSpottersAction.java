package com.wellpoint.pc2dash.action.tap.patients;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.tap.patients.HotSpottersChartBean;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.service.tap.patients.ConditionPopulationHotSpottersServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetConditionPopulationHotSpottersAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetConditionPopulationHotSpottersRequest request = (GetConditionPopulationHotSpottersRequest) actionRequest;
		GetConditionPopulationHotSpottersResponse response = new GetConditionPopulationHotSpottersResponse();
		ErrorProperties err = ErrorProperties.getInstance();

		ConditionPopulationHotSpottersServiceImpl service = new ConditionPopulationHotSpottersServiceImpl();
		List<String> grps = null;

		try {

			removeLobPgmPrefixes(request);
			prepareChronicCareGapMap(request);

			// Kill switch check on Provider groups
			if (StringUtils.isNotBlank(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			prepareRASuppressionCond(request);
			prepareLPRSuppressionCond(request);

			// Clinical access check on provider groups
			if (null != grps && !grps.isEmpty()) {

				request.setProvGrpIdsWithoutClinicalCheck(StringUtils.join(grps, ','));
				grps = filterProvGrpsByClinicalInd(request, grps);
				request.setProvGrpIds(StringUtils.join(grps, ','));
			}

			/*
			 * Need to populate HCC/Total Cost suppression values for the chart, so the chart/grid
			 * queries can be kept in sync.
			 */
			CommonQueries cq = new CommonQueries();
			request.setGroupsWithActionCenterSuppressed(cq.getGroupsWithComponentSuppressed(request, Constants.AC_RF_CARDCONTAINER));
			request.setSuppression(cq.getActiveSuppressionForSelectComponents(request));
			request.setUnsuppressedLOBsTotalCost(getLOBsWithoutTotalCostSuppressed(request));

			if (null != grps && !grps.isEmpty()) {

				if (StringUtil.isExportDest(request.getDest())) {

					//					List<ExportGridColumn> columns = service.buildExportGridColumns(request);
					//					AttributedPatientExport exp = new AttributedPatientExport(request, columns);
					//
					//					ExportProcessor.getInstance().submit(exp);
				}
				else {

					List<HotSpottersChartBean> results = service.getTAPReportData(request);

					if (null != results && !results.isEmpty()) {

						response.setData(results);
						response.setMessage(err.getProperty("successful"));
						response.setTotal(1);
					}
					else {

						response.setMessage(err.getProperty("successNoData"));
					}
				}
			}

			response.setSuccess(true);
			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}
}
