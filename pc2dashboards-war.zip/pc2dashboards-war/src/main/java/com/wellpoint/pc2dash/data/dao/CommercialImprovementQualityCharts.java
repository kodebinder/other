package com.wellpoint.pc2dash.data.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.quality.GetQualityChartRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.drillDown.DrillDownChart;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QueryConstants;
import com.wellpoint.pc2dash.util.StringUtil;

public class CommercialImprovementQualityCharts extends GeneralCharts {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(CommercialImprovementQualityCharts.class);

	public List<DrillDownChart> getCommercialImprovementQualityChart(GetQualityChartRequest request) throws Exception {

		List<DrillDownChart> result = new ArrayList<DrillDownChart>();
		String sql = buildSql(request);

		try {
			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			buildPreparedStatement(request, sql);
			executeQuery(logger, sql);
			result = convertSelectedRowsToObjects(rs);

		}
		catch (Exception e) {
			throw new Exception("Exception during getCommercialImprovementQualityChart (" + request.toString() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}

	protected String buildSql(GetQualityChartRequest request) {
		String countWhereClause = "";

		StringBuilder sql = new StringBuilder()
			.append("select DISTINCT "
				+ "MD_IMP.MSR_ID, "
				+ "SMHD.SUB_CMPST_NM, "
				+ "SMHD.SUB_CMPST_DEFN_ID, "
				+ "MD_IMP.MSR_DSPLY_NM, "
				+ "cfq.MSR_NON_CMPLNT, "
				+ "cfq.MSR_CMPLNT ");

		// add to from and where clauses as necessary (adding some by default, since they're very likely to be required)

		StringBuilder from = new StringBuilder(" from scrcrd_pgm_msr_hrchy_fact spmhf ");
		from.append("join SCRCRD_MSR_HRCHY_DIM AS SMHD ON (spmhf.SCRCRD_MSR_HRCHY_DIM_KEY = SMHD.SCRCRD_MSR_HRCHY_DIM_KEY) ");
		from.append("join MSR_DIM AS MD_IMP ON (SMHD.MSR_DIM_KEY = MD_IMP.MSR_DIM_KEY)  ");
		from.append("join PGM_DIM AS PD ON (spmhf.PGM_DIM_KEY = PD.PGM_DIM_KEY) ");

		StringBuilder leftJoin = new StringBuilder(" left join ");

		StringBuilder innerSelect = new StringBuilder("(Select "
			+ buildSharedSelectGroupByColumns(request)
			+ ", COUNT(CASE WHEN CF.MSR_NMRTR_NBR = 0 THEN CF.MSTR_CNSMR_DIM_KEY END) AS MSR_NON_CMPLNT,"
			+ "COUNT(CASE WHEN CF.MSR_NMRTR_NBR = 1 THEN CF.MSTR_CNSMR_DIM_KEY END) AS MSR_CMPLNT, "
			+ "  count(CF.MSTR_CNSMR_DIM_KEY) as ELIGIBLE_CNT ");

		StringBuilder innerFrom = new StringBuilder(" from CMPLNC_FACT AS CF ");
		//because of UAT issue changed from MSTR_CNSMR_FACT to PAT_SMRY_FACT (since we are using pat_smry in the quality patients query and both will be in sync)
		innerFrom
			.append(
				"join PAT_SMRY_FACT AS PSF ON (CF.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY AND CF.PROV_GRP_DIM_KEY = PSF.PROV_GRP_DIM_KEY AND CF.PGM_DIM_KEY = PSF.PGM_DIM_KEY AND PSF.ATRBN_STTS_CD = 'ACTIVE' ) ");
		innerFrom.append("join PGM_DIM AS PD ON (CF.PGM_DIM_KEY = PD.PGM_DIM_KEY and PD.PGM_ID = ?) ");
		innerFrom.append("join prov_org_dim pod on (cf.prov_org_dim_key = pod.prov_org_dim_key) "); // added for POIT join
		innerFrom.append("join IP_DIM AS IPD ON (CF.IP_DIM_KEY = IPD.IP_DIM_KEY) ");
		innerFrom.append("join PROV_GRP_DIM AS PGD ON (CF.PROV_GRP_DIM_KEY = PGD.PROV_GRP_DIM_KEY and PGD.PROV_GRP_ID = ?) ");
		/**
		 * Changed the alias from which CARE_OPRTNTY_MSR_DIM_KEY is getting picked | IMPRV -> QLTY
		 * Based on suggestions by Data team, dated 12-May-16 to fix defect WLPRD02576052
		 * Release 1.9 <DF WLPRD02576052> <AD12140> | START
		 */
		innerFrom
			.append(
				"JOIN (SELECT QLTY.MSR_DIM_KEY, IMPRV.MSR_ID, QLTY.CARE_OPRTNTY_MSR_DIM_KEY, QLTY.SCRCRD_MSR_HRCHY_DIM_KEY,IMPRV.CMPST_DEFN_ID, QLTY.MSRMNT_PRD_STRT_DT, IMPRV.PGM_DIM_KEY  "
					/**
					 * Picking up CARE_OPRTNTY_MSR_DIM_KEY from QLTY
					 * Based on suggestions by Data team, dated 12-May-16 to fix defect WLPRD02576052
					 * Release 1.9 <DF WLPRD02576052> <AD12140> | END
					 */
					+ " FROM (SELECT A.MSR_DIM_KEY, A.MSR_ID, A.CARE_OPRTNTY_MSR_DIM_KEY, A.RULE_ID, C.PGM_DIM_KEY, C.MSRMNT_PRD_STRT_DT,B.SCRCRD_DEFN_ID, C.SCRCRD_MSR_HRCHY_DIM_KEY "
					+ " FROM MSR_DIM AS A JOIN SCRCRD_MSR_HRCHY_DIM AS B ON A.MSR_DIM_KEY = B.MSR_DIM_KEY AND A.MSR_TYPE_CD = 'RHI' INNER JOIN SCRCRD_PGM_MSR_HRCHY_FACT AS C ON B.SCRCRD_MSR_HRCHY_DIM_KEY = C.SCRCRD_MSR_HRCHY_DIM_KEY "
					+ "  AND B.CMPST_TYPE_DESC = 'Quality' WHERE C.MNTH_ID = (SELECT MAX(IPGSF.MNTH_ID) FROM IMPRV_PROV_GRP_SMRY_FACT IPGSF INNER JOIN "
					+ " (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT FROM SCRCRD_PGM_MSR_HRCHY_FACT WHERE  "
					+ " PGM_DIM_KEY=(SELECT PGM_DIM_KEY FROM PGM_DIM WHERE PGM_ID=?) ");
		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {

			innerFrom.append(" and MSRMNT_PRD_STRT_DT=? ");
		}

		innerFrom
			.append(" GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM "
				+ " ON IPGSF.PGM_DIM_KEY=SC_PGM.PGM_DIM_KEY AND IPGSF.MSRMNT_PRD_STRT_DT=SC_PGM.MSRMNT_PRD_STRT_DT) "
				/**
				 * Picking up CARE_OPRTNTY_MSR_DIM_KEY from QLTY, thus adding it in group by
				 * Based on suggestions by Data team, dated 12-May-16 to fix defect WLPRD02576052
				 * Release 1.9 <DF WLPRD02576052> <AD12140>
				 */
				+ "  GROUP BY A.MSR_DIM_KEY, A.MSR_ID, A.CARE_OPRTNTY_MSR_DIM_KEY, A.RULE_ID,C.PGM_DIM_KEY, C.MSRMNT_PRD_STRT_DT, B.SCRCRD_DEFN_ID,C.SCRCRD_MSR_HRCHY_DIM_KEY) AS QLTY "
				+ "  INNER JOIN (SELECT A.MSR_DIM_KEY, A.CARE_OPRTNTY_MSR_DIM_KEY, A.MSR_ID, A.RULE_ID,B.CMPST_DEFN_ID, C.PGM_DIM_KEY, C.MSRMNT_PRD_STRT_DT,B.SCRCRD_DEFN_ID, C.SCRCRD_MSR_HRCHY_DIM_KEY "
				+ "   FROM MSR_DIM AS A JOIN SCRCRD_MSR_HRCHY_DIM AS B ON A.MSR_DIM_KEY = B.MSR_DIM_KEY AND A.MSR_TYPE_CD = 'RHI' INNER JOIN SCRCRD_PGM_MSR_HRCHY_FACT AS C ON B.SCRCRD_MSR_HRCHY_DIM_KEY = C.SCRCRD_MSR_HRCHY_DIM_KEY "
				+ " AND B.CMPST_TYPE_DESC = 'Improvement' INNER JOIN PGM_DIM AS PGM ON C.PGM_DIM_KEY = PGM.PGM_DIM_KEY WHERE B.CMPST_DEFN_ID = ? AND PGM.PGM_ID = ? "
				+ " AND C.MNTH_ID = (SELECT MAX(IPGSF.MNTH_ID) FROM IMPRV_PROV_GRP_SMRY_FACT IPGSF INNER JOIN "
				+ " (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT FROM SCRCRD_PGM_MSR_HRCHY_FACT WHERE  "
				+ " PGM_DIM_KEY=(SELECT PGM_DIM_KEY FROM PGM_DIM WHERE PGM_ID=?) ");
		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {

			innerFrom.append(" and MSRMNT_PRD_STRT_DT=? ");
		}

		innerFrom
			.append(" GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM "
				+ " ON IPGSF.PGM_DIM_KEY=SC_PGM.PGM_DIM_KEY AND IPGSF.MSRMNT_PRD_STRT_DT=SC_PGM.MSRMNT_PRD_STRT_DT) "
				+ " GROUP BY A.MSR_DIM_KEY,A.CARE_OPRTNTY_MSR_DIM_KEY, A.MSR_ID, A.RULE_ID,B.CMPST_DEFN_ID, C.PGM_DIM_KEY, C.MSRMNT_PRD_STRT_DT, "
				+ " B.SCRCRD_DEFN_ID, C.SCRCRD_MSR_HRCHY_DIM_KEY) AS IMPRV ON QLTY.RULE_ID = IMPRV.RULE_ID AND IMPRV.SCRCRD_DEFN_ID = QLTY.SCRCRD_DEFN_ID AND QLTY.MSRMNT_PRD_STRT_DT = IMPRV.MSRMNT_PRD_STRT_DT "
				/**
				 * Picking up CARE_OPRTNTY_MSR_DIM_KEY from QLTY, thus changing the group by
				 * Based on suggestions by Data team, dated 05/12-May-16 to fix defect WLPRD02576052
				 * Release 1.9 <DF WLPRD02576052> <AD12140>
				 */
				+ " AND QLTY.PGM_DIM_KEY = IMPRV.PGM_DIM_KEY GROUP BY QLTY.MSR_DIM_KEY, IMPRV.MSR_ID, QLTY.CARE_OPRTNTY_MSR_DIM_KEY, QLTY.SCRCRD_MSR_HRCHY_DIM_KEY, "
				+ " IMPRV.CMPST_DEFN_ID, QLTY.MSRMNT_PRD_STRT_DT, IMPRV.PGM_DIM_KEY) AS MD ON (CF.SCRCRD_MSR_HRCHY_DIM_KEY = MD.SCRCRD_MSR_HRCHY_DIM_KEY AND MD.CMPST_DEFN_ID = ? AND CF.MSR_DIM_KEY = MD.MSR_DIM_KEY and CF.MSRMNT_PRD_STRT_DT = MD.MSRMNT_PRD_STRT_DT and CF.PGM_DIM_KEY = MD.PGM_DIM_KEY) ");

		innerFrom
			.append(" LEFT JOIN psl_dim psl_dim on (PSF.psl_dim_key = psl_dim.psl_dim_key) ");

		if (StringUtil.isNotBlankOrFalse(request.getCareOppsStatusCds())) {
			innerFrom.append(" LEFT JOIN CARE_OPRTNTY_FACT COF ON ( MD.CARE_OPRTNTY_MSR_DIM_KEY = COF.MSR_DIM_KEY ");
			innerFrom.append(" and PD.PGM_DIM_KEY = COF.PGM_DIM_KEY ");
			innerFrom.append(" and  COF.prov_grp_dim_key = PGD.PROV_GRP_DIM_KEY  ");
			innerFrom.append(" and COF.MSTR_CNSMR_DIM_KEY = CF.MSTR_CNSMR_DIM_KEY ) ");
		}
		// innerFrom.append("LEFT JOIN LOB_DIM AS LD ON (PSF.LOB_DIM_KEY = LD.LOB_DIM_KEY) ");
		/*
		 * innerFrom.append(
		 * "join prov_grp_hrchy_dim pghd on (cf.prov_grp_dim_key = pghd.prov_grp_dim_key "
		 * ); // Moved this join into the if-statement as it was causing too
		 * many rows to be returned
		 * innerFrom.append("and cf.prov_org_dim_key = pghd.prov_org_dim_key ");
		 * innerFrom.append("and cf.ip_dim_key = pghd.ip_dim_key "); // added
		 * this condition to the join so that Quality Charts returns the same
		 * counts as Quality Patients/Providers [WLPRD01083809]
		 * innerFrom.append(
		 * "and PSF.PROV_GRP_HRCHY_DIM_KEY = pghd.PROV_GRP_HRCHY_DIM_KEY) ");
		 */
		// innerFrom.append("join pat_smry_fact psf on (cf.mstr_cnsmr_dim_key = psf.mstr_cnsmr_dim_key) ");

		StringBuilder innerWhere = new StringBuilder(" where ");

		// POIT clause
		//if (doPoitTableJoin(request.getGrpInd())) {
		innerFrom.append(getPoitTableJoin());

		innerWhere.append(getPoitTableWhere());
		//}

		innerWhere.append("and CF.ANLYSS_AS_OF_DT = ? ");
		/*innerWhere.append(" AND (LD.LOB_DIM_KEY IN ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getLobDimKeys()) 
				+ ") or (LD.LOB_DIM_KEY is null))");*/
		StringBuilder groupBy = new StringBuilder(" group by ")
			.append(buildSharedSelectGroupByColumns(request))
			.append(" ) cfq")
			.append(" on spmhf.PGM_DIM_KEY = cfq.PGM_DIM_KEY and spmhf.MSRMNT_PRD_STRT_DT = cfq.MSRMNT_PRD_STRT_DT and MD_IMP.MSR_ID = cfq.MSR_ID ");

		StringBuilder where = new StringBuilder(" where ");

		if (!StringUtils.isBlank(request.getProgramId())) {

			where.append("and pd.pgm_id = ? "); // programId
		}

		if (StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys())) {

			innerWhere.append("and md.msr_id in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getQualityMeasureKeys())
				+ ") "); // qualityMeasureKeys (not smhd.msr_dim_key)
		}
		/** AF21144 | PCMSP-473 start */
		if (Constants.AND_OPERATOR.equalsIgnoreCase(request.getQualityMeasureKeysToggle()) || Constants.AND_OPERATOR.equalsIgnoreCase(request.getStatusCdsToggle())) {
			innerWhere.append(" and cf.MSTR_CNSMR_DIM_KEY in (select MSTR_CNSMR_DIM_KEY from ")
				.append("(select MSTR_CNSMR_DIM_KEY ");
			if (Constants.AND_OPERATOR.equalsIgnoreCase(request.getQualityMeasureKeysToggle()))
				innerWhere.append(", LISTAGG( md2.msr_id, ',') msr_list ");
			if (Constants.AND_OPERATOR.equalsIgnoreCase(request.getStatusCdsToggle()))
				innerWhere.append(", count(distinct cf2.MSR_NMRTR_NBR) as st_count ");

			innerWhere.append(" from CMPLNC_FACT cf2 ")
				.append(" join msr_dim md2 on cf2.msr_dim_key = md2.msr_dim_key");

			StringBuilder innerWhereCheck = new StringBuilder();
			innerWhereCheck.append(" where cf2.msrmnt_prd_strt_dt = ? ");
			if (StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys()))
				innerWhereCheck.append(" and md2.msr_id in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getQualityMeasureKeys())
					+ ") ");
			if (StringUtil.isNotBlankOrFalse(request.getStatusCds())) {
				innerWhereCheck.append(" and cf2.MSR_NMRTR_NBR in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getStatusCds())
					+ ") ");
			}
			innerWhere.append(innerWhereCheck);

			innerWhere.append(" group by MSTR_CNSMR_DIM_KEY) ");

			StringBuilder outerWhereCheck = new StringBuilder();
			if (Constants.AND_OPERATOR.equalsIgnoreCase(request.getQualityMeasureKeysToggle())) {
				outerWhereCheck.append(" where (");
				String[] msrIds = request.getQualityMeasureKeys().split(",");
				for (int i = 0; i < msrIds.length; i++) {
					if (i > 0)
						outerWhereCheck.append(" and ");
					outerWhereCheck.append(" msr_list like ? ");
				}
				outerWhereCheck.append(" ) ");

			}
			if (Constants.AND_OPERATOR.equalsIgnoreCase(request.getStatusCdsToggle())) {
				if (outerWhereCheck.length() > 0)
					outerWhereCheck.append(" and ");
				else
					outerWhereCheck.append(" where ");
				outerWhereCheck.append(" st_count = ? ");
			}
			innerWhere.append(outerWhereCheck);
			innerWhere.append(")");
		}

		if (!StringUtils.isBlank(request.getCompositeId())) {

			where.append("and smhd.cmpst_defn_id = ? "); // CompositeId
			where.append(" and spmhf.MNTH_ID = (SELECT MAX(IPGSF.MNTH_ID) FROM IMPRV_PROV_GRP_SMRY_FACT IPGSF INNER JOIN "
				+ " (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT FROM SCRCRD_PGM_MSR_HRCHY_FACT WHERE "
				+ " PGM_DIM_KEY=(SELECT PGM_DIM_KEY FROM PGM_DIM WHERE PGM_ID=?) ");
			if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {

				where.append(" and MSRMNT_PRD_STRT_DT=? ");
			}
			where.append("GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM "
				+ " ON IPGSF.PGM_DIM_KEY=SC_PGM.PGM_DIM_KEY AND IPGSF.MSRMNT_PRD_STRT_DT=SC_PGM.MSRMNT_PRD_STRT_DT) ");

		}

		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {

			where.append("and spmhf.msrmnt_prd_strt_dt = ? "); // measurementPeriodStartDt
		}

		if (StringUtil.isNotBlankOrFalse(request.getCareOppsStatusCds())) {

			/*	innerWhere.append("and CF.MSTR_CNSMR_DIM_KEY in "
						+ "(select COF.MSTR_CNSMR_DIM_KEY from CARE_OPRTNTY_FACT AS COF, MSR_DIM MD_CO "
						+ "where MD.CARE_OPRTNTY_MSR_DIM_KEY = MD_CO.MSR_DIM_KEY and MD_CO.MSR_DIM_KEY = COF.MSR_DIM_KEY "
						+ "and COF.prov_grp_dim_key = CF.PROV_GRP_DIM_KEY "*/
			innerWhere.append(" and COF.MSTR_CNSMR_DIM_KEY in ( "
				+ QueryConstants.getCareOppStatusImpQueryWithToggle(request)
				+ ")  ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) { // populated if the Organization filter is applied
			innerWhere.append(" and ipd.ip_dim_key in (" // NF31 (no longer pghd.prov_grp_hrchy_dim_key)
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys())
				+ ") "); // provDimKeys
		}
		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			innerWhere.append(" and pod.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}

		// IHM Care Coordination filter: AP56, CP34, CO19, & SC92
		//		innerWhere.append(QueryConstants.buildIhmExistsCondition(request.getIhmIndToggle(),request.getIhmInd())); // Moved due to 2.0 toggle logic

		/** 57008 CHRONIC_CARE_GAP changes| ad87338 | START */
		//AF00030 made changes for PCMSP-1041 CommercialImprovement Quality Charts
		QueryConstants.prepareChronicRiskFiltersFromPatTable(StringUtil.prepareMapForChronicRisk(request), innerWhere);
		//QueryConstants.prepareChronicRiskFilters(StringUtil.prepareMapForChronicRisk(request), innerWhere);
		/** 57008 CHRONIC_CARE_GAP changes| ad87338 | END */

		if (filterCMDMPrograms(request)) {
			innerFrom.append(" left join crmgt_dm_fact cdf on (psf.mstr_cnsmr_dim_key = cdf.mstr_cnsmr_dim_key) ");

			if (StringUtil.isNotBlankOrFalse(request.getCmdmProgramKeys())) {

				innerWhere.append(QueryConstants.buildCmDmProgramKeysSubSelect(request));
			}

			if (StringUtil.isNotBlankOrFalse(request.getCmdmStatusKeys())) {
				// Quality Patients and Quality Charts (as well as Pop Mgt tabs) all use this same logic - reuse it.
				//				innerFrom.append(QueryConstants.buildCmDmStatusKeysFilterFromClause(request.getCmdmStatusKeys()));

				//				innerWhere.append(QueryConstants.buildCmDmStatusKeysFilterWhereClause(request.getCmdmStatusKeys(), "cf"));

				innerWhere.append(QueryConstants.buildCmDmStatusKeysSubSelectsWithPatTables(request));
			}
		}
		else {

			innerWhere.append(QueryConstants.buildIhmExistsCondition(request));
		}

		where = StringUtil.removeFirstOccurenceWithinString(where, "and");
		innerWhere = StringUtil.removeFirstOccurenceWithinString(innerWhere, "and");

		sql.append(from).append(leftJoin).append(innerSelect).append(innerFrom).append(innerWhere).append(groupBy).append(where);

		/** AF21144 | PCMSP-473, change to show selected msr in chart | start */
		if (StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys()) && Constants.AND_OPERATOR.equalsIgnoreCase(request.getQualityMeasureKeysToggle())) {
			sql.append("and MD_IMP.msr_id in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getQualityMeasureKeys())
				+ ") ");
		}
		/** end */

		sql
			.append("with ur ");

		String sqlString = String.format(sql.toString(), new Object[] {countWhereClause, countWhereClause});

		return sqlString;
	}

	protected String buildSharedSelectGroupByColumns(GetQualityChartRequest request) {
		StringBuilder select = new StringBuilder()
			.append(" cf.PGM_DIM_KEY ")
			.append(", CF.PROV_GRP_DIM_KEY ")
			.append(", cf.MSRMNT_PRD_STRT_DT ")
			.append(", MD.msr_id ");



		return select.toString();
	}

	protected void buildPreparedStatement(GetQualityChartRequest request, String sql) throws SQLException {
		int i = 0;
		prepareStatement(logger, sql);

		// same order of null checks as buildSql() to make sure markers are populated correctly

		if (!StringUtils.isBlank(request.getProgramId())) {
			ps.setString(++i, request.getProgramId());
		}

		if (!StringUtils.isBlank(request.getProvGrpIds())) {
			ps.setString(++i, request.getProvGrpIds());
		}

		if (!StringUtils.isBlank(request.getProgramId())) {
			ps.setString(++i, request.getProgramId());
		}

		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
			ps.setString(++i, request.getMeasurementPeriodStartDt());
		}

		if (!StringUtils.isBlank(request.getCompositeId())) {
			ps.setString(++i, request.getCompositeId());
		}

		if (!StringUtils.isBlank(request.getProgramId())) {
			ps.setString(++i, request.getProgramId());
		}

		if (!StringUtils.isBlank(request.getProgramId())) {
			ps.setString(++i, request.getProgramId());
		}

		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
			ps.setString(++i, request.getMeasurementPeriodStartDt());
		}

		if (!StringUtils.isBlank(request.getCompositeId())) {
			ps.setString(++i, request.getCompositeId());
		}

		//	if (doPoitTableJoin(request.getGrpInd())) {			
		ps.setString(++i, request.getSessionId());

		ps.setString(++i, request.getEntitlementId());
		//	}

		CommonQueries cq = new CommonQueries();
		String aaod = cq.selectAAODNImprovement(request.getProgramId(), request.getMeasurementPeriodStartDt());
		ps.setString(++i, aaod);

		String[] msrArray = null;
		List<String> statArray = null;
		if (StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys()))
			msrArray = request.getQualityMeasureKeys().split(",");
		if (StringUtil.isNotBlankOrFalse(request.getStatusCds()))
			statArray = StringUtil.getStatusCdsFilters(request.getStatusCds());

		if (StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys())) {
			for (String item : msrArray) {
				ps.setString(++i, item);
			}
		}

		if (Constants.AND_OPERATOR.equalsIgnoreCase(request.getQualityMeasureKeysToggle()) || Constants.AND_OPERATOR.equalsIgnoreCase(request.getStatusCdsToggle())) {

			if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
				ps.setString(++i, request.getMeasurementPeriodStartDt());
			}

			if (StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys()))
				for (String item : msrArray) {
					ps.setString(++i, item);
				}

			if (StringUtil.isNotBlankOrFalse(request.getStatusCds()))
				for (String item : statArray) {
					ps.setString(++i, item);
				}


			/** AF21144 | PCMSP-473 start */
			if (Constants.AND_OPERATOR.equalsIgnoreCase(request.getQualityMeasureKeysToggle())) {
				if (StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys()))
					for (String item : msrArray) {
						ps.setString(++i, "%" + item + "%");
					}
			}
			/** end */

			/** AF21144 | PCMSP-472 start */
			if (Constants.AND_OPERATOR.equalsIgnoreCase(request.getStatusCdsToggle()))
				ps.setInt(++i, statArray.size());
			/** end */
		}

		/*if (!StringUtil.isBlank(request.getLobDimKeys())) { // YJF: WLPRD01594317 lobDimKeys need to be set before careOppStatusCds
			String[] array = request.getLobDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}*/

		if (StringUtil.isNotBlankOrFalse(request.getCareOppsStatusCds())) {
			String[] array = request.getCareOppsStatusCds().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.convertCareOppsStatus(item));
			}
			ps.setInt(++i, array.length);
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) { // populated if the Organization filter is applied
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}
		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		/** 57008 CHRONIC_CARE_GAP changes| ad87338 | START */
		/*// Risk Drivers filter
		if (null != request.getRiskDriverKeys() && StringUtil.isNotBlankOrFalse(request.getRiskDriverKeys())) {
			String[] array = request.getRiskDriverKeys().split(",");
			// Need to be set 4 times
			for (String item : array) {
				ps.setString(++i, item);
			}
			for (String item : array) {
				ps.setString(++i, item);
			}
			for (String item : array) {
				ps.setString(++i, item);
			}
			for (String item : array) {
				ps.setString(++i, item);
			}
		}*/

		// Risk Drivers filter
		if (StringUtil.isNotBlankOrFalse(request.getRiskDriverKeys())) {
			i = buildRiskDriversFilterPreparedStatement(request, i);
		}

		// Risk Drivers filter
		if (null != request.getChronicCareGapsKeys()
			&& StringUtil.isNotBlankOrFalse(request.getChronicCareGapsKeys())) {
			String[] array = request.getChronicCareGapsKeys().split(",");
			// Need to be set 4 times
			for (String item : array) {
				ps.setString(++i, item);
			}
			/*for (String item : array) {
				ps.setString(++i, item);
			}
			for (String item : array) {
				ps.setString(++i, item);
			}
			for (String item : array) {
				ps.setString(++i, item);
			}*/
		}
		/** 57008 CHRONIC_CARE_GAP changes| ad87338 | END */

		if (filterCMDMPrograms(request)) {

			// CMDM Program filters
			i = buildCMDMPreparedStatement(request, i);

			// CMDM Status filters
			i = buildCMDMStatusPreparedStatement(request, i);
		}

		if (!StringUtils.isBlank(request.getProgramId())) {
			ps.setString(++i, request.getProgramId());
		}

		if (!StringUtils.isBlank(request.getCompositeId())) {
			ps.setString(++i, request.getCompositeId());
		}

		if (!StringUtils.isBlank(request.getProgramId())) {
			ps.setString(++i, request.getProgramId());
		}
		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
			ps.setString(++i, request.getMeasurementPeriodStartDt());
		}
		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
			ps.setString(++i, request.getMeasurementPeriodStartDt());
		}

		/** AF21144 | PCMSP-473 start */
		if (StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys()) && Constants.AND_OPERATOR.equalsIgnoreCase(request.getQualityMeasureKeysToggle())) {
			String[] array = request.getQualityMeasureKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}
		/** end */
	}
}
