package com.wellpoint.pc2dash.action.tooltip;

import com.wellpoint.pc2dash.action.drilldown.GetDrillDownRequest;

public class GetPatientDetailRequest extends GetDrillDownRequest {

	//protected String cmd;
	protected String lineOfBusiness;
	protected boolean attested;
	protected String highRiskRxIndCd;


	/*public String getCmd() {
		return cmd;
	}

	public void setCmd(String cmd) {
		this.cmd = cmd;
	}
	*/
	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	public boolean isAttested() {
		return attested;
	}

	public void setAttested(boolean attested) {
		this.attested = attested;
	}

	public String getHighRiskRxIndCd() {
		return highRiskRxIndCd;
	}

	public void setHighRiskRxIndCd(String highRiskRxIndCd) {
		this.highRiskRxIndCd = highRiskRxIndCd;
	}



}
