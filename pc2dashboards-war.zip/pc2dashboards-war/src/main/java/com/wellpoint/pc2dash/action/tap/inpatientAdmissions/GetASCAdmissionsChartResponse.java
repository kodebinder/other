package com.wellpoint.pc2dash.action.tap.inpatientAdmissions;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetASCAdmissionsChartResponse extends ActionResponse {

}
