package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
//import java.util.Arrays;
import java.util.Collection;

import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.data.dto.PCMSRequest;
import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;
import com.wellpoint.pc2dash.dto.scorecard.ScorecardMeasureBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;

public class MedicareScorecardMeasureFactsDao extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(MedicareScorecardMeasureFactsDao.class);

	public Collection<ScorecardMeasureBean> getScorecardMeasures(PerformanceManagementRequest request) throws Exception {
		Collection<ScorecardMeasureBean> resultList = new ArrayList<ScorecardMeasureBean>();
		StringBuilder sql = new StringBuilder();
		ScorecardMeasureBean measureBean = null;

		//Initialising the variable once instead of reading from the map again and again
		String pgmLobTypeCd = null;
		if (null != request.getProgramLobTypeCd()) {
			pgmLobTypeCd = request.getProgramLobTypeCd();
			if (pgmLobTypeCd.contains(Constants.FPCC_PGM_TYPE)) {
				sql = getFpccScorecardMeasuresQuery(request);
			}
			else
				sql = getEphcScorecardMeasuresQuery(request);
		}

		//		logger.debug("getScorecardMeasures SQL: " + sql.toString());

		try
		{
			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			prepareStatement(logger, sql.toString());
			int i = 0;
			if (null != pgmLobTypeCd && pgmLobTypeCd.contains(Constants.FPCC_PGM_TYPE)) {
				ps.setString(++i, request.getProvGrpIds());
			}
			ps.setString(++i, request.getOrganizationId());
			ps.setString(++i, request.getProvGrpIds());
			ps.setString(++i, request.getAnalysisAsOfDt());
			ps.setString(++i, request.getProvGrpIds());
			ps.setString(++i, request.getAnalysisAsOfDt());

			//logger.debug("provGrpId: " + request.getProvGrpId());
			//logger.debug("organizationId: " + request.getOrganizationId());
			//logger.debug("provGrpId: " + request.getProvGrpId());
			//logger.debug("analysisAsOfDt: " + request.getAnalysisAsOfDt());
			//logger.debug("provGrpId: " + request.getProvGrpId());
			//logger.debug("analysisAsOfDt: " + request.getAnalysisAsOfDt());

			if (null != pgmLobTypeCd && !pgmLobTypeCd.contains(Constants.FPCC_PGM_TYPE)) {
				ps.setString(++i, request.getAnalysisAsOfDt());
				ps.setString(++i, request.getMedicalPanelId());
				//logger.debug("analysisAsOfDt: " + request.getAnalysisAsOfDt());
			}

			ps.setString(++i, request.getProgramId());
			ps.setString(++i, request.getCompositeId());
			ps.setString(++i, request.getMeasurementPeriodStartDt());
			ps.setString(++i, request.getProgramLobTypeCd().toUpperCase());
			if (null != pgmLobTypeCd && !pgmLobTypeCd.contains(Constants.FPCC_PGM_TYPE)) {
				ps.setString(++i, request.getProvGrpIds());
			}
			/*if(null != pgmLobTypeCd && !pgmLobTypeCd.contains(Constants.FPCC_PGM_TYPE)){
				ps.setString(++i, request.getMedicalPanelId());
			}*/

			//logger.debug("prgmId: " + request.getProgramId());
			//logger.debug("compositeId: " + request.getCompositeId());
			//logger.debug("msrmntStrtDt: " + request.getMeasurementPeriodStartDt());
			//logger.debug("programLobTypeCd: " + request.getProgramLobTypeCd().toUpperCase());


			if (null != Constants.getQuarterName(request.getMeasurementInterval())) {
				if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
					ps.setString(++i, "Y");
				}
				else {
					ps.setString(++i, Constants.getQuarterName(request.getMeasurementInterval()));
				}
				//logger.debug("measurementInterval: " + Constants.getQuarterName(request.getMeasurementInterval()));
			}
			else {
				ps.setString(++i, request.getProgramId());
				ps.setString(++i, request.getMeasurementPeriodStartDt());
				//logger.debug("prgmId: " + request.getProgramId());
			}

			executeQuery(logger, sql.toString());

			while (rs.next()) {

				measureBean = new ScorecardMeasureBean();
				if (rs.getString("CMPST_TYPE_DESC") != null) {
					measureBean.setCompTypeDesc(rs.getString("CMPST_TYPE_DESC"));
				}
				if (rs.getString("CMPST_DEFN_ID") != null) {
					measureBean.setCmpstDefnId(rs.getString("CMPST_DEFN_ID"));
				}
				if (rs.getString("CMPST_NM") != null) {
					measureBean.setCmpstNm(rs.getString("CMPST_NM"));
				}
				if (rs.getString("SUB_CMPST_DEFN_ID") != null) {
					measureBean.setSubCmpstDefnId(rs.getString("SUB_CMPST_DEFN_ID"));
				}
				if (rs.getString("SUB_CMPST_NM") != null) {
					measureBean.setSubCmpstNm(rs.getString("SUB_CMPST_NM"));
				}
				if (rs.getString("MSR_DIM_KEY") != null) {
					measureBean.setMsrId(rs.getString("MSR_DIM_KEY"));
				}
				if (rs.getString("MSR_DSPLY_NM") != null) {
					measureBean.setMsrDsplyNm(rs.getString("MSR_DSPLY_NM"));
				}
				//Setting values for Organization Level
				if (rs.getString("COSF_MSR_NMRTR_NBR") != null) {
					measureBean.getScorecardMeasureOrgLvl().setMsrNmrtrNbr(Integer.valueOf(rs.getInt("COSF_MSR_NMRTR_NBR")));
				}
				if (rs.getString("COSF_MSR_DNMNTR_NBR") != null) {
					measureBean.getScorecardMeasureOrgLvl().setMsrDnmntrNbr(Integer.valueOf(rs.getInt("COSF_MSR_DNMNTR_NBR")));
				}
				if (rs.getString("COSF_RT_PCT") != null)
					measureBean.getScorecardMeasureOrgLvl().setRtPct(rs.getString("COSF_RT_PCT"));

				//Setting values for Group Level
				if (rs.getString("CPGSF_MSR_NMRTR_NBR") != null) {
					measureBean.getScorecardMeasureGrpLvl().setMsrNmrtrNbr(Integer.valueOf(rs.getString("CPGSF_MSR_NMRTR_NBR")));
				}
				if (rs.getString("CPGSF_MSR_DNMNTR_NBR") != null) {
					measureBean.getScorecardMeasureGrpLvl().setMsrDnmntrNbr(Integer.valueOf(rs.getString("CPGSF_MSR_DNMNTR_NBR")));
				}
				if (rs.getString("CPGSF_RT_PCT") != null)
					measureBean.getScorecardMeasureGrpLvl().setRtPct(rs.getString("CPGSF_RT_PCT"));

				//Setting values for Panel Level only in case of EPHC Programs
				if (null != pgmLobTypeCd && !pgmLobTypeCd.contains(Constants.FPCC_PGM_TYPE)) {
					if (rs.getString("CMSF_MSR_NMRTR_NBR") != null) {
						measureBean.getScorecardMeasurePnlLvl().setMsrNmrtrNbr(Integer.valueOf(rs.getString("CMSF_MSR_NMRTR_NBR")));
					}
					if (rs.getString("CMSF_MSR_DNMNTR_NBR") != null) {
						measureBean.getScorecardMeasurePnlLvl().setMsrDnmntrNbr(Integer.valueOf(rs.getString("CMSF_MSR_DNMNTR_NBR")));
					}
					if (rs.getBigDecimal("MRKT_RT_PCT") != null) {
						measureBean.setMrktRtPct(rs.getBigDecimal("MRKT_RT_PCT"));
					}
					if (rs.getString("CMSF_RT_PCT") != null)
						measureBean.getScorecardMeasurePnlLvl().setRtPct(rs.getString("CMSF_RT_PCT"));

					if (rs.getBigDecimal("RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT") != null) {
						measureBean.setWeight(rs.getBigDecimal("RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT"));
					}
				}
				//Setting Bean values for Composite: Utilization
				if (rs.getString("CMPST_TYPE_DESC") != null && rs.getString("CMPST_TYPE_DESC").equalsIgnoreCase("Utilization"))
				{
					if (rs.getBigDecimal("COSF_RISK_ADJSTMNT_FCTR") != null) {
						measureBean.getScorecardMeasureOrgLvl().setRiskAdjstmntFctr(rs.getBigDecimal("COSF_RISK_ADJSTMNT_FCTR"));
					}
					if (rs.getBigDecimal("CPGSF_RISK_ADJSTMNT_FCTR") != null) {
						measureBean.getScorecardMeasureGrpLvl().setRiskAdjstmntFctr(rs.getBigDecimal("CPGSF_RISK_ADJSTMNT_FCTR"));
					}
					if (null != pgmLobTypeCd && !pgmLobTypeCd.contains(Constants.FPCC_PGM_TYPE) && rs.getBigDecimal("CMSF_RISK_ADJSTMNT_FCTR") != null) {
						measureBean.getScorecardMeasurePnlLvl().setRiskAdjstmntFctr(rs.getBigDecimal("CMSF_RISK_ADJSTMNT_FCTR"));
					}
				}
				//PCMSP-11258
				if(rs.getString("ACHVD_TRNCH_LVL_CD") != null)
					measureBean.setAchvdTrnchLvlCd(rs.getString("ACHVD_TRNCH_LVL_CD"));
				if(rs.getString("MDCR_TIER_2_IND") != null)
					measureBean.setTier2Ind(rs.getString("MDCR_TIER_2_IND"));
				
				resultList.add(measureBean);
			}
		}
		catch (Exception e) {
			logger.error("Exception during getScorecardMeasures", e);
		}
		finally {
			close();
		}

		return resultList;
	}

	/**
	 * @param request
	 * @return
	 * @throws Exception
	 */
	private StringBuilder getEphcScorecardMeasuresQuery(PCMSRequest request) {

		StringBuilder query =
			new StringBuilder()
				//.append(" SELECT DISTINCT z.* from ( " 
				.append(" SELECT DISTINCT SMHD.CMPST_DEFN_ID, SMHD.CMPST_NM, SMHD.SUB_CMPST_DEFN_ID, SMHD.SUB_CMPST_NM, "
					+ "MSR.MSR_DSPLY_NM, MSR.MSR_DIM_KEY, "
					+ "COSF1.MSR_NMRTR_NBR AS COSF_MSR_NMRTR_NBR, COSF1.MSR_DNMNTR_NBR AS COSF_MSR_DNMNTR_NBR, "
					+ "COSF1.RISK_ADJSTMNT_FCTR AS COSF_RISK_ADJSTMNT_FCTR, "
					+ "CPGSF1.MSR_NMRTR_NBR AS CPGSF_MSR_NMRTR_NBR, CPGSF1.MSR_DNMNTR_NBR AS CPGSF_MSR_DNMNTR_NBR, "
					+ "CPGSF1.RISK_ADJSTMNT_FCTR AS CPGSF_RISK_ADJSTMNT_FCTR, "
					+ "CMSF1.MDPNL_DIM_KEY, CMSF1.MSR_NMRTR_NBR AS CMSF_MSR_NMRTR_NBR, CMSF1.MSR_DNMNTR_NBR AS CMSF_MSR_DNMNTR_NBR, "
					+ "CMSF1.RISK_ADJSTMNT_FCTR AS CMSF_RISK_ADJSTMNT_FCTR, SPGMHF.MRKT_RT_PCT, "
					+ "EF.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT, SMHD.CMPST_TYPE_DESC, cmsf1.mdpnl_id,cpgsf1.rt_pct as CPGSF_RT_PCT,cmsf1.rt_pct as CMSF_RT_PCT,cosf1.rt_pct as COSF_RT_PCT, case when EF.SSAV_UPSD_DSTRBTN_PCT > 0  then ef.ACHVD_TRNCH_LVL_CD else 'NA' end as ACHVD_TRNCH_LVL_CD,epgsf.MDCR_TIER_2_IND " //PCMSP-11258
					/*+ " , rank() over (partition by ef.prov_grp_dim_key, ef.pgm_dim_key, ef.msrmnt_prd_strt_dt order by case when ef.sor_dtm > pgpa1.prov_grp_pnl_assn_trmntn_dt then 999 " 
					+" else timestampdiff(16, pgpa1.prov_grp_pnl_assn_trmntn_dt - ef.sor_dtm) end, pgpa1.prov_grp_pnl_assn_trmntn_dt desc) as pnl_rank "*/
					+ "FROM "
					+ "SCRCRD_PGM_MSR_HRCHY_FACT AS SPGMHF "
					+ "INNER JOIN ERNCNTR_FACT AS EF ON EF.MNTH_ID = SPGMHF.MNTH_ID "
					+ "AND EF.PGM_DIM_KEY = SPGMHF.PGM_DIM_KEY "
					+ "AND EF.MSRMNT_PRD_STRT_DT = SPGMHF.MSRMNT_PRD_STRT_DT "
					+ "AND EF.TRNCH_DEFN_DIM_KEY = SPGMHF.TRNCH_DEFN_DIM_KEY "
					+ "INNER JOIN SCRCRD_MSR_HRCHY_DIM AS SMHD ON SPGMHF.SCRCRD_MSR_HRCHY_DIM_KEY = SMHD.SCRCRD_MSR_HRCHY_DIM_KEY "
					+ "INNER JOIN MSR_DIM AS MSR ON SMHD.MSR_DIM_KEY = MSR.MSR_DIM_KEY "
					+ " and SPGMHF.msrmnt_prd_strt_dt >= MSR.MSR_EFCTV_DT and SPGMHF.msrmnt_prd_end_dt <= MSR.MSR_TRMNTN_DT "
					+ "INNER JOIN PGM_DIM AS PGM ON SPGMHF.PGM_DIM_KEY = PGM.PGM_DIM_KEY "
					+ " inner join PROV_GRP_DIM as PGD on ef.prov_grp_dim_key=pgd.prov_grp_dim_key "
					+ " JOIN ERNCNTR_PROV_GRP_SMRY_FACT epgsf on  epgsf.prov_grp_dim_key = ef.prov_grp_dim_key and epgsf.pgm_dim_key = ef.pgm_dim_key " //PCMSP-11258
					+ " and  epgsf.mnth_id = ef.mnth_id and   epgsf.msrmnt_prd_strt_dt = ef.msrmnt_prd_strt_dt	"
					/*+ " inner join "
					+ "   (Select pgpa.prov_grp_dim_key, pgpa.pgm_dim_key, pgpa.mdpnl_dim_key, pgpa.PROV_GRP_PNL_ASSN_EFCTV_DT, pgpa.prov_grp_pnl_assn_trmntn_dt  "
					+ "   FROM prov_grp_pnl_assn_fact pgpa "
					+ "   group by pgpa.prov_grp_dim_key, pgpa.pgm_dim_key, pgpa.mdpnl_dim_key, pgpa.PROV_GRP_PNL_ASSN_EFCTV_DT, pgpa.prov_grp_pnl_assn_trmntn_dt) pgpa1 "
					+ "   on pgm.PGM_DIM_KEY=pgpa1.PGM_DIM_KEY "
					//	+ " and spgmhf.msrmnt_prd_strt_dt >= pgpa1.PROV_GRP_PNL_ASSN_EFCTV_DT  "     //commented based  on the confirmation from data team since the PG can come in middle of MP
					+ " INNER JOIN PROV_GRP_DIM AS PGD ON PGPA1.PROV_GRP_DIM_KEY = PGD.PROV_GRP_DIM_KEY AND EF.PROV_GRP_DIM_KEY = PGD.PROV_GRP_DIM_KEY " 
					//+ " AND PGD.PROV_GRP_ID = ? and PGD.PROV_GRP_TRMNTN_DT >= pgpa1.prov_grp_pnl_assn_trmntn_dt "
					+ " and pgd.prov_grp_id = ?  and ( ef.msrmnt_prd_strt_dt <= pgpa1.prov_grp_pnl_assn_trmntn_dt and ef.msrmnt_prd_end_dt >= pgpa1.PROV_GRP_PNL_ASSN_EFCTV_DT ) "*/
					//+ "INNER JOIN PROV_GRP_PGM_LOB_FACT AS PGPLF ON PGPLF.PGM_DIM_KEY = SPGMHF.PGM_DIM_KEY "
					//+ "AND PGPLF.PROV_GRP_DIM_KEY = PGD.PROV_GRP_DIM_KEY "
					//+ "INNER JOIN LOB_DIM AS LD ON LD.LOB_DIM_KEY = PGPLF.LOB_DIM_KEY "
					+ "LEFT OUTER JOIN ( SELECT COSF.PGM_DIM_KEY, COSF.MSRMNT_PRD_STRT_DT, COSF.SCRCRD_MSR_HRCHY_DIM_KEY, COSF.MSR_NMRTR_NBR, COSF.MSR_DNMNTR_NBR, COSF.RISK_ADJSTMNT_FCTR, POD.PROV_ORG_DIM_KEY, PGD.PROV_GRP_DIM_KEY,cosf.rt_pct  "
					+ "FROM CMPLNC_ORG_SMRY_FACT AS COSF "
					+ "INNER JOIN PROV_ORG_DIM AS POD ON COSF.PROV_ORG_DIM_KEY = POD.PROV_ORG_DIM_KEY AND POD.PROV_ORG_DIM_KEY = ? " // Result of NF31: PROV_ORG_TAX_ID changed to PROV_ORG_DIM_KEY
					+ "INNER JOIN PROV_GRP_DIM AS PGD ON COSF.PROV_GRP_DIM_KEY = PGD.PROV_GRP_DIM_KEY AND PGD.PROV_GRP_ID = ? "
					+ "AND COSF.ANLYSS_AS_OF_DT = ?) AS COSF1 "
					+ "ON (SPGMHF.PGM_DIM_KEY = COSF1.PGM_DIM_KEY "
					+ "AND SPGMHF.MSRMNT_PRD_STRT_DT = COSF1.MSRMNT_PRD_STRT_DT "
					+ "AND SPGMHF.SCRCRD_MSR_HRCHY_DIM_KEY = COSF1.SCRCRD_MSR_HRCHY_DIM_KEY) "
					+ "LEFT OUTER JOIN ( SELECT CPGSF.MSR_NMRTR_NBR, CPGSF.MSR_DNMNTR_NBR, CPGSF.RISK_ADJSTMNT_FCTR, CPGSF.MDPNL_DIM_KEY, CPGSF.SCRCRD_MSR_HRCHY_DIM_KEY, PGD.PROV_GRP_DIM_KEY, CPGSF.PGM_DIM_KEY, CPGSF.MSRMNT_PRD_STRT_DT,cpgsf.rt_pct  "
					+ "FROM CMPLNC_PROV_GRP_SMRY_FACT AS CPGSF "
					+ "INNER JOIN PROV_GRP_DIM AS PGD ON CPGSF.PROV_GRP_DIM_KEY = PGD.PROV_GRP_DIM_KEY AND PGD.PROV_GRP_ID = ? "
					+ "AND CPGSF.ANLYSS_AS_OF_DT = ?) AS CPGSF1 "
					+ "ON (SPGMHF.PGM_DIM_KEY = CPGSF1.PGM_DIM_KEY "
					+ "AND SPGMHF.MSRMNT_PRD_STRT_DT = CPGSF1.MSRMNT_PRD_STRT_DT "
					+ "AND SPGMHF.SCRCRD_MSR_HRCHY_DIM_KEY = CPGSF1.SCRCRD_MSR_HRCHY_DIM_KEY) "
					+ "LEFT OUTER JOIN ( SELECT CMSF.MSR_NMRTR_NBR, CMSF.MSR_DNMNTR_NBR, CMSF.RISK_ADJSTMNT_FCTR, CMSF.MDPNL_DIM_KEY, CMSF.PGM_DIM_KEY, CMSF.MSRMNT_PRD_STRT_DT, CMSF.SCRCRD_MSR_HRCHY_DIM_KEY, md.mdpnl_id,cmsf.rt_pct "
					+ "FROM CMPLNC_MDPNL_SMRY_FACT AS CMSF inner join mdpnl_dim md on md.mdpnl_dim_key = cmsf.mdpnl_dim_key "
					+ "WHERE CMSF.ANLYSS_AS_OF_DT = ? and md.mdpnl_id = ? ) AS CMSF1 "
					+ "ON (SPGMHF.PGM_DIM_KEY = CMSF1.PGM_DIM_KEY "
					+ "AND SPGMHF.MSRMNT_PRD_STRT_DT = CMSF1.MSRMNT_PRD_STRT_DT "
					+ "AND SPGMHF.SCRCRD_MSR_HRCHY_DIM_KEY = CMSF1.SCRCRD_MSR_HRCHY_DIM_KEY "
					+ "AND ef.MDPNL_DIM_KEY = CMSF1.MDPNL_DIM_KEY) "
					+ "WHERE PGM.PGM_ID = ? "
					+ "AND SMHD.CMPST_DEFN_ID = ? "
					+ "AND SPGMHF.MSRMNT_PRD_STRT_DT = ? "
					+ "AND spgmhf.pgm_lob_type_cd = ? "
					+ " and pgd.prov_grp_id = ? ");
		//	+ "and cmsf1.mdpnl_id = ? " );

		/*int counter = 0;
		query.append("AND ld.LOB_DIM_KEY IN (");
		for(String lobDimKey : Arrays.asList(request.get("lobDimKeys").split(","))){
			if (Arrays.asList(request.get("lobDimKeys").split(",")).size() == 1 || counter == Arrays.asList(request.get("lobDimKeys").split(",")).size() - 1) {
				query.append("'" + lobDimKey + "'");
			} else {
				query.append("'" + lobDimKey + "'" + ",");
			}
			counter++;
		}
		query.append(" ) ");*/


		if (null != Constants.getQuarterName(request.getMeasurementInterval())) {
			if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
				query.append(" AND ef.BSLN_SCRCRD_IND = ? ");
			}
			else {
				query.append(" AND ef.QTR_ID = ? ");
			}
		}
		else {
			query.append(" AND ef.MNTH_ID = (SELECT MAX(EF.MNTH_ID) FROM ERNCNTR_FACT EF INNER JOIN "
				+ "(Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT FROM SCRCRD_PGM_MSR_HRCHY_FACT WHERE "
				+ "PGM_DIM_KEY=(SELECT PGM_DIM_KEY FROM PGM_DIM WHERE PGM_ID= ?) and MSRMNT_PRD_STRT_DT=? GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM "
				+ "ON EF.PGM_DIM_KEY=SC_PGM.PGM_DIM_KEY AND EF.MSRMNT_PRD_STRT_DT=SC_PGM.MSRMNT_PRD_STRT_DT) ");
		}

		/*query.append(" ) z where z.pnl_rank = 1 ") ;
		query.append("ORDER BY z.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT DESC, z.MSR_DSPLY_NM ");*/
		query.append("ORDER BY ef.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT DESC, msr.MSR_DSPLY_NM ");
		query = StringUtil.appendWithUr(query);
		return query;
	}

	/**
	 * @param request
	 * @return
	 */
	private StringBuilder getFpccScorecardMeasuresQuery(PCMSRequest request) {
		StringBuilder query =
			new StringBuilder()
				.append("SELECT DISTINCT SMHD.CMPST_DEFN_ID, SMHD.CMPST_NM, SMHD.SUB_CMPST_DEFN_ID, SMHD.SUB_CMPST_NM, "
					+ "MSR.MSR_DSPLY_NM, MSR.MSR_DIM_KEY, "
					+ "COSF1.MSR_NMRTR_NBR AS COSF_MSR_NMRTR_NBR, COSF1.MSR_DNMNTR_NBR AS COSF_MSR_DNMNTR_NBR, "
					+ "COSF1.RISK_ADJSTMNT_FCTR AS COSF_RISK_ADJSTMNT_FCTR, "
					+ "CPGSF1.MSR_NMRTR_NBR AS CPGSF_MSR_NMRTR_NBR, CPGSF1.MSR_DNMNTR_NBR AS CPGSF_MSR_DNMNTR_NBR, "
					+ "CPGSF1.RISK_ADJSTMNT_FCTR AS CPGSF_RISK_ADJSTMNT_FCTR, SPGMHF.MRKT_RT_PCT, "
					+ "EF.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT, SMHD.CMPST_TYPE_DESC,cpgsf1.rt_pct as CPGSF_RT_PCT,cosf1.rt_pct as COSF_RT_PCT, case when EF.SSAV_UPSD_DSTRBTN_PCT > 0  then ef.ACHVD_TRNCH_LVL_CD else 'NA' end as ACHVD_TRNCH_LVL_CD,epgsf.MDCR_TIER_2_IND " //PCMSP-11258 
					+ "FROM "
					+ "SCRCRD_PGM_MSR_HRCHY_FACT AS SPGMHF "
					+ "INNER JOIN ERNCNTR_FACT AS EF ON EF.MNTH_ID = SPGMHF.MNTH_ID "
					+ "AND EF.PGM_DIM_KEY = SPGMHF.PGM_DIM_KEY "
					+ "AND EF.MSRMNT_PRD_STRT_DT = SPGMHF.MSRMNT_PRD_STRT_DT "
					+ "AND EF.TRNCH_DEFN_DIM_KEY = SPGMHF.TRNCH_DEFN_DIM_KEY "
					+ "INNER JOIN SCRCRD_MSR_HRCHY_DIM AS SMHD ON SPGMHF.SCRCRD_MSR_HRCHY_DIM_KEY = SMHD.SCRCRD_MSR_HRCHY_DIM_KEY "
					+ "INNER JOIN MSR_DIM AS MSR ON SMHD.MSR_DIM_KEY = MSR.MSR_DIM_KEY "
					+ " and SPGMHF.msrmnt_prd_strt_dt >= MSR.MSR_EFCTV_DT and SPGMHF.msrmnt_prd_end_dt <= MSR.MSR_TRMNTN_DT "
					+ "INNER JOIN PGM_DIM AS PGM ON SPGMHF.PGM_DIM_KEY = PGM.PGM_DIM_KEY "
					+ " INNER JOIN PROV_GRP_DIM AS PGD ON EF.PROV_GRP_DIM_KEY = PGD.PROV_GRP_DIM_KEY AND PGD.PROV_GRP_ID = ? "
					+ " JOIN ERNCNTR_PROV_GRP_SMRY_FACT epgsf on  epgsf.prov_grp_dim_key = ef.prov_grp_dim_key and epgsf.pgm_dim_key = ef.pgm_dim_key " //PCMSP-11258
					+ " and  epgsf.mnth_id = ef.mnth_id and   epgsf.msrmnt_prd_strt_dt = ef.msrmnt_prd_strt_dt	" 
					+ "LEFT OUTER JOIN ( SELECT COSF.PGM_DIM_KEY, COSF.MSRMNT_PRD_STRT_DT, COSF.SCRCRD_MSR_HRCHY_DIM_KEY, COSF.MSR_NMRTR_NBR, COSF.MSR_DNMNTR_NBR, COSF.RISK_ADJSTMNT_FCTR, POD.PROV_ORG_DIM_KEY, PGD.PROV_GRP_DIM_KEY, COSF.RT_PCT "
					+ "FROM CMPLNC_ORG_SMRY_FACT AS COSF "
					+ "INNER JOIN PROV_ORG_DIM AS POD ON COSF.PROV_ORG_DIM_KEY = POD.PROV_ORG_DIM_KEY AND POD.PROV_ORG_DIM_KEY = ? " // Result of NF31: PROV_ORG_TAX_ID changed to PROV_ORG_DIM_KEY
					+ "INNER JOIN PROV_GRP_DIM AS PGD ON COSF.PROV_GRP_DIM_KEY = PGD.PROV_GRP_DIM_KEY AND PGD.PROV_GRP_ID = ? "
					+ "AND COSF.ANLYSS_AS_OF_DT = ?) AS COSF1 "
					+ "ON (SPGMHF.PGM_DIM_KEY = COSF1.PGM_DIM_KEY "
					+ "AND SPGMHF.MSRMNT_PRD_STRT_DT = COSF1.MSRMNT_PRD_STRT_DT "
					+ "AND SPGMHF.SCRCRD_MSR_HRCHY_DIM_KEY = COSF1.SCRCRD_MSR_HRCHY_DIM_KEY) "
					+ "LEFT OUTER JOIN ( SELECT CPGSF.MSR_NMRTR_NBR, CPGSF.MSR_DNMNTR_NBR, CPGSF.RISK_ADJSTMNT_FCTR, CPGSF.MDPNL_DIM_KEY, CPGSF.SCRCRD_MSR_HRCHY_DIM_KEY, PGD.PROV_GRP_DIM_KEY, CPGSF.PGM_DIM_KEY, CPGSF.MSRMNT_PRD_STRT_DT, CPGSF.RT_PCT "
					+ "FROM CMPLNC_PROV_GRP_SMRY_FACT AS CPGSF "
					+ "INNER JOIN PROV_GRP_DIM AS PGD ON CPGSF.PROV_GRP_DIM_KEY = PGD.PROV_GRP_DIM_KEY AND PGD.PROV_GRP_ID = ? "
					+ "AND CPGSF.ANLYSS_AS_OF_DT = ?) AS CPGSF1 "
					+ "ON (SPGMHF.PGM_DIM_KEY = CPGSF1.PGM_DIM_KEY "
					+ "AND SPGMHF.MSRMNT_PRD_STRT_DT = CPGSF1.MSRMNT_PRD_STRT_DT "
					+ "AND SPGMHF.SCRCRD_MSR_HRCHY_DIM_KEY = CPGSF1.SCRCRD_MSR_HRCHY_DIM_KEY) "
					+ "WHERE PGM.PGM_ID = ? "
					+ "AND SMHD.CMPST_DEFN_ID = ? "
					+ "AND SPGMHF.MSRMNT_PRD_STRT_DT = ? "
					+ "AND spgmhf.pgm_lob_type_cd = ? ");


		if (null != Constants.getQuarterName(request.getMeasurementInterval())) {
			if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
				query.append(" AND ef.BSLN_SCRCRD_IND = ? ");
			}
			else {
				query.append(" AND ef.QTR_ID = ? ");
			}
		}
		else {
			query.append(" AND ef.MNTH_ID = (SELECT MAX(EF.MNTH_ID) FROM ERNCNTR_FACT EF INNER JOIN "
				+ "(Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT FROM SCRCRD_PGM_MSR_HRCHY_FACT WHERE "
				+ "PGM_DIM_KEY=(SELECT PGM_DIM_KEY FROM PGM_DIM WHERE PGM_ID= ?) and MSRMNT_PRD_STRT_DT=? GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM "
				+ "ON EF.PGM_DIM_KEY=SC_PGM.PGM_DIM_KEY AND EF.MSRMNT_PRD_STRT_DT=SC_PGM.MSRMNT_PRD_STRT_DT)");
		}

		query.append("ORDER BY ef.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT DESC, msr.MSR_DSPLY_NM ");
		query = StringUtil.appendWithUr(query);

		return query;
	}

	@Override
	public boolean read(Dto o) throws Exception {

		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {


	}

	@Override
	public void update(Dto o) throws Exception {


	}

	@Override
	public void delete(Dto o) throws Exception {


	}

}
