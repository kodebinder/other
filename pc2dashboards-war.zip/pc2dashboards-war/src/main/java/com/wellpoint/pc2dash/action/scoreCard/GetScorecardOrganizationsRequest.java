package com.wellpoint.pc2dash.action.scoreCard;

import com.wellpoint.pc2dash.data.dto.PCMSRequest;

public class GetScorecardOrganizationsRequest extends PCMSRequest {

	private String bslnPrdEndDt;
	private String bslnPrdStrtDt;
	private String msrmntPrdEndDt;
	private String msrmntPrdStrtDt;

	public String getBslnPrdEndDt() {
		return bslnPrdEndDt;
	}

	public String getBslnPrdStrtDt() {
		return bslnPrdStrtDt;
	}

	public String getMsrmntPrdEndDt() {
		return msrmntPrdEndDt;
	}

	public String getMsrmntPrdStrtDt() {
		return msrmntPrdStrtDt;
	}

	public void setBslnPrdEndDt(String bslnPrdEndDt) {
		this.bslnPrdEndDt = bslnPrdEndDt;
	}

	public void setBslnPrdStrtDt(String bslnPrdStrtDt) {
		this.bslnPrdStrtDt = bslnPrdStrtDt;
	}

	public void setMsrmntPrdEndDt(String msrmntPrdEndDt) {
		this.msrmntPrdEndDt = msrmntPrdEndDt;
	}

	public void setMsrmntPrdStrtDt(String msrmntPrdStrtDt) {
		this.msrmntPrdStrtDt = msrmntPrdStrtDt;
	}

}
