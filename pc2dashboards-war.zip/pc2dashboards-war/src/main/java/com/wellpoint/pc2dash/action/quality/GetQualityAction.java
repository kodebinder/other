package com.wellpoint.pc2dash.action.quality;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.drilldown.GetDrillDownRequest;
import com.wellpoint.pc2dash.util.StringUtil;


public class GetQualityAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		return null;
	}

	/**
	 * Clean certain fields before passing them to the DB.
	 * Note: provDimKeys is also known as panelHierarchy.
	 */
	public GetDrillDownRequest cleanRequest(GetDrillDownRequest request) throws Exception {

		if (request != null) {

			if (!StringUtils.isBlank(request.getMeasurementPeriodEndDt())) {
				request.setMeasurementPeriodEndDt(StringUtil.convertDate(request.getMeasurementPeriodEndDt()));
			}

			if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
				request.setMeasurementPeriodStartDt(StringUtil.convertDate(request.getMeasurementPeriodStartDt()));
			}

			if (!StringUtils.isBlank(request.getAnalysisAsOfDt())) {
				request.setAnalysisAsOfDt(StringUtil.convertDate(request.getAnalysisAsOfDt()));
			}
		}

		return request;
	}
}
