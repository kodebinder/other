package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.action.tooltip.GetPatientDetailRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.patient.CareGaps;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;


public class CareOpportunityFacts extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(CareOpportunityFacts.class);

	public boolean read(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void insert(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void update(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void delete(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public Collection<CareGaps> getCareOpportunities(GetPatientDetailRequest request) throws Exception {

		Collection<CareGaps> result = new ArrayList<CareGaps>();

		StringBuilder sql = new StringBuilder()
			.append("select ")
			.append("	md.msr_dsply_nm, ")
			.append("	cof.last_cmplnc_dt, ")
			.append("	cof.next_clncl_due_dt, ")
			.append("   cof.careopp_vst_due_nbr, ") //added by vishwa CO16306 R1.4
			.append("	cof.care_oprtnty_stts_cd, ")  //PCMSP-17463
			.append("	cof.pdc_pct ")
			.append("from ")
			.append("	care_oprtnty_fact cof ")
			.append("	join msr_dim md on (cof.msr_dim_key = md.msr_dim_key) ")
			.append("	join clncl_msr_hrchy_dim cmhd on (md.msr_dim_key = cmhd.msr_dim_key) ")
			.append("	join mstr_cnsmr_fact mcf on (cof.mstr_cnsmr_dim_key = mcf.mstr_cnsmr_dim_key) ")
			.append("	join poit_user_scrty_acs pusa on ( ")
			.append("		mcf.prov_grp_id = pusa.prov_grp_id ")
			.append("		and case ")
			.append("				when pusa.prov_org_tax_id = '0' then mcf.prov_org_tax_id ")
			.append("				else pusa.prov_org_tax_id ")
			.append("			end = mcf.prov_org_tax_id ")
			.append("	) ")
			.append("where ")
			.append("	pusa.sesn_id = ? ")
			.append("	and pusa.enttlmnt_hash_key = ? ")
			.append("	and mcf.mstr_cnsmr_dim_key = ? ")
			.append("	and cof.care_oprtnty_stts_cd in ('0','1','2','3','4') ")
			.append("	and cmhd.msr_sprs_ind_cd = 'N' ")
			.append("order by ")
			.append("	cof.next_clncl_due_dt ")
			.append("with ur ");

		//		logger.debug("getCareOpportunities SQL: " + sql.toString());

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());
			ps.setString(1, request.getSessionId());
			ps.setString(2, request.getEntitlementId());
			ps.setString(3, request.getMemberKey());

			//logger.debug("sesn_id: " + request.getSessionId());
			//logger.debug("enttlmnt_hash_key: " + request.getEntitlementId());
			//logger.debug("mstr_cnsmr_dim_key: " + request.getMemberKey());

			executeQuery(logger, sql.toString());

			while (rs.next()) {

				CareGaps r = new CareGaps();
				r.setCareOppsDsplyNm(getString(rs, "msr_dsply_nm"));
				r.setCareOppsPrevDt(getDate(rs, "last_cmplnc_dt"));
				r.setClinicalDueDt(getDate(rs, "next_clncl_due_dt"));
				r.setRemainingVisits(getString(rs, "careopp_vst_due_nbr")); //added by vishwa CO16306 R1.4
				//r.setRemainingVisits("1");
				r.setCareOppsStatusCd(rs.getInt("care_oprtnty_stts_cd"));
				r.setProportionOfDaysCovered(getString(rs, "pdc_pct")); //PCMSP-17463

				/*if (r.getClinicalDueDt().equals("---")) {
					r.setCareOppsStatusCd(null);
				}*/

				result.add(r);
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get care opportunities (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}
}
