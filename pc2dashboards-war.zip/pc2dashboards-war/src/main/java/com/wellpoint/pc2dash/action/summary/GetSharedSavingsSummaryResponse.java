package com.wellpoint.pc2dash.action.summary;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetSharedSavingsSummaryResponse extends ActionResponse {

}
