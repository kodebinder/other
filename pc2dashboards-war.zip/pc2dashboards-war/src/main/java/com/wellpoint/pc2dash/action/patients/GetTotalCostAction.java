package com.wellpoint.pc2dash.action.patients;

import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.patient.TotalCostBean;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.patient.TotalCostServiceImpl;
import com.wellpoint.pc2dash.util.ErrorProperties;


public class GetTotalCostAction extends Action {

	List<TotalCostBean> resultList;
	ActionResponse response = new GetTotalCostResponse();
	ErrorProperties err = ErrorProperties.getInstance();
	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetTotalCostAction.class);

	@SuppressWarnings("unchecked")
	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		//PCMSRequest request = new HashMap<String, String>();
		GetTotalCostRequest request = (GetTotalCostRequest) actionRequest;

		TotalCostServiceImpl pC2Service = new TotalCostServiceImpl();

		try {
			resultList = pC2Service.getData(request);
			ArrayList<TotalCostBean> totalCostList = (ArrayList<TotalCostBean>) pC2Service.getBeanList(resultList);

			response.setData(totalCostList);
			response.setSuccess(true);

			if (resultList.isEmpty()) {
				response.setMessage(err.getProperty("successNoData"));
			}
			else {
				response.setMessage(err.getProperty("successful"));
			}

			return response;
		}
		catch (Exception pe) {

			logger.error("Unable to get Total Cost.", pe);

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}
}
