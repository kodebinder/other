/**
 * 
 */
package com.wellpoint.pc2dash.action.costOpportunity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.dto.costOpportunity.COCRxDrugDetailBean;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.service.costOpportunity.GetCostOpportunityAverageCostPerRxDrugDetailTotalServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;

/**
 * @author AF34286
 *
 */
public class GetCostOpportunityAverageCostPerRxDrugDetailTotalAction extends Action {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.wellpoint.pc2dash.action.base.Action#process(com.wellpoint.pc2dash.
	 * action.base. ActionRequest)
	 */
	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		List<String> filteredProvGrpList = new ArrayList<String>();

		GetCOCAverageRxDrugDetailsRequest request = (GetCOCAverageRxDrugDetailsRequest) actionRequest;
		GetCostOpportunityAverageCostPerRxDrugDetailTotalResponse response = new GetCostOpportunityAverageCostPerRxDrugDetailTotalResponse();
		ErrorProperties err = ErrorProperties.getInstance();
		GetCostOpportunityAverageCostPerRxDrugDetailTotalServiceImpl service = new GetCostOpportunityAverageCostPerRxDrugDetailTotalServiceImpl();
		COCRxDrugDetailBean result = null;

		try {
			removeLobPgmPrefixes(request);
			if (StringUtils.isNotBlank(request.getCmpId())) {
				filteredProvGrpList = filterProvGrpsByKillSwitch(request);
			}

			if (null != filteredProvGrpList && !filteredProvGrpList.isEmpty()) {
				request.setProvGrpIdsWithoutClinicalCheck(StringUtils.join(filteredProvGrpList, ','));
				filteredProvGrpList = filterProvGrpsByClincalFinancialInd(request, filteredProvGrpList);
				request.setProvGrpIds(CollectionUtils.isNotEmpty(filteredProvGrpList)
						? StringUtils.join(filteredProvGrpList, ',') : Constants.DASHES);
				request.setGrpInd(Constants.GRP_IND_N);
				CommonQueries cq = new CommonQueries();
				request.setTapId(request.getMetricViewId());// TO re-use
															// available tap
															// framework.
				request.setSuppression(cq.getActiveSuppressionForSelectComponents(request));

				MetaData metaData = new MetaData();
				metaData.setReportingPeriod(cq.getReportingPeriodForCostOpportunity(Constants.AVERAGE_COST_PER_RX));
				metaData.setReportDate(cq.getReportDateForCostOpportunity(Constants.AVERAGE_COST_PER_RX));

				result = service.getData(request);

				if (null == result) {
					response.setMessage(err.getProperty("successNoData"));
				} else {
					response.setMetaData(metaData);
					response.setMessage(err.getProperty("successful"));
					response.setData(result);
					response.setTotal(service.getNoOfRecords());
				}
			}
			response.setSuccess(true);

			return response;

		} catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}

}
