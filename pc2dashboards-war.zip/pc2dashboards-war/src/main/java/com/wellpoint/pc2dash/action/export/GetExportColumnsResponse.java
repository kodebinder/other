package com.wellpoint.pc2dash.action.export;

import java.util.List;

import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.export.ExportColumn;

public class GetExportColumnsResponse extends ActionResponse {

	private String id;
	private String text;
	private List<ExportColumn> children;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public List<ExportColumn> getChildren() {
		return children;
	}

	public void setChildren(List<ExportColumn> children) {
		this.children = children;
	}
}
