package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.wellpoint.pc2dash.action.tooltip.GetPatientDetailRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.patient.HccRiskScoreMedicareData;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;


public class HccRiskScoreMedicareAndCommercialFacts extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(HccRiskScoreMedicareAndCommercialFacts.class);

	public boolean read(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void insert(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void update(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void delete(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public Collection<HccRiskScoreMedicareData> getCoolerKingOrMedicarePopupDetails(GetPatientDetailRequest request) throws Exception {

		List<HccRiskScoreMedicareData> hccDataList = new ArrayList<HccRiskScoreMedicareData>();

		StringBuilder sql = new StringBuilder()
			.append("select distinct ")
			.append(" pccg.cndtn_desc as cndtn_desc, ")
			.append("  pccg.cndtn_ind_rsn_txt as cndtn_ind_rsn, ")
			.append("  pccg.frst_idntfd_dt, ")
			.append("  coalesce(pccg.diag_desc, '---') as diag_desc, ")
			.append("  coalesce(pccg.snsitv_diag_desc, '---') as snstv_diag_desc ")
			.append("from ")
			.append("  PAT_CLNCL_CARE_GAP pccg ")
			.append("  join PAT_SMRY_FACT psf on ( ")
			.append("  pccg.PAT_ID = psf.mstr_cnsmr_dim_key ) ")
			.append("  join poit_user_scrty_acs pusa on ( ")
			.append("  psf.prov_grp_id = pusa.prov_grp_id )")
			.append("  and case ")
			.append("  when pusa.prov_org_tax_id = '0' then psf.prov_org_tax_id ")
			.append("  else pusa.prov_org_tax_id ")
			.append("  end = psf.prov_org_tax_id ")

			.append("where ")
			.append("  pusa.sesn_id = ? ")
			.append("  and pusa.enttlmnt_hash_key = ? ")
			.append("  and psf.mstr_cnsmr_dim_key = ? ")
			.append("with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());
			ps.setString(1, request.getSessionId());
			ps.setString(2, request.getEntitlementId());
			ps.setString(3, request.getMemberKey());

			executeQuery(logger, sql.toString());

			boolean attested = true;//PCMSP-18536 CommonQueries.checkAttestation(request);

			while (rs.next()) {

				HccRiskScoreMedicareData hcc = new HccRiskScoreMedicareData();
				hcc.setGapType(getString(rs, "cndtn_ind_rsn"));
				if(request.getLineOfBusiness() != null && request.getLineOfBusiness().toUpperCase().contains(Constants.MEDICAID.toUpperCase()))
					hcc.setGapDescription(getString(rs, "cndtn_desc"));
				else if(attested)
					hcc.setGapDescription(getString(rs, "cndtn_desc"));
				else
					hcc.setGapDescription(Constants.MASKED_INFO);
				hcc.setFirstIdentifiedDt(getDate(rs, "frst_idntfd_dt").equalsIgnoreCase(Constants.HIGH_END_DT) ? "---" : getDate(rs, "frst_idntfd_dt"));
				hcc.setMostRecentSvcDt(getDate(rs, "frst_idntfd_dt").equalsIgnoreCase(Constants.HIGH_END_DT) ? "---" : getDate(rs, "frst_idntfd_dt"));
				hcc.setDiagnosisDescription(getString(rs, "diag_desc"));//PCMSP-19910
				/*if (attested) {
					hcc.setDiagnosisDescription(getString(rs, "snstv_diag_desc"));

				}
				else {
					hcc.setDiagnosisDescription(getString(rs, "diag_desc"));
				}*/

				hccDataList.add(hcc);
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get HccRiskScoreMedicareData ("
				+ request.getEntitlementId() + ", "
				+ request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return hccDataList;
	}

	public boolean checkAttestation(GetPatientDetailRequest request) throws Exception {
		return CommonQueries.checkAttestation(request);
	}
}
