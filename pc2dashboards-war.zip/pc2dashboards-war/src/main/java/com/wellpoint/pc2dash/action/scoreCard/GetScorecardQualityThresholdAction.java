/**
 * 
 */
package com.wellpoint.pc2dash.action.scoreCard;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.scorecard.ScorecardQualityThresholdBean;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.scorecard.ScorecardQualityThresholdServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;

/**
 * @author AD34782
 *
 */
public class GetScorecardQualityThresholdAction extends Action {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetScorecardQualityThresholdAction.class);

	ActionResponse response = new ActionResponse();

	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		GetScorecardQualityThresholdRequest request = (GetScorecardQualityThresholdRequest) actionRequest;

		ScorecardQualityThresholdServiceImpl pC2Service = new ScorecardQualityThresholdServiceImpl();
		List<String> filteredProvGrpList = new ArrayList<String>();
		List<String> filteredProvGrpListOnAccess = null;
		String provGrpCSVWithGrpIndN = "";
		List<ScorecardQualityThresholdBean> scorecardQualityThresholdBean = new ArrayList<ScorecardQualityThresholdBean>();
		ErrorProperties err = ErrorProperties.getInstance();

		try {
			//			PCMSRequest request = getDataMap(getScorecardQualityThresholdRequest);

			//Kill switch check on Provider groups
			if (null != request) {
				//	if(StringUtils.isNotBlank(request.getCmpId())){
				filteredProvGrpList = filterProvGrpsByKillSwitch(request);
			}

			if (null != filteredProvGrpList && filteredProvGrpList.size() > 0) {
				//Clinical & Financial access check on provider groups
				filteredProvGrpListOnAccess = filterProvGrpsByClincalFinancialInd(request, filteredProvGrpList);

			}

			if (null != filteredProvGrpListOnAccess && filteredProvGrpListOnAccess.size() > 0) {
				provGrpCSVWithGrpIndN = StringUtils.join(filteredProvGrpListOnAccess, ',');
			}

			//TODO confirm if this check is necessary
			//Group Ind N list
			if (null != provGrpCSVWithGrpIndN && !provGrpCSVWithGrpIndN.isEmpty()) {
				request.setProvGrpIds(provGrpCSVWithGrpIndN);
				request.setGrpInd(Constants.GRP_IND_N);
				//TODO finish service layer and prepare response
				scorecardQualityThresholdBean = pC2Service.getData(request);
			}
			//			}

			response.setSuccess(true);
			if (null == scorecardQualityThresholdBean || (null != scorecardQualityThresholdBean && scorecardQualityThresholdBean.isEmpty())) {
				response.setMessage(err.getProperty("successNoData"));
			}
			else {
				response.setMessage(err.getProperty("successful"));
				response.setData(scorecardQualityThresholdBean);
			}

			return response;
		}
		catch (Exception pe) {
			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}

	//	private Map<String, String> getDataMap(
	//			GetScorecardQualityThresholdRequest request) {
	//		//PCMSRequest request = new HashMap<String, String>();
	//		try {
	//		QualityIndicatorsFromRequest  qualityIndFromUi = (QualityIndicatorsFromRequest) JSONUtils.convertJSONToJavaObj(request.getQualityGate() ,  "com.wellpoint.pc2dash.dto.scorecard.QualityIndicatorsFromRequest");			
	//		//request.put("sessionId", request.getSessionId());
	//		//request.put("entitlementId", request.getEntitlementId());
	//		request.put("grpInd", request.getGrpInd());
	//		//request.setCmpId(request.getCmpId());
	//		//request.setProvGrpIds(request.getProvGrpIds());
	//		request.put(Constants.USER_ACS_INFO_JSON, request.getUserAcsInfoJson());
	//		 request.put("programId", request.getProgramId());
	//		 /*
	//			 * Adding the programLobTypeCd parameter to the datamap
	//			 * The value is going to be the pgmLobTypCd
	//			 */
	//		request.put("programLobTypeCd", request.getProgramLobTypeCd());
	//        request.put("provDimKeys", request.getProviderGroupDimKey());
	//        request.put("qualityGateInd",qualityIndFromUi.getQualityGateInd());
	//		request.put("qualityGateRequest",qualityIndFromUi.getQualityGate());
	//		request.put("qualityScore",qualityIndFromUi.getQualityScore());
	//		request.put("msrmntStrtDt", request.getMeasurementPeriodStartDt());
	//		request.put("msrmntEndDt", request.getMeasurementPeriodEndDt());
	//		request.put("provGrpId", request.getProviderGroupId());
	//		request.put("provGrpDimKey", request.getProviderGroupDimKey());
	//		request.put("measurementInterval", request.getMeasurementInterval());
	//		request.put("prgmId", request.getProgramId());
	//		request.put("mdcdQltyScorTrmntnDt", request.getMdcdQltyScorTrmntnDt());
	//		request.put("mdcdQltyScorEfctvDt", request.getMdcdQltyScorEfctvDt());
	//		} catch (JsonSyntaxException e) {
	//			logger.error(e);
	//		} catch (ClassNotFoundException e) {
	//			logger.error(e);
	//		}
	//		return request;
	//	}
}
