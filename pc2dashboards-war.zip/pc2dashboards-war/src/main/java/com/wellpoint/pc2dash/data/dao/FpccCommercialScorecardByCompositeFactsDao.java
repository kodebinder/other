package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.data.dto.PCMSRequest;
import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;
import com.wellpoint.pc2dash.dto.scorecard.ScorecardCompositeBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;


public class FpccCommercialScorecardByCompositeFactsDao extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(FpccCommercialScorecardByCompositeFactsDao.class);

	public boolean read(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void insert(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void update(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void delete(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public Collection<ScorecardCompositeBean> getFpccCommercialScorecardComposites(PerformanceManagementRequest request) throws Exception {

		Collection<ScorecardCompositeBean> result = new ArrayList<ScorecardCompositeBean>();
		StringBuilder sql = new StringBuilder();

		sql = createQueryForImprovement(request)
			.append(" UNION ")
			.append(createQueryForQuality(request))
			.append(" UNION ")
			.append(createQueryForUtilization(request))
			.append(" UNION ")
			.append(createQueryForQhip(request));

		sql = StringUtil.appendWithUr(sql);

		try {

			int i = 0;

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());

			for (int q = 0; q < 4; q++) {

				ps.setString(++i, request.getProgramId());
				ps.setString(++i, request.getMeasurementPeriodStartDt());
				ps.setString(++i, request.getProvGrpIds());
				ps.setString(++i, request.getProgramLobTypeCd().toUpperCase());

				if (null != Constants.getQuarterName(request
					.getMeasurementInterval())) {
					if ("1".equalsIgnoreCase(request
						.getMeasurementInterval())) {
						ps.setString(++i, "Y");
					}
					else {
						ps.setString(++i, Constants.getQuarterName(request
							.getMeasurementInterval()));
					}
				}
				else {
					ps.setString(++i, request.getProvGrpIds());
					ps.setString(++i, request.getProgramId());
					ps.setString(++i, request.getMeasurementPeriodStartDt());
					ps.setString(++i, request.getProgramId());
				}
			}

			executeQuery(logger, sql.toString());

			while (rs.next()) {

				ScorecardCompositeBean sc = new ScorecardCompositeBean();
				sc.setCompositeId(getString(rs, "cmpst_defn_id"));
				sc.setCompositeName(getString(rs, "cmpst_nm"));
				sc.setCompositeTypeDesc(getString(rs, "cmpst_type_desc"));
				sc.setSsavUpsdDstrbnPct(getString(rs, "ssav"));
				sc.setErncntrPct(getString(rs, "erncntr"));

				result.add(sc);
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get Scorecard details.", e);
		}
		finally {

			close();
		}

		return result;
	}

	public StringBuilder createQueryForQuality(PCMSRequest request) {

		StringBuilder sql = new StringBuilder()
			.append("select cmpst_nm, cmpst_defn_id, cmpst_type_desc, sum(erncntr) as erncntr, sum(ssav) as ssav from ( ")
			.append("select ")
			.append(" smhd.cmpst_nm, ")
			.append(" smhd.cmpst_defn_id, ")
			.append(" smhd.cmpst_type_desc, ")
			.append(" ef.rdstrbtd_erncntr_pct as erncntr, ")
			.append(" ef.rdstrbtd_ssav_upsd_dstrbtn_pct as ssav, ") //PCMSP-3190 - Reverting back the code based on confirmation from business
			//.append(" ef.ssav_upsd_dstrbtn_pct as ssav, ") 
			.append(" smhd.sub_cmpst_nm ")
			.append(" from ")
			.append(" erncntr_fact ef ")
			.append(" join pgm_dim pgm on ( ")
			.append(" ef.pgm_dim_key = pgm.pgm_dim_key ")
			.append(" ) ")
			.append(" join prov_grp_dim pg on ( ")
			.append(" ef.prov_grp_dim_key = pg.prov_grp_dim_key ")
			.append(" ) ")
			.append(" join scrcrd_pgm_msr_hrchy_fact spmhf on ( ")
			.append(" ef.pgm_dim_key = spmhf.pgm_dim_key  and ")
			.append(" ef.trnch_defn_dim_key = spmhf.trnch_defn_dim_key and ")
			.append(" ef.mnth_id = spmhf.mnth_id and ")
			.append(" ef.msrmnt_prd_strt_dt = spmhf.msrmnt_prd_strt_dt ")
			.append(" ) ")
			.append(" join scrcrd_msr_hrchy_dim smhd on ( ")
			.append(" spmhf.scrcrd_msr_hrchy_dim_key = smhd.scrcrd_msr_hrchy_dim_key ")
			.append(" ) ")
			.append(" where ")
			.append(" pgm.pgm_id = ? and ")
			.append(" ef.msrmnt_prd_strt_dt = ? and ")
			.append(" pg.prov_grp_id = ? and ")
			.append(" smhd.cmpst_type_desc in ('Quality') and ")
			.append(" spmhf.pgm_lob_type_cd = ? ");

		if (null != Constants.getQuarterName(request
			.getMeasurementInterval())) {
			if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
				sql.append(" AND ef.BSLN_SCRCRD_IND = ? ");
			}
			else {
				sql.append(" AND ef.QTR_ID = ? ");
			}
		}
		else {

			sql.append(" AND EF.MNTH_ID = (SELECT MAX(EF.MNTH_ID) ");
			sql.append(" 					FROM ERNCNTR_FACT EF  ");
			sql.append(" 					INNER JOIN (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT ");
			sql.append(" 								FROM SCRCRD_PGM_MSR_HRCHY_FACT ");
			//sql.append(" 					WHERE PGM_DIM_KEY = (SELECT PGM_DIM_KEY FROM PROV_GRP_PGM_LOB_FACT WHERE PGM_ID = ? and PGM_PG_TRMNTN_DT > CURRENT_DATE GROUP BY PGM_DIM_KEY ) ");
			sql.append(" 		WHERE PGM_DIM_KEY = (SELECT PGM_DIM_KEY FROM PROV_GRP_PGM_LOB_FACT A ");
			sql.append(" 		inner join   PROV_GRP_DIM B ON A.PROV_GRP_DIM_KEY=B.PROV_GRP_DIM_KEY and  B.PROV_GRP_ID = ?");
			sql.append("		WHERE A.PGM_ID = ? and A.PGM_PG_TRMNTN_DT > CURRENT_DATE GROUP BY A.PGM_DIM_KEY) ");
			sql.append("  and  MSRMNT_PRD_STRT_DT = ? ");
			sql.append(" 								GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM ");
			sql.append(" 					ON EF.PGM_DIM_KEY = SC_PGM.PGM_DIM_KEY AND EF.MSRMNT_PRD_STRT_DT = SC_PGM.MSRMNT_PRD_STRT_DT) ");
			sql.append(" and (select max(ef.mnth_id)MAX_MON from ERNCNTR_FACT ef join PGM_DIM pd on ef.pgm_dim_key = pd.pgm_dim_key where pd.pgm_id = ? ) <=  INT(TO_CHAR(ef.msrmnt_prd_strt_dt + 15 months, 'YYYYMM')) ");


		}

		sql.append(
			" group by smhd.CMPST_NM ,smhd.CMPST_DEFN_ID, smhd.CMPST_TYPE_DESC,ef.rdstrbtd_erncntr_pct,ef.rdstrbtd_ssav_upsd_dstrbtn_pct,smhd.sub_cmpst_nm, smhd.msr_dim_key ")
			.append(" order by smhd.CMPST_NM")
			.append(") group by cmpst_nm,cmpst_defn_id, cmpst_type_desc ");

		return sql;
	}

	public StringBuilder createQueryForQhip(PCMSRequest request) {

		StringBuilder sql = new StringBuilder();
		sql.append("select cmpst_nm, cmpst_defn_id, cmpst_type_desc, sum(erncntr) as erncntr, sum(ssav) as ssav from ( ")
			.append("select ")
			.append(" smhd.cmpst_nm, ")
			.append(" smhd.cmpst_defn_id, ")
			.append(" smhd.cmpst_type_desc, ")
			.append(" ef.rdstrbtd_erncntr_pct as erncntr, ")
			.append(" ef.rdstrbtd_ssav_upsd_dstrbtn_pct as ssav, ")  
			.append(" smhd.sub_cmpst_nm, ")
			.append(" smhd.msr_dim_key ")
			.append(" from ")
			.append(" erncntr_fact ef ")
			.append(" join pgm_dim pgm on ( ")
			.append(" ef.pgm_dim_key = pgm.pgm_dim_key ")
			.append(" ) ")
			.append(" join prov_grp_dim pg on ( ")
			.append(" ef.prov_grp_dim_key = pg.prov_grp_dim_key ")
			.append(" ) ")
			.append(" join scrcrd_pgm_msr_hrchy_fact spmhf on ( ")
			.append(" ef.pgm_dim_key = spmhf.pgm_dim_key  and ")
			.append(" ef.trnch_defn_dim_key = spmhf.trnch_defn_dim_key and ")
			.append(" ef.mnth_id = spmhf.mnth_id and ")
			.append(" ef.msrmnt_prd_strt_dt = spmhf.msrmnt_prd_strt_dt ")
			.append(" ) ")
			.append(" join scrcrd_msr_hrchy_dim smhd on ( ")
			.append(" spmhf.scrcrd_msr_hrchy_dim_key = smhd.scrcrd_msr_hrchy_dim_key ")
			.append(" ) ")
			.append(" where ")
			.append(" pgm.pgm_id = ? and ")
			.append(" ef.msrmnt_prd_strt_dt = ? and ")
			.append(" pg.prov_grp_id = ? and ")
			.append(" smhd.cmpst_type_desc = 'Q-HIP' and ")
			.append(" spmhf.pgm_lob_type_cd = ? ");

		if (null != Constants.getQuarterName(request
			.getMeasurementInterval())) {
			if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
				sql.append(" AND ef.BSLN_SCRCRD_IND = ? ");
			}
			else {
				sql.append(" AND ef.QTR_ID = ? ");
			}
		}
		else {

			sql.append(" AND EF.MNTH_ID = (SELECT MAX(EF.MNTH_ID) ");
			sql.append(" 					FROM ERNCNTR_FACT EF  ");
			sql.append(" 					INNER JOIN (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT ");
			sql.append(" 								FROM SCRCRD_PGM_MSR_HRCHY_FACT ");
			//sql.append(" 			WHERE PGM_DIM_KEY = (SELECT PGM_DIM_KEY FROM PROV_GRP_PGM_LOB_FACT WHERE PGM_ID = ? and PGM_PG_TRMNTN_DT > CURRENT_DATE GROUP BY PGM_DIM_KEY ) ");
			sql.append(" 		WHERE PGM_DIM_KEY = (SELECT PGM_DIM_KEY FROM PROV_GRP_PGM_LOB_FACT A ");
			sql.append(" 		inner join   PROV_GRP_DIM B ON A.PROV_GRP_DIM_KEY=B.PROV_GRP_DIM_KEY and  B.PROV_GRP_ID = ?");
			sql.append("		WHERE A.PGM_ID = ? and A.PGM_PG_TRMNTN_DT > CURRENT_DATE GROUP BY A.PGM_DIM_KEY) ");
			sql.append("  and  MSRMNT_PRD_STRT_DT = ? ");
			sql.append(" 								GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM ");
			sql.append(" 					ON EF.PGM_DIM_KEY = SC_PGM.PGM_DIM_KEY AND EF.MSRMNT_PRD_STRT_DT = SC_PGM.MSRMNT_PRD_STRT_DT) ");
			sql.append(" and (select max(ef.mnth_id)MAX_MON from ERNCNTR_FACT ef join PGM_DIM pd on ef.pgm_dim_key = pd.pgm_dim_key where pd.pgm_id = ? ) <=  INT(TO_CHAR(ef.msrmnt_prd_strt_dt + 15 months, 'YYYYMM')) ");

		}

		sql.append(
			" group by smhd.CMPST_NM ,smhd.CMPST_DEFN_ID, smhd.CMPST_TYPE_DESC, ef.rdstrbtd_erncntr_pct, ef.rdstrbtd_ssav_upsd_dstrbtn_pct, smhd.sub_cmpst_nm, smhd.msr_dim_key  ")
			.append(" order by smhd.CMPST_NM")
			.append(") group by cmpst_nm, cmpst_defn_id, cmpst_type_desc ");

		return sql;
	}

	public StringBuilder createQueryForUtilization(PCMSRequest request) {

		StringBuilder sql = new StringBuilder()
			.append("select cmpst_nm, cmpst_defn_id, cmpst_type_desc, sum(erncntr) as erncntr, sum(ssav) as ssav from ( ")
			.append("select ")
			.append(" smhd.cmpst_nm, ")
			.append(" smhd.cmpst_defn_id, ")
			.append(" smhd.cmpst_type_desc, ")
			.append(" ef.rdstrbtd_erncntr_pct as erncntr, ")
			.append(" ef.rdstrbtd_ssav_upsd_dstrbtn_pct as ssav, ")
			//.append(" ef.ssav_upsd_dstrbtn_pct as ssav, ") //PCMSP-3190 - Reverting back the code based on confirmation from business
			.append(" smhd.sub_cmpst_nm, ")
			.append(" smhd.msr_dim_key ")
			.append(" from ")
			.append(" erncntr_fact ef ")
			.append(" join pgm_dim pgm on ( ")
			.append(" ef.pgm_dim_key = pgm.pgm_dim_key ")
			.append(" ) ")
			.append(" join prov_grp_dim pg on ( ")
			.append(" ef.prov_grp_dim_key = pg.prov_grp_dim_key ")
			.append(" ) ")
			.append(" join scrcrd_pgm_msr_hrchy_fact spmhf on (")
			.append(" ef.pgm_dim_key = spmhf.pgm_dim_key  and ")
			.append(" ef.trnch_defn_dim_key = spmhf.trnch_defn_dim_key and ")
			.append(" ef.mnth_id = spmhf.mnth_id and ")
			.append(" ef.msrmnt_prd_strt_dt = spmhf.msrmnt_prd_strt_dt ")
			.append(" ) ")
			.append(" join scrcrd_msr_hrchy_dim smhd on ( ")
			.append(" spmhf.scrcrd_msr_hrchy_dim_key = smhd.scrcrd_msr_hrchy_dim_key ")
			.append(" ) ")
			.append(" where ")
			.append(" pgm.pgm_id = ? and ")
			.append(" ef.msrmnt_prd_strt_dt = ? and ")
			.append(" pg.prov_grp_id = ? and ")
			.append(" smhd.cmpst_type_desc = 'Utilization' and ")
			.append(" spmhf.pgm_lob_type_cd = ? ");

		if (null != Constants.getQuarterName(request
			.getMeasurementInterval())) {
			if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
				sql.append(" AND ef.BSLN_SCRCRD_IND = ? ");
			}
			else {
				sql.append(" AND ef.QTR_ID = ? ");
			}
		}
		else {

			sql.append(" AND EF.MNTH_ID = (SELECT MAX(EF.MNTH_ID) ");
			sql.append(" 					FROM ERNCNTR_FACT EF  ");
			sql.append(" 					INNER JOIN (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT ");
			sql.append(" 								FROM SCRCRD_PGM_MSR_HRCHY_FACT ");
			//sql.append(" 		WHERE PGM_DIM_KEY = (SELECT PGM_DIM_KEY FROM PROV_GRP_PGM_LOB_FACT WHERE PGM_ID = ? and PGM_PG_TRMNTN_DT > CURRENT_DATE GROUP BY PGM_DIM_KEY ) ");
			sql.append(" 		WHERE PGM_DIM_KEY = (SELECT PGM_DIM_KEY FROM PROV_GRP_PGM_LOB_FACT A ");
			sql.append(" 		inner join   PROV_GRP_DIM B ON A.PROV_GRP_DIM_KEY=B.PROV_GRP_DIM_KEY and  B.PROV_GRP_ID = ?");
			sql.append("		WHERE A.PGM_ID = ? and A.PGM_PG_TRMNTN_DT > CURRENT_DATE GROUP BY A.PGM_DIM_KEY) ");
			sql.append("  and  MSRMNT_PRD_STRT_DT = ? ");
			sql.append(" 								GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM ");
			sql.append(" 					ON EF.PGM_DIM_KEY = SC_PGM.PGM_DIM_KEY AND EF.MSRMNT_PRD_STRT_DT = SC_PGM.MSRMNT_PRD_STRT_DT) ");
			sql.append(" and (select max(ef.mnth_id)MAX_MON from ERNCNTR_FACT ef join PGM_DIM pd on ef.pgm_dim_key = pd.pgm_dim_key where pd.pgm_id = ? ) <=  INT(TO_CHAR(ef.msrmnt_prd_strt_dt + 15 months, 'YYYYMM')) ");

		}

		sql.append(
			" group by smhd.CMPST_NM ,smhd.CMPST_DEFN_ID, smhd.CMPST_TYPE_DESC, ef.rdstrbtd_erncntr_pct, ef.rdstrbtd_ssav_upsd_dstrbtn_pct, smhd.sub_cmpst_nm, smhd.msr_dim_key ")
			.append(" order by smhd.CMPST_NM")
			.append(") group by cmpst_nm, cmpst_defn_id, cmpst_type_desc ");

		return sql;
	}

	public StringBuilder createQueryForImprovement(PCMSRequest request) {

		StringBuilder sql = new StringBuilder()
			.append("select cmpst_nm, cmpst_defn_id, cmpst_type_desc, sum(erncntr) as erncntr, sum(ssav) as ssav from ( ")
			.append("select ")
			.append(" ipgsf.rdstrbtd_erncntr_pct as erncntr, ")
			.append(" ipgsf.rdstrbtd_ssav_upsd_dstrbtn_pct as ssav, ")
			.append(" smhd.cmpst_nm, ")
			.append(" smhd.cmpst_defn_id, ")
			.append(" smhd.cmpst_type_desc ")
			.append(" from ")
			.append(" imprv_prov_grp_smry_fact ipgsf ")
			.append(" join erncntr_fact ef on ( ")
			.append(" IPGSF.MNTH_ID = EF.MNTH_ID and ")
			.append(" ef.pgm_dim_key = ipgsf.pgm_dim_key and ")
			.append(" ef.prov_grp_dim_key = ipgsf.prov_grp_dim_key and ")
			.append(" ipgsf.msrmnt_prd_strt_dt = ef.msrmnt_prd_strt_dt ")
			.append(" ) ")
			.append(" join pgm_dim pgm on ( ")
			.append(" ipgsf.pgm_dim_key = pgm.pgm_dim_key ")
			.append(" ) ")
			.append(" join prov_grp_dim pg on ( ")
			.append(" ipgsf.prov_grp_dim_key = pg.prov_grp_dim_key ")
			.append(" ) ")
			.append(" join scrcrd_pgm_msr_hrchy_fact spmhf on ( ")
			.append(" ipgsf.pgm_dim_key = spmhf.pgm_dim_key  and ")
			.append(" ipgsf.mnth_id = spmhf.mnth_id and ")
			.append(" ipgsf.msrmnt_prd_strt_dt = spmhf.msrmnt_prd_strt_dt ")
			.append(" ) ")
			.append(" join scrcrd_msr_hrchy_dim smhd on ( ")
			.append(" spmhf.scrcrd_msr_hrchy_dim_key = smhd.scrcrd_msr_hrchy_dim_key and ")
			.append(" ipgsf.scrcrd_msr_hrchy_dim_key = smhd.scrcrd_msr_hrchy_dim_key ")
			.append(" ) ")
			.append(" where ")
			.append(" pgm.pgm_id = ? and ")
			.append(" ipgsf.msrmnt_prd_strt_dt = ? and ")
			.append(" pg.prov_grp_id = ? and ")
			.append(" spmhf.pgm_lob_type_cd = ? ");

		if (null != Constants.getQuarterName(request
			.getMeasurementInterval())) {
			if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
				sql.append(" AND ipgsf.BSLN_SCRCRD_IND = ? ");
			}
			else {
				sql.append(" AND ipgsf.QTR_ID = ? ");
			}
		}
		else {

			sql.append(" AND ipgsf.MNTH_ID = (SELECT MAX(IPGSF.MNTH_ID) ");
			sql.append(" 					FROM IMPRV_PROV_GRP_SMRY_FACT IPGSF ");
			sql.append(" 					INNER JOIN (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT  ");
			sql.append(" 								FROM SCRCRD_PGM_MSR_HRCHY_FACT ");
			//sql.append(" 					WHERE PGM_DIM_KEY = (SELECT PGM_DIM_KEY FROM PROV_GRP_PGM_LOB_FACT WHERE PGM_ID = ? and PGM_PG_TRMNTN_DT > CURRENT_DATE GROUP BY PGM_DIM_KEY ) ");
			sql.append(" 		WHERE PGM_DIM_KEY = (SELECT PGM_DIM_KEY FROM PROV_GRP_PGM_LOB_FACT A ");
			sql.append(" 		inner join   PROV_GRP_DIM B ON A.PROV_GRP_DIM_KEY=B.PROV_GRP_DIM_KEY and  B.PROV_GRP_ID = ? ");
			sql.append("		WHERE A.PGM_ID = ? and A.PGM_PG_TRMNTN_DT > CURRENT_DATE GROUP BY A.PGM_DIM_KEY) ");
			sql.append("  and  MSRMNT_PRD_STRT_DT = ? ");
			sql.append(" 								GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM ");
			sql.append(" 					ON IPGSF.PGM_DIM_KEY = SC_PGM.PGM_DIM_KEY AND IPGSF.MSRMNT_PRD_STRT_DT = SC_PGM.MSRMNT_PRD_STRT_DT) ");
			//sql.append(" and (select max(ef.mnth_id)MAX_MON from IMPRV_PROV_GRP_SMRY_FACT ef join PGM_DIM pd on ef.pgm_dim_key = pd.pgm_dim_key where pd.pgm_id = ? ) <=  INT(TO_CHAR(ef.msrmnt_prd_strt_dt + 15 months, 'YYYYMM')) " );
			sql.append(" and (select max(ef.mnth_id)MAX_MON from ERNCNTR_FACT ef join PGM_DIM pd on ef.pgm_dim_key = pd.pgm_dim_key where pd.pgm_id = ? ) <=  INT(TO_CHAR(ef.msrmnt_prd_strt_dt + 15 months, 'YYYYMM')) ");
		}

		sql.append(" group by smhd.CMPST_NM ,smhd.CMPST_DEFN_ID, smhd.CMPST_TYPE_DESC,ipgsf.rdstrbtd_erncntr_pct,ipgsf.rdstrbtd_ssav_upsd_dstrbtn_pct,smhd.msr_dim_key ")
			.append(") group by cmpst_nm,cmpst_defn_id, cmpst_type_desc ");

		return sql;
	}
}
