package com.wellpoint.pc2dash.data.dao;


import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.costOpportunity.GetAmbulatorySurgeryDetailRequest;
import com.wellpoint.pc2dash.action.costOpportunity.GetTotalSurgeryCountRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.costOpportunity.TotalSurgeryCountBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;

//PCMSP-21873
public class GetTotalSurgeryCountDao extends ServiceImpl {
	
	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(EpisodesPatientsDao.class);

	public List<TotalSurgeryCountBean> getData(GetTotalSurgeryCountRequest request, boolean boolFalse, int index, int limit) throws Exception {
		// TODO Auto-generated method stub
		List<TotalSurgeryCountBean> result = new ArrayList<TotalSurgeryCountBean>();
		setRowCount(0);
		
		StringBuilder query = new StringBuilder()
				.append("Select dtl.PRMRY_PROC as primaryProcedure,")
				.append("sum(case when dtl.HCOST_IND ='N' then 0 else ctgry.COST_OPRTNTY_AMT end) as costOpportunity,")
				.append("count(1) as unitCount")
				.append("from coc_asc_dtl_smry dtl")
				.append("join COC_ASC_CTGRY_SMRY ctgry")
				.append("on (ctgry.PROV_GRP_ID= dtl.PROV_GRP_ID ")
				.append("and  ctgry.PROV_GRP_DIM_KEY = dtl.PROV_GRP_DIM_KEY")
				.append(" and  ctgry.PROV_ORG_DIM_KEY=dtl.PROV_ORG_DIM_KEY ")
				.append("and ctgry.PGM_DIM_KEY=dtl.PGM_DIM_KEY")
				.append(" and ctgry.LOB_DIM_KEY=dtl.LOB_DIM_KEY) ")
				.append("join poit_user_scrty_acs pusa ")
				.append("on (dtl.prov_grp_id = pusa.prov_grp_id)")
				.append("where pusa.sesn_id = ?")
				.append("and  pusa.enttlmnt_hash_key= ?")
				.append("and dtl.FCLTY_TAX_ID= ? ")
				.append("and dtl.lob_desc in ('Commercial')");
		
		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and ctgry.prov_grp_id in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(
				StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and ctgry.pgm_dim_key in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(
				StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and ctgry.lob_desc in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(
				StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}
				
		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and dtl.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and dtl.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys()) + ") ");
		}
		if (StringUtil.isNotBlankOrFalse(request.getProcedureCode())) {
			query.append(" and ctgry.SUB_MTRC_CD in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProcedureCode())
				+ ") ");
		}

		
		query.append("group by dtl.PRMRY_PROC with ur;");
				
		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());

			buildPreparedStatement(request, i, boolFalse, index, limit);

			executeQuery(logger, query.toString());

			result = convertSelectedRowsToObjects(rs, request, boolFalse);

		}
		catch (Exception e) {

			throw new Exception("Unable to get TotalSurgeryCount(" + request.getEntitlementId() + ", "
				+ request.getFacilityName() + ").", e);
		}
		finally {

			close();
		}
				
		return null;
	}

private List<TotalSurgeryCountBean> convertSelectedRowsToObjects(ResultSet rs, GetTotalSurgeryCountRequest request,
			boolean boolFalse) throws SQLException {
		// TODO Auto-generated method stub
	
	List<TotalSurgeryCountBean> totalSurgeryCount = new ArrayList<TotalSurgeryCountBean> ();
	while (rs.next()) {
		TotalSurgeryCountBean item = new TotalSurgeryCountBean();
		if (null != rs.getString("unitCount")) {
			item.setUnitCount(rs.getString("unitCount"));
		}
		if (null != rs.getString("primaryProcedure")) {
			item.setPrimaryProcedure(rs.getString("primaryProcedure"));
		}
		if (null != rs.getString("costOpportunity")) {
			item.setCostOpportunity( rs.getBigDecimal("COST_OPRTNTY_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
		}
		
	}
	
	if (getRowCount() == 0) {
		setRowCount(totalSurgeryCount.size());
	}
		return totalSurgeryCount;
	}

private void buildPreparedStatement(GetTotalSurgeryCountRequest request, int i, boolean exportFlag, int index, int limit) throws SQLException {
		
		int start = 0;
		int stop = 0;
		
		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());
		
		if (StringUtil.isNotBlankOrFalse(request.getFacilityTaxId())) {
			ps.setString(++i, request.getFacilityTaxId());
		}
		
		
		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProcedureCode())) { // PCMSP-7421
			String[] array = request.getProcedureCode().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}
		
		start = index;
		stop = limit;
}
}
