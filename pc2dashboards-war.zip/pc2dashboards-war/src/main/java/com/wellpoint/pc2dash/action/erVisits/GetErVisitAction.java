package com.wellpoint.pc2dash.action.erVisits;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.patient.MstrCnsmrFactAndOthers;
import com.wellpoint.pc2dash.dto.patient.Patient;
import com.wellpoint.pc2dash.dto.tap.ervisits.PopulationTapMetadata;
import com.wellpoint.pc2dash.exception.PC2Exception;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportGridColumn;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.population.ErVisitExport;
import com.wellpoint.pc2dash.export.population.TapChartExport;
import com.wellpoint.pc2dash.service.erVisits.EmergencyRoomServiceImpl;
import com.wellpoint.pc2dash.service.tap.ervisits.PopulationTapServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;


public class GetErVisitAction extends Action {

	@Override
	public ActionResponse process(ActionRequest aRequest) {

		GetErVisitResponse response = new GetErVisitResponse();
		ActionRequest actionRequest = aRequest;
        GetErVisitRequest request;
        
        try {
          request = castActionRequest(actionRequest);
        } catch (Exception e) {
          Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
          return pce.checkException(e, response);
        }
        
		ErrorProperties err = ErrorProperties.getInstance();

		EmergencyRoomServiceImpl service = new EmergencyRoomServiceImpl();
		List<String> grps = new ArrayList<String>();

		try {

			removeLobPgmPrefixes(request);
			prepareChronicCareGapMap(request);

            //Kill switch check on Provider groups
            grps = groupKillSwitch(request, grps);

			prepareRASuppressionCond(request);
			prepareLPRSuppressionCond(request);

            // Clinical access check on provider groups
            grps = checkClinicalAccess(request, grps);

			/*
			 * Determine whether Action Center is suppressed - it'll play a part in deciding whether to display
			 * the "i" icon in all of the Clinical Programs columns in Population Management and
			 * Performance Management drill-downs.
			 * 
			 * Determine which LOBs are suppressed - it'll play a part in deciding whether to replace the Total Cost
			 * and HCC values with dashes.
			 */
			CommonQueries cq = new CommonQueries();
			request.setGroupsWithActionCenterSuppressed(cq.getGroupsWithComponentSuppressed(request, Constants.AC_RF_CARDCONTAINER));
			request.setSuppression(cq.getActiveSuppressionForSelectComponents(request));
			request.setUnsuppressedLOBsTotalCost(getLOBsWithoutTotalCostSuppressed(request));

            if (null != grps && !grps.isEmpty()) {

                generateResponse(response, request, err, service);
            }

			response.setSuccess(true);
			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}

	  /**
	   * @param request
	   * @param grps
	   * @return
	   * @throws JsonSyntaxException
	   * @throws ClassNotFoundException
	   */
	  private List<String> checkClinicalAccess(GetErVisitRequest request, List<String> grps)
	      throws ClassNotFoundException {
	    List<String> groups = grps;
	    if (null != groups && !groups.isEmpty()) {

	        request.setProvGrpIdsWithoutClinicalCheck(StringUtils.join(groups, ','));
	        groups = filterProvGrpsByClinicalInd(request, groups);
	        request.setProvGrpIds(StringUtils.join(groups, ','));
	    }
	    return groups;
	  }

	  /**
	   * @param request
	   * @param grps
	   * @return
	   */
	  private List<String> groupKillSwitch(GetErVisitRequest request, List<String> grps) {
	    List<String> groups = grps;
	    if (StringUtils.isNotBlank(request.getCmpId())) {
	        groups = filterProvGrpsByKillSwitch(request);
	    }
	    return groups;
	  }

	  /**
	   * Used to reduce cyclomatic complexity
	   * 
	   * @param response
	   * @param request
	   * @param err
	   * @param service
	   * @throws PC2Exception
	   * @throws Exception
	   */
	  private void generateResponse(GetErVisitResponse response, GetErVisitRequest request,
	      ErrorProperties err, EmergencyRoomServiceImpl service) throws Exception {
	    if (StringUtil.isExportDest(request.getDest())) {

	        populateExportProcessor(request, service);
	    }
	    else {

	        populateResponse(response, request, err, service);
	    }
	  }

	  /**
	   * Used to reduce cyclomatic complexity
	   * 
	   * @param response
	   * @param request
	   * @param err
	   * @param service
	   * @throws PC2Exception
	   * @throws Exception
	   */
	  private void populateResponse(GetErVisitResponse response, GetErVisitRequest request,
	      ErrorProperties err, EmergencyRoomServiceImpl service) throws Exception {
	    List<MstrCnsmrFactAndOthers> resultList = service.getData(request);
	    List<Patient> patientList = service.getBeanList(resultList, request);
	    PopulationTapMetadata metaData = new PopulationTapMetadata(buildMetaData(request, service), null);
	    
	    if(StringUtil.isNotBlankOrFalse(request.getTapId())
	    		&& Constants.ER_POP_TAP_ID.equalsIgnoreCase(request.getTapId())){
	    	PopulationTapServiceImpl tapService = new PopulationTapServiceImpl();
	    	metaData.setErVisitCost(tapService.getERcost(request).getErVisitCost());
	    }

	    if (null != resultList && !resultList.isEmpty()) {

	    	response.setData(patientList);
	    	response.setMetaData(metaData);
	    	response.setMessage(err.getProperty("successful"));
	    	response.setExportTotal(service.getTotalExport());
	    	response.setTotal(service.getRowCount());
	    }
	    else {

	        response.setMessage(err.getProperty("successNoData"));
	    }
	  }

	  /**
	   * Used to reduce cyclomatic complexity
	   * 
	   * @param request
	   * @param service
	   * @throws PC2Exception
	   */
	  private void populateExportProcessor(GetErVisitRequest request, EmergencyRoomServiceImpl service)
	      throws PC2Exception {
	    if (StringUtil.isChartExport(request.getChartImageData())) {
	    	String tapId = null;
	    	if(StringUtils.equalsIgnoreCase(request.getTapId(), "avoidableervisitschart")){
	    		tapId = Constants.TOP_10_ER_TAP_REPORT;
	    	}
	    	else if(StringUtils.equalsIgnoreCase(request.getTapId(), Constants.ER_POP_TAP_ID)) {
	    		tapId =  Constants.ER_TAP_REPORT;
	    	}
	    	TapChartExport exp = new TapChartExport(request, tapId);	
	        ExportProcessor.getInstance().submit(exp);
	    }
	    else {
	        List<ExportGridColumn> columns = service.buildExportGridColumns(request);
	        ErVisitExport exp = new ErVisitExport(request, columns);

	        ExportProcessor.getInstance().submit(exp);
	    }
	  }

	  /**
	   * Verifies that incoming ActionRequest is an instance of GetErVisitRequest
	   * @param actionRequest
	   * @return
	   * @throws Exception
	   */
	  private GetErVisitRequest castActionRequest(ActionRequest actionRequest) throws PC2Exception {
	    if(actionRequest instanceof GetErVisitRequest){
	      return (GetErVisitRequest) actionRequest;
	    }
	    
	      throw new PC2Exception("Incoming parameter: ActionRequest is not an instance of GetErVisitRequest");
	  }
}
