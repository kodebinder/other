package com.wellpoint.pc2dash.action.tooltip;

import com.wellpoint.pc2dash.action.medicalCostServiceDetails.GetMedicalCostServiceDetailsRequest;

public class GetMLRRangesRequest extends GetMedicalCostServiceDetailsRequest {

}
