package com.wellpoint.pc2dash.data.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.costOpportunity.GetEvidenceBasedCareVariationsCategoryRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.costOpportunity.EvidenceBasedCareVariationsCategoryBean;
import com.wellpoint.pc2dash.dto.costOpportunity.MinimumCriteriaBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class EvidenceBasedCareVariationsCategoryDao extends ServiceImpl {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(EvidenceBasedCareVariationsCategoryDao.class);
	private boolean displayDashes = false;
	private boolean displayDashesSummarySpl = false;

	public List<EvidenceBasedCareVariationsCategoryBean> getEBCVCategories(GetEvidenceBasedCareVariationsCategoryRequest request, boolean exportFlag, int index, int limit)
		throws Exception {
		List<EvidenceBasedCareVariationsCategoryBean> ebcvCategories = new ArrayList<EvidenceBasedCareVariationsCategoryBean>();

		String dir = request.getSort().get(0).getDirection();
		String masked = "asc".equalsIgnoreCase(dir) ? String.valueOf(Integer.MAX_VALUE) : String.valueOf(Integer.MIN_VALUE); // we want masked values to always be at the bottom, so use either the biggest or smallest value, depending

		String dashesClause =
			" sum(cecs.MBR_ELGBL_SLCT_SRVC_CNT) < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_EBC_MIN_TOTL_EVNT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG') "; // PCMSP-18378

		String multiplePgmCheck_10_Perc = " or  ((SUM(count(distinct cecs.BNCHMRK_PCTILE_10_NBR)) over (partition by cecs.SUB_MTRC_CD, cecs.SUB_MTRC_NM)) > 1) ";
		String multiplePgmCheck_90_Perc = " or  ((SUM(count(distinct cecs.BNCHMRK_PCTILE_90_NBR)) over (partition by cecs.SUB_MTRC_CD, cecs.SUB_MTRC_NM)) > 1) ";

		MinimumCriteriaBean minCritSpl = new MinimumCriteriaBean(/*"MBR_SPCFD_SRVC_CNT",*/"MBR_ELGBL_SLCT_SRVC_CNT", "COC_EBC_CTGRY_SMRY", "COC_EBC_MIN_TOTL_EVNT", null); //PCMSP-6868, PCMSP-18378

		CommonQueries cq = new CommonQueries(); //PCMSP-6868
		displayDashesSummarySpl = cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request, minCritSpl); //PCMSP-6867

		String dashesClauseSummary = " or ( true = " + displayDashesSummarySpl + ") "; //PCMSP-6868

		StringBuilder sql = new StringBuilder()
			.append(" select b.* ")
			.append(" from ( ")
			.append(" select a.* ")
			.append("	,row_number() over (")
			.append("		order by ")
			.append(buildSortClause(request))
			.append(" ) as row_nbr ")
			.append(" from ( ")
			.append(" select ")
			.append(" cecs.SUB_MTRC_CD ")
			.append(" ,cecs.SUB_MTRC_NM ")

			.append(" ,case when ").append(dashesClause).append(dashesClauseSummary).append(" then ").append(masked)
			.append(" when sum(cecs.COST_OPRTNTY_AMT) >= 0 "
				+ "then sum(cecs.COST_OPRTNTY_AMT) else 0 end as COST_OPRTNTY_AMT ")

			.append(" ,case when ").append(dashesClause).append(dashesClauseSummary).append(" then ").append(masked)
			.append(" when sum(cecs.COST_OPRTNTY_AMT) >= 0 "
				+ "then CAST(sum(cecs.COST_OPRTNTY_AMT) * 0.1 as decimal(18,4)) else 0 end as COST_OPRTNTY_10_PCTAG_AMT ")

			.append(" ,case when ").append(dashesClause).append(dashesClauseSummary).append(" then ").append(masked)
			.append(" when sum(cecs.COST_OPRTNTY_AMT)>=0 and ILV.MEM_MNTH > 0 "
				+ "then CAST(sum(cecs.COST_OPRTNTY_AMT) as decimal(18,4)) / cast(ILV.MEM_MNTH as decimal (18,4)) else 0.00 end as PMPM_OPRTNTY_AMT ")

			.append(" ,case when ").append(dashesClause).append(dashesClauseSummary).append(" then ").append(masked)
			.append(" when sum(cecs.COST_OPRTNTY_AMT)>=0 and ILV.MEM_MNTH > 0 "
				+ "then CAST(sum(cecs.COST_OPRTNTY_AMT) * 0.1 as decimal(18,4)) / cast(ILV.MEM_MNTH as decimal (18,4)) else 0.00 end as PMPM_OPRTNTY_10_PCTAG_AMT ")

			.append(" ,case when ").append(" sum(cecs.MBR_SPCFD_SRVC_CNT)>=0 ").append(" then ").append(" sum(cecs.MBR_SPCFD_SRVC_CNT) ")
			.append(" else 0 end as MBR_SPCFD_SRVC_CNT ")
			.append(" ,case when ").append(" sum(cecs.MBR_ELGBL_SLCT_SRVC_CNT)>=0 ").append(" then ").append(" sum(cecs.MBR_ELGBL_SLCT_SRVC_CNT) ")
			.append(" else 0 end as MBR_ELGBL_SLCT_SRVC_CNT ")

			.append(" ,case when  ").append(dashesClause).append(dashesClauseSummary).append(" then ").append(masked)
			.append(" when sum(cecs.MBR_SPCFD_SRVC_CNT) >= 0 and sum(cecs.MBR_ELGBL_SLCT_SRVC_CNT) > 0 "
				+ "then cast((cast (sum(cecs.MBR_SPCFD_SRVC_CNT) as Decimal(18,4)) / cast(sum(cecs.MBR_ELGBL_SLCT_SRVC_CNT) as decimal(18,4)))*1000   as decimal(18,4)) else 0.00 end as CURRENT_PERF_RATE ")

			.append(" ,case when ").append(dashesClause).append(dashesClauseSummary).append(multiplePgmCheck_90_Perc).append(" then ").append(masked)
			.append(" else MAX(cecs.BNCHMRK_PCTILE_90_NBR) end as BNCHMRK_90_PCTILE_AMT")
			.append(" ,case when ").append(dashesClause).append(dashesClauseSummary).append(multiplePgmCheck_10_Perc).append(" then ").append(masked)
			.append(" else MAX(cecs.BNCHMRK_PCTILE_10_NBR) end as BNCHMRK_10_PCTILE_AMT")

			.append(" ,count(*) over () as row_cnt")
			.append(" ,case when ").append(dashesClause).append(dashesClauseSummary).append(" then 'Y' else 'N' end as dsply_dashes ")
			.append(" ,SUM(count(distinct cecs.BNCHMRK_PCTILE_90_NBR)) over (partition by cecs.SUB_MTRC_CD, cecs.SUB_MTRC_NM) as BNCH_90_CNT ")
			.append(" ,SUM(count(distinct cecs.BNCHMRK_PCTILE_10_NBR)) over (partition by cecs.SUB_MTRC_CD, cecs.SUB_MTRC_NM) as BNCH_10_CNT ")

			.append(" from")
			.append(" COC_EBC_CTGRY_SMRY cecs")
			.append(" join (select  ")
			.append(" nvl(SUM(MM.MBR_MNTH_12_CNT),0) as MEM_MNTH ")
			.append(" FROM  PAT_SMRY_FACT PSF ")
			.append(" INNER JOIN MSTR_CNSMR_MBR_MNTH_FACT MM ON ")
			.append(" MM.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY ")
			.append(" AND MM.RCRD_STTS_CD = 'ACT' ")
			.append(" AND PSF.ATRBN_STTS_CD = 'ACTIVE' ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			sql.append(" and psf.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			sql.append(" and psf.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {

			sql.append(" and psf.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");

		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			sql.append(" and psf.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			sql.append(" and psf.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}


		sql.append(" ) as ILV on 1=1 ")
			.append(" join poit_user_scrty_acs pusa on (")
			.append(" cecs.prov_grp_id = pusa.prov_grp_id ")
			.append(" and case")
			.append(" when pusa.prov_org_tax_id = '0' then cecs.prov_org_tax_id")
			.append("  else pusa.prov_org_tax_id")
			.append("  end = cecs.prov_org_tax_id")
			.append("  )")
			.append(" where")
			.append("  pusa.sesn_id = ? ")
			.append(" and pusa.enttlmnt_hash_key = ? ");


		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			sql.append(" and cecs.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			sql.append(" and cecs.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {

			sql.append(" and cecs.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");

		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			sql.append(" and cecs.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			sql.append(" and cecs.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getCategoryCode())) {
			sql.append(" and cecs.sub_mtrc_cd in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getCategoryCode())
				+ ") ");
		}

		sql.append(
			" and cecs.MBR_ELGBL_SLCT_SRVC_CNT>0  group by  cecs.SUB_MTRC_CD, cecs.SUB_MTRC_NM, ILV.MEM_MNTH  ")
			.append(") a ")
			.append(") b ")
			.append(" where b.row_nbr between ? and ? ")
			.append(" order by b.row_nbr ")
			.append(" with ur ");

		try {
			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			int start = 0;
			int stop = 0;
			prepareStatement(logger, sql.toString());

			//For PM PM Calculations : Starts


			// Group Ids
			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// Program filters
			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// LOB filters
			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// Organization filter
			if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
				String[] array = request.getProvDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, StringUtil.parseProviderId(item));
				}
			}
			if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
				String[] array = request.getOrgDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			//For PMPM Calculation : Ends

			ps.setString(++i, request.getSessionId());
			ps.setString(++i, request.getEntitlementId());

			// Group Ids
			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// Program filters
			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// LOB filters
			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// Organization filter
			if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
				String[] array = request.getProvDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, StringUtil.parseProviderId(item));
				}
			}
			if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
				String[] array = request.getOrgDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}
			if (StringUtil.isNotBlankOrFalse(request.getCategoryCode())) {
				String[] array = request.getCategoryCode().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}
			if (!exportFlag) {
				start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
				stop = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
			}
			else {
				start = index;
				stop = limit;
			}
			ps.setInt(++i, start + 1);
			ps.setInt(++i, start + stop);

			executeQuery(logger, sql.toString());
			ebcvCategories = convertSelectedRowsToObjects(rs, request, exportFlag);
		}
		catch (Exception e) {
			throw new Exception("Exception during EvidenceBasedCareVariationsCategoryDao (" + request.toString() + ").", e);
		}
		finally {

			close();
		}
		return ebcvCategories;
	}

	private List<EvidenceBasedCareVariationsCategoryBean> convertSelectedRowsToObjects(ResultSet rs, GetEvidenceBasedCareVariationsCategoryRequest request, boolean exportFlag)
		throws Exception {
		List<EvidenceBasedCareVariationsCategoryBean> resultList = new ArrayList<EvidenceBasedCareVariationsCategoryBean>();

		while (rs.next()) {
			
			setTotalExport(rs.getInt("row_cnt"));   
			
			if (rs.getString("dsply_dashes") != null && rs.getString("dsply_dashes").equalsIgnoreCase(Constants.Y)) {
				displayDashes = true;
			}
			else {
				displayDashes = false;
			}

			EvidenceBasedCareVariationsCategoryBean ebcvBean = new EvidenceBasedCareVariationsCategoryBean();

			ebcvBean.setCategory(StringUtil.getValueOrDashes(rs.getString("SUB_MTRC_NM")));
			ebcvBean.setCategoryCode(StringUtil.getValueOrDashes(rs.getString("SUB_MTRC_CD")));
			if (!displayDashes) {
				if (rs.getString("COST_OPRTNTY_AMT") != null)
					ebcvBean.setTotalOpportunity(
						exportFlag ? StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("COST_OPRTNTY_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString())
							: rs.getBigDecimal("COST_OPRTNTY_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
			}
			else {
				ebcvBean.setTotalOpportunity(Constants.DASHES);
			}

			if (!displayDashes) {
				if (rs.getString("COST_OPRTNTY_10_PCTAG_AMT") != null)
					ebcvBean
						.setTenPercentImprovement(
							exportFlag
								? StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("COST_OPRTNTY_10_PCTAG_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString())
								: rs.getBigDecimal("COST_OPRTNTY_10_PCTAG_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
			}
			else {
				ebcvBean.setTenPercentImprovement(Constants.DASHES);
			}

			if (!displayDashes) {
				if (rs.getString("PMPM_OPRTNTY_AMT") != null)
					ebcvBean.setTotalOpportunityPMPM(
						exportFlag ? StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("PMPM_OPRTNTY_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString())
							: rs.getBigDecimal("PMPM_OPRTNTY_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
			}
			else {
				ebcvBean.setTotalOpportunityPMPM(Constants.DASHES);
			}

			if (!displayDashes) {
				if (rs.getString("PMPM_OPRTNTY_10_PCTAG_AMT") != null)
					ebcvBean.setTenPercentImprovementPMPM(
						exportFlag ? StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("PMPM_OPRTNTY_10_PCTAG_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString())
							: rs.getBigDecimal("PMPM_OPRTNTY_10_PCTAG_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
			}
			else {
				ebcvBean.setTenPercentImprovementPMPM(Constants.DASHES);
			}

			if (rs.getString("MBR_SPCFD_SRVC_CNT") != null)
				ebcvBean.setTotalMemberCount(
					exportFlag ? StringUtil.convertStringToCommaBigDecimal(rs.getBigDecimal("MBR_SPCFD_SRVC_CNT").setScale(0, BigDecimal.ROUND_HALF_UP).toString(), 0)
						: rs.getBigDecimal("MBR_SPCFD_SRVC_CNT").setScale(0, BigDecimal.ROUND_HALF_UP).toString());



			if (rs.getString("MBR_ELGBL_SLCT_SRVC_CNT") != null)
				ebcvBean
					.setEligibleMemberCount(
						exportFlag ? StringUtil.convertStringToCommaBigDecimal(rs.getBigDecimal("MBR_ELGBL_SLCT_SRVC_CNT").setScale(0, BigDecimal.ROUND_HALF_UP).toString(),0)
							: rs.getBigDecimal("MBR_ELGBL_SLCT_SRVC_CNT").setScale(0, BigDecimal.ROUND_HALF_UP).toString());



			if (!displayDashes && rs.getShort("BNCH_90_CNT") == Constants.INT_ONE) {
				if (rs.getString("BNCHMRK_90_PCTILE_AMT") != null)
					ebcvBean.setPercentileBenchmark90(rs.getBigDecimal("BNCHMRK_90_PCTILE_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
			}
			else {
				ebcvBean.setPercentileBenchmark90(Constants.DASHES);
			}

			if (!displayDashes && rs.getShort("BNCH_10_CNT") == Constants.INT_ONE) {
				if (rs.getString("BNCHMRK_10_PCTILE_AMT") != null)
					ebcvBean.setPercentileBenchmark10(rs.getBigDecimal("BNCHMRK_10_PCTILE_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
			}
			else {
				ebcvBean.setPercentileBenchmark10(Constants.DASHES);
			}

			if (!displayDashes) {
				if (rs.getString("CURRENT_PERF_RATE") != null)
					ebcvBean.setCurrentPerformanceRate(rs.getBigDecimal("CURRENT_PERF_RATE").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
			}
			else {
				ebcvBean.setCurrentPerformanceRate(Constants.DASHES);
			}

			if (!displayDashes)
				ebcvBean.setHasCategoryDrilldownInd(Boolean.TRUE);
			resultList.add(ebcvBean);
		}
		return resultList;
	}

	private StringBuilder buildSortClause(GetEvidenceBasedCareVariationsCategoryRequest request) {
		StringBuilder query = new StringBuilder();

		for (QuerySort sort : request.getSort()) {
			String dir = sort.getDirection().replaceAll("\"", "");
			String property = sort.getProperty();

			if (property.equals("category")) {
				query.append(" SUB_MTRC_NM " + dir);
			}
			else if (property.equals("totalOpportunity")) {
				query.append(" COST_OPRTNTY_AMT " + dir);
			}
			else if (property.equals("tenPercentImprovement")) {
				query.append(" COST_OPRTNTY_10_PCTAG_AMT " + dir);
			}
			else if (property.equals("totalOpportunityPMPM")) {
				query.append(" PMPM_OPRTNTY_AMT " + dir);
			}
			else if (property.equals("tenPercentImprovementPMPM")) {
				query.append(" PMPM_OPRTNTY_10_PCTAG_AMT " + dir);
			}
			else if (property.equals("totalMemberCount")) {
				query.append(" MBR_SPCFD_SRVC_CNT " + dir);
			}
			else if (property.equals("eligibleMemberCount")) {
				query.append(" MBR_ELGBL_SLCT_SRVC_CNT " + dir);
			}
			else if (property.equals("currentPerformanceRate")) {
				query.append(" CURRENT_PERF_RATE " + dir);
			}
			else if (property.equals("percentileBenchmark90")) {
				query.append(" BNCHMRK_90_PCTILE_AMT " + dir);
			}
			else if (property.equals("percentileBenchmark10")) {
				query.append(" BNCHMRK_10_PCTILE_AMT " + dir);
			}
		}

		return query;
	}

}
