package com.wellpoint.pc2dash.action.costOpportunity;

import com.wellpoint.pc2dash.data.dto.PopulationManagementRequest;

public class GetLabUnitCountPopupRequest extends PopulationManagementRequest {

	private String labTaxId;
	private String networkStatus;

	public String getNetworkStatus() {
		return networkStatus;
	}

	public void setNetworkStatus(String networkStatus) {
		this.networkStatus = networkStatus;
	}

	public String getLabTaxId() {
		return labTaxId;
	}

	public void setLabTaxId(String labTaxId) {
		this.labTaxId = labTaxId;
	}

}
