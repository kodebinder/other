package com.wellpoint.pc2dash.action.tap.inpatientAdmissions;

import com.wellpoint.pc2dash.data.dto.PopulationManagementRequest;

public class GetASCAdmissionsChartRequest extends PopulationManagementRequest {
	
	protected String minimumInpatientAdmits;

	public String getMinimumInpatientAdmits() {
		return minimumInpatientAdmits;
	}

	public void setMinimumInpatientAdmits(String minimumInpatientAdmits) {
		this.minimumInpatientAdmits = minimumInpatientAdmits;
	}
	
}
