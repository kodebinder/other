package com.wellpoint.pc2dash.data.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import com.wellpoint.pc2dash.action.costOpportunity.GetLabUnitCountPopupRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.costOpportunity.LabUnitCountPopupBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class LabUnitCountPopupDao extends ServiceImpl {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(LabUnitCountPopupDao.class);

	public List<LabUnitCountPopupBean> getData(GetLabUnitCountPopupRequest request, boolean exportFlag) throws Exception {

		List<LabUnitCountPopupBean> result = new ArrayList<LabUnitCountPopupBean>();
		setRowCount(0);
		//PCMSP-13739 - Minimumn criteria condition to mask Cost Opportunity Value 
		String dashesClause = " sum(lab.unit_cnt) < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LAB_MIN_LABS' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG') "; 

		StringBuilder query = new StringBuilder()
			.append(" select CPT_CD,CPT_DESC,UNIT_CNT,COST_OPRTNTY_AMT,dsply_dashes ")
			.append(" 	from ( ")
			.append(" 		select cptsmry.CPT_CD as CPT_CD, cptsmry.CPT_DESC as CPT_DESC, SUM(cptsmry.UNIT_CNT) as UNIT_CNT, ")
			.append(" 			case ")
			.append(" 				when   SUM(cptsmry.COST_OPRTNTY_AMT) > 0 ")
			.append(" 				then   SUM(cptsmry.COST_OPRTNTY_AMT) ")
			.append(" 				else   0.00 ")
			.append(" 			end as COST_OPRTNTY_AMT,LAB.dsply_dashes ")
			.append(" 		from coc_lab_prov_smry cptsmry ")
			.append(" 		join poit_user_scrty_acs pusa on (cptsmry.prov_grp_id = pusa.prov_grp_id ")
			.append(" 			and ")
			.append(" 			case ")
			.append(" 				when   pusa.prov_org_tax_id = '0' ")
			.append(" 				then   cptsmry.prov_org_tax_id ")
			.append(" 				else   pusa.prov_org_tax_id ")
			.append(" 			end = cptsmry.prov_org_tax_id) ")
			.append(" JOIN ( select sum(lab.UNIT_CNT) as UNITCNT, ")
			.append(" case when ").append(dashesClause).append(" then 'Y' else 'N' end as dsply_dashes ")
			.append("	from coc_lab_prov_smry lab  ")
			.append("	join  poit_user_scrty_acs pusa on (lab.prov_grp_id = pusa.prov_grp_id  ") 
			.append("	and case    ")
			.append("	when    pusa.prov_org_tax_id = '0'   ")
			.append("	then    lab.prov_org_tax_id   ")
			.append("	else    pusa.prov_org_tax_id  end = lab.prov_org_tax_id)  ")
		 	.append(" 		where  ") 
			.append(" 		pusa.sesn_id = ? ")
			.append(" 		and pusa.enttlmnt_hash_key = ? ");

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
				query.append(" and lab.PROV_GRP_ID in (" +
					StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
			}

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
				query.append(" and lab.PGM_DIM_KEY in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
			}

			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
				query.append(" and lab.LOB_DESC in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
			}

			if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
				query.append(" and lab.IP_DIM_KEY in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
			}

			if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
				query.append(" and lab.PROV_ORG_DIM_KEY in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
					+ ") ");
			}

			if (StringUtil.isNotBlankOrFalse(request.getLabName())) {
				query.append(" and lab.LAB_NM in ( ? )");
					
			}

			if (StringUtil.isNotBlankOrFalse(request.getLabTaxId())) {
				query.append(" and lab.lab_tax_id in ( ? )");
					
			}
			
			if (StringUtil.isNotBlankOrFalse(request.getNetworkStatus())) {
				query.append(" and lab.parg_cd in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getNetworkStatus())
					+ ") ");
			}
			//PCMSP-20002
			if (StringUtil.isNotBlankOrFalse(request.getScorecardAnalysisOfDate())) {
				query.append(" and upper(lab.rpt_type_ind) = 'SC' ");
			}else{
				query.append(" and upper(lab.rpt_type_ind) = 'COC' ");
			}

			query.append(" group by LAB_TAX_ID,LAB_NM,PARG_CD  ) As LAB on 1=1  ")
			.append(" 		where  ")
			.append(" 		pusa.sesn_id = ? ")
			.append(" 		and pusa.enttlmnt_hash_key = ? ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and cptsmry.PROV_GRP_ID in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and cptsmry.PGM_DIM_KEY in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and cptsmry.LOB_DESC in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and cptsmry.IP_DIM_KEY in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and cptsmry.PROV_ORG_DIM_KEY in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getLabName())) {
			query.append(" and cptsmry.LAB_NM in ( ? )");
				
		}

		if (StringUtil.isNotBlankOrFalse(request.getLabTaxId())) {
			query.append(" and cptsmry.lab_tax_id in ( ? )");
				
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getNetworkStatus())) {
			query.append(" and cptsmry.parg_cd in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getNetworkStatus())
				+ ") ");
		}
		
		//PCMSP-20002
		if (StringUtil.isNotBlankOrFalse(request.getScorecardAnalysisOfDate())) {
			query.append(" and upper(cptsmry.rpt_type_ind) = 'SC' ");
		}else{
			query.append(" and upper(cptsmry.rpt_type_ind) = 'COC' ");
		}

		query.append(" 	group by CPT_CD, CPT_DESC,LAB.dsply_dashes   ) As CPTLAB  ")
			.append(" order by ")
			.append(buildSortClause(request))
			.append(" with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());

			buildPreparedStatement(request, i);

			executeQuery(logger, query.toString());

			result = convertSelectedRowsToObjects(rs, request, exportFlag);

		}
		catch (Exception e) {

			throw new Exception("Unable to get LabUnitCountPopupDao.", e);
		}
		finally {

			close();
		}

		return result;

	}

	private void buildPreparedStatement(GetLabUnitCountPopupRequest request, int i) throws SQLException {

		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}
		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getLabName())) {
			ps.setString(++i, request.getLabName());
		}

		if (StringUtil.isNotBlankOrFalse(request.getLabTaxId())) {
			ps.setString(++i, request.getLabTaxId());				
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getNetworkStatus())) {
			String[] array = request.getNetworkStatus().split(",");
			for (String item : array) {
				ps.setString(++i, item.trim());
			}
		}
		
		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}
		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getLabName())) {
			ps.setString(++i, request.getLabName());
		}

		if (StringUtil.isNotBlankOrFalse(request.getLabTaxId())) {
			ps.setString(++i, request.getLabTaxId());				
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getNetworkStatus())) {
			String[] array = request.getNetworkStatus().split(",");
			for (String item : array) {
				ps.setString(++i, item.trim());
			}
		}

	}

	private List<LabUnitCountPopupBean> convertSelectedRowsToObjects(ResultSet rs, GetLabUnitCountPopupRequest request, boolean exportFlag) throws SQLException {

		List<LabUnitCountPopupBean> list = new ArrayList<LabUnitCountPopupBean>();
		if(exportFlag && null != request.getLabName()){
			LabUnitCountPopupBean unitCountBean = new LabUnitCountPopupBean();
			unitCountBean.setCptCode(request.getLabName());
			list.add(unitCountBean);
		}

		while (rs.next()) {

			LabUnitCountPopupBean item = new LabUnitCountPopupBean();

			if (rs.getString("cpt_cd") != null) {
				item.setCptCode(rs.getString("cpt_cd"));
			}
			else {
				item.setCptCode(Constants.DASHES);
			}
			if (rs.getString("cpt_desc") != null) {
				item.setCptDesc(rs.getString("cpt_desc"));
			}
			else {
				item.setCptDesc(Constants.DASHES);
			}
			if (rs.getString("unit_cnt") != null) {
				item.setUnitCount(exportFlag
					? (StringUtil.convertStringToCommaBigDecimal(rs.getBigDecimal("unit_cnt")
						.setScale(0, BigDecimal.ROUND_HALF_UP).toString(), 0))
					: rs.getBigDecimal("unit_cnt").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
			}
			else {
				item.setUnitCount(Constants.DASHES);
			}
			if (rs.getString("cost_oprtnty_amt") != null && (rs.getString("dsply_dashes") != null && rs.getString("dsply_dashes").equalsIgnoreCase(Constants.N))) { //PCMSP-13739 - Minimumn criteria condition to mask Cost Opportunity Value 
				item.setCostOpportunity(
					exportFlag ? StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("cost_oprtnty_amt").setScale(2, BigDecimal.ROUND_HALF_UP).toString())
						: rs.getBigDecimal("cost_oprtnty_amt").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
			}
			else {
				item.setCostOpportunity(Constants.DASHES);
			}

			list.add(item);

		}

		return list;
	}

	private String buildSortClause(GetLabUnitCountPopupRequest request) {

		String query = " COST_OPRTNTY_AMT desc ";
		
		if (CollectionUtils.isNotEmpty(request.getSort())) {

			for (QuerySort sort : request.getSort()) {
				String dir = sort.getDirection().replaceAll("\"", "");
				String property = sort.getProperty();
	
				if (property.equals("cptCode")) {
					query = " CPT_CD " + dir;
				}
				else if (property.equals("cptDesc")) {
					query = " CPT_DESC " + dir;
				}
				else if (property.equals("unitCount")) {
					query = " UNIT_CNT " + dir;
				}
				else if (property.equals("costOpportunity")) {
					query = " COST_OPRTNTY_AMT " + dir;
				}
			}
			
		}

		return query;
	}


}
