package com.wellpoint.pc2dash.action.patients;

import java.util.Collection;
import java.util.Vector;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetVisitsResponse extends ActionResponse {

	private String id;
	private String text;
	private Collection<Object> children = new Vector<Object>();
	private String rollupMeasureName;
	public String getRollupMeasureName() {
		return rollupMeasureName;
	}

	public void setRollupMeasureName(String rollupMeasureName) {
		this.rollupMeasureName = rollupMeasureName;
	}

	

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Collection<Object> getChildren() {
		return children;
	}

	public void setChildren(Collection<Object> children) {
		this.children = children;
	}
}
