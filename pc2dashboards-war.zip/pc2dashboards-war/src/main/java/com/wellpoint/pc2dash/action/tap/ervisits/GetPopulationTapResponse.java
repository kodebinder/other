package com.wellpoint.pc2dash.action.tap.ervisits;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetPopulationTapResponse extends ActionResponse {

}
