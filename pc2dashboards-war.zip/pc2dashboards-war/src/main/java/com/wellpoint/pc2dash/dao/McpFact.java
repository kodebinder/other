package com.wellpoint.pc2dash.dao;


import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class McpFact implements Serializable {

	private static final long serialVersionUID = 1L;

	private BigDecimal adjstdAlwdAmt;
	private BigDecimal adjstdAlwdPmpmAmt;
	private BigDecimal adjstdPaidAmt;
	private BigDecimal bslnAlwdAmt;
	private BigDecimal bslnPaidAmt;
	private BigDecimal ccrcvryAmt;
	private BigDecimal cspmpmBrskcrdrAccrcvryAmt;
	private BigDecimal fnlScrcrdPgScrcrdPct;
	private BigDecimal lcfwrdRcvryAmt;
	private BigDecimal maxSsavPct;
	private BigDecimal maxSsavPmpmAmt;
	private BigDecimal mcpPMPMAdjstdAmt;
	private BigDecimal mcpPMPMUnadjstdCorrection;
	private BigDecimal minRskcrdrPct;
	private BigDecimal mnth3TrnddPmpmAmt;
	private BigDecimal mnth6TrnddPmpmAmt;
	private BigDecimal mnth9TrnddPmpmAmt;
	private BigDecimal netPayblAftrLcfwrdAmt;
	private BigDecimal nrmlrtaRiskScorNbr;
	private BigDecimal nspmpmArskcrdrBscrcrdAmt;
	private BigDecimal pgNetSvngsAmt;
	private BigDecimal pgSvngsPmpmAmt;
	private BigDecimal pgSvngsPmpmAudthrshldAmt;
	private BigDecimal pgWthldAmt;
	private BigDecimal provGrpNrmlrtaRiskScorNbr;
	private BigDecimal provGrpSvradjstMbrMnthCnt;
	private BigDecimal rskcrdrPmpmSigndAmt;
	private BigDecimal sadjpmpmAmt;
	private BigDecimal ssavPtntlPct;
	private BigDecimal svradjstMbrMnthCnt;
	private BigDecimal svrtyadjMbrMnthCnt;
	private BigDecimal totlClcrdPaymntAmt;
	private BigDecimal trnddPmpmAmt;
	private Date bslnPrdEndDt;
	private Date bslnPrdStrtDt;
	private Date msrmntPrdEndDt;
	private Date msrmntPrdStrtDt;
	private Integer adjstdMbrMnthCnt;
	private Integer bslnMbrMnthCnt;
	private Integer intrvlMnthCnt;
	private Integer provGrpAdjstdMbrMnthCnt;
	private Integer provGrpBslnMbrMnthCnt;
	private long creatdLoadLogKey;
	private long lobDimKey;
	private long mcpFactKey;
	private long mdpnlDimKey;
	private long pgmDimKey;
	private long provGrpDimKey;
	private long pslDimKey;
	private long updtdLoadLogKey;
	private String fundgSrcPoolCd;
	private String lmtdDwnsdRiskInd;
	private String lmtdUpsdRiskInd;
	private String phrmcyInd;
	private String pslName;
	private String rcrdSttsCd;
	private String shrdSvngsClnclPaymntInd;
	private Timestamp sorDtm;

	public McpFact() {}

	public BigDecimal getAdjstdAlwdAmt() {
		return adjstdAlwdAmt;
	}

	public void setAdjstdAlwdAmt(BigDecimal adjstdAlwdAmt) {
		this.adjstdAlwdAmt = adjstdAlwdAmt;
	}

	public BigDecimal getAdjstdAlwdPmpmAmt() {
		return adjstdAlwdPmpmAmt;
	}

	public void setAdjstdAlwdPmpmAmt(BigDecimal adjstdAlwdPmpmAmt) {
		this.adjstdAlwdPmpmAmt = adjstdAlwdPmpmAmt;
	}

	public BigDecimal getAdjstdPaidAmt() {
		return adjstdPaidAmt;
	}

	public void setAdjstdPaidAmt(BigDecimal adjstdPaidAmt) {
		this.adjstdPaidAmt = adjstdPaidAmt;
	}

	public BigDecimal getBslnAlwdAmt() {
		return bslnAlwdAmt;
	}

	public void setBslnAlwdAmt(BigDecimal bslnAlwdAmt) {
		this.bslnAlwdAmt = bslnAlwdAmt;
	}

	public BigDecimal getBslnPaidAmt() {
		return bslnPaidAmt;
	}

	public void setBslnPaidAmt(BigDecimal bslnPaidAmt) {
		this.bslnPaidAmt = bslnPaidAmt;
	}

	public BigDecimal getCcrcvryAmt() {
		return ccrcvryAmt;
	}

	public void setCcrcvryAmt(BigDecimal ccrcvryAmt) {
		this.ccrcvryAmt = ccrcvryAmt;
	}

	public BigDecimal getCspmpmBrskcrdrAccrcvryAmt() {
		return cspmpmBrskcrdrAccrcvryAmt;
	}

	public void setCspmpmBrskcrdrAccrcvryAmt(BigDecimal cspmpmBrskcrdrAccrcvryAmt) {
		this.cspmpmBrskcrdrAccrcvryAmt = cspmpmBrskcrdrAccrcvryAmt;
	}

	public BigDecimal getFnlScrcrdPgScrcrdPct() {
		return fnlScrcrdPgScrcrdPct;
	}

	public void setFnlScrcrdPgScrcrdPct(BigDecimal fnlScrcrdPgScrcrdPct) {
		this.fnlScrcrdPgScrcrdPct = fnlScrcrdPgScrcrdPct;
	}

	public BigDecimal getLcfwrdRcvryAmt() {
		return lcfwrdRcvryAmt;
	}

	public void setLcfwrdRcvryAmt(BigDecimal lcfwrdRcvryAmt) {
		this.lcfwrdRcvryAmt = lcfwrdRcvryAmt;
	}

	public BigDecimal getMaxSsavPct() {
		return maxSsavPct;
	}

	public void setMaxSsavPct(BigDecimal maxSsavPct) {
		this.maxSsavPct = maxSsavPct;
	}

	public BigDecimal getMaxSsavPmpmAmt() {
		return maxSsavPmpmAmt;
	}

	public void setMaxSsavPmpmAmt(BigDecimal maxSsavPmpmAmt) {
		this.maxSsavPmpmAmt = maxSsavPmpmAmt;
	}

	public BigDecimal getMcpPMPMAdjstdAmt() {
		return mcpPMPMAdjstdAmt;
	}

	public void setMcpPMPMAdjstdAmt(BigDecimal mcpPMPMAdjstdAmt) {
		this.mcpPMPMAdjstdAmt = mcpPMPMAdjstdAmt;
	}

	public BigDecimal getMcpPMPMUnadjstdCorrection() {
		return mcpPMPMUnadjstdCorrection;
	}

	public void setMcpPMPMUnadjstdCorrection(BigDecimal mcpPMPMUnadjstdCorrection) {
		this.mcpPMPMUnadjstdCorrection = mcpPMPMUnadjstdCorrection;
	}

	public BigDecimal getMinRskcrdrPct() {
		return minRskcrdrPct;
	}

	public void setMinRskcrdrPct(BigDecimal minRskcrdrPct) {
		this.minRskcrdrPct = minRskcrdrPct;
	}

	public BigDecimal getMnth3TrnddPmpmAmt() {
		return mnth3TrnddPmpmAmt;
	}

	public void setMnth3TrnddPmpmAmt(BigDecimal mnth3TrnddPmpmAmt) {
		this.mnth3TrnddPmpmAmt = mnth3TrnddPmpmAmt;
	}

	public BigDecimal getMnth6TrnddPmpmAmt() {
		return mnth6TrnddPmpmAmt;
	}

	public void setMnth6TrnddPmpmAmt(BigDecimal mnth6TrnddPmpmAmt) {
		this.mnth6TrnddPmpmAmt = mnth6TrnddPmpmAmt;
	}

	public BigDecimal getMnth9TrnddPmpmAmt() {
		return mnth9TrnddPmpmAmt;
	}

	public void setMnth9TrnddPmpmAmt(BigDecimal mnth9TrnddPmpmAmt) {
		this.mnth9TrnddPmpmAmt = mnth9TrnddPmpmAmt;
	}

	public BigDecimal getNetPayblAftrLcfwrdAmt() {
		return netPayblAftrLcfwrdAmt;
	}

	public void setNetPayblAftrLcfwrdAmt(BigDecimal netPayblAftrLcfwrdAmt) {
		this.netPayblAftrLcfwrdAmt = netPayblAftrLcfwrdAmt;
	}

	public BigDecimal getNrmlrtaRiskScorNbr() {
		return nrmlrtaRiskScorNbr;
	}

	public void setNrmlrtaRiskScorNbr(BigDecimal nrmlrtaRiskScorNbr) {
		this.nrmlrtaRiskScorNbr = nrmlrtaRiskScorNbr;
	}

	public BigDecimal getNspmpmArskcrdrBscrcrdAmt() {
		return nspmpmArskcrdrBscrcrdAmt;
	}

	public void setNspmpmArskcrdrBscrcrdAmt(BigDecimal nspmpmArskcrdrBscrcrdAmt) {
		this.nspmpmArskcrdrBscrcrdAmt = nspmpmArskcrdrBscrcrdAmt;
	}

	public BigDecimal getPgNetSvngsAmt() {
		return pgNetSvngsAmt;
	}

	public void setPgNetSvngsAmt(BigDecimal pgNetSvngsAmt) {
		this.pgNetSvngsAmt = pgNetSvngsAmt;
	}

	public BigDecimal getPgSvngsPmpmAmt() {
		return pgSvngsPmpmAmt;
	}

	public void setPgSvngsPmpmAmt(BigDecimal pgSvngsPmpmAmt) {
		this.pgSvngsPmpmAmt = pgSvngsPmpmAmt;
	}

	public BigDecimal getPgSvngsPmpmAudthrshldAmt() {
		return pgSvngsPmpmAudthrshldAmt;
	}

	public void setPgSvngsPmpmAudthrshldAmt(BigDecimal pgSvngsPmpmAudthrshldAmt) {
		this.pgSvngsPmpmAudthrshldAmt = pgSvngsPmpmAudthrshldAmt;
	}

	public BigDecimal getPgWthldAmt() {
		return pgWthldAmt;
	}

	public void setPgWthldAmt(BigDecimal pgWthldAmt) {
		this.pgWthldAmt = pgWthldAmt;
	}

	public BigDecimal getProvGrpNrmlrtaRiskScorNbr() {
		return provGrpNrmlrtaRiskScorNbr;
	}

	public void setProvGrpNrmlrtaRiskScorNbr(BigDecimal provGrpNrmlrtaRiskScorNbr) {
		this.provGrpNrmlrtaRiskScorNbr = provGrpNrmlrtaRiskScorNbr;
	}

	public BigDecimal getProvGrpSvradjstMbrMnthCnt() {
		return provGrpSvradjstMbrMnthCnt;
	}

	public void setProvGrpSvradjstMbrMnthCnt(BigDecimal provGrpSvradjstMbrMnthCnt) {
		this.provGrpSvradjstMbrMnthCnt = provGrpSvradjstMbrMnthCnt;
	}

	public BigDecimal getRskcrdrPmpmSigndAmt() {
		return rskcrdrPmpmSigndAmt;
	}

	public void setRskcrdrPmpmSigndAmt(BigDecimal rskcrdrPmpmSigndAmt) {
		this.rskcrdrPmpmSigndAmt = rskcrdrPmpmSigndAmt;
	}

	public BigDecimal getSadjpmpmAmt() {
		return sadjpmpmAmt;
	}

	public void setSadjpmpmAmt(BigDecimal sadjpmpmAmt) {
		this.sadjpmpmAmt = sadjpmpmAmt;
	}

	public BigDecimal getSsavPtntlPct() {
		return ssavPtntlPct;
	}

	public void setSsavPtntlPct(BigDecimal ssavPtntlPct) {
		this.ssavPtntlPct = ssavPtntlPct;
	}

	public BigDecimal getSvradjstMbrMnthCnt() {
		return svradjstMbrMnthCnt;
	}

	public void setSvradjstMbrMnthCnt(BigDecimal svradjstMbrMnthCnt) {
		this.svradjstMbrMnthCnt = svradjstMbrMnthCnt;
	}

	public BigDecimal getSvrtyadjMbrMnthCnt() {
		return svrtyadjMbrMnthCnt;
	}

	public void setSvrtyadjMbrMnthCnt(BigDecimal svrtyadjMbrMnthCnt) {
		this.svrtyadjMbrMnthCnt = svrtyadjMbrMnthCnt;
	}

	public BigDecimal getTotlClcrdPaymntAmt() {
		return totlClcrdPaymntAmt;
	}

	public void setTotlClcrdPaymntAmt(BigDecimal totlClcrdPaymntAmt) {
		this.totlClcrdPaymntAmt = totlClcrdPaymntAmt;
	}

	public BigDecimal getTrnddPmpmAmt() {
		return trnddPmpmAmt;
	}

	public void setTrnddPmpmAmt(BigDecimal trnddPmpmAmt) {
		this.trnddPmpmAmt = trnddPmpmAmt;
	}

	public Date getBslnPrdEndDt() {
		return bslnPrdEndDt;
	}

	public void setBslnPrdEndDt(Date bslnPrdEndDt) {
		this.bslnPrdEndDt = bslnPrdEndDt;
	}

	public Date getBslnPrdStrtDt() {
		return bslnPrdStrtDt;
	}

	public void setBslnPrdStrtDt(Date bslnPrdStrtDt) {
		this.bslnPrdStrtDt = bslnPrdStrtDt;
	}

	public Date getMsrmntPrdEndDt() {
		return msrmntPrdEndDt;
	}

	public void setMsrmntPrdEndDt(Date msrmntPrdEndDt) {
		this.msrmntPrdEndDt = msrmntPrdEndDt;
	}

	public Date getMsrmntPrdStrtDt() {
		return msrmntPrdStrtDt;
	}

	public void setMsrmntPrdStrtDt(Date msrmntPrdStrtDt) {
		this.msrmntPrdStrtDt = msrmntPrdStrtDt;
	}

	public Integer getAdjstdMbrMnthCnt() {
		return adjstdMbrMnthCnt;
	}

	public void setAdjstdMbrMnthCnt(Integer adjstdMbrMnthCnt) {
		this.adjstdMbrMnthCnt = adjstdMbrMnthCnt;
	}

	public Integer getBslnMbrMnthCnt() {
		return bslnMbrMnthCnt;
	}

	public void setBslnMbrMnthCnt(Integer bslnMbrMnthCnt) {
		this.bslnMbrMnthCnt = bslnMbrMnthCnt;
	}

	public Integer getIntrvlMnthCnt() {
		return intrvlMnthCnt;
	}

	public void setIntrvlMnthCnt(Integer intrvlMnthCnt) {
		this.intrvlMnthCnt = intrvlMnthCnt;
	}

	public Integer getProvGrpAdjstdMbrMnthCnt() {
		return provGrpAdjstdMbrMnthCnt;
	}

	public void setProvGrpAdjstdMbrMnthCnt(Integer provGrpAdjstdMbrMnthCnt) {
		this.provGrpAdjstdMbrMnthCnt = provGrpAdjstdMbrMnthCnt;
	}

	public Integer getProvGrpBslnMbrMnthCnt() {
		return provGrpBslnMbrMnthCnt;
	}

	public void setProvGrpBslnMbrMnthCnt(Integer provGrpBslnMbrMnthCnt) {
		this.provGrpBslnMbrMnthCnt = provGrpBslnMbrMnthCnt;
	}

	public long getCreatdLoadLogKey() {
		return creatdLoadLogKey;
	}

	public void setCreatdLoadLogKey(long creatdLoadLogKey) {
		this.creatdLoadLogKey = creatdLoadLogKey;
	}

	public long getLobDimKey() {
		return lobDimKey;
	}

	public void setLobDimKey(long lobDimKey) {
		this.lobDimKey = lobDimKey;
	}

	public long getMcpFactKey() {
		return mcpFactKey;
	}

	public void setMcpFactKey(long mcpFactKey) {
		this.mcpFactKey = mcpFactKey;
	}

	public long getMdpnlDimKey() {
		return mdpnlDimKey;
	}

	public void setMdpnlDimKey(long mdpnlDimKey) {
		this.mdpnlDimKey = mdpnlDimKey;
	}

	public long getPgmDimKey() {
		return pgmDimKey;
	}

	public void setPgmDimKey(long pgmDimKey) {
		this.pgmDimKey = pgmDimKey;
	}

	public long getProvGrpDimKey() {
		return provGrpDimKey;
	}

	public void setProvGrpDimKey(long provGrpDimKey) {
		this.provGrpDimKey = provGrpDimKey;
	}

	public long getPslDimKey() {
		return pslDimKey;
	}

	public void setPslDimKey(long pslDimKey) {
		this.pslDimKey = pslDimKey;
	}

	public long getUpdtdLoadLogKey() {
		return updtdLoadLogKey;
	}

	public void setUpdtdLoadLogKey(long updtdLoadLogKey) {
		this.updtdLoadLogKey = updtdLoadLogKey;
	}

	public String getFundgSrcPoolCd() {
		return fundgSrcPoolCd;
	}

	public void setFundgSrcPoolCd(String fundgSrcPoolCd) {
		this.fundgSrcPoolCd = fundgSrcPoolCd;
	}

	public String getLmtdDwnsdRiskInd() {
		return lmtdDwnsdRiskInd;
	}

	public void setLmtdDwnsdRiskInd(String lmtdDwnsdRiskInd) {
		this.lmtdDwnsdRiskInd = lmtdDwnsdRiskInd;
	}

	public String getLmtdUpsdRiskInd() {
		return lmtdUpsdRiskInd;
	}

	public void setLmtdUpsdRiskInd(String lmtdUpsdRiskInd) {
		this.lmtdUpsdRiskInd = lmtdUpsdRiskInd;
	}

	public String getPhrmcyInd() {
		return phrmcyInd;
	}

	public void setPhrmcyInd(String phrmcyInd) {
		this.phrmcyInd = phrmcyInd;
	}

	public String getPslName() {
		return pslName;
	}

	public void setPslName(String pslName) {
		this.pslName = pslName;
	}

	public String getRcrdSttsCd() {
		return rcrdSttsCd;
	}

	public void setRcrdSttsCd(String rcrdSttsCd) {
		this.rcrdSttsCd = rcrdSttsCd;
	}

	public String getShrdSvngsClnclPaymntInd() {
		return shrdSvngsClnclPaymntInd;
	}

	public void setShrdSvngsClnclPaymntInd(String shrdSvngsClnclPaymntInd) {
		this.shrdSvngsClnclPaymntInd = shrdSvngsClnclPaymntInd;
	}

	public Timestamp getSorDtm() {
		return sorDtm;
	}

	public void setSorDtm(Timestamp sorDtm) {
		this.sorDtm = sorDtm;
	}
}
