package com.wellpoint.pc2dash.data.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.costOpportunity.GetInpatientUtilizationDetailRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.costOpportunity.InpatientUtilizationDetailBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.DateUtil;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class InpatientUtilizationDetailDao extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(InpatientUtilizationDetailDao.class);

	@Override
	public boolean read(Dto o) throws Exception {
		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {

	}

	@Override
	public void update(Dto o) throws Exception {

	}

	@Override
	public void delete(Dto o) throws Exception {

	}

	public List<InpatientUtilizationDetailBean> getData(GetInpatientUtilizationDetailRequest request, boolean exportFlag, int index, int limit) throws Exception {
		List<InpatientUtilizationDetailBean> result = new ArrayList<InpatientUtilizationDetailBean>();
		setRowCount(0);
		StringBuilder query = new StringBuilder()
			.append(" select a.* ")
			.append(" from( ")
			.append(" select b.*,row_number() over ( order by ")
			.append(buildSortClause(request))
			.append(" ) as rank ")
			.append(" from( ")
			.append(" select distinct dtl.SUB_MTRC_CD as etg_Cond_Cd, ")
			.append(" dtl.SUB_MTRC_NM as etg_Cond_Nm,")
			.append(" dtl.ip_dim_key as ip_dim_key, ")
			.append(" psf.frst_nm as frst_nm, ")
			.append(" psf.last_nm as last_nm, ")
			.append(" to_char(psf.brth_dt, '" + Constants.DATE_FRMT_YYYYMMDD + "' )  as dob, ")
			.append(" psf.age_nbr as age, ")
			.append(" psf.gndr_cd as gender, ")
			.append(" psf.mstr_cnsmr_dim_key as member_id, ")
			.append(" psf.lob_desc as lob_desc, ")
			.append(" psf.psl_desc as psl_desc, ")
			.append(" psf.crprt_plan_cmpny_nm as crprt_plan_cmpny_nm, ")
			.append(" psf.home_plan_nm, ")
			.append(" psf.ip_frst_nm as ip_frst_nm, ")
			.append(" psf.ip_last_nm as ip_last_nm, ")
			.append(" psf.IP_SPCLTY_NM as IP_SPCLTY_NM, ")
			.append(" psf.ip_npi as ip_npi, ")
			.append(" psf.prov_org_full_nm as organisation_nm, ")
			.append(" psf.prov_org_tax_id as orgtin, ") 
			.append(" psf.prov_org_dim_key as prov_org_dim_key, ")
			.append(" dtl.RSPNSBL_PROV_DSPLY_NM as rspnsbl_prov_nm, ")
			.append(" dtl.FCLTY_NM as fclty_nm, ")
			.append(" to_char(dtl.ADMT_DT, '" + Constants.DATE_FRMT_YYYYMMDD + "' ) as admt_dt, ")
			.append(" to_char(dtl.DSCHRG_DT, '" + Constants.DATE_FRMT_YYYYMMDD + "') as dschrg_dt, ")
			.append(" case when dtl.DSCHRG_DT > dtl.ADMT_DT then " )
			.append(" days(dtl.DSCHRG_DT) - days(dtl.ADMT_DT) ")
			.append(" when dtl.DSCHRG_DT is not null and dtl.ADMT_DT is not null and dtl.DSCHRG_DT = dtl.ADMT_DT then 1 else")
			.append(" 0 end as admt_duration, ")
			.append(" dtl.PRIMARY_DIAG_DESC as prim_diag_desc, ")
			.append(" dtl.PRNCPAL_PROC_DESC as prin_proc_desc, ")
			.append(" count(*) over () as row_cnt ")

			.append(" 	from  COC_IP_UTL_DTL_SMRY dtl ")
			.append(" 	join  pat_smry_fact psf on   (psf.PROV_GRP_ID=dtl.PROV_GRP_ID ")
			.append("   and psf.mstr_cnsmr_dim_key = dtl.mstr_cnsmr_dim_key ")
			.append("	and psf.pgm_dim_key=dtl.pgm_dim_key  and dtl.IP_DIM_KEY=psf.IP_DIM_KEY ")
			.append("	and  dtl.prov_org_dim_key =psf.prov_org_dim_key ")
			.append("	and dtl.LOB_DESC=psf.LOB_DESC) ")
			.append(" 	join  poit_user_scrty_acs pusa on ( dtl.prov_grp_id = pusa.prov_grp_id ")
			.append(" 			and ")
			.append(" 		case ")
			.append(" 				when  pusa.prov_org_tax_id = '0' ")
			.append(" 				then  dtl.prov_org_tax_id ")
			.append(" 				else  pusa.prov_org_tax_id end = dtl.prov_org_tax_id ) ")
			.append(" 	where ")
			.append(" 		psf.atrbn_stts_cd = 'ACTIVE' ")
			.append(" 		and pusa.sesn_id = ? ")
			.append(" 		and  pusa.enttlmnt_hash_key = ? ")
			.append(" and dtl.IP_UTL_FACT_KEY *0 =0  ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and dtl.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and dtl.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and dtl.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and dtl.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and dtl.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}

		//PCMSP-12621 : Starts
		if (StringUtil.isNotBlankOrFalse(request.getCategoryCode())) {
			query.append(" and dtl.SUB_MTRC_CD in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getCategoryCode())
				+ ") ");
		}
		//PCMSP-12621 : Ends



		query.append(" )b ) a ");

		query.append(" where a.rank between ? and ? ")
		.append(" order by   a.rank  with ur ");
		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());

			buildPreparedStatement(request, i, exportFlag, index, limit);

			executeQuery(logger, query.toString());

			result = convertSelectedRowsToObjects(rs, request, exportFlag);

		}
		catch (Exception e) {

			throw new Exception("Unable to get InpatientUtilizationDetailDao (" + request.getEntitlementId() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}

	private List<InpatientUtilizationDetailBean> convertSelectedRowsToObjects(ResultSet rs, GetInpatientUtilizationDetailRequest request, boolean exportFlag) throws SQLException {
		List<InpatientUtilizationDetailBean> list = new ArrayList<InpatientUtilizationDetailBean>();

		if (exportFlag) {
			//Added for PCMSP-9579 : Starts 
			while (rs.next()) {
				InpatientUtilizationDetailBean item = new InpatientUtilizationDetailBean();

				if (null != rs.getString("etg_Cond_Nm")) {
					item.setEtgConditionName(rs.getString("etg_Cond_Nm"));
				}

				if (null != rs.getString("age")) {
					item.setMemberAge(rs.getShort("age"));
				}

				if (null != rs.getString("dob")) {
					item.setMemberDOB(DateUtil.formatDateToMMDDYYYY(Constants.DATE_FRMT_YYYYMMDD, Constants.DATE_FRMT_MDYYYY, rs.getString("dob")));
				}

				if (null != rs.getString("frst_nm")) {
					item.setMemberFirstName(rs.getString("frst_nm"));
				}
				if (null != rs.getString("last_nm")) {
					item.setMemberLastName(rs.getString("last_nm"));
				}

				item.setMemberFullName(StringUtil.buildFullName(item.getMemberFirstName(), item.getMemberLastName()));

				if (null != rs.getString("gender")) {
					item.setMemberGender(rs.getString("gender"));
				}
				if (null != rs.getString("member_id")) {
					item.setMemberId(rs.getString("member_id"));
					item.setMemberKey(rs.getInt("member_id"));
				}

								
				//Changed for release-Q1-2018/PCMSP-18421 : Starts
				item.setAttributedPhysicianName(CommonQueries.getFilteredProviderName(rs.getString("ip_frst_nm"),rs.getString("ip_last_nm")));				
				//Changed for release-Q1-2018/PCMSP-18421 : Ends

				item.setProviderId(StringUtil.buildUniqueProviderId(rs.getString("ip_dim_key"), rs.getString("prov_org_dim_key")));

				if (null != rs.getString("organisation_nm")) {
					item.setOrganizationName(rs.getString("organisation_nm"));
				}
				if (null != rs.getString("orgtin")) {
					item.setOrganizationTin(rs.getString("orgtin"));
				} 
				if (null != rs.getString("rspnsbl_prov_nm")) {
					item.setResponsibleProviderName(rs.getString("rspnsbl_prov_nm"));
				}
				if (null != rs.getString("fclty_nm")) {
					item.setFacilityName(rs.getString("fclty_nm"));
				}
				if (null != rs.getString("admt_dt")) {
					item.setAdmitDt(DateUtil.formatDateToMMDDYYYY(Constants.DATE_FRMT_YYYYMMDD, Constants.DATE_FRMT_MDYYYY, rs.getString("admt_dt")));
				}
				if (null != rs.getString("dschrg_dt")) {
					item.setDischargeDt(DateUtil.formatDateToMMDDYYYY(Constants.DATE_FRMT_YYYYMMDD, Constants.DATE_FRMT_MDYYYY, rs.getString("dschrg_dt")));
				}
				if (null != rs.getString("admt_duration")) {
					item.setTotalInpatientDays(rs.getString("admt_duration"));
				}
				if (null != rs.getString("prim_diag_desc")) {
					item.setPrimaryDiagnosisDescription(rs.getString("prim_diag_desc"));
				}
				if (null != rs.getString("prin_proc_desc")) {
					item.setPrincipalProcedureDescription(rs.getString("prin_proc_desc"));
				}


				item.setAttributedProvNpi(StringUtil.getValueOrDashes(rs.getString("ip_npi")));
				item.setAttributedProvSpeciality(StringUtil.getValueOrDashes(rs.getString("IP_SPCLTY_NM")));
				item.setMemberLob(StringUtil.getValueOrDashes(rs.getString("lob_desc")));
				item.setMemberProduct(StringUtil.getValueOrDashes(rs.getString("psl_desc")));
				item.setMemberHomePlanParentCo(StringUtil.getValueOrDashes(rs.getString("crprt_plan_cmpny_nm")));
				item.setMemberHomePlan(StringUtil.getValueOrDashes(rs.getString("home_plan_nm")));

				list.add(item);
				if (getRowCount() == 0) {
					setRowCount(rs.getInt("row_cnt"));
				}
				setTotalExport(rs.getInt("row_cnt"));

			}
			//Added for PCMSP-9579 : Ends
		}
		else {
			while (rs.next()) {
				InpatientUtilizationDetailBean item = new InpatientUtilizationDetailBean();

				if (null != rs.getString("etg_Cond_Nm")) {
					item.setEtgConditionName(rs.getString("etg_Cond_Nm"));
				}

				if (null != rs.getString("age")) {
					item.setMemberAge(rs.getShort("age"));
				}

				if (null != rs.getString("dob")) {
					item.setMemberDOB(DateUtil.formatDateToMMDDYYYY(Constants.DATE_FRMT_YYYYMMDD, Constants.DATE_FRMT_MDYYYY, rs.getString("dob")));
				}

				if (null != rs.getString("frst_nm")) {
					item.setMemberFirstName(rs.getString("frst_nm"));
				}
				if (null != rs.getString("last_nm")) {
					item.setMemberLastName(rs.getString("last_nm"));
				}

				item.setMemberFullName(StringUtil.buildFullName(item.getMemberFirstName(), item.getMemberLastName()));

				if (null != rs.getString("gender")) {
					item.setMemberGender(rs.getString("gender"));
				}
				if (null != rs.getString("member_id")) {
					item.setMemberId(rs.getString("member_id"));
					item.setMemberKey(rs.getInt("member_id"));
				}

				
				//Changed for release-Q1-2018/PCMSP-18421 : Starts
				item.setAttributedPhysicianName(CommonQueries.getFilteredProviderName(rs.getString("ip_frst_nm"),rs.getString("ip_last_nm")));				
				//Changed for release-Q1-2018/PCMSP-18421 : Ends

				item.setProviderId(StringUtil.buildUniqueProviderId(rs.getString("ip_dim_key"), rs.getString("prov_org_dim_key")));

				if (null != rs.getString("organisation_nm")) {
					item.setOrganizationName(rs.getString("organisation_nm"));
				}
				if (null != rs.getString("rspnsbl_prov_nm")) {
					item.setResponsibleProviderName(rs.getString("rspnsbl_prov_nm"));
				}
				if (null != rs.getString("fclty_nm")) {
					item.setFacilityName(rs.getString("fclty_nm"));
				}
				if (null != rs.getString("admt_dt")) {
					item.setAdmitDt(DateUtil.formatDateToMMDDYYYY(Constants.DATE_FRMT_YYYYMMDD, Constants.DATE_FRMT_MDYYYY, rs.getString("admt_dt")));
				}
				if (null != rs.getString("dschrg_dt")) {
					item.setDischargeDt(DateUtil.formatDateToMMDDYYYY(Constants.DATE_FRMT_YYYYMMDD, Constants.DATE_FRMT_MDYYYY, rs.getString("dschrg_dt")));
				}
				if (null != rs.getString("admt_duration")) {
					item.setTotalInpatientDays(rs.getString("admt_duration"));
				}
				if (null != rs.getString("prim_diag_desc")) {
					item.setPrimaryDiagnosisDescription(rs.getString("prim_diag_desc"));
				}
				if (null != rs.getString("prin_proc_desc")) {
					item.setPrincipalProcedureDescription(rs.getString("prin_proc_desc"));
				}

				list.add(item);
				if (getRowCount() == 0) {
					setRowCount(rs.getInt("row_cnt"));
				}

			}
		}

		return list;

	}

	private void buildPreparedStatement(GetInpatientUtilizationDetailRequest request, int i, boolean exportFlag, int index, int limit) throws SQLException {
		int start = 0;
		int stop = 0;

		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		//PCMSP-12621 : Starts
		if (StringUtil.isNotBlankOrFalse(request.getCategoryCode())) {
			String[] array = request.getCategoryCode().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		//PCMSP-12621 : Ends

		if (!exportFlag) {
			start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
			stop = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
		}
		else {
			start = index;
			stop = limit;
		}
		ps.setInt(++i, start + 1);
		ps.setInt(++i, start + stop);

	}

	private String buildSortClause(GetInpatientUtilizationDetailRequest request) {

		StringBuilder query = new StringBuilder();
		String defaultColumn = "  etg_Cond_Nm ";
		String defaultSort = defaultColumn + " asc ";

		if (null != request.getSort()) {

			for (QuerySort sort : request.getSort()) {

				String dir = sort.getDirection().replaceAll("\"", "");
				String property = sort.getProperty();

				if (property.equals("etgConditionName")) {
					query.append(" etg_Cond_Nm " + dir);
				}
				else if (property.equals("memberFullName")) {
					query.append(" last_nm " + dir + ", " + " frst_nm " + dir + ", " + defaultSort);
				}
				else if (property.equals("attributedPhysicianName")) {
					query.append(" ip_last_nm " + dir + ", " + " ip_frst_nm " + dir + ", " + defaultSort);
				}
				else if (property.equals("organizationName")) {
					query.append(" organisation_nm " + dir + ", " + defaultSort);
				}
				else if (property.equals("responsibleProviderName")) {
					query.append(" rspnsbl_prov_nm " + dir + ", " + defaultSort);
				}
				else if (property.equals("facilityName")) {
					query.append(" fclty_nm " + dir + ", " + defaultSort);
				}
				else if (property.equals("admitDt")) {
					query.append(" to_date( admt_dt , '" + Constants.DATE_FORMAT_YYYY_MM_DD + "') " + dir + ", " + defaultSort);
				}
				else if (property.equals("dischargeDt")) {
					query.append(" to_date( dschrg_dt , '" + Constants.DATE_FORMAT_YYYY_MM_DD + "') " + dir + ", " + defaultSort);
				}
				else if (property.equals("totalInpatientDays")) {
					query.append(" admt_duration " + dir + ", " + defaultSort);
				}
				else if (property.equals("primaryDiagnosisDescription")) {
					query.append(" prim_diag_desc " + dir + ", " + defaultSort);
				}
				else if (property.equals("principalProcedureDescription")) {
					query.append(" prin_proc_desc " + dir + ", " + defaultSort);
				}

				else {
					query.append(defaultSort);
				}
			}
		}
		else {
			query.append(defaultSort);
		}
		return query.toString();
	}

}