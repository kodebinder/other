package com.wellpoint.pc2dash.action.utilization;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.action.quality.GetQualityAction;
import com.wellpoint.pc2dash.action.quality.GetQualityResponse;
import com.wellpoint.pc2dash.data.dao.UtilizationProviders;
import com.wellpoint.pc2dash.dto.careOpportunities.Provider;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportGridColumn;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.scorecard.DrillDownChartExport;
import com.wellpoint.pc2dash.export.scorecard.commercial.UtilizationProviderExport;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;


public class GetUtilizationProvidersAction extends GetQualityAction {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetUtilizationProvidersRequest request = (GetUtilizationProvidersRequest) actionRequest;
		GetQualityResponse response = new GetQualityResponse();

		List<String> grps = new ArrayList<String>();
		List<Provider> resultList = new ArrayList<Provider>();

		try {

			request = (GetUtilizationProvidersRequest) cleanRequest(request);
			String pgmLobTypeCode = request.getProgramLobTypeCd() == null ? null : request.getProgramLobTypeCd().toUpperCase();
			// Pass the Request to the DAO (no need to populate a HashMap)
			UtilizationProviders dao = new UtilizationProviders();

			// Kill switch check on Provider groups
			if (StringUtils.isNotBlank(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			// Clinical access check on provider groups
			if (null != grps && grps.size() > 0) {

				grps = filterProvGrpsByClinicalInd(request, grps);
				request.setProvGrpIds(StringUtils.join(grps, ','));

				if (StringUtil.isJson(request)) {
					if (StringUtils.isNotBlank(pgmLobTypeCode)
						&& pgmLobTypeCode.contains(Constants.COMMERCIAL.toUpperCase())
						&& request.getMeasureName().contains(Constants.FRMLY)) {
						resultList.addAll(dao.getUtilizationFRMLYProviders(request));
						// calculates total without another query
					}
					else if (!request.getMeasureName().contains(Constants.FRMLY)) {
						resultList = dao.getUtilizationProviders(request);
					}

					MetaData metaData = buildMetaData(request, dao);
					response.setMetaData(metaData);

					response.setData(resultList);
					response.setTotal(dao.getRowCount()); // calculates total without another query
					response.setMessage(StringUtil.buildMessage(resultList.isEmpty()));
				}
				else {

					List<ExportGridColumn> columns = dao.buildExportGridColumns(request);
					if (StringUtil.isChartExport(request.getChartImageData())) {
						DrillDownChartExport exp = new DrillDownChartExport(request, Constants.PROVIDER);
						ExportProcessor.getInstance().submit(exp);
					}
					else {
						UtilizationProviderExport exp = new UtilizationProviderExport(request, columns);
						ExportProcessor.getInstance().submit(exp);
					}
				}
			}

			response.setSuccess(true);
		}
		catch (Exception e) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(e, response);
		}

		return response;
	}
}
