package com.wellpoint.pc2dash.action.medicalCostServiceDetails;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.performance.medicalCostPerformance.MedicalCostServiceDetailsDto;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.performance.McpDrilldownExport;
import com.wellpoint.pc2dash.service.medicalCost.MedicalCostServiceDetailsImpl;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;


public class GetMedicalCostServiceDetailsAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetMedicalCostServiceDetailsRequest request = (GetMedicalCostServiceDetailsRequest) actionRequest;
		GetMedicalCostServiceDetailsResponse response = new GetMedicalCostServiceDetailsResponse();
		ErrorProperties err = ErrorProperties.getInstance();

		MedicalCostServiceDetailsImpl service = new MedicalCostServiceDetailsImpl();
		List<MedicalCostServiceDetailsDto> resultList = new ArrayList<MedicalCostServiceDetailsDto>();
		List<String> grps = new ArrayList<String>();
		int totalRecords = 0;

		try {

			request.setShowMI(true);
			request.setAddHighCost(true);

			//Kill switch check on Provider groups
			if (StringUtil.isNotBlankOrFalse(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			//Financial access check on provider groups
			if (null != grps && grps.size() > 0) {
				grps = filterProvGrpsByFinancialInd(request, grps);
				//request.setProvGrpIds(StringUtils.join(grps, ','));
			}
			request.setProvGrpIds(StringUtils.join(grps, ','));

			if (null == request.getDest() || request.getDest().equalsIgnoreCase("json")) {

				if (StringUtils.isNotBlank(request.getProviderGroupDimKey())) {

					if (!CollectionUtils.isEmpty(grps)) {
						resultList = service.getData(request, false);
						totalRecords = service.getTotalRecords();
					}
					else {
						response.setData(resultList);
						response.setTotal(totalRecords);
						response.setMessage(err.getProperty("successful"));
					}
				}

				if (resultList == null || (null != resultList && resultList.isEmpty())) {
					response.setMessage(err.getProperty("successNoData"));
				}
				else {

					response.setData(resultList);
					response.setTotal(totalRecords);
					response.setMessage(err.getProperty("successful"));
				}
			}

			if (StringUtil.isExportDest(request.getDest())) {
				McpDrilldownExport exp = new McpDrilldownExport(request);
				ExportProcessor.getInstance().submit(exp);
			}

			response.setSuccess(true);
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

		return response;
	}
}
