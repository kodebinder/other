package com.wellpoint.pc2dash.action.performance;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetPerformanceHeaderCombosResponse extends ActionResponse {

}
