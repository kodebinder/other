package com.wellpoint.pc2dash.action.reconciliationReports;

import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;

public class GetReconciliationReportsRequest extends PerformanceManagementRequest {
	
	private String reconciliationReportsKeys; // TODO #ReconReports *If* UI sends as an array: change to List<String> and add to Controller.java's "hack" code near line 80; otherwise, treat as comma-delimited String

	public String getReconciliationReportsKeys() {
		return reconciliationReportsKeys;
	}

	public void setReconciliationReportsKeys(String reconciliationReportsKeys) {
		this.reconciliationReportsKeys = reconciliationReportsKeys;
	}

}
