package com.wellpoint.pc2dash.action.medicalCostTarget;

import com.wellpoint.pc2dash.action.medicalCostServiceDetails.GetMedicalCostServiceDetailsRequest;

public class GetMedicalCostTargetRequest extends GetMedicalCostServiceDetailsRequest {

}
