package com.wellpoint.pc2dash.action.quality;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.data.dao.CommercialImprovementQualityPatients;
import com.wellpoint.pc2dash.data.dao.MedicaidImprovementQualityPatients;
import com.wellpoint.pc2dash.data.dao.MedicaidQualityPatients;
import com.wellpoint.pc2dash.data.dao.QualityPatients;
import com.wellpoint.pc2dash.dto.patient.Patient;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportGridColumn;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.scorecard.commercial.QualityPatientExport;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.DateUtil;
import com.wellpoint.pc2dash.util.StringUtil;


public class GetQualityPatientsAction extends GetQualityAction {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetQualityPatientsRequest request = (GetQualityPatientsRequest) actionRequest;
		GetQualityResponse response = new GetQualityResponse();
		List<String> grps = new ArrayList<String>();
		List<Patient> resultList = new ArrayList<Patient>();

		try {
			String measStartDate = request.getMeasurementPeriodStartDt();
			boolean isMPGreaterThanOrEqual01012018 = DateUtil.dateComparator(measStartDate, Constants.IND_MTRC_STRT_DT);
			request = (GetQualityPatientsRequest) cleanRequest(request);
			QualityPatients dao1 = new QualityPatients();
			MedicaidQualityPatients dao2 = new MedicaidQualityPatients();
			MedicaidImprovementQualityPatients dao3 = new MedicaidImprovementQualityPatients();
			CommercialImprovementQualityPatients dao4 = new CommercialImprovementQualityPatients();

			boolean medicaidLOB = request.getProgramLobTypeCd().equalsIgnoreCase(Constants.MEDICAID);
			boolean medicareLOB = request.getProgramLobTypeCd().equalsIgnoreCase(Constants.MEDICARE) || request.getProgramLobTypeCd().equalsIgnoreCase(Constants.FPCC_MEDICARE);
			boolean commercialLOB = request.getProgramLobTypeCd().equalsIgnoreCase(Constants.COMMERCIAL);
			boolean fpccCommercialLOB = request.getProgramLobTypeCd().startsWith(Constants.FPCC_PGM_TYPE);
			boolean improvementComposite = request.getCompositeType().equalsIgnoreCase(Constants.IMPCOMPOSITETYPE);

			if (StringUtils.isNotBlank(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			if (null != grps && grps.size() > 0) {
				grps = filterProvGrpsByClinicalInd(request, grps);
			}

			// RA Action Menu Suppression
			prepareRASuppressionCond(request);

			// R1.9|LPR Suppression 61461|AD91912
			prepareLPRSuppressionCond(request);

			/*
			 * Determine whether Action Center is suppressed - it'll play a part in deciding whether to display
			 * the "i" icon in all of the Clinical Programs columns in Population Management and
			 * Performance Management drill-downs.
			 */
			CommonQueries cq = new CommonQueries();
			request.setGroupsWithActionCenterSuppressed(cq.getGroupsWithComponentSuppressed(request, Constants.AC_RF_CARDCONTAINER));
			List<ExportGridColumn> columns = new ArrayList<ExportGridColumn>();
			List<String> columnNames = new ArrayList<String>();

			if (StringUtil.isExport(request)) {

				columns = dao1.buildExportGridColumns(request);;
				columnNames = buildColumnNameList(columns);
			}

			if (null != grps && !grps.isEmpty()) {

				request.setProvGrpIds(StringUtils.join(grps, ','));
				request.setGrpInd(Constants.GRP_IND_N);

				if (StringUtil.isJson(request)) {
					MetaData metaData = new MetaData();

					if (!improvementComposite) {
						if (!medicaidLOB) {
							resultList.addAll(dao1.getQualityPatients(request, columnNames));
							response.setTotal(dao1.getRowCount()); // calculates total without another query
							metaData = buildMetaData(request, dao1);
						}
						else {
							resultList.addAll(dao2.getMedicaidQualityPatients(request, columnNames));
							response.setTotal(dao2.getRowCount()); // calculates total without another query
							metaData = buildMetaData(request, dao2);
						}
					}
					else {
						if (medicareLOB && isMPGreaterThanOrEqual01012018) {
							resultList.addAll(dao1.getQualityPatients(request, columnNames));
							response.setTotal(dao1.getRowCount()); // calculates total without another query
							metaData = buildMetaData(request, dao1);
						}
						else if (commercialLOB || fpccCommercialLOB) {
							resultList.addAll(dao4.getCommercialImprovementQualityPatients(request, columnNames));
							response.setTotal(dao4.getRowCount()); // calculates total without another query
							metaData = buildMetaData(request, dao4);
						}
						else if (medicaidLOB) {
							resultList.addAll(dao3.getMedicaidImprovementQualityPatients(request, columnNames));
							response.setTotal(dao3.getRowCount()); // calculates total without another query
							metaData = buildMetaData(request, dao3);
						}
						
					}

					response.setMetaData(metaData);
					response.setMessage(StringUtil.buildMessage(resultList.isEmpty()));
					response.setData(resultList);
				}
				else {

					QualityPatientExport exp = new QualityPatientExport(request, columns);
					ExportProcessor.getInstance().submit(exp);
				}
			}

			response.setSuccess(true);

		}
		catch (Exception e) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(e, response);
		}

		return response;
	}
}
