package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.costOpportunity.GetAverageCostPerRxDrugClassFilterRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.pharmacy.DrugClassFilter;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;

public class COCAverageCostPerRxDrugClassFilter extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(COCAverageCostPerRxDrugClassFilter.class);

	public List<DrugClassFilter> getAverageCostPerRxDrugDetails(GetAverageCostPerRxDrugClassFilterRequest request) throws Exception {

		List<DrugClassFilter> result = new ArrayList<DrugClassFilter>();
		
		StringBuilder sql = new StringBuilder()
		.append(" select distinct SUB_MTRC_NM as drug_cls_nm, SUB_MTRC_CD as drug_cls_cd from COC_RX_CTGRY_SMRY  ")
		.append(" order by drug_cls_cd ")
		.append(" with ur ");


		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			prepareStatement(logger, sql.toString());
			executeQuery(logger, sql.toString());

			while (rs.next()) {

				DrugClassFilter json = new DrugClassFilter();

				if (rs.getString("drug_cls_cd") != null) {
					json.setDrugClassCode(rs.getLong("drug_cls_cd"));
				}
				if (rs.getString("drug_cls_nm") != null) {
					json.setDrugClassName(rs.getString("drug_cls_nm").toString());
				}

				result.add(json);
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get COCAverageCostPerRxDrugClassFilter (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}
	
	

	@Override
	public boolean read(Dto o) throws Exception {

		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {


	}

	@Override
	public void update(Dto o) throws Exception {


	}

	@Override
	public void delete(Dto o) throws Exception {


	}


}
