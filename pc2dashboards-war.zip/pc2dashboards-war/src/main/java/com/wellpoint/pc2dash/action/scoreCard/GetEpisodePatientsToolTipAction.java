package com.wellpoint.pc2dash.action.scoreCard;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.data.dao.EpisodesPatientsToolTipDao;
import com.wellpoint.pc2dash.dto.scorecard.EpisodesPatientGrid;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetEpisodePatientsToolTipAction extends Action{

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetEpisodePatientsToolTipRequest request = (GetEpisodePatientsToolTipRequest) actionRequest;
		ActionResponse response = new GetEpisodePatientsToolTipResponse();
		ErrorProperties err = ErrorProperties.getInstance();

		List<EpisodesPatientGrid> resultList = new ArrayList<EpisodesPatientGrid>();
		EpisodesPatientsToolTipDao dao = new EpisodesPatientsToolTipDao();

		try {

			removeLobPgmPrefixes(request);


			if (StringUtil.isExportDest(request.getDest())) {

				//export code

			}
			else {
					resultList = dao.getPatientGrid(request);
					if (null == resultList || resultList.isEmpty()) {
						response.setMessage(err.getProperty("successNoData"));
					}
					else {
						//response.setMetaData(metaData);
						response.setMessage(err.getProperty("successful"));
						response.setData(resultList);
						response.setTotal(dao.getRowCount());
					}
			}

			response.setSuccess(true);
			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

	}

}
