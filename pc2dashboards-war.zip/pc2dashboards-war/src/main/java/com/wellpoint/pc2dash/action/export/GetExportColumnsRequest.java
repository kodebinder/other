package com.wellpoint.pc2dash.action.export;

import com.wellpoint.pc2dash.data.dto.PCMSRequest;

public class GetExportColumnsRequest extends PCMSRequest {

}
