package com.wellpoint.pc2dash.action.medicalCostBaseline;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetMedicalCostBaselineResponse extends ActionResponse {

}
