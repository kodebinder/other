package com.wellpoint.pc2dash.action.patients;

import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.patient.CostCategoryBean;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.patient.CostCategoryServiceImpl;
import com.wellpoint.pc2dash.util.ErrorProperties;


public class GetCostCategoryAction extends Action {

	List<CostCategoryBean> resultList;
	ActionResponse response = new GetCostCategoryResponse();
	ErrorProperties err = ErrorProperties.getInstance();
	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetCostCategoryAction.class);

	@SuppressWarnings("unchecked")
	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		//PCMSRequest request = new HashMap<String, String>();
		GetCostCategoryRequest request = (GetCostCategoryRequest) actionRequest;

		CostCategoryServiceImpl pC2Service = new CostCategoryServiceImpl();

		try {
			resultList = pC2Service.getData(request);
			ArrayList<CostCategoryBean> costCategoryList = (ArrayList<CostCategoryBean>) pC2Service.getBeanList(resultList);

			response = populateResponse(costCategoryList);
			response.setSuccess(true);

			if (resultList.isEmpty()) {
				response.setMessage(err.getProperty("successNoData"));
			}
			else {
				response.setMessage(err.getProperty("successful"));
			}

			return response;
		}
		catch (Exception pe) {

			logger.error("Unable to get cost Categories.", pe);

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}

	private ActionResponse populateResponse(ArrayList<CostCategoryBean> costCategoryList) {
		((GetCostCategoryResponse) (response)).setData(costCategoryList);
		return response;
	}
}
