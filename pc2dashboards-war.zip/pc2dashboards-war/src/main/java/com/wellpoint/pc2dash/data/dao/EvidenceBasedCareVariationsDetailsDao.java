package com.wellpoint.pc2dash.data.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.wellpoint.pc2dash.action.costOpportunity.GetEvidenceBasedCareVariationsDetailsRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.costOpportunity.EvidenceBasedCareVariationsDetailsBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.DateUtil;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class EvidenceBasedCareVariationsDetailsDao extends ServiceImpl {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(EvidenceBasedCareVariationsDetailsDao.class);

	public List<EvidenceBasedCareVariationsDetailsBean> getData(GetEvidenceBasedCareVariationsDetailsRequest request, boolean exportFlag, int index, int limit)
		throws Exception {

		List<EvidenceBasedCareVariationsDetailsBean> result = new ArrayList<EvidenceBasedCareVariationsDetailsBean>();
		setRowCount(0);

		boolean displayDashes = false;

		StringBuilder query = new StringBuilder()
			.append("select ")
			.append("	a.* ")
			.append("from ")
			.append("	( ")
			.append("		select ")
			.append("			row_number() over ( ")
			.append("				order by ")
			.append(buildSortClause(request))
			.append(" ) as row_nbr, ")
			.append(" mstr_cnsmr_dim_key, ip_dim_key, frst_nm,last_nm,brth_dt, age_nbr,gndr_cd,ip_frst_nm,ip_last_nm, memberId, ")
			.append(" serviceDate, orgName, serviceProv, serviceProvSpec, category, procedureCode, procedureDesc, ")
			.append(" count(*) over () as row_cnt ");
		if (StringUtil.isExportDest(request.getDest())) {
				query.append(" ,IP_SPCLTY_NM, ip_npi,orgtin, lob_desc, psl_desc,home_plan_nm,crprt_plan_cmpny_nm ");
		}	
		
		query.append(" from ( select distinct ")
			.append(" psf.MSTR_CNSMR_DIM_KEY AS mstr_cnsmr_dim_key, psf.ip_dim_key, upper(psf.frst_nm) as frst_nm, upper(psf.last_nm) as last_nm, ")
			.append(" nullif(psf.brth_dt, '0001-01-01') as brth_dt, psf.age_nbr,psf.gndr_cd, upper(psf.ip_frst_nm) as ip_frst_nm, ")
			.append(" upper(psf.ip_last_nm) as ip_last_nm, psf.hc_id memberId, smry.MOST_RCNT_SRVC_DT as serviceDate, psf.prov_org_full_nm  as orgName , ")
			.append(" smry.SRVCG_PROV_DSPLY_NM as serviceProv, smry.SRVCG_PROV_SPCLTY_NM as serviceProvSpec, ")
			.append(" smry.sub_mtrc_nm as category,smry.CPT_NDC_CD as procedureCode, smry.CPT_NDC_DESC as procedureDesc ");
		if (StringUtil.isExportDest(request.getDest())) {
			query.append(" ,psf.IP_SPCLTY_NM, psf.ip_npi,psf.prov_org_tax_id as orgtin, ")
				.append(" psf.lob_desc, psf.psl_desc, psf.crprt_plan_cmpny_nm,psf.home_plan_nm ");
		}
		
		query.append(" 	from coc_ebc_dtl_smry smry ")
		.append(" 	join  pat_smry_fact psf on   (psf.PROV_GRP_ID=smry.PROV_GRP_ID ")
		.append("   and psf.mstr_cnsmr_dim_key = smry.mstr_cnsmr_dim_key ")
		.append("	and psf.pgm_dim_key=smry.pgm_dim_key  and smry.IP_DIM_KEY=psf.IP_DIM_KEY ")
		.append("	and  smry.prov_org_dim_key =psf.prov_org_dim_key ")
		.append("	and smry.LOB_DESC=psf.LOB_DESC) ")
			.append("	join poit_user_scrty_acs pusa on ( ")
			.append("		psf.prov_grp_id = pusa.prov_grp_id ")
			.append("		and case ")
			.append("				when pusa.prov_org_tax_id = '0' then psf.prov_org_tax_id ")
			.append("				else pusa.prov_org_tax_id ")
			.append("			end = psf.prov_org_tax_id ")
			.append("	) ")
			.append(" WHERE  ")
			.append(" PSF.ATRBN_STTS_CD = 'ACTIVE' ")
			.append(" and pusa.sesn_id = ? ")
			.append(" and pusa.enttlmnt_hash_key = ? ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and smry.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and smry.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and smry.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and smry.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and smry.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getCategoryCode())) {
			query.append(" and smry.sub_mtrc_cd in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getCategoryCode())
				+ ") ");
		}

		query.append(" group by psf.MSTR_CNSMR_DIM_KEY , psf.ip_dim_key, upper(psf.frst_nm) , upper(psf.last_nm) ,")
			.append(" nullif(psf.brth_dt, '0001-01-01') , psf.age_nbr,psf.gndr_cd, upper(psf.ip_frst_nm) ,  upper(psf.ip_last_nm) , ")
			.append("psf.hc_id , smry.SRVCG_PROV_DSPLY_NM ,psf.prov_org_full_nm , smry.MOST_RCNT_SRVC_DT , smry.SRVCG_PROV_SPCLTY_NM, ")
			.append(" smry.sub_mtrc_nm, smry.CPT_NDC_CD , smry.CPT_NDC_DESC ");
		
		if (StringUtil.isExportDest(request.getDest())) {
			query.append(" ,psf.IP_SPCLTY_NM, psf.ip_npi,psf.prov_org_tax_id, ")
				.append(" psf.lob_desc, psf.psl_desc, psf.crprt_plan_cmpny_nm, psf.home_plan_nm ");
		}

		query.append(") ) a ");
		
		query.append(" where a.row_nbr between ? and ? ");
		query.append(" order by a.row_nbr  with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());

			buildPreparedStatement(request, i, exportFlag, index, limit);

			executeQuery(logger, query.toString());

			result = convertSelectedRowsToObjects(rs, request, displayDashes, exportFlag);

		}
		catch (Exception e) {

			throw new Exception("Unable to get EvidenceBasedCareVariationsDetailsDao (" + request.getEntitlementId() + ").", e);
		}
		finally {

			close();
		}

		return result;

	}

	private void buildPreparedStatement(GetEvidenceBasedCareVariationsDetailsRequest request, int i, boolean exportFlag, int index, int limit) throws SQLException {

		int start = 0;
		int stop = 0;

		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getCategoryCode())) {
			String[] array = request.getCategoryCode().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (!exportFlag) {
			start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
			stop = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
		}
		else {
			start = index;
			stop = limit;
		}
		ps.setInt(++i, start + 1);
		ps.setInt(++i, start + stop);

	}

	private List<EvidenceBasedCareVariationsDetailsBean> convertSelectedRowsToObjects(ResultSet rs, GetEvidenceBasedCareVariationsDetailsRequest request,
		boolean displayDashes, boolean exportFlag)
		throws SQLException {

		List<EvidenceBasedCareVariationsDetailsBean> list = new ArrayList<EvidenceBasedCareVariationsDetailsBean>();
			
		if (exportFlag) {
			while (rs.next()) {
				
				setTotalExport(rs.getInt("row_cnt"));   

				EvidenceBasedCareVariationsDetailsBean item = new EvidenceBasedCareVariationsDetailsBean();
				
				item.setCategory(StringUtil.getValueOrDashes(rs.getString("category")));
				item.setMemberLastName(StringUtil.getValueOrDashes(rs.getString("last_nm")));
				item.setMemberFirstName(StringUtil.getValueOrDashes(rs.getString("frst_nm")));
				item.setMemberGender(StringUtil.getValueOrDashes(rs.getString("gndr_cd")));
				if (rs.getString("age_nbr") != null)
					item.setMemberAge(rs.getShort("age_nbr"));
				if (rs.getString("brth_dt") != null) {
					item.setMemberDOB(DateUtil.formatDateToMMDDYYYY(
						"yyyy-MM-dd", "M/d/yyyy", rs.getString("brth_dt")));
				}
				else {
					item.setMemberDOB(Constants.DASHES);
				}
				item.setMemberId(StringUtil.getValueOrDashes(rs.getString("memberId")));
				item.setMemberLob(StringUtil.getValueOrDashes(rs.getString("lob_desc")));
				item.setMemberProduct(StringUtil.getValueOrDashes(rs.getString("psl_desc")));
				item.setMemberHomePlanParentCo(StringUtil.getValueOrDashes(rs.getString("crprt_plan_cmpny_nm")));
				item.setMemberHomePlan(StringUtil.getValueOrDashes(rs.getString("home_plan_nm")));	
	
				//Changed for release-Q1-2018/PCMSP-18421 : Starts
				item.setAttributedPhysicianName(CommonQueries.getFilteredProviderName(rs.getString("ip_frst_nm"),rs.getString("ip_last_nm")));				
				//Changed for release-Q1-2018/PCMSP-18421 : Ends

				item.setAttributedProvNpi(StringUtil.getValueOrDashes(rs.getString("ip_npi")));
				item.setAttributedProvSpeciality(StringUtil.getValueOrDashes(rs.getString("IP_SPCLTY_NM")));
				//Changed for release-Q1-2018/PCMSP-18530 : Starts
				if(null!= rs.getString("orgName"))
					item.setOrganizationName(rs.getString("orgName"));
				else
					item.setOrganizationName(Constants.DASHES);
				//Changed for release-Q1-2018/PCMSP-18530 : Ends;
				item.setOrganizationTin(StringUtil.getValueOrDashes(rs.getString("orgtin")));
				//PCMSP-17803
				//item.setServicingProvider(StringUtil.getValueOrDashes(rs.getString("serviceProv")));
				item.setServicingProvider((null != rs.getString("serviceProv") && !Constants.STAR.equalsIgnoreCase(rs.getString("serviceProv").trim())) ? 
						rs.getString("serviceProv") : Constants.DASHES);
				item.setServicingProviderSpecialty(StringUtil.getValueOrDashes(getSpecialtyServicingProvider(rs)));
				item.setProcedureCode(StringUtil.getValueOrDashes(rs.getString("procedureCode")));
				item.setProcedureDescription(StringUtil.getValueOrDashes(rs.getString("procedureDesc")));
				
				if (rs.getString("serviceDate") != null) {
					item.setServiceDt(DateUtil.formatDateToMMDDYYYY(
						"yyyy-MM-dd", "M/d/yyyy", rs.getString("serviceDate")));
				}
				else {
					item.setServiceDt(Constants.DASHES);
				}
				list.add(item);

				if (getRowCount() == 0) {
					setRowCount(rs.getInt("row_cnt"));
				}
			}
		}
		else {
			while (rs.next()) {

				EvidenceBasedCareVariationsDetailsBean item = new EvidenceBasedCareVariationsDetailsBean();

				if (rs.getString("age_nbr") != null)
					item.setMemberAge(rs.getShort("age_nbr"));
				if (rs.getString("brth_dt") != null) {
					item.setMemberDOB(DateUtil.formatDateToMMDDYYYY(
						"yyyy-MM-dd", "M/d/yyyy", rs.getString("brth_dt")));
				}
				else {
					item.setMemberDOB(Constants.DASHES);
				}
				item.setMemberLastName(StringUtil.getValueOrDashes(rs.getString("last_nm")));
				item.setMemberFirstName(StringUtil.getValueOrDashes(rs.getString("frst_nm")));
				item.setMemberGender(StringUtil.getValueOrDashes(rs.getString("gndr_cd")));
				item.setMemberId(StringUtil.getValueOrDashes(rs.getString("memberId")));

				if (rs.getString("frst_nm") != null
					&& rs.getString("last_nm") != null)
					item.setMemberFullName(StringUtil.buildFullName(
						rs.getString("frst_nm"), rs.getString("last_nm")));

				if (rs.getString("mstr_cnsmr_dim_key") != null)
					item.setMemberKey(rs.getLong("mstr_cnsmr_dim_key"));

				if (rs.getString("serviceDate") != null) {
					item.setServiceDt(DateUtil.formatDateToMMDDYYYY(
						"yyyy-MM-dd", "M/d/yyyy", rs.getString("serviceDate")));
				}
				else {
					item.setServiceDt(Constants.DASHES);
				}

				//Changed for release-Q1-2018/PCMSP-18421 : Starts
				item.setAttributedPhysicianName(CommonQueries.getFilteredProviderName(rs.getString("ip_frst_nm"),rs.getString("ip_last_nm")));				
				//Changed for release-Q1-2018/PCMSP-18421 : Ends

				//Changed for release-Q1-2018/PCMSP-18530 : Starts
				if(null!= rs.getString("orgName"))
					item.setOrganizationName(rs.getString("orgName"));
				else
					item.setOrganizationName(Constants.DASHES);
				//Changed for release-Q1-2018/PCMSP-18530 : Ends
				
				//PCMSP-17803
				//item.setServicingProvider(StringUtil.getValueOrDashes(rs.getString("serviceProv")));
				item.setServicingProvider((null != rs.getString("serviceProv") && !Constants.STAR.equalsIgnoreCase(rs.getString("serviceProv").trim())) ? 
						rs.getString("serviceProv") : Constants.DASHES);
				item.setServicingProviderSpecialty(StringUtil.getValueOrDashes(getSpecialtyServicingProvider(rs)));
				item.setCategory(StringUtil.getValueOrDashes(rs.getString("category")));
				item.setProcedureCode(StringUtil.getValueOrDashes(rs.getString("procedureCode")));
				item.setProcedureDescription(StringUtil.getValueOrDashes(rs.getString("procedureDesc")));

				list.add(item);

				if (getRowCount() == 0) {
					setRowCount(rs.getInt("row_cnt"));
				}

			}
		}

		return list;

	}

  /**
   * @param rs
   * @return
   * @throws SQLException
   */
  private String getSpecialtyServicingProvider(ResultSet rs) throws SQLException {
    String serviceProvSpec = rs.getString("serviceProvSpec").toLowerCase();
    
    if(StringUtils.isEmpty(serviceProvSpec)||serviceProvSpec.contains("not available")||serviceProvSpec.contains("unknown")
    		||serviceProvSpec.equalsIgnoreCase(Constants.DASHES)||serviceProvSpec.equalsIgnoreCase(Constants.UNK)){
      return Constants.UNKNOWN;
    }
    
    return rs.getString("serviceProvSpec");
  }

	private String buildSortClause(GetEvidenceBasedCareVariationsDetailsRequest request) {

		StringBuilder query = new StringBuilder();
		String defaultColumn = " category ";
		String defaultSort = defaultColumn + " asc ";

		if (null != request.getSort()) {

			for (QuerySort sort : request.getSort()) {

				String dir = sort.getDirection().replaceAll("\"", "");
				String property = sort.getProperty();

				if (property.equals("procedureDescription")) {
					query.append(" procedureDesc " + dir + ", " + defaultSort);
				}
				else if (property.equals("memberFullName")) {
					query.append("  last_nm " + dir + ", frst_nm " + dir);
				}
				else if (property.equals("attributedPhysicianName")) {
					query.append(" ip_last_nm " + dir + ", ip_frst_nm " + dir);
				}
				else if (property.equals("organizationName")) {
					query.append(" orgName " + dir + ", " + defaultSort);
				}
				else if (property.equals("category")) {
					query.append(" category " + dir + ", " + defaultSort);
				}
				else if (property.equals("procedureCode")) {
					query.append(" procedureCode " + dir + ", " + defaultSort);
				}
				else if (property.equals("servicingProviderSpecialty")) {
					query.append(" serviceProvSpec " + dir + ", " + defaultSort);
				}
				else if (property.equals("servicingProvider")) {
					query.append(" serviceProv " + dir + ", " + defaultSort);
				}
				else if (property.equals("procedureDescription")) {
					query.append(" procedureDesc " + dir + ", " + defaultSort);
				}
				else if (property.equals("servicingProvider")) {
					query.append(" serviceProv " + dir + ", " + defaultSort);
				}
				else if (property.equals("serviceDt")) {
					query.append(" serviceDate " + dir + ", " + defaultSort);
				}
				else {
					query.append(defaultColumn + dir);
				}
			}

		}

		return query.toString();

	}

}
