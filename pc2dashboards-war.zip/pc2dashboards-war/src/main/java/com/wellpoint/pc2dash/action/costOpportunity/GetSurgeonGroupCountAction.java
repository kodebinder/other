package com.wellpoint.pc2dash.action.costOpportunity;

import java.util.List;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.costOpportunity.SurgeonGroupCountBean;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.service.costOpportunity.SurgeonGroupCountServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;

public class GetSurgeonGroupCountAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		List<SurgeonGroupCountBean> resultList = null;

		GetSurgeonGroupCountRequest request = (GetSurgeonGroupCountRequest) actionRequest;
		GetSurgeonGroupCountResponse response = new GetSurgeonGroupCountResponse();
		ErrorProperties err = ErrorProperties.getInstance();
		SurgeonGroupCountServiceImpl service = new SurgeonGroupCountServiceImpl();	

		try {
			
					removeLobPgmPrefixes(request);	
					resultList = service.getData(request, Constants.BOOL_FALSE);

					if (null == resultList || resultList.isEmpty()) {
						response.setMessage(err.getProperty("successNoData"));
					} else {
						response.setMessage(err.getProperty("successful"));
						response.setData(resultList);
						response.setTotal(service.getNoOfRecords());
					}
				

			response.setSuccess(true);
			return response;
		} catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

	}

}