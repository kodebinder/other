package com.wellpoint.pc2dash.action.costOpportunity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.dto.costOpportunity.HighValueSpecialistReferralsSpecialistBean;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportGridColumn;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.costOpportunity.HighValueSpecialistReferralsSpecialistExport;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.costOpportunity.HighValueSpecialistReferralsSpecialistServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetHighValueSpecialistReferralsSpecialistAction extends Action {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetHighValueSpecialistReferralsSpecialistAction.class);

	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		List<HighValueSpecialistReferralsSpecialistBean> resultList = null;

		ActionResponse response = new GetHighValueSpecialistReferralsSpecialistResponse();
		GetHighValueSpecialistReferralsSpecialistRequest request = (GetHighValueSpecialistReferralsSpecialistRequest) actionRequest;
		ErrorProperties err = ErrorProperties.getInstance();

		HighValueSpecialistReferralsSpecialistServiceImpl service = new HighValueSpecialistReferralsSpecialistServiceImpl();
		List<String> filteredProvGrpList = new ArrayList<String>();


		try {

			removeLobPgmPrefixes(request);
			prepareChronicCareGapMap(request);


			if (StringUtils.isNotBlank(request.getCmpId())) {
				filteredProvGrpList = filterProvGrpsByKillSwitch(request);
			}
			//Clinical access check on provider groups
			/*if (null != filteredProvGrpList && filteredProvGrpList.size() > 0) {
				filteredProvGrpList = filterProvGrpsByClinicalInd(request, filteredProvGrpList);
			}*/

			if (null != filteredProvGrpList && !filteredProvGrpList.isEmpty()) {
				request.setProvGrpIdsWithoutClinicalCheck(StringUtils.join(filteredProvGrpList, ','));
				filteredProvGrpList = filterProvGrpsByClincalFinancialInd(request, filteredProvGrpList);
				request.setProvGrpIds(CollectionUtils.isNotEmpty(filteredProvGrpList) ? StringUtils.join(filteredProvGrpList, ',') : Constants.DASHES);
				request.setGrpInd(Constants.GRP_IND_N);

				CommonQueries cq = new CommonQueries();
				request.setTapId(request.getMetricViewId());// TO re-use available tap framework.
				request.setSuppression(cq.getActiveSuppressionForSelectComponents(request));
				
				MetaData metaData = new MetaData();
				metaData.setReportingPeriod(cq.getReportingPeriodForCostOpportunity(Constants.HIGH_VALUE_SPECIALIST_REFERRALS));
				metaData.setReportDate(cq.getReportDateForCostOpportunity(Constants.HIGH_VALUE_SPECIALIST_REFERRALS));

				if (StringUtil.isExportDest(request.getDest())) {
	            	request.setReportingPeriod(metaData.getReportingPeriod());
	            	request.setReportDate(metaData.getReportDate());
					List<ExportGridColumn> columns = service.buildExportGridColumns(request);
					HighValueSpecialistReferralsSpecialistExport exp = new HighValueSpecialistReferralsSpecialistExport(request, columns);
					
					ExportProcessor.getInstance().submit(exp);
					}
				else {

					request.setHasEpisodesDrilldownInd(isUserClinical(request));
					resultList = service.getData(request);
					
					if (null != resultList && !resultList.isEmpty()) {
						response.setData(resultList);
						response.setMessage(err.getProperty("successful"));
						response.setTotal(service.getNoOfRecords());
						response.setMetaData(metaData);
					}
					else {
						response.setMessage(err.getProperty("successNoData"));
					}

				}

			}

			logger.debug("success");
			response.setSuccess(true);
			return response;

		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

	}

}
