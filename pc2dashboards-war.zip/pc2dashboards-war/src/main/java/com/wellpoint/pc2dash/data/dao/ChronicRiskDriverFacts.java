package com.wellpoint.pc2dash.data.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.action.tooltip.GetPatientDetailRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.patient.ChronicCareGaps;
import com.wellpoint.pc2dash.dto.patient.RiskDrivers;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;


public class ChronicRiskDriverFacts extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(ChronicRiskDriverFacts.class);

	private static final int ZERO = 0;

	public boolean read(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void insert(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void update(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void delete(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public Collection<RiskDrivers> getChronicRiskDrivers(GetPatientDetailRequest request) throws Exception {
		Collection<RiskDrivers> result = new ArrayList<RiskDrivers>();
		try {
			String sql = prepareQueryConnection(request, Boolean.FALSE);
			executeQuery(logger, sql.toString());
			// Result Set.
			while (rs.next()) {
				prepareDataForRiskDriver(result);
			}
		}
		catch (Exception e) {
			throw new Exception("Unable to get chronic risk drivers (" + request.getEntitlementId() + ", "
				+ request.getMemberKey() + ").", e);
		}
		finally {
			close();
		}
		return result;
	}

	/**
	 * @param request
	 * @return
	 * @throws Exception
	 * @throws SQLException
	 */
	private String prepareQueryConnection(GetPatientDetailRequest request, Boolean isCareGap)
		throws Exception, SQLException {
		String sql = buildQueryForChronicRiskDrivers(isCareGap);
		cn = Database.getConnection(Constants.RPT_DATASOURCE);
		prepareStatement(logger, sql.toString());
		ps.setString(1, request.getSessionId());
		ps.setString(2, request.getEntitlementId());
		ps.setString(3, request.getMemberKey());
		//		if (isCareGap) {
		//			ps.setString(4, request.getSessionId());
		//			ps.setString(5, request.getEntitlementId());
		//			ps.setString(6, request.getMemberKey());
		//		}
		// logger.debug("sesn_id: " + request.getSessionId());
		// logger.debug("enttlmnt_hash_key: " + request.getEntitlementId());
		// logger.debug("mstr_cnsmr_dim_key: " + request.getMemberKey());
		return sql;
	}

	private void prepareDataForRiskDriver(Collection<RiskDrivers> result) throws Exception {
		RiskDrivers r;
		r = new RiskDrivers();
		/** 57008 CHRONIC_CARE_GAP changes| ad87338 | START */
		String cdValName = getString(rs, "cd_val_nm");
		if (Constants.HIGH_RISK_COMORBIDITIES.equalsIgnoreCase(cdValName)) {
			r.setChronicRiskDriverName(cdValName);
		}
		else {
			r.setChronicRiskDriverName(Constants.CHRONIC_CARE_GAP);
		}
		/** 57008 CHRONIC_CARE_GAP changes| ad87338 | END */
		r.setPriorityNo(Short.parseShort(getInt(rs, "prty_nbr")));
		if (!result.contains(r)) {
			result.add(r);
		}
	}

	public Collection<ChronicCareGaps> getChronicRiskDrivers(GetPatientDetailRequest request,
		Boolean... isChronicGapScore) throws Exception {
		Collection<ChronicCareGaps> result = new ArrayList<ChronicCareGaps>();
		try {
			String sql = prepareQueryConnection(request, Boolean.TRUE);
			executeQuery(logger, sql.toString());
			// Result Set.
			if ((null != isChronicGapScore && ZERO != isChronicGapScore.length)) {
				if (isChronicGapScore[ZERO]) {
					while (rs.next()) {
						String cdValName = getString(rs, "cd_val_nm");
						if (!(Constants.HIGH_RISK_COMORBIDITIES.equalsIgnoreCase(getString(rs, "cd_val_nm")))) {
							ChronicCareGaps c = new ChronicCareGaps();
							c.setRiskScoreIndicator(cdValName);
							c.setPriorityNo(Short.parseShort(getInt(rs, "prty_nbr")));
							result.add(c);
						}

					}
				}
			}
		}
		catch (Exception e) {
			throw new Exception("Unable to get chronic risk drivers (" + request.getEntitlementId() + ", "
				+ request.getMemberKey() + ").", e);
		}
		finally {
			close();
		}
		return result;
	}

	public String getChronicRiskDriversForExport(GetPatientDetailRequest request) throws Exception {

		String result = "";

		StringBuilder sql = new StringBuilder()
			.append("select ")
			.append("	listagg(cd.cd_val_nm, ',') as chronic_risk_drivers ")
			.append("from ")
			.append("	chrnc_risk_drvr_fact crdf ")
			.append("	join mstr_cnsmr_fact mcf on (crdf.mstr_cnsmr_dim_key = mcf.mstr_cnsmr_dim_key) ")
			.append("	join cd_dim cd on (crdf.risk_drvr_cd_dim_key = cd.cd_dim_key) ")
			.append("	join poit_user_scrty_acs pusa on ( ")
			.append("		mcf.prov_grp_id = pusa.prov_grp_id ")
			.append("		and case ")
			.append("				when pusa.prov_org_tax_id = '0' then mcf.prov_org_tax_id ")
			.append("				else pusa.prov_org_tax_id ")
			.append("			end = mcf.prov_org_tax_id ")
			.append("	) ")
			.append("where ")
			.append("	pusa.sesn_id = ? ")
			.append("	and pusa.enttlmnt_hash_key = ? ")
			.append("	and mcf.mstr_cnsmr_dim_key = ? ")
			.append("with ur ");

		//		logger.debug("getChronicRiskDriversForExport SQL: " + sql.toString());

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());
			ps.setString(1, request.getSessionId());
			ps.setString(2, request.getEntitlementId());
			ps.setString(3, request.getMemberKey());

			//logger.debug("sesn_id: " + request.getSessionId());
			//logger.debug("enttlmnt_hash_key: " + request.getEntitlementId());
			//logger.debug("mstr_cnsmr_dim_key: " + request.getMemberKey());

			executeQuery(logger, sql.toString());

			rs.next();
			if (rs.getString("chronic_risk_drivers") != null) {
				result = rs.getString("chronic_risk_drivers");
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get chronic risk drivers for export (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}

	public static String buildQueryForChronicRiskDrivers(Boolean isCareGap) {
		StringBuilder sql = new StringBuilder()
			//				.append("(select ")
			//				.append("	cd.cd_val_nm, ")
			//				.append("	coalesce(crdf.prty_nbr, -1) as prty_nbr ")
			//				.append("from ")
			//				.append("	chrnc_risk_drvr_fact crdf ")
			//				.append("	join mstr_cnsmr_fact mcf on (crdf.mstr_cnsmr_dim_key = mcf.mstr_cnsmr_dim_key) ")
			//				.append("	join cd_dim cd on (crdf.risk_drvr_cd_dim_key = cd.cd_dim_key) ")
			//				.append("	join poit_user_scrty_acs pusa on ( ")
			//				.append("		mcf.prov_grp_id = pusa.prov_grp_id ")
			//				.append("		and case ")
			//				.append("				when pusa.prov_org_tax_id = '0' then mcf.prov_org_tax_id ")
			//				.append("				else pusa.prov_org_tax_id ")
			//				.append("			end = mcf.prov_org_tax_id ")
			//				.append("	) ")
			//				.append("where ")
			//				.append("	pusa.sesn_id = ? ")
			//				.append("	and pusa.enttlmnt_hash_key = ? ")
			//				.append("	and mcf.mstr_cnsmr_dim_key = ? ")
			//				.append("order by ")
			//				.append("	crdf.prty_nbr asc, ")
			//				.append("	cd.cd_val_nm ")
			//				.append("with ur )");

			/** PCMSP-2999, AF21144 */
			.append("(SELECT ")
			.append("RISK_DRVR_NM AS CD_VAL_NM, ")
			.append("SORT_NBR AS PRTY_NBR ")
			.append("FROM ")
			.append("PAT_RISK_DRVR PRD ")
			.append("JOIN  PAT_SMRY_FACT PSF ON (PRD.PAT_ID= PSF.MSTR_CNSMR_DIM_KEY) ")
			.append("	join poit_user_scrty_acs pusa on ( ")
			.append("		psf.prov_grp_id = pusa.prov_grp_id ")
			.append("		and case ")
			.append("				when pusa.prov_org_tax_id = '0' then psf.prov_org_tax_id ")
			.append("				else pusa.prov_org_tax_id ")
			.append("			end = psf.prov_org_tax_id ")
			.append("	) ")
			.append("where ")
			.append("	pusa.sesn_id = ? ")
			.append("	and pusa.enttlmnt_hash_key = ? ")
			.append("	and psf.mstr_cnsmr_dim_key = ? ")
			.append("	and PRD.RISK_DRVR_TYPE_CD in ('C','NC' "); // PCMSP-5215
		if (isCareGap)
			sql.append(", 'NC'");
		sql.append(") ")
			.append("order by ")
			.append(" PRD.SORT_NBR ASC, ")
			.append(" RISK_DRVR_NM ")
			.append("with ur )");
		//		if (isCareGap) {
		//			sql.append(" UNION ")
		//			        .append("(select ")
		//			        .append("	cd.cd_val_nm, ")
		//			        .append("	coalesce(rrdf.prty_nbr, -1) as prty_nbr ")
		//			        .append("from (")
		//			        .append("	select  af.mstr_cnsmr_dim_key, af.authrzn_fact_key, row_number () over (partition by af.mstr_cnsmr_dim_key order by af.admt_dt desc) as rank")
		//			        .append("	from authrzn_fact af ")
		//			        .append("	join  mstr_cnsmr_fact mcf on (af.mstr_cnsmr_dim_key = mcf.mstr_cnsmr_dim_key)")
		//			        .append("	join  poit_user_scrty_acs pusa on ( mcf.prov_grp_id = pusa.prov_grp_id")
		//			        .append("				and case ")
		//			        .append("						when pusa.prov_org_tax_id = '0' then mcf.prov_org_tax_id ")
		//			        .append("						else pusa.prov_org_tax_id ")
		//			        .append("					end = mcf.prov_org_tax_id ")
		//			        .append("			) ")
		//			        .append("		where ")
		//			        .append("			pusa.sesn_id = ? ")
		//			        .append("			and pusa.enttlmnt_hash_key = ? ")
		//			        .append("			and af.care_plan_ind_cd = 'Y' ")
		//			        .append("			and af.AUTHRZD_STTS_IND_CD='Y' ) mx")
		//			        .append("	join readmsn_risk_drvr_fact rrdf on (mx.authrzn_fact_key = rrdf.authrzn_fact_key) ")
		//			        .append("	join cd_dim cd on (rrdf.risk_drvr_cd_dim_key = cd.cd_dim_key) ")
		//			        .append("	where mx.rank = 1 and mx.mstr_cnsmr_dim_key = ? ")
		//			        .append("order by ")
		//			        .append("	coalesce(rrdf.prty_nbr, -1), ")
		//			        .append("	cd.cd_val_nm ")
		//			        .append("with ur )");
		//		}
		return sql.toString();
	}
}
