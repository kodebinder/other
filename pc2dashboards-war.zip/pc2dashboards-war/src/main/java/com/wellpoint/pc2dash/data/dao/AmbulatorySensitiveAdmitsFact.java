package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.action.tooltip.GetPatientDetailRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.utilization.AmbltrySenstvAdmtsRowEx;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;

public class AmbulatorySensitiveAdmitsFact extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(VisitFacts.class);

	public boolean read(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void insert(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void update(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void delete(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}


	public Collection<AmbltrySenstvAdmtsRowEx> getAmbulatorySensitiveAdmits(GetPatientDetailRequest request) throws Exception {

		Collection<AmbltrySenstvAdmtsRowEx> result = new ArrayList<AmbltrySenstvAdmtsRowEx>();

		StringBuilder sql = new StringBuilder()
			.append("select ")
			.append("	vf.admt_dt, ")
			.append("	vf.dschrg_dt, ")
			//.append("	vf.alwd_amt, ")
			.append("	vf.fclty_nm, ")
			.append("   ip.ip_frst_nm, ")
			.append("   ip.ip_last_nm, ")
			.append("	case ")
			.append("		when diag_1.cd_val_nm = '***' then '*** - ***' ")
			.append("		when DIAG_1.CD_SET_NM like '%ICD10' then coalesce(rtrim(diag_1.cd_val_txt) || ' - ' || diag_1.cd_val_long_desc, '---') ") //added ICD10 AP41
			.append("		else coalesce(rtrim(diag_1.cd_val_txt) || ' - ' || diag_1.cd_val_nm, '---') ")
			.append("	end as admtg_diag_nm ")
			.append("from ")
			.append("	vst_fact vf ")
			.append("	JOIN CLM_VST_UM_XREF AS CVUX ON (VF.VST_FACT_KEY = CVUX.VST_FACT_KEY) ")
			.append("	JOIN CMPLNC_UM_DTL_FACT AS CUDF ON (CUDF.CMPLNC_UM_DTL_FACT_KEY = CVUX.CMPLNC_UM_DTL_FACT_KEY ")
			.append("	AND CUDF.MSTR_CNSMR_DIM_KEY = CVUX.MSTR_CNSMR_DIM_KEY")
			.append("	) ")
			.append("   LEFT JOIN IP_DIM IP ON (IP.IP_DIM_KEY = VF.RNDRG_IP_DIM_KEY) ")
			.append("	join cd_dim srvc_type on (vf.srvc_type_cd_dim_key = srvc_type.cd_dim_key) ")
			.append("	left join cd_dim diag_1 on (vf.prncpl_diag_cd_dim_key = diag_1.cd_dim_key) ")
			.append("where ")
			.append("  cudf.mstr_cnsmr_dim_key = ? ")
			.append("	and cudf.msrmnt_prd_strt_dt = ?") //added to remove duplicate records in pop up
			.append("	and srvc_type.cd_val_txt = 'IP' ")
			.append("	and cudf.clm_line_srvc_strt_dt >= (current_date - day(current_date) day +1 day) - 15 MONTHS ")
			/*
			 * Adding the subCmpstNm check in order to differentiate between the ASA and RAR records
			 * considering the cdValTxt for both is IP
			 */
			.append("  and cudf.sub_cmpst_nm = 'ASC' ")
			.append("order by ")
			.append("	vf.admt_dt desc ")
			.append("with ur ");

		//		logger.debug("getEmergencyVisits SQL: " + sql.toString());

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());
			ps.setString(1, request.getMemberKey());
			ps.setString(2, request.getMeasurementPeriodStartDt());

			//logger.debug("mstr_cnsmr_dim_key: " + request.getMemberKey());

			executeQuery(logger, sql.toString());

			while (rs.next()) {

				AmbltrySenstvAdmtsRowEx r = new AmbltrySenstvAdmtsRowEx();
				r.setAdmitDate(getDate(rs, "admt_dt"));
				r.setDischargeDate(getDate(rs, "dschrg_dt"));
				r.setFacilityName(getString(rs, "fclty_nm"));
				r.setAdmittingPhysicianName(getString(rs, "ip_frst_nm") + " " + getString(rs, "ip_last_nm"));
				r.setAdmittingDiagnosis(getString(rs, "admtg_diag_nm"));
				/*
				 * Hard coding right now - as per discussion; data is not available as of now. 
				 * For the iteration purposes, hard coding the JSON parameter to 100 to reflect on the UI
				 */
				/*
				 * 11 Dec 2015 - Removing the hard coding following the discussion with the data team
				 * 04th January 2016 - Following the RTM Update, Cost of Admits not to be shown in the pop up, hence commenting the following setter
				 */
				/*if(null != rs.getBigDecimal("alwd_amt"))
					r.setAdmitCost(rs.getBigDecimal("alwd_amt").toString());
				else
					r.setAdmitCost(Constants.DASHES);*/
				result.add(r);
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get emergency visits (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}
}
