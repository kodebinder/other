package com.wellpoint.pc2dash.action.costOpportunity;

import com.wellpoint.pc2dash.data.dto.PopulationManagementRequest;

public class GetSurgeonGroupCountRequest extends PopulationManagementRequest {

	private String facilityTaxId;

	public String getFacilityTaxId() {
		return facilityTaxId;
	}

	public void setFacilityTaxId(String facilityTaxId) {
		this.facilityTaxId = facilityTaxId;
	}
	
	
	
}
