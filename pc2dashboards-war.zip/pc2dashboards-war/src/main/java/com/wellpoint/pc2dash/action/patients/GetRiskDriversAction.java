package com.wellpoint.pc2dash.action.patients;

import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.patient.RiskDrivers;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.service.patient.RiskDriversServiceImpl;
import com.wellpoint.pc2dash.util.ErrorProperties;

public class GetRiskDriversAction extends Action {

	@SuppressWarnings("unchecked")
	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		List<RiskDrivers> resultList;
		ActionResponse response = new GetRiskDriversResponse();
		GetRiskDriversRequest request = (GetRiskDriversRequest) actionRequest;
		RiskDriversServiceImpl service = new RiskDriversServiceImpl();
		ErrorProperties err = ErrorProperties.getInstance();

		try {
			buildProvGrpIdList(request);
			resultList = service.getData(request);
			ArrayList<RiskDrivers> riskDriversList = (ArrayList<RiskDrivers>) service.getBeanList(resultList);

			response.setData(riskDriversList);
			response.setSuccess(true);
			if (resultList.isEmpty()) {
				response.setMessage(err.getProperty("successNoData"));
			}
			else {
				response.setMessage(err.getProperty("successful"));
			}
			return response;
		}
		catch (Exception pe) {
			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}

}
