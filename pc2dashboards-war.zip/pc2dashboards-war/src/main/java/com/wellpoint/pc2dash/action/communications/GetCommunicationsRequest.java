package com.wellpoint.pc2dash.action.communications;

import com.wellpoint.pc2dash.data.dto.PCMSRequest;

public class GetCommunicationsRequest extends PCMSRequest {

}
