package com.wellpoint.pc2dash.action.utilization;

import java.util.List;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.data.dao.PAERMeasuresDao;
import com.wellpoint.pc2dash.dto.utilization.PAERMeasuresBean;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.ErrorProperties;

public class GetPAERMeasuresAction extends Action {

	List<PAERMeasuresBean> resultList;
	ActionResponse response = new GetPAERMeasuresResponse();
	ErrorProperties err = ErrorProperties.getInstance();
	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetPAERMeasuresAction.class);

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetPAERMeasuresRequest request = (GetPAERMeasuresRequest) actionRequest;
		PAERMeasuresDao dao = new PAERMeasuresDao();

		try {
			resultList = dao.getPAERMeasures(request);

			if (null == resultList || resultList.isEmpty()) {
				response.setMessage(err.getProperty("successNoData"));
			}
			else {
				response.setData(resultList);
				response.setMessage(err.getProperty("successful"));
			}

			response.setSuccess(true);
			return response;
		}
		catch (Exception pe) {

			logger.error("Unable to get GetPAERMeasuresAction.", pe);

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

	}


}