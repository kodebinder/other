package com.wellpoint.pc2dash.action.audit;

import com.wellpoint.pc2dash.data.dto.PCMSRequest;
import com.wellpoint.pc2dash.util.StringUtil;


public class AuditRequest extends PCMSRequest {

	protected String accessType;
	protected String ipAddress;
	protected String patientId;
	protected String referenceId;

	public boolean isValid() {

		if (!StringUtil.isNotBlankOrFalse(patientId))
			return false;
		if (!StringUtil.isNotBlankOrFalse(accessType))
			return false;

		if (!StringUtil.isNotBlankOrFalse(referenceId)) {
			referenceId = patientId;
		}

		return true;
	}

	public String getAccessType() {
		return accessType;
	}

	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}
}
