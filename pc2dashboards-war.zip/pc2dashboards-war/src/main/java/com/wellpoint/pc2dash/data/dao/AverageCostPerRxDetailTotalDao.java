package com.wellpoint.pc2dash.data.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.costOpportunity.GetAverageCostPerRxDetailTotalRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.costOpportunity.AverageCostPerRxDetailBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;

public class AverageCostPerRxDetailTotalDao extends ServiceImpl {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(AverageCostPerRxDetailDao.class);

	public List<AverageCostPerRxDetailBean> getData(GetAverageCostPerRxDetailTotalRequest request, boolean exportFlag, int index, int limit) throws Exception {

		List<AverageCostPerRxDetailBean> result = new ArrayList<AverageCostPerRxDetailBean>();
		setRowCount(0);

		boolean displayDashes = false;

		StringBuilder query = new StringBuilder()
			.append("select ")
			.append("	a.* ")
			.append("from ")
			.append("	( ")
			.append("		select ")
			.append(" sum(smry.rx_cnt) as ttl_rx_cnt ")
			.append(" 	from coc_rx_dtl_smry as smry ")
			.append("	join poit_user_scrty_acs pusa on ( ")
			.append("		smry.prov_grp_id = pusa.prov_grp_id ")
			.append("		and case ")
			.append("				when pusa.prov_org_tax_id = '0' then smry.prov_org_tax_id ")
			.append("				else pusa.prov_org_tax_id ")
			.append("			end = smry.prov_org_tax_id ")
			.append("	) ")
			.append(" where  ")
			.append(" pusa.sesn_id = ? ")
			.append(" and pusa.enttlmnt_hash_key = ? ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and smry.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and smry.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and smry.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and smry.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and smry.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}
		
		// PCMSP-16136 - Code change for having absolute search instead of like search
		if (StringUtil.isNotBlankOrFalse(request.getDrugName())) {
			query.append(" and upper(smry.drug_nm) = ? ");
		}
		
		/** PCMSP-21970 - Code change for having drill down search from drug detail to detail view
		 * since drug name for brand category drugs in detail view was changed to actual name, business wanted taht if they drill down to detail view using the brand category
		 * in drug detail view, it should filter all drugs related to the category. hence the absolute search implemented using PCMSP-16136 wont work in this scenario.
		 */
		if (StringUtil.isNotBlankOrFalse(request.getDrugCtgryName())) {
			query.append(" and upper(smry.drug_ctgry_nm) = ? ");
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getDrugClassKeys())) {
            query.append(" and smry.SUB_MTRC_CD in ("
                + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getDrugClassKeys())
                + ") ");
        }
		
		query.append(") a ")
		.append(" with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());

			buildPreparedStatement(request, i, exportFlag, index, limit);

			executeQuery(logger, query.toString());

			result = convertSelectedRowsToObjects(rs, request, displayDashes, exportFlag);

		}
		catch (Exception e) {

			throw new Exception("Unable to get AverageCostPerRxDetailTotalDao (" + request.getEntitlementId() + ").", e);
		}
		finally {

			close();
		}

		return result;

	}

	private void buildPreparedStatement(GetAverageCostPerRxDetailTotalRequest request, int i, boolean exportFlag, int index, int limit) throws SQLException {
		
		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getDrugName())) {
			ps.setString(++i, request.getDrugName().toUpperCase());
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getDrugCtgryName())) {
			ps.setString(++i, request.getDrugCtgryName().toUpperCase());
		}  
		
		if (StringUtil.isNotBlankOrFalse(request.getDrugClassKeys())) {
            String[] array = request.getDrugClassKeys().split(",");
            for (String item : array) {
                ps.setString(++i, item);
            }
        }
	}

	private List<AverageCostPerRxDetailBean> convertSelectedRowsToObjects(ResultSet rs, GetAverageCostPerRxDetailTotalRequest request,
		boolean displayDashes, boolean exportFlag)
		throws SQLException {

		List<AverageCostPerRxDetailBean> list = new ArrayList<AverageCostPerRxDetailBean>();

		while (rs.next()) {

			AverageCostPerRxDetailBean item = new AverageCostPerRxDetailBean();

			if (rs.getString("ttl_rx_cnt") != null) {
				item.setDrugName("TOTAL");
				item.setTotalScripts(rs.getString("ttl_rx_cnt"));
				
				list.add(item);
			}
		}

		return list;
	}
}