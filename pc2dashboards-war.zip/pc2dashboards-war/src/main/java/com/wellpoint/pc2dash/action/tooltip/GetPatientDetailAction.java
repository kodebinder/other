package com.wellpoint.pc2dash.action.tooltip;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.JsonObject;
import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.data.dao.AmbulatorySensitiveAdmitsFact;
import com.wellpoint.pc2dash.data.dao.AttributionFacts;
import com.wellpoint.pc2dash.data.dao.AuthorizationFacts;
import com.wellpoint.pc2dash.data.dao.AvoidableErVisitsFact;
import com.wellpoint.pc2dash.data.dao.BrandFormularyDetailsFact;
import com.wellpoint.pc2dash.data.dao.BrandFormularyDrugDetailsFacts;
import com.wellpoint.pc2dash.data.dao.CMDMFacts;
import com.wellpoint.pc2dash.data.dao.CareOpportunityFacts;
import com.wellpoint.pc2dash.data.dao.ChronicRiskDriverFacts;
import com.wellpoint.pc2dash.data.dao.CostByServiceFacts;
import com.wellpoint.pc2dash.data.dao.DiseaseConditionFacts;
import com.wellpoint.pc2dash.data.dao.EligibleMeasureFacts;
import com.wellpoint.pc2dash.data.dao.GDRDrugDetailsFacts;
import com.wellpoint.pc2dash.data.dao.HighRiskDriversFacts;
import com.wellpoint.pc2dash.data.dao.ReadmissionReAdmitsFact;
import com.wellpoint.pc2dash.data.dao.ReadmissionRiskDriverFacts;
import com.wellpoint.pc2dash.data.dao.ReadmissionTotalIndexAdmitsFact;
import com.wellpoint.pc2dash.data.dao.ReferralFacts;
import com.wellpoint.pc2dash.data.dao.VisitFacts;
import com.wellpoint.pc2dash.data.dao.VisitSummaryFacts;
import com.wellpoint.pc2dash.data.tooltip.dao.SupplementalADTToolTipDao;// Added for PCMS-512
import com.wellpoint.pc2dash.dto.patient.CMDMPrograms;
import com.wellpoint.pc2dash.exception.PC2Exception;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;


public class GetPatientDetailAction extends Action {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetPatientDetailAction.class);
	boolean isAttested = false;
	boolean hasSensitive = false;

	public ActionResponse process(ActionRequest actionRequest) {

		ActionResponse result = new GetPatientDetailResponse();
		GetPatientDetailRequest request = (GetPatientDetailRequest) actionRequest;
		ErrorProperties err = ErrorProperties.getInstance();
		try {

			Collection<Object> vals;

			String typeCd = request.getTypeCd();

			if (null != typeCd && typeCd.equalsIgnoreCase("attributionHistory")) {
				vals = getAttributionHistory(request);
			}
			else if (null != typeCd && typeCd.equalsIgnoreCase("careOpportunities")) {
				vals = getCareOpportunities(request);
			}
			else if (null != typeCd && typeCd.equalsIgnoreCase("cmDMPrograms")) {
				vals = getCMDMPrograms(request);
			}
			else if (null != typeCd && typeCd.equalsIgnoreCase("eligibleMeasures")) {
				vals = getEligibleMeasures(request);
			}
			else if (null != typeCd && typeCd.equalsIgnoreCase("diseaseConditions")) {
				vals = getDiseaseConditions(request);
				JsonObject jsonObject = new JsonObject();
				jsonObject.addProperty("hasSensitiveInformation", hasSensitive);
				result.setMetaData(jsonObject);
			}
			else if (null != typeCd && typeCd.equalsIgnoreCase("costByService")) {
				vals = getCostByService(request);
			}
			else if (null != typeCd && typeCd.equalsIgnoreCase("emergencyVisits")) {
				vals = getEmergencyVisits(request);
				JsonObject jsonObject = new JsonObject();
				jsonObject.addProperty("hasSensitiveInformation", hasSensitive);
				result.setMetaData(jsonObject);
			}
			else if (null != typeCd && Constants.INPATIENT_ADMISSION_TYPE_CD.equalsIgnoreCase(typeCd)) {
				vals = getInpatientAdmits(request);
				JsonObject jsonObject = new JsonObject();
				jsonObject.addProperty("hasSensitiveInformation", hasSensitive);
				result.setMetaData(jsonObject);
			}
			else if (null != typeCd && typeCd.equalsIgnoreCase("chronicRiskDrivers")) {
				vals = getChronicRiskDrivers(request);
			}
			/** 57008 CHRONIC_CARE_GAP changes| ad87338 | START */
			else if (null != typeCd && typeCd.equalsIgnoreCase("chronicCareGapScoresDetail")) {
				vals = getChronicRiskDrivers(request, Boolean.TRUE);
			}
			/** 57008 CHRONIC_CARE_GAP changes| ad87338 | END */
			else if (null != typeCd && typeCd.equalsIgnoreCase("inpatientAdmissions")) {
				vals = getInpatientAdmissions(request);
				JsonObject jsonObject = new JsonObject();
				jsonObject.addProperty("hasSensitiveInformation", hasSensitive);
				result.setMetaData(jsonObject);
			}
			else if (null != typeCd && typeCd.equalsIgnoreCase("readmissionRiskDrivers")) {
				vals = getReadmissionRiskDrivers(request);
			}
			else if (null != typeCd && typeCd.equalsIgnoreCase("visits")) {
				vals = getVisits(request);
			}
			else if (null != typeCd && typeCd.equalsIgnoreCase("ambulatorySensitiveAdmits")) {
				vals = getAmbulatorySensitiveAdmits(request);
			}
			else if (null != typeCd && typeCd.equalsIgnoreCase("avoidableErVisits")) {
				vals = getAvoidableErVisits(request);
			}
			else if (null != typeCd && typeCd.equalsIgnoreCase("gdrDrugsDetail")) {
				vals = getGDRDrugDetails(request);
			}
			/*PCMSP-9481 STARTS 1*/
			else if (null != typeCd && typeCd.equalsIgnoreCase(Constants.FRMLY_PATIENT)) {
				vals = getBrandFormularyPatientDrugDetails(request);
			}
			/*PCMSP-9481 ENDS 1*/
			else if (null != typeCd && typeCd.equalsIgnoreCase(Constants.FRMLY_PROVIDER)) {
				vals = getBrandFormularyProviderDrugDetails(request);
			}
			else if (null != typeCd && typeCd.equalsIgnoreCase("totalIndexAdmission")) {
				vals = getRARTotalIndexAdmitsDetails(request);
			}
			else if (null != typeCd && typeCd.equalsIgnoreCase("totalReadmission")) {
				vals = getRARReadmissionDetails(request);
			}
			else if (null != typeCd && typeCd.equalsIgnoreCase("HighRiskRx")) {
				String highRiskIndCd = request.getHighRiskRxIndCd();
				if (highRiskIndCd != null && highRiskIndCd.equalsIgnoreCase(Constants.HIG_RISK_IND_CD_PH_AND_EARLY)) {
					vals = getHighRiskRxDetailsForEarlyAndPharmacy(request);
				}
				else if (highRiskIndCd != null && highRiskIndCd.equalsIgnoreCase(Constants.HIG_RISK_IND_CD_EARLY)) {
					vals = getHighRiskRxDetailsForEarly(request);
				}
				else {
					vals = getHighRiskRxDetailsForPharmacy(request);
				}
			}
			//Added for PCMS-512 : Starts
			else if (null != typeCd && typeCd.equalsIgnoreCase(Constants.SUPPLEMENT_ADT)) {
				vals = getSupplementalADTToolTipData(request);
			}
			//Added for PCMSP-512 : Ends
			//Added for PCMSP-9484 : Starts
			else if (null != typeCd && typeCd.equalsIgnoreCase(Constants.FRMLY_PRESCRIBER)) {
				vals = getBrandFormularyPrescriberDrugDetails(request);
			}
			//Added for PCMSP-9484 : Ends
			else {
				throw new Exception("Invalid detail type (" + typeCd + ").");
			}

			result.setMessage(err.getProperty("successful"));
			result.setData(vals);
			result.setTotal(vals.size());
			result.setSuccess(true);
		}
		catch (Exception e) {

			logger.error("Unable to retrieve patient detail.", e);

			result.setMessage("Unable to retrieve patient detail.");
			result.setSuccess(false);
		}

		return result;
	}

	//Added for PCMS-512 : Starts
	/**
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	private Collection<Object> getSupplementalADTToolTipData(GetPatientDetailRequest request) throws Exception {
		SupplementalADTToolTipDao dao = new SupplementalADTToolTipDao();
		Collection<?> vals = dao.getSupplementalADTToolTipData(request);
		return (Collection<Object>) vals;
	}

	//Added for PCMS-512 : Ends

	@SuppressWarnings("unchecked")
	private Collection<Object> getAttributionHistory(GetPatientDetailRequest request) throws Exception {

		AttributionFacts dao = new AttributionFacts();
		Collection<?> details = dao.getAttributionHistory(request);

		return (Collection<Object>) details;
	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getCMDMPrograms(GetPatientDetailRequest request) throws Exception {

		CMDMFacts dao = new CMDMFacts();
		Collection details = dao.getCMDMPrograms(request);
		ReferralFacts factsDao = new ReferralFacts();
		List<String> tempGrpList = new ArrayList<String>();
		List<String> grps = null;
		String uiCmpId = request.getCmpId(); // Save the original UI cmpId so request.cmpId can be reset to it
		//PCMSRequest request = new HashMap<String, String>();
		request.setCmpId(Constants.AC_RF_CARDCONTAINER);
		//request.setProvGrpIds(request.getProvGrpIds());
		//request.put("sessionId", request.getSessionId());
		//request.put("entitlementId", request.getEntitlementId());
		//		if (StringUtils.isNotBlank(request.getCmpId())) {
		grps = filterProvGrpsByKillSwitch(request);
		request.setProvGrpIds(StringUtils.join(grps, ','));
		//		}

		//		if (StringUtils.isNotBlank(request.getCmpId())) {
		request.setCmpId(Constants.AC_RF_RECEIVEDREFERRALS);
		tempGrpList = filterProvGrpsByKillSwitch(request);
		request.setProvGrpIdRcvdRfrls(StringUtils.join(tempGrpList, ','));
		//		}

		// CR 620
		CommonQueries cq = new CommonQueries();

		if (!grps.isEmpty()) {
			Collection<CMDMPrograms> referralList = factsDao.getData(request);
			for (CMDMPrograms referral : referralList) {
				if (!cq.getGroupsWithComponentSuppressed(request, Constants.AC_RF_CARDCONTAINER).contains(referral.getProvGrpId()) // check for suppression on this patient's prov_grp_id
					&& referral.getProgramType().equals("Referrals - Clinical Programs") && null != referral.getRows() && !referral.getRows().isEmpty()) {
					details.addAll(referralList);
				}
			}
		}

		request.setCmpId(uiCmpId);

		return details;
	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getCostByService(GetPatientDetailRequest request) throws Exception {

		CostByServiceFacts dao = new CostByServiceFacts();
		Collection<?> details = dao.getCostByService(request);

		return (Collection<Object>) details;
	}

	//end of changes

	@SuppressWarnings("unchecked")
	private Collection<Object> getCareOpportunities(GetPatientDetailRequest request) throws Exception {

		CareOpportunityFacts dao = new CareOpportunityFacts();
		Collection<?> details = dao.getCareOpportunities(request);

		return (Collection<Object>) details;
	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getEligibleMeasures(GetPatientDetailRequest request) throws Exception {

		EligibleMeasureFacts dao = new EligibleMeasureFacts();
		Collection<?> details = dao.getEligibleMeasures(request);

		return (Collection<Object>) details;
	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getDiseaseConditions(GetPatientDetailRequest request) throws Exception {

		DiseaseConditionFacts dao = new DiseaseConditionFacts();
		Collection<?> details = dao.getDiseaseConditions(request);
		isAttested = dao.isAttested();
		hasSensitive = dao.isSensitive();
		return (Collection<Object>) details;
	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getEmergencyVisits(GetPatientDetailRequest request) throws Exception {

		VisitFacts dao = new VisitFacts();
		Collection<?> details = dao.getEmergencyVisits(request);
		isAttested = dao.isAttested();
		hasSensitive = dao.isSensitive();
		return (Collection<Object>) details;
	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getInpatientAdmits(
		GetPatientDetailRequest request) throws PC2Exception {
		//logger.trace("Entry: getInpatientAdmits() of GetPatientDetailAction");
		VisitFacts dao = new VisitFacts();
		Collection<?> details = dao.getInpatientAdmits(request);
		//logger.trace("Exit: getInpatientAdmits() of GetPatientDetailAction");
		isAttested = dao.isAttested();
		hasSensitive = dao.isSensitive();
		return (Collection<Object>) details;
	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getChronicRiskDrivers(GetPatientDetailRequest request) throws Exception {
		ChronicRiskDriverFacts dao = new ChronicRiskDriverFacts();
		/** 57008 CHRONIC_CARE_GAP changes| ad87338 | START */
		Collection<?> details = dao.getChronicRiskDrivers(request);
		/** 57008 CHRONIC_CARE_GAP changes| ad87338 | END */
		return (Collection<Object>) details;
	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getChronicRiskDrivers(GetPatientDetailRequest request, Boolean... isChronicGapScore)
		throws Exception {
		ChronicRiskDriverFacts dao = new ChronicRiskDriverFacts();
		/** 57008 CHRONIC_CARE_GAP changes| ad87338 | START */
		Collection<?> details = dao.getChronicRiskDrivers(request, isChronicGapScore);
		/** 57008 CHRONIC_CARE_GAP changes| ad87338 | END */
		return (Collection<Object>) details;
	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getInpatientAdmissions(GetPatientDetailRequest request) throws Exception {

		AuthorizationFacts dao = new AuthorizationFacts();
		Collection<?> details = dao.getInpatientAdmissions(request);
		isAttested = dao.isAttested();
		hasSensitive = dao.isSensitive();
		return (Collection<Object>) details;
	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getReadmissionRiskDrivers(GetPatientDetailRequest request) throws Exception {

		ReadmissionRiskDriverFacts dao = new ReadmissionRiskDriverFacts();
		Collection<?> details = dao.getReadmissionRiskDrivers(request);

		return (Collection<Object>) details;
	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getVisits(GetPatientDetailRequest request) throws Exception {

		VisitSummaryFacts dao = new VisitSummaryFacts();
		Collection<?> details = dao.getVisits(request);

		return (Collection<Object>) details;
	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getAmbulatorySensitiveAdmits(GetPatientDetailRequest request) throws Exception {

		AmbulatorySensitiveAdmitsFact dao = new AmbulatorySensitiveAdmitsFact();
		Collection<?> details = dao.getAmbulatorySensitiveAdmits(request);

		return (Collection<Object>) details;
	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getAvoidableErVisits(GetPatientDetailRequest request) throws Exception {

		AvoidableErVisitsFact dao = new AvoidableErVisitsFact();
		Collection<?> details = dao.getAvoidableErVisits(request);

		return (Collection<Object>) details;
	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getGDRDrugDetails(GetPatientDetailRequest request) throws Exception {
		GDRDrugDetailsFacts dao = new GDRDrugDetailsFacts();
		Collection<?> details = dao.getGDRDrugDetails(request);

		return (Collection<Object>) details;
	}

	/* PCMSP 9481 STARTS 2 */
	@SuppressWarnings("unchecked")
	private Collection<Object> getBrandFormularyPatientDrugDetails(GetPatientDetailRequest request) throws Exception {
		BrandFormularyDrugDetailsFacts dao = new BrandFormularyDrugDetailsFacts();
		Collection<?> details = dao.getBrandFormularyDrugDetails(request);


		return (Collection<Object>) details;
	}

	/* PCMSP 9481 ENDS 2 */
	@SuppressWarnings("unchecked")
	private Collection<Object> getBrandFormularyProviderDrugDetails(GetPatientDetailRequest request) throws Exception {
		BrandFormularyDetailsFact dao = new BrandFormularyDetailsFact();
		Collection<?> details = dao.getBrandFormularyDetailsFact(request);

		return (Collection<Object>) details;
	}

	//Added for PCMSP-9484 : Starts
	@SuppressWarnings("unchecked")
	private Collection<Object> getBrandFormularyPrescriberDrugDetails(GetPatientDetailRequest request) throws Exception {
		BrandFormularyDetailsFact dao = new BrandFormularyDetailsFact();
		Collection<?> details = dao.getBrandFormularyPrescriberDetailsFact(request);

		return (Collection<Object>) details;
	}

	//Added for PCMSP-9484 : Ends

	@SuppressWarnings("unchecked")
	private Collection<Object> getRARTotalIndexAdmitsDetails(GetPatientDetailRequest request) throws Exception {
		ReadmissionTotalIndexAdmitsFact dao = new ReadmissionTotalIndexAdmitsFact();
		Collection<?> details = dao.getRARTotalIndexAdmits(request);

		return (Collection<Object>) details;
	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getRARReadmissionDetails(GetPatientDetailRequest request) throws Exception {
		ReadmissionReAdmitsFact dao = new ReadmissionReAdmitsFact();
		Collection<?> details = dao.getRARReadmissions(request);

		return (Collection<Object>) details;
	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getHighRiskRxDetailsForPharmacy(GetPatientDetailRequest request) throws Exception {

		HighRiskDriversFacts dao = new HighRiskDriversFacts();
		Collection<?> details = dao.getHighRiskDriversForPharmacy(request);

		return (Collection<Object>) details;
	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getHighRiskRxDetailsForEarlyAndPharmacy(GetPatientDetailRequest request) throws Exception {

		HighRiskDriversFacts dao = new HighRiskDriversFacts();
		Collection<?> details = dao.getHighRiskDriversForEarlyAndPharmacy(request);

		return (Collection<Object>) details;
	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getHighRiskRxDetailsForEarly(GetPatientDetailRequest request) throws Exception {

		HighRiskDriversFacts dao = new HighRiskDriversFacts();
		Collection<?> details = dao.getHighRiskDriversForEarly(request);

		return (Collection<Object>) details;
	}

}
