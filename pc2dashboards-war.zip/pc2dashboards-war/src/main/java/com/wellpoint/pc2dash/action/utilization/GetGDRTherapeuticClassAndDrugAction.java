package com.wellpoint.pc2dash.action.utilization;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.quality.GetQualityAction;
import com.wellpoint.pc2dash.data.dao.UtilizationDrugClassFilter;
import com.wellpoint.pc2dash.dto.patient.TreeHierarchy;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetGDRTherapeuticClassAndDrugAction extends GetQualityAction {

	GetGDRTherapeuticClassAndDrugResponse response = new GetGDRTherapeuticClassAndDrugResponse();

	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		GetGDRTherapeuticClassAndDrugRequest request = (GetGDRTherapeuticClassAndDrugRequest) actionRequest;
		List<String> filteredProvGrpList = new ArrayList<String>();
		List<TreeHierarchy> resultList = new ArrayList<TreeHierarchy>();

		try {
			request = (GetGDRTherapeuticClassAndDrugRequest) cleanRequest(request);

			if (StringUtil.isJson(request)) {

				//				//PCMSRequest request = getDataMap((GetDrillDownRequest) actionRequest);
				//Kill switch check on Provider groups
				if (null != request) {
					filteredProvGrpList = filterProvGrpsByKillSwitch(request);
				}

				//Clinical access check on provider groups
				if (null != request && null != filteredProvGrpList && filteredProvGrpList.size() > 0) {
					filteredProvGrpList = filterProvGrpsByClinicalInd(request, filteredProvGrpList);
				}


				if (null != filteredProvGrpList && !filteredProvGrpList.isEmpty()) {
					request.setProvGrpIds(StringUtils.join(filteredProvGrpList, ','));
					request.setGrpInd(Constants.GRP_IND_N);
					UtilizationDrugClassFilter dao = new UtilizationDrugClassFilter();
					resultList.addAll(dao.getUtilizationGDRDrugClass(request));
				}
				if (null == resultList || (null != resultList && resultList.isEmpty())) {
					response.setMessage(StringUtil.buildMessage(resultList.isEmpty()));
				}
				else {
					response.getChildren().addAll(resultList);
					response.setTotal(resultList.size()); // calculates total without another query
					response.setMessage(StringUtil.buildMessage(resultList.isEmpty()));
				}

				response.setSuccess(true);
			}

		}
		catch (Exception e) {
			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(e, response);
		}

		return response;
	}

}
