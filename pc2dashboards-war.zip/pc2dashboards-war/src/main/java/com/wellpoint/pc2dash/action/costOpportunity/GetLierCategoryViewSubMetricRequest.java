package com.wellpoint.pc2dash.action.costOpportunity;

import com.wellpoint.pc2dash.data.dto.PopulationManagementRequest;

public class GetLierCategoryViewSubMetricRequest extends PopulationManagementRequest {

	private boolean hasLIERDrilldownInd;
	
	public boolean isHasLIERDrilldownInd() {
		return hasLIERDrilldownInd;
	}

	public void setHasLIERDrilldownInd(boolean hasLIERDrilldownInd) {
		this.hasLIERDrilldownInd = hasLIERDrilldownInd;
	}
}
