package com.wellpoint.pc2dash.action.tooltip;

import java.util.Collection;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.data.dao.MlrFact;
import com.wellpoint.pc2dash.dto.performance.medicalLossRatio.MlrRanges;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.ErrorProperties;

public class GetMLRRangesAction extends Action {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetMLRRangesAction.class);

	public ActionResponse process(ActionRequest actionRequest) {
		ActionResponse result = new GetMLRRangesResponse();
		GetMLRRangesRequest request = (GetMLRRangesRequest) actionRequest;
		ErrorProperties err = ErrorProperties.getInstance();
		try {
			MlrFact dao = new MlrFact();
			Collection<MlrRanges> vals = dao.getMLRRanges(request);
			result.setMessage(err.getProperty("successful"));
			result.setData(vals);
			result.setTotal(vals.size());
			result.setSuccess(true);
		}
		catch (Exception e) {
			logger.error("Unable to retrieve MLR Ranges", e);
			result.setMessage("Unable to retrieve MLR Ranges");
			result.setSuccess(false);
		}
		return result;
	}
}
