package com.wellpoint.pc2dash.data.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.costOpportunity.GetAmbulatorySurgeryFacilityRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.costOpportunity.AmbulatorySurgeryFacilityBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class AmbulatorySurgeryFacilityDao extends ServiceImpl {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(AmbulatorySurgeryFacilityDao.class);

	public List<AmbulatorySurgeryFacilityBean> getData(GetAmbulatorySurgeryFacilityRequest request, boolean exportFlag, int index, int limit) throws Exception {

		List<AmbulatorySurgeryFacilityBean> result = new ArrayList<AmbulatorySurgeryFacilityBean>();
		setRowCount(0);

		StringBuilder query = new StringBuilder()
			.append(" select c.* from (")
			.append(" select b.*, ")
			.append(" row_number() over (  ")
			.append(" 	order by   ")
			.append(buildSortClause(request))
			.append(" ) as row_nbr ")
			.append("	from  ( ")
			.append("       SELECT  ASMRY.FCLTY_TAX_ID as FCLTY_TAX_ID, upper(ASMRY.FCLTY_NM) as FCLTY_NM, ")
			.append("			ASMRY.FCLTY_TYPE_CD, ")
			.append("	CASE WHEN ASMRY.FCLTY_TYPE_CD = 'ASC' then '-1.00' WHEN SUM(ASMRY.COST_OPRTNTY_AMT) >= 0 THEN SUM(ASMRY.COST_OPRTNTY_AMT) ELSE 0.00 END AS TOTALOPPORTUNITY, ") //PCMSP-13417 //PCMSP-14003
			
			/*.append("   case  when  sum(HCOST_SITE_CASE_CNT) ")
            .append("     *(case when sum(CMAD_HCOST_SITE_NBR) <= 0 then 0 else cast(sum(HCOST_SITE_TOTL_AMT) as decimal(18, 5))/sum(CMAD_HCOST_SITE_NBR) end ")
            .append("      -case when sum(CMAD_LOW_COST_SITE_NBR) <= 0  then 0 else cast(sum(LOW_COST_SITE_TOTL_AMT) as decimal(18, 5))/sum(CMAD_LOW_COST_SITE_NBR) end) ")
            .append("     *sum(CASE_MIX_ADJSTMNT_FCTR)/sum(CASE_MIX_ADJSTMNT_SRGRY_CNT) >= 0  ")
            .append("  then  sum(HCOST_SITE_CASE_CNT) ")
            .append("      *(case when sum(CMAD_HCOST_SITE_NBR) <= 0 then 0 else cast(sum(HCOST_SITE_TOTL_AMT) as decimal(18, 5))/sum(CMAD_HCOST_SITE_NBR) end ")
            .append("     -case when sum(CMAD_LOW_COST_SITE_NBR) <= 0 then 0 else cast(sum(LOW_COST_SITE_TOTL_AMT) as decimal(18, 5))/sum(CMAD_LOW_COST_SITE_NBR) end) ")
            .append("     *sum(CASE_MIX_ADJSTMNT_FCTR)/sum(CASE_MIX_ADJSTMNT_SRGRY_CNT)  ")
            .append(" else  0.00 END AS TOTALOPPORTUNITY,  ")*/
			
			//.append(" CASE WHEN sum(HCOST_SITE_CASE_CNT)*(sum(HCOST_SITE_TOTL_AMT)-sum(LOW_COST_SITE_TOTL_AMT))*sum(CASE_MIX_ADJSTMNT_FCTR)/sum(CASE_MIX_ADJSTMNT_SRGRY_CNT) >= 0 THEN sum(HCOST_SITE_CASE_CNT)*(sum(HCOST_SITE_TOTL_AMT)-sum(LOW_COST_SITE_TOTL_AMT))*sum(CASE_MIX_ADJSTMNT_FCTR)/sum(CASE_MIX_ADJSTMNT_SRGRY_CNT) ELSE 0.00 END AS TOTALOPPORTUNITY, ")
			//.append("	CASE WHEN SUM(ASMRY.MBR_CNT) >= 0 THEN SUM(ASMRY.MBR_CNT)  ELSE 0 END AS MBR_CNT, ") //PCMSP-13950
			.append("	CASE WHEN ASC_DTL.mem_cnt >= 0 THEN ASC_DTL.mem_cnt  ELSE 0 END AS MBR_CNT, ")
			.append("	CASE WHEN SUM(ASMRY.SRGRY_CNT) >=0 then SUM(ASMRY.SRGRY_CNT) else 0 end AS TOTALSURGERYCOUNT, ")
			.append("   CASE WHEN count(distinct SRGN_TAX_ID) >=0 then count(distinct SRGN_TAX_ID) else 0 end as surgeonGroupCount , ")
			.append("	max(HCOST_IND) as highCostFacilityInd, COUNT(*) OVER () AS ROW_CNT ")
			.append("   FROM  COC_ASC_CTGRY_SMRY AS ASMRY ")
			//PCMSP-13950 Changes as suggested by data team Pankaj
			.append(" JOIN ( ")  
			.append("	select count(distinct mstr_cnsmr_dim_key) as mem_cnt,ADTL.FCLTY_TAX_ID, upper(ADTL.FCLTY_NM) as FCLTY_NM,FCLTY_TYPE_CD ")
			.append("	 from COC_ASC_DTL_SMRY ADTL ")
			.append("         join  poit_user_scrty_acs pusa on (ADTL.prov_grp_id = pusa.prov_grp_id and ")
			.append("           case ")
			.append("                      when    pusa.prov_org_tax_id = '0' ")
			.append("                      then    ADTL.prov_org_tax_id ")
			.append("                      else    pusa.prov_org_tax_id end = ADTL.prov_org_tax_id) ")
			.append("       where  pusa.sesn_id = ? ")
			.append("       and  pusa.enttlmnt_hash_key = ? ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and ADTL.prov_grp_id in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(
				StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and ADTL.pgm_dim_key in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(
				StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and ADTL.lob_desc in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(
				StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and ADTL.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and ADTL.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys()) + ") ");
		}

		// Changes for PCMSP- 7421 - Procedure Filter
		if (StringUtil.isNotBlankOrFalse(request.getProcedureCode())) {
			query.append(" and ADTL.SUB_MTRC_CD in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProcedureCode())
				+ ") ");
		}

		query.append(" group by ADTL.FCLTY_TAX_ID, upper(ADTL.FCLTY_NM), ADTL.FCLTY_TYPE_CD ")
			.append(" )    ASC_DTL  on  ASC_DTL.FCLTY_TAX_ID = ASMRY.FCLTY_TAX_ID ")
			.append(" and ASC_DTL.FCLTY_NM = ASMRY.FCLTY_NM and ASMRY.FCLTY_TYPE_CD = ASC_DTL.FCLTY_TYPE_CD ")
			.append("         join  poit_user_scrty_acs pusa on (ASMRY.prov_grp_id = pusa.prov_grp_id and ")
			.append("           case ")
			.append("                      when    pusa.prov_org_tax_id = '0' ")
			.append("                      then    ASMRY.prov_org_tax_id ")
			.append("                      else    pusa.prov_org_tax_id end = ASMRY.prov_org_tax_id) ")
			.append("       where  pusa.sesn_id = ? ")
			.append("       and  pusa.enttlmnt_hash_key = ? ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and ASMRY.prov_grp_id in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(
				StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and ASMRY.pgm_dim_key in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(
				StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and ASMRY.lob_desc in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(
				StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and ASMRY.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and ASMRY.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys()) + ") ");
		}

		// Changes for PCMSP- 7421 - Procedure Filter
		if (StringUtil.isNotBlankOrFalse(request.getProcedureCode())) {
			query.append(" and ASMRY.SUB_MTRC_CD in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProcedureCode())
				+ ") ");
		}

		query.append("       group by ")
		.append("         ASMRY.FCLTY_TAX_ID, upper(ASMRY.FCLTY_NM), ASMRY.FCLTY_TYPE_CD,ASC_DTL.mem_cnt ")
		.append("   ) as b ")
		.append(" ) as c ");
		/*if(!exportFlag){
			query.append(" where  c.row_nbr between ? and ? ");
		}
		query.append(" order by   c.row_nbr  with ur ");*/
		query.append(" where  c.row_nbr between ? and ? ");
		query.append(" order by   c.row_nbr  with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());

			buildPreparedStatement(request, i, exportFlag, index, limit);

			executeQuery(logger, query.toString());

			result = convertSelectedRowsToObjects(rs, request, false, exportFlag);

		}
		catch (Exception e) {

			throw new Exception("Unable to get AmbulatorySurgeryFacilityDao (" + request.getEntitlementId() + ", "
				+ request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;

	}

	private void buildPreparedStatement(GetAmbulatorySurgeryFacilityRequest request, int i, boolean exportFlag, int index, int limit)
			throws SQLException {

		int start = 0;
		int stop = 0;

		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProcedureCode())) { // PCMSP-7421
			String[] array = request.getProcedureCode().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}
		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProcedureCode())) { // PCMSP-7421
			String[] array = request.getProcedureCode().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (!exportFlag) {
			start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
			stop = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
		}
		else {
			start = index;
			stop = limit;
		}
		ps.setInt(++i, start + 1);
		ps.setInt(++i, start + stop);

	}

	private List<AmbulatorySurgeryFacilityBean> convertSelectedRowsToObjects(ResultSet rs, GetAmbulatorySurgeryFacilityRequest request,
		boolean displayDashes, boolean exportFlag) throws SQLException {

		List<AmbulatorySurgeryFacilityBean> list = new ArrayList<AmbulatorySurgeryFacilityBean>();

		while (rs.next()) {

			AmbulatorySurgeryFacilityBean item = new AmbulatorySurgeryFacilityBean();

			if (displayDashes) {
				item.setFacilityTaxId(Constants.DASHES);
				item.setFacilityName(Constants.DASHES);
				item.setFacilityType(Constants.DASHES);
				item.setTotalMemberCount(Constants.DASHES);
				item.setTotalSurgeryCount(Constants.DASHES);
				item.setCostOpportunity(Constants.DASHES);
			}
			else {
				if (exportFlag) {

					if (null != rs.getString("FCLTY_TAX_ID")) {
						item.setFacilityTaxId(rs.getString("FCLTY_TAX_ID"));
					}

					if (null != rs.getString("FCLTY_NM")) {
						item.setFacilityName(rs.getString("FCLTY_NM"));
					}
					if (null != rs.getString("FCLTY_TYPE_CD")) {
						item.setFacilityType(rs.getString("FCLTY_TYPE_CD"));
					}
					if (null != rs.getString("TOTALSURGERYCOUNT")) {
						item.setTotalSurgeryCount(StringUtil.convertIntWithCommaToString(rs.getInt("TOTALSURGERYCOUNT")));
					}
					if (null != rs.getString("TOTALOPPORTUNITY") && !rs.getString("FCLTY_TYPE_CD").equalsIgnoreCase("ASC") ) {
						item.setCostOpportunity(StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("TOTALOPPORTUNITY").setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
					} else {
						item.setCostOpportunity(Constants.DASHES);
					}
					if (null != rs.getString("surgeonGroupCount")) {
						item.setSurgeonGroupCount(rs.getString("surgeonGroupCount"));
					}
					if (null != rs.getString("MBR_CNT")) {
						item.setTotalMemberCount(StringUtil.convertIntWithCommaToString(rs.getInt("MBR_CNT")));
					}
					if (null != rs.getString("highCostFacilityInd")) {
						item.setHighCostFacilityInd(rs.getString("highCostFacilityInd").equals(Constants.Y) ? Constants.BOOL_TRUE : Constants.BOOL_FALSE);
					}
				}
				else {
					if (null != rs.getString("FCLTY_TAX_ID")) {
						item.setFacilityTaxId(rs.getString("FCLTY_TAX_ID"));
					}

					if (null != rs.getString("FCLTY_NM")) {
						item.setFacilityName(rs.getString("FCLTY_NM"));
					}
					if (null != rs.getString("FCLTY_TYPE_CD")) {
						item.setFacilityType(rs.getString("FCLTY_TYPE_CD"));
					}
					if (null != rs.getString("TOTALSURGERYCOUNT")) {
						item.setTotalSurgeryCount(rs.getString("TOTALSURGERYCOUNT"));
					}
					if (null != rs.getString("MBR_CNT")) {
						item.setTotalMemberCount(rs.getString("MBR_CNT"));
					}
					if (null != rs.getString("TOTALOPPORTUNITY") && !rs.getString("FCLTY_TYPE_CD").equalsIgnoreCase("ASC") ) {
						item.setCostOpportunity(rs.getString("TOTALOPPORTUNITY"));
					} else {
						item.setCostOpportunity(Constants.DASHES);
					}
					if (null != rs.getString("surgeonGroupCount")) {
						item.setSurgeonGroupCount(rs.getString("surgeonGroupCount"));
					}
					
					if (null != rs.getString("highCostFacilityInd")) {
						item.setHighCostFacilityInd(rs.getString("highCostFacilityInd").equals(Constants.Y) ? Constants.BOOL_TRUE : Constants.BOOL_FALSE);
					}
					item.setHasDetailsDrilldownInd(request.isHasDetailsDrilldownInd());
				}
			}

			list.add(item);

			if (getRowCount() == 0) {
				setRowCount(rs.getInt("row_cnt"));
			}

			if (exportFlag) {
				setTotalExport(rs.getInt("row_cnt"));  } 
			}

		return list;

	}

	private String buildSortClause(GetAmbulatorySurgeryFacilityRequest request) {
		StringBuilder query = new StringBuilder();
		String defaultColumn = " totalOpportunity ";
		String defaultSort = defaultColumn + " desc ";

		if (null != request.getSort()) {
			for (QuerySort sort : request.getSort()) {

				String dir = sort.getDirection().replaceAll("\"", "");
				String property = sort.getProperty();

				if (property.equals("facilityName")) {
					query.append(" upper(FCLTY_NM) " + dir + ", " + defaultSort);
				}
				else if (property.equals("facilityType")) {
					query.append(" FCLTY_TYPE_CD " + dir + ", " + defaultSort);
				}
				else if (property.equals("totalSurgeryCount")) {
					query.append(" TOTALSURGERYCOUNT " + dir + ", " + defaultSort);
				}
				else if (property.equals("costOpportunity")) {
					query.append(" case when TOTALOPPORTUNITY < 0 then 1 else 0 end, TOTALOPPORTUNITY " + dir);
				}
				else if (property.equals("totalMemberCount")) {
					query.append(" MBR_CNT " + dir + ", " + defaultSort);
				}
				else if (property.equals("surgeonGroupCount")){
					query.append(" surgeonGroupCount " + dir + ", " + defaultSort);
				}
				else {
					query.append(defaultColumn + dir);
				}
			}
		}
		else {

		}
		return query.toString();
	}
}
