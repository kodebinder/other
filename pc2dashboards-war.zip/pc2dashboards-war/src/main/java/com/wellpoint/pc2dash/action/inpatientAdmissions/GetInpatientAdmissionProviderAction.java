package com.wellpoint.pc2dash.action.inpatientAdmissions;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.dto.inpatientAdmissions.ProvGrpHrchyDimOthers;
import com.wellpoint.pc2dash.dto.inpatientAdmissions.Provider;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportGridColumn;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.population.InpatientAdmissionProviderExport;
import com.wellpoint.pc2dash.export.population.TapChartExport;
import com.wellpoint.pc2dash.service.inpatientAdmissions.InpatientAdmissionProviderServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;


public class GetInpatientAdmissionProviderAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetInpatientAdmissionProviderRequest request = (GetInpatientAdmissionProviderRequest) actionRequest;
		GetInpatientAdmissionProviderResponse response = new GetInpatientAdmissionProviderResponse();
		ErrorProperties err = ErrorProperties.getInstance();

		InpatientAdmissionProviderServiceImpl service = new InpatientAdmissionProviderServiceImpl();
		List<String> grps = null;

		try {

			removeLobPgmPrefixes(request);

			// Kill switch check on Provider groups
			if (StringUtils.isNotBlank(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			// Clinical access check on provider groups
			if (null != grps && !grps.isEmpty()) {

				request.setProvGrpIdsWithoutClinicalCheck(StringUtils.join(grps, ','));
				grps = filterProvGrpsByClinicalInd(request, grps);
				request.setProvGrpIds(StringUtils.join(grps, ','));
			}

			if (null != grps && !grps.isEmpty()) {

				if (StringUtil.isExportDest(request.getDest())) {
					
					if (StringUtil.isChartExport(request.getChartImageData())) {
						TapChartExport exp = new TapChartExport(request, Constants.IA_PROV_TAP_REPORT);
						ExportProcessor.getInstance().submit(exp);
					}
					else {

						List<ExportGridColumn> columns = service.buildExportGridColumns(request);
						InpatientAdmissionProviderExport exp = new InpatientAdmissionProviderExport(request, columns);

						ExportProcessor.getInstance().submit(exp);
					}
				}
				else {
					
					List<ProvGrpHrchyDimOthers> resultList = service.getData(request, null, false);
					List<Provider> providerList = service.getBeanList(resultList);
					MetaData metaData = buildMetaData(request, service);

					if (null != resultList && !resultList.isEmpty()) {

						response.setData(providerList);
						response.setMetaData(metaData);
						response.setMessage(err.getProperty("successful"));
						response.setTotal(service.getRowCount());
					}
					else {

						response.setMessage(err.getProperty("successNoData"));
					}
				}
			}

			response.setSuccess(true);
			return response;

		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}
}
