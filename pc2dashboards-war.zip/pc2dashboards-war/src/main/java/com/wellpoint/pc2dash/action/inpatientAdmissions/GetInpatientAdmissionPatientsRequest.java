package com.wellpoint.pc2dash.action.inpatientAdmissions;

import com.wellpoint.pc2dash.data.dto.PopulationManagementRequest;

/**
 * @author AD90349
 *
 */
public class GetInpatientAdmissionPatientsRequest extends PopulationManagementRequest {

	//AF00030 R2.0 Defect PCMSP-766
	protected String minimumInpatientAdmits;

	public String getMinimumInpatientAdmits() {
		return minimumInpatientAdmits;
	}
	
	public void setMinimumInpatientAdmits(String minimumInpatientAdmits) {
		this.minimumInpatientAdmits = minimumInpatientAdmits;
	}

}
