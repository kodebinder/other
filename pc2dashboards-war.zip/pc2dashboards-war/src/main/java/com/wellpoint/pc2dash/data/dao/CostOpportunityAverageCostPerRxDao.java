package com.wellpoint.pc2dash.data.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.costOpportunity.GetCostOpportunityAverageCostPerRxRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.costOpportunity.CostOpportunityAverageRxBean;
import com.wellpoint.pc2dash.dto.costOpportunity.MinimumCriteriaBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;


public class CostOpportunityAverageCostPerRxDao extends ServiceImpl {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(CostOpportunityAverageCostPerRxDao.class);

	private boolean displayDashes = false;
	private boolean displayDashesRx = false; //PCMSP-15224

	public List<CostOpportunityAverageRxBean> getAverageCostPerRxDetails(GetCostOpportunityAverageCostPerRxRequest request, boolean exportFlag, int index, int limit)
		throws Exception {

		List<CostOpportunityAverageRxBean> result = new ArrayList<CostOpportunityAverageRxBean>();
		setRowCount(0);
		//PCMSP-15224 Starts
		MinimumCriteriaBean minCritRx = new MinimumCriteriaBean("TOTL_SCRPT_NBR", "COC_RX_CTGRY_SMRY", Constants.COC_RX_PARAM, null);
		String dir = request.getSort().get(0).getDirection();
		String masked = "asc".equalsIgnoreCase(dir) ? String.valueOf(Integer.MAX_VALUE) : String.valueOf(Integer.MIN_VALUE); // we want masked values to always be at the bottom, so use either the biggest or smallest value, depending
		String dashesClause =
			" sum(s.TOTL_SCRPT_NBR) < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_RX_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG') ";
		String multiplePgmCheck_10_Perc = " or  ((SUM(count(distinct s.BNCHMRK_10_PCTILE_AMT)) over (partition by s.SUB_MTRC_CD, s.SUB_MTRC_NM)) > 1) ";
		String multiplePgmCheck_90_Perc = " or  ((SUM(count(distinct s.BNCHMRK_90_PCTILE_AMT)) over (partition by s.SUB_MTRC_CD, s.SUB_MTRC_NM)) > 1) ";
		CommonQueries cq = new CommonQueries();
		displayDashesRx = cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request, minCritRx);
		StringBuilder dashesClauseRx = new StringBuilder()
			.append(" case  when true = " + displayDashesRx + " then ")
			.append(masked);
		//PCMSP-15224 Ends

		StringBuilder sql = new StringBuilder()
			.append(" select b.* ")
			.append(" from ( ")
			.append(" select a.*, ")
			.append("	row_number() over (")
			.append("		order by ")
			.append(buildSortClause(request))
			.append(" ) as row_nbr ")
			.append(" from ( ")
			.append(" select ")
			.append(" s.SUB_MTRC_CD,")
			.append(" s.SUB_MTRC_NM,")
			.append(dashesClauseRx).append(" when ").append(dashesClause).append(" then ").append(masked)
			.append(" when sum(s.COST_OPRTNTY_AMT) >=0 then sum(s.COST_OPRTNTY_AMT) else 0 end as COST_OPRTNTY_AMT,")
			.append(dashesClauseRx).append(" when ").append(dashesClause).append(" then ").append(masked)
			.append(" when sum(s.COST_OPRTNTY_10_PCTAG_AMT) >=0 then CAST(sum(s.COST_OPRTNTY_10_PCTAG_AMT) as decimal(18,4))  else 0 end as COST_OPRTNTY_10_PCTAG_AMT, ")
			//.append(" case when ").append(dashesClause).append(" then ").append(masked).append(" when sum(s.COST_OPRTNTY_AMT) >=0  and sum(s.MBR_MNTH_CNT) > 0 then CAST(sum(s.COST_OPRTNTY_AMT) as decimal(18,4))/ cast(sum(MBR_MNTH_CNT) as decimal (18,3)) else 0.00 end as PMPM_OPRTNTY_AMT, ")
			//.append(" case when ").append(dashesClause).append(" then ").append(masked).append(" when sum(s.COST_OPRTNTY_10_PCTAG_AMT) >=0  and sum(s.MBR_MNTH_CNT) > 0 then ((CAST(sum(s.COST_OPRTNTY_10_PCTAG_AMT) as decimal(18,4))/ cast(sum(MBR_MNTH_CNT) as decimal (18,3)))) else 0.00 end as PMPM_OPRTNTY_10_PCTAG_AMT, ")
			.append(dashesClauseRx).append(" when ").append(dashesClause).append(" then ").append(masked).append(
				" when sum(s.COST_OPRTNTY_AMT) >=0  and ILV.MEM_MNTH > 0 then CAST(sum(s.COST_OPRTNTY_AMT) as decimal(18,4))/ cast( ILV.MEM_MNTH as decimal (18,4)) else 0.00 end as PMPM_OPRTNTY_AMT, ")
			.append(dashesClauseRx).append(" when ").append(dashesClause).append(" then ").append(masked).append(
				" when sum(s.COST_OPRTNTY_10_PCTAG_AMT) >=0  and ILV.MEM_MNTH > 0 then ((CAST(sum(s.COST_OPRTNTY_10_PCTAG_AMT) as decimal(18,4))/ cast( ILV.MEM_MNTH as decimal (18,4) ))) else 0.00 end as PMPM_OPRTNTY_10_PCTAG_AMT, ")
			//.append(" case when ").append(dashesClause).append(" then ").append(masked).append(" else sum(s.TOTL_SCRPT_NBR) end as TOTL_SCRPT_NBR,")
			.append(" sum(s.TOTL_SCRPT_NBR)  as TOTL_SCRPT_NBR,") //PCMSP-15224
			.append(dashesClauseRx).append(" when ").append(dashesClause).append(" then ").append(masked).append(" else sum(s.TOTL_ALWD_AMT) end as TOTL_ALWD_AMT,")
			.append(dashesClauseRx).append(" when ").append(dashesClause).append(" then ").append(masked)
			.append(" when sum(s.TOTL_SCRPT_NBR) > 0 ")
			.append(" then   (cast(sum(s.totl_alwd_amt) as decimal(18,4)) / cast(sum(s.TOTL_SCRPT_NBR) as decimal(18,4))) ")
			.append(" else 0.00")
			.append(" end as CURRENT_PERF_RATE,")
			.append(dashesClauseRx).append(" when ").append(dashesClause).append(multiplePgmCheck_90_Perc).append(" then ").append(masked)
			.append(" else MAX(s.BNCHMRK_90_PCTILE_AMT) end as BNCHMRK_90_PCTILE_AMT,")
			.append(dashesClauseRx).append(" when ").append(dashesClause).append(multiplePgmCheck_10_Perc).append(" then ").append(masked)
			.append(" else MAX(s.BNCHMRK_10_PCTILE_AMT) end as BNCHMRK_10_PCTILE_AMT,")
			.append(" count(*) over () as row_cnt,")
			.append(" case when ").append(dashesClause).append(" then 'Y' else 'N' end as dsply_dashes, ")
			.append(dashesClauseRx).append(" when ").append(dashesClause).append(" then ").append(masked)
			.append(" else SUM(count(distinct s.BNCHMRK_90_PCTILE_AMT)) over (partition by s.SUB_MTRC_CD, s.SUB_MTRC_NM) end as BNCH_90_CNT, ")
			.append(dashesClauseRx).append(" when ").append(dashesClause).append(" then ").append(masked)
			.append(" else SUM(count(distinct s.BNCHMRK_10_PCTILE_AMT)) over (partition by s.SUB_MTRC_CD, s.SUB_MTRC_NM) end as BNCH_10_CNT ")
			.append(" from")
			.append(" COC_RX_CTGRY_SMRY s")
			.append(" join (select  ")
			.append(" nvl(SUM(MM.MBR_MNTH_12_CNT),0) as MEM_MNTH ")
			.append(" FROM  PAT_SMRY_FACT PSF ")
			.append(" INNER JOIN MSTR_CNSMR_MBR_MNTH_FACT MM ON ")
			.append(" MM.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY ")
			.append(" AND MM.RCRD_STTS_CD = 'ACT' ")
			.append(" AND PSF.ATRBN_STTS_CD = 'ACTIVE' ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			sql.append(" and psf.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			sql.append(" and psf.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {

			sql.append(" and psf.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");

		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			sql.append(" and psf.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			sql.append(" and psf.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}


		sql.append(" ) as ILV on 1=1 ")
			.append(" join poit_user_scrty_acs pusa on (")
			.append(" s.prov_grp_id = pusa.prov_grp_id ")
			.append(" and case")
			.append(" when pusa.prov_org_tax_id = '0' then s.prov_org_tax_id")
			.append("  else pusa.prov_org_tax_id")
			.append("  end = s.prov_org_tax_id")
			.append("  )")
			.append(" where")
			.append("  pusa.sesn_id = ? ")
			.append(" and pusa.enttlmnt_hash_key = ? ");


		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			sql.append(" and s.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			sql.append(" and s.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {

			sql.append(" and s.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");

		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			sql.append(" and s.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			sql.append(" and s.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getDrugClassKeys())) {
			sql.append(" and s.SUB_MTRC_CD in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getDrugClassKeys())
				+ ") ");
		}


		sql.append(
			" group by  s.SUB_MTRC_CD, s.SUB_MTRC_NM, ILV.MEM_MNTH  ")
			.append(") a ")
			.append(") b ")
			.append(" where b.row_nbr between ? and ? ")
			.append(" order by b.row_nbr ")
			.append(" with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			int start = 0;
			int stop = 0;
			prepareStatement(logger, sql.toString());

			//For PM PM Calculations : Starts


			// Group Ids
			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// Program filters
			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// LOB filters
			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// Organization filter
			if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
				String[] array = request.getProvDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, StringUtil.parseProviderId(item));
				}
			}
			if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
				String[] array = request.getOrgDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			//For PMPM Calculation : Ends

			ps.setString(++i, request.getSessionId());
			ps.setString(++i, request.getEntitlementId());

			// Group Ids
			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// Program filters
			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// LOB filters
			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// Organization filter
			if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
				String[] array = request.getProvDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, StringUtil.parseProviderId(item));
				}
			}
			if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
				String[] array = request.getOrgDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (StringUtil.isNotBlankOrFalse(request.getDrugClassKeys())) {
				String[] array = request.getDrugClassKeys().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (!exportFlag) {
				start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
				stop = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
			}
			else {
				start = index;
				stop = limit;
			}
			ps.setInt(++i, start + 1);
			ps.setInt(++i, start + stop);

			executeQuery(logger, sql.toString());

			while (rs.next()) {
				
				setTotalExport(rs.getInt("row_cnt"));

				CostOpportunityAverageRxBean jsonResult = new CostOpportunityAverageRxBean();

				if (rs.getString("dsply_dashes") != null && rs.getString("dsply_dashes").equalsIgnoreCase(Constants.Y) || displayDashesRx) {
					displayDashes = true;
				}
				else {
					displayDashes = false;
				}
				jsonResult.setCategory(StringUtil.getValueOrDashes(rs.getString("SUB_MTRC_NM")));
				jsonResult.setDrugClassCode(StringUtil.getValueOrDashes(rs.getString("SUB_MTRC_CD")));

				if (!displayDashes) {
					if (rs.getString("COST_OPRTNTY_AMT") != null)
						jsonResult.setTotalOpportunity(
							exportFlag ? StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("COST_OPRTNTY_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString())
								: rs.getBigDecimal("COST_OPRTNTY_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
				}
				else {
					jsonResult.setTotalOpportunity(Constants.DASHES);
				}

				if (!displayDashes) {
					if (rs.getString("COST_OPRTNTY_10_PCTAG_AMT") != null)
						jsonResult
							.setTenPercentImprovement(
								exportFlag
									? StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("COST_OPRTNTY_10_PCTAG_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString())
									: rs.getBigDecimal("COST_OPRTNTY_10_PCTAG_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
				}
				else {
					jsonResult.setTenPercentImprovement(Constants.DASHES);
				}

				if (!displayDashes) {
					if (rs.getString("PMPM_OPRTNTY_AMT") != null)
						jsonResult.setTotalOpportunityPMPM(
							exportFlag ? StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("PMPM_OPRTNTY_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString())
								: rs.getBigDecimal("PMPM_OPRTNTY_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
				}
				else {
					jsonResult.setTotalOpportunityPMPM(Constants.DASHES);
				}

				if (!displayDashes) {
					if (rs.getString("PMPM_OPRTNTY_10_PCTAG_AMT") != null)
						jsonResult.setTenPercentImprovementPMPM(
							exportFlag ? StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("PMPM_OPRTNTY_10_PCTAG_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString())
								: rs.getBigDecimal("PMPM_OPRTNTY_10_PCTAG_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
				}
				else {
					jsonResult.setTenPercentImprovementPMPM(Constants.DASHES);
				}


				if (rs.getString("TOTL_SCRPT_NBR") != null)//PCMSP-15224
					jsonResult.setTotalScripts(
						exportFlag ? StringUtil.convertStringToCommaBigDecimal(rs.getBigDecimal("TOTL_SCRPT_NBR").setScale(0, BigDecimal.ROUND_HALF_UP).toString(), 0)
							: rs.getBigDecimal("TOTL_SCRPT_NBR").setScale(0, BigDecimal.ROUND_HALF_UP).toString());


				if (!displayDashes) {
					if (rs.getString("TOTL_ALWD_AMT") != null)
						jsonResult
							.setTotalAllowedAmount(
								exportFlag ? StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("TOTL_ALWD_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString())
									: rs.getBigDecimal("TOTL_ALWD_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
				}
				else {
					jsonResult.setTotalAllowedAmount(Constants.DASHES);
				}

				if (!displayDashes && rs.getShort("BNCH_90_CNT") == Constants.INT_ONE) {
					if (rs.getString("BNCHMRK_90_PCTILE_AMT") != null)
						jsonResult.setPercentileBenchmark90(
							exportFlag ? StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("BNCHMRK_90_PCTILE_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString())
								: rs.getBigDecimal("BNCHMRK_90_PCTILE_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
				}
				else {
					jsonResult.setPercentileBenchmark90(Constants.DASHES);
				}

				if (!displayDashes && rs.getShort("BNCH_10_CNT") == Constants.INT_ONE) {
					if (rs.getString("BNCHMRK_10_PCTILE_AMT") != null)
						jsonResult.setPercentileBenchmark10(
							exportFlag ? StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("BNCHMRK_10_PCTILE_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString())
								: rs.getBigDecimal("BNCHMRK_10_PCTILE_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
				}
				else {
					jsonResult.setPercentileBenchmark10(Constants.DASHES);
				}

				if (!displayDashes) {
					if (rs.getString("CURRENT_PERF_RATE") != null)
						jsonResult.setCurrentPerformanceRate(
							exportFlag ? StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("CURRENT_PERF_RATE").setScale(2, BigDecimal.ROUND_HALF_UP).toString())
								: rs.getBigDecimal("CURRENT_PERF_RATE").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
				}
				else {
					jsonResult.setCurrentPerformanceRate(Constants.DASHES);
				}

				if (!displayDashes)
					jsonResult.setCostPerRxCategoryInd(Boolean.TRUE);

				result.add(jsonResult);
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get CostOpportunityAverageCostPerRxDao (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}
		return result;

	}



	private String buildSortClause(GetCostOpportunityAverageCostPerRxRequest request) {

		StringBuilder query = new StringBuilder();

		for (QuerySort sort : request.getSort()) {
			String dir = sort.getDirection().replaceAll("\"", "");
			String property = sort.getProperty();

			if (property.equals("category")) {
				query.append(" SUB_MTRC_NM " + dir);
			}
			else if (property.equals("totalOpportunity")) {
				query.append(" COST_OPRTNTY_AMT " + dir);
			}
			else if (property.equals("tenPercentImprovement")) {
				query.append(" COST_OPRTNTY_10_PCTAG_AMT " + dir);
			}
			else if (property.equals("totalOpportunityPMPM")) {
				query.append(" PMPM_OPRTNTY_AMT " + dir);
			}
			else if (property.equals("tenPercentImprovementPMPM")) {
				query.append(" PMPM_OPRTNTY_10_PCTAG_AMT " + dir);
			}
			else if (property.equals("totalScripts")) {
				query.append(" TOTL_SCRPT_NBR " + dir);
			}
			else if (property.equals("totalAllowedAmount")) {
				query.append(" TOTL_ALWD_AMT " + dir);
			}
			else if (property.equals("currentPerformanceRate")) {
				query.append(" CURRENT_PERF_RATE " + dir);
			}
			else if (property.equals("percentileBenchmark90")) {
				query.append(" BNCHMRK_90_PCTILE_AMT " + dir);
			}
			else if (property.equals("percentileBenchmark10")) {
				query.append(" BNCHMRK_10_PCTILE_AMT " + dir);
			}
		}

		return query.toString();
	}

}
