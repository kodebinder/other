package com.wellpoint.pc2dash.action.utilization;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.quality.GetQualityAction;
import com.wellpoint.pc2dash.action.quality.GetQualityResponse;
import com.wellpoint.pc2dash.data.dao.UtilizationConditionFilter;
import com.wellpoint.pc2dash.dto.utilization.UtilizationCondition;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetUtilizationConditionFilterAction extends GetQualityAction {

	ActionResponse response = new GetQualityResponse();

	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		GetUtilizationConditionFilterRequest request = (GetUtilizationConditionFilterRequest) actionRequest;
		List<String> filteredProvGrpList = new ArrayList<String>();
		List<UtilizationCondition> resultList = new ArrayList<UtilizationCondition>();

		try {
			request = (GetUtilizationConditionFilterRequest) cleanRequest(request);

			if (StringUtil.isJson(request)) {

				//PCMSRequest request = getDataMap((GetDrillDownRequest) actionRequest);
				//Kill switch check on Provider groups
				if (null != request) {
					filteredProvGrpList = filterProvGrpsByKillSwitch(request);
				}

				//Clinical access check on provider groups
				if (null != request && null != filteredProvGrpList && filteredProvGrpList.size() > 0) {
					filteredProvGrpList = filterProvGrpsByClinicalInd(request, filteredProvGrpList);
				}


				if (null != filteredProvGrpList && !filteredProvGrpList.isEmpty()) {
					request.setProvGrpIds(StringUtils.join(filteredProvGrpList, ','));
					request.setGrpInd(Constants.GRP_IND_N);
					UtilizationConditionFilter dao = new UtilizationConditionFilter();
					resultList.addAll(dao.getUtilizationConditions(request));
				}
				if (null == resultList || (null != resultList && resultList.isEmpty())) {
					response.setMessage(StringUtil.buildMessage(resultList.isEmpty()));
				}
				else {
					response.setData(resultList);
					response.setTotal(resultList.size()); // calculates total without another query
					response.setMessage(StringUtil.buildMessage(resultList.isEmpty()));
				}

				response.setSuccess(true);
			}

		}
		catch (Exception e) {
			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(e, response);
		}

		return response;
	}

}
