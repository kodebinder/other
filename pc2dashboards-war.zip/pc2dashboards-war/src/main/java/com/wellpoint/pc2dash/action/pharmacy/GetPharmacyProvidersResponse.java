package com.wellpoint.pc2dash.action.pharmacy;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetPharmacyProvidersResponse extends ActionResponse {

}
