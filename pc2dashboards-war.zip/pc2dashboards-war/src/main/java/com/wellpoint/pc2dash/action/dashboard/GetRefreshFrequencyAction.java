package com.wellpoint.pc2dash.action.dashboard;

import java.util.Collection;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.tooltip.GetPatientDetailAction;
import com.wellpoint.pc2dash.data.dao.RefreshFrequencyDao;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;

public class GetRefreshFrequencyAction extends Action {

	//PCMSRequest request = new HashMap<String, String>();
	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetPatientDetailAction.class);
	ErrorProperties err = ErrorProperties.getInstance();

	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		GetRefreshFrequencyRequest request = (GetRefreshFrequencyRequest) actionRequest;
		ActionResponse response = new GetRefreshFrequencyResponse();

		String view = request.getView();
		Collection<Object> vals;
		try {
			if ((Constants.ATTRIBUTED_PATIENTS).equalsIgnoreCase(view)) {
				vals = getRefreshFrequecyDataForAttributedPatients(request);
			}
			else if ((Constants.INACTIVE_PATIENTS).equalsIgnoreCase(view)) {
				vals = getRefreshFrequecyDataForInactivepatients(request);
			}
			else if ((Constants.ERVISITS).equalsIgnoreCase(view)) {
				vals = getRefreshFrequecyDataForErvisits(request);
			}
			else if ((Constants.CARE_OPPORTUNITIES).equalsIgnoreCase(view)) {
				vals = getRefreshFrequecyDataForCareopportunities(request);
			}
			else if ((Constants.INPATIENT_ADMISSNS).equalsIgnoreCase(view)) {
				vals = getRefreshFrequecyDataForInPatientAdmissions(request);
			}
			else if ((Constants.PHARMACY).equalsIgnoreCase(view)) {
				vals = getRefreshFrequecyDataForPharmacy(request);
			}
			else if ("coc-summary".equalsIgnoreCase(view)) {
				vals = getRefreshFrequencyDataForView(request, null); // null denotes Summary page; all others pass their view name
			}
			else if ("averagecostperrx".equalsIgnoreCase(view)) {
				vals = getRefreshFrequencyDataForView(request, "Average Cost Per Rx");
			}
			else if ("lier".equalsIgnoreCase(view)) {
				vals = getRefreshFrequencyDataForView(request, "Low Intensity ER");
			}
			else if ("labsiteofservice".equalsIgnoreCase(view)) {
				vals = getRefreshFrequencyDataForView(request, "Laboratory Site of Service");
			}
			else if ("ambulatorysiteofcare".equalsIgnoreCase(view)) {
				vals = getRefreshFrequencyDataForView(request, "Ambulatory Surgery Site of Care");
			}
			else if ("highvaluespecialist".equalsIgnoreCase(view)) {
				vals = getRefreshFrequencyDataForView(request, "High Value Specialist Referrals");
			}
			else if ("inpatientadmissions".equalsIgnoreCase(view)) {
				vals = getRefreshFrequencyDataForView(request, "Inpatient Admissions");
			}
			else if ("empiricalcarevariations".equalsIgnoreCase(view)) {
				vals = getRefreshFrequencyDataForView(request, ""); // TODO update when known
			}
			else if ("evidencecarevariations".equalsIgnoreCase(view)) {
				vals = getRefreshFrequencyDataForView(request, "Evidence Based Care Variations");
			}
			else if ("inpatientutilization".equalsIgnoreCase(view)) {
				vals = getRefreshFrequencyDataForView(request, "Inpatient Utilization");
			}
			else if ("specialtyrxsoc".equalsIgnoreCase(view)) {
				vals = getRefreshFrequencyDataForView(request, "Specialty Rx Site of Care");
			}
			else {
				throw new Exception("Invalid detail view (" + view + ").");
			}

			response.setMessage(err.getProperty("successful"));
			response.setData(vals);
			response.setTotal(vals.size());
			response.setSuccess(true);
		}
		catch (Exception e) {

			logger.error("Unable to retrieve patient detail.", e);

			response.setMessage("Unable to retrieve patient detail.");
			response.setSuccess(false);
		}
		return response;
	}

	@SuppressWarnings("unchecked")
	public Collection<Object> getRefreshFrequecyDataForAttributedPatients(GetRefreshFrequencyRequest request) {
		RefreshFrequencyDao dao = new RefreshFrequencyDao();
		Collection<?> details = dao.getAttributedPatientDetails(request);
		return (Collection<Object>) details;
	}

	@SuppressWarnings("unchecked")
	public Collection<Object> getRefreshFrequecyDataForInactivepatients(GetRefreshFrequencyRequest request) {
		RefreshFrequencyDao dao = new RefreshFrequencyDao();
		Collection<?> details = dao.getInactivePatientDetails(request);
		return (Collection<Object>) details;
	}

	@SuppressWarnings("unchecked")
	public Collection<Object> getRefreshFrequecyDataForErvisits(GetRefreshFrequencyRequest request) {
		RefreshFrequencyDao dao = new RefreshFrequencyDao();
		Collection<?> details = dao.getErvisitsDetails(request);
		return (Collection<Object>) details;
	}

	@SuppressWarnings("unchecked")
	public Collection<Object> getRefreshFrequecyDataForCareopportunities(GetRefreshFrequencyRequest request) {
		RefreshFrequencyDao dao = new RefreshFrequencyDao();
		Collection<?> details = dao.getCareOpportunityDetails(request);
		return (Collection<Object>) details;
	}

	/**
	 * Get Refresh Frequency Data for InPatient Admissions
	 * 
	 * @param request
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Collection<Object> getRefreshFrequecyDataForInPatientAdmissions(GetRefreshFrequencyRequest request) {
		RefreshFrequencyDao dao = new RefreshFrequencyDao();
		Collection<?> details = dao.getInPatientAdmissionDetails(request);
		return (Collection<Object>) details;
	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getRefreshFrequecyDataForPharmacy(GetRefreshFrequencyRequest request) {
		RefreshFrequencyDao dao = new RefreshFrequencyDao();
		Collection<?> details = dao.getPharmacyDetails(request);
		return (Collection<Object>) details;
	}

	@SuppressWarnings("unchecked")
	private Collection<Object> getRefreshFrequencyDataForView(GetRefreshFrequencyRequest request, String view) {
		RefreshFrequencyDao dao = new RefreshFrequencyDao();
		Collection<?> details = dao.getRefreshFrequencyDetails(request, view);
		return (Collection<Object>) details;
	}

}
