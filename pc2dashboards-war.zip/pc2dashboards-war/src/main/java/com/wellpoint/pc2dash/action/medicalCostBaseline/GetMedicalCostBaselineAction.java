package com.wellpoint.pc2dash.action.medicalCostBaseline;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.medicalCostBaseline.McbSmryDtoMetadata;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.performance.McbExport;
import com.wellpoint.pc2dash.service.medicalCost.MedicalCostBaselineServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;


public class GetMedicalCostBaselineAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetMedicalCostBaselineRequest request = (GetMedicalCostBaselineRequest) actionRequest;
		GetMedicalCostBaselineResponse response = new GetMedicalCostBaselineResponse();
		ErrorProperties err = ErrorProperties.getInstance();

		MedicalCostBaselineServiceImpl service = new MedicalCostBaselineServiceImpl();
		List<String> grps = new ArrayList<String>();
		int totalRecords = 0;

		try {

			// Kill switch check on Provider groups
			if (StringUtil.isNotBlankOrFalse(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			// Clinical access check on provider groups
			if (null != grps && grps.size() > 0) {
				grps = filterProvGrpsByFinancialInd(request, grps);
			}

			request.setProvGrpIds(StringUtils.join(grps, Constants.COMMA));
			
			CommonQueries cq = new CommonQueries();
			request.setSuppression(cq.getActiveSuppressionForSelectComponents(request));

			if (null == request.getDest() || request.getDest().equalsIgnoreCase(Constants.JSON)) {
				McbSmryDtoMetadata metadata = new McbSmryDtoMetadata();
				metadata.setCalculationType(Constants.BLANK);
				List<Map<String, String>> resultList = new ArrayList<Map<String, String>>();
				if (!CollectionUtils.isEmpty(grps)) {
					Map<String, Map<String, String>> resultMap = service.getData(request);	
					
					for(String key:resultMap.keySet())
						resultList.add(resultMap.get(key));
					response.setData(resultList);
					response.setTotal(resultList.size());
					if(service.getDollarType() != null){
						if(service.getDollarType().equalsIgnoreCase(Constants.FIRST_DOLLAR_MCB)){
							metadata.setCalculationType(Constants.FIRST_DOLLAR_RPRT);
						}
						else if(service.getDollarType().equalsIgnoreCase(Constants.SECOND_DOLLAR_MCB)){
							metadata.setCalculationType(Constants.SECOND_DOLLAR_RPRT);
						}
						
					}	

					if (null == resultList || (null != resultList && resultList.isEmpty())) {
						response.setMessage(err.getProperty(Constants.SUCCESS_NO_DATA));
					}
					else {
						response.setMessage(err.getProperty(Constants.SUCCESSFUL));
					}
				}
				else {
					response.setData(resultList);
					response.setTotal(resultList.size());
					response.setMessage(err.getProperty(Constants.SUCCESSFUL));
				}
				response.setMetaData(metadata);
			}

			if (StringUtil.isExportDest(request.getDest())) {

				McbExport exp = new McbExport(request);
				ExportProcessor.getInstance().submit(exp);
			}

			response.setSuccess(true);
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

		return response;
	}
}
