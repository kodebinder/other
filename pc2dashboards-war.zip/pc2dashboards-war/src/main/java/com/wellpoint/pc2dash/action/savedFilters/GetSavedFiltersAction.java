package com.wellpoint.pc2dash.action.savedFilters;

import java.util.List;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.savedFilters.Filter;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.service.savedFilters.SavedFiltersImpl;
import com.wellpoint.pc2dash.util.ErrorProperties;

public class GetSavedFiltersAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		SavedFiltersRequest request = (SavedFiltersRequest) actionRequest;
		ActionResponse response = new SavedFiltersResponse();
		ErrorProperties err = ErrorProperties.getInstance();

		SavedFiltersImpl service = new SavedFiltersImpl();

		try {

			Filter filter = request.getFilters().get(0); // Only need userId and entitlementId
			//			Set<String> id = new HashSet<String>();
			//			id.add(filter.getSavedViewId());
			//			List<Filter> resultList = service.selectFilters(filter.getUserId(), filter.getEntitlementId(), id);
			List<Filter> resultList = service.selectFilters(filter.getUserId(), filter.getEntitlementId());

			if (null == resultList || (null != resultList && resultList.isEmpty())) {

				response.setMessage(err.getProperty("successNoData"));
			}
			else {

				response.setMessage(err.getProperty("successful"));
				//				response.getData().addAll(resultList);
				response.setData(resultList);
				response.setTotal(resultList.size());
			}

			response.setSuccess(true);
			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}

}
