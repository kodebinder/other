package com.wellpoint.pc2dash.action.medicalCostTarget;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dao.MctFact;
import com.wellpoint.pc2dash.dto.performance.MedicalCostReport;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.performance.MctExport;
import com.wellpoint.pc2dash.service.medicalCost.MedicalCostTargetRetroServiceImpl;
import com.wellpoint.pc2dash.service.medicalCost.MedicalCostTargetServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;


public class GetMedicalCostTargetAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetMedicalCostTargetRequest request = (GetMedicalCostTargetRequest) actionRequest;
		GetMedicalCostTargetResponse response = new GetMedicalCostTargetResponse();
		ErrorProperties err = ErrorProperties.getInstance();

		MedicalCostTargetServiceImpl service = new MedicalCostTargetServiceImpl();
		MedicalCostTargetRetroServiceImpl retroService = new MedicalCostTargetRetroServiceImpl();
		List<String> grps = new ArrayList<String>();
		int totalRecords = 0;

		try {

			// Kill switch check on Provider groups
			if (StringUtil.isNotBlankOrFalse(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			// Clinical access check on provider groups
			if (null != grps && grps.size() > 0) {
				grps = filterProvGrpsByFinancialInd(request, grps);
				//request.setProvGrpIds(StringUtils.join(grps, ','));
			}

			request.setProvGrpIds(StringUtils.join(grps, ','));

			if (null == request.getDest() || request.getDest().equalsIgnoreCase("json")) {

				List<MctFact> resultList = new ArrayList<MctFact>();
				ArrayList<MedicalCostReport> medicalCostTargetList = new ArrayList<MedicalCostReport>();
				if (!CollectionUtils.isEmpty(grps)) {
					if (request.getReportType() != null && request.getReportType().contains(Constants.MCTR)) {
						Map<String, Map<String, String>> resultMap = retroService.getData(request);

						List<Map<String, String>> retroResultMap = new ArrayList<Map<String, String>>();
						for (String key : resultMap.keySet())
							retroResultMap.add(resultMap.get(key));
						response.setData(retroResultMap);
						response.setTotal(retroResultMap.size());
					}
					else {
						resultList = service.getData(request);
						medicalCostTargetList = (ArrayList<MedicalCostReport>) service.getBeanList(resultList);
						totalRecords = service.getTotalRecords();

						response.setData(medicalCostTargetList);
						response.setTotal(totalRecords);

						if (null == resultList || (null != resultList && resultList.isEmpty())) {
							response.setMessage(err.getProperty("successNoData"));
						}
						else {
							response.setMessage(err.getProperty("successful"));
						}
					}
				}
				else {
					response.setData(resultList);
					response.setTotal(totalRecords);
					response.setMessage(err.getProperty("successful"));
				}

				/*if (null == resultList || (null != resultList && resultList.isEmpty())) {
					response.setMessage(err.getProperty("successNoData"));
				}
				else {
					response.setMessage(err.getProperty("successful"));
				}*/
			}

			if (StringUtil.isExportDest(request.getDest())) {

				MctExport exp = new MctExport(request);
				ExportProcessor.getInstance().submit(exp);
			}

			response.setSuccess(true);
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

		return response;
	}
}
