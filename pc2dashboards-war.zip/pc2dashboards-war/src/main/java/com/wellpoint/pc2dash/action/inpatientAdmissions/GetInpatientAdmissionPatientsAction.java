package com.wellpoint.pc2dash.action.inpatientAdmissions;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.dto.patient.MstrCnsmrFactAndOthers;
import com.wellpoint.pc2dash.dto.patient.Patient;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportGridColumn;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.population.InpatientAdmissionPatientExport;
import com.wellpoint.pc2dash.export.population.TapChartExport;
import com.wellpoint.pc2dash.service.inpatientAdmissions.InpatientAdmissionPatientsServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;


public class GetInpatientAdmissionPatientsAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetInpatientAdmissionPatientsRequest request = (GetInpatientAdmissionPatientsRequest) actionRequest;
		GetInpatientAdmissionPatientsResponse response = new GetInpatientAdmissionPatientsResponse();
		ErrorProperties err = ErrorProperties.getInstance();

		InpatientAdmissionPatientsServiceImpl service = new InpatientAdmissionPatientsServiceImpl();
		List<String> grps = new ArrayList<String>();

		try {

			removeLobPgmPrefixes(request);
			prepareChronicCareGapMap(request);

			// Kill switch check on Provider groups
			if (StringUtils.isNotBlank(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			prepareRASuppressionCond(request);
			prepareLPRSuppressionCond(request);

			// Clinical access check on provider groups
			if (null != grps && !grps.isEmpty()) {

				request.setProvGrpIdsWithoutClinicalCheck(StringUtils.join(grps, ','));
				grps = filterProvGrpsByClinicalInd(request, grps);
				request.setProvGrpIds(StringUtils.join(grps, ','));
			}

			/*
			 * Determine whether Action Center is suppressed - it'll play a part in deciding whether to display
			 * the "i" icon in all of the Clinical Programs columns in Population Management and
			 * Performance Management drill-downs.
			 * 
			 * Determine which LOBs are suppressed - it'll play a part in deciding whether to replace the Total Cost
			 * and HCC values with dashes.
			 */
			CommonQueries cq = new CommonQueries();
			request.setGroupsWithActionCenterSuppressed(cq.getGroupsWithComponentSuppressed(request, Constants.AC_RF_CARDCONTAINER));
			request.setSuppression(cq.getActiveSuppressionForSelectComponents(request));
			request.setUnsuppressedLOBsTotalCost(getLOBsWithoutTotalCostSuppressed(request));

			if (null != grps && !grps.isEmpty()) {

				if (StringUtil.isExportDest(request.getDest())) {

					if (StringUtil.isChartExport(request.getChartImageData())) {
						TapChartExport exp = new TapChartExport(request, Constants.IA_PAT_TAP_REPORT);
						ExportProcessor.getInstance().submit(exp);
					}
					else {

						List<ExportGridColumn> columns = service.buildExportGridColumns(request);
						InpatientAdmissionPatientExport exp = new InpatientAdmissionPatientExport(request, columns);

						ExportProcessor.getInstance().submit(exp);

					}
				}
				else {

					List<MstrCnsmrFactAndOthers> resultList = service.getData(request);
					List<Patient> patientList = service.getBeanList(resultList, request);
					MetaData metaData = buildMetaData(request, service);

					if (null != resultList && !resultList.isEmpty()) {

						response.setData(patientList);
						response.setMetaData(metaData);
						response.setMessage(err.getProperty("successful"));
						response.setExportTotal(service.getTotalExport());
						response.setTotal(service.getRowCount());
					}
					else {

						response.setMessage(err.getProperty("successNoData"));
					}
				}
			}

			response.setSuccess(true);

			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}
}
