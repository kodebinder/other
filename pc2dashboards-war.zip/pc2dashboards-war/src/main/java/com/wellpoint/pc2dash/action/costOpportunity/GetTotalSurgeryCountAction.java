package com.wellpoint.pc2dash.action.costOpportunity;

import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.dto.costOpportunity.CostOppForLabsBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.dto.costOpportunity.TotalSurgeryCountBean;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.service.costOpportunity.GetTotalSurgeryCountServiceImpl;

//PCMSP-21873

public class GetTotalSurgeryCountAction extends Action {
	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetTotalSurgeryCountAction.class);
	
	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		
		List<TotalSurgeryCountBean> resultList = new ArrayList<TotalSurgeryCountBean>();
		GetTotalSurgeryCountResponse response = new GetTotalSurgeryCountResponse();
		GetTotalSurgeryCountRequest request = (GetTotalSurgeryCountRequest) actionRequest;
		ErrorProperties err = ErrorProperties.getInstance();
		GetTotalSurgeryCountServiceImpl service = new GetTotalSurgeryCountServiceImpl();
		MetaData metaData = new MetaData();
		
		try {
			resultList = service.getData(request);
			if (null == resultList || resultList.isEmpty()) {
				response.setMessage(err.getProperty("successNoData"));
			}
			else {
				response.setMetaData(metaData);
				response.setMessage(err.getProperty("successful"));
				response.setData(resultList);
				response.setTotal(service.getRowCount());
			}
			response.setSuccess(true);
			return response;
		}catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			logger.info(pce.toString());
			return pce.checkException(pe, response);
		}
	}
}
