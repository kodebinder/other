package com.wellpoint.pc2dash.action.summary;

import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;

public class GetSharedSavingsSummaryRequest extends PerformanceManagementRequest {

}
