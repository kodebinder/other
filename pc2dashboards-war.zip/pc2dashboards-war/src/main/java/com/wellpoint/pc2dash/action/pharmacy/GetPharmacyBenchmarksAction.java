package com.wellpoint.pc2dash.action.pharmacy;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.dto.pharmacy.PharmacyBenchmarks;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportGridColumn;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.population.PharmacyTherapeuticClassExport;
import com.wellpoint.pc2dash.service.pharmacy.PharmacyBenchmarksServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetPharmacyBenchmarksAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetPharmacyBenchmarksRequest request = (GetPharmacyBenchmarksRequest) actionRequest;
		GetPharmacyBenchmarksResponse response = new GetPharmacyBenchmarksResponse();
		ErrorProperties err = ErrorProperties.getInstance();

		List<PharmacyBenchmarks> resultList = new ArrayList<PharmacyBenchmarks>();

		PharmacyBenchmarksServiceImpl service = new PharmacyBenchmarksServiceImpl();
		List<String> grps = null;

		try {

			removeLobPgmPrefixes(request);

			if (StringUtils.isNotBlank(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			if (null != grps && !grps.isEmpty()) {
				request.setProvGrpIdsWithoutClinicalCheck(StringUtils.join(grps, Constants.COMMA));
				grps = filterProvGrpsByClinicalInd(request, grps);
				request.setProvGrpIds(StringUtils.join(grps, Constants.COMMA));
			}

			if (StringUtil.isExportDest(request.getDest())) {
				// To do -> Export code goes here!
			} else if(null != grps && !grps.isEmpty()){

				resultList = service.getResultList(request);

				if (null == resultList || resultList.isEmpty()) {
					response.setMessage(err.getProperty("successNoData"));
					response.setData(resultList);
				}
				else {
					response.setMessage(err.getProperty("successful"));
					response.setData(resultList);
					response.setTotal(resultList.size());
				}
			}

			response.setSuccess(true);
			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

	}

}
