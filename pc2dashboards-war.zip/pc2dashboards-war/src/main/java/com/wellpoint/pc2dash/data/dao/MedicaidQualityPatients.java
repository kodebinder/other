package com.wellpoint.pc2dash.data.dao;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.quality.GetQualityPatientsRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.patient.Patient;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QueryConstants;
import com.wellpoint.pc2dash.util.StringUtil;

public class MedicaidQualityPatients extends GeneralPatients {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(MedicaidQualityPatients.class);

	public List<Patient> getMedicaidQualityPatients(GetQualityPatientsRequest request, List<String> columnsForExport) throws Exception {

		setExport(StringUtil.isExport(request));
		setRowCount(0);

		List<Patient> result = new ArrayList<Patient>();
		String sql = buildSql(request, columnsForExport);

		try {
			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			buildPreparedStatement(request, sql, columnsForExport);
			executeQuery(logger, sql);
			result = convertSelectedRowsToObjects(rs, request, columnsForExport);

		}
		catch (Exception e) {
			throw new Exception("Exception during getMedicaidQualityPatients (" + request.toString() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}

	protected String buildSql(GetQualityPatientsRequest request, List<String> columnsForExport) throws ParseException {
		StringBuilder sql = new StringBuilder()
			.append("select a.* ")
			.append("from ( ")
			.append("select row_number() over () as rank, ")
			.append(buildSharedSelectGroupByColumns(request, columnsForExport))
			.append(buildNonAdherenceQualityMeasureNumberSubSelect())
			.append(", count(*) over () as row_cnt ");

		StringBuilder from = new StringBuilder("from pat_smry_fact psf ");

		// User Story 52549
		from.append(" left join (select  rfd.mstr_cnsmr_dim_key, rfd.prov_grp_dim_key, rfd.prov_org_dim_key, rfd.ip_dim_key, sum(case")
			.append(" when  rfd.rfrl_type_cd = 'Draft' ")
			.append(" then  1 ")
			.append(" else  0 end) as draft_rfrl_cnt, sum(case ")
			.append(" when  rfd.rfrl_type_cd = 'Sent' ")
			.append(" then  1 ")
			.append(" else  0 end) as sent_rfrl_cnt, sum(case ")
			.append(" when  rfd.rfrl_type_cd = 'Received' ")
			.append(" then  1 ")
			.append(" else  0 end) as recvd_rfrl_cnt, count(*) as rfrl_cnt ")
			.append(" from  rfrl_form_dtl rfd")
			.append(" where  rfd.rcrd_stts_cd <> 'DEL' ")
			.append(" and  rfd.rfrl_sbmtd_dt between (current_date -1 year) ")
			.append(" and  (current_date) ")
			.append(" group by  rfd.mstr_cnsmr_dim_key, rfd.prov_grp_dim_key, rfd.prov_org_dim_key, rfd.ip_dim_key ) ref on ( psf.mstr_cnsmr_dim_key = ref.mstr_cnsmr_dim_key ")
			.append(" and  psf.prov_grp_dim_key = ref.prov_grp_dim_key ")
			.append(" and  psf.prov_org_dim_key = ref.prov_org_dim_key ")
			.append(" and  psf.ip_dim_key = ref.ip_dim_key ) ");
		// 52549 Ends

		if (isExport()) { // In the case of export, join to some of the pre-psf tables

			from.append("join cmplnc_fact cf on (psf.mstr_cnsmr_dim_key = cf.mstr_cnsmr_dim_key) ");
			from.append("join msr_dim md_q on (cf.msr_dim_key = md_q.msr_dim_key) ");
			// Export: Sometimes needs to join, select, and set (from the resultSet) care opps status (if populated). Sometimes includes care opps status in where (if populated).
			// Display: Never needs to select or set care opps status. Sometimes includes care opps status in join and where (if populated).
			from.append("left join msr_dim md_co on (md_q.care_oprtnty_msr_dim_key = md_co.msr_dim_key) ");
			from.append("left join care_oprtnty_fact cof on (md_co.msr_dim_key = cof.msr_dim_key ");
			from.append("and cf.mstr_cnsmr_dim_key = cof.mstr_cnsmr_dim_key) ");
			from.append("join scrcrd_msr_hrchy_dim smhd on (cf.scrcrd_msr_hrchy_dim_key = smhd.scrcrd_msr_hrchy_dim_key) ");
		}

		if (isExport()) {
			/** 57008 CHRONIC_CARE_GAP changes| ad87338 | START */
			//QueryConstants.prepareQualityPatientChronicRiskExportQuery(columnsForExport, sql);
			// AF00030 Made changes for PCMSP-1041 
			QueryConstants.prepareChronicRiskExportQueryWithPatTable(columnsForExport, sql);
			//AF00030 made changes for PCMSP-1042 for High Risk Rx export
			//	QueryConstants.prepareHighRiskQualityExportQuery(columnsForExport, sql, request);
			/** 57008 CHRONIC_CARE_GAP changes| ad87338 | END */
		}

		/*
		 * Earlier : CM/DM not applicable for FPCC
		 * Changing it back after updated requirement to include CM/DM for FPCC
		 * Removing the if clause
		 */

		if (isExport() && columnsForExport.contains(Constants.CMDMPrograms)) {
			from.append(QueryConstants.buildCmDmExportJoinClause());
		}
		if (isExport() && columnsForExport.contains(Constants.MEASURES)) {
			from.append(QueryConstants.buildMeasuresJoinClause(request));
		}

		StringBuilder where = new StringBuilder("where ");

		// POIT clause
		buildPoitClauses(request, from, where);

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) { // populated if the Organization filter is applied

			where.append("and psf.ip_dim_key in (" // NF31 (no longer psf.prov_grp_hrchy_dim_key)
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys())
				+ ") "); // provDimKeys
		}
		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			where.append(" and psf.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}

		if (!StringUtils.isBlank(request.getProgramId())) {

			where.append("and psf.pgm_id = ? "); // programId
		}

		where.append(" AND psf.ATRBN_STTS_CD = 'ACTIVE' ");

		// Sub-select costs less than joins, but if this is an export, we've already joined to these tables above, since we'll need to select from them.
		// Therefore, if this is an export, just use the inner where clause. If this is not an export, use the sub-select and the inner where clause.
		//		if (!isExport()) {
		where.append("and psf.mstr_cnsmr_dim_key in ( ");
		where.append("select cf.mstr_cnsmr_dim_key ");
		where.append("from cmplnc_fact cf ");
		where.append("join msr_dim md_q on (cf.msr_dim_key = md_q.msr_dim_key) ");
		where.append("left join msr_dim md_co on (md_q.care_oprtnty_msr_dim_key = md_co.msr_dim_key) ");
		where.append("left join care_oprtnty_fact cof on (md_co.msr_dim_key = cof.msr_dim_key ");
		where.append("and  cf.mstr_cnsmr_dim_key = cof.mstr_cnsmr_dim_key) ");
		where.append("join scrcrd_msr_hrchy_dim smhd on (cf.scrcrd_msr_hrchy_dim_key = smhd.scrcrd_msr_hrchy_dim_key) ");
		where.append("join  prov_grp_hrchy_dim pghd on (cf.prov_grp_dim_key = pghd.prov_grp_dim_key ");
		where.append("and  cf.prov_org_dim_key = pghd.prov_org_dim_key and  cf.ip_dim_key = pghd.ip_dim_key ");
		where.append("and  psf.PROV_GRP_HRCHY_DIM_KEY = pghd.PROV_GRP_HRCHY_DIM_KEY) ");
		where.append("where ");
		//		}
		StringBuilder innerWhere = new StringBuilder();


		if (!StringUtils.isBlank(request.getCompositeId())) {
			innerWhere.append("and smhd.cmpst_defn_id = ? ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys())) {
			innerWhere.append("and md_q.msr_id in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getQualityMeasureKeys())
				+ ") "); // qualityMeasureKeys (not smhd.msr_dim_key)
		}

		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
			innerWhere.append("and cf.msrmnt_prd_strt_dt = ? "); // measurementPeriodStartDt
		}

		//		if (StringUtil.getStatusCdsFilter(request.getStatusCds()) != -1) {
		//			innerWhere.append("and cf.msr_nmrtr_nbr = ? "); // msr_nmrtr_nbr of 0 means non-compliant (note: msr_dnmntr_nbr is always 1)	
		//		}
		/** PCMSP-472, modifying logic to include and/or toggle for compliance status */
		if (StringUtil.getStatusCdsFilters(request.getStatusCds()).size() > 0) {
			innerWhere.append("and cf.msr_nmrtr_nbr in (" + StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getStatusCds()) + ") "); // msr_nmrtr_nbr of 0 means non-compliant (note: msr_dnmntr_nbr is always 1)	
		}

		if (StringUtil.isNotBlankOrFalse(request.getCareOppsStatusCds())) {

			innerWhere.append("and cof.mstr_cnsmr_dim_key  in ("
				+ QueryConstants.getCareOppStatusImpQueryWithToggle(request)
				+ ") "); // careOppsStatusCds
		}


		innerWhere.append("and smhd.cmpst_type_desc = ? ");
		innerWhere.append("and cf.rcrd_stts_cd <> 'DEL' ");
		innerWhere.append("and cf.anlyss_as_of_dt = ? "); // new per Vishal

		/** AF21144 | PCMSP-473 */
		//		if (!isExport()) {
		innerWhere.append(" group by cf.mstr_cnsmr_dim_key ");
		StringBuilder havingClause = new StringBuilder();
		if (StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys()) && Constants.AND_OPERATOR.equalsIgnoreCase(request.getQualityMeasureKeysToggle()))
			havingClause.append(QueryConstants.qualityMeasureToggleQuery(request, "cf"));
		if (StringUtil.isNotBlankOrFalse(request.getStatusCds()) && Constants.AND_OPERATOR.equalsIgnoreCase(request.getStatusCdsToggle())
			&& StringUtil.getStatusCdsFilters(request.getStatusCds()).size() == 2) {
			if (havingClause.length() > 0)
				havingClause.append(" and ");
			else
				havingClause.append(" having ");
			havingClause.append(" count(distinct(cf.msr_nmrtr_nbr)) = ? ");
		}
		innerWhere.append(havingClause);
		//		}

		//		if (!isExport()) {
		innerWhere = StringUtil.removeFirstOccurenceWithinString(innerWhere, "and");
		where.append(innerWhere);
		where.append(") ");

		//		}
		//		else {
		//			where.append(innerWhere);
		//		}
		/** 57008 CHRONIC_CARE_GAP changes| ad87338 | START */
		//	QueryConstants.prepareChronicRiskFilters(StringUtil.prepareMapForChronicRisk(request), where);
		// AF00030 made changes for High Risk included in Global Filter PCMSP-1041
		QueryConstants.prepareChronicRiskFiltersFromPatTable(StringUtil.prepareMapForChronicRisk(request), where);

		/** 57008 CHRONIC_CARE_GAP changes| ad87338 | END */

		if (StringUtil.isNotBlankOrFalseOrMasked(request.getMemberFullNameQuery())) {

			String str = request.getMemberFullNameQuery().trim();
			if (str.contains(",")) {
				String[] splited = str.split(",");
				Integer len = splited.length;
				if (len == 2) {
					where.append(" and(( (upper(psf.last_nm) like upper(?)) and (upper(psf.frst_nm) like upper(?))) "
						+ "or ((upper(psf.last_nm) like upper(?)) and (upper(psf.frst_nm) like upper(?) )))");
				}
				if (len == 1) {
					where.append(" and (upper(psf.last_nm) like upper(?) or upper(psf.frst_nm) like upper(?)) ");
				}
			}
			else if (str.contains(" ")) {
				where.append(" and(( (upper(psf.last_nm) like upper(?)) and (upper(psf.frst_nm) like upper(?))) "
					+ "or ((upper(psf.last_nm) like upper(?)) and (upper(psf.frst_nm) like upper(?) )))");
			}
			else
				where.append(" and (upper(psf.last_nm) like upper(?) or upper(psf.frst_nm) like upper(?)) ");
		}

		if (!StringUtils.isBlank(request.getProvGrpIds())) {

			where.append("and psf.prov_grp_id = ? ");
		}

		/**
		 * Commenting the lob dim key where clause as part of Defect fix for WLPRD02383426
		 * Author - AD12140
		 * Based on suggestions from Data team to remove lob checks from the Drill down Patient and chart queries
		 */
		/*if (!StringUtils.isBlank(request.getLobDimKeys())) {
			
			where.append("and (psf.lob_dim_key in (" 
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getLobDimKeys()) 
					+ ") or (psf.LOB_DIM_KEY = '0' )) ");
		}*/

		// IHM Care Coordination filter: AP56, CP34, CO19, & SC92
		//		where.append(QueryConstants.buildIhmExistsCondition(request.getIhmIndToggle(),request.getIhmInd())); // Moved due to 2.0 toggle logic

		if (filterCMDMPrograms(request)) {

			// CMDM Program filters
			if (StringUtil.isNotBlankOrFalse(request.getCmdmProgramKeys())) {

				where.append(QueryConstants.buildCmDmProgramKeysSubSelect(request));
			}

			// CMDM Status filters
			if (StringUtil.isNotBlankOrFalse(request.getCmdmStatusKeys())) {

				where.append(QueryConstants.buildCmDmStatusKeysSubSelectsWithPatTables(request));
			}
		}
		else {

			where.append(QueryConstants.buildIhmExistsCondition(request));
		}

		where = StringUtil.removeFirstOccurenceWithinString(where, "and");

		sql.append(from).append(where);

		sql
			// group by instead of distinct/dense_rank()
			.append(" group by ")
			.append(StringUtil.stripAsAndUpperFromClause(buildSharedSelectGroupByColumns(request, columnsForExport)));

		//		/** AF21144 | PCMSP-473 */
		//		if (isExport() && StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys()) && Constants.AND_OPERATOR.equalsIgnoreCase(request.getQualityMeasureKeysToggle())) {
		//			sql.append(QueryConstants.qualityMeasureToggleQuery(request, "cf"));
		//		}

		if (!isExport())
			sql.append(" order by %s"); // now that we've removed the top level joins and are relying on sub-selects, the order by clause had to move here
		else {
			sql.append(" order by ");
			sql.append(getSortClauseForQualityExport(request));
		}
		sql.append(") a ");

		// format the sql string differently depending on whether we're displaying or exporting the grid
		boolean limited = isLimited(request);
		ArrayList<Object> paramList = new ArrayList<Object>();

		// Export: sort by last name, first name (per requirement BR1.1.15.9)
		// Display: sort by the parameters UI passes
		// Commented by Vignesh as per Defect no WLPRD01549503	
		/*if (isExport()) {
			request.getSort().setProperty("memberFullName");
			request.getSort().setDirection("asc");
		}*/
		if (!isExport())
			paramList.add(getSortClause(request));


		if (limited && !isExport()) {
			sql.append("where rank between %d and %d ");
			paramList.add(Integer.parseInt(request.getStart()) + 1);
			paramList.add(Integer.parseInt(request.getStart()) + Integer.parseInt(request.getLimit()));
		}

		sql.append("with ur");
		String sqlString = sql.toString();
		if (!isExport())
			sqlString = String.format(sql.toString(), paramList.toArray());

		return sqlString;
	}

	protected void buildPreparedStatement(GetQualityPatientsRequest request, String sql, List<String> columnsForExport) throws SQLException {
		int i = 0;
		prepareStatement(logger, sql);

		// same order of null checks as buildSql() to make sure markers are populated correctly
		if (StringUtil.isNotBlankOrFalse(request.getCompositeType())) {
			ps.setString(++i, request.getCompositeType());
		}

		CommonQueries cq = new CommonQueries();
		//String aaod = cq.selectAAODOther(request.getProgramId(), request.getMeasurementPeriodStartDt());
		String aaod = cq.selectAAODOther(request.getProgramId(), request.getMeasurementPeriodStartDt(), request.getProvGrpIds()); //PCMSP-13914
		ps.setString(++i, aaod);

		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
			ps.setString(++i, request.getMeasurementPeriodStartDt());
		}

		/*
		 * Populating these prepared statement clauses in order to cater to the LEFT OUTER JOIN for the export hover records
		 */
		if (isExport() && columnsForExport.contains(Constants.MEASURES)) {
			if (StringUtil.isNotBlankOrFalse(request.getCompositeType())) {
				ps.setString(++i, request.getCompositeType());
			}
			ps.setString(++i, aaod);
			if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
				ps.setString(++i, request.getMeasurementPeriodStartDt());
			}
		}
		// End of clauses for the LEFT OUTER JOIN clause

		//if (doPoitTableJoin(request.getGrpInd())) {			
		ps.setString(++i, request.getSessionId());

		ps.setString(++i, request.getEntitlementId());
		//}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) { // populated if the Organization filter is applied
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}
		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (!StringUtils.isBlank(request.getProgramId())) {
			ps.setString(++i, request.getProgramId());
		}

		if (!StringUtils.isBlank(request.getCompositeId())) {
			ps.setString(++i, request.getCompositeId());
		}

		if (StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys())) {
			String[] array = request.getQualityMeasureKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
			ps.setString(++i, request.getMeasurementPeriodStartDt());
		}

		//		if (StringUtil.getStatusCdsFilter(request.getStatusCds()) != -1) {
		//			ps.setInt(++i, StringUtil.getStatusCdsFilter(request.getStatusCds()));
		//		}

		if (!StringUtil.getStatusCdsFilters(request.getStatusCds()).isEmpty()) {
			for (String code : StringUtil.getStatusCdsFilters(request.getStatusCds()))
				ps.setString(++i, code);
		}

		if (StringUtil.isNotBlankOrFalse(request.getCareOppsStatusCds())) {
			String[] array = request.getCareOppsStatusCds().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.convertCareOppsStatus(item));
			}
			ps.setInt(++i, array.length);
		}

		if (StringUtil.isNotBlankOrFalse(request.getCompositeType())) {
			ps.setString(++i, request.getCompositeType());
		}

		ps.setString(++i, aaod); // second instance of AAOD parameter

		/** AF21144 | PCMSP-473 start */
		if (
		//			!isExport() && 
		StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys()) && Constants.AND_OPERATOR.equalsIgnoreCase(request.getQualityMeasureKeysToggle())) {
			int msr_count = request.getQualityMeasureKeys().split(",").length;
			if (msr_count > 1)
				ps.setInt(++i, msr_count);
			else
				ps.setInt(++i, 0);
		}
		/** end */

		if (
		//			!isExport() && 
		StringUtil.isNotBlankOrFalse(request.getStatusCds()) && Constants.AND_OPERATOR.equalsIgnoreCase(request.getStatusCdsToggle())) {
			int statusCnt = request.getStatusCds().split(",").length;
			if (statusCnt == 2)
				ps.setInt(++i, statusCnt);
		}

		/** 57008 CHRONIC_CARE_GAP changes| ad87338 | START */
		// Risk Drivers filter
		if (StringUtil.isNotBlankOrFalse(request.getRiskDriverKeys())) {
			i = buildRiskDriversFilterPreparedStatement(request, i);
		}

		/*if (null != request.getRiskDriverKeys() && StringUtil.isNotBlankOrFalse(request.getRiskDriverKeys())) {
			String[] array = request.getRiskDriverKeys().split(",");
			// Need to be set 4 times
			for (String item : array) {
				ps.setString(++i, item);
			}
			for (String item : array) {
				ps.setString(++i, item);
			}
			for (String item : array) {
				ps.setString(++i, item);
			}
			for (String item : array) {
				ps.setString(++i, item);
			}
		}*/

		/*if (StringUtil.isNotBlankOrFalse(request.getRiskDriverKeys())) {
		
			List<String> arrCcPlaceHolders = new ArrayList<String>();
			List<String> arrNonCcPlaceHolders = new ArrayList<String>();
		
		
			if (StringUtil.isNotBlankOrFalse(request.getRiskDriverKeys()))
			{
				String riskDriverKeys = request.getRiskDriverKeys();
				if (null != riskDriverKeys)
				{
					String[] arrRiskDriverKeys = riskDriverKeys.split(",");
					for (int j = 0; j < arrRiskDriverKeys.length; j++)
					{
						if (arrRiskDriverKeys[j].indexOf('_') != -1)
						{
							String[] ccRD = arrRiskDriverKeys[j].split("_");
							for (String s : ccRD)
								arrCcPlaceHolders.add(s);
						}
						else
							arrNonCcPlaceHolders.add(arrRiskDriverKeys[j]);
					}
				}
			}
		
		
		
			if (!arrNonCcPlaceHolders.isEmpty()) {
				for (String nonCCString : arrNonCcPlaceHolders) {
					ps.setString(++i, nonCCString);
				}
			}
			if (!arrNonCcPlaceHolders.isEmpty()) {
				for (String nonCCString : arrNonCcPlaceHolders) {
					ps.setString(++i, nonCCString);
				}
			}
			if (!arrCcPlaceHolders.isEmpty()) {
				for (String ccString : arrCcPlaceHolders) {
					ps.setString(++i, ccString);
				}
			}
			if (!arrCcPlaceHolders.isEmpty()) {
				for (String ccString : arrCcPlaceHolders) {
					ps.setString(++i, ccString);
				}
			}
			if(!arrNonCcPlaceHolders.isEmpty()){
				for(String nonCCString : arrNonCcPlaceHolders){
					ps.setString(++i, nonCCString);
				}
			}
			if(!arrNonCcPlaceHolders.isEmpty()){
				for(String nonCCString : arrNonCcPlaceHolders){
					ps.setString(++i, nonCCString);
				}
			}
			if(!arrNonCcPlaceHolders.isEmpty()){
				for(String nonCCString : arrNonCcPlaceHolders){
					ps.setString(++i, nonCCString);
				}
			}
			if(!arrNonCcPlaceHolders.isEmpty()){
				for(String nonCCString : arrNonCcPlaceHolders){
					ps.setString(++i, nonCCString);
				}
			}
		
			if (!arrNonCcPlaceHolders.isEmpty()) {
				for (String nonCCString : arrNonCcPlaceHolders) {
					ps.setString(++i, nonCCString);
				}
			}
			else
				ps.setNull(++i, java.sql.Types.VARCHAR);
		
			if (!arrNonCcPlaceHolders.isEmpty()) {
				for (String nonCCString : arrNonCcPlaceHolders) {
					ps.setString(++i, nonCCString);
				}
			}
			else
				ps.setNull(++i, java.sql.Types.VARCHAR);
		}*/
		// Risk Drivers filter
		if (null != request.getChronicCareGapsKeys()
			&& StringUtil.isNotBlankOrFalse(request.getChronicCareGapsKeys())) {
			String[] array = request.getChronicCareGapsKeys().split(",");
			// Need to be set 4 times
			for (String item : array) {
				ps.setString(++i, item);
			}
			/*for (String item : array) {
				ps.setString(++i, item);
			}
			for (String item : array) {
				ps.setString(++i, item);
			}
			for (String item : array) {
				ps.setString(++i, item);
			}*/
		}
		/** 57008 CHRONIC_CARE_GAP changes| ad87338 | END */

		if (StringUtil.isNotBlankOrFalseOrMasked(request.getMemberFullNameQuery())) {
			String str = request.getMemberFullNameQuery().trim();
			if (str.contains(",")) {
				String[] splited = str.split(",");
				Integer len = splited.length;
				if (len == 2) {
					String split_one = splited[0].trim();
					String split_second = splited[1].trim();
					String fn = "%" + split_one.toUpperCase().replaceAll("'", "''") + "%";
					String ln = "%" + split_second.toUpperCase().replaceAll("'", "''") + "%";
					ps.setString(++i, fn);
					ps.setString(++i, ln);
					ps.setString(++i, ln);
					ps.setString(++i, fn);
				}
				else if (len == 1) {
					String nm = "%" + splited[0].trim().toUpperCase().replaceAll("'", "''") + "%";
					ps.setString(++i, nm);
					ps.setString(++i, nm);

				}
			}
			else if (str.contains(" ")) {
				String[] splited = str.split(" ");
				Integer len = splited.length;
				if (len == 2) {
					String split_one = splited[0];
					String split_second = splited[1];
					String fn = "%" + split_one.toUpperCase().replaceAll("'", "''") + "%";
					String ln = "%" + split_second.toUpperCase().replaceAll("'", "''") + "%";
					ps.setString(++i, fn);
					ps.setString(++i, ln);
					ps.setString(++i, ln);
					ps.setString(++i, fn);
				}
			}
			else {
				String nm = "%" + request.getMemberFullNameQuery().trim().toUpperCase().replaceAll("'", "''") + "%";
				ps.setString(++i, nm);
				ps.setString(++i, nm);

			}

		}

		if (!StringUtils.isBlank(request.getProvGrpIds())) {
			ps.setString(++i, request.getProvGrpIds());
		}

		/**
		 * Commenting the lob dim key where clause as part of Defect fix for WLPRD02383426
		 * Author - AD12140
		 * Based on suggestions from Data team to remove lob checks from the Drill down Patient and chart queries
		 */
		/*if (!StringUtils.isBlank(request.getLobDimKeys())) {
			String[] array = request.getLobDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}*/

		if (filterCMDMPrograms(request)) {
			// CMDM Program filters
			i = buildCMDMPreparedStatement(request, i);

			// CMDM Status filters
			i = buildCMDMStatusPreparedStatement(request, i);
//			if (StringUtil.isNotBlankOrFalse(request.getCmdmStatusKeys())) {
//
//				Set<String> typs = new HashSet<String>();
//				Set<String> stts = new HashSet<String>();
//				Set<String> rsns = new HashSet<String>();
//				Set<String> ntrg = new HashSet<String>();
//
//				for (String v : request.getCmdmStatusKeys().split(",")) {
//
//					String[] s = v.replaceAll("_", " ").split("-");
//
//					if ("Not Triggered".equals(s[1])) {
//						ntrg.add(s[0]);
//					}
//					else {
//						typs.add(s[0]);
//						stts.add(s[1]);
//						rsns.add(s[2]);
//					}
//				}
//
//				//				if (typs.size() > 0) {
//				//					for (String s : typs) {
//				//						ps.setString(++i, s.toUpperCase());
//				//					}
//				//				}
//				//
//				//				if (stts.size() > 0) {
//				//					for (String s : stts) {
//				//						ps.setString(++i, s.toUpperCase());
//				//					}
//				//				}
//				//
//				//				if (rsns.size() > 0) {
//				//					for (String s : rsns) {
//				//						ps.setString(++i, s.toUpperCase());
//				//					}
//				//				}
//
//				//				R1.9|Defect-2631004|AD91912 start
//				HashMap<String, HashMap<String, ArrayList<String>>> programs = QueryConstants.populateProgramStructure(request.getCmdmStatusKeys());
//				for (String program : programs.keySet()) {
//					ps.setString(++i, program.toUpperCase());
//					HashMap<String, ArrayList<String>> stats = programs.get(program);
//					if (stats != null) {
//						for (String stat : stats.keySet()) {
//							ps.setString(++i, stat.toUpperCase());
//							if (!Constants.TRIGGRRD.equalsIgnoreCase(stat)) {
//								ArrayList<String> subStats = stats.get(stat);
//								if (subStats != null) {
//									for (String subStat : subStats)
//										ps.setString(++i, subStat.toUpperCase());
//								}
//							}
//						}
//					}
//				}
//				//				end
//
//				if (ntrg.size() > 0) {
//					for (String s : ntrg) {
//						ps.setString(++i, s.toUpperCase());
//					}
//				}
//			}
		}

		//		/** AF21144 | PCMSP-473 start */
		//		if (isExport() && StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys()) && Constants.AND_OPERATOR.equalsIgnoreCase(request.getQualityMeasureKeysToggle())) {
		//			int msr_count = request.getQualityMeasureKeys().split(",").length;
		//			if (msr_count > 1)
		//				ps.setInt(++i, msr_count);
		//			else
		//				ps.setInt(++i, 0);
		//		}
		//		/** end */
	}
}
