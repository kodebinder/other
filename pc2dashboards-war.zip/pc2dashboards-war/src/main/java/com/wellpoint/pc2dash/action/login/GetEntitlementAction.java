package com.wellpoint.pc2dash.action.login;

import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.data.dao.UserSecurityAccess;
import com.wellpoint.pc2dash.data.dto.Entitlement;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;


public class GetEntitlementAction extends Action {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetEntitlementAction.class);

	private static final String GROUP_SEARCH = "getSearchResults";

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetEntitlementRequest request = (GetEntitlementRequest) actionRequest;
		GetEntitlementResponse response = new GetEntitlementResponse();

		if (request.isValid()) {

			UserSecurityAccess dao = new UserSecurityAccess();
			Collection<Entitlement> ents = new ArrayList<Entitlement>();
			String grpId = request.getGroupId();

			if (GROUP_SEARCH.equals(request.getCmd())) {

				try {
					ents.addAll(dao.getLocalEntitlements(grpId));
				}
				catch (Exception e) {
					logger.error("Unable to retrieve local entitlements.", e);
				}
			}
			else {

				try {
					ents.addAll(dao.getRemoteEntitlements(grpId));
				}
				catch (Exception e) {
					logger.error("Unable to retrieve remote entitlements.", e);
				}
			}

			response.setData(ents);
			response.setTotal(ents.size());
			response.setSuccess(true);
		}
		else {

			response.setMessage("Missing required fields.");
			response.setSuccess(false);
		}

		return response;
	}
}
