package com.wellpoint.pc2dash.action.savedFilters;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class SavedFiltersResponse extends ActionResponse {

}
