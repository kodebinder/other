package com.wellpoint.pc2dash.action.utilization;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.action.quality.GetQualityAction;
import com.wellpoint.pc2dash.data.dao.UtilizationBrndFrmlryPrscrbrDao;
import com.wellpoint.pc2dash.dto.careOpportunities.Provider;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportGridColumn;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.scorecard.DrillDownChartExport;
import com.wellpoint.pc2dash.export.scorecard.commercial.BrandFormularyPrescribersExport;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetUtilizationBrandFormularyPrescribersAction extends GetQualityAction  {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetUtilizationBrandFormularyPrescribersRequest request = (GetUtilizationBrandFormularyPrescribersRequest) actionRequest;
		GetUtilizationBrandFormularyPrescribersResponse response = new GetUtilizationBrandFormularyPrescribersResponse();

		List<String> grps = new ArrayList<String>();
		List<Provider> resultList = new ArrayList<Provider>();

		try {

			request = (GetUtilizationBrandFormularyPrescribersRequest) cleanRequest(request);

			// Pass the Request to the DAO (no need to populate a HashMap)
			UtilizationBrndFrmlryPrscrbrDao dao = new UtilizationBrndFrmlryPrscrbrDao();

			// Kill switch check on Provider groups
			if (StringUtils.isNotBlank(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			// Clinical access check on provider groups
			if (null != grps && grps.size() > 0) {

				grps = filterProvGrpsByClinicalInd(request, grps);
				request.setProvGrpIds(StringUtils.join(grps, ','));

				if (StringUtil.isJson(request)) {

					resultList = dao.getPrecribingProviders(request);

					MetaData metaData = buildMetaData(request, dao);
					response.setMetaData(metaData);

					response.setData(resultList);
					response.setTotal(dao.getRowCount()); // calculates total without another query
					response.setMessage(StringUtil.buildMessage(resultList.isEmpty()));
				}
				else {
					
					if (StringUtil.isChartExport(request.getChartImageData())) {
						DrillDownChartExport exp = new DrillDownChartExport(request, Constants.PRESCRIBER);	
				        ExportProcessor.getInstance().submit(exp);
					} else {

						List<ExportGridColumn> columns = dao.buildExportGridColumns(request);
						BrandFormularyPrescribersExport exp = new BrandFormularyPrescribersExport(request, columns);
						ExportProcessor.getInstance().submit(exp);

					}
				}
			}

			response.setSuccess(true);
		}
		catch (Exception e) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(e, response);
		}

		return response;
	}
}
