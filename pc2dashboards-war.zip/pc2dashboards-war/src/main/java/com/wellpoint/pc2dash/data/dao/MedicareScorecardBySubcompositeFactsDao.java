package com.wellpoint.pc2dash.data.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;
import com.wellpoint.pc2dash.dto.scorecard.ScorecardSubcompositeBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.DateUtil;
import com.wellpoint.pc2dash.util.StringUtil;

public class MedicareScorecardBySubcompositeFactsDao extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(MedicareScorecardBySubcompositeFactsDao.class);

	public Collection<ScorecardSubcompositeBean> getScorecardSubcomposites(PerformanceManagementRequest request) throws Exception {

		Collection<ScorecardSubcompositeBean> result = new ArrayList<ScorecardSubcompositeBean>();

		try {
			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			String scrngLvlCd;
			String msrDimKey;
			Set<String> subCmpstDefnIdWithGroup = new HashSet<String>();
			Set<String> subCmpstDefnIdWithPanel = new HashSet<String>();
			Map<String, Set<String>> scrngLvlMap = new HashMap<String, Set<String>>();
			StringBuilder sql = null;
			String qrtrId = null;
			String cmpstTypeDesc = request.getCompositeType();
			//PCMSP-11158
			String measStartDate = request.getMeasurementPeriodStartDt();
			boolean isMPGreaterThan2017 = DateUtil.dateComparator(measStartDate, Constants.IND_MTRC_STRT_DT);

			//added based on new req
			String improvement = "Improvement";
			//Query for Improvement
			if (cmpstTypeDesc.equalsIgnoreCase(improvement) && !isMPGreaterThan2017) {
				//sql.delete(0,sql.length()-1);
				sql = new StringBuilder();
				sql.append("SELECT DISTINCT ms.MSR_DSPLY_NM , ")
					.append("ms.MSR_DIM_KEY , ")
					.append("ms.MSR_ID , ")
					.append("ipgsf.SCORG_LVL_CD , ")
					.append("ipgsf.BSLN_RT_PCT , ")
					.append("ipgsf.TRGT_RT_PCT , ")
					.append("ipgsf.CURNT_CMPLNC_RT_PCT , ")
					.append("ipgsf.RDSTRBTD_ERNCNTR_PCT , ")
					.append("ipgsf.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT , ")
					.append("smhd.SUB_CMPST_NM , ")
					.append("smhd.CMPST_DEFN_ID,")
					.append("smhd.SUB_CMPST_DEFN_ID,")
					.append("ipgsf.MSR_DNMNTR_NBR, ")
					.append("ipgsf.ANLYSS_AS_OF_DT ")
					//.append(" epgsf.MDCR_TOTL_ERCNTR_PCT ,epgsf.MDCR_TIER_2_IND ")  //PCMSP-11254
					.append("FROM ")
					.append("IMPRV_PROV_GRP_SMRY_FACT ipgsf,")
					//	.append("ERNCNTR_FACT ef,")
					.append("SCRCRD_MSR_HRCHY_DIM smhd, ")
					.append("MSR_DIM ms,")
					.append("PGM_DIM pgm, ")
					.append("PROV_GRP_DIM pg, ")
					.append("SCRCRD_PGM_MSR_HRCHY_FACT spmhf ")
					//.append(" ERNCNTR_PROV_GRP_SMRY_FACT epgsf ")  //PCMSP-11254
					//.append(" prov_grp_pgm_lob_fact pgplf, ")      //added as a part of R1.3
					//.append(" lob_dim ld ")						   //added as a part of R1.3
					.append(" WHERE ")
					//.append(" ipgsf.PROV_GRP_DIM_KEY = ef.PROV_GRP_DIM_KEY AND ")
					//.append(" ipgsf.PGM_DIM_KEY = ef.PGM_DIM_KEY AND  ")
					//.append(" ipgsf.MSRMNT_PRD_STRT_DT = ef.MSRMNT_PRD_STRT_DT AND ")
					//.append(" ipgsf.ANLYSS_AS_OF_DT = ef.ANLYSS_AS_OF_DT  AND ")
					.append(" ipgsf.PGM_DIM_KEY = pgm.PGM_DIM_KEY AND  ")
					.append(" ipgsf.PROV_GRP_DIM_KEY = pg.PROV_GRP_DIM_KEY AND  ")
					//.append(" ipgsf.MNTH_ID = ef.MNTH_ID AND  ") //Commented as per Dasmeets email.
					.append(" ipgsf.MNTH_ID = spmhf.MNTH_ID AND  ") //this should be added as per confirmation from Amit
					.append(" ipgsf.SCRCRD_MSR_HRCHY_DIM_KEY = smhd.SCRCRD_MSR_HRCHY_DIM_KEY AND  ")

					//.append(" ipgsf.prov_grp_dim_key = pgplf.prov_grp_dim_key and ") //added as a part of R1.3
					//.append(" ipgsf.pgm_dim_key= pgplf.pgm_dim_key and ")             //added as a part of R1.3
					//.append(" ld.lob_dim_key = PGPLF.LOB_DIM_KEY and ")		  //added as a part of R1.3

					.append(" smhd.MSR_DIM_KEY = ms.MSR_DIM_KEY AND ") //Added as per Dasmeet's email.
					.append(" ipgsf.MSR_DIM_KEY = ms.MSR_DIM_KEY AND  ")
					/*.append(" epgsf.prov_grp_dim_key = ef.prov_grp_dim_key and epgsf.pgm_dim_key = ef.pgm_dim_key and ") //PCMSP-11254
					.append(" epgsf.mnth_id = ef.mnth_id and   epgsf.msrmnt_prd_strt_dt = ef.msrmnt_prd_strt_dt and ")*/
					.append(" pg.PROV_GRP_ID= ? AND  ")
					.append("  pgm.PGM_ID = ? AND  ")
					.append(" ipgsf.MSRMNT_PRD_STRT_DT = ? AND  ")
					.append(" smhd.CMPST_DEFN_ID = ? AND  ")
					.append(" spmhf.pgm_lob_type_cd = ? ");
				/*.append(" pgplf.lob_dim_key in ( ");
				int counter = 0;
				List<String> lobDimKeys = Arrays.asList(request.get("lobDimKeys").split(","));
				for(String lobDimKey:lobDimKeys){
					counter++;
					sql.append(" "+new BigInteger(lobDimKey)+" ");
					if(counter<lobDimKeys.size()){
						sql.append(", ");
					}
				}
				sql.append(" ) ");*/

				if (null != Constants.getQuarterName(request.getMeasurementInterval())) {
					if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
						sql.append(" AND ipgsf.BSLN_SCRCRD_IND = ? ");
					}
					else {
						sql.append(" AND ipgsf.QTR_ID = ? ");
					}
				}
				else {
					//Changing the implementation of the month id clause based on the query snippet suggested by vishwa
					//Commenting the code earlier
					//sql.append(" AND ipgsf.MNTH_ID = (Select max(ipgsf.mnth_id) from imprv_prov_grp_smry_fact ipgsf) ");

					sql.append(" AND IPGSF.MNTH_ID = (SELECT MAX(IPGSF.MNTH_ID) ");
					sql.append(" FROM IMPRV_PROV_GRP_SMRY_FACT IPGSF ");
					sql.append(" INNER JOIN ");
					sql.append(" (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT ");
					sql.append(" FROM SCRCRD_PGM_MSR_HRCHY_FACT ");
					sql.append(" WHERE PGM_DIM_KEY = ");
					sql.append(" (SELECT PGM_DIM_KEY FROM PGM_DIM WHERE PGM_ID = ? ) ");
					sql.append("  and  MSRMNT_PRD_STRT_DT = ? ");
					sql.append(" GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM ");
					sql.append(" ON IPGSF.PGM_DIM_KEY = SC_PGM.PGM_DIM_KEY AND IPGSF.MSRMNT_PRD_STRT_DT = SC_PGM.MSRMNT_PRD_STRT_DT) ");


				}

				sql = StringUtil.appendWithUr(sql);

				//				logger.debug("getScorecardSubcomposites SQL: " + sql.toString());

				if (cn != null) {
					ScorecardSubcompositeBean subcompositeBean;

					prepareStatement(logger, sql.toString());
					ps.setString(1, request.getProvGrpIds());
					ps.setString(2, request.getProgramId());
					ps.setString(3, request.getMeasurementPeriodStartDt());
					ps.setString(4, request.getCompositeId());
					ps.setString(5, request.getProgramLobTypeCd().toUpperCase());

					//logger.debug("provGrpId: " + request.getProvGrpId());
					//logger.debug("prgmId: " + request.getProgramId());
					//logger.debug("msrmntStrtDt: " + request.getMeasurementPeriodStartDt());
					//logger.debug("compositeId: " + request.getCompositeId());
					//logger.debug("programLobTypeCd: " + request.getProgramLobTypeCd());

					if (null != Constants.getQuarterName(request.getMeasurementInterval())) {
						if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
							ps.setString(6, "Y");
						}
						else {
							ps.setString(6, Constants.getQuarterName(request.getMeasurementInterval()));
						}
						//logger.debug("measurementInterval: " + Constants.getQuarterName(request.getMeasurementInterval()));
					}
					else {
						ps.setString(6, request.getProgramId());
						//logger.debug("prgmId: " + request.getProgramId());
						ps.setString(7, request.getMeasurementPeriodStartDt());
					}

					executeQuery(logger, sql.toString());
					while (rs.next()) {
						subcompositeBean = new ScorecardSubcompositeBean();
						subcompositeBean.setCompositeId(getString(rs, "CMPST_DEFN_ID"));
						subcompositeBean.setMsrDimKey(rs.getString("MSR_DIM_KEY"));
						subcompositeBean.setMsrId(rs.getString("MSR_ID"));
						subcompositeBean.setScoreLevel(getString(rs, "SCORG_LVL_CD"));
						//subcompositeBean.setScoreId(getString(rs, "SCRCRD_DEFN_ID"));
						subcompositeBean.setMsrNm(getString(rs, "MSR_DSPLY_NM"));
						subcompositeBean.setBslnRtPct(getString(rs, "BSLN_RT_PCT"));
						subcompositeBean.setTrgtRtPct(getString(rs, "TRGT_RT_PCT"));
						subcompositeBean.setCurntCmplncRtPct(getString(rs, "CURNT_CMPLNC_RT_PCT"));
						subcompositeBean.setRdstrbtdErncntrpct(getString(rs, "RDSTRBTD_ERNCNTR_PCT"));
						subcompositeBean.setRdstrbtdSsavUpsdDstrbnPct(getString(rs, "RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT"));
						subcompositeBean.setMsrDnmntrNbr(getString(rs, "MSR_DNMNTR_NBR"));
						subcompositeBean.setAnalysisAsOfDt(DateUtil.formatDateToMMDDYYYY("yyyy-MM-dd", "MM/dd/yyyy", rs.getDate("ANLYSS_AS_OF_DT").toString()));
						subcompositeBean.setSubcmpstDefnId(rs.getString("SUB_CMPST_DEFN_ID"));

						result.add(subcompositeBean);
					}

				}
				else {
					throw new Exception("Unable to establish the connection");
				}
			}

			if (request.getViewBy().equalsIgnoreCase("scoringLevels")) {

				if (cn != null) {
					sql = new StringBuilder();
					sql.append("SELECT DISTINCT ")
						.append("case ")
						.append("when ef.BSLN_SCRCRD_IND='Y' then 'Q0' else ef.qtr_id  end as QTR_ID, ")
						.append("ef.SCORG_LVL_CD, ")
						.append("smhd.MSR_DIM_KEY ")
						.append("FROM ")
						.append("ERNCNTR_FACT ef , ")
						.append("PGM_DIM pg , ")
						.append("PROV_GRP_DIM pgd , ")
						.append("SCRCRD_PGM_MSR_HRCHY_FACT spmhf, ")
						.append("SCRCRD_MSR_HRCHY_DIM smhd ")
						.append("WHERE ")
						.append("ef.PROV_GRP_DIM_KEY= pgd.PROV_GRP_DIM_KEY  AND ")
						.append("ef.PGM_DIM_KEY = pg.PGM_DIM_KEY   AND ")
						.append("ef.trnch_defn_dim_key = spmhf.trnch_defn_dim_key  AND ")
						.append("pg.PGM_DIM_KEY = spmhf.PGM_DIM_KEY AND ")
						.append("ef.PGM_DIM_KEY = spmhf.PGM_DIM_KEY AND ")
						.append("spmhf.MSRMNT_PRD_STRT_DT = ef.MSRMNT_PRD_STRT_DT AND ")
						.append("spmhf.SCRCRD_MSR_HRCHY_DIM_KEY = smhd.SCRCRD_MSR_HRCHY_DIM_KEY  AND ")
						.append("pgd.PROV_GRP_ID=? AND ")
						.append("pg.PGM_ID = ? AND ")
						.append("ef.MSRMNT_PRD_STRT_DT= ?  AND ")
						.append("smhd.CMPST_DEFN_ID = ? ");

					if (null != Constants.getQuarterName(request.getMeasurementInterval())) {
						if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
							sql.append(" AND ef.BSLN_SCRCRD_IND = ? ");
						}
						else {
							sql.append(" AND ef.QTR_ID = ? ");
						}
					}
					else {
						sql.append("AND ef.MNTH_ID = (SELECT MAX(EF.MNTH_ID) FROM ERNCNTR_FACT EF INNER JOIN "
							+ "(Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT FROM SCRCRD_PGM_MSR_HRCHY_FACT WHERE "
							+ "PGM_DIM_KEY=(SELECT PGM_DIM_KEY FROM PGM_DIM WHERE PGM_ID= ? ) "
							+ "  and  MSRMNT_PRD_STRT_DT = ? "
							+ " GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM "
							+ "ON EF.PGM_DIM_KEY=SC_PGM.PGM_DIM_KEY AND EF.MSRMNT_PRD_STRT_DT=SC_PGM.MSRMNT_PRD_STRT_DT)");
					}

					sql.append(" GROUP BY ef.QTR_ID, ef.BSLN_SCRCRD_IND, EF.SCORG_LVL_CD, SMHD.MSR_DIM_KEY ");
					sql = StringUtil.appendWithUr(sql);

					prepareStatement(logger, sql.toString());
					ps.setString(1, request.getProvGrpIds());
					ps.setString(2, request.getProgramId());
					ps.setString(3, request.getMeasurementPeriodStartDt());
					ps.setString(4, request.getCompositeId());

					if (null != Constants.getQuarterName(request.getMeasurementInterval())) {
						if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
							ps.setString(5, "Y");
						}
						else {
							ps.setString(5, Constants.getQuarterName(request.getMeasurementInterval()));
						}
					}
					else {
						ps.setString(5, request.getProgramId());
						ps.setString(6, request.getMeasurementPeriodStartDt());
					}

					executeQuery(logger, sql.toString());
					while (rs.next()) {
						scrngLvlCd = getString(rs, "SCORG_LVL_CD");
						msrDimKey = getString(rs, "MSR_DIM_KEY");
						qrtrId = getString(rs, "QTR_ID");
						if (scrngLvlCd.equalsIgnoreCase("G")) {
							subCmpstDefnIdWithGroup.add(msrDimKey);
						}
						if (scrngLvlCd.equalsIgnoreCase("P")) {
							subCmpstDefnIdWithPanel.add(msrDimKey);
						}
					}
					scrngLvlMap.put("G", subCmpstDefnIdWithGroup);
					scrngLvlMap.put("P", subCmpstDefnIdWithPanel);

				}

			}
			if (request.getViewBy().equalsIgnoreCase("organization")) {

				sql = new StringBuilder();
				sql.append(" SELECT DISTINCT cosf1.MSR_DNMNTR_NBR , "
					+ "cosf1.RT_PCT , cosf1.RISK_ADJSTMNT_FCTR , ef.RDSTRBTD_ERNCNTR_PCT ,  ef.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT , "
					+ "'O' as SCORG_LVL_CD , td.TRNCH_CTGRY_CD , td.TRNCH_CUT_LOW_PCT ,td.TRNCH_CUT_HIGH_PCT , "
					+ "td.TRNCH_SVNGS_PTNTL_PCT , smhd.CMPST_DEFN_ID , smhd.SUB_CMPST_DEFN_ID, "
					+ "msr.MSR_DSPLY_NM, msr.MSR_DIM_KEY , msr.MSR_ID, "
					+ "cosf1.SUB_CMPST_DNMNTR_NBR , cosf1.SUB_CMPST_RT_PCT , cosf1.RISK_ADJSTMNT_FCTR , smhd.SUB_CMPST_NM ,ef.CMPLNC_RT_PCT ,"
					+ " td.trnch_defn_dtl_dim_key, td.trnch_cut_ordr_cd , TD.TRNCH_CUT_TYPE_CD , ef.ANLYSS_AS_OF_DT,  case when EF.SSAV_UPSD_DSTRBTN_PCT > 0  then ef.ACHVD_TRNCH_LVL_CD else 'NA' end as ACHVD_TRNCH_LVL_CD,epgsf.MDCR_TIER_2_IND "
					+ " FROM "
					+ " ERNCNTR_FACT ef "
					+ " inner join SCRCRD_PGM_MSR_HRCHY_FACT spgmhf "
					+ " on ef.PGM_DIM_KEY = spgmhf.PGM_DIM_KEY "
					+ " AND ef.MSRMNT_PRD_STRT_DT = spgmhf.MSRMNT_PRD_STRT_DT"
					+ " AND ef.trnch_defn_dim_key = spgmhf.trnch_defn_dim_key ");
				sql.append(" AND ef.MNTH_ID = spgmhf.MNTH_ID ");
				sql.append(" inner join SCRCRD_MSR_HRCHY_DIM smhd "
					+ " on spgmhf.SCRCRD_MSR_HRCHY_DIM_KEY = smhd.SCRCRD_MSR_HRCHY_DIM_KEY "
					+ " inner join MSR_DIM msr on smhd.MSR_DIM_KEY = msr.MSR_DIM_KEY "
					+ " and SPGMHF.msrmnt_prd_strt_dt >= msr.MSR_EFCTV_DT and SPGMHF.msrmnt_prd_end_dt <= msr.MSR_TRMNTN_DT "
					+ " inner join PROV_GRP_DIM pg on ef.PROV_GRP_DIM_KEY = pg.PROV_GRP_DIM_KEY  "
					+ " inner join PGM_DIM pgm on ef.PGM_DIM_KEY = pgm.PGM_DIM_KEY "
					+ " inner join TRNCH_DEFN_DTL_DIM td on ef.TRNCH_DEFN_DIM_KEY = td.TRNCH_DEFN_DIM_KEY"
					// Added below conditions for dates as suggested by Data Team - Trupti
					+ " and (CASE WHEN EF.MSRMNT_PRD_END_DT < CURRENT_DATE THEN EF.MSRMNT_PRD_END_DT "
					+ " WHEN CURRENT_DATE <= EF.MSRMNT_PRD_END_DT AND CURRENT_DATE >=EF.MSRMNT_PRD_STRT_DT THEN CURRENT_DATE "
					+ " WHEN EF.MSRMNT_PRD_STRT_DT > CURRENT_DATE THEN EF.MSRMNT_PRD_STRT_DT END) >= TD.TRNCH_DEFN_DTL_DIM_EFCTV_DT "
					+ " AND "
					+ " (CASE WHEN EF.MSRMNT_PRD_END_DT < CURRENT_DATE THEN EF.MSRMNT_PRD_END_DT "
					+ " WHEN CURRENT_DATE <= EF.MSRMNT_PRD_END_DT AND CURRENT_DATE >=EF.MSRMNT_PRD_STRT_DT THEN CURRENT_DATE "
					+ " WHEN EF.MSRMNT_PRD_STRT_DT > CURRENT_DATE THEN EF.MSRMNT_PRD_STRT_DT END) <=TD.TRNCH_DEFN_DTL_DIM_TRMNTN_DT "

					+ " left outer join "
					+ " (select cosf.SUB_CMPST_DNMNTR_NBR , cosf.SUB_CMPST_RT_PCT, cosf.MSR_DNMNTR_NBR ,cosf.RT_PCT ,"
					+ " cosf.RISK_ADJSTMNT_FCTR , cosf.scrcrd_msr_hrchy_dim_key, COSF.MSRMNT_PRD_STRT_DT, cosf.MSR_DIM_KEY,cosf.ANLYSS_AS_OF_DT"
					+ " from CMPLNC_ORG_SMRY_FACT cosf"
					+ " inner join PROV_ORG_DIM po on cosf.PROV_ORG_DIM_KEY = po.PROV_ORG_DIM_KEY AND po.PROV_ORG_DIM_KEY = ?" // Result of NF31: PROV_ORG_TAX_ID changed to PROV_ORG_DIM_KEY
					+ " inner join PROV_GRP_DIM pg on cosf.PROV_GRP_DIM_KEY = pg.PROV_GRP_DIM_KEY  AND pg.PROV_GRP_ID = ?"
					+ " inner join PGM_DIM pgm on cosf.PGM_DIM_key = pgm.PGM_DIM_key AND pgm.PGM_ID= ?"
					+ " ) cosf1 "
					+ " on spgmhf.SCRCRD_MSR_HRCHY_DIM_KEY = cosf1.SCRCRD_MSR_HRCHY_DIM_KEY "
					+ " AND cosf1.MSRMNT_PRD_STRT_DT = ef.MSRMNT_PRD_STRT_DT  "
					+ " AND msr.MSR_DIM_KEY = cosf1.MSR_DIM_KEY "
					+ " AND ef.ANLYSS_AS_OF_DT = cosf1.ANLYSS_AS_OF_DT "
					+ " JOIN ERNCNTR_PROV_GRP_SMRY_FACT epgsf on  epgsf.prov_grp_dim_key = ef.prov_grp_dim_key and epgsf.pgm_dim_key = ef.pgm_dim_key "
					+ " and  epgsf.mnth_id = ef.mnth_id and   epgsf.msrmnt_prd_strt_dt = ef.msrmnt_prd_strt_dt	"
					+ " WHERE "
					+ " pg.PROV_GRP_ID = ? "
					+ " AND pgm.PGM_ID= ? "
					+ " AND ef.MSRMNT_PRD_STRT_DT = ?  "
					+ " AND smhd.CMPST_DEFN_ID = ? "
					+ " AND spgmhf.pgm_lob_type_cd = ? ");

				if (null != Constants.getQuarterName(request.getMeasurementInterval())) {
					if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
						sql.append(" AND ef.BSLN_SCRCRD_IND = ? ");
					}
					else {
						sql.append(" AND ef.QTR_ID = ? ");
					}
				}
				else {
					sql.append("AND ef.MNTH_ID = (SELECT MAX(EF.MNTH_ID) FROM ERNCNTR_FACT EF INNER JOIN "
						+ "(Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT FROM SCRCRD_PGM_MSR_HRCHY_FACT WHERE  "
						+ "PGM_DIM_KEY=(SELECT PGM_DIM_KEY FROM PGM_DIM WHERE PGM_ID= ?)"
						+ "  and  MSRMNT_PRD_STRT_DT = ? "
						+ " GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM "
						+ "ON EF.PGM_DIM_KEY=SC_PGM.PGM_DIM_KEY AND EF.MSRMNT_PRD_STRT_DT=SC_PGM.MSRMNT_PRD_STRT_DT)");
				}

				// SIP Code R1.3 added by Vishwa
				if (request.getMeasurementInterval().equalsIgnoreCase("12")) {

					sql.append("  AND TD.TRNCH_CUT_TYPE_CD =   CASE WHEN EF.QTR_ID IN ('Q1','Q2','Q3') THEN 'NONADJD' ELSE TD.TRNCH_CUT_TYPE_CD END ");

				}
				else if (request.getMeasurementInterval().equalsIgnoreCase("0")) {
					if (null != qrtrId && qrtrId.equalsIgnoreCase("Q4")) {
						sql.append("  AND TD.TRNCH_CUT_TYPE_CD =   CASE WHEN EF.QTR_ID IN ('Q1','Q2','Q3') THEN 'NONADJD' ELSE TD.TRNCH_CUT_TYPE_CD END ");
					}
					else {
						sql.append("AND TD.TRNCH_CUT_TYPE_CD = 'NONADJD' ");
					}
				}
				else {
					sql.append("AND TD.TRNCH_CUT_TYPE_CD = 'NONADJD' ");

				}

				sql.append(" Order By ef.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT DESC, msr.MSR_DSPLY_NM, TD.TRNCH_CUT_TYPE_CD ,cosf1.RT_PCT ASC, msr.MSR_DIM_KEY , td.TRNCH_CTGRY_CD ");
				sql = StringUtil.appendWithUr(sql);

				if (cn != null) {
					prepareStatement(logger, sql.toString());
					ps.setString(1, request.getOrganizationId());
					ps.setString(2, request.getProvGrpIds());
					ps.setString(3, request.getProgramId());
					ps.setString(4, request.getProvGrpIds());
					ps.setString(5, request.getProgramId());
					ps.setString(6, request.getMeasurementPeriodStartDt());
					ps.setString(7, request.getCompositeId());
					ps.setString(8, request.getProgramLobTypeCd().toUpperCase());

					if (null != Constants.getQuarterName(request.getMeasurementInterval())) {
						if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
							ps.setString(9, "Y");
						}
						else {
							ps.setString(9, Constants.getQuarterName(request.getMeasurementInterval()));
						}
					}
					else {
						ps.setString(9, request.getProgramId());
						ps.setString(10, request.getMeasurementPeriodStartDt());
					}

					executeQuery(logger, sql.toString());

					List<ScorecardSubcompositeBean> tempList = prepareSubCompositeBeanList(rs);
					result.addAll(tempList);

				}
				else {
					throw new Exception("Unable to establish the connection");
				}

			}

			if (request.getViewBy().equalsIgnoreCase("group") || null != scrngLvlMap && scrngLvlMap.keySet().size() > 0 && scrngLvlMap.keySet().contains("G")
				&& scrngLvlMap.get("G").size() > 0) {
				sql = new StringBuilder();
				sql.append(" SELECT DISTINCT "
					+ " cgsf1.MSR_DNMNTR_NBR , cgsf1.RT_PCT ,"
					+ " ef.RDSTRBTD_ERNCNTR_PCT ,  ef.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT ,"
					+ " 'G' as SCORG_LVL_CD , td.TRNCH_CTGRY_CD , td.TRNCH_CUT_LOW_PCT , td.TRNCH_CUT_HIGH_PCT ,td.TRNCH_SVNGS_PTNTL_PCT ,"
					+ " msr.MSR_DIM_KEY , msr.MSR_ID,smhd.CMPST_DEFN_ID, smhd.SUB_CMPST_DEFN_ID, "
					+ " cgsf1.SUB_CMPST_DNMNTR_NBR , cgsf1.SUB_CMPST_RT_PCT , cgsf1.RISK_ADJSTMNT_FCTR , smhd.SUB_CMPST_NM ,ef.CMPLNC_RT_PCT ,"
					+ " ef.ANLYSS_AS_OF_DT , td.trnch_defn_dtl_dim_key, td.trnch_cut_ordr_cd , TD.TRNCH_CUT_TYPE_CD , msr.MSR_DSPLY_NM,  case when EF.SSAV_UPSD_DSTRBTN_PCT > 0  then ef.ACHVD_TRNCH_LVL_CD else 'NA' end as ACHVD_TRNCH_LVL_CD,epgsf.MDCR_TIER_2_IND "
					+ " FROM ERNCNTR_FACT ef "
					+ " inner join SCRCRD_PGM_MSR_HRCHY_FACT spgmhf on ef.MSRMNT_PRD_STRT_DT = spgmhf.MSRMNT_PRD_STRT_DT "
					+ "AND ef.TRNCH_DEFN_DIM_KEY = spgmhf.TRNCH_DEFN_DIM_KEY "
					+ "AND ef.PGM_DIM_KEY = spgmhf.PGM_DIM_KEY ");
				sql.append(" AND ef.MNTH_ID = spgmhf.MNTH_ID ");
				sql.append(" inner join SCRCRD_MSR_HRCHY_DIM smhd on spgmhf.SCRCRD_MSR_HRCHY_DIM_KEY = smhd.SCRCRD_MSR_HRCHY_DIM_KEY "
					+ " inner join MSR_DIM msr on  smhd.MSR_DIM_KEY = msr.MSR_DIM_KEY "
					+ " and SPGMHF.msrmnt_prd_strt_dt >= msr.MSR_EFCTV_DT and SPGMHF.msrmnt_prd_end_dt <= msr.MSR_TRMNTN_DT "
					+ " inner join PGM_DIM pgm on ef.PGM_DIM_KEY = pgm.PGM_DIM_KEY "
					+ " inner join PROV_GRP_DIM pg on ef.PROV_GRP_DIM_KEY = pg.PROV_GRP_DIM_KEY "
					+ " inner join TRNCH_DEFN_DTL_DIM td on ef.TRNCH_DEFN_DIM_KEY = td.TRNCH_DEFN_DIM_KEY "

					// Added below condition for dates as suggested by Data team - Trupti
					+ " and (CASE WHEN EF.MSRMNT_PRD_END_DT < CURRENT_DATE THEN EF.MSRMNT_PRD_END_DT "
					+ " WHEN CURRENT_DATE <= EF.MSRMNT_PRD_END_DT AND CURRENT_DATE >=EF.MSRMNT_PRD_STRT_DT THEN CURRENT_DATE "
					+ " WHEN EF.MSRMNT_PRD_STRT_DT > CURRENT_DATE THEN EF.MSRMNT_PRD_STRT_DT END) >= TD.TRNCH_DEFN_DTL_DIM_EFCTV_DT "
					+ " AND "
					+ " (CASE WHEN EF.MSRMNT_PRD_END_DT < CURRENT_DATE THEN EF.MSRMNT_PRD_END_DT "
					+ " WHEN CURRENT_DATE <= EF.MSRMNT_PRD_END_DT AND CURRENT_DATE >=EF.MSRMNT_PRD_STRT_DT THEN CURRENT_DATE "
					+ " WHEN EF.MSRMNT_PRD_STRT_DT > CURRENT_DATE THEN EF.MSRMNT_PRD_STRT_DT END) <=TD.TRNCH_DEFN_DTL_DIM_TRMNTN_DT "
					+ " left outer join "
					+ " (select cgsf.SUB_CMPST_RT_PCT , cgsf.SUB_CMPST_DNMNTR_NBR , cgsf.MSR_DNMNTR_NBR , "
					+ " cgsf.RT_PCT , cgsf.RISK_ADJSTMNT_FCTR ,"
					+ " cgsf.ANLYSS_AS_OF_DT, cgsf.PROV_GRP_DIM_KEY, cgsf.PGM_DIM_KEY, "
					+ " cgsf.MSRMNT_PRD_STRT_DT, cgsf.MSR_DIM_KEY, cgsf.SCRCRD_MSR_HRCHY_DIM_KEY"
					+ " from CMPLNC_PROV_GRP_SMRY_FACT cgsf "
					+ " inner join PROV_GRP_DIM PG ON  (cgsf.PROV_GRP_DIM_KEY = pg.PROV_GRP_DIM_KEY) "//AND PG.PROV_GRP_ID=? "
					+ " INNER JOIN PGM_DIM PGM ON (CGSF.PGM_DIM_KEY = PGM.PGM_DIM_KEY) "// AND pgm.PGM_ID=? "
					+ " )cgsf1 ON "
					+ " ef.ANLYSS_AS_OF_DT = cgsf1.ANLYSS_AS_OF_DT AND "
					+ " cgsf1.PROV_GRP_DIM_KEY = ef.PROV_GRP_DIM_KEY AND "
					+ " cgsf1.PGM_DIM_KEY = ef.PGM_DIM_KEY AND  "
					+ " cgsf1.MSRMNT_PRD_STRT_DT = ef.MSRMNT_PRD_STRT_DT AND "
					+ " smhd.SCRCRD_MSR_HRCHY_DIM_KEY = cgsf1.SCRCRD_MSR_HRCHY_DIM_KEY AND "
					+ " smhd.MSR_DIM_KEY = cgsf1.MSR_DIM_KEY "
					+ " JOIN ERNCNTR_PROV_GRP_SMRY_FACT epgsf on  epgsf.prov_grp_dim_key = ef.prov_grp_dim_key and epgsf.pgm_dim_key = ef.pgm_dim_key "
					+ " and  epgsf.mnth_id = ef.mnth_id and   epgsf.msrmnt_prd_strt_dt = ef.msrmnt_prd_strt_dt	"
					+ "  where "
					+ " pg.PROV_GRP_ID = ? AND "
					+ "  pgm.PGM_ID= ? AND "
					+ "  ef.MSRMNT_PRD_STRT_DT =  ? AND "
					+ "  smhd.CMPST_DEFN_ID = ? "
					+ " AND spgmhf.pgm_lob_type_cd = ? ");

				if (null != scrngLvlMap && scrngLvlMap.keySet().size() > 0
					&& scrngLvlMap.keySet().contains("G") && scrngLvlMap.get("G").size() > 0) {

					sql.append("AND msr.MSR_DIM_KEY IN (");
					sql.append(StringUtil.buildPlaceholders(scrngLvlMap.get("G").size()));
					sql.append(") ");
				}

				if (null != Constants.getQuarterName(request.getMeasurementInterval())) {
					if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
						sql.append(" AND ef.BSLN_SCRCRD_IND = ? ");
					}
					else {
						sql.append(" AND ef.QTR_ID = ? ");
					}
				}
				else {
					sql.append("AND ef.MNTH_ID = (SELECT MAX(EF.MNTH_ID) FROM ERNCNTR_FACT EF INNER JOIN "
						+ "(Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT FROM SCRCRD_PGM_MSR_HRCHY_FACT WHERE  "
						+ "PGM_DIM_KEY=(SELECT PGM_DIM_KEY FROM PGM_DIM WHERE PGM_ID= ?)"
						+ "  and  MSRMNT_PRD_STRT_DT = ? "
						+ " GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM "
						+ "ON EF.PGM_DIM_KEY=SC_PGM.PGM_DIM_KEY AND EF.MSRMNT_PRD_STRT_DT=SC_PGM.MSRMNT_PRD_STRT_DT)");

				}
				// SIP Code R1.3 added by Vishwa
				if (request.getMeasurementInterval().equalsIgnoreCase("12")) {
					sql.append("  AND TD.TRNCH_CUT_TYPE_CD =   CASE WHEN EF.QTR_ID IN ('Q1','Q2','Q3') THEN 'NONADJD' ELSE TD.TRNCH_CUT_TYPE_CD END ");
				}
				else if (request.getMeasurementInterval().equalsIgnoreCase("0")) {
					if (null != qrtrId && qrtrId.equalsIgnoreCase("Q4")) {
						sql.append("  AND TD.TRNCH_CUT_TYPE_CD =   CASE WHEN EF.QTR_ID IN ('Q1','Q2','Q3') THEN 'NONADJD' ELSE TD.TRNCH_CUT_TYPE_CD END ");
					}
					else {
						sql.append("AND TD.TRNCH_CUT_TYPE_CD = 'NONADJD' ");
					}
				}
				else {
					sql.append("AND TD.TRNCH_CUT_TYPE_CD = 'NONADJD' ");
				}

				sql.append(" Order By ef.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT DESC , msr.MSR_DSPLY_NM, TD.TRNCH_CUT_TYPE_CD ,cgsf1.RT_PCT ASC, msr.MSR_DIM_KEY , td.TRNCH_CTGRY_CD ");
				sql = StringUtil.appendWithUr(sql);

				if (cn != null) {
					prepareStatement(logger, sql.toString());
					int i = 0;

					ps.setString(++i, request.getProvGrpIds());
					ps.setString(++i, request.getProgramId());
					ps.setString(++i, request.getMeasurementPeriodStartDt());
					ps.setString(++i, request.getCompositeId());
					ps.setString(++i, request.getProgramLobTypeCd().toUpperCase());

					if (null != scrngLvlMap && scrngLvlMap.keySet().size() > 0
						&& scrngLvlMap.keySet().contains("G") && scrngLvlMap.get("G").size() > 0) {

						for (String msrKey : scrngLvlMap.get("G")) {
							ps.setString(++i, msrKey);
						}
					}

					if (null != Constants.getQuarterName(request.getMeasurementInterval())) {
						if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
							ps.setString(++i, "Y");
						}
						else {
							ps.setString(++i, Constants.getQuarterName(request.getMeasurementInterval()));
						}
					}
					else {
						ps.setString(++i, request.getProgramId());
						ps.setString(++i, request.getMeasurementPeriodStartDt());
					}

					executeQuery(logger, sql.toString());

					List<ScorecardSubcompositeBean> tempList = prepareSubCompositeBeanList(rs);
					result.addAll(tempList);

				}
				else {
					throw new Exception("Unable to establish the connection");
				}
			}

			if (request.getViewBy().equalsIgnoreCase("panel") || null != scrngLvlMap && scrngLvlMap.keySet().size() > 0 && scrngLvlMap.keySet().contains("P")
				&& scrngLvlMap.get("P").size() > 0) {

				sql = new StringBuilder();
				sql.append("SELECT DISTINCT "
					+ "CMPSF1.MSR_DNMNTR_NBR,  CMPSF1.RT_PCT, EF.RDSTRBTD_ERNCNTR_PCT, "
					+ "EF.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT, 'P' as SCORG_LVL_CD, TD.TRNCH_CTGRY_CD,  TD.TRNCH_CUT_LOW_PCT,td.TRNCH_CUT_HIGH_PCT , "
					+ "TD.TRNCH_SVNGS_PTNTL_PCT, SMHD.CMPST_DEFN_ID, smhd.SUB_CMPST_DEFN_ID, MSR.MSR_DSPLY_NM,  "
					+ " CMPSF1.SUB_CMPST_DNMNTR_NBR , CMPSF1.SUB_CMPST_RT_PCT , CMPSF1.RISK_ADJSTMNT_FCTR , smhd.SUB_CMPST_NM ,ef.CMPLNC_RT_PCT ,"
					+ "MSR.MSR_DIM_KEY, MSR.MSR_ID, TD.TRNCH_DEFN_DTL_DIM_KEY, td.trnch_cut_ordr_cd , TD.TRNCH_CUT_TYPE_CD , EF.ANLYSS_AS_OF_DT, case when EF.SSAV_UPSD_DSTRBTN_PCT > 0  then ef.ACHVD_TRNCH_LVL_CD else 'NA' end as ACHVD_TRNCH_LVL_CD,epgsf.MDCR_TIER_2_IND "
					//	+ ", cmpsf1.mdpnl_id "
					+ "FROM ERNCNTR_FACT AS EF "
					+ "INNER JOIN SCRCRD_PGM_MSR_HRCHY_FACT AS SPGMHF ON "
					+ "EF.TRNCH_DEFN_DIM_KEY = SPGMHF.TRNCH_DEFN_DIM_KEY "
					+ "AND EF.PGM_DIM_KEY = SPGMHF.PGM_DIM_KEY "
					+ "AND EF.MSRMNT_PRD_STRT_DT = SPGMHF.MSRMNT_PRD_STRT_DT ");
				sql.append(" AND ef.MNTH_ID = spgmhf.MNTH_ID ");
				sql.append("INNER JOIN SCRCRD_MSR_HRCHY_DIM AS SMHD ON SPGMHF.SCRCRD_MSR_HRCHY_DIM_KEY = SMHD.SCRCRD_MSR_HRCHY_DIM_KEY "
					+ "INNER JOIN MSR_DIM AS MSR ON SMHD.MSR_DIM_KEY = MSR.MSR_DIM_KEY  "
					+ " and SPGMHF.msrmnt_prd_strt_dt >= MSR.MSR_EFCTV_DT and SPGMHF.msrmnt_prd_end_dt <= MSR.MSR_TRMNTN_DT "
					+ "INNER JOIN PGM_DIM AS PGM ON EF.PGM_DIM_KEY = PGM.PGM_DIM_KEY  "
					+ "INNER JOIN TRNCH_DEFN_DTL_DIM AS TD ON EF.TRNCH_DEFN_DIM_KEY = TD.TRNCH_DEFN_DIM_KEY "

					// Added below for dates as suggested by Data team - Trupti
					+ " and (CASE WHEN EF.MSRMNT_PRD_END_DT < CURRENT_DATE THEN EF.MSRMNT_PRD_END_DT "
					+ " WHEN CURRENT_DATE <= EF.MSRMNT_PRD_END_DT AND CURRENT_DATE >=EF.MSRMNT_PRD_STRT_DT THEN CURRENT_DATE "
					+ " WHEN EF.MSRMNT_PRD_STRT_DT > CURRENT_DATE THEN EF.MSRMNT_PRD_STRT_DT END) >= TD.TRNCH_DEFN_DTL_DIM_EFCTV_DT "
					+ " AND "
					+ " (CASE WHEN EF.MSRMNT_PRD_END_DT < CURRENT_DATE THEN EF.MSRMNT_PRD_END_DT "
					+ " WHEN CURRENT_DATE <= EF.MSRMNT_PRD_END_DT AND CURRENT_DATE >=EF.MSRMNT_PRD_STRT_DT THEN CURRENT_DATE "
					+ " WHEN EF.MSRMNT_PRD_STRT_DT > CURRENT_DATE THEN EF.MSRMNT_PRD_STRT_DT END) <=TD.TRNCH_DEFN_DTL_DIM_TRMNTN_DT "

					+ "INNER JOIN PROV_GRP_DIM AS PG ON EF.PROV_GRP_DIM_KEY = PG.PROV_GRP_DIM_KEY  "
					+ "LEFT OUTER JOIN  CMPLNC_MDPNL_SMRY_FACT AS CMPSF1 ON "
					// commented below snippet as suggested by data team(Amit SHarma) for R1.8 MDPNL_DIM_KEY US
					/*	+ " SELECT CMPSF.SUB_CMPST_RT_PCT, CMPSF.SUB_CMPST_DNMNTR_NBR, "
						+ "CMPSF.MSR_DNMNTR_NBR, CMPSF.RT_PCT, CMPSF.RISK_ADJSTMNT_FCTR, "
						+ "CMPSF.PGM_DIM_KEY, CMPSF.MSRMNT_PRD_STRT_DT AS CMPSF_MSRMNT_PRD_STRT_DT, "
						+ "CMPSF.SCRCRD_MSR_HRCHY_DIM_KEY AS CMPSF_SCRCRD_MSR_HRCHY_DIM_KEY, "
						+ "CMPSF.ANLYSS_AS_OF_DT AS CMPSF_AOD, PGPAF.PROV_GRP_DIM_KEY ,md.mdpnl_id "
						+ " FROM "
						+ "   CMPLNC_MDPNL_SMRY_FACT AS CMPSF "
					+ "INNER JOIN PGM_DIM AS PGM ON CMPSF.PGM_DIM_KEY = PGM.PGM_DIM_KEY "//AND PGM.PGM_ID = ? "
					+ "INNER JOIN PROV_GRP_PNL_ASSN_FACT PGPAF ON CMPSF.MDPNL_DIM_KEY = PGPAF.MDPNL_DIM_KEY "
					+ "INNER JOIN mdpnl_dim md on md.mdpnl_dim_key = pgpaf.mdpnl_dim_key "
					+ "INNER JOIN PROV_GRP_DIM AS PG ON PGPAF.PROV_GRP_DIM_KEY = PG.PROV_GRP_DIM_KEY "  
					+ " and  md.mdpnl_id = ? )  "
					+ "AS CMPSF1 ON  "*/
					+ " SPGMHF.PGM_DIM_KEY = CMPSF1.PGM_DIM_KEY "
					//	+ "AND CMPSF1.PROV_GRP_DIM_KEY = EF.PROV_GRP_DIM_KEY "
					+ "AND SPGMHF.MSRMNT_PRD_STRT_DT = CMPSF1.MSRMNT_PRD_STRT_DT "
					+ "AND SPGMHF.SCRCRD_MSR_HRCHY_DIM_KEY = CMPSF1.SCRCRD_MSR_HRCHY_DIM_KEY "
					+ "AND EF.ANLYSS_AS_OF_DT = CMPSF1.ANLYSS_AS_OF_DT "
					+ " AND ef.mdpnl_dim_key=cmpsf1.mdpnl_dim_key "
					+ " JOIN ERNCNTR_PROV_GRP_SMRY_FACT epgsf on  epgsf.prov_grp_dim_key = ef.prov_grp_dim_key and epgsf.pgm_dim_key = ef.pgm_dim_key "
					+ " and  epgsf.mnth_id = ef.mnth_id and   epgsf.msrmnt_prd_strt_dt = ef.msrmnt_prd_strt_dt	"
					+ " WHERE  "
					+ "PG.PROV_GRP_ID = ? "
					+ " AND PGM.PGM_ID = ? "
					+ " AND EF.MSRMNT_PRD_STRT_DT = ?  "
					//+ " and  cmpsf1.mdpnl_id = ? "
					+ " AND SMHD.CMPST_DEFN_ID = ? "
					+ " AND spgmhf.pgm_lob_type_cd = ? ");

				if (null != scrngLvlMap && scrngLvlMap.keySet().size() > 0
					&& scrngLvlMap.keySet().contains("P") && scrngLvlMap.get("P").size() > 0) {

					sql.append("AND msr.MSR_DIM_KEY IN (");
					sql.append(StringUtil.buildPlaceholders(scrngLvlMap.get("P").size()));
					sql.append(") ");
				}

				if (null != Constants.getQuarterName(request.getMeasurementInterval())) {
					if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
						sql.append(" AND ef.BSLN_SCRCRD_IND = ? ");
					}
					else {
						sql.append(" AND ef.QTR_ID = ? ");
					}
				}
				else {
					sql.append("AND ef.MNTH_ID = (SELECT MAX(EF.MNTH_ID) FROM ERNCNTR_FACT EF INNER JOIN "
						+ "(Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT FROM SCRCRD_PGM_MSR_HRCHY_FACT WHERE  "
						+ "PGM_DIM_KEY=(SELECT PGM_DIM_KEY FROM PGM_DIM WHERE PGM_ID= ?)"
						+ "  and  MSRMNT_PRD_STRT_DT = ? "
						+ " GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM "
						+ "ON EF.PGM_DIM_KEY=SC_PGM.PGM_DIM_KEY AND EF.MSRMNT_PRD_STRT_DT=SC_PGM.MSRMNT_PRD_STRT_DT)");

				}

				if (request.getMeasurementInterval().equalsIgnoreCase("12")) {
					sql.append("  AND TD.TRNCH_CUT_TYPE_CD =   CASE WHEN EF.QTR_ID IN ('Q1','Q2','Q3') THEN 'NONADJD' ELSE TD.TRNCH_CUT_TYPE_CD END ");
				}
				else if (request.getMeasurementInterval().equalsIgnoreCase("0")) {
					if (null != qrtrId && qrtrId.equalsIgnoreCase("Q4")) {
						sql.append("  AND TD.TRNCH_CUT_TYPE_CD =   CASE WHEN EF.QTR_ID IN ('Q1','Q2','Q3') THEN 'NONADJD' ELSE TD.TRNCH_CUT_TYPE_CD END ");
					}
					else {
						sql.append("AND TD.TRNCH_CUT_TYPE_CD = 'NONADJD' ");
					}
				}
				else {
					sql.append("AND TD.TRNCH_CUT_TYPE_CD = 'NONADJD' ");
				}

				sql.append(" Order By ef.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT DESC, msr.MSR_DSPLY_NM, TD.TRNCH_CUT_TYPE_CD, CMPSF1.RT_PCT ASC, msr.MSR_DIM_KEY, td.TRNCH_CTGRY_CD ");
				sql = StringUtil.appendWithUr(sql);

				if (cn != null) {
					int i = 0;
					prepareStatement(logger, sql.toString());
					//	ps.setString(++i, request.getMedicalPanelId());
					ps.setString(++i, request.getProvGrpIds());
					ps.setString(++i, request.getProgramId());
					ps.setString(++i, request.getMeasurementPeriodStartDt());
					ps.setString(++i, request.getCompositeId());
					ps.setString(++i, request.getProgramLobTypeCd().toUpperCase());

					if (null != scrngLvlMap && scrngLvlMap.keySet().size() > 0
						&& scrngLvlMap.keySet().contains("P") && scrngLvlMap.get("P").size() > 0) {

						for (String msrKey : scrngLvlMap.get("P")) {
							ps.setString(++i, msrKey);
						}
					}

					if (null != Constants.getQuarterName(request.getMeasurementInterval())) {
						if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
							ps.setString(++i, "Y");
						}
						else {
							ps.setString(++i, Constants.getQuarterName(request.getMeasurementInterval()));
						}
					}
					else {
						ps.setString(++i, request.getProgramId());
						ps.setString(++i, request.getMeasurementPeriodStartDt());
					}

					executeQuery(logger, sql.toString());

					List<ScorecardSubcompositeBean> tempList = prepareSubCompositeBeanList(rs);
					result.addAll(tempList);

				}
				else {
					throw new Exception("Unable to establish the connection");
				}
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get Scorecard By Subcomposite details (" + request.getEntitlementId() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}

	private List<ScorecardSubcompositeBean> prepareSubCompositeBeanList(ResultSet rs) throws SQLException, Exception {
		List<ScorecardSubcompositeBean> subCompositeList = new ArrayList<ScorecardSubcompositeBean>();
		ScorecardSubcompositeBean subcompositeBean = null;
		while (rs.next()) {
			subcompositeBean = new ScorecardSubcompositeBean();
			subcompositeBean.setCompositeId(rs.getString("CMPST_DEFN_ID"));
			subcompositeBean.setMsrDsplyNm(rs.getString("MSR_DSPLY_NM"));
			subcompositeBean.setMsrDimKey(rs.getString("MSR_DIM_KEY"));
			subcompositeBean.setMsrId(rs.getString("MSR_ID"));
			subcompositeBean.setSubcmpstDefnId(rs.getString("SUB_CMPST_DEFN_ID"));
			subcompositeBean.setSubCmpstNm(rs.getString("SUB_CMPST_NM"));
			subcompositeBean.setScoreLevel(rs.getString("SCORG_LVL_CD"));
			subcompositeBean.setRdstrbtdErncntrpct(rs.getString("RDSTRBTD_ERNCNTR_PCT"));
			subcompositeBean.setRdstrbtdSsavUpsdDstrbnPct(rs.getString("RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT"));
			subcompositeBean.setTrnchCtgryCd(rs.getString("TRNCH_CTGRY_CD"));
			subcompositeBean.setTrnchCutLowPct(rs.getString("TRNCH_CUT_LOW_PCT"));
			subcompositeBean.setTrnchCutHighPct(rs.getString("TRNCH_CUT_HIGH_PCT"));
			subcompositeBean.setTrnchSvngsPtntlPct(rs.getString("TRNCH_SVNGS_PTNTL_PCT"));
			//subcompositeBean.setTrnchSvngsPtntlPct(rs.getBigDecimal("TRNCH_SVNGS_PTNTL_PCT"));
			//subcompositeBean.setMsrNmrtrNbr(getString(rs, "MSR_NRMTR_NBR"));
			subcompositeBean.setMsrDnmntrNbr(rs.getString("MSR_DNMNTR_NBR"));
			subcompositeBean.setRtPct(rs.getString("RT_PCT"));
			subcompositeBean.setAnalysisAsOfDt(DateUtil.formatDateToMMDDYYYY("yyyy-MM-dd", "MM/dd/yyyy", rs.getDate("ANLYSS_AS_OF_DT").toString()));
			subcompositeBean.setRiskAdjFactor(rs.getString("RISK_ADJSTMNT_FCTR"));
			//subcompositeBean.setMrktRtPct(getString(rs, "MRKT_RT_PCT"));
			subcompositeBean.setTrnchOrderCd(rs.getString("TRNCH_CUT_ORDR_CD"));
			//PCMSP-11254
			subcompositeBean.setAchvdTrnchLvlCd(rs.getString("ACHVD_TRNCH_LVL_CD"));
			subcompositeBean.setTier2Ind(rs.getString("MDCR_TIER_2_IND"));
			
			subCompositeList.add(subcompositeBean);
		}
		return subCompositeList;
	}

	@Override
	public boolean read(Dto o) throws Exception {

		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {


	}

	@Override
	public void update(Dto o) throws Exception {


	}

	@Override
	public void delete(Dto o) throws Exception {


	}
}
