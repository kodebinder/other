package com.wellpoint.pc2dash.action.globalFilters;

import java.util.List;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.dto.patient.EntityFilter;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.service.globalFilters.EntityFilterDataFetchService;
import com.wellpoint.pc2dash.util.ErrorProperties;

public class GetEntityAction extends Action {

	private ActionResponse response = new GetEntityResponse();
	private MetaData metadata = new MetaData();

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		List<EntityFilter> resultList;
		String applicableMarket;
		GetEntityRequest request = (GetEntityRequest) actionRequest;
		EntityFilterDataFetchService service = new EntityFilterDataFetchService();
		ErrorProperties err = ErrorProperties.getInstance();


		try {
			buildProvGrpIdList(request);
			resultList = service.getData(request);
			applicableMarket = service.getMarketList();

			response.setData(resultList);
			response.setSuccess(true);
			if (resultList.isEmpty()) {
				response.setMessage(err.getProperty("successNoData"));
			}
			else {
				response.setMessage(err.getProperty("successful"));
			}
			
			generateMetaData(request,applicableMarket);
			response.setMetaData(metadata);
			return response;
		}
		catch (Exception pe) {
			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}

	private void generateMetaData(GetEntityRequest request, String applicableMarket) {
		boolean displayEntityFilter = Boolean.FALSE;

		String[] ProvGrpIdArray = request.getProvGrpIds().split(",");

		if (null != request.getProvGrpIds() && null != applicableMarket) {
			for (String prg : ProvGrpIdArray) {
				if (applicableMarket.contains(prg.substring(0, 2))) {
					displayEntityFilter = Boolean.TRUE;
					break;
				}
			}
		}

		metadata.setDisplayIndicator(displayEntityFilter);

	}

}
