package com.wellpoint.pc2dash.action.careOpportunities;

import com.wellpoint.pc2dash.data.dto.PopulationManagementRequest;

public class GetCareOpportunitiesRateRequest extends PopulationManagementRequest {
	private String careOppsRatesData;

	public String getCareOppsRatesData() {
		return careOppsRatesData;
	}


	public void setCareOppsRatesData(String careOppsRatesData) {
		this.careOppsRatesData = careOppsRatesData;
	}

}
