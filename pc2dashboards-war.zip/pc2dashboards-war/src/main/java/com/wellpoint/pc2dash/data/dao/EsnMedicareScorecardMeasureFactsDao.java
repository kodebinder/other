package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;
import com.wellpoint.pc2dash.dto.scorecard.ScorecardMeasureBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;

public class EsnMedicareScorecardMeasureFactsDao extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(EsnMedicareScorecardMeasureFactsDao.class);

	public boolean read(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void insert(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void update(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void delete(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public Collection<ScorecardMeasureBean> getEsnMedicareScorecardMeasuresQuery(PerformanceManagementRequest request) throws Exception {

		Collection<ScorecardMeasureBean> resultList = new ArrayList<ScorecardMeasureBean>();
		ScorecardMeasureBean measureBean = null;

		StringBuilder query = new StringBuilder()
			.append("  select "
				+ "smhd.CMPST_DEFN_ID, "
				+ "smhd.CMPST_NM, "
				+ " smhd.SUB_CMPST_DEFN_ID,"
				+ " smhd.SUB_CMPST_NM,"
				+ "   msr.MSR_DSPLY_NM, "
				+ "   msr.MSR_DIM_KEY ,"
				+ "  cosf1.MSR_NMRTR_NBR AS COSF_MSR_NMRTR_NBR,"
				+ "  cosf1.MSR_DNMNTR_NBR AS COSF_MSR_DNMNTR_NBR, "
				+ "  cpgsf1.MSR_NMRTR_NBR AS CPGSF_MSR_NMRTR_NBR, "
				+ "  cpgsf1.MSR_DNMNTR_NBR AS CPGSF_MSR_DNMNTR_NBR,"
				+ "   spgmhf.MRKT_RT_PCT, spgmhf.CMS_4_STR_RT_PCT, spgmhf.CMS_5_STR_RT_PCT, EF.QLTY_GATE_IND, sesf.PCV_BSLN_PCT as pcvPriorYrRate, "
				+ "	  EF.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT, "
				+ " smhd.CMPST_TYPE_DESC, "
				+ "	cpgsf1.rt_pct as CPGSF_RT_PCT, cosf1.rt_pct as COSF_RT_PCT "
				+ " , sesf.MIN_DNMNTR_FLAG_CD AS MIN_DNMNTR_FLAG_CD, sesf.FNL_MSR_SCOR_NBR as finalRate, "
				+ "  sesf.MBR_CNT AS MBR_CNT, sesf.OE_RATIO_NBR AS OE_RATIO_NBR, EF.TRNCH_LVL_DNMNTR_NBR , EF.TRNCH_LVL_NMRTR_NBR "
				+ " from "
				+ " SCRCRD_PGM_MSR_HRCHY_FACT spgmhf "
				+ " INNER JOIN  ERNCNTR_FACT ef"
				+ " 			on  ef.mnth_id = spgmhf.mnth_id "
				+ " AND EF.PGM_DIM_KEY = SPGMHF.PGM_DIM_KEY "
				+ "  AND EF.MSRMNT_PRD_STRT_DT = SPGMHF.MSRMNT_PRD_STRT_DT "
				+ "  AND EF.TRNCH_DEFN_DIM_KEY = SPGMHF.TRNCH_DEFN_DIM_KEY "
				+ "      INNER JOIN SCRCRD_MSR_HRCHY_DIM smhd "
				+ "            on spgmhf.SCRCRD_MSR_HRCHY_DIM_KEY = smhd.SCRCRD_MSR_HRCHY_DIM_KEY "
				+ "      INNER JOIN MSR_DIM  msr "
				+ "            on smhd.msr_dim_key = msr.msr_dim_key"
				+ " and SPGMHF.msrmnt_prd_strt_dt >= msr.MSR_EFCTV_DT and SPGMHF.msrmnt_prd_end_dt <= msr.MSR_TRMNTN_DT"
				+ "      INNER JOIN PGM_DIM pgm "
				+ "      on spgmhf.PGM_DIM_key = pgm.PGM_DIM_KEY"
				+ " inner join PROV_GRP_DIM as PGD on ef.prov_grp_dim_key=pgd.prov_grp_dim_key "
				
				+ " inner join   SCRCRD_ESN_SCOR_FACT  sesf on pgm.PGM_DIM_KEY = sesf.PGM_DIM_KEY and "           
				+ " spgmhf.MSRMNT_PRD_STRT_DT = sesf.MSRMNT_PRD_STRT_DT and  spgmhf.SCRCRD_MSR_HRCHY_DIM_KEY = sesf.SCRCRD_MSR_HRCHY_DIM_KEY "
				+ " and  EF.TRNCH_DEFN_DIM_KEY = sesf.TRNCH_DEFN_DIM_KEY and EF.prov_grp_dim_key = sesf.prov_grp_dim_key and ef.mnth_id = sesf.mnth_id "

				+ "    LEFT OUTER JOIN "
				+ "      (select cosf.PGM_DIM_key,cosf.MSRMNT_PRD_STRT_DT,cosf.SCRCRD_MSR_HRCHY_DIM_KEY,"
				+ "      cosf.MSR_NMRTR_NBR,cosf.MSR_DNMNTR_NBR,cosf.RISK_ADJSTMNT_FCTR, POD.PROV_ORG_DIM_KEY, pgd.PROV_GRP_DIM_KEY,cosf.rt_pct"
				+ "            FROM CMPLNC_ORG_SMRY_FACT cosf  "
				+ "            inner join PROV_ORG_DIM  pod"
				+ "           on cosf.PROV_ORG_DIM_KEY = pod.PROV_ORG_DIM_KEY "
				+ "                  and pod.PROV_ORG_DIM_KEY = ? "
				+ "            inner join PROV_GRP_DIM pgd "
				+ "            on cosf.PROV_GRP_DIM_KEY = pgd.PROV_GRP_DIM_KEY "
				+ "                  and pgd.PROV_GRP_ID = ? and cosf.ANLYSS_AS_OF_DT= ?) cosf1 "
				+ "      on (spgmhf.PGM_DIM_key = cosf1.PGM_DIM_key "
				+ "      and spgmhf.MSRMNT_PRD_STRT_DT = cosf1.MSRMNT_PRD_STRT_DT  "
				+ "      and spgmhf.SCRCRD_MSR_HRCHY_DIM_KEY = cosf1.SCRCRD_MSR_HRCHY_DIM_KEY ) "

				+ "    LEFT OUTER JOIN "
				+ "      (select cpgsf.MSR_NMRTR_NBR, cpgsf.MSR_DNMNTR_NBR, cpgsf.RISK_ADJSTMNT_FCTR, cpgsf.MDPNL_DIM_KEY, "
				+ "            cpgsf.SCRCRD_MSR_HRCHY_DIM_KEY,pgd.PROV_GRP_DIM_KEY, cpgsf.PGM_DIM_key, cpgsf.MSRMNT_PRD_STRT_DT,cpgsf.rt_pct "
				+ "            FROM CMPLNC_PROV_GRP_SMRY_FACT  cpgsf "
				+ "            inner join PROV_GRP_DIM pgd "
				+ "            on cpgsf.PROV_GRP_DIM_KEY = pgd.PROV_GRP_DIM_KEY "
				+ "                  and pgd.PROV_GRP_ID = ? and cpgsf.ANLYSS_AS_OF_DT= ? ) cpgsf1 "
				+ "            on (spgmhf.PGM_DIM_key = cpgsf1.PGM_DIM_key "
				+ "            and spgmhf.MSRMNT_PRD_STRT_DT = cpgsf1.MSRMNT_PRD_STRT_DT "
				+ "            and spgmhf.SCRCRD_MSR_HRCHY_DIM_KEY = cpgsf1.SCRCRD_MSR_HRCHY_DIM_KEY ) "

				+ " where "
				+ "      pgm.PGM_ID = ? "
				+ "      and smhd.CMPST_DEFN_ID = ? "
				+ "      and spgmhf.MSRMNT_PRD_STRT_DT = ? "
				+ "      and spgmhf.PGM_LOB_TYPE_CD = ? "
				+ "  	and pgd.prov_grp_id = ? ");

		if (null != request.getSubCompositeId() && !request.getSubCompositeId().equalsIgnoreCase("null")) {
			query.append(" AND smhd.SUB_CMPST_DEFN_ID = ?");
		}
		if (null != Constants
			.getQuarterName(request.getMeasurementInterval())) {
			if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
				query.append(" AND ef.BSLN_SCRCRD_IND = ? ");
			}
			else {
				query.append(" AND ef.QTR_ID = ? ");
			}
		}
		else {
			query.append(" AND EF.MNTH_ID = (SELECT MAX(EF.MNTH_ID) ");
			query.append("                   FROM ERNCNTR_FACT EF  ");
			query.append("                   INNER JOIN ");
			query.append("                   (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT ");
			query.append("                    FROM SCRCRD_PGM_MSR_HRCHY_FACT ");
			query.append("                    WHERE PGM_DIM_KEY = (SELECT PGM_DIM_KEY FROM PGM_DIM WHERE PGM_ID = ? ) and MSRMNT_PRD_STRT_DT=? ");
			query.append("                    GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM ");
			query.append("                    ON EF.PGM_DIM_KEY = SC_PGM.PGM_DIM_KEY AND EF.MSRMNT_PRD_STRT_DT = SC_PGM.MSRMNT_PRD_STRT_DT) ");

		}
		
		if(Constants.ORGANIZATION.equals(request.getViewBy())){
			query.append(" ORDER BY coalesce(cosf1.MSR_DNMNTR_NBR,0) DESC, coalesce(cosf1.MSR_NMRTR_NBR,0 ) DESC, ")
				 .append(" coalesce(cpgsf1.MSR_DNMNTR_NBR,0) DESC, coalesce(cpgsf1.MSR_NMRTR_NBR,0) DESC, msr.MSR_DSPLY_NM ");
		}else{
			query.append(" ORDER BY  coalesce(cpgsf1.MSR_DNMNTR_NBR,0) DESC, coalesce(cpgsf1.MSR_NMRTR_NBR,0) DESC, msr.MSR_DSPLY_NM ");
		}
		query = StringUtil.appendWithUr(query);

		try {
			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			prepareStatement(logger, query.toString());

			ps.setString(1, request.getOrganizationId());
			ps.setString(2, request.getProvGrpIds());
			
			if (StringUtil.isNotBlankOrFalse(request.getDest()) && request.getDest().equalsIgnoreCase("Json")) {
				ps.setString(3, request.getAnalysisAsOfDt());
			}
			else {
				ps.setString(3, request.getEsnAnalysisAsOfDt());
			}

			ps.setString(4, request.getProvGrpIds());
			
			if (StringUtil.isNotBlankOrFalse(request.getDest()) && request.getDest().equalsIgnoreCase("Json")) {
				ps.setString(5, request.getAnalysisAsOfDt());
			}
			else {
				ps.setString(5, request.getEsnAnalysisAsOfDt());
			}
			ps.setString(6, request.getProgramId());
			ps.setString(7, request.getCompositeId());
			ps.setString(8, request.getMeasurementPeriodStartDt());
			ps.setString(9, request.getProgramLobTypeCd().toUpperCase());
			ps.setString(10, request.getProvGrpIds());

			int i = 11;
			if (null != request.getSubCompositeId() && !request.getSubCompositeId().equalsIgnoreCase("null")) {
				ps.setString(i++, request.getSubCompositeId());
			}

			if (null != Constants.getQuarterName(request
				.getMeasurementInterval())) {
				if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
					ps.setString(i++, "Y");
				}
				else {
					ps.setString(i++, Constants.getQuarterName(request
						.getMeasurementInterval()));
				}
			}
			else {
				ps.setString(i++, request.getProgramId());
				ps.setString(i++, request.getMeasurementPeriodStartDt());
			}

			executeQuery(logger, query.toString());
			while (rs.next()) {
				measureBean = new ScorecardMeasureBean();
				if (rs.getString("CMPST_TYPE_DESC") != null) {
					measureBean.setCompTypeDesc(rs.getString("CMPST_TYPE_DESC"));
				}
				if (rs.getString("CMPST_DEFN_ID") != null) {
					measureBean.setCmpstDefnId(rs.getString("CMPST_DEFN_ID"));
				}
				if (rs.getString("CMPST_NM") != null) {
					measureBean.setCmpstNm(rs.getString("CMPST_NM"));
				}
				if (rs.getString("SUB_CMPST_DEFN_ID") != null) {
					measureBean.setSubCmpstDefnId(rs.getString("SUB_CMPST_DEFN_ID"));
				}
				if (rs.getString("SUB_CMPST_NM") != null) {
					measureBean.setSubCmpstNm(rs.getString("SUB_CMPST_NM"));
				}
				if (rs.getString("MSR_DIM_KEY") != null) {
					measureBean.setMsrId(rs.getString("MSR_DIM_KEY"));
				}
				if (rs.getString("MSR_DSPLY_NM") != null) {
					measureBean.setMsrDsplyNm(rs.getString("MSR_DSPLY_NM"));
				}

				//Setting values for Organization Level
				if (rs.getString("COSF_MSR_NMRTR_NBR") != null) {
					measureBean.getScorecardMeasureOrgLvl().setMsrNmrtrNbr(Integer.valueOf(rs.getInt("COSF_MSR_NMRTR_NBR")));
				}
				if (rs.getString("COSF_MSR_DNMNTR_NBR") != null) {
					measureBean.getScorecardMeasureOrgLvl().setMsrDnmntrNbr(Integer.valueOf(rs.getInt("COSF_MSR_DNMNTR_NBR")));
				}
				if (rs.getString("COSF_RT_PCT") != null)
					measureBean.getScorecardMeasureOrgLvl().setRtPct(rs.getString("COSF_RT_PCT"));

				//Setting values for Group Level
				if (rs.getString("CPGSF_MSR_NMRTR_NBR") != null) {
					measureBean.getScorecardMeasureGrpLvl().setMsrNmrtrNbr(Integer.valueOf(rs.getString("CPGSF_MSR_NMRTR_NBR")));
				}
				if (rs.getString("CPGSF_MSR_DNMNTR_NBR") != null) {
					measureBean.getScorecardMeasureGrpLvl().setMsrDnmntrNbr(Integer.valueOf(rs.getString("CPGSF_MSR_DNMNTR_NBR")));
				}
				if (rs.getString("CPGSF_RT_PCT") != null) {
					measureBean.getScorecardMeasureGrpLvl().setRtPct(rs.getString("CPGSF_RT_PCT"));
				}
				if (rs.getBigDecimal("MRKT_RT_PCT") != null) {
					measureBean.setMrktRtPct(rs.getBigDecimal("MRKT_RT_PCT"));
				}
				if (rs.getBigDecimal("RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT") != null) {
					measureBean.setWeight(rs.getBigDecimal("RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT"));
				}
				if (rs.getBigDecimal("CMS_4_STR_RT_PCT") != null) {
					measureBean.setCms4starRate(rs.getBigDecimal("CMS_4_STR_RT_PCT"));
				}
				if (rs.getBigDecimal("CMS_5_STR_RT_PCT") != null) {
					measureBean.setCms5starRate(rs.getBigDecimal("CMS_5_STR_RT_PCT"));
				}
				if (rs.getBigDecimal("pcvPriorYrRate") != null) {
					measureBean.setPcvPriorYrRate(rs.getBigDecimal("pcvPriorYrRate"));
				}
				if (rs.getString("QLTY_GATE_IND") != null) {
					measureBean.setQualityGateInd(rs.getString("QLTY_GATE_IND"));
				}
				
				if (rs.getString("MIN_DNMNTR_FLAG_CD") != null) {
					measureBean.setMinDenFlagCd(rs.getString("MIN_DNMNTR_FLAG_CD"));
				}
				
				if(rs.getString("MBR_CNT") != null) {
					measureBean.setMemberCount(Integer.valueOf(rs.getString("MBR_CNT")));
				}
				
				if (rs.getBigDecimal("OE_RATIO_NBR") != null) {
					measureBean.setOeRatioNbr(rs.getBigDecimal("OE_RATIO_NBR"));
				}
				if(rs.getString("TRNCH_LVL_DNMNTR_NBR") != null) {
					measureBean.setTotalDenominator(Integer.valueOf(rs.getString("TRNCH_LVL_DNMNTR_NBR")));
				}
				if(rs.getString("TRNCH_LVL_NMRTR_NBR") != null) {
					measureBean.setTotalNumerator(Integer.valueOf(rs.getString("TRNCH_LVL_NMRTR_NBR")));
				}
				if (rs.getBigDecimal("finalRate") != null) {
					measureBean.setFinalRate(rs.getBigDecimal("finalRate"));
				}
				
				resultList.add(measureBean);
			}
		}
		catch (Exception e) {
			logger.error("Exception during getEsnMedicareScorecardMeasuresQuery", e);
		}
		finally {
			close();
		}

		return resultList;
	}
}