package com.wellpoint.pc2dash.action.patients;

import com.wellpoint.pc2dash.data.dto.PCMSRequest;
import com.wellpoint.pc2dash.util.StringUtil;


public class GetPatientLinkRequest extends PCMSRequest {

	private String firstName;
	private String lastName;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public boolean isValid() {

		if (!StringUtil.isNotBlankOrFalse(this.memberKey))
			return false;

		return true;
	}
}
