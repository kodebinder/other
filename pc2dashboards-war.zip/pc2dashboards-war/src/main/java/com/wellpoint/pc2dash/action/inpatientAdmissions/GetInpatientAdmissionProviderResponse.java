package com.wellpoint.pc2dash.action.inpatientAdmissions;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetInpatientAdmissionProviderResponse extends ActionResponse {

}
