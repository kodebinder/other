package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.action.tooltip.GetPatientDetailRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.erVisits.ErVisitRowExp;
import com.wellpoint.pc2dash.dto.erVisits.SecondaryDiagnosis;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;

public class AvoidableErVisitsFact extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(VisitFacts.class);

	public boolean read(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void insert(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void update(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void delete(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}


	public Collection<ErVisitRowExp> getAvoidableErVisits(GetPatientDetailRequest request) throws Exception {

		Collection<ErVisitRowExp> result = new ArrayList<ErVisitRowExp>();

		StringBuilder sql = new StringBuilder()
			.append("select ")
			.append("	vf.vst_strt_dt, ")
			.append("	vf.vst_end_dt, ")
			.append("	vf.day_long_nm, ")
			.append("	vf.fclty_nm, ")
			//.append("	vf.alwd_amt, ")
			.append("	case ")
			.append("		when diag_1.cd_val_nm = '***' then '*** - ***' ")
			.append("		when DIAG_1.CD_SET_NM like '%ICD10' then coalesce(rtrim(diag_1.cd_val_txt) || ' - ' || diag_1.cd_val_long_desc, '---') ") //added ICD10 AP41
			.append("		else coalesce(rtrim(diag_1.cd_val_txt) || ' - ' || diag_1.cd_val_nm, '---') ")
			.append("	end as prncpl_diag_nm, ")
			.append("	case ")
			.append("		when diag_2.cd_val_nm = '***' then '*** - ***' ")
			.append("		when diag_2.CD_SET_NM like '%ICD10' then coalesce(rtrim(diag_2.cd_val_txt) || ' - ' || diag_2.cd_val_long_desc, '*') ") //added ICD10 AP41
			.append("		else coalesce(rtrim(diag_2.cd_val_txt) || ' - ' || diag_2.cd_val_nm, '*') ")
			.append("	end as other_diag_1_nm, ")
			.append("	case ")
			.append("		when diag_3.cd_val_nm = '***' then '*** - ***' ")
			.append("		when diag_3.CD_SET_NM like '%ICD10' then coalesce(rtrim(diag_3.cd_val_txt) || ' - ' || diag_3.cd_val_long_desc, '*') ") //added ICD10 AP41
			.append("		else coalesce(rtrim(diag_3.cd_val_txt) || ' - ' || diag_3.cd_val_nm, '*') ")
			.append("	end as other_diag_2_nm, ")
			.append("	case ")
			.append("		when diag_4.cd_val_nm = '***' then '*** - ***' ")
			.append("		when diag_4.CD_SET_NM like '%ICD10' then coalesce(rtrim(diag_4.cd_val_txt) || ' - ' || diag_4.cd_val_long_desc, '*') ") //added ICD10 AP41
			.append("		else coalesce(rtrim(diag_4.cd_val_txt) || ' - ' || diag_4.cd_val_nm, '*') ")
			.append("	end as other_diag_3_nm ")
			.append("from ")
			.append("	vst_fact vf ")
			.append("	JOIN CLM_VST_UM_XREF AS CVUX ON (VF.VST_FACT_KEY = CVUX.VST_FACT_KEY) ")
			.append("	JOIN CMPLNC_UM_DTL_FACT AS CUDF ON (CUDF.CMPLNC_UM_DTL_FACT_KEY = CVUX.CMPLNC_UM_DTL_FACT_KEY ")
			.append("	AND CUDF.MSTR_CNSMR_DIM_KEY = CVUX.MSTR_CNSMR_DIM_KEY) ")
			.append("	join cd_dim srvc_type on (vf.srvc_type_cd_dim_key = srvc_type.cd_dim_key) ")
			.append("	left join cd_dim diag_1 on (vf.prncpl_diag_cd_dim_key = diag_1.cd_dim_key) ")
			.append("	left join cd_dim diag_2 on (vf.othr_diag_1_cd_dim_key = diag_2.cd_dim_key) ")
			.append("	left join cd_dim diag_3 on (vf.othr_diag_2_cd_dim_key = diag_3.cd_dim_key) ")
			.append("	left join cd_dim diag_4 on (vf.othr_diag_3_cd_dim_key = diag_4.cd_dim_key) ")
			.append("where ")
			.append("	cudf.mstr_cnsmr_dim_key = ? ")
			.append("	and cudf.msrmnt_prd_strt_dt = ?") //added to remove duplicate records in pop up
			.append("	and srvc_type.cd_val_txt = 'ER' ")
			.append("	and cudf.clm_line_srvc_strt_dt >= (current_date - day(current_date) day +1 day) - 15 MONTHS ")
			/*
			 * Adding the subCmpstNm check
			 */
			.append("   and cudf.sub_cmpst_nm = 'LIER' ")
			.append("order by ")
			.append("	vf.vst_strt_dt desc ")
			.append("with ur ");

		//		logger.debug("getEmergencyVisits SQL: " + sql.toString());

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());
			ps.setString(1, request.getMemberKey());
			ps.setString(2, request.getMeasurementPeriodStartDt());

			//logger.debug("sesn_id: " + request.getSessionId());
			//logger.debug("enttlmnt_hash_key: " + request.getEntitlementId());
			//logger.debug("mstr_cnsmr_dim_key: " + request.getMemberKey());

			executeQuery(logger, sql.toString());

			while (rs.next()) {

				ErVisitRowExp r = new ErVisitRowExp();
				r.setAdmitDate(getDate(rs, "vst_strt_dt"));
				r.setDayofWeek(getString(rs, "day_long_nm"));
				r.setFacilityName(getString(rs, "fclty_nm"));
				r.setPrimaryDiagnosis(getString(rs, "prncpl_diag_nm"));

				Collection<SecondaryDiagnosis> diags = new ArrayList<SecondaryDiagnosis>();

				for (int i = 1; i <= 3; i++) {
					String cd = getString(rs, "other_diag_" + i + "_nm");
					if (!cd.equals("*")) {
						diags.add(new SecondaryDiagnosis(cd));
					}
				}

				r.setSecondaryDiagnosisList(diags);
				/*
				 * Hard coding right now - as per discussion; data is not available as of now. 
				 * For the iteration purposes, hard coding the JSON parameter to 100 to reflect on the UI
				 */
				/*
				 * 11 Dec 2015 - Removing the hard coding following the discussion with the data team
				 * 04th January 2016 - Following the RTM Update, Cost of Visits not to be shown in the pop up, hence commenting the following setter
				 */
				/*if(null != rs.getBigDecimal("alwd_amt"))
					r.setVisitCost(rs.getBigDecimal("alwd_amt").toString());
				else
					r.setVisitCost(Constants.DASHES);*/

				result.add(r);
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get emergency visits (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}
}
