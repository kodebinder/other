package com.wellpoint.pc2dash.action.communications;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.data.dao.AppProperties;
import com.wellpoint.pc2dash.data.dto.AppProperty;
import com.wellpoint.pc2dash.dto.communications.CommunicationsJson;
import com.wellpoint.pc2dash.dto.dashboard.HomePageTickersJson;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.communications.CommunicationsServiceImpl;
import com.wellpoint.pc2dash.util.ErrorProperties;


public class GetCommunicationsAction extends Action {

	List<HomePageTickersJson> resultList;
	ErrorProperties err = ErrorProperties.getInstance();

	ActionResponse response = new GetCommunicationsResponse();

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetCommunicationsAction.class);

	@SuppressWarnings("unchecked")
	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetCommunicationsRequest request = (GetCommunicationsRequest) actionRequest;
		CommunicationsServiceImpl service = new CommunicationsServiceImpl();

		try {
			
			/*
			 * Toggle between old and new queries for now
			 */
			resultList = getDataViaToggle(request, service);
			ArrayList<CommunicationsJson> communicationsList = (ArrayList<CommunicationsJson>) service.getBeanList(resultList);

			response = populateResponse(communicationsList);
			response.setSuccess(true);
			if (null == resultList || (null != resultList && resultList.isEmpty())) {
				response.setMessage(err.getProperty("successNoData"));
			}
			else {
				response.setMessage(err.getProperty("successful"));
			}

			return response;
		}
		catch (Exception pe) {

			logger.error("Unable to get communications.", pe);

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}

	private ActionResponse populateResponse(ArrayList<CommunicationsJson> communicationsList) {
		response.setData(communicationsList);
		return response;
	}

	@SuppressWarnings("unchecked")
	protected List<HomePageTickersJson> getDataViaToggle(GetCommunicationsRequest request, CommunicationsServiceImpl dao) throws Exception {
		AppProperties props = new AppProperties();
		AppProperty prop = props.getAppProperty("ADMIN_CONFIG", "useCmnctnAcsQuery");

		List<HomePageTickersJson> results;
		if (prop != null && "true".equalsIgnoreCase(prop.getValue())) {
			results = dao.getData_Acs(request);
		}
		else {
			results = dao.getData(request);
		}
		return results;
	}
}
