package com.wellpoint.pc2dash.action.scorecardTrending;


public class ScorecardComponentsRequest extends ScorecardTrendingRequest {

	protected String measurementPeriod;

	public String getMeasurementPeriod() {
		return measurementPeriod;
	}

	public void setMeasurementPeriod(String measurementPeriod) {
		this.measurementPeriod = measurementPeriod;
	}

}
