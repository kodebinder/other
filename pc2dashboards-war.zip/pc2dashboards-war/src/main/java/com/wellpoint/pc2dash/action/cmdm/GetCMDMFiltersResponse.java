package com.wellpoint.pc2dash.action.cmdm;

import java.util.Collection;
import java.util.Vector;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetCMDMFiltersResponse extends ActionResponse {

	private int id;
	private String text;
	private Collection<Object> children = new Vector<Object>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Collection<Object> getChildren() {
		return children;
	}

	public void setChildren(Collection<Object> children) {
		this.children = children;
	}

}
