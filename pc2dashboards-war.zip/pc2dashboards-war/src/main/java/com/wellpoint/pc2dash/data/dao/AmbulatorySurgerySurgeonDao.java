package com.wellpoint.pc2dash.data.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.costOpportunity.GetAmbulatorySurgerySurgeonRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.costOpportunity.AmbulatorySurgerySurgeonBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class AmbulatorySurgerySurgeonDao extends ServiceImpl {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(AmbulatorySurgerySurgeonDao.class);

	private boolean displayDashes = false;

	public List<AmbulatorySurgerySurgeonBean> getData(GetAmbulatorySurgerySurgeonRequest request, boolean exportFlag, int index, int limit) throws Exception {


		List<AmbulatorySurgerySurgeonBean> result = new ArrayList<AmbulatorySurgerySurgeonBean>();
		setRowCount(0);

		String dir = request.getSort().get(0).getDirection();
		String masked = "asc".equalsIgnoreCase(dir) ? String.valueOf(Integer.MAX_VALUE) : String.valueOf(Integer.MIN_VALUE); // we want masked values to always be at the bottom, so use either the biggest or smallest value, depending
		String dashesClause =
			" sum(srgry_cnt) < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_ASC_MIN_TOTL_SRGRY' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG') ";


		StringBuilder query =
			new StringBuilder()
				.append(" select   c.* ")
				.append(" from   ( ")
				.append("   select   b.*, row_number() over( order by ")
				.append(buildSortClause(request))
				.append(" ) as row_nbr ")
				.append("   from   ( ")
				.append(" select ")
				.append(" a.surgeonTaxId, ")        
				.append(" a.surgeonGroup, ")
				.append(" a.surgeonCount, ")        
				.append(" a.costOpportunity, ")        
				.append(" a.totalSurgeryCount, ")        
				.append(" a.totalHighCostSurgeryCount, ")        
				.append(" a.percentageHighCostSurgeryCount, ")       
				.append(" a.row_cnt as row_cnt, ")        
				.append(" a.dsply_dashes ")      
				.append(" from   ( ")       
				.append(" select ")
				.append(" surgeonTaxId, ")          
				.append(" surgeonGroup, ")
				.append(" surgeonCount, ")
				.append(" case when ")
				.append(dashesClause)
				.append(" then ")
				.append(masked)
				.append(" when sum(cost_oprtnty_amt) >= 0 then sum(cost_oprtnty_amt) else 0.00 end as costOpportunity, ")
				.append(" sum(srgry_cnt) as totalSurgeryCount, ")
				.append(" sum(HSRGRY_CNT) as totalHighCostSurgeryCount, ")
				
				.append(" case when ")
				.append(dashesClause)
				.append(" then ")
				.append(masked)
			//	.append(" when sum(srgry_cnt) > 0 then (100 * CAST(sum(HSRGRY_CNT) as decimal(18,4)) / CAST(sum(srgry_cnt) as decimal(18,4))) else 0.00 end as percentageHighCostSurgeryCount, ")
				.append(" when  sum(srgry_cnt) > 0 then  (100 * (CAST(sum(HSRGRY_CNT) as decimal(18,4)) / CAST(sum(srgry_cnt) as decimal(18,4)))) else  0.0000 end as percentageHighCostSurgeryCount, ")
				.append(" count(*) over () as row_cnt, ")
				
				.append(" case when ")
				.append(dashesClause)
				.append(" then 'Y' else 'N' end as dsply_dashes from ( ")

				.append(" select  ") 
				.append(" smry.srgn_tax_id as surgeonTaxId,  ") 
				.append(" smry.srgn_bsns_nm as surgeonGroup,  ")  
				.append(" count(distinct srgn_npi) as surgeonCount,  ")  
				.append(" sum(COST_OPRTNTY_AMT) as COST_OPRTNTY_AMT,  ")  
				.append(" sum(srgry_cnt) as srgry_cnt,   ")  
				.append(" ILV.MEM_MNTH as MEM_MNTH,   ")
				.append(" sum( case  when  hcost_ind = 'Y' then  srgry_cnt else  0 end ) as HSRGRY_CNT  ")      
				.append(" from   coc_asc_ctgry_smry smry  ")

				.append(" join (select  ")
				.append(" nvl(SUM(MM.MBR_MNTH_12_CNT),0) as MEM_MNTH ")
				.append(" FROM  PAT_SMRY_FACT PSF ")
				.append(" INNER JOIN MSTR_CNSMR_MBR_MNTH_FACT MM ON ")
				.append(" MM.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY ")
				.append(" AND MM.RCRD_STTS_CD = 'ACT' ")
				.append(" AND PSF.ATRBN_STTS_CD = 'ACTIVE' ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and psf.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and psf.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and psf.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and psf.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and psf.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}



		query.append(" ) as ILV on 1=1 ")

			.append("         join  poit_user_scrty_acs pusa on (smry.prov_grp_id = pusa.prov_grp_id and ")
			.append("           case ")
			.append("                      when    pusa.prov_org_tax_id = '0' ")
			.append("                      then    smry.prov_org_tax_id ")
			.append("                      else    pusa.prov_org_tax_id end = smry.prov_org_tax_id) ")
			.append("       where  pusa.sesn_id = ? ")
			.append("       and  pusa.enttlmnt_hash_key = ? ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and smry.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and smry.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and smry.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and smry.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and smry.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProcedureCode())) {
			query.append(" and smry.SUB_MTRC_CD in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProcedureCode())
				+ ") ");
		}

		query.append(" group by ")  
		.append(" smry.srgn_tax_id, ")   
		.append(" smry.srgn_bsns_nm, ")      
	    .append(" ILV.MEM_MNTH ") 
		.append(" )   ")  
		.append(" group by ")    
		.append(" surgeonTaxId, ")   
		.append(" surgeonGroup, ")  
		.append(" surgeonCount, ") 
		.append(" MEM_MNTH ")         
		.append(" ) as a  ")    
		.append(" ) as b ")   
	    .append(" ) as c ");  

		query.append("where  c.row_nbr between ? and ? ");
		query.append(" order by   c.row_nbr  with ur ");



		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());

			buildPreparedStatement(request, i, exportFlag, index, limit);

			executeQuery(logger, query.toString());

			result = convertSelectedRowsToObjects(rs, request, displayDashes, exportFlag);

		}
		catch (Exception e) {

			throw new Exception("Unable to get AmbulatorySurgerySurgeonDao (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;

	
	}

	private void buildPreparedStatement(GetAmbulatorySurgerySurgeonRequest request, int i, boolean exportFlag, int index, int limit) throws SQLException {

		//For PMPM Starts
		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}
		//For PMPM Ends
		int start = 0;
		int stop = 0;

		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProcedureCode())) { 
			String[] array = request.getProcedureCode().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (!exportFlag) {
			start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
			stop = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
		}
		else {
			start = index;
			stop = limit;
		}
		ps.setInt(++i, start + 1);
		ps.setInt(++i, start + stop);

	}

	private List<AmbulatorySurgerySurgeonBean> convertSelectedRowsToObjects(ResultSet rs, GetAmbulatorySurgerySurgeonRequest request, boolean displayDashes, boolean exportFlag)
		throws SQLException {

		List<AmbulatorySurgerySurgeonBean> list = new ArrayList<AmbulatorySurgerySurgeonBean>();


		if (exportFlag) {
			while (rs.next()) {

				AmbulatorySurgerySurgeonBean item = new AmbulatorySurgerySurgeonBean();

				if(rs.getString("surgeonGroup") != null){
					item.setSurgeonGroup(rs.getString("surgeonGroup"));
				}else{
					item.setSurgeonGroup(Constants.UNK);
				}
				item.setSurgeonTin(StringUtil.getValueOrDashes(rs.getString("surgeonTaxId")));
				item.setTotalSurgeryCount(rs.getString("totalSurgeryCount"));
				if (rs.getString("percentageHighCostSurgeryCount") != null) {
					item.setPercentageHighCostSurgeryCount(StringUtil.convertStringToCommaBigDecimal(
						rs.getBigDecimal("percentageHighCostSurgeryCount").setScale(2, BigDecimal.ROUND_HALF_UP).toString(), 2).concat("%"));
				}
				item.setSurgeonCount(rs.getString("surgeonCount"));
				if (rs.getString("costOpportunity") != null) {
					item.setCostOpportunity(StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("costOpportunity").setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
				}
				item.setHighCostSurgeryPercentageInd(false);							
				item.setProviderId(StringUtil.getValueOrDashes(rs.getString("surgeonTaxId")));
				item.setHasDetailsDrilldownInd(false);	

				if (rs.getString("dsply_dashes") != null && rs.getString("dsply_dashes").equalsIgnoreCase(Constants.Y)) {
					displayDashes = true;
				}
				else {
					displayDashes = false;
				}

				if (displayDashes) {

					if(rs.getString("surgeonGroup") != null){
						item.setSurgeonGroup(rs.getString("surgeonGroup"));
					}else{
						item.setSurgeonGroup(Constants.UNK);
					}
					item.setSurgeonTin(Constants.DASHES);
					item.setTotalSurgeryCount(Constants.DASHES);
					item.setPercentageHighCostSurgeryCount(Constants.DASHES);
					item.setSurgeonCount(Constants.DASHES);
					item.setCostOpportunity(Constants.DASHES);
					item.setHighCostSurgeryPercentageInd(false);							
					item.setProviderId(Constants.DASHES);
					item.setHasDetailsDrilldownInd(false);	

				}

				list.add(item);

				if (getRowCount() == 0) {
					setRowCount(rs.getInt("row_cnt"));
				}
				setTotalExport(rs.getInt("row_cnt"));   

			}
		}
		else {
			while (rs.next()) {

				AmbulatorySurgerySurgeonBean item = new AmbulatorySurgerySurgeonBean();

				if(rs.getString("surgeonGroup") != null){
					item.setSurgeonGroup(rs.getString("surgeonGroup"));
				}else{
					item.setSurgeonGroup(Constants.UNK);
				}
				item.setTotalSurgeryCount(rs.getString("totalSurgeryCount"));
				item.setPercentageHighCostSurgeryCount(rs.getString("percentageHighCostSurgeryCount"));
				item.setSurgeonCount(rs.getString("surgeonCount"));
				item.setCostOpportunity(rs.getString("costOpportunity"));
				item.setHighCostSurgeryPercentageInd(false);							
				item.setProviderId(rs.getString("surgeonTaxId"));
				item.setHasDetailsDrilldownInd(false);	

				if (rs.getString("dsply_dashes") != null && rs.getString("dsply_dashes").equalsIgnoreCase(Constants.Y)) {
					displayDashes = true;
				}
				else {
					displayDashes = false;
				}

				if (displayDashes) {
					if(rs.getString("surgeonGroup") != null){
						item.setSurgeonGroup(rs.getString("surgeonGroup"));
					}else{
						item.setSurgeonGroup(Constants.UNK);
					}
					item.setTotalSurgeryCount(Constants.DASHES);
					item.setPercentageHighCostSurgeryCount(Constants.DASHES);
					item.setSurgeonCount(Constants.DASHES);
					item.setCostOpportunity(Constants.DASHES);
					item.setHighCostSurgeryPercentageInd(false);							
					item.setProviderId(Constants.DASHES);
					item.setHasDetailsDrilldownInd(false);
				}
				else {
					
					if(rs.getString("surgeonGroup") != null){
						item.setSurgeonGroup(rs.getString("surgeonGroup"));
					}else{
						item.setSurgeonGroup(Constants.UNK);
					}

					if (rs.getString("totalSurgeryCount") != null) {
						item.setTotalSurgeryCount(rs.getString("totalSurgeryCount"));
						if(Integer.parseInt(rs.getString("totalSurgeryCount"))>0)			//PCMSP-21806
						{
						item.setHasDetailsDrilldownInd(true); 
						}
						
					} else {
						item.setTotalSurgeryCount(Constants.DASHES);
					}

					if (rs.getString("percentageHighCostSurgeryCount") != null) {
						item.setPercentageHighCostSurgeryCount(rs.getString("percentageHighCostSurgeryCount"));
					} else {
						item.setPercentageHighCostSurgeryCount(Constants.DASHES);
					}

					if (rs.getString("surgeonCount") != null) {
						item.setSurgeonCount(rs.getString("surgeonCount"));
					} else {
						item.setSurgeonCount(Constants.DASHES);
					}

					if (rs.getString("costOpportunity") != null) {
						item.setCostOpportunity(rs.getString("costOpportunity"));
					} else {
						item.setCostOpportunity(Constants.DASHES);
					}
				
					item.setHighCostSurgeryPercentageInd(false);
			
				}

				list.add(item);

				if (getRowCount() == 0) {
					setRowCount(rs.getInt("row_cnt"));
				}

			}

		}

		return list;

	}

	protected String getSort(GetAmbulatorySurgerySurgeonRequest request) {
		String dir = "";
		if (CollectionUtils.isNotEmpty(request.getSort())
			&& request.getSort().get(0) != null
			&& StringUtils.isNotBlank(request.getSort().get(0).getDirection())) {
			dir = request.getSort().get(0).getDirection();
		}
		return dir;
	}
	
	private String buildSortClause(GetAmbulatorySurgerySurgeonRequest request) {

		StringBuilder query = new StringBuilder();
		String defaultColumn = " costOpportunity ";
		String defaultSort = defaultColumn + " desc ";

		if (null != request.getSort()) {

			for (QuerySort sort : request.getSort()) {

				String dir = sort.getDirection().replaceAll("\"", "");
				String property = sort.getProperty();

				if (property.equals("surgeonGroup")) {
					query.append(" case when surgeonGroup is not null then 0 else 1 end,"  + " surgeonGroup " + dir + ", " + defaultSort);
				}
				else if (property.equals("totalSurgeryCount")) {
					query.append(" case when totalSurgeryCount is not null then 0 else 1 end,"  + " totalSurgeryCount " + dir + ", " + defaultSort);
				}
				else if (property.equals("percentageHighCostSurgeryCount")) {
					query.append(" case when percentageHighCostSurgeryCount is not null then 0 else 1 end,"  + " percentageHighCostSurgeryCount " + dir + ", " + defaultSort);
				}
				else if (property.equals("surgeonCount")) {
					query.append(" case when surgeonCount is not null then 0 else 1 end,"  + " surgeonCount " + dir + ", " + defaultSort);
				}
				else if (property.equals("costOpportunity")) {
					query.append(" case when costOpportunity is not null then 0 else 1 end,"  + " costOpportunity " + dir + ", " + defaultSort);
				}
				else {
					query.append(defaultColumn + dir);
				}
			}

		}
		else{
			query.append(defaultSort);
		}

		return query.toString();

	}
	
}