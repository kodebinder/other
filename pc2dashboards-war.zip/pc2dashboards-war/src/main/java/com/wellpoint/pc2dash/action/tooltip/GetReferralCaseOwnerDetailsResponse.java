package com.wellpoint.pc2dash.action.tooltip;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetReferralCaseOwnerDetailsResponse extends ActionResponse{

}
