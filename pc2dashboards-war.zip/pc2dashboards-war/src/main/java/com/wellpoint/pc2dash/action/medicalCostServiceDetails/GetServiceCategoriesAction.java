package com.wellpoint.pc2dash.action.medicalCostServiceDetails;

import java.util.List;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.service.medicalCost.ServiceCategory;
import com.wellpoint.pc2dash.service.medicalCost.ServiceCategoryImpl;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetServiceCategoriesAction extends Action {
	GetServiceCategoryResponse response = new GetServiceCategoryResponse();

	List<ServiceCategory> resultList;

	ErrorProperties err = ErrorProperties.getInstance();

	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		GetServiceCategoriesRequest request = (GetServiceCategoriesRequest) actionRequest;

		ServiceCategoryImpl pC2Service = new ServiceCategoryImpl();

		try {
			resultList = pC2Service.getData(request);

			response.setMessage(StringUtil.buildMessage(resultList.isEmpty()));
			response.setSuccess(true);

			response.setText(".");
			response.setId(0);
			response.setChildren(resultList);

		}
		catch (Exception pe) {
			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
		return response;
	}
}
