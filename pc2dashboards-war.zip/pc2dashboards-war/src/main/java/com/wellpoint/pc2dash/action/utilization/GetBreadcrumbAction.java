package com.wellpoint.pc2dash.action.utilization;

import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.quality.GetQualityAction;
import com.wellpoint.pc2dash.data.dao.BreadcrumbsUtility;
import com.wellpoint.pc2dash.dto.patient.BreadCrumbTreeHierarchy;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetBreadcrumbAction extends GetQualityAction {

	GetBreadCrumbResponse response = new GetBreadCrumbResponse();

	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		GetBreadcrumbRequest request = (GetBreadcrumbRequest) actionRequest;
		List<BreadCrumbTreeHierarchy> resultList = new ArrayList<BreadCrumbTreeHierarchy>();

		try {
			request = (GetBreadcrumbRequest) cleanRequest(request);
			if (StringUtil.isJson(request)) {

				BreadcrumbsUtility dao = new BreadcrumbsUtility();
				
				if("getBrandFormularyBreadcrumbs".equalsIgnoreCase(request.getCmd())){

					resultList.addAll(dao.getBrandFormularyBreadCrumbsData(request));

				} else {
					
					resultList.addAll(dao.getBreadCrumbsData(request));

				}


				if (null == resultList || (null != resultList && resultList.isEmpty())) {
					response.setMessage(StringUtil.buildMessage(resultList.isEmpty()));
				}
				else {
					response.setMessage(StringUtil.buildMessage(resultList.isEmpty()));
					response.getChildren().addAll(resultList);
				}

				response.setSuccess(true);
			}

		}
		catch (Exception e) {
			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(e, response);
		}

		return response;
	}

}
