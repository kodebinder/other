package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.action.tooltip.GetPatientDetailRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.data.dto.AuditEntry;
import com.wellpoint.pc2dash.dto.patient.Conditions;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QueryConstants;
import com.wellpoint.pc2dash.util.StringUtil;


public class DiseaseConditionFacts extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(DiseaseConditionFacts.class);
	private boolean sensitive = false;
	private boolean attested = false;
	public boolean read(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void insert(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void update(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void delete(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}
	
	public Collection<Conditions> getDiseaseConditions(GetPatientDetailRequest request) throws Exception {

		Collection<Conditions> result = new ArrayList<Conditions>();

		/*
		 * AD11480 - NF20045
		 */
		StringBuilder sql = new StringBuilder()

			.append("select pc.snsitv_ind, ")
			.append("case ")
			.append(" when pc.snsitv_ind='0' then pc.CNDTN_NM ")
			.append(" when pc.SNSITV_IND = '1' and locate_in_string(AP.CMNT_TXT, psf.LOB_CTGRY_NM)>0 then '***'") //PCMSP-18486
			.append(" else AP.APLCTN_PRPTY_VAL_TXT")
			.append(" end as CD_VAL_NM ,")
			.append(" pc.sort_nbr ")
			.append(" from pat_cndtn pc ")
			.append("      join  PAT_SMRY_FACT psf ON (pc.PAT_ID = psf.MSTR_CNSMR_DIM_KEY) ")
			.append("        join  POIT_USER_SCRTY_ACS PUSA ON ( psf.PROV_GRP_ID = PUSA.PROV_GRP_ID ")
			
			.append(" and case ")
			.append("      when PUSA.PROV_ORG_TAX_ID = '0' ")
			.append("         then  psf.PROV_ORG_TAX_ID ")
			.append("           else  PUSA.PROV_ORG_TAX_ID END = psf.PROV_ORG_TAX_ID  ) ")
			.append("    inner join CD_DIM snstv on  (pc.CNDTN_ID = snstv.CD_DIM_KEY) ")
			.append("    Left join   APLCTN_PRPTY AP on (snstv.CD_VAL_TXT = AP.APLCTN_PRPTY_NM) ")
			.append(" where  PUSA.SESN_ID = ? ")
			.append(" and  PUSA.ENTTLMNT_HASH_KEY = ? ")
			.append(" and  psf.MSTR_CNSMR_DIM_KEY = ? ")
			.append(" and pc.CNDTN_TYPE_CD='DSEAS' ")
			.append(" order by ")
			.append(" pc.sort_nbr ");

		/*.append("SELECT CD_VAL_NM, PARNT_CD_DIM_KEY, CD_DIM_KEY FROM ( ")
		.append(queryForNonSnstv())
		.append(" UNION ")
		.append(queryForSnstvSpecificLobMarket())
		.append(" UNION ")
		.append(queryForSnstvAllLobMarket())
		.append(" UNION ")
		.append(queryForSnstvAllLob())
		.append(" UNION ")
		.append(queryForSnstvAllMarket())
		.append(" UNION ")
		.append(queryForNonSnstvMrktOrLob())
		.append(" ) ORDER BY PARNT_CD_DIM_KEY ");*/


		sql = StringUtil.appendWithUr(sql);

		//		logger.debug("getDiseaseConditions SQL: " + sql.toString());

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());
			int i = 1;
			ps.setString(i++, request.getSessionId());
			ps.setString(i++, request.getEntitlementId());
			ps.setString(i++, request.getMemberKey());
			/*ps.setString(i++, request.getSessionId());
			ps.setString(i++, request.getEntitlementId());
			ps.setString(i++, request.getMemberKey());
			ps.setString(i++, request.getSessionId());
			ps.setString(i++, request.getEntitlementId());
			ps.setString(i++, request.getMemberKey());
			ps.setString(i++, request.getSessionId());
			ps.setString(i++, request.getEntitlementId());
			ps.setString(i++, request.getMemberKey());
			ps.setString(i++, request.getSessionId());
			ps.setString(i++, request.getEntitlementId());
			ps.setString(i++, request.getMemberKey());
			ps.setString(i++, request.getSessionId());
			ps.setString(i++, request.getEntitlementId());
			ps.setString(i++, request.getMemberKey());
			ps.setString(i++, request.getSessionId());
			ps.setString(i++, request.getEntitlementId());
			ps.setString(i++, request.getMemberKey());
			ps.setString(i++, request.getSessionId());
			ps.setString(i++, request.getEntitlementId());
			ps.setString(i++, request.getMemberKey());
			ps.setString(i++, request.getSessionId());
			ps.setString(i++, request.getEntitlementId());
			ps.setString(i++, request.getMemberKey());
			ps.setString(i++, request.getSessionId());
			ps.setString(i++, request.getEntitlementId());
			ps.setString(i++, request.getMemberKey());
			*/
			//logger.debug("sesn_id: " + request.getSessionId());
			//logger.debug("enttlmnt_hash_key: " + request.getEntitlementId());
			//logger.debug("mstr_cnsmr_dim_key: " + request.getMemberKey());

			executeQuery(logger, sql.toString());
			
			attested = CommonQueries.checkAttestation(request);
			
			while (rs.next()) {

				Conditions r = new Conditions();
				r.setConditionName(getString(rs, "CD_VAL_NM"));
				/*if(Constants.ZERO.equalsIgnoreCase(getString(rs, "snsitv_ind")))
					r.setConditionName(getString(rs, "CD_VAL_NM"));
				else
				{
					if(attested)
						r.setConditionName(getString(rs, "CD_VAL_NM"));
					else{
						r.setConditionName(Constants.RA_MASK);
						sensitive = true;
					}
				}*/

				result.add(r);
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get disease conditions (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}

	private StringBuilder queryForNonSnstv() {
		StringBuilder sql = new StringBuilder()
			.append(" SELECT CD.CD_VAL_NM AS CD_VAL_NM, CD.PARNT_CD_DIM_KEY AS PARNT_CD_DIM_KEY, CD.CD_DIM_KEY ")
			.append(" FROM DSEAS_CNDTN_FACT DCF ")
			.append(" JOIN MSTR_CNSMR_FACT MCF ON (DCF.MSTR_CNSMR_DIM_KEY  = MCF.MSTR_CNSMR_DIM_KEY) ")
			.append(" JOIN CD_DIM CD ON (DCF.DSEAS_CNDTN_CD_DIM_KEY = CD.CD_DIM_KEY) ")
			.append(" JOIN POIT_USER_SCRTY_ACS PUSA ON ( ")
			.append("	MCF.PROV_GRP_ID = PUSA.PROV_GRP_ID ")
			.append("	AND CASE ")
			.append("		WHEN PUSA.PROV_ORG_TAX_ID = '0' THEN MCF.PROV_ORG_TAX_ID ")
			.append("		ELSE PUSA.PROV_ORG_TAX_ID ")
			.append("		END = MCF.PROV_ORG_TAX_ID ")
			.append(" ) ")
			.append("WHERE ")
			.append("	PUSA.SESN_ID = ? ")
			.append("	AND PUSA.ENTTLMNT_HASH_KEY = ? ")
			.append("	AND MCF.MSTR_CNSMR_DIM_KEY = ? ")
			.append("   AND CD.CD_DIM_KEY NOT IN (SELECT SCD.CD_DIM_KEY FROM SNSTV_CD_DIM SCD )");
		return sql;

	}

	private StringBuilder queryForNonSnstvForExport() {
		StringBuilder sql = new StringBuilder()
			.append(" SELECT CD.CD_VAL_NM AS CD_VAL_NM, CD.PARNT_CD_DIM_KEY AS PARNT_CD_DIM_KEY, CD.CD_DIM_KEY, DCF.MSTR_CNSMR_DIM_KEY ")
			.append(" FROM DSEAS_CNDTN_FACT DCF ")
			.append(" JOIN PAT_SMRY_FACT PSF ON (DCF.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY) ")
			.append(" JOIN CD_DIM CD ON (DCF.DSEAS_CNDTN_CD_DIM_KEY = CD.CD_DIM_KEY) ")
			.append("WHERE ")
			.append("   CD.CD_DIM_KEY NOT IN (SELECT SCD.CD_DIM_KEY FROM SNSTV_CD_DIM SCD )");
		return sql;

	}

	private StringBuilder queryForSnstvSpecificLobMarket() {
		StringBuilder sql = new StringBuilder()
			.append(" SELECT '***' AS CD_VAL_NM, CD.PARNT_CD_DIM_KEY AS PARNT_CD_DIM_KEY, CD.CD_DIM_KEY ")
			.append(" FROM DSEAS_CNDTN_FACT DCF ")
			.append(" JOIN MSTR_CNSMR_FACT MCF ON (DCF.MSTR_CNSMR_DIM_KEY  = MCF.MSTR_CNSMR_DIM_KEY) ")
			.append(" JOIN CD_DIM CD ON (DCF.DSEAS_CNDTN_CD_DIM_KEY = CD.CD_DIM_KEY) ")
			.append(" JOIN POIT_USER_SCRTY_ACS PUSA ON ( ")
			.append("	MCF.PROV_GRP_ID = PUSA.PROV_GRP_ID ")
			.append("	AND CASE ")
			.append("		WHEN PUSA.PROV_ORG_TAX_ID = '0' THEN MCF.PROV_ORG_TAX_ID ")
			.append("		ELSE PUSA.PROV_ORG_TAX_ID ")
			.append("		END = MCF.PROV_ORG_TAX_ID ")
			.append(" ) ")
			.append(" JOIN SNSTV_CD_DIM SCD ON (SCD.CD_DIM_KEY = CD.CD_DIM_KEY) ")
			.append(" JOIN LOB_DIM LB ON (LB.LOB_DIM_KEY = MCF.LOB_DIM_KEY AND SCD.LOB_ID = LB.LOB_CTGRY_NM) ")
			.append(" JOIN PROV_GRP_DIM PGD ON (PGD.PROV_GRP_ID = MCF.PROV_GRP_ID AND PGD.ST_PRVNC_CD = SCD.MRKT_ST_CD) ")
			.append("WHERE ")
			.append("	PUSA.SESN_ID = ? ")
			.append("	AND PUSA.ENTTLMNT_HASH_KEY = ? ")
			.append("	AND MCF.MSTR_CNSMR_DIM_KEY = ? ");
		return sql;

	}

	private StringBuilder queryForSnstvSpecificLobMarketForExport() {
		StringBuilder sql = new StringBuilder()
			.append(" SELECT '***' AS CD_VAL_NM, CD.PARNT_CD_DIM_KEY AS PARNT_CD_DIM_KEY, CD.CD_DIM_KEY, DCF.MSTR_CNSMR_DIM_KEY ")
			.append(" FROM DSEAS_CNDTN_FACT DCF ")
			.append(" JOIN PAT_SMRY_FACT PSF ON (DCF.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY) ")
			.append(" JOIN CD_DIM CD ON (DCF.DSEAS_CNDTN_CD_DIM_KEY = CD.CD_DIM_KEY) ")
			.append(" JOIN SNSTV_CD_DIM SCD ON (SCD.CD_DIM_KEY = CD.CD_DIM_KEY) ")
			.append(" JOIN LOB_DIM LB ON (LB.LOB_DIM_KEY = PSF.LOB_DIM_KEY AND SCD.LOB_ID = LB.LOB_CTGRY_NM) ")
			.append(" JOIN PROV_GRP_DIM PGD ON (PGD.PROV_GRP_ID = PSF.PROV_GRP_ID AND PGD.ST_PRVNC_CD = SCD.MRKT_ST_CD) ");
		return sql;

	}

	private StringBuilder queryForSnstvAllLob() {
		StringBuilder sql = new StringBuilder()
			.append(" SELECT '***' AS CD_VAL_NM, CD.PARNT_CD_DIM_KEY AS PARNT_CD_DIM_KEY, CD.CD_DIM_KEY ")
			.append(" FROM DSEAS_CNDTN_FACT DCF ")
			.append(" JOIN MSTR_CNSMR_FACT MCF ON (DCF.MSTR_CNSMR_DIM_KEY  = MCF.MSTR_CNSMR_DIM_KEY) ")
			.append(" JOIN CD_DIM CD ON (DCF.DSEAS_CNDTN_CD_DIM_KEY = CD.CD_DIM_KEY) ")
			.append(" JOIN POIT_USER_SCRTY_ACS PUSA ON ( ")
			.append("	MCF.PROV_GRP_ID = PUSA.PROV_GRP_ID ")
			.append("	AND CASE ")
			.append("		WHEN PUSA.PROV_ORG_TAX_ID = '0' THEN MCF.PROV_ORG_TAX_ID ")
			.append("		ELSE PUSA.PROV_ORG_TAX_ID ")
			.append("		END = MCF.PROV_ORG_TAX_ID ")
			.append(" ) ")
			.append(" JOIN SNSTV_CD_DIM SCD ON (SCD.CD_DIM_KEY = CD.CD_DIM_KEY AND SCD.LOB_ID = 'NA') ")
			.append(" JOIN PROV_GRP_DIM PGD ON (PGD.PROV_GRP_ID = MCF.PROV_GRP_ID AND PGD.ST_PRVNC_CD = SCD.MRKT_ST_CD) ")
			.append("WHERE ")
			.append("	PUSA.SESN_ID = ? ")
			.append("	AND PUSA.ENTTLMNT_HASH_KEY = ? ")
			.append("	AND MCF.MSTR_CNSMR_DIM_KEY = ? ");
		return sql;

	}

	private StringBuilder queryForSnstvAllLobForExport() {
		StringBuilder sql = new StringBuilder()
			.append(" SELECT '***' AS CD_VAL_NM, CD.PARNT_CD_DIM_KEY AS PARNT_CD_DIM_KEY, CD.CD_DIM_KEY, DCF.MSTR_CNSMR_DIM_KEY ")
			.append(" FROM DSEAS_CNDTN_FACT DCF ")
			.append(" JOIN PAT_SMRY_FACT PSF ON (DCF.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY) ")
			.append(" JOIN CD_DIM CD ON (DCF.DSEAS_CNDTN_CD_DIM_KEY = CD.CD_DIM_KEY) ")
			.append(" JOIN SNSTV_CD_DIM SCD ON (SCD.CD_DIM_KEY = CD.CD_DIM_KEY AND SCD.LOB_ID = 'NA') ")
			.append(" JOIN PROV_GRP_DIM PGD ON (PGD.PROV_GRP_ID = PSF.PROV_GRP_ID AND PGD.ST_PRVNC_CD = SCD.MRKT_ST_CD) ");
		return sql;

	}

	private StringBuilder queryForSnstvAllMarket() {
		StringBuilder sql = new StringBuilder()
			.append(" SELECT '***' AS CD_VAL_NM, CD.PARNT_CD_DIM_KEY AS PARNT_CD_DIM_KEY, CD.CD_DIM_KEY ")
			.append(" FROM DSEAS_CNDTN_FACT DCF ")
			.append(" JOIN MSTR_CNSMR_FACT MCF ON (DCF.MSTR_CNSMR_DIM_KEY  = MCF.MSTR_CNSMR_DIM_KEY) ")
			.append(" JOIN CD_DIM CD ON (DCF.DSEAS_CNDTN_CD_DIM_KEY = CD.CD_DIM_KEY) ")
			.append(" JOIN POIT_USER_SCRTY_ACS PUSA ON ( ")
			.append("	MCF.PROV_GRP_ID = PUSA.PROV_GRP_ID ")
			.append("	AND CASE ")
			.append("		WHEN PUSA.PROV_ORG_TAX_ID = '0' THEN MCF.PROV_ORG_TAX_ID ")
			.append("		ELSE PUSA.PROV_ORG_TAX_ID ")
			.append("		END = MCF.PROV_ORG_TAX_ID ")
			.append(" ) ")
			.append(" JOIN SNSTV_CD_DIM SCD ON (SCD.CD_DIM_KEY = CD.CD_DIM_KEY AND SCD.MRKT_ST_CD = 'NA') ")
			.append(" JOIN LOB_DIM LB ON (LB.LOB_DIM_KEY = MCF.LOB_DIM_KEY AND SCD.LOB_ID = LB.LOB_CTGRY_NM) ")
			.append("WHERE ")
			.append("	PUSA.SESN_ID = ? ")
			.append("	AND PUSA.ENTTLMNT_HASH_KEY = ? ")
			.append("	AND MCF.MSTR_CNSMR_DIM_KEY = ? ");
		return sql;

	}

	private StringBuilder queryForSnstvAllMarketForExport() {
		StringBuilder sql = new StringBuilder()
			.append(" SELECT '***' AS CD_VAL_NM, CD.PARNT_CD_DIM_KEY AS PARNT_CD_DIM_KEY, CD.CD_DIM_KEY, DCF.MSTR_CNSMR_DIM_KEY ")
			.append(" FROM DSEAS_CNDTN_FACT DCF ")
			.append(" JOIN PAT_SMRY_FACT PSF ON (DCF.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY) ")
			.append(" JOIN CD_DIM CD ON (DCF.DSEAS_CNDTN_CD_DIM_KEY = CD.CD_DIM_KEY) ")
			.append(" JOIN SNSTV_CD_DIM SCD ON (SCD.CD_DIM_KEY = CD.CD_DIM_KEY AND SCD.MRKT_ST_CD = 'NA') ")
			.append(" JOIN LOB_DIM LB ON (LB.LOB_DIM_KEY = PSF.LOB_DIM_KEY AND SCD.LOB_ID = LB.LOB_CTGRY_NM) ");
		return sql;

	}

	private StringBuilder queryForSnstvAllLobMarket() {
		StringBuilder sql = new StringBuilder()
			.append(" SELECT '***' AS CD_VAL_NM, CD.PARNT_CD_DIM_KEY AS PARNT_CD_DIM_KEY, CD.CD_DIM_KEY ")
			.append(" FROM DSEAS_CNDTN_FACT DCF ")
			.append(" JOIN MSTR_CNSMR_FACT MCF ON (DCF.MSTR_CNSMR_DIM_KEY  = MCF.MSTR_CNSMR_DIM_KEY) ")
			.append(" JOIN CD_DIM CD ON (DCF.DSEAS_CNDTN_CD_DIM_KEY = CD.CD_DIM_KEY) ")
			.append(" JOIN POIT_USER_SCRTY_ACS PUSA ON ( ")
			.append("	MCF.PROV_GRP_ID = PUSA.PROV_GRP_ID ")
			.append("	AND CASE ")
			.append("		WHEN PUSA.PROV_ORG_TAX_ID = '0' THEN MCF.PROV_ORG_TAX_ID ")
			.append("		ELSE PUSA.PROV_ORG_TAX_ID ")
			.append("		END = MCF.PROV_ORG_TAX_ID ")
			.append(" ) ")
			.append(" JOIN SNSTV_CD_DIM SCD ON (SCD.CD_DIM_KEY = CD.CD_DIM_KEY AND SCD.MRKT_ST_CD = 'NA' AND SCD.LOB_ID = 'NA') ")
			.append("WHERE ")
			.append("	PUSA.SESN_ID = ? ")
			.append("	AND PUSA.ENTTLMNT_HASH_KEY = ? ")
			.append("	AND MCF.MSTR_CNSMR_DIM_KEY = ? ");
		return sql;

	}

	private StringBuilder queryForSnstvAllLobMarketForExport() {
		StringBuilder sql = new StringBuilder()
			.append(" SELECT '***' AS CD_VAL_NM, CD.PARNT_CD_DIM_KEY AS PARNT_CD_DIM_KEY, CD.CD_DIM_KEY, DCF.MSTR_CNSMR_DIM_KEY ")
			.append(" FROM DSEAS_CNDTN_FACT DCF ")
			.append(" JOIN PAT_SMRY_FACT PSF ON (DCF.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY) ")
			.append(" JOIN CD_DIM CD ON (DCF.DSEAS_CNDTN_CD_DIM_KEY = CD.CD_DIM_KEY) ")
			.append(" JOIN SNSTV_CD_DIM SCD ON (SCD.CD_DIM_KEY = CD.CD_DIM_KEY AND SCD.MRKT_ST_CD = 'NA' AND SCD.LOB_ID = 'NA') ");
		return sql;

	}

	private StringBuilder queryForNonSnstvMrktOrLob() {
		StringBuilder sql = new StringBuilder()
			.append("SELECT CD.CD_VAL_NM AS CD_VAL_NM, CD.PARNT_CD_DIM_KEY AS PARNT_CD_DIM_KEY, CD.CD_DIM_KEY ")
			.append("    FROM DSEAS_CNDTN_FACT AS DCF ")
			.append("    JOIN MSTR_CNSMR_FACT AS MCF ON (DCF.MSTR_CNSMR_DIM_KEY = MCF.MSTR_CNSMR_DIM_KEY) ")
			.append("    JOIN CD_DIM AS CD ON (DCF.DSEAS_CNDTN_CD_DIM_KEY = CD.CD_DIM_KEY) ")
			.append("    JOIN POIT_USER_SCRTY_ACS AS PUSA ")
			.append("    	ON (MCF.PROV_GRP_ID = PUSA.PROV_GRP_ID ")
			.append("      		AND CASE WHEN PUSA.PROV_ORG_TAX_ID = '0' THEN MCF.PROV_ORG_TAX_ID ELSE PUSA.PROV_ORG_TAX_ID END = MCF.PROV_ORG_TAX_ID) ")
			.append("    JOIN SNSTV_CD_DIM AS SCD ON (SCD.CD_DIM_KEY = CD.CD_DIM_KEY) ")
			.append("    WHERE PUSA.SESN_ID = ? ")
			.append("    AND PUSA.ENTTLMNT_HASH_KEY = ? ")
			.append("    AND MCF.MSTR_CNSMR_DIM_KEY = ? ")
			.append("    AND CD.CD_VAL_NM NOT IN ( ")
			.append(notInClauseForNonSnstvMrktOrLob())
			.append(") ")
			.append("	GROUP BY CD_VAL_NM, PARNT_CD_DIM_KEY, CD.CD_DIM_KEY ");

		return sql;
	}

	private StringBuilder queryForNonSnstvMrktOrLobForExport() {
		StringBuilder sql = new StringBuilder()

			.append("SELECT CD.CD_VAL_NM AS CD_VAL_NM, CD.PARNT_CD_DIM_KEY AS PARNT_CD_DIM_KEY, CD.CD_DIM_KEY, DCF.MSTR_CNSMR_DIM_KEY ")
			.append("    FROM DSEAS_CNDTN_FACT AS DCF ")
			.append("	 JOIN PAT_SMRY_FACT PSF ON (DCF.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY) ")
			.append("    JOIN CD_DIM AS CD ON (DCF.DSEAS_CNDTN_CD_DIM_KEY = CD.CD_DIM_KEY) ")
			.append("    JOIN SNSTV_CD_DIM AS SCD ON (SCD.CD_DIM_KEY = CD.CD_DIM_KEY) ")
			.append("    WHERE ")
			.append("    CD.CD_VAL_NM NOT IN ( ")
			.append("	 	SELECT INNER_VIEW.CD_VAL_NM FROM ( ")
			.append(notInClauseForNonSnstvMrktOrLobForExport())
			.append(")INNER_VIEW WHERE INNER_VIEW.MSTR_CNSMR_DIM_KEY = DCF.MSTR_CNSMR_DIM_KEY ) ")
			.append("	GROUP BY CD_VAL_NM, PARNT_CD_DIM_KEY, CD.CD_DIM_KEY, DCF.MSTR_CNSMR_DIM_KEY ");

		return sql;
	}

	private StringBuilder notInClauseForNonSnstvMrktOrLob() {
		StringBuilder notInClause = new StringBuilder()
			.append(queryForSnstvSpecificLobMarket().replace(0, queryForSnstvSpecificLobMarket().indexOf("FROM"), "SELECT CD.CD_VAL_NM "))
			.append(" UNION ")
			.append(queryForSnstvAllLob().replace(0, queryForSnstvAllLob().indexOf("FROM"), "SELECT CD.CD_VAL_NM "))
			.append(" UNION ")
			.append(queryForSnstvAllMarket().replace(0, queryForSnstvAllMarket().indexOf("FROM"), "SELECT CD.CD_VAL_NM "))
			.append(" UNION ")
			.append(queryForSnstvAllLobMarket().replace(0, queryForSnstvAllLobMarket().indexOf("FROM"), "SELECT CD.CD_VAL_NM "));

		return notInClause;
	}

	private StringBuilder notInClauseForNonSnstvMrktOrLobForExport() {
		StringBuilder notInClause =
			new StringBuilder()
				.append(
					queryForSnstvSpecificLobMarketForExport()
						.replace(0, queryForSnstvSpecificLobMarketForExport().indexOf("FROM"), "SELECT CD.CD_VAL_NM , DCF.MSTR_CNSMR_DIM_KEY "))
				.append(" UNION ")
				.append(queryForSnstvAllLobForExport().replace(0, queryForSnstvAllLobForExport().indexOf("FROM"), "SELECT CD.CD_VAL_NM , DCF.MSTR_CNSMR_DIM_KEY "))
				.append(" UNION ")
				.append(queryForSnstvAllMarketForExport().replace(0, queryForSnstvAllMarketForExport().indexOf("FROM"), "SELECT CD.CD_VAL_NM , DCF.MSTR_CNSMR_DIM_KEY "))
				.append(" UNION ")
				.append(queryForSnstvAllLobMarketForExport().replace(0, queryForSnstvAllLobMarketForExport().indexOf("FROM"), "SELECT CD.CD_VAL_NM , DCF.MSTR_CNSMR_DIM_KEY "));

		return notInClause;
	}

	public StringBuilder getDiseaseConditionsQuerySegmentForExport() {
		StringBuilder sql = new StringBuilder()
			//.append("SELECT CD_VAL_NM FROM ( ")
			.append(" FROM ( ")
			.append(queryForNonSnstvForExport())
			.append(" UNION ")
			.append(queryForSnstvSpecificLobMarketForExport())
			.append(" UNION ")
			.append(queryForSnstvAllLobMarketForExport())
			.append(" UNION ")
			.append(queryForSnstvAllLobForExport())
			.append(" UNION ")
			.append(queryForSnstvAllMarketForExport())
			.append(" UNION ")
			.append(queryForNonSnstvMrktOrLobForExport())
			.append(" ) ");

		return sql;
	}
	
	public boolean isSensitive() {
		return sensitive;
	}

	public boolean isAttested() {
		return attested;
	}
}
