package com.wellpoint.pc2dash.action.base;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.JsonSyntaxException;
import com.wellpoint.pc2dash.data.dao.AppProperties;
import com.wellpoint.pc2dash.data.dto.AppProperty;
import com.wellpoint.pc2dash.data.dto.PCMSRequest;
import com.wellpoint.pc2dash.data.dto.ReferralRequest;
import com.wellpoint.pc2dash.dto.suppression.Column;
import com.wellpoint.pc2dash.dto.suppression.SuppressionBean;
import com.wellpoint.pc2dash.dto.tinNpi.UserAcsIndicators;
import com.wellpoint.pc2dash.export.ExportGridColumn;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.service.killswitch.KillSwitchServiceImpl;
import com.wellpoint.pc2dash.util.ApplicationConfig;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.JSONUtils;
import com.wellpoint.pc2dash.util.StringUtil;


public abstract class Action {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(Action.class);

	String action;

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public abstract ActionResponse process(ActionRequest actionRequest);

	/**
	 * Moved here to avoid duplicate code in child classes.
	 * 
	 * @param ReferralRequest
	 * @return boolean
	 */
	protected boolean isAuthorized(ReferralRequest request) {

		if (!Constants.LOGIN_EXTERNAL.equals(request.getAuthMethod())
			&& "false".equals(ApplicationConfig.getInstance().getProperty("enableInternalReferralActions"))) {

			return false;
		}

		return true;
	}

	/**
	 * This method will return a list of Provider Groups which are filtered depending on the access to a particular UI component. This method will make a service call providing
	 * Component Id and List of Provider Groups.
	 * 
	 * @param request
	 * @return
	 */
	protected List<String> filterProvGrpsByKillSwitch(PCMSRequest request) {

		List<String> results = new ArrayList<String>();
		KillSwitchServiceImpl srvc = new KillSwitchServiceImpl();

		try {
			/*
			 * results = Arrays.asList(StringUtils.split(
			 * request.getProvGrpIds(), ","));
			 */
			results = srvc.getData(request);
		}
		catch (Exception e) {
			logger.error("Unable to filter groups by kill switch settings.", e);
		}

		return results;
	}

	/**
	 * This method will return String which is comma separated values of provider groups which are prepared by iterating the UserAcsIndicators list
	 * 
	 * @param list
	 * @return
	 */
	protected String getCSProvGrpValsFromRequest(List<UserAcsIndicators> userAcsIndicatorsList) {
		StringBuilder provGrpCSV = new StringBuilder();
		//String appndStrng = ",";
		for (UserAcsIndicators uai : userAcsIndicatorsList) {
			provGrpCSV.append(uai.getProvGrpId());
			provGrpCSV.append(",");
		}
		if (provGrpCSV.lastIndexOf(",") != -1) {
			provGrpCSV.replace(provGrpCSV.lastIndexOf(","), provGrpCSV.length(), "");
		}

		return provGrpCSV.toString();

	}

	protected List<String> filterProvGrpsByClinicalInd(PCMSRequest request, List<String> filteredProvGrpList) throws JsonSyntaxException, ClassNotFoundException {
		if ("Y".equalsIgnoreCase(request.getShowAll())) { // if (request.getCmpId() != null && request.getCmpId().equalsIgnoreCase(Constants.VIEW_ALL_CONTENT)) { // PCMSP-683: Use showAll=Y for decisions instead
			return filteredProvGrpList;
		}
		List<String> clinicalAccessProvGrpList = new ArrayList<String>();
		if (request.getUserAcsInfoJson() != null) {
			List<UserAcsIndicators> uaiList = request.getUserAcsInfoJson();
			for (UserAcsIndicators uai : uaiList) {
				if (filteredProvGrpList.contains(uai.getProvGrpId())) {
					if (uai.getClinicalInd().equalsIgnoreCase(Constants.CLINICAL_IND_Y))
						clinicalAccessProvGrpList.add(uai.getProvGrpId());
				}

			}
		}

		return clinicalAccessProvGrpList;
	}

	protected List<String> filterProvGrpsByFinancialInd(PCMSRequest request, List<String> filteredProvGrpList) throws JsonSyntaxException, ClassNotFoundException {
		List<String> financialAccessProvGrpList = new ArrayList<String>();
		if (request.getUserAcsInfoJson() != null) {
			List<UserAcsIndicators> uaiList = request.getUserAcsInfoJson();
			for (UserAcsIndicators uai : uaiList) {
				if (filteredProvGrpList.contains(uai.getProvGrpId())) {
					if (uai.getFinancialInd().equalsIgnoreCase(Constants.CLINICAL_IND_Y)) // same constant is being used
						financialAccessProvGrpList.add(uai.getProvGrpId());
				}

			}
		}

		return financialAccessProvGrpList;
	}

	protected List<String> filterProvGrpsByClincalFinancialInd(PCMSRequest request, List<String> filteredProvGrpList) throws JsonSyntaxException, ClassNotFoundException {
		List<String> financialAccessProvGrpList = new ArrayList<String>();
		if (request.getUserAcsInfoJson() != null) {
			List<UserAcsIndicators> uaiList = request.getUserAcsInfoJson();
			for (UserAcsIndicators uai : uaiList) {
				if (filteredProvGrpList.contains(uai.getProvGrpId())) {
					if (uai.getFinancialInd().equalsIgnoreCase(Constants.CLINICAL_IND_Y) || uai.getClinicalInd().equalsIgnoreCase(Constants.CLINICAL_IND_Y)) // same constant is being used
						financialAccessProvGrpList.add(uai.getProvGrpId());
				}

			}
		}

		return financialAccessProvGrpList;
	}

	/**
	 * This method accepts list of prov grps and datamap, fetches UserAcsIndicators from the map and filters on Group access(Y/N) for all the provider group coming as list and
	 * return.
	 * 
	 * @param request
	 * @param filteredProvGrpList
	 * @return
	 */
	protected String prepareProvGrpCSVWithGrpInd(PCMSRequest request, List<String> filteredProvGrpList, String grpInd) {
		List<String> prvGrpGrpIndList = new ArrayList<String>();
		if (request.getUserAcsInfoJson() != null) {
			List<UserAcsIndicators> uaiList = request.getUserAcsInfoJson();
			for (UserAcsIndicators uai : uaiList) {
				if (filteredProvGrpList.contains(uai.getProvGrpId()) && uai.getGrpInd().equalsIgnoreCase(grpInd)) { // pass parameter instead of using Constants.GRP_IND_Y/Constants.GRP_IND_N
					prvGrpGrpIndList.add(uai.getProvGrpId());
				}

			}
		}

		return StringUtils.join(prvGrpGrpIndList, ',');
	}


	public void prepareRASuppressionCond(PCMSRequest request) {
		List<String> tempGrpSentList = new ArrayList<String>();
		List<String> tempGrpRcvdList = new ArrayList<String>();
		String uiCmpId = request.getCmpId(); // Save the original UI cmpId so request.cmpId can be reset to it
		// Suppression CR 260 | Start
		// Suppress referral.
		request.setCmpId(Constants.AC_RF_ACTIONS_BUTTON);
		tempGrpSentList = filterProvGrpsByKillSwitch(request);
		request.setProvGrpIdSentRfrls(StringUtils.join(tempGrpSentList, ','));
		// Received referrals/
		request.setCmpId(Constants.AC_RF_RECEIVEDREFERRALS);
		tempGrpRcvdList = filterProvGrpsByKillSwitch(request);
		request.setProvGrpIdRcvdRfrls(StringUtils.join(tempGrpRcvdList, ','));
		// Suppression CR 260 | END
		request.setCmpId(uiCmpId);
	}

	protected void prepareChronicCareGapMap(PCMSRequest request) {
		request.setChronicGapScores(request.getChronicCareGapsKeys());
		request.setChronicGapScoresOp(request.getChronicCareGapsKeysToggle());
		/*if (Constants.TRUE.equalsIgnoreCase(request.getChronicCareGapsKeysToggle())) {
			request.setChronicGapScoresOp(Constants.AND_OPERATOR);
		} else {
			request.setChronicGapScoresOp(Constants.OR_OPERATOR);
		}*/
	}

	// TODO make sure every calling method is storing the values in the same fields (lobIds vs lobDimKeys, etc)
	protected void removeLobPgmPrefixes(PCMSRequest request) {
		request.setLobIds(JSONUtils.removeFirstOccurenceOfCharsFromJsonString(request.getLobIds(), Constants.LOB_ID_PREFIX));
		request.setProgramIds(JSONUtils.removeFirstOccurenceOfCharsFromJsonString(request.getProgramIds(), Constants.PRGM_ID_PREFIX));
	}

	/**
	 * R1.9|LPR Suppression 61461|AD91912
	 * 
	 * @param request
	 */
	public void prepareLPRSuppressionCond(PCMSRequest request) {
		List<String> tempLPRGrps = new ArrayList<String>();
		String uiCmpId = request.getCmpId(); // Save the original UI cmpId so request.cmpId can be reset to it
		request.setCmpId(Constants.LPR_BTN_INDICATOR);
		tempLPRGrps = filterProvGrpsByKillSwitch(request);
		request.setLprActiveProviders(StringUtils.join(tempLPRGrps, ','));
		request.setCmpId(uiCmpId);
	}

	/**
	 * R1.9.2|Pharmacy Script View icon Suppression
	 * 
	 * @param request
	 */
	public void preparePharmacyScriptsIconSuppressionCond(PCMSRequest request) {
		List<String> tempPhGrps = new ArrayList<String>();
		String uiCmpId = request.getCmpId(); // Save the original UI cmpId so request.cmpId can be reset to it
		request.setCmpId(Constants.PHRMCY_SCRIPT_INDICATOR);
		request.setRowLevelSuppression(Boolean.TRUE);
		tempPhGrps = filterProvGrpsByKillSwitch(request);
		request.setPhScActiveProviders(StringUtils.join(tempPhGrps, ','));
		request.setCmpId(uiCmpId);
	}

	protected String getLOBsWithoutTotalCostSuppressed(PCMSRequest request) {
		if (!StringUtil.isSuppressedTotalCostLOBsEmpty(request)) {
			List<String> suppressed = new ArrayList<String>(request.getSuppressionForTotalCost().getSuppressedLOBs());
			List<String> filtered = new ArrayList<String>(Arrays.asList(request.getLobCtgryNm().split(",")));
			filtered.removeAll(suppressed);

			String unsuppressed = StringUtils.join(filtered, ",");
			return unsuppressed;
		}

		return request.getLobCtgryNm(); // if nothing was suppressed, return the original LOBs
	}

	protected List<String> buildColumnNameList(List<ExportGridColumn> columnObjects) {
		List<String> names = new ArrayList<String>();

		for (ExportGridColumn columnObject : columnObjects) {
			names.add(columnObject.getCategoryName()); // TODO use the column's name itself if necessary
		}

		return names;
	}

	protected MetaData buildMetaData(PCMSRequest request, ServiceImpl service) throws Exception {
		MetaData metaData = new MetaData();
		
			List<Column> columns = service.buildGridColumns(request);
			metaData.setColumns(columns);
		
		return metaData;
	}

	protected boolean isUserClinical(PCMSRequest request) {
		if (request.getUserAcsInfoJson() != null) {
			List<UserAcsIndicators> uaiList = request.getUserAcsInfoJson();
			for (UserAcsIndicators uai : uaiList) {
				if (uai.getClinicalInd().equalsIgnoreCase(Constants.CLINICAL_IND_Y))
					return true;
			}
		}
		return false;
	}
	

    protected boolean isComponentSuppressed(PCMSRequest request, String cmpntId) throws Exception {
    	AppProperties dao = new AppProperties();
		Collection<SuppressionBean> cmps = dao.getKillSwitchConfig(request.getSessionId(), request.getEntitlementId(), cmpntId);
		for (SuppressionBean cmp : cmps) {
			if (!cmp.getStatus().equalsIgnoreCase(Constants.NORMAL)) {
				return true;
			}
		}
		return false;
    }

	protected void buildProvGrpIdList(PCMSRequest request) {
		List<String> provGrpListFromRequest = new ArrayList<String>();
		for (UserAcsIndicators u : request.getUserAcsInfoJson()) {
			provGrpListFromRequest.add(u.getProvGrpId());
		}

		if (null != provGrpListFromRequest && !provGrpListFromRequest.isEmpty()) {
			request.setProvGrpIds(StringUtils.join(provGrpListFromRequest, ','));
		}
	}
}
