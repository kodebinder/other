package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.utilization.GetPAERMeasuresRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.utilization.PAERMeasuresBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;

public class PAERMeasuresDao extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(PAERMeasuresDao.class);

	public List<PAERMeasuresBean> getPAERMeasures(GetPAERMeasuresRequest request) throws Exception {

		List<PAERMeasuresBean> result = new ArrayList<PAERMeasuresBean>();

		StringBuilder query = new StringBuilder()
			.append("  select distinct msr.MSR_DSPLY_NM, msr.MSR_DIM_KEY , msr.MSR_ID "
				+ " from "
				+ " SCRCRD_PGM_MSR_HRCHY_FACT spgmhf "
				+ " INNER JOIN  ERNCNTR_FACT ef"
				+ " 			on  ef.mnth_id = spgmhf.mnth_id "
				+ " AND EF.PGM_DIM_KEY = SPGMHF.PGM_DIM_KEY "
				+ "  AND EF.MSRMNT_PRD_STRT_DT = SPGMHF.MSRMNT_PRD_STRT_DT "
				+ "  AND EF.TRNCH_DEFN_DIM_KEY = SPGMHF.TRNCH_DEFN_DIM_KEY "
				+ "      INNER JOIN SCRCRD_MSR_HRCHY_DIM smhd "
				+ "            on spgmhf.SCRCRD_MSR_HRCHY_DIM_KEY = smhd.SCRCRD_MSR_HRCHY_DIM_KEY "
				+ "      INNER JOIN MSR_DIM  msr "
				+ "            on smhd.msr_dim_key = msr.msr_dim_key"
				+ " and SPGMHF.msrmnt_prd_strt_dt >= msr.MSR_EFCTV_DT and SPGMHF.msrmnt_prd_end_dt <= msr.MSR_TRMNTN_DT"
				+ "      INNER JOIN PGM_DIM pgm "
				+ "      on spgmhf.PGM_DIM_key = pgm.PGM_DIM_KEY"
				+ " inner join PROV_GRP_DIM as PGD on ef.prov_grp_dim_key=pgd.prov_grp_dim_key "
				+ " where "
				+ "      pgm.PGM_ID = ? "
				+ "      and smhd.CMPST_DEFN_ID = ? "
				+ "      and spgmhf.MSRMNT_PRD_STRT_DT = ? "
				+ "      and spgmhf.PGM_LOB_TYPE_CD = ? "
				+ "  	and pgd.prov_grp_id = ? ");

		if (null != request.getSubCompositeId() && !request.getSubCompositeId().equalsIgnoreCase("null")) {
			query.append(" AND smhd.SUB_CMPST_DEFN_ID = ? ");
		}
		query = StringUtil.appendWithUr(query);

		try {
			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			prepareStatement(logger, query.toString());
			ps.setString(1, request.getProgramId());
			ps.setString(2, request.getCompositeId());
			ps.setString(3, request.getMeasurementPeriodStartDt());
			ps.setString(4, request.getProgramLobTypeCd().toUpperCase());
			ps.setString(5, request.getProvGrpIds());

			int i = 6;
			if (null != request.getSubCompositeId() && !request.getSubCompositeId().equalsIgnoreCase("null")) {
				ps.setString(i++, request.getSubCompositeId());
			}

			executeQuery(logger, query.toString());
			while (rs.next()) {

				PAERMeasuresBean json = new PAERMeasuresBean();

				if (rs.getString("MSR_DSPLY_NM") != null) {
					json.setMeasureName(rs.getString("MSR_DSPLY_NM"));
				}
				if (rs.getString("MSR_DIM_KEY") != null) {
					json.setMeasureDimKey(rs.getString("MSR_DIM_KEY"));
				}
				if (rs.getString("MSR_ID") != null) {
					json.setMeasureId(rs.getString("MSR_ID"));
				}

				result.add(json);
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get PAERMeasuresDao (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}


	@Override
	public boolean read(Dto o) throws Exception {

		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {


	}

	@Override
	public void update(Dto o) throws Exception {


	}

	@Override
	public void delete(Dto o) throws Exception {


	}

}
