package com.wellpoint.pc2dash.data.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.wellpoint.pc2dash.action.cmdm.GetCMDMStatusesRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.patient.CMDMStatusReasons;
import com.wellpoint.pc2dash.dto.patient.cmdm.CMDMFilter;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;

public class CMDMStatuses extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(CMDMStatuses.class);

	public List<CMDMFilter> getCMDMStatusesAndReasons(GetCMDMStatusesRequest request) throws Exception {
		List<CMDMFilter> result = new ArrayList<CMDMFilter>();

		try {
			ArrayList<CMDMStatusReasons> list = getCMDMStatusReasons();

			result = buildTreeFromList(list);

		}
		catch (Exception e) {
			throw new Exception("Exception during getCMDMStatusesAndReasons (" + request.toString() + ").", e);
		}
		finally {

			close();
		}

		return result;

	}

	public ArrayList<CMDMStatusReasons> getCMDMStatusReasons() throws Exception {
		ArrayList<CMDMStatusReasons> list = new ArrayList<CMDMStatusReasons>();

		String sql =
			"select " +
				"cdf.pgm_case_type_cd " +
				", cd_status.cd_val_nm " +
				", coalesce(upper(cd_reason.cd_val_nm),'') as rsn_val_nm " +
				", 1 seq " +
				"from crmgt_dm_fact cdf " +
				"join cd_dim cd_status on (cd_status.cd_dim_key = cdf.hlth_pgm_stts_cd_dim_key and cdf.pgm_case_type_cd in ('CM','DM')) " +
				"left join cd_dim cd_reason on (cd_reason.cd_dim_key = cdf.pgm_stts_rsn_cd_dim_key and cdf.pgm_case_type_cd in ('CM','DM')) " +
				" where cd_status.cd_dim_key is not null or cd_reason.cd_dim_key is not null " +
				"group by " +
				"cd_status.cd_set_nm " +
				", cd_reason.cd_set_nm " +
				", cd_status.cd_val_nm " +
				", upper(cd_reason.cd_val_nm) " +
				", cdf.pgm_case_type_cd " +
				"union " +
				"select 'CM' pgm_case_type_cd, 'Not Triggered' stts_cd, '' stts_rsn , 2 seq from sysibm.SYSDUMMY1 "
				+
				"union " +
				"select 'DM' pgm_case_type_cd, 'Not Triggered' stts_cd, '' stts_rsn , 2 seq from sysibm.SYSDUMMY1 "
				+
				"order by " +
				"pgm_case_type_cd ,seq  " +
				", cd_val_nm " +
				"with ur ";

		//		logger.debug("getCMDMStatusReasons SQL: " + sql);

		cn = Database.getConnection(Constants.RPT_DATASOURCE);
		prepareStatement(logger, sql);
		executeQuery(logger, sql);
		list = convertSelectedRowsToObjects();

		return list;

	}

	// Elements in HashMap will look like <"CM-Closed", CMDMStatusReason("CM","Closed","UNABLE TO REACH")>
	protected ArrayList<CMDMStatusReasons> convertSelectedRowsToObjects() throws SQLException {
		ArrayList<CMDMStatusReasons> list = new ArrayList<CMDMStatusReasons>();

		CMDMStatusReasons item = null;
		while (rs.next()) {
			item = new CMDMStatusReasons();
			item.setType(rs.getString("pgm_case_type_cd").trim());
			item.setStatus(rs.getString("cd_val_nm").trim());
			item.setReason(rs.getString("rsn_val_nm").trim());

			list.add(item);
		}

		return list;
	}

	/**
	 * 4 levels: Root --> CM/DM branches --> Status --> Status reason
	 */
	protected List<CMDMFilter> buildTreeFromList(ArrayList<CMDMStatusReasons> list) throws SQLException {
		int id = 0;
		List<String> usedCMStatuses = new ArrayList<String>();
		List<String> usedDMStatuses = new ArrayList<String>();

		// Build the Status/Reason nodes (3rd/4th level)
		List<CMDMFilter> cmStatuses = new ArrayList<CMDMFilter>();
		List<CMDMFilter> dmStatuses = new ArrayList<CMDMFilter>();

		HashMap<String, List<CMDMFilter>> maps = new HashMap<String, List<CMDMFilter>>(); // i.e. id = "CM-Active"

		for (CMDMStatusReasons item : list) {

			List<CMDMFilter> reasonList = new ArrayList<CMDMFilter>();
			if (!maps.containsKey(item.getType() + "-" + item.getStatus())) {
				maps.put(item.getType() + "-" + item.getStatus(), reasonList);
			}

			CMDMFilter status = new CMDMFilter();

			if (!item.getReason().isEmpty()) {
				status.setId(String.valueOf(++id)); // arbitrary
				status.setLeaf(false);
			}
			else {
				status.setId(StringUtil.buildUniqueStatusReasonId(
					item.getType(), item.getStatus(), item.getStatus()));// Passing
																			// status
																			// 2
																			// times
																			// as
																			// this
																			// will
																			// be
																			// executed
																			// when
																			// there
																			// is
																			// no
																			// reason
																			// in
																			// db.
				status.setLeaf(false);
			}

			status.setText(item.getStatus());


			CMDMFilter reason = new CMDMFilter();
			reason.setId(StringUtil.buildUniqueStatusReasonId(item.getType(), item.getStatus(), item.getReason()));
			reason.setText(StringUtil.capitalizeWords(item.getReason()));
			if (!item.getReason().isEmpty()) {
				reason.setLeaf(true);
			}
			else {
				reason.setLeaf(false);
			}
			reason.setChildren(new ArrayList<CMDMFilter>()); // UI wants it empty, but not null

			/*
			 * List<CMDMFilter> reasonList = new ArrayList<CMDMFilter>(); if
			 * (!maps.containsKey(item.getType() + "-" + item.getStatus())) {
			 * maps.put(item.getType() + "-" + item.getStatus(), reasonList); }
			 */

			String statusUnderscored = item.getStatus().replaceAll(" ", "_"); // WLPRD01277504 (Not Triggered is a special case, since it has two words)

			if (item.getType().equalsIgnoreCase("CM")) {
				if (!usedCMStatuses.contains(item.getStatus())) {
					usedCMStatuses.add(item.getStatus());
					cmStatuses.add(status);
					status.setChildren(maps.get("CM-" + item.getStatus()));
				}

				if (reason.getId().contains(statusUnderscored)
					&& !item.getReason().isEmpty()) {
					(maps.get("CM-" + item.getStatus())).add(reason);
				}

			}
			else if (item.getType().equalsIgnoreCase("DM")) {
				if (!usedDMStatuses.contains(item.getStatus())) {
					usedDMStatuses.add(item.getStatus());
					dmStatuses.add(status);
					status.setChildren(maps.get("DM-" + item.getStatus()));
				}

				if (reason.getId().contains(statusUnderscored)
					&& !item.getReason().isEmpty()) {
					(maps.get("DM-" + item.getStatus())).add(reason);
				}
			}

		}

		// Build the CM branch and the DM branch (2nd level)
		List<CMDMFilter> cmBranch = new ArrayList<CMDMFilter>();
		CMDMFilter cmRoot = new CMDMFilter();
		cmRoot.setId(String.valueOf(++id)); // arbitrary
		cmRoot.setText("Case Management (CM)");
		cmRoot.setLeaf(false);
		cmRoot.setChildren(cmStatuses);
		cmBranch.add(cmRoot);

		List<CMDMFilter> dmBranch = new ArrayList<CMDMFilter>();
		CMDMFilter dmRoot = new CMDMFilter();
		dmRoot.setId(String.valueOf(++id)); // arbitrary
		dmRoot.setText("Disease Management (DM)");
		dmRoot.setLeaf(false);
		dmRoot.setChildren(dmStatuses);
		dmBranch.add(dmRoot);

		// Build the "children" of the root node (1st level - to be assigned in the Action class)
		List<CMDMFilter> rootChildren = new ArrayList<CMDMFilter>();
		rootChildren.addAll(cmBranch);
		rootChildren.addAll(dmBranch);


		rootChildren = (List<CMDMFilter>) setChildLeafNode(rootChildren);

		return rootChildren;
	}



	public Collection<CMDMFilter> setChildLeafNode(Collection<CMDMFilter> tree) {
		Collection<CMDMFilter> retTree = new ArrayList<CMDMFilter>();
		Iterator<CMDMFilter> rcIter = tree.iterator();
		while (rcIter.hasNext())
		{
			CMDMFilter cmdmFltr = rcIter.next();
			if (cmdmFltr.getChildren().isEmpty())
				cmdmFltr.setLeaf(true);
			else {
				cmdmFltr.setChildren(setChildLeafNode(cmdmFltr.getChildren()));
				cmdmFltr.setLeaf(false);
			}
			retTree.add(cmdmFltr);
		}
		return retTree;

	}

	@Override
	public boolean read(Dto o) throws Exception {

		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {


	}

	@Override
	public void update(Dto o) throws Exception {


	}

	@Override
	public void delete(Dto o) throws Exception {


	}

}
