package com.wellpoint.pc2dash.action.costOpportunity;

import com.wellpoint.pc2dash.data.dto.PopulationManagementRequest;

public class GetLabCountPopupRequest extends PopulationManagementRequest {
	
	private String ipDimKey;

	public String getIpDimKey() {
		return ipDimKey;
	}

	public void setIpDimKey(String ipDimKey) {
		this.ipDimKey = ipDimKey;
	}

}
