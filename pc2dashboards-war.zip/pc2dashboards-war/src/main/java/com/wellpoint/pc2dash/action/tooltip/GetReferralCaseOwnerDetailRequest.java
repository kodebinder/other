package com.wellpoint.pc2dash.action.tooltip;

import com.wellpoint.pc2dash.data.dto.PCMSRequest;

public class GetReferralCaseOwnerDetailRequest extends PCMSRequest{
	private String referralId;

	public String getReferralId() {
		return referralId;
	}

	public void setReferralId(String referralId) {
		this.referralId = referralId;
	}
	
}
