package com.wellpoint.pc2dash.dao;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;


public class MctFact implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long mctFactKey;
	private BigDecimal adjstdAlwdAmt;
	private BigDecimal adjstdPaidAmt;
	private Integer adjstdMbrMnthCnt;
	private BigDecimal anlTrndPct;
	private BigDecimal bslnAlwdAmt;
	private Integer bslnMbrMnthCnt;
	private BigDecimal bslnPaidAmt;
	private Date bslnPrdEndDt;
	private Date bslnPrdStrtDt;
	private long creatdLoadLogKey;
	private BigDecimal dwnsdMaxSsavPct;
	private String dwnsdRiskInd;
	private BigDecimal dwnsdSsavPtntlPct;
	private String fundgSrcPoolCd;
	private long lobDimKey;
	private long mdpnlDimKey;
	private BigDecimal mnth3TrnddPmpmAmt;
	private BigDecimal mnth6TrnddPmpmAmt;
	private BigDecimal mnth9TrnddPmpmAmt;
	private BigDecimal mrktAvgRiskScorNbr;
	private Date msrmntPrdEndDt;
	private Date msrmntPrdStrtDt;
	private BigDecimal nrmlrtaRiskScorNbr;
	private long pgmDimKey;
	private String phrmcyInd;
	private Integer provGrpAdjstdMbrMnthCnt;
	private long provGrpDimKey;
	private BigDecimal provGrpNrmlrtaRiskScorNbr;
	private BigDecimal provGrpSvradjstMbrMnthCnt;
	private long pslDimKey;
	private String pslName;
	private String pslDesc;
	private String rcrdSttsCd;
	private Timestamp sorDtm;
	private BigDecimal svradjstMbrMnthCnt;
	private BigDecimal trnddCocPmpmAmt;
	private BigDecimal trnddPmpmAmt;
	private Integer unadjstdMbrCnt;
	private long updtdLoadLogKey;
	private BigDecimal upsdMaxSsavPct;
	private BigDecimal upsdRskcrdrPct;
	private BigDecimal upsdSsavPtntlPct;

	public MctFact() {}

	public Long getMctFactKey() {
		return mctFactKey;
	}

	public void setMctFactKey(Long mctFactKey) {
		this.mctFactKey = mctFactKey;
	}

	public BigDecimal getAdjstdAlwdAmt() {
		return adjstdAlwdAmt;
	}

	public void setAdjstdAlwdAmt(BigDecimal adjstdAlwdAmt) {
		this.adjstdAlwdAmt = adjstdAlwdAmt;
	}

	public BigDecimal getAdjstdPaidAmt() {
		return adjstdPaidAmt;
	}

	public void setAdjstdPaidAmt(BigDecimal adjstdPaidAmt) {
		this.adjstdPaidAmt = adjstdPaidAmt;
	}

	public Integer getAdjstdMbrMnthCnt() {
		return adjstdMbrMnthCnt;
	}

	public void setAdjstdMbrMnthCnt(Integer adjstdMbrMnthCnt) {
		this.adjstdMbrMnthCnt = adjstdMbrMnthCnt;
	}

	public BigDecimal getAnlTrndPct() {
		return anlTrndPct;
	}

	public void setAnlTrndPct(BigDecimal anlTrndPct) {
		this.anlTrndPct = anlTrndPct;
	}

	public BigDecimal getBslnAlwdAmt() {
		return bslnAlwdAmt;
	}

	public void setBslnAlwdAmt(BigDecimal bslnAlwdAmt) {
		this.bslnAlwdAmt = bslnAlwdAmt;
	}

	public Integer getBslnMbrMnthCnt() {
		return bslnMbrMnthCnt;
	}

	public void setBslnMbrMnthCnt(Integer bslnMbrMnthCnt) {
		this.bslnMbrMnthCnt = bslnMbrMnthCnt;
	}

	public BigDecimal getBslnPaidAmt() {
		return bslnPaidAmt;
	}

	public void setBslnPaidAmt(BigDecimal bslnPaidAmt) {
		this.bslnPaidAmt = bslnPaidAmt;
	}

	public Date getBslnPrdEndDt() {
		return bslnPrdEndDt;
	}

	public void setBslnPrdEndDt(Date bslnPrdEndDt) {
		this.bslnPrdEndDt = bslnPrdEndDt;
	}

	public Date getBslnPrdStrtDt() {
		return bslnPrdStrtDt;
	}

	public void setBslnPrdStrtDt(Date bslnPrdStrtDt) {
		this.bslnPrdStrtDt = bslnPrdStrtDt;
	}

	public long getCreatdLoadLogKey() {
		return creatdLoadLogKey;
	}

	public void setCreatdLoadLogKey(long creatdLoadLogKey) {
		this.creatdLoadLogKey = creatdLoadLogKey;
	}

	public BigDecimal getDwnsdMaxSsavPct() {
		return dwnsdMaxSsavPct;
	}

	public void setDwnsdMaxSsavPct(BigDecimal dwnsdMaxSsavPct) {
		this.dwnsdMaxSsavPct = dwnsdMaxSsavPct;
	}

	public String getDwnsdRiskInd() {
		return dwnsdRiskInd;
	}

	public void setDwnsdRiskInd(String dwnsdRiskInd) {
		this.dwnsdRiskInd = dwnsdRiskInd;
	}

	public BigDecimal getDwnsdSsavPtntlPct() {
		return dwnsdSsavPtntlPct;
	}

	public void setDwnsdSsavPtntlPct(BigDecimal dwnsdSsavPtntlPct) {
		this.dwnsdSsavPtntlPct = dwnsdSsavPtntlPct;
	}

	public String getFundgSrcPoolCd() {
		return fundgSrcPoolCd;
	}

	public void setFundgSrcPoolCd(String fundgSrcPoolCd) {
		this.fundgSrcPoolCd = fundgSrcPoolCd;
	}

	public long getLobDimKey() {
		return lobDimKey;
	}

	public void setLobDimKey(long lobDimKey) {
		this.lobDimKey = lobDimKey;
	}

	public long getMdpnlDimKey() {
		return mdpnlDimKey;
	}

	public void setMdpnlDimKey(long mdpnlDimKey) {
		this.mdpnlDimKey = mdpnlDimKey;
	}

	public BigDecimal getMnth3TrnddPmpmAmt() {
		return mnth3TrnddPmpmAmt;
	}

	public void setMnth3TrnddPmpmAmt(BigDecimal mnth3TrnddPmpmAmt) {
		this.mnth3TrnddPmpmAmt = mnth3TrnddPmpmAmt;
	}

	public BigDecimal getMnth6TrnddPmpmAmt() {
		return mnth6TrnddPmpmAmt;
	}

	public void setMnth6TrnddPmpmAmt(BigDecimal mnth6TrnddPmpmAmt) {
		this.mnth6TrnddPmpmAmt = mnth6TrnddPmpmAmt;
	}

	public BigDecimal getMnth9TrnddPmpmAmt() {
		return mnth9TrnddPmpmAmt;
	}

	public void setMnth9TrnddPmpmAmt(BigDecimal mnth9TrnddPmpmAmt) {
		this.mnth9TrnddPmpmAmt = mnth9TrnddPmpmAmt;
	}

	public BigDecimal getMrktAvgRiskScorNbr() {
		return mrktAvgRiskScorNbr;
	}

	public void setMrktAvgRiskScorNbr(BigDecimal mrktAvgRiskScorNbr) {
		this.mrktAvgRiskScorNbr = mrktAvgRiskScorNbr;
	}

	public Date getMsrmntPrdEndDt() {
		return msrmntPrdEndDt;
	}

	public void setMsrmntPrdEndDt(Date msrmntPrdEndDt) {
		this.msrmntPrdEndDt = msrmntPrdEndDt;
	}

	public Date getMsrmntPrdStrtDt() {
		return msrmntPrdStrtDt;
	}

	public void setMsrmntPrdStrtDt(Date msrmntPrdStrtDt) {
		this.msrmntPrdStrtDt = msrmntPrdStrtDt;
	}

	public BigDecimal getNrmlrtaRiskScorNbr() {
		return nrmlrtaRiskScorNbr;
	}

	public void setNrmlrtaRiskScorNbr(BigDecimal nrmlrtaRiskScorNbr) {
		this.nrmlrtaRiskScorNbr = nrmlrtaRiskScorNbr;
	}

	public long getPgmDimKey() {
		return pgmDimKey;
	}

	public void setPgmDimKey(long pgmDimKey) {
		this.pgmDimKey = pgmDimKey;
	}

	public String getPhrmcyInd() {
		return phrmcyInd;
	}

	public void setPhrmcyInd(String phrmcyInd) {
		this.phrmcyInd = phrmcyInd;
	}

	public Integer getProvGrpAdjstdMbrMnthCnt() {
		return provGrpAdjstdMbrMnthCnt;
	}

	public void setProvGrpAdjstdMbrMnthCnt(Integer provGrpAdjstdMbrMnthCnt) {
		this.provGrpAdjstdMbrMnthCnt = provGrpAdjstdMbrMnthCnt;
	}

	public long getProvGrpDimKey() {
		return provGrpDimKey;
	}

	public void setProvGrpDimKey(long provGrpDimKey) {
		this.provGrpDimKey = provGrpDimKey;
	}

	public BigDecimal getProvGrpNrmlrtaRiskScorNbr() {
		return provGrpNrmlrtaRiskScorNbr;
	}

	public void setProvGrpNrmlrtaRiskScorNbr(BigDecimal provGrpNrmlrtaRiskScorNbr) {
		this.provGrpNrmlrtaRiskScorNbr = provGrpNrmlrtaRiskScorNbr;
	}

	public BigDecimal getProvGrpSvradjstMbrMnthCnt() {
		return provGrpSvradjstMbrMnthCnt;
	}

	public void setProvGrpSvradjstMbrMnthCnt(BigDecimal provGrpSvradjstMbrMnthCnt) {
		this.provGrpSvradjstMbrMnthCnt = provGrpSvradjstMbrMnthCnt;
	}

	public long getPslDimKey() {
		return pslDimKey;
	}

	public void setPslDimKey(long pslDimKey) {
		this.pslDimKey = pslDimKey;
	}

	public String getPslName() {
		return pslName;
	}

	public void setPslName(String pslName) {
		this.pslName = pslName;
	}

	public String getPslDesc() {
		return pslDesc;
	}

	public void setPslDesc(String pslDesc) {
		this.pslDesc = pslDesc;
	}

	public String getRcrdSttsCd() {
		return rcrdSttsCd;
	}

	public void setRcrdSttsCd(String rcrdSttsCd) {
		this.rcrdSttsCd = rcrdSttsCd;
	}

	public Timestamp getSorDtm() {
		return sorDtm;
	}

	public void setSorDtm(Timestamp sorDtm) {
		this.sorDtm = sorDtm;
	}

	public BigDecimal getSvradjstMbrMnthCnt() {
		return svradjstMbrMnthCnt;
	}

	public void setSvradjstMbrMnthCnt(BigDecimal svradjstMbrMnthCnt) {
		this.svradjstMbrMnthCnt = svradjstMbrMnthCnt;
	}

	public BigDecimal getTrnddCocPmpmAmt() {
		return trnddCocPmpmAmt;
	}

	public void setTrnddCocPmpmAmt(BigDecimal trnddCocPmpmAmt) {
		this.trnddCocPmpmAmt = trnddCocPmpmAmt;
	}

	public BigDecimal getTrnddPmpmAmt() {
		return trnddPmpmAmt;
	}

	public void setTrnddPmpmAmt(BigDecimal trnddPmpmAmt) {
		this.trnddPmpmAmt = trnddPmpmAmt;
	}

	public Integer getUnadjstdMbrCnt() {
		return unadjstdMbrCnt;
	}

	public void setUnadjstdMbrCnt(Integer unadjstdMbrCnt) {
		this.unadjstdMbrCnt = unadjstdMbrCnt;
	}

	public long getUpdtdLoadLogKey() {
		return updtdLoadLogKey;
	}

	public void setUpdtdLoadLogKey(long updtdLoadLogKey) {
		this.updtdLoadLogKey = updtdLoadLogKey;
	}

	public BigDecimal getUpsdMaxSsavPct() {
		return upsdMaxSsavPct;
	}

	public void setUpsdMaxSsavPct(BigDecimal upsdMaxSsavPct) {
		this.upsdMaxSsavPct = upsdMaxSsavPct;
	}

	public BigDecimal getUpsdRskcrdrPct() {
		return upsdRskcrdrPct;
	}

	public void setUpsdRskcrdrPct(BigDecimal upsdRskcrdrPct) {
		this.upsdRskcrdrPct = upsdRskcrdrPct;
	}

	public BigDecimal getUpsdSsavPtntlPct() {
		return upsdSsavPtntlPct;
	}

	public void setUpsdSsavPtntlPct(BigDecimal upsdSsavPtntlPct) {
		this.upsdSsavPtntlPct = upsdSsavPtntlPct;
	}
}
