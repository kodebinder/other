package com.wellpoint.pc2dash.action.scorecardTrending;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.scorecardTrending.ScorecardTrendingGraphJson;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.scorecardTrending.ScorecardTrendingExport;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.scorecardTrending.ScorecardTrendingServiceImpl;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;

/**
 * Action Class to service the graph data request on Scorecard Trending Tab
 * 
 * @author ad91912
 *
 */
public class ScorecardTrendingAction extends Action {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(ScorecardTrendingAction.class);

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		ScorecardTrendingRequest request = (ScorecardTrendingRequest) actionRequest;
		ScorecardTrendingResponse result = new ScorecardTrendingResponse();
		ErrorProperties err = ErrorProperties.getInstance();

		try {

			List<String> grps = new ArrayList<String>();

			// Kill switch check on Provider groups
			if (StringUtils.isNotBlank(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			// Clinical & Financial access check on provider groups
			if (null != grps && grps.size() > 0) {
				grps = filterProvGrpsByClincalFinancialInd(request, grps);
				//request.setProvGrpIds(StringUtils.join(grps, ','));
			}

			request.setProvGrpIds(StringUtils.join(grps, ','));
			//PCMSP-11853
			if(null == request.getMedicalPanelId()){
				request.setMedicalPanelId("");
			}
			
			if (StringUtil.isExportDest(request.getDest())) {

				ScorecardTrendingExport exp = new ScorecardTrendingExport(request);
				ExportProcessor.getInstance().submit(exp);
			}
			else {

				ScorecardTrendingServiceImpl service = new ScorecardTrendingServiceImpl();
				List<ScorecardTrendingGraphJson> vals = service.getData(request);

				if (null == vals || (null != vals && vals.isEmpty())) {

					result.setMessage(err.getProperty("successNoData"));
					result.setData(vals);
					result.setTotal(0);
				}
				else {

					result.setMessage(err.getProperty("successful"));
					result.setData(vals);
					result.setTotal(vals.size());
				}
			}

			result.setSuccess(true);
		}
		catch (Exception e) {

			logger.error("Unable to retrieve Scorecard composite  detail.", e);

			result.setMessage("Unable to retrieve Scorecard composite  detail.");
			result.setSuccess(false);
		}

		return result;
	}
}
