package com.wellpoint.pc2dash.action.pharmacy;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.data.dao.PharmacyProviderDao;
import com.wellpoint.pc2dash.dto.pharmacy.PharmacyProviderGrid;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportGridColumn;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.population.PharmacyProviderExport;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetPharmacyProvidersAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetPharmacyProvidersRequest request = (GetPharmacyProvidersRequest) actionRequest;
		ActionResponse response = new GetPharmacyProvidersResponse();
		ErrorProperties err = ErrorProperties.getInstance();

		List<PharmacyProviderGrid> resultList = new ArrayList<PharmacyProviderGrid>();
		PharmacyProviderDao dao = new PharmacyProviderDao();
		List<String> grps = null;

		try {

			removeLobPgmPrefixes(request);

			if (StringUtils.isNotBlank(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			if (!StringUtil.isExportDest(request.getDest())) {
				preparePharmacyScriptsIconSuppressionCond(request);
			}

			if (null != grps && !grps.isEmpty()) {

				request.setProvGrpIdsWithoutClinicalCheck(StringUtils.join(grps, ','));
				grps = filterProvGrpsByClinicalInd(request, grps);
				request.setProvGrpIds(StringUtils.join(grps, ','));
			}

			if (StringUtil.isExportDest(request.getDest())) {

				List<ExportGridColumn> columns = dao.buildExportGridColumns(request);
				PharmacyProviderExport exp = new PharmacyProviderExport(request, columns);

				ExportProcessor.getInstance().submit(exp);

			}
			else {

				if (null != grps && !grps.isEmpty()) {

					resultList = dao.getProviderGrid(request);
					CommonQueries cq = new CommonQueries();

					MetaData metaData = buildMetaData(request, dao);
					metaData.setReportingPeriod(cq.getReportingPeriodForPharmacy());

					if (null == resultList || resultList.isEmpty()) {
						response.setMessage(err.getProperty("successNoData"));
					}
					else {
						response.setMetaData(metaData);
						response.setMessage(err.getProperty("successful"));
						response.setData(resultList);
						response.setTotal(dao.getRowCount());
					}
				}
			}

			response.setSuccess(true);
			return response;
		}
		catch (Exception pe) {
			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}

}
