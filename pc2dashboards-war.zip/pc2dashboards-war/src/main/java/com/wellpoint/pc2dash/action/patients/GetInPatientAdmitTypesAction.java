package com.wellpoint.pc2dash.action.patients;

import java.util.List;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.patient.InPatientAdmitTypesBean;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.patient.InPatientAdmitTypesServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;

/**
 * @author AD90349
 *
 */
public class GetInPatientAdmitTypesAction extends Action {

	ActionResponse response = new GetVisitsResponse();
	ErrorProperties err = ErrorProperties.getInstance();
	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetInPatientAdmitTypesAction.class);

	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		//logger.trace("Entry: process() of GetInPatientAdmitTypesAction");

		List<InPatientAdmitTypesBean> resultList;

		//PCMSRequest request = new HashMap<String, String>();
		GetVisitsRequest request = (GetVisitsRequest) actionRequest;
		//		String cardId = request.getCardId();
		//		if (cardId != null) {
		//			request.put(Constants.CARD_ID, cardId);
		//		}
		InPatientAdmitTypesServiceImpl service = new InPatientAdmitTypesServiceImpl();

		try {

			resultList = service.getData(request);

			response = populateResponse(resultList);
			response.setSuccess(true);

			if (resultList.isEmpty()) {
				response.setMessage(err.getProperty(Constants.SUCCESS_NO_DATA));
			}
			else {
				response.setMessage(err.getProperty(Constants.SUCCESSFUL));
			}
			//logger.trace("Exit: process() of GetInPatientAdmitTypesAction");
			return response;
		}
		catch (Exception pe) {

			logger.error(Constants.INPAT_ADMT_TYPE_EXCPTN_MSG, pe);
			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}

	/**
	 * @param admitTypeList
	 * @return
	 */
	private ActionResponse populateResponse(List<InPatientAdmitTypesBean> admitTypeList) {
		((GetVisitsResponse) (response)).setData(admitTypeList);
		//logger.trace("Entry: populateResponse() of GetInPatientAdmitTypesAction");
		//logger.trace("Exit: populateResponse() of GetInPatientAdmitTypesAction");
		return response;
	}

}
