package com.wellpoint.pc2dash.data.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.costOpportunity.GetLierCategoryViewSubMetricRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.costOpportunity.LierCategoryViewSubMetricBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class LierCategoryViewSubMetricFactsDao extends ServiceImpl {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(LierCategoryViewSubMetricFactsDao.class);

	private boolean displayDashes = false; //PCMSP-6863

	public List<LierCategoryViewSubMetricBean> getLierSubMetricdata(GetLierCategoryViewSubMetricRequest request, boolean exportFlag, int index, int limit) throws Exception {

		List<LierCategoryViewSubMetricBean> result = new ArrayList<LierCategoryViewSubMetricBean>();
		//String multiplePgmCheck_10_Perc = " or  ((SUM(count(distinct s.BNCHMRK_10_PCTILE_AMT)) over (partition by s.SUB_MTRC_CD, s.SUB_MTRC_NM)) > 1) ";
		//String multiplePgmCheck_90_Perc = " or  ((SUM(count(distinct s.BNCHMRK_90_PCTILE_AMT)) over (partition by s.SUB_MTRC_CD, s.SUB_MTRC_NM)) > 1) ";

		setRowCount(0);

		StringBuilder query = new StringBuilder()

			.append("select ")
			.append("	a.* ")
			.append("from ")
			.append("	( ")
			.append(" select ")
			.append(" row_number() over ( ")
			.append("    order by ")
			.append(buildSortClause(request))
			.append(" ) as row_nbr, ")
			.append(" SUB_MTRC_CD,SUB_MTRC_NM,COST_OPRTNTY_AMT,COST_OPRTNTY_10_PCTAG_AMT,PMPM_OPRTNTY_AMT,PMPM_OPRTNTY_10_PCTAG_AMT,MBR_MNTH_CNT,LIER_VST_CNT, ")
			.append(" CURRENT_PERF_RATE,BNCHMRK_90_PCTILE_AMT,BNCHMRK_10_PCTILE_AMT,dsply_dashes,BNCH_90_CNT,BNCH_10_CNT,row_cnt ")
			.append(" from( select ")
			.append(" s.SUB_MTRC_CD, ")
			.append(" s.SUB_MTRC_NM, ")
			.append(" case  ")
			.append(
				" when (s.SUB_MTRC_CD ='A' and ILV.MEM_MNTH_ADLT < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LIER_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG')) ")
			.append(
				" or (s.SUB_MTRC_CD ='P' and ILV.MEM_MNTH_PED < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LIER_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG')) ")
			.append(" then -1.00 ")
			.append(" when sum(s.COST_OPRTNTY_AMT) >=0 then cast(sum(s.COST_OPRTNTY_AMT) as Decimal(18,4)) else 0.00 end as COST_OPRTNTY_AMT, ")
			.append(" case ")
			.append(
				" when (s.SUB_MTRC_CD ='A' and ILV.MEM_MNTH_ADLT < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LIER_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG')) ")
			.append(
				" or (s.SUB_MTRC_CD ='P' and ILV.MEM_MNTH_PED < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LIER_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG')) ")
			.append(" then -1.00 ")
			.append(" when sum(s.COST_OPRTNTY_10_PCTAG_AMT) >= 0 then cast(sum(s.COST_OPRTNTY_10_PCTAG_AMT) as Decimal(18,4)) else 0.00 end as COST_OPRTNTY_10_PCTAG_AMT, ")
			.append(" case  ")
			.append(
				" when (s.SUB_MTRC_CD ='A' and ILV.MEM_MNTH_ADLT < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LIER_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG')) ")
			.append(
				" or (s.SUB_MTRC_CD ='P' and ILV.MEM_MNTH_PED < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LIER_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG')) ")
			.append(" then -1.00 ")
			.append(
				" when ILV.MEM_MNTH_TOTL > 0 and sum(s.COST_OPRTNTY_AMT)  >= 0 then (cast(sum(s.COST_OPRTNTY_AMT) as Decimal(18,4)) / cast(ILV.MEM_MNTH_TOTL as Decimal(18,4))) else 0.00 end as PMPM_OPRTNTY_AMT,  ")
			.append(" case  ")
			.append(
				" when (s.SUB_MTRC_CD ='A' and ILV.MEM_MNTH_ADLT < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LIER_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG')) ")
			.append(
				" or (s.SUB_MTRC_CD ='P' and ILV.MEM_MNTH_PED < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LIER_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG')) ")
			.append(" then -1.00 ")
			.append(
				" when ILV.MEM_MNTH_TOTL > 0 and sum(s.COST_OPRTNTY_10_PCTAG_AMT)  >= 0 then (cast(sum(s.COST_OPRTNTY_10_PCTAG_AMT) as Decimal(18,4)) / cast(ILV.MEM_MNTH_TOTL as Decimal(18,4))) else 0.00 end as PMPM_OPRTNTY_10_PCTAG_AMT, ")
			.append(" case  ")
			.append(
				" when s.SUB_MTRC_CD ='A' and ILV.MEM_MNTH_ADLT  >= (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LIER_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG') then ILV.MEM_MNTH_ADLT  ")
			.append(
				" when s.SUB_MTRC_CD ='P' and ILV.MEM_MNTH_PED  >= (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LIER_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG') then ILV.MEM_MNTH_PED  ")
			.append("  else -1 end as MBR_MNTH_CNT, ")
			.append(" case  ")
			.append(
				" when (s.SUB_MTRC_CD ='A' and ILV.MEM_MNTH_ADLT < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LIER_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG')) ")
			.append(
				" or (s.SUB_MTRC_CD ='P' and ILV.MEM_MNTH_PED < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LIER_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG')) ")
			.append(" then -1.00 ")
			.append(" else sum(s.LIER_VST_CNT) end as LIER_VST_CNT, ")
			.append(" case ")
			.append(
				" when (s.SUB_MTRC_CD ='A' and ILV.MEM_MNTH_ADLT < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LIER_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG')) ")
			.append(
				" or (s.SUB_MTRC_CD ='P' and ILV.MEM_MNTH_PED < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LIER_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG')) ")
			.append(" then -1.00 ")
			.append(" else ( ")
			.append("  case ")
			.append("  when s.SUB_MTRC_CD ='A' and ILV.MEM_MNTH_ADLT > 0 then  (cast(sum(LIER_VST_CNT) as decimal (18,4)) / cast(ILV.MEM_MNTH_ADLT as decimal (18,4)) * 12000)  ")
			.append("  when s.SUB_MTRC_CD ='P' and ILV.MEM_MNTH_PED > 0 then  (cast(sum(LIER_VST_CNT) as decimal (18,4)) / cast(ILV.MEM_MNTH_PED as decimal (18,4)) * 12000)  ")
			.append("  else 0.00 end ) ")
			.append("  end as CURRENT_PERF_RATE, ")
			.append(" case ")
			.append(
				" when (s.SUB_MTRC_CD ='A' and ILV.MEM_MNTH_ADLT < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LIER_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG')) ")
			.append(
				" or (s.SUB_MTRC_CD ='P' and ILV.MEM_MNTH_PED < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LIER_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG')) ")
			.append(" then -1.00 ")
			.append(" else max(s.BNCHMRK_90_PCTILE_AMT) end as BNCHMRK_90_PCTILE_AMT,    ")
			.append(" case ")
			.append(
				" when (s.SUB_MTRC_CD ='A' and ILV.MEM_MNTH_ADLT < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LIER_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG')) ")
			.append(
				" or (s.SUB_MTRC_CD ='P' and ILV.MEM_MNTH_PED < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LIER_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG')) ")
			.append(" then -1.00 ")
			.append(" else max(s.BNCHMRK_10_PCTILE_AMT) end as BNCHMRK_10_PCTILE_AMT,   ")
			.append(" case ")
			.append(
				" when (s.SUB_MTRC_CD ='A' and ILV.MEM_MNTH_ADLT < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LIER_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG')) ")
			.append(
				" or (s.SUB_MTRC_CD ='P' and ILV.MEM_MNTH_PED < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LIER_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG')) ")
			.append(" then 'Y' else 'N' end as dsply_dashes,  ")
			.append(" case ")
			.append(
				" when (s.SUB_MTRC_CD ='A' and ILV.MEM_MNTH_ADLT < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LIER_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG')) ")
			.append(
				" or (s.SUB_MTRC_CD ='P' and ILV.MEM_MNTH_PED < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LIER_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG')) ")
			.append(" then 0 else SUM(count(distinct s.BNCHMRK_90_PCTILE_AMT)) over (partition by s.SUB_MTRC_CD, s.SUB_MTRC_NM) end as BNCH_90_CNT,  ")
			.append(" case ")
			.append(
				" when (s.SUB_MTRC_CD ='A' and ILV.MEM_MNTH_ADLT < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LIER_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG')) ")
			.append(
				" or (s.SUB_MTRC_CD ='P' and ILV.MEM_MNTH_PED < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LIER_MIN_TOTL_SCRPT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG')) ")
			.append(" then 0 else SUM(count(distinct s.BNCHMRK_10_PCTILE_AMT)) over (partition by s.SUB_MTRC_CD, s.SUB_MTRC_NM) end as BNCH_10_CNT, ")
			.append(" count(*) over () as row_cnt ")
			.append(" from ")
			.append(" coc_lier_ctgry_smry s ")
			.append(" join( ")
			.append(" select ")
			/*.append(" nvl(SUM(CASE WHEN PSF.AGE_NBR >= 18 THEN MM.MBR_MNTH_12_CNT ELSE 0 END),0)  as MEM_MNTH_ADLT, ")
			.append(" nvl(SUM(CASE WHEN PSF.AGE_NBR < 18 THEN MM.MBR_MNTH_12_CNT ELSE 0 END),0)  as MEM_MNTH_PED, ")
			.append(" nvl(SUM(MM.MBR_MNTH_12_CNT),0) as MEM_MNTH_TOTL ")
			.append(" FROM  PAT_SMRY_FACT PSF  ")
			.append(" INNER JOIN MSTR_CNSMR_MBR_MNTH_FACT MM ON  ")
			.append(" MM.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY  ")
			.append(" AND MM.RCRD_STTS_CD = 'ACT' ")
			.append(" AND PSF.ATRBN_STTS_CD = 'ACTIVE' ");*/
			.append(" NVL(SUM(CASE WHEN LS.SUB_MTRC_CD='A' THEN LS.MBR_MNTH_CNT ELSE 0 END),  0) AS MEM_MNTH_ADLT, ")
			.append(" NVL( SUM(CASE WHEN LS.SUB_MTRC_CD='P' THEN LS.MBR_MNTH_CNT ELSE 0 END),  0) AS MEM_MNTH_PED, ")
			.append(" NVL( SUM(LS.MBR_MNTH_CNT), 0) AS MEM_MNTH_TOTL FROM COC_LIER_CTGRY_SMRY LS where  ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" LS.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and LS.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and LS.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		// Organization filter
		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and LS.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and LS.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}

		query.append(" )as ilv on (1=1) ")
			.append(" join poit_user_scrty_acs pusa on ( ")
			.append(" s.prov_grp_id = pusa.prov_grp_id ")
			.append(" and ")
			.append(" case ")
			.append(" when  pusa.prov_org_tax_id = '0' then  s.prov_org_tax_id ")
			.append(" else  pusa.prov_org_tax_id ")
			.append(" end = s.prov_org_tax_id ")
			.append(" ) ")
			.append(" where ")
			.append("  pusa.sesn_id = ? ")
			.append(" and pusa.enttlmnt_hash_key = ? ");



		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and s.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and s.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and s.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		// Organization filter
		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and s.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and s.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}

		query.append(" group by  s.SUB_MTRC_CD, s.SUB_MTRC_NM ,ILV.MEM_MNTH_ADLT ,ILV.MEM_MNTH_PED, ILV.MEM_MNTH_TOTL ");
		query.append(") )a ");
		query.append(" where a.row_nbr between ? and ? ");

		query.append(" order by a.row_nbr ");
		query.append(" with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			
			int start = 0;
			int stop = 0;
			
			prepareStatement(logger, query.toString());

			//For PMPM Starts
			// Group Ids
			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// Program filters
			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// LOB filters
			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// Organization filter
			if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
				String[] array = request.getProvDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, StringUtil.parseProviderId(item));
				}
			}
			if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
				String[] array = request.getOrgDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			//For PMPM Ends

			ps.setString(++i, request.getSessionId());
			ps.setString(++i, request.getEntitlementId());

			// Group Ids
			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// Program filters
			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// LOB filters
			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// Organization filter
			if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
				String[] array = request.getProvDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, StringUtil.parseProviderId(item));
				}
			}
			if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
				String[] array = request.getOrgDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (!exportFlag) {
				start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
				stop = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
			}
			else {
				start = index;
				stop = limit;
			}
			ps.setInt(++i, start + 1);
			ps.setInt(++i, start + stop);

			executeQuery(logger, query.toString());

			while (rs.next()) {
				
				setTotalExport(rs.getInt("row_cnt"));   

				LierCategoryViewSubMetricBean jsonResult = new LierCategoryViewSubMetricBean();

				if (rs.getString("dsply_dashes") != null && rs.getString("dsply_dashes").equalsIgnoreCase(Constants.Y)) {
					displayDashes = true;
				}
				else {
					displayDashes = false;
				}
				jsonResult.setCategory(StringUtil.getValueOrDashes(rs.getString("SUB_MTRC_NM")));

				//PCMSP-6863 changes starts
				if (!displayDashes) {
					// PCMSP-5616 changes
					if (rs.getString("COST_OPRTNTY_AMT") != null)
						jsonResult.setTotalOpportunity(
							exportFlag ? StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("COST_OPRTNTY_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString())
								: rs.getBigDecimal("COST_OPRTNTY_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
				}
				else {
					jsonResult.setTotalOpportunity(Constants.DASHES);
				}

				if (!displayDashes) {
					if (rs.getString("COST_OPRTNTY_10_PCTAG_AMT") != null)
						jsonResult.setTenPercentImprovement(
							exportFlag ? StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("COST_OPRTNTY_10_PCTAG_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString())
								: rs.getBigDecimal("COST_OPRTNTY_10_PCTAG_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
				}
				else {
					jsonResult.setTenPercentImprovement(Constants.DASHES);
				}
				if (!displayDashes) {
					if (rs.getString("PMPM_OPRTNTY_AMT") != null)
						jsonResult.setTotalOpportunityPMPM(
							exportFlag ? StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("PMPM_OPRTNTY_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString())
								: rs.getBigDecimal("PMPM_OPRTNTY_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
				}
				else {
					jsonResult.setTotalOpportunityPMPM(Constants.DASHES);
				}
				if (!displayDashes) {
					if (rs.getString("PMPM_OPRTNTY_10_PCTAG_AMT") != null)
						jsonResult.setTenPercentImprovementPMPM(
							exportFlag ? StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("PMPM_OPRTNTY_10_PCTAG_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString())
								: rs.getBigDecimal("PMPM_OPRTNTY_10_PCTAG_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
				}
				else {
					jsonResult.setTenPercentImprovementPMPM(Constants.DASHES);
				}
				if (!displayDashes) {
					if (rs.getString("MBR_MNTH_CNT") != null)
						jsonResult.setMemberMonths(exportFlag
							? (StringUtil.convertStringToCommaBigDecimal(rs.getBigDecimal("MBR_MNTH_CNT")
								.setScale(0, BigDecimal.ROUND_HALF_UP).toString(), 0))
							: rs.getBigDecimal("MBR_MNTH_CNT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
				}
				else {
					jsonResult.setMemberMonths(Constants.DASHES);
				}
				if (!displayDashes) {
					if (rs.getString("LIER_VST_CNT") != null)
						jsonResult.setTotalVisits(exportFlag
							? (StringUtil.convertStringToCommaBigDecimal(rs.getBigDecimal("LIER_VST_CNT")
								.setScale(0, BigDecimal.ROUND_HALF_UP).toString(), 0))
							: rs.getBigDecimal("LIER_VST_CNT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
				}
				else {
					jsonResult.setTotalVisits(Constants.DASHES);
				}
				if (!displayDashes) {
					if (rs.getString("CURRENT_PERF_RATE") != null)
						jsonResult.setCurrentPerformanceRate(rs.getBigDecimal("CURRENT_PERF_RATE").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
				}
				else {
					jsonResult.setCurrentPerformanceRate(Constants.DASHES);
				}
				if (!displayDashes && rs.getShort("BNCH_90_CNT") == Constants.INT_ONE) {
					if (rs.getString("BNCHMRK_90_PCTILE_AMT") != null)
						jsonResult.setPercentileBenchmark90(rs.getBigDecimal("BNCHMRK_90_PCTILE_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
				}
				else {
					jsonResult.setPercentileBenchmark90(Constants.DASHES);
				}
				if (!displayDashes && rs.getShort("BNCH_10_CNT") == Constants.INT_ONE) {
					if (rs.getString("BNCHMRK_10_PCTILE_AMT") != null)
						jsonResult.setPercentileBenchmark10(rs.getBigDecimal("BNCHMRK_10_PCTILE_AMT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
				}
				else {
					jsonResult.setPercentileBenchmark10(Constants.DASHES);
				}
				if (displayDashes) {
					jsonResult.setHasLIERDrilldownInd(Constants.BOOL_FALSE);
				}
				else {
					jsonResult.setHasLIERDrilldownInd(request.isHasLIERDrilldownInd());
				}

				result.add(jsonResult);
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get LierCategoryViewSubMetricFactsDao (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}
		return result;

	}


	private String buildSortClause(GetLierCategoryViewSubMetricRequest request) {

		StringBuilder query = new StringBuilder();

		for (QuerySort sort : request.getSort()) {
			String dir = sort.getDirection().replaceAll("\"", "");
			String property = sort.getProperty();

			if (property.equals("category")) {
				query.append(" SUB_MTRC_NM " + dir);
			}
			if (property.equals("totalOpportunity")) {
				query.append(" case when COST_OPRTNTY_AMT < 0 then 1 else 0 end,COST_OPRTNTY_AMT " + dir);
			}
			if (property.equals("tenPercentImprovement")) {
				query.append(" case when COST_OPRTNTY_10_PCTAG_AMT < 0 then 1 else 0 end,COST_OPRTNTY_10_PCTAG_AMT " + dir);
			}
			if (property.equals("totalOpportunityPMPM")) {
				query.append(" case when PMPM_OPRTNTY_AMT < 0 then 1 else 0 end,PMPM_OPRTNTY_AMT " + dir);
			}
			if (property.equals("tenPercentImprovementPMPM")) {
				query.append(" case when PMPM_OPRTNTY_10_PCTAG_AMT < 0 then 1 else 0 end,PMPM_OPRTNTY_10_PCTAG_AMT " + dir);
			}
			if (property.equals("memberMonths")) {
				query.append(" case when MBR_MNTH_CNT < 0 then 1 else 0 end,MBR_MNTH_CNT " + dir);
			}
			if (property.equals("totalVisits")) {
				query.append(" case when LIER_VST_CNT < 0 then 1 else 0 end,LIER_VST_CNT " + dir);
			}
			if (property.equals("currentPerformanceRate")) {
				query.append(" case when CURRENT_PERF_RATE < 0 then 1 else 0 end,CURRENT_PERF_RATE " + dir);
			}
			if (property.equals("percentileBenchmark90")) {
				query.append(" case when BNCHMRK_90_PCTILE_AMT < 0 then 1 else 0 end,BNCHMRK_90_PCTILE_AMT " + dir);
			}
			if (property.equals("percentileBenchmark10")) {
				query.append(" case when BNCHMRK_10_PCTILE_AMT < 0 then 1 else 0 end,BNCHMRK_10_PCTILE_AMT " + dir);
			}
		}

		return query.toString();
	}

}
