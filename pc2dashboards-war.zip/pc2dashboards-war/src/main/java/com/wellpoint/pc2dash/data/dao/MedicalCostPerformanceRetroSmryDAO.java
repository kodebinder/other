package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;
import com.wellpoint.pc2dash.dto.medicalCostBaseline.McbSmryDto;
import com.wellpoint.pc2dash.exception.PC2Exception;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;

public class MedicalCostPerformanceRetroSmryDAO extends AbstractDao{
	
	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(MedicalCostPerformanceRetroSmryDAO.class);
	
	@Override
	public boolean read(Dto o) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Dto o) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Dto o) throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	public List<McbSmryDto> getMcpRetroMetricData(PerformanceManagementRequest request) throws PC2Exception {
		List<McbSmryDto> resultList = new ArrayList<McbSmryDto>();
		try {
			StringBuilder query = new StringBuilder();

			query.append("SELECT ")
				.append("  MTRC_CD ")
				.append(", MTRC_NM ")
				.append(", PHRMCY_IND ")
				.append(", PSL_ID ")
				.append(", PG_PROD_NBR ")
				.append(", PROD_MDCL_NBR ")
				.append(", mcprsf.INTRVL_MNTH_CNT ")
				.append(", PG_IND ")
				.append(" FROM ")
				.append(" MCP_RETRO_FACT_SMRY mcprsf")
				.append(" join LOB_DIM lob on (mcprsf.LOB_DIM_KEY = lob.LOB_DIM_KEY)")
				.append(" WHERE ")
				.append(" mcprsf.MSRMNT_PRD_STRT_DT = ? ")
				.append(" AND mcprsf.MSRMNT_PRD_END_DT = ? ")
				.append(" AND mcprsf.PROV_GRP_ID = ? ") // switched from PROV_GRP_DIM_KEY for suppression purposes
				.append(" AND mcprsf.PGM_ID = ? ")
				.append(" AND lob.LOB_DESC = ? ")
				.append(" AND mcprsf.MDPNL_ID = ? ")
				.append(" AND mcprsf.INTRVL_MNTH_CNT = ? ")
				;
			

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			prepareStatement(logger, query.toString());
			
			int i = 0;
			ps.setString(++i, StringUtil.convertDate(request.getMeasurementPeriodStartDt()));
			ps.setString(++i, StringUtil.convertDate(request.getMeasurementPeriodEndDt()));
//			ps.setString(++i, request.getFundingPool());
			ps.setString(++i, request.getProvGrpIds());
			ps.setString(++i, request.getProgramId());
			ps.setString(++i, request.getLobNm());			
			ps.setString(++i, request.getMedicalPanelId());
			ps.setInt(++i, Integer.parseInt(request.getMeasurementInterval()));
			
			executeQuery(logger, query.toString());
			
			while(rs.next()){
				McbSmryDto mcbDto = new McbSmryDto();
				mcbDto.setMetricCd(rs.getString("MTRC_CD"));
				mcbDto.setMetricNm(rs.getString("MTRC_NM"));
				mcbDto.setPhrmcyInd(rs.getString("PHRMCY_IND"));
				mcbDto.setPslId(rs.getString("PSL_ID"));
				mcbDto.setPgProdNbr(rs.getBigDecimal("PG_PROD_NBR"));
				mcbDto.setProdMedNbr(rs.getBigDecimal("PROD_MDCL_NBR"));
				mcbDto.setIntervalMonthCount(rs.getInt("INTRVL_MNTH_CNT"));
				mcbDto.setPgInd(rs.getString("PG_IND"));
				resultList.add(mcbDto);
			}
		}
		catch (Exception e) {

			logger.error("Unable to get MCB data.", e);
		}
		finally {

			close();
		}
		return resultList;
	}

}
