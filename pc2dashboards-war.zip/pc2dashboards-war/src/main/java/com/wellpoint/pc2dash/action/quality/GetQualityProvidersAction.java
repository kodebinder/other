package com.wellpoint.pc2dash.action.quality;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.data.dao.ImprovementQualityProviders;
import com.wellpoint.pc2dash.data.dao.MedicaidQualityProviders;
import com.wellpoint.pc2dash.data.dao.QualityProviders;
import com.wellpoint.pc2dash.dto.careOpportunities.Provider;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportGridColumn;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.scorecard.commercial.QualityProviderExport;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.DateUtil;
import com.wellpoint.pc2dash.util.StringUtil;


public class GetQualityProvidersAction extends GetQualityAction {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetQualityProvidersRequest request = (GetQualityProvidersRequest) actionRequest;
		GetQualityResponse response = new GetQualityResponse();
		List<String> grps = new ArrayList<String>();
		List<Provider> resultList = new ArrayList<Provider>();

		try {
			
			String measStartDate = request.getMeasurementPeriodStartDt();
			boolean isMPGreaterThanOrEqual01012018 = DateUtil.dateComparator(measStartDate, Constants.IND_MTRC_STRT_DT);
			request = (GetQualityProvidersRequest) cleanRequest(request);

			QualityProviders dao1 = new QualityProviders();
			MedicaidQualityProviders dao2 = new MedicaidQualityProviders();
			ImprovementQualityProviders dao3 = new ImprovementQualityProviders();

			boolean medicaidLOB = request.getProgramLobTypeCd().equalsIgnoreCase(Constants.MEDICAID);
			boolean commercialLOB = request.getProgramLobTypeCd().equalsIgnoreCase(Constants.COMMERCIAL);
			boolean improvementComposite = request.getCompositeType().equalsIgnoreCase(Constants.IMPCOMPOSITETYPE);
			boolean medicareLOB = request.getProgramLobTypeCd().equalsIgnoreCase(Constants.MEDICARE) ||
									request.getProgramLobTypeCd().equalsIgnoreCase(Constants.FPCC_MEDICARE);

			// Kill switch check on Provider groups
			if (StringUtils.isNotBlank(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			// Clinical access check on provider groups
			if (null != grps && grps.size() > 0) {
				grps = filterProvGrpsByClinicalInd(request, grps);
			}

			if (null != grps && !grps.isEmpty()) {

				request.setProvGrpIds(StringUtils.join(grps, ','));
				request.setGrpInd(Constants.GRP_IND_N);

				if (StringUtil.isJson(request)) {
					MetaData metaData = new MetaData();

					if (!improvementComposite) {
						if (!medicaidLOB) {
							resultList.addAll(dao1.getQualityProviders(request));
							response.setTotal(dao1.getRowCount()); // calculates total without another query
							metaData = buildMetaData(request, dao1);
						}
						else if (medicaidLOB) {
							resultList.addAll(dao2.getMedicaidQualityProviders(request));
							response.setTotal(dao2.getRowCount()); // calculates total without another query
							metaData = buildMetaData(request, dao2);
						}
					}
					else if (medicareLOB && isMPGreaterThanOrEqual01012018) {
						resultList.addAll(dao1.getQualityProviders(request));
						response.setTotal(dao1.getRowCount()); // calculates total without another query
						metaData = buildMetaData(request, dao1);
					}
					else {
						resultList.addAll(dao3.getImprovementQualityProviders(request));
						response.setTotal(dao3.getRowCount()); // calculates total without another query
						metaData = buildMetaData(request, dao3);
					}

					response.setMetaData(metaData);
					response.setMessage(StringUtil.buildMessage(resultList.isEmpty()));
					response.setData(resultList);
				}
				else {

					List<ExportGridColumn> columns = dao1.buildExportGridColumns(request);

					QualityProviderExport exp = new QualityProviderExport(request, columns);
					ExportProcessor.getInstance().submit(exp);
				}
			}

			response.setSuccess(true);

		}
		catch (Exception e) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(e, response);
		}

		return response;
	}
}
