package com.wellpoint.pc2dash.data.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.costOpportunity.GetEvidenceBasedCareVariationsProviderRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.costOpportunity.EvidenceBasedCareVariationsProviderBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class EvidenceBasedCareVariationsProviderDao extends ServiceImpl {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(EvidenceBasedCareVariationsProviderDao.class);

	public List<EvidenceBasedCareVariationsProviderBean> getData(GetEvidenceBasedCareVariationsProviderRequest request, boolean exportFlag, int index, int limit)
		throws Exception {

		List<EvidenceBasedCareVariationsProviderBean> result = new ArrayList<EvidenceBasedCareVariationsProviderBean>();
		//		MinimumCriteriaBean minCrit = new MinimumCriteriaBean("MBR_SPCFD_SRVC_CNT", "COC_EBC_CTGRY_SMRY", "COC_EBC_MIN_TOTL_EVNT", null); 
		setRowCount(0);

		boolean displayDashes = false;



		StringBuilder query =
			new StringBuilder()
				.append(" select   c.* ")
				.append(" from   ( ")
				.append(" 	select   b.*, row_number() over( order by ")
				.append(buildSortClause(request))
				.append("   ) as row_nbr ")
				.append(" 	from   ( ")
				.append(" 		select ")
				.append(" 			a.provider_frst_nm, ")
				.append("			a.provider_last_nm, ")
				.append(" 			a.IP_NPI, ")
				.append(" 			a.IP_SPCLTY_NM, ")
				.append(" 			a.prov_name, ")
				.append(" 			a.prov_org_name, ")
				.append(" 			a.category, ")
				.append(" 			a.total_member_count, ")
				.append("           a.eligible_member_count, ")
				.append("           a.current_performance_rate, ")
				.append("           a.provider_dim, ")
				.append(" 			a.provider_org_dim, ")
				.append(" 			a.PROV_ORG_TAX_ID, ")
				.append(" 			a.row_cnt as row_cnt ")
				.append(" 		from  ( ")
				.append(" 			select ")
				.append(" 				smry.IP_FRST_NM as provider_frst_nm, ")
				.append(" 				smry.IP_LAST_NM as provider_last_nm, ")
				.append(" 				smry.PROV_DSPLY_NM as prov_name, ")
				.append(" 				smry.PROV_ORG_FULL_NM as prov_org_name, ")
				.append(" 				smry.SUB_MTRC_NM as category, ")
				.append(" 				sum(smry.MBR_SPCFD_SRVC_CNT) as total_member_count, ")
				.append("               sum(smry.MBR_ELGBL_SLCT_SRVC_CNT) as eligible_member_count, ")
				.append("               smry.ip_dim_key as provider_dim, ")
				.append("               smry.PROV_ORG_DIM_key as provider_org_dim, ")
				.append(" 				smry.IP_NPI IP_NPI, ")
				.append(" 				smry.PROV_ORG_TAX_ID as PROV_ORG_TAX_ID, ")
				.append(" 				cd.cd_val_nm IP_SPCLTY_NM, ")
				.append(" 				case when sum(smry.MBR_SPCFD_SRVC_CNT)>0 and  sum(smry.MBR_ELGBL_SLCT_SRVC_CNT) > 0 ")
				.append(
					"                  then cast((cast (sum(smry.MBR_SPCFD_SRVC_CNT) as Decimal(18,4)) / cast(sum(smry.MBR_ELGBL_SLCT_SRVC_CNT) as decimal(18,4)))*1000   as decimal(18,4)) ")
				.append("                  ELSE 0.00 ")
				.append("                END as current_performance_rate, ")
				.append("				count(*) over () as row_cnt ")

				/*.append(" 				case when ")
				.append(dashesClause)
				.append(" then 'Y' else 'N' end as dsply_dashes ")*/
				.append(" 				    FROM coc_ebc_ctgry_smry smry ")
				.append("                 join   IP_DIM ip on ( ip.ip_dim_key = smry.ip_dim_key ) ")
				.append(" 				join  cd_dim cd on ( cd.cd_dim_key = ip.SPCLTY_CD_DIM_KEY) ")
				.append(" 			join  poit_user_scrty_acs pusa on (smry.prov_grp_id = pusa.prov_grp_id ")
				.append(" 					and ")
				.append(" 				case ")
				.append(" 						when    pusa.prov_org_tax_id = '0' ")
				.append(" 						then    smry.prov_org_tax_id ")
				.append(" 						else    pusa.prov_org_tax_id end = smry.prov_org_tax_id) ")
				.append(" 			where  pusa.sesn_id = ? ")
				.append(" 				and  pusa.enttlmnt_hash_key = ? ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and smry.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and smry.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and smry.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and smry.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and smry.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}

		// Category Filter
		if (StringUtil.isNotBlankOrFalse(request.getCategoryCode())) {
			query.append(" and smry.SUB_MTRC_CD in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getCategoryCode())
				+ ") ");
		}

		query.append(" and smry.MBR_ELGBL_SLCT_SRVC_CNT>0		group by ")
			.append(" smry.IP_FRST_NM, ")
			.append(" smry.IP_LAST_NM, ")
			.append(" 				smry.SUB_MTRC_NM, ")
			.append(" 				smry.ip_dim_key, ")
			.append(" 				smry.PROV_DSPLY_NM, ")
			.append(" 				smry.PROV_ORG_FULL_NM, ")
			.append(" smry.PROV_ORG_TAX_ID, ")
			//			.append("               smry.MBR_SPCFD_SRVC_CNT, ")
			//			.append("               smry.MBR_ELGBL_SLCT_SRVC_CNT, ")
			.append("               smry.PROV_ORG_DIM_key, ")
			.append(" smry.IP_NPI, ")
			.append(" cd.cd_val_nm ")
			.append(" 		) as a ")
			.append(" 	) as b ")
			.append(" ) as c ");

		//		if (!exportFlag) {
		//			query.append(" where c.row_nbr between ? and ? ");
		//		}
		//		query.append(" order by c.row_nbr  with ur ");
		query.append(" where c.row_nbr between ? and ? ");
		query.append(" order by c.row_nbr  with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());

			buildPreparedStatement(request, i, exportFlag, index, limit);

			executeQuery(logger, query.toString());

			result = convertSelectedRowsToObjects(rs, request, displayDashes, exportFlag);

		}
		catch (Exception e) {

			throw new Exception("Unable to get EvidenceBasedCareVariationsProviderDao (" + request.getEntitlementId() + ").", e);
		}
		finally {

			close();
		}

		return result;

	}

	protected String getSort(GetEvidenceBasedCareVariationsProviderRequest request) {
		String dir = "";
		if (CollectionUtils.isNotEmpty(request.getSort())
			&& request.getSort().get(0) != null
			&& StringUtils.isNotBlank(request.getSort().get(0).getDirection())) {
			dir = request.getSort().get(0).getDirection();
		}
		return dir;
	}

	private void buildPreparedStatement(GetEvidenceBasedCareVariationsProviderRequest request, int i, boolean exportFlag, int index, int limit) throws SQLException {

		int start = 0;
		int stop = 0;

		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getCategoryCode())) {
			String[] array = request.getCategoryCode().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (!exportFlag) {
			start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
			stop = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
		}
		else {
			start = index;
			stop = limit;
		}
		ps.setInt(++i, start + 1);
		ps.setInt(++i, start + stop);

	}

	private List<EvidenceBasedCareVariationsProviderBean> convertSelectedRowsToObjects(ResultSet rs, GetEvidenceBasedCareVariationsProviderRequest request, boolean displayDashes,
		boolean exportFlag)
		throws SQLException {

		List<EvidenceBasedCareVariationsProviderBean> list = new ArrayList<EvidenceBasedCareVariationsProviderBean>();
		if (exportFlag) {
			while (rs.next()) {
				
				setTotalExport(rs.getInt("row_cnt"));   
				
				EvidenceBasedCareVariationsProviderBean item = new EvidenceBasedCareVariationsProviderBean();
				
				//Changed for release-Q1-2018/PCMSP-18421 : Starts
				item.setAttributedPhysicianName(CommonQueries.getFilteredProviderName(rs.getString("provider_frst_nm"),rs.getString("provider_last_nm")));				
				//Changed for release-Q1-2018/PCMSP-18421 : Ends
				
				
				if (rs.getString("IP_NPI") != null) {
					item.setAttributedProvNpi(StringUtil.getValueOrDashes(rs.getString("IP_NPI")));
				}
				if (rs.getString("IP_SPCLTY_NM") != null) {
					item.setAttributedProvSpeciality(StringUtil.getValueOrDashes(rs.getString("IP_SPCLTY_NM")));
				}

				item.setProviderId(StringUtil.buildUniqueProviderId(rs.getString("provider_dim"), rs.getString("provider_org_dim")));



				item.setProviderId(StringUtil.buildUniqueProviderId(rs.getString("provider_dim"), rs.getString("provider_org_dim")));
				
				if(rs.getString("category") != null){
					item.setCategory(rs.getString("category"));
				}

				if (rs.getString("prov_org_name") != null) {
					item.setOrganizationName(rs.getString("prov_org_name"));
				}
				if (null != rs.getString("PROV_ORG_TAX_ID")) {
					item.setOrgTin(rs.getString("PROV_ORG_TAX_ID"));
				}
				if (rs.getString("current_performance_rate") != null) {
					item.setcurrentPerformanceRate(StringUtil.convertStringToCommaBigDecimal(
						rs.getBigDecimal("current_performance_rate").setScale(2, BigDecimal.ROUND_HALF_UP).toString(), 2));
				}
				if (rs.getString("eligible_member_count") != null) {
					item.setEligibleMemberCount(StringUtil.convertStringToCommaBigDecimal(
						rs.getBigDecimal("eligible_member_count").setScale(0, BigDecimal.ROUND_HALF_UP).toString(), 0));
				}
				if (rs.getString("total_member_count") != null) {
					item.setTotalMemberCount(StringUtil.convertStringToCommaBigDecimal(
						rs.getBigDecimal("total_member_count").setScale(0, BigDecimal.ROUND_HALF_UP).toString(), 0));
				}
				
				list.add(item);

				if (getRowCount() == 0) {
					setRowCount(rs.getInt("row_cnt"));
				}
			}

		}
		else {
			while (rs.next()) {

				EvidenceBasedCareVariationsProviderBean item = new EvidenceBasedCareVariationsProviderBean();

				//Changed for release-Q1-2018/PCMSP-18421 : Starts
				item.setAttributedPhysicianName(CommonQueries.getFilteredProviderName(rs.getString("provider_frst_nm"),rs.getString("provider_last_nm")));				
				//Changed for release-Q1-2018/PCMSP-18421 : Ends
				item.setOrganizationName(rs.getString("prov_org_name"));
				item.setProviderId(StringUtil.buildUniqueProviderId(rs.getString("provider_dim"), rs.getString("provider_org_dim")));
				item.setCategory(rs.getString("category"));
				item.setcurrentPerformanceRate(rs.getString("current_performance_rate"));
				item.setEligibleMemberCount(rs.getString("eligible_member_count"));
				item.setTotalMemberCount(rs.getString("total_member_count"));
				/*	if (displayDashes ||
						rs.getString("dsply_dashes") != null && rs.getString("dsply_dashes").equalsIgnoreCase(Constants.Y)) {
						displayDashes = true;
					}
					else {
						displayDashes = false;
					}*/

				item.setHasDetailsDrilldownInd(request.isHasDetailsDrilldownInd());

				list.add(item);

				if (getRowCount() == 0) {
					setRowCount(rs.getInt("row_cnt"));
				}

			}
		}
		return list;

		/*while (rs.next()) {

			EvidenceBasedCareVariationsProviderBean item = new EvidenceBasedCareVariationsProviderBean();

			

			if (exportFlag) {

				if (displayDashes) {

				}
				else {
				}
			}
			else {

				if (displayDashes) {

				}
				else {
				}
			}

			item.setHasDetailsDrilldownInd(request.isHasDetailsDrilldownInd());

			list.add(item);

			if (getRowCount() == 0) {
				setRowCount(rs.getInt("row_cnt"));
			}

		}

		return list;*/

	}

	private String buildSortClause(GetEvidenceBasedCareVariationsProviderRequest request) {

		StringBuilder query = new StringBuilder();
		String defaultColumn = " current_performance_rate ";
		String defaultSort = defaultColumn + " desc ";

		if (null != request.getSort()) {

			for (QuerySort sort : request.getSort()) {

				String dir = sort.getDirection().replaceAll("\"", "");
				String property = sort.getProperty();

				if (property.equals("attributedPhysicianName")) {
					query.append(" prov_name " + dir + ", " + defaultSort);
				}
				else if (property.equals("organizationName")) {
					query.append(" prov_org_name " + dir + ", " + defaultSort);
				}
				else if (property.equals("category")) {
					query.append(" category " + dir + ", " + defaultSort);
				}
				else if (property.equals("totalMemberCount")) {
					query.append(" total_member_count " + dir + ", " + defaultSort);
				}
				else if (property.equals("eligibleMemberCount")) {
					query.append(" eligible_member_count " + dir + ", " + defaultSort);
				}
				else {
					query.append(defaultColumn + dir);
				}
			}

		}
		else {
			query.append(defaultSort);
		}

		return query.toString();

	}



}
