package com.wellpoint.pc2dash.action.tap;

import com.wellpoint.pc2dash.data.dto.PopulationManagementRequest;

public class GetTapReportsRequest extends PopulationManagementRequest {

}
