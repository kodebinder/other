package com.wellpoint.pc2dash.action.scoreCard;

import java.util.ArrayList;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetScorecardAction extends Action {

	ActionResponse scoreCardRespObj = new GetScorecardResponse();

	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		scoreCardRespObj.setMessage("No functionality!");
		scoreCardRespObj.setData(new ArrayList());
		scoreCardRespObj.setSuccess(true);
		return scoreCardRespObj;
	}

}
