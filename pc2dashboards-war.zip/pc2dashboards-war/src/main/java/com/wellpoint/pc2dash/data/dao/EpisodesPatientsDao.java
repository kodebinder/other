package com.wellpoint.pc2dash.data.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


import com.wellpoint.pc2dash.action.scoreCard.GetEpisodePatientsRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.scorecard.EpisodesPatientGrid;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.DateUtil;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.ReferralBeanConstants;
import com.wellpoint.pc2dash.util.StringUtil;

public class EpisodesPatientsDao extends ServiceImpl{


	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(EpisodesPatientsDao.class);


	public List<EpisodesPatientGrid> getPatientGrid(GetEpisodePatientsRequest request, boolean exportFlag, int index, int limit) throws Exception {


		List<EpisodesPatientGrid> result = new ArrayList<EpisodesPatientGrid>();
		setRowCount(0);
		int start = 0;
		int stop = 0;

		StringBuilder sql = new StringBuilder()
			.append("select ")
			.append("	a.* ")
			.append("from ")
			.append("	( ")
			.append("		select ")
			.append("			row_number() over (")
			.append("				order by ")
			.append(buildSortClause(request))
			.append("	) as rank ")
			.append(" ,mstr_cnsmr_dim_key,hc_id,prov_org_full_nm,ip_frst_nm, ip_last_nm, ");
		if (StringUtil.isExportDest(request.getDest())) {
			
			sql.append(" PROV_ORG_TAX_ID, IP_SPCLTY_NM, ip_npi,  ")
			.append(" etgConditionCd, etgCondition,sum(facilityAllowedAmount) as facilityAllowedAmount,sum(anciliaryIPAllowedAmount) as anciliaryIPAllowedAmount, ")
			.append(" sum(managementAllowedAmount) as managementAllowedAmount, sum(anciliaryOPAllowedAmount) as anciliaryOPAllowedAmount, ")
			.append(" sum(surgeryAllowedAmount) as surgeryAllowedAmount, sum(pharmacyAllowedAmount) as pharmacyAllowedAmount, ")
			.append(" sum(totalAllowedAmt) as totalAllowedAmt, count(totalEpisodeCountExp) as totalEpisodeCountExp, ");
		}else {
			sql.append(" totalAllowedAmt,totalEpisodeCount,");
		}
		sql.append(" frst_nm,last_nm,brth_dt,age_nbr,gndr_cd,phone_nbr,lob_ctgry_nm,lob_desc,psl_desc,psl_grp_nm,prov_grp_id,pgm_id,crprt_plan_cmpny_nm, home_plan_nm,ooa_ind_cd,sent_referral_count,rcvd_referral_count,has_referrals,lpr_ind_cd, ");
		sql.append(" count(*) over () as row_cnt,ipDimKey,provOrgDimKey,provGrpDimKey ");
		sql.append(" from  ")
			.append(" ( ")
			.append(" select psf.mstr_cnsmr_dim_key,psf.hc_id,upper(psf.prov_org_full_nm) as prov_org_full_nm, upper(psf.ip_frst_nm) as ip_frst_nm, upper(psf.ip_last_nm) as ip_last_nm,psf.lpr_ind_cd,  ")
			.append(" psf.ooa_ind_cd,coalesce(ref.sent_rfrl_cnt, 0) as sent_referral_count")
			.append(", coalesce(ref.recvd_rfrl_cnt, 0) as rcvd_referral_count")
			.append(", case when  coalesce(ref.rfrl_cnt, 0) > 0 then  1 else  0 end as has_referrals, ");
		if (StringUtil.isExportDest(request.getDest())) {
			sql.append(" psf.PROV_ORG_TAX_ID, psf.IP_SPCLTY_NM,psf.ip_npi, ")
			.append(" ETG.ETG_BASE_CLS_CD as etgConditionCd,UPPER(ETG.ETG_BASE_CLS_DESC) as etgCondition, ")
			.append(" ETG.ANLZD_FCLTY_ALWD_AMT as facilityAllowedAmount,ETG.ANLZD_ANCLRY_INPAT_ALWD_AMT as anciliaryIPAllowedAmount, ")
			.append(" ETG.ANLZD_MNGMNT_ALWD_AMT as managementAllowedAmount,ETG.ANLZD_ANCLRY_OUTPAT_ALWD_AMT as anciliaryOPAllowedAmount, ")
			.append(" ETG.ANLZD_SRGRY_ALWD_AMT as surgeryAllowedAmount,ETG.ANLZD_PHRMCY_ALWD_AMT as pharmacyAllowedAmount, ETG.EPSD_NBR as totalEpisodeCountExp,");
		}
		sql.append(" upper(psf.frst_nm) as frst_nm,upper(psf.last_nm) as last_nm,nullif(psf.brth_dt, '0001-01-01') as brth_dt,psf.age_nbr, ")
			.append(" psf.gndr_cd,psf.phone_nbr,psf.lob_ctgry_nm,psf.lob_desc,psf.psl_desc,psf.psl_grp_nm,psf.prov_grp_id,psf.pgm_id,psf.crprt_plan_cmpny_nm, ");
		sql.append(" psf.home_plan_nm,SUM(ETG.TOTL_ANLZD_ALWD_AMT) as totalAllowedAmt, count(ETG.EPSD_NBR) as totalEpisodeCount,PSF.IP_DIM_KEY as ipDimKey,PSF.PROV_ORG_DIM_KEY as provOrgDimKey,PSF.PROV_GRP_DIM_KEY as provGrpDimKey ");
		sql.append(" from  ")
			.append(" SCRCRD_ESN_ETG_MCID_FACT ETG  ")
			.append(" JOIN PAT_SMRY_FACT PSF ON  PSF.MSTR_CNSMR_DIM_KEY = ETG.MSTR_CNSMR_DIM_KEY and PSF.prov_grp_dim_key = ETG.prov_grp_dim_key")
			.append(" and PSF.ip_dim_key = ETG.ip_dim_key ") // and PSF.prov_org_dim_key = ETG.prov_org_dim_key")
			.append(" left join (select  rfd.mstr_cnsmr_dim_key, rfd.prov_grp_dim_key, rfd.prov_org_dim_key, rfd.ip_dim_key, sum(case")
			.append(" when  rfd.rfrl_type_cd = 'Draft' ")
			.append(" then  1 ")
			.append(" else  0 end) as draft_rfrl_cnt, sum(case ")
			.append(" when  rfd.rfrl_type_cd = 'Sent' ")
			.append(" then  1 ")
			.append(" else  0 end) as sent_rfrl_cnt, sum(case ")
			.append(" when  rfd.rfrl_type_cd = 'Received' ")
			.append(" then  1 ")
			.append(" else  0 end) as recvd_rfrl_cnt, count(*) as rfrl_cnt ")
			.append(" from  rfrl_form_dtl rfd")
			.append(" where  rfd.rcrd_stts_cd <> 'DEL' ")
			.append(" and  rfd.rfrl_sbmtd_dt between (current_date -1 year) ")
			.append(" and  (current_date) ")
			.append(" group by  rfd.mstr_cnsmr_dim_key, rfd.prov_grp_dim_key, rfd.prov_org_dim_key, rfd.ip_dim_key ) ref on ( psf.mstr_cnsmr_dim_key = ref.mstr_cnsmr_dim_key ")
			.append(" and  psf.prov_grp_dim_key = ref.prov_grp_dim_key ")
			.append(" and  psf.prov_org_dim_key = ref.prov_org_dim_key ")
			.append(" and  psf.ip_dim_key = ref.ip_dim_key ) ")
			.append("	join poit_user_scrty_acs pusa on ( ")
			.append("		psf.prov_grp_id = pusa.prov_grp_id ")
			.append("		and case ")
			.append("				when pusa.prov_org_tax_id = '0' then psf.prov_org_tax_id ")
			.append("				else pusa.prov_org_tax_id ")
			.append("			end = psf.prov_org_tax_id ")
			.append("	) ")
			.append("  WHERE ");
		sql.append("  PSF.ATRBN_STTS_CD = 'ACTIVE' ")
			.append(" and pusa.sesn_id = ? ")
			.append(" and pusa.enttlmnt_hash_key = ? ");
		
		sql = addAgeFilter(request, sql, "psf");

		if (StringUtil.isNotBlankOrFalse(request.getProvGrpIds())) {
			sql.append(" and psf.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvGrpIds()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProgramId())) {
			sql.append(" and psf.pgm_id in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProgramId()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getLobNm())) {
			/** 66200 PSL Desc Changes | ad87338 | START */
			sql.append(" and psf.lob_ctgry_nm in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getLobNm()) + ") ");
			/** 66200 PSL Desc Changes | ad87338 | END */
		}

		// Name search US 54933
		if (StringUtil.isNotBlankOrFalseOrMasked(request.getMemberFullNameQuery())) {
			String str = request.getMemberFullNameQuery().trim();
			if (str.contains(",")) {
				String[] splited = str.split(",");
				Integer len = splited.length;
				if (len == 2) {
					sql.append(" and(( (upper(psf.last_nm) like upper(?)) and (upper(psf.frst_nm) like upper(?))) "
						+ "or ((upper(psf.last_nm) like upper(?)) and (upper(psf.frst_nm) like upper(?) )))");
				}
				if (len == 1) {
					sql.append(" and (upper(psf.last_nm) like upper(?) or upper(psf.frst_nm) like upper(?)) ");
				}
			}
			else if (str.contains(" ")) {
				sql.append(" and(( (upper(psf.last_nm) like upper(?)) and (upper(psf.frst_nm) like upper(?))) "
					+ "or ((upper(psf.last_nm) like upper(?)) and (upper(psf.frst_nm) like upper(?) )))");
			}
			else
				sql.append(" and (upper(psf.last_nm) like upper(?) or upper(psf.frst_nm) like upper(?)) ");
		}

		// Organization filter
		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			sql.append(" and psf.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			sql.append(" and psf.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}


		sql.append(" group by psf.mstr_cnsmr_dim_key,psf.hc_id,upper(psf.prov_org_full_nm) , upper(psf.ip_frst_nm), ") 
			.append(" upper(psf.ip_last_nm), psf.lpr_ind_cd,  upper(psf.frst_nm),upper(psf.last_nm),nullif(psf.brth_dt, '0001-01-01'), ")
			.append(" psf.ooa_ind_cd,coalesce(ref.sent_rfrl_cnt, 0)")
			.append(", coalesce(ref.recvd_rfrl_cnt, 0)")
			.append(", case when  coalesce(ref.rfrl_cnt, 0) > 0 then  1 else  0 end, ");
			if (StringUtil.isExportDest(request.getDest())) {
				sql.append(" psf.PROV_ORG_TAX_ID, psf.IP_SPCLTY_NM,psf.ip_npi, ")
				.append(" ETG.ETG_BASE_CLS_CD , UPPER(ETG.ETG_BASE_CLS_DESC), ")
				.append(" ETG.ANLZD_FCLTY_ALWD_AMT , ETG.ANLZD_ANCLRY_INPAT_ALWD_AMT, ")
				.append(" ETG.ANLZD_MNGMNT_ALWD_AMT , ETG.ANLZD_ANCLRY_OUTPAT_ALWD_AMT, ")
				.append(" ETG.ANLZD_SRGRY_ALWD_AMT , ETG.ANLZD_PHRMCY_ALWD_AMT,ETG.EPSD_NBR,");
				
			}
			sql.append(" psf.age_nbr,  psf.gndr_cd,psf.phone_nbr,psf.lob_ctgry_nm,psf.lob_desc,psf.psl_desc,psf.psl_grp_nm,psf.prov_grp_id,psf.pgm_id,psf.crprt_plan_cmpny_nm, psf.home_plan_nm,PSF.IP_DIM_KEY,PSF.PROV_ORG_DIM_KEY,PSF.PROV_GRP_DIM_KEY) ");
			
			if (StringUtil.isExportDest(request.getDest())) {
			sql.append(" group by  mstr_cnsmr_dim_key, hc_id, prov_org_full_nm, ip_frst_nm, ip_last_nm, PROV_ORG_TAX_ID, IP_SPCLTY_NM, ip_npi, ")
			.append(" frst_nm, last_nm, brth_dt, age_nbr, gndr_cd, phone_nbr, lob_ctgry_nm, lob_desc, psl_desc, psl_grp_nm, prov_grp_id,pgm_id, ")
			.append("crprt_plan_cmpny_nm, home_plan_nm,ooa_ind_cd, sent_referral_count, rcvd_referral_count,  has_referrals,lpr_ind_cd, ")
			.append(" ipDimKey, provOrgDimKey, provGrpDimKey , etgConditionCd, etgCondition ");
			}
			sql.append(") a ");

		// Do not apply the limit if the request is for export
		//if (!StringUtil.isExportDest(request.getDest())
		//	&& StringUtils.isNotBlank(request.getStart()) && StringUtils.isNotBlank(request.getLimit())) {
			sql.append(" where a.rank between ? and ? ");
		//}

		sql.append(" order by a.rank ");
		sql.append(" with ur ");



		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, sql.toString());

			
			ps.setString(++i, request.getSessionId());
			ps.setString(++i, request.getEntitlementId());

			// Group Ids
			if (StringUtil.isNotBlankOrFalse(request.getProvGrpIds())) {
				String[] array = request.getProvGrpIds().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// Program filters
			if (StringUtil.isNotBlankOrFalse(request.getProgramId())) {
				String[] array = request.getProgramId().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// LOB filters
			if (StringUtil.isNotBlankOrFalse(request.getLobNm())) {
				String[] array = request.getLobNm().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// Name search us54933
			if (StringUtil.isNotBlankOrFalseOrMasked(request.getMemberFullNameQuery())) {
				String str = request.getMemberFullNameQuery().trim();
				if (str.contains(",")) {
					String[] splited = str.split(",");
					Integer len = splited.length;
					if (len == 2) {
						String split_one = splited[0].trim();
						String split_second = splited[1].trim();
						String fn = "%" + split_one.toUpperCase().replaceAll("'", "''") + "%";
						String ln = "%" + split_second.toUpperCase().replaceAll("'", "''") + "%";
						ps.setString(++i, fn);
						ps.setString(++i, ln);
						ps.setString(++i, ln);
						ps.setString(++i, fn);
					}
					else if (len == 1) {
						String nm = "%" + splited[0].trim().toUpperCase().replaceAll("'", "''") + "%";
						ps.setString(++i, nm);
						ps.setString(++i, nm);

					}
				}
				else if (str.contains(" ")) {
					String[] splited = str.split(" ");
					Integer len = splited.length;
					if (len == 2) {
						String split_one = splited[0];
						String split_second = splited[1];
						String fn = "%" + split_one.toUpperCase().replaceAll("'", "''") + "%";
						String ln = "%" + split_second.toUpperCase().replaceAll("'", "''") + "%";
						ps.setString(++i, fn);
						ps.setString(++i, ln);
						ps.setString(++i, ln);
						ps.setString(++i, fn);
					}
				}
				else {
					String nm = "%" + request.getMemberFullNameQuery().trim().toUpperCase().replaceAll("'", "''") + "%";
					ps.setString(++i, nm);
					ps.setString(++i, nm);

				}

			}

			// Organization filter
			if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
				String[] array = request.getProvDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, StringUtil.parseProviderId(item));
				}
			}
			if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
				String[] array = request.getOrgDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}



			// Do not apply the limit if the request is for export
			
			if (!exportFlag) {
				start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
				stop = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
			}
			else {
				start = index;
				stop = limit;
			}
			ps.setInt(++i, start + 1);
			ps.setInt(++i, start + stop);

			executeQuery(logger, sql.toString());	

			while (rs.next()) {
				
				EpisodesPatientGrid jsonResult = new EpisodesPatientGrid();
				
				// RA - Action menu Suppression
				boolean isACMenuSuppressed = false;
				boolean isACRecRefSuppressed = false;
				List<String> acSuppressedLOBs = null;
				List<String> suppressedPgm = null;
				// AC Menu - Suppression
				if (request.getAcSuppressedLOBs() != null) {
					acSuppressedLOBs = Arrays.asList(request.getAcSuppressedLOBs().split(Constants.COMMA));
				}
				
				if (request.getSuppressedPGM() != null) {
					suppressedPgm = Arrays.asList(request.getSuppressedPGM().split(Constants.COMMA));
				}
				if ((null != request.getProvGrpIdSentRfrls()
					&& !request.getProvGrpIdSentRfrls().contains(null != rs.getString("prov_grp_id") ? rs.getString("prov_grp_id") : Constants.BLANK)) //Group/Market level
					|| (null != acSuppressedLOBs
					&& acSuppressedLOBs.contains(null != rs.getString("lob_ctgry_nm") ? rs.getString("lob_ctgry_nm") : Constants.BLANK))
					|| (null != suppressedPgm && suppressedPgm.contains(null != rs.getString("pgm_id") ? rs.getString("pgm_id") : Constants.BLANK))) { //LOB level
					isACMenuSuppressed = true;
				}

				// AC Received Referrals - Suppression
				if (request.getAcRecRefSuppressedLOBs() != null) {
					acSuppressedLOBs = Arrays.asList(request.getAcRecRefSuppressedLOBs().split(Constants.COMMA));
				}
				if (request.getAceRecRefSuppressedPgms() != null) {
					suppressedPgm = Arrays.asList(request.getAceRecRefSuppressedPgms().split(Constants.COMMA));
				}
				if ((null != request.getProvGrpIdRcvdRfrls()
					&& !request.getProvGrpIdRcvdRfrls().contains(null != rs.getString("prov_grp_id") ? rs.getString("prov_grp_id") : Constants.BLANK)) //Group/Market level
					|| (null != acSuppressedLOBs
					&& acSuppressedLOBs.contains(null != rs.getString("lob_ctgry_nm") ? rs.getString("lob_ctgry_nm") : Constants.BLANK))
					|| (null != suppressedPgm && suppressedPgm.contains(null != rs.getString("pgm_id") ? rs.getString("pgm_id") : Constants.BLANK))) { //LOB level
					isACRecRefSuppressed = true;
				}

				if ("Y".equalsIgnoreCase(request.getShowAll()) || !isACMenuSuppressed) {
					String ooa_ind_cd = rs.getString("ooa_ind_cd");
					if (ooa_ind_cd != null) {
						if (Constants.N.equalsIgnoreCase(ooa_ind_cd)) {
							jsonResult.getActions().add(ReferralBeanConstants.ACTIONOOIND);
						}
					}
					String has_rfrl = rs.getString("has_referrals");
					if (has_rfrl != null) {
						if (!isACRecRefSuppressed && "1".equalsIgnoreCase(has_rfrl)) {
							jsonResult.getActions().add(ReferralBeanConstants.ACTIONRFRLCNT);
						}
					}
				}

				jsonResult.setLprInd(!Constants.STAR.equals(rs.getString("lpr_ind_cd")) ? rs.getString("lpr_ind_cd") : "N");

				if (!"Y".equalsIgnoreCase(request.getShowAll())) {

					List<String> lprSuppressedLOBs = null;
					if (request.getLprSuppressedLOBs() != null) {
						lprSuppressedLOBs = Arrays.asList(request.getLprSuppressedLOBs().split(","));
					}
					List<String> lprSuppressedPGMs = null;
					if (request.getLprSuppressedPGMs() != null) {
						lprSuppressedPGMs = Arrays.asList(request.getLprSuppressedPGMs().split(","));
					}

					if ((request.getLprActiveProviders() != null && !request.getLprActiveProviders().contains(rs.getString("prov_grp_id")))
						|| (lprSuppressedLOBs != null && lprSuppressedLOBs.contains(rs.getString("lob_ctgry_nm")))
						|| (lprSuppressedPGMs != null && lprSuppressedPGMs.contains(rs.getString("pgm_id")))) {
						jsonResult.setLprInd("N");
					}
				}

				jsonResult.setMemberId(StringUtil.getValueOrDashes(rs.getString("hc_id")));

				if (rs.getString("age_nbr") != null) {
					jsonResult.setMemberAge(rs.getShort("age_nbr"));
				}

				if (rs.getString("brth_dt") != null) {
					jsonResult.setMemberDOB(DateUtil.formatDateToMMDDYYYY("yyyy-MM-dd",
						"M/d/yyyy", rs.getString("brth_dt")));
				}
				else {
					jsonResult.setMemberDOB(Constants.DASHES);
				}

				jsonResult.setMemberLastName(StringUtil.getValueOrDashes(rs.getString("last_nm")));

				jsonResult.setMemberFirstName(StringUtil.getValueOrDashes(rs.getString("frst_nm")));

				if (rs.getString("frst_nm") != null && rs.getString("last_nm") != null)
					jsonResult.setMemberFullName(StringUtil.buildFullName(rs.getString("frst_nm"), rs.getString("last_nm")));

				jsonResult.setMemberGender(StringUtil.getValueOrDashes(rs.getString("gndr_cd")));

				jsonResult.setMemberPhoneNumber(StringUtil.buildPhoneNumber(rs.getString("phone_nbr")));

				if (rs.getString("mstr_cnsmr_dim_key") != null) {
					jsonResult.setMemberKey(rs.getLong("mstr_cnsmr_dim_key"));
				}

				jsonResult.setLineOfBusiness(StringUtil.getValueOrDashes(rs.getString("lob_desc")));

				jsonResult.setProduct(StringUtil.getValueOrDashes(rs.getString("psl_desc")));

				String memberHomePlan =
					(!rs.getString("crprt_plan_cmpny_nm").equalsIgnoreCase("*") ? rs.getString("crprt_plan_cmpny_nm") : Constants.DASHES) + " - "
						+ (!rs.getString("home_plan_nm").equalsIgnoreCase("*") ? rs.getString("home_plan_nm") : Constants.DASHES);
				jsonResult.setMemberHomePlan((memberHomePlan).equalsIgnoreCase("--- - ---") ? Constants.DASHES : memberHomePlan);

				jsonResult.setLobCtgryNm(StringUtil.getValueOrDashes(rs.getString("lob_ctgry_nm")));
				
				if (rs.getString("totalAllowedAmt") != null){
					if (exportFlag) {
						jsonResult.setTotalAllowedAmount(StringUtil.convertStringToDecimalCurrency(
								rs.getBigDecimal("totalAllowedAmt").setScale(2, BigDecimal.ROUND_HALF_UP).toString()) );
					}else {
						jsonResult.setTotalAllowedAmount(rs.getString("totalAllowedAmt"));
					}
				}	

				
					if(exportFlag) {
						if (rs.getString("totalEpisodeCountExp") != null) {
						String totEpisodeCount = StringUtil.convertStringToCommaBigDecimal(rs.getString("totalEpisodeCountExp"), 0);
						jsonResult.setTotalEpisodeCount(totEpisodeCount);
						}
					} else {
						if (rs.getString("totalEpisodeCount") != null) {
						jsonResult.setTotalEpisodeCount(rs.getString("totalEpisodeCount"));
					}
					
				}
				
				jsonResult.setOrganizationName((null != (rs.getString("prov_org_full_nm"))
					&& !Constants.STAR.equalsIgnoreCase(rs.getString("prov_org_full_nm"))
						? rs.getString("prov_org_full_nm") : Constants.UNK));
				if ((!(Constants.STAR.equalsIgnoreCase(rs.getString("ip_last_nm")) || Constants.UNK.equalsIgnoreCase(rs.getString("ip_last_nm")))
					&& (null != rs.getString("ip_last_nm")))
					&& (!(Constants.STAR.equalsIgnoreCase(rs.getString("ip_frst_nm")) || Constants.UNK.equalsIgnoreCase(rs.getString("ip_frst_nm")))
						&& (null != rs.getString("ip_frst_nm")))) {
					jsonResult.setAttributedPhysicianName(rs.getString("ip_last_nm").trim() + ", " + rs.getString("ip_frst_nm").trim());
				}
				else if (!(Constants.STAR.equalsIgnoreCase(rs.getString("ip_last_nm")) || Constants.UNK.equalsIgnoreCase(rs.getString("ip_last_nm")))
					&& (null != rs.getString("ip_last_nm"))) {
					jsonResult.setAttributedPhysicianName(rs.getString("ip_last_nm").trim());
				}
				else {
					jsonResult.setAttributedPhysicianName(Constants.UNK);
				}

				if (StringUtil.isExportDest(request.getDest())) {
					
					jsonResult.setAttributedPhysicianNPI(StringUtil.getValueOrDashes(rs.getString("ip_npi")));
					jsonResult.setAttributedProvSpclty(StringUtil.getValueOrDashes(rs.getString("IP_SPCLTY_NM")));
					jsonResult.setOrganizationTin(StringUtil.getValueOrDashes(rs.getString("PROV_ORG_TAX_ID")));
					jsonResult.setHmPlanNm(StringUtil.getValueOrDashes(rs.getString("home_plan_nm")));
					jsonResult.setHmPlanCmpny(StringUtil.getValueOrDashes(rs.getString("crprt_plan_cmpny_nm")));
					
					if (rs.getString("etgCondition") != null){
						jsonResult.setEtgCondition(rs.getString("etgCondition"));
					}else{
						jsonResult.setEtgCondition(Constants.DASHES);
					}
					
					if (rs.getString("facilityAllowedAmount") != null){
							jsonResult.setFacilityAllowedAmount(StringUtil.convertStringToDecimalCurrency(
									rs.getBigDecimal("facilityAllowedAmount").setScale(2, BigDecimal.ROUND_HALF_UP).toString()) );
					}else {
						jsonResult.setFacilityAllowedAmount(Constants.DASHES);
					}
					
					if (rs.getString("anciliaryIPAllowedAmount") != null){
							jsonResult.setAnciliaryIPAllowedAmount(StringUtil.convertStringToDecimalCurrency(
									rs.getBigDecimal("anciliaryIPAllowedAmount").setScale(2, BigDecimal.ROUND_HALF_UP).toString()) );
					}else {
						jsonResult.setAnciliaryIPAllowedAmount(Constants.DASHES);
					}
					
					if (rs.getString("managementAllowedAmount") != null){
							jsonResult.setManagementAllowedAmount(StringUtil.convertStringToDecimalCurrency(
									rs.getBigDecimal("managementAllowedAmount").setScale(2, BigDecimal.ROUND_HALF_UP).toString()) );
					}else {
						jsonResult.setManagementAllowedAmount(Constants.DASHES);
					}
					
					if (rs.getString("anciliaryOPAllowedAmount") != null){
							jsonResult.setAnciliaryOPAllowedAmount(StringUtil.convertStringToDecimalCurrency(
									rs.getBigDecimal("anciliaryOPAllowedAmount").setScale(2, BigDecimal.ROUND_HALF_UP).toString()) );
					}else {
						jsonResult.setAnciliaryOPAllowedAmount(Constants.DASHES);
					}
					
					if (rs.getString("surgeryAllowedAmount") != null){
							jsonResult.setSurgeryAllowedAmount(StringUtil.convertStringToDecimalCurrency(
									rs.getBigDecimal("surgeryAllowedAmount").setScale(2, BigDecimal.ROUND_HALF_UP).toString()) );
					}else {
						jsonResult.setSurgeryAllowedAmount(Constants.DASHES);
					}
					
					if (rs.getString("pharmacyAllowedAmount") != null){
							jsonResult.setPharmacyAllowedAmount(StringUtil.convertStringToDecimalCurrency(
									rs.getBigDecimal("pharmacyAllowedAmount").setScale(2, BigDecimal.ROUND_HALF_UP).toString()) );
					}else {
						jsonResult.setPharmacyAllowedAmount(Constants.DASHES);
					}
					

				}
				
				jsonResult.setProvGrpDimKey(rs.getLong("provGrpDimKey"));
				jsonResult.setProvOrgDimKey(rs.getLong("provOrgDimKey"));
				jsonResult.setIpDimKey(rs.getLong("ipDimKey"));

				setTotalExport(rs.getInt("row_cnt"));
				setRowCount(rs.getInt("row_cnt"));

				result.add(jsonResult);
			}
			//	setRowCount(rs.getInt("row_cnt"));
		}
		catch (Exception e) {

			throw new Exception("Unable to get EpisodesPatientGrid (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;

	}

	private String buildSortClause(GetEpisodePatientsRequest request) {

		StringBuilder query = new StringBuilder();
		String defaultSort = "";
		
		if (StringUtil.isExportDest(request.getDest())) {
			defaultSort = ", sum(totalAllowedAmt) desc" ;
		}else {
			defaultSort = ", totalAllowedAmt desc" ;
		}

		for (QuerySort sort : request.getSort()) {
			String dir = sort.getDirection().replaceAll("\"", "");
			String property = sort.getProperty();

			if (property.contains("totalAllowedAmount")) {
				if (StringUtil.isExportDest(request.getDest())) {
					query.append(" last_nm asc, frst_nm asc, sum(totalAllowedAmt) " + dir  +defaultSort);
					
				}else {
					query.append(" totalAllowedAmt " + dir  +defaultSort);
				}
				
			} 
			if (property.contains("memberFullName")) {
				if (StringUtil.isExportDest(request.getDest())) {
					query.append(" last_nm asc, frst_nm asc, ");
				} 
				query.append(" last_nm " + dir + ", frst_nm " + dir +defaultSort);
			}
			if (property.contains("attributedPhysicianName")) {
				if (StringUtil.isExportDest(request.getDest())) {
					query.append(" last_nm asc, frst_nm asc, ");
				} 
				query.append(" upper(ip_last_nm) " + dir + ", upper(ip_frst_nm) " + dir + defaultSort );   
			}
			if (property.contains("organizationName")) {
				if (StringUtil.isExportDest(request.getDest())) {
					query.append(" last_nm asc, frst_nm asc, ");
				} 
				query.append( " upper(prov_org_full_nm) " + dir  +defaultSort);
			}
			if (property.contains("totalEpisodeCount")) {
				if (StringUtil.isExportDest(request.getDest())) {
					query.append(" last_nm asc, frst_nm asc, count(totalEpisodeCount) " + dir  +defaultSort);
					
				}else {
					query.append(" totalEpisodeCount " + dir  +defaultSort);
				}
				
			}
		}

		return query.toString();
	}


}
