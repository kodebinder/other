package com.wellpoint.pc2dash.action.scoreCard;


public class QualityGateRequest {

	protected String qualityGate;
	protected String qualityGateInd;
	protected String qualityScore;

	public String getQualityGate() {
		return qualityGate;
	}

	public void setQualityGate(String qualityGate) {
		this.qualityGate = qualityGate;
	}

	public String getQualityGateInd() {
		return qualityGateInd;
	}

	public void setQualityGateInd(String qualityGateInd) {
		this.qualityGateInd = qualityGateInd;
	}

	public String getQualityScore() {
		return qualityScore;
	}

	public void setQualityScore(String qualityScore) {
		this.qualityScore = qualityScore;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((qualityGate == null) ? 0 : qualityGate.hashCode());
		result = prime * result + ((qualityGateInd == null) ? 0 : qualityGateInd.hashCode());
		result = prime * result + ((qualityScore == null) ? 0 : qualityScore.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		QualityGateRequest other = (QualityGateRequest) obj;
		if (qualityGate == null) {
			if (other.qualityGate != null)
				return false;
		}
		else if (!qualityGate.equals(other.qualityGate))
			return false;
		if (qualityGateInd == null) {
			if (other.qualityGateInd != null)
				return false;
		}
		else if (!qualityGateInd.equals(other.qualityGateInd))
			return false;
		if (qualityScore == null) {
			if (other.qualityScore != null)
				return false;
		}
		else if (!qualityScore.equals(other.qualityScore))
			return false;
		return true;
	}

}
