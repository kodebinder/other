package com.wellpoint.pc2dash.action.summary;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.dto.performance.summary.SummaryConstructorClass;
import com.wellpoint.pc2dash.dto.performance.summary.SummaryJsonObj;
import com.wellpoint.pc2dash.dto.performance.summary.SummaryObject;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.service.summary.SharedSavingsSummaryServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;


public class GetSharedSavingsSummaryAction extends Action {

	@SuppressWarnings({"unchecked"})
	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		ActionResponse response = new GetSharedSavingsSummaryResponse();
		//		PCMSRequest request = new HashMap<String,String>();
		List<SummaryConstructorClass> resultList = null;
		//PCMSP-243
		SummaryObject summaryObject;
		HashSet<String> uniqueLobDesc = new HashSet<String>();
		MetaData metaData = new MetaData();
		SharedSavingsSummaryServiceImpl service = new SharedSavingsSummaryServiceImpl();
		GetSharedSavingsSummaryRequest request = (GetSharedSavingsSummaryRequest) actionRequest;
		List<String> filteredProvGrpList = new ArrayList<String>();
		String provGrpCSVWithGrpIndY = Constants.BLANK;
		String provGrpCSVWithGrpIndN = Constants.BLANK;
		List<SummaryJsonObj> beanList = new ArrayList<SummaryJsonObj>();
		int totalRecords = 0;
		ErrorProperties err = ErrorProperties.getInstance();

		try {
			//			request = getDataMap(request);

			//Kill switch check on Provider groups
			if (null != request) {
				filteredProvGrpList = filterProvGrpsByKillSwitch(request);
			}

			//Clinical access check on provider groups
			if (null != request && null != filteredProvGrpList && filteredProvGrpList.size() > 0) {
				filteredProvGrpList = filterProvGrpsByFinancialInd(request, filteredProvGrpList);
			}


			//Group Ind Y list
			if (null != request && null != filteredProvGrpList && filteredProvGrpList.size() > 0) {
				provGrpCSVWithGrpIndY = prepareProvGrpCSVWithGrpInd(request, filteredProvGrpList, Constants.GRP_IND_Y);
				provGrpCSVWithGrpIndN = prepareProvGrpCSVWithGrpInd(request, filteredProvGrpList, Constants.GRP_IND_N);
			}

			//Group Ind Y list
			if (null != request && null != provGrpCSVWithGrpIndY && !provGrpCSVWithGrpIndY.isEmpty()) {
				if (request.getProviderGroupDimKey() != null) {
					request.setProvGrpIds(provGrpCSVWithGrpIndY);
					request.setGrpInd(Constants.GRP_IND_Y);
					//PCMSP-243
					//resultList = service.getData(request);
					summaryObject = service.getData(request);
					resultList = summaryObject.getResults();
					uniqueLobDesc = summaryObject.getUniqueLobDesc();
					metaData.setLobDesc(new ArrayList<String>(uniqueLobDesc));
					beanList = service.getBeanList(resultList, request);
					totalRecords = service.getTotalRecords();
				}

			}

			//Group Ind N list
			if (null != request && null != provGrpCSVWithGrpIndN && !provGrpCSVWithGrpIndN.isEmpty()) {
				if (request.getProviderGroupDimKey() != null) {
					request.setProvGrpIds(provGrpCSVWithGrpIndN);
					request.setGrpInd(Constants.GRP_IND_N);
					//PCMSP-243
					//resultList = service.getData(request);
					summaryObject = service.getData(request);
					resultList = summaryObject.getResults();
					uniqueLobDesc = summaryObject.getUniqueLobDesc();
					metaData.setLobDesc(new ArrayList<String>(uniqueLobDesc));
					beanList.addAll(service.getBeanList(resultList, request));
					totalRecords = totalRecords + service.getTotalRecords();
				}
			}

			if (null == beanList || (null != beanList && beanList.isEmpty())) {
				response.setMessage(err.getProperty("successNoData"));
			}
			else {
				response.setData(beanList);
				response.setTotal(totalRecords);
				response.setMetaData(metaData);
				response.setMessage(err.getProperty("successful"));
			}

			response.setSuccess(true);

		}
		catch (Exception pe) {
			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

		return response;
	}

	//	public Map<String, String> getDataMap(GetSharedSavingsSummaryRequest request)
	// {
	//		//PCMSRequest request = new HashMap<String, String>();
	//		request.put("provGrpId", request.getProviderGroupId());
	//		request.put("provGrpDimKey",request.getProviderGroupDimKey());
	//		request.put("lob", request.getLob());
	//		request.put("measurementInterval", request.getMeasurementInterval());
	//		request.put("programId", request.getProgramId());
	//		request.put("measurementPeriodStartDt", request.getMeasurementPeriodStartDt());
	//		request.put("measurementPeriodEndDt", request.getMeasurementPeriodEndDt());
	//		request.put("products", request.getProducts());
	//		//request.setCmpId(request.getCmpId());
	//		request.setProvGrpIds(request.getProviderGroupId());
	//		request.put(Constants.USER_ACS_INFO_JSON, request.getUserAcsInfoJson());
	//		//request.put("sessionId", request.getSessionId());
	//		//request.put("entitlementId", request.getEntitlementId());
	//		request.put("msrmntStrtDt", request.getMeasurementPeriodStartDt());
	//		return request;
	//	}

}
