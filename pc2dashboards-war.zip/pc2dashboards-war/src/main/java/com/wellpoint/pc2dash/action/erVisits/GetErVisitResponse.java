package com.wellpoint.pc2dash.action.erVisits;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetErVisitResponse extends ActionResponse {

}
