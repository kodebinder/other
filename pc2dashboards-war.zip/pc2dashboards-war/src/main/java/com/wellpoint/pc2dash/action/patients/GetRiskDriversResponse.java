package com.wellpoint.pc2dash.action.patients;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetRiskDriversResponse extends ActionResponse {

	/*private Collection<Pc2DashError> errors = new Vector<Pc2DashError>();
	private Collection<String> errorFields = new Vector<String>();*/

	/*public Collection<Pc2DashError> getErrors() {
		return errors;
	}

	public void setErrors(Collection<Pc2DashError> errors) {
		this.errors = errors;
	}

	public Collection<String> getErrorFields() {
		return errorFields;
	}

	public void setErrorFields(Collection<String> errorFields) {
		this.errorFields = errorFields;
	}
	*/
}
