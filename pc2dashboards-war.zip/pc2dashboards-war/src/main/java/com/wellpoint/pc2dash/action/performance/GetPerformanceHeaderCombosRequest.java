package com.wellpoint.pc2dash.action.performance;

import com.wellpoint.pc2dash.data.dto.PCMSRequest;

public class GetPerformanceHeaderCombosRequest extends PCMSRequest {

}
