package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.action.tooltip.GetPatientDetailRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.patient.HighRiskDriversToolTip;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;

public class HighRiskDriversFacts extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(HighRiskDriversFacts.class);

	public boolean read(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void insert(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void update(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void delete(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public Collection<HighRiskDriversToolTip> getHighRiskDriversForPharmacy(GetPatientDetailRequest request) throws Exception {
		Collection<HighRiskDriversToolTip> result = new ArrayList<HighRiskDriversToolTip>();

		StringBuilder sql = new StringBuilder()
			.append("select DISTINCT")
			.append("	RISK_DRVR_TYPE_CD, ")
			.append("	RISK_DRVR_CTGRY_NM, ")
			.append("	SORT_NBR, ")
			.append("	RISK_DRVR_NM, ")
			.append("	RISK_IDNTFD_DT, ")
			.append("	CASE WHEN RISK_DRVR_TYPE_CD = 'H' THEN 1 ")
			.append("	WHEN RISK_DRVR_TYPE_CD = 'P' THEN 2 ")
			.append("	ELSE 3 END AS RANKING ")
			.append("FROM ")
			.append("	PAT_RISK_DRVR ")
			.append("where ")
			.append("  PAT_ID = ? AND RISK_DRVR_TYPE_CD IN ( ? , 'H') ")
			.append("	ORDER BY ")
			.append("	RANKING, SORT_NBR ")
			.append(" with ur ");


		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());
			if (request.getMemberKey() != null)
				ps.setString(1, request.getMemberKey());
			if (request.getHighRiskRxIndCd() != null)
				ps.setString(2, request.getHighRiskRxIndCd());

			executeQuery(logger, sql.toString());

			while (rs.next()) {

				HighRiskDriversToolTip hr = new HighRiskDriversToolTip();
				hr.setHighRiskDrugDrivers(getString(rs, "RISK_DRVR_NM"));
				hr.setDateIdentified(getDate(rs, "RISK_IDNTFD_DT"));
				if (rs.getString("SORT_NBR") != null) {
					hr.setSortNo(rs.getString("SORT_NBR"));
				}
				else {
					hr.setSortNo(Constants.ZERO);
				}
				result.add(hr);
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get HighRiskDriversForPharmacy Details (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}

	public Collection<HighRiskDriversToolTip> getHighRiskDriversForEarly(GetPatientDetailRequest request) throws Exception {
		Collection<HighRiskDriversToolTip> result = new ArrayList<HighRiskDriversToolTip>();

		StringBuilder sql =
			new StringBuilder()
				.append("select DISTINCT ")
				.append("	RD.RISK_DRVR_TYPE_CD, ")
				.append("	RD.SORT_NBR, ")
				.append("	RD.RISK_DRVR_NM, ")
				.append("   RD.RISK_IDNTFD_DT, ")
				.append("	CASE WHEN RD.RISK_DRVR_TYPE_CD = 'H' THEN 1 ")
				.append("	WHEN RD.RISK_DRVR_TYPE_CD = 'P' THEN 2 ")
				.append("	ELSE 3 END AS RANKING ")
				.append("FROM ")
				.append("	PAT_RISK_DRVR RD ")
				.append("where ")
				.append("  RD.PAT_ID = ? AND RD.RISK_DRVR_TYPE_CD IN ( ? , 'H') ")
				.append("	ORDER BY ")
				.append("	RANKING, SORT_NBR ")
				.append(" with ur ");


		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());
			if (request.getMemberKey() != null)
				ps.setString(1, request.getMemberKey());
			if (request.getHighRiskRxIndCd() != null)
				ps.setString(2, request.getHighRiskRxIndCd());

			executeQuery(logger, sql.toString());
			
			while (rs.next()) {

				HighRiskDriversToolTip hr = new HighRiskDriversToolTip();
				hr.setHighRiskDrugDrivers(getString(rs, "RISK_DRVR_NM"));
				hr.setDateIdentified(getDate(rs, "RISK_IDNTFD_DT"));
				hr.setSortNo(Constants.ZERO);
				result.add(hr);
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get HighRiskDriversForEarly Details (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}

	public Collection<HighRiskDriversToolTip> getHighRiskDriversForEarlyAndPharmacy(GetPatientDetailRequest request) throws Exception {
		Collection<HighRiskDriversToolTip> result = new ArrayList<HighRiskDriversToolTip>();

		StringBuilder sql =
			new StringBuilder()
				.append("select ")
				.append("	RD.RISK_IDNTFD_DT, ")
				.append("	RD.RISK_DRVR_NM, ")
				.append("	CASE WHEN RD.RISK_DRVR_TYPE_CD = 'H' THEN 1 ")
				.append("	WHEN RD.RISK_DRVR_TYPE_CD = 'P' THEN 2 ")
				.append("	ELSE 3 END AS RANKING ")
				.append("FROM ")
				.append("	PAT_RISK_DRVR RD ")
				.append("where ")
				.append("  RD.PAT_ID = ? AND  RD.RISK_DRVR_TYPE_CD in  ('E','P','H') ")
				.append("ORDER BY RANKING, SORT_NBR ")
				.append(" with ur ");


		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());
			if (request.getMemberKey() != null)
				ps.setString(1, request.getMemberKey());

			executeQuery(logger, sql.toString());

			while (rs.next()) {

				HighRiskDriversToolTip hr = new HighRiskDriversToolTip();
				hr.setHighRiskDrugDrivers(getString(rs, "RISK_DRVR_NM"));
				hr.setDateIdentified(getDate(rs, "RISK_IDNTFD_DT"));
				hr.setSortNo(Constants.ZERO);
				result.add(hr);
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get HighRiskDriversForEarlyAndPharmacy Details (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}

}
