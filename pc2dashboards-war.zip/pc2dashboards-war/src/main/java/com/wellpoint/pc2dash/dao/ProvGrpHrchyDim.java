package com.wellpoint.pc2dash.dao;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

public class ProvGrpHrchyDim implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long provGrpHrchyDimKey;

	private Long crtdLoadLogKey;

	private String ipNpi;

	private String npiCd;

	private Date provGrpHrchyEfctvDt;

	private Date provGrpHrchyTrmntnDt;

	private String provGrpHrchyTrmntnRsnCd;

	private String provOrgTaxId;

	private String rcrdSttsCd;

	private Timestamp sorDtm;

	private Long updtdLoadLogKey;

	public ProvGrpHrchyDim() {}

	public Long getProvGrpHrchyDimKey() {
		return this.provGrpHrchyDimKey;
	}

	public void setProvGrpHrchyDimKey(Long provGrpHrchyDimKey) {
		this.provGrpHrchyDimKey = provGrpHrchyDimKey;
	}

	public Long getCrtdLoadLogKey() {
		return this.crtdLoadLogKey;
	}

	public void setCrtdLoadLogKey(Long crtdLoadLogKey) {
		this.crtdLoadLogKey = crtdLoadLogKey;
	}

	public String getIpNpi() {
		return this.ipNpi;
	}

	public void setIpNpi(String ipNpi) {
		this.ipNpi = ipNpi;
	}

	public String getNpiCd() {
		return this.npiCd;
	}

	public void setNpiCd(String npiCd) {
		this.npiCd = npiCd;
	}

	public Date getProvGrpHrchyEfctvDt() {
		return this.provGrpHrchyEfctvDt;
	}

	public void setProvGrpHrchyEfctvDt(Date provGrpHrchyEfctvDt) {
		this.provGrpHrchyEfctvDt = provGrpHrchyEfctvDt;
	}

	public Date getProvGrpHrchyTrmntnDt() {
		return this.provGrpHrchyTrmntnDt;
	}

	public void setProvGrpHrchyTrmntnDt(Date provGrpHrchyTrmntnDt) {
		this.provGrpHrchyTrmntnDt = provGrpHrchyTrmntnDt;
	}

	public String getProvGrpHrchyTrmntnRsnCd() {
		return this.provGrpHrchyTrmntnRsnCd;
	}

	public void setProvGrpHrchyTrmntnRsnCd(String provGrpHrchyTrmntnRsnCd) {
		this.provGrpHrchyTrmntnRsnCd = provGrpHrchyTrmntnRsnCd;
	}

	public String getProvOrgTaxId() {
		return this.provOrgTaxId;
	}

	public void setProvOrgTaxId(String provOrgTaxId) {
		this.provOrgTaxId = provOrgTaxId;
	}

	public String getRcrdSttsCd() {
		return this.rcrdSttsCd;
	}

	public void setRcrdSttsCd(String rcrdSttsCd) {
		this.rcrdSttsCd = rcrdSttsCd;
	}

	public Timestamp getSorDtm() {
		return this.sorDtm;
	}

	public void setSorDtm(Timestamp sorDtm) {
		this.sorDtm = sorDtm;
	}

	public Long getUpdtdLoadLogKey() {
		return this.updtdLoadLogKey;
	}

	public void setUpdtdLoadLogKey(Long updtdLoadLogKey) {
		this.updtdLoadLogKey = updtdLoadLogKey;
	}
}
