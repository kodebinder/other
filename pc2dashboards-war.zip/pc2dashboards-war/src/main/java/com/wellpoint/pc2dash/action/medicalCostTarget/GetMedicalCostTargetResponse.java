package com.wellpoint.pc2dash.action.medicalCostTarget;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetMedicalCostTargetResponse extends ActionResponse {

}
