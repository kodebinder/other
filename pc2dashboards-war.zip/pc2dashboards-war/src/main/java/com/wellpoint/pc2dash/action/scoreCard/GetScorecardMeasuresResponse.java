package com.wellpoint.pc2dash.action.scoreCard;

import com.wellpoint.pc2dash.action.base.ActionResponse;


public class GetScorecardMeasuresResponse extends ActionResponse {

}
