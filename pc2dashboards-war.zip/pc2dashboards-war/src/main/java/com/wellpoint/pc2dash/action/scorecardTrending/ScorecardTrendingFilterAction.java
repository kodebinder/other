package com.wellpoint.pc2dash.action.scorecardTrending;

import java.util.Collection;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.scorecardTrending.ScorecardTrendingFiltersServiceImpl;
import com.wellpoint.pc2dash.util.ErrorProperties;

/**
 * Action Class to service the static filter request on Scorecard Trending Reports
 * 
 * @Author ad91912
 */
public class ScorecardTrendingFilterAction extends Action {
	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(ScorecardTrendingFilterAction.class);

	@SuppressWarnings({"unchecked"})
	@Override
	public ActionResponse process(ActionRequest actionRequest) {


		ScorecardTrendingFiltersServiceImpl stFilterService = new ScorecardTrendingFiltersServiceImpl();
		ScorecardTrendingFilterRequest request = (ScorecardTrendingFilterRequest) actionRequest;
		ActionResponse result = new ScorecardTrendingFilterResponse();
		ErrorProperties err = ErrorProperties.getInstance();
		Collection<Object> vals = null;
		try {
			//			PCMSRequest request = new HashMap<String,String>();
			//			request.put("programId", request.getProgramId());
			//			request.put("measurementPeriodStartDt", request.getMeasurementPeriodStartDt());
			//			request.put("providerGroupId", request.getProviderGroupId());
			//			request.put("lob", request.getLob());
			//			request.put("programLobTypeCd", request.getProgramLobTypeCd());
			//			//request.put("sessionId", request.getSessionId());
			//			//request.put("entitlementId", request.getEntitlementId());
			vals = stFilterService.getStaticData(request);
			if (null == vals || (null != vals && vals.isEmpty())) {
				result.setMessage(err.getProperty("successNoData"));
				result.setData(vals);
				result.setTotal(0);
			}
			else {
				result.setMessage(err.getProperty("successful"));
				result.setData(vals);
				result.setTotal(vals.size());
			}

			result.setSuccess(true);
		}
		catch (Exception e) {
			logger.error("Unable to retrieve Scorecard Trending filter data detail.", e);

			result.setMessage("Unable to retrieve Scorecard composite  detail.");
			result.setSuccess(false);
		}
		return result;
	}

}
