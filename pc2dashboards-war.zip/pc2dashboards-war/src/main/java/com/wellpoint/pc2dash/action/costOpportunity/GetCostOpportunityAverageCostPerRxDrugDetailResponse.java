/**
 * 
 */
package com.wellpoint.pc2dash.action.costOpportunity;

import com.wellpoint.pc2dash.action.base.ActionResponse;

/**
 * @author AF34286
 *
 */
public class GetCostOpportunityAverageCostPerRxDrugDetailResponse extends ActionResponse {

}
