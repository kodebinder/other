package com.wellpoint.pc2dash.action.drilldown;

import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;

public class GetDrillDownRequest extends PerformanceManagementRequest {

	private String minimumAdmits;
	private String minimumFills;
	private String minimumReadmissions;
	private String parentId;
	private String phrmcyClassNm;
	private String phrmcyDimKeysToggle;
	private String phrmcyDimKeys;
	private String phrmcyFullNms;
	private String phrmcyMsrIds;
	private String phrmcyMsrNms;
	private String drugClassKeys;
	private String drugClassNms;
	private String prescribingPhysicianName;
	private String prescribingProviderId;
	private String prescribingProviderIdToggle;
	private String qualityMeasureKeys;
	private String readmitCtgryNms;
	private String readmitCtgryKeysToggle;
	private String scoreId;
	private String qualityMeasureKeysToggle;
	private String chartImageData;
	private String programNm;
	private String chartTitle;
	private String chartDisclaimer;

	public String getMinimumAdmits() {
		return minimumAdmits;
	}

	public String getMinimumFills() {
		return minimumFills;
	}

	public String getMinimumReadmissions() {
		return minimumReadmissions;
	}

	public String getParentId() {
		return parentId;
	}

	public String getPhrmcyClassNm() {
		return phrmcyClassNm;
	}

	public String getPhrmcyMsrNms() {
		return phrmcyMsrNms;
	}

	public String getPrescribingPhysicianName() {
		return prescribingPhysicianName;
	}

	public String getPrescribingProviderId() {
		return prescribingProviderId;
	}

	public String getQualityMeasureKeys() {
		return qualityMeasureKeys;
	}

	public String getReadmitCtgryNms() {
		return readmitCtgryNms;
	}

	public String getScoreId() {
		return scoreId;
	}

	public void setMinimumAdmits(String minimumAdmits) {
		this.minimumAdmits = minimumAdmits;
	}

	public void setMinimumFills(String minimumFills) {
		this.minimumFills = minimumFills;
	}

	public void setMinimumReadmissions(String minimumReadmissions) {
		this.minimumReadmissions = minimumReadmissions;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public void setPhrmcyClassNm(String phrmcyClassNm) {
		this.phrmcyClassNm = phrmcyClassNm;
	}

	public void setPhrmcyMsrNms(String phrmcyMsrNms) {
		this.phrmcyMsrNms = phrmcyMsrNms;
	}

	public void setPrescribingPhysicianName(String prescribingPhysicianName) {
		this.prescribingPhysicianName = prescribingPhysicianName;
	}

	public void setPrescribingProviderId(String prescribingProviderId) {
		this.prescribingProviderId = prescribingProviderId;
	}

	public void setQualityMeasureKeys(String qualityMeasureKeys) {
		this.qualityMeasureKeys = qualityMeasureKeys;
	}

	public void setReadmitCtgryNms(String readmitCtgryNms) {
		this.readmitCtgryNms = readmitCtgryNms;
	}

	public void setScoreId(String scoreId) {
		this.scoreId = scoreId;
	}

	//	public void setSortObj(QuerySort sortObj) {
	//		this.sortObj = sortObj;
	//	}

	public String getPhrmcyFullNms() {
		return phrmcyFullNms;
	}

	public void setPhrmcyFullNms(String phrmcyFullNms) {
		this.phrmcyFullNms = phrmcyFullNms;
	}

	public String getPhrmcyMsrIds() {
		return phrmcyMsrIds;
	}

	public void setPhrmcyMsrIds(String phrmcyMsrIds) {
		this.phrmcyMsrIds = phrmcyMsrIds;
	}

	public String getReadmitCtgryKeysToggle() {
		return readmitCtgryKeysToggle;
	}

	public void setReadmitCtgryKeysToggle(String readmitCtgryKeysToggle) {
		this.readmitCtgryKeysToggle = readmitCtgryKeysToggle;
	}

	public String getPhrmcyDimKeysToggle() {
		return phrmcyDimKeysToggle;
	}

	public void setPhrmcyDimKeysToggle(String phrmcyDimKeysToggle) {
		this.phrmcyDimKeysToggle = phrmcyDimKeysToggle;
	}

	public String getPhrmcyDimKeys() {
		return phrmcyDimKeys;
	}

	public void setPhrmcyDimKeys(String phrmcyDimKeys) {
		this.phrmcyDimKeys = phrmcyDimKeys;
	}

	public String getQualityMeasureKeysToggle() {
		return qualityMeasureKeysToggle;
	}

	public void setQualityMeasureKeysToggle(String qualityMeasureKeysToggle) {
		this.qualityMeasureKeysToggle = qualityMeasureKeysToggle;
	}

	public String getPrescribingProviderIdToggle() {
		return prescribingProviderIdToggle;
	}

	public void setPrescribingProviderIdToggle(String prescribingProviderIdToggle) {
		this.prescribingProviderIdToggle = prescribingProviderIdToggle;
	}

	public String getDrugClassKeys() {
		return drugClassKeys;
	}

	public void setDrugClassKeys(String drugClassKeys) {
		this.drugClassKeys = drugClassKeys;
	}

	public String getChartImageData() {
		return chartImageData;
	}

	public void setChartImageData(String chartImageData) {
		this.chartImageData = chartImageData;
	}
	
	public String getProgramNm() {
		return programNm;
	}

	public void setProgramNm(String programNm) {
		this.programNm = programNm;
	}

	public String getChartTitle() {
		return chartTitle;
	}

	public void setChartTitle(String chartTitle) {
		this.chartTitle = chartTitle;
	}

	public String getChartDisclaimer() {
		return chartDisclaimer;
	}

	public void setChartDisclaimer(String chartDisclaimer) {
		this.chartDisclaimer = chartDisclaimer;
	}

	public String getDrugClassNms() {
		return drugClassNms;
	}

	public void setDrugClassNms(String drugClassNms) {
		this.drugClassNms = drugClassNms;
	}

}
