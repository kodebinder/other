package com.wellpoint.pc2dash.action.quality;

import com.wellpoint.pc2dash.action.base.ActionResponse;

/**
 * Rather than create nearly identical classes for
 * getQualityPatients, getQualityProviders, and getQualityChart,
 * have them all use this class.
 */
public class GetQualityResponse extends ActionResponse {

}
