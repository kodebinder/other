package com.wellpoint.pc2dash.data.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.costOpportunity.GetInpatientUtilizationCategoryRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.costOpportunity.InpatientUtilizationCategoryBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class InpatientUtilizationCategoryDao extends ServiceImpl {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(InpatientUtilizationCategoryDao.class);
	private boolean displayDashes = false;
	
	public List<InpatientUtilizationCategoryBean> getData(GetInpatientUtilizationCategoryRequest request,
		boolean exportFlag, int index, int limit) throws Exception {

		//Added for PCMSP-6869 : Minimum Criteria Implementation : Starts
		String dir = request.getSort().get(0).getDirection();
		String masked = "ASC".equalsIgnoreCase(dir) ? String.valueOf(Integer.MAX_VALUE) : String.valueOf(Integer.MIN_VALUE);
		String dashesClause =
			" C.MBR_CNDTN_CNT < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_IP_UTL_MIN_TOTL_EVNT' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG') ";
		String multiplePgmCheck_90_Perc = " or  C.BNCH_90_CNT > 1 ";



		//Added for PCMSP-6869 : Minimum Criteria Implementation : Ends

		List<InpatientUtilizationCategoryBean> result = new ArrayList<InpatientUtilizationCategoryBean>();
		setRowCount(0);


		

		StringBuilder query = new StringBuilder()
			.append(" select ilv2.* ")
			.append(" from( ")
			.append(" select ilv1.*, row_number() over( order by ")
			.append(buildSortClause(request))
			.append(" ) as row_nbr ")
			.append(" from( ")
			.append(" select  C.CATEGORYCODE as categoryCode ")
			.append(" ,C.CATEGORY as category ")
			.append(" ,case when ")
			.append(dashesClause)
			.append(" then ")
			.append(masked)
			.append("  when C.Days_Over_Benchmark > 0 and  C.Allowed_cost_per_day > 0  then cast(C.Days_Over_Benchmark as decimal(18,4)) * cast(C.Allowed_cost_per_day as decimal(18,4)) else 0.00 end as totalOpportunity  ")
			.append(" ,case when ")
			.append(dashesClause)
			.append(" then ")
			.append(masked)
			.append(" when C.Days_Over_Benchmark > 0 and  C.Allowed_cost_per_day > 0 then cast(C.Days_Over_Benchmark as decimal(18,4)) * cast(C.Allowed_cost_per_day as decimal(18,4))*0.1 else 0.00 end as tenPercentImprovement ")
			.append(" ,case when ")
			.append(dashesClause)
			.append(" then ")
			.append(masked)
			.append(
				" when C.MEM_MNTH > 0 and C.Days_Over_Benchmark > 0 and  C.Allowed_cost_per_day >0  then cast(C.Days_Over_Benchmark as decimal(18,4)) * cast(C.Allowed_cost_per_day as decimal(18,4))/ cast(C.MEM_MNTH as decimal(18,4)) else 0.00 end as totalOpportunityPMPM ")
			.append(" ,case when ")
			.append(dashesClause)
			.append(" then ")
			.append(masked)
			.append(
				" when C.MEM_MNTH >0  and  C.Days_Over_Benchmark > 0 and  C.Allowed_cost_per_day > 0 then cast(cast(C.Days_Over_Benchmark as decimal(18,4)) * cast(C.Allowed_cost_per_day as decimal(18,4)) *0.1 as decimal(18,4))/ cast(C.MEM_MNTH as decimal(18,4)) else 0.00 end  as tenPercentImprovementPMPM ")
			.append(" ,case when C.MBR_CNDTN_CNT > 0 then C.MBR_CNDTN_CNT else 0.00 end  as membersWithCondition ")
			.append(" ,case when ")
			.append(dashesClause)
			.append(" then ")
			.append(masked)
			.append(" when C.SVRTY_ADJSTMNT> 0 then C.SVRTY_ADJSTMNT else 0.00 end  as severityAdjustment ")
			.append(" ,case when C.TC_INPAT_DAY_CNT > 0 then C.TC_INPAT_DAY_CNT else 0.00 end  as totalInpatientDays ")
			.append(" ,case when ")
			.append(dashesClause)
			.append(" then ")
			.append(masked)
			.append(" when C.Perf_Rate > 0 then C.Perf_Rate else 0.00 end  as currentPerformanceRate ")
			.append(" ,case when ")
			.append(dashesClause)
			.append(multiplePgmCheck_90_Perc)
			.append(" then ")
			.append(masked)
			.append(" when C.BNCHMRK_PCTILE_90_NBR > 0 then C.BNCHMRK_PCTILE_90_NBR else 0.00 end  as percentileBenchmark90 ")
			.append(" ,case when ")
			.append(dashesClause)
			.append(" then ")
			.append(masked)
			.append(" when C.Days_Over_Benchmark >0 then C.Days_Over_Benchmark else 0.00 end as daysOverBenchmark ")
			.append(" ,case when ")
			.append(dashesClause)
			.append(" then ")
			.append(masked)
			.append(" when C.Allowed_cost_per_day >0 then C.Allowed_cost_per_day else 0.00 end  as allowedCostPerDay ")
			.append(" ,case when ")
			.append(dashesClause)
			.append(" then ")
			.append(masked)
			.append(" when C.Admits_Above_Benchmark >0 then C.Admits_Above_Benchmark else 0.00 end  as numberOfAdmitsAboveBenchmark ")
			.append(" ,case when ")
			.append(dashesClause)
			.append(" then ")
			.append(masked)
			.append(" when C.LOS_Above_Benchmark>0 then C.LOS_Above_Benchmark else 0.00 end  as lengthOfStayAboveBenchmark ")
			.append(" ,C.BNCH_90_CNT as BNCH_90_CNT ")
			.append(" ,case when ")
			.append(dashesClause)
			.append(" then ")
			.append(masked)
			.append(" when C.ADMT_CNT>0 then C.ADMT_CNT else 0 end  as totalAdmissions ")
			.append(" ,case when ")
			.append(dashesClause)
			.append(" then 'Y' else 'N' end as dsply_dashes ")
			.append(" ,count(*) over () as row_cnt ")
			.append(" from ")
			.append(" ( ")
			.append(" select  ")
			.append("  B.CATEGORYCODE ")
			.append(" ,B.CATEGORY ")
			.append(" ,B.SVRTY_ADJSTMNT ")
			.append(" ,B.BNCHMRK_PCTILE_90_NBR ")
			.append(" ,B.TC_INPAT_DAY_CNT ")
			.append(" ,case when B.TC_INPAT_DAY_CNT>B.Days_At_Benchmark then (B.TC_INPAT_DAY_CNT - B.Days_At_Benchmark) else 0 end as Days_Over_Benchmark ")
			.append(" ,B.ADMT_CNT - B.Admits_At_Benchmark as Admits_Above_Benchmark  ")
			.append(" ,B.MBR_CNDTN_CNT ")
			.append(" ,B.Allowed_cost_per_day  ")
			.append(" ,B.Perf_Rate ")
			.append(" ,B.LOS_Above_Benchmark  ")
			.append(" ,B.BNCH_90_CNT ")
			.append(" ,B.ADMT_CNT ")
			.append(" ,B.MEM_MNTH ")
			.append(" from  ")
			.append(" ( ")
			.append(" select A.CATEGORYCODE ")
			.append(" ,A.CATEGORY ")
			.append(" ,A.SVRTY_ADJSTMNT ")
			.append(" ,A.BNCHMRK_PCTILE_90_NBR ")
			.append(
				" ,case when A.MBR_CNDTN_CNT>0 and A.SVRTY_ADJSTMNT>0 and BNCH_90_CNT =1 then  CAST(((CAST(A.BNCHMRK_PCTILE_90_NBR AS DECIMAL(18,4)) * CAST(A.MBR_CNDTN_CNT AS DECIMAL(18,4))) / 1000) AS DECIMAL(18,4)) *CAST(A.SVRTY_ADJSTMNT AS DECIMAL(18,4)) else  0.0 end as Days_At_Benchmark   ")
			.append(" ,case when A.MBR_CNDTN_CNT>0 and A.SVRTY_ADJSTMNT>0 then  CAST(((CAST(A.ADMT_BNCHMRK AS DECIMAL(18,4)) * CAST(A.MBR_CNDTN_CNT AS DECIMAL(18,4))) / 1000) AS DECIMAL(18,4)) * CAST(A.SVRTY_ADJSTMNT AS DECIMAL(18,4)) else  0.0 end as Admits_At_Benchmark ")
			.append(" ,A.MBR_CNDTN_CNT	 ")
			.append(" ,A.ADMT_CNT    ")
			.append(" ,A.TC_INPAT_DAY_CNT ")
			.append(" ,A.Allowed_cost_per_day ")
			.append(" ,case when A.MBR_CNDTN_CNT>0 and A.SVRTY_ADJSTMNT>0 then   CAST(((CAST(TC_INPAT_DAY_CNT AS DECIMAL(18,4)) / CAST(MBR_CNDTN_CNT AS DECIMAL(18,4))) * 1000) AS DECIMAL(18,4)) / cast(SVRTY_ADJSTMNT as decimal(18,4))  else  0.00 END AS PERF_RATE ")
			.append(" ,A.Avg_LOS - A.LOS_BNCHMRK as LOS_Above_Benchmark  ")
			.append(" ,A.BNCH_90_CNT ")
			.append(" ,A.MEM_MNTH ")
			.append(" from	    ")
			.append(" ( ")
			.append(" select  trim(SUB_MTRC_CD) AS CATEGORYCODE  ")
			.append(" ,trim(SUB_MTRC_NM) AS CATEGORY  ")
			.append(
				" ,case when sum(SMRY.EPSD_CNT) > 0 and max(SMRY.SVRTY_BNCHMRK) >0  then cast(cast (sum(SMRY.SVRTY_SCR_NBR) as decimal(18,4)) / cast (sum(SMRY.EPSD_CNT) as decimal(18,4)) as decimal(18,4))/ cast(max(SMRY.SVRTY_BNCHMRK) as decimal(18,4)) else 0.00 end as SVRTY_ADJSTMNT  ")
			.append(
				" ,case when sum(SMRY.TC_INPAT_DAY_CNT) > 0 then cast (sum(SMRY.TOTL_ALWD_AMT) as decimal(18,4))/ cast (sum(SMRY.TC_INPAT_DAY_CNT) as decimal(18,4)) else 0.00 end as Allowed_cost_per_day  ")
			.append(
				" ,case when sum(SMRY.ADMT_CNT) > 0 then  cast (sum(SMRY.TC_INPAT_DAY_CNT) as decimal(18,4))/ cast (sum(SMRY.ADMT_CNT) as decimal(18,4)) else 0.00 end as Avg_LOS  ")
			.append(" ,cast (sum(SMRY.SVRTY_SCR_NBR) as decimal(18,4)) as SVRTY      ")
			.append(" ,cast (sum(SMRY.MBR_CNDTN_CNT) as decimal(18,4)) as MBR_CNDTN_CNT  ")
			.append(" ,cast (max(SMRY.SVRTY_BNCHMRK) as decimal(18,4)) as SVRTY_BNCMRK   ")
			.append(" ,cast (max(SMRY.BNCHMRK_PCTILE_90_NBR) as decimal(18,4))  as BNCHMRK_PCTILE_90_NBR  ")
			.append(" ,cast (sum(SMRY.TC_INPAT_DAY_CNT) as decimal(18,4))  as TC_INPAT_DAY_CNT    ")
			.append(" ,cast (sum(SMRY.TOTL_ALWD_AMT) as decimal(18,4))  as TOTL_ALWD_AMT    ")
			.append(" ,cast (max(SMRY.ADMT_BNCHMRK) as decimal(18,4)) as ADMT_BNCHMRK    ")
			.append(" ,cast (sum(SMRY.ADMT_CNT) as decimal(18,4)) as ADMT_CNT    ")
			.append(" ,cast (max(SMRY.LOS_BNCHMRK) as decimal(18,4)) as LOS_BNCHMRK  ")
			.append(" ,SUM(count(distinct SMRY.BNCHMRK_PCTILE_90_NBR)) over (partition by smry.SUB_MTRC_CD, smry.sub_mtrc_nm)  as BNCH_90_CNT  ")
			.append(" ,ILV.MEM_MNTH   ")

			.append(" FROM COC_IP_UTL_CTGRY_SMRY AS SMRY ")
			.append(" join  ( ")
			.append(" select    nvl(SUM(MM.MBR_MNTH_12_CNT),0) as MEM_MNTH   ")
			.append(" from   PAT_SMRY_FACT PSF   ")
			.append(" inner join   MSTR_CNSMR_MBR_MNTH_FACT MM ON  MM.MSTR_CNSMR_DIM_KEY = PSF.MSTR_CNSMR_DIM_KEY   ")
			.append(" and  MM.RCRD_STTS_CD = 'ACT'   ")
			.append(" and  PSF.ATRBN_STTS_CD = 'ACTIVE'   ");
		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and psf.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and psf.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {

			query.append(" and psf.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");

		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and psf.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and psf.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}
		query.append(" ) as ILV on 1=1   ")
			.append("         join  poit_user_scrty_acs pusa on (smry.prov_grp_id = pusa.prov_grp_id and ")
			.append("           case ")
			.append("                      when    pusa.prov_org_tax_id = '0' ")
			.append("                      then    smry.prov_org_tax_id ")
			.append("                      else    pusa.prov_org_tax_id end = smry.prov_org_tax_id) ")
			.append("       where  pusa.sesn_id = ? ")
			.append("       and  pusa.enttlmnt_hash_key = ? ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and smry.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and smry.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and smry.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and smry.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and smry.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}
		if (StringUtil.isNotBlankOrFalse(request.getSpecialtyCode())) {
			query.append(" and smry.SUB_MTRC_CD in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getSpecialtyCode())
				+ ") ");
		}


		if (StringUtil.isNotBlankOrFalse(request.getCategoryCode())) {
			query.append(" and smry.SUB_MTRC_CD in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getCategoryCode())
				+ ") ");
		}

		query.append(" GROUP BY SMRY.SUB_MTRC_CD, SMRY.SUB_MTRC_NM,ILV.MEM_MNTH) as A) as B) as C) as ilv1) as ilv2 ")

			.append(" 			 where ilv2.row_nbr between ? and ? ")
			.append(" order by ilv2.row_nbr ")
			.append(" with ur  ");
			
			

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());

			buildPreparedStatement(request, i, exportFlag, index, limit);

			executeQuery(logger, query.toString());

			result = convertSelectedRowsToObjects(rs, request, displayDashes, exportFlag);

		}
		catch (Exception e) {

			throw new Exception("Unable to get InpatientUtilizationCategoryDao (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;

	}

	private void buildPreparedStatement(GetInpatientUtilizationCategoryRequest request, int i, boolean exportFlag, int index, int limit) throws SQLException {


		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		int start = 0;
		int stop = 0;

		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getCategoryCode())) {
			String[] array = request.getCategoryCode().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (!exportFlag) {
			start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
			stop = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
		}
		else {
			start = index;
			stop = limit;
		}
		ps.setInt(++i, start + 1);
		ps.setInt(++i, start + stop);

	}

	private List<InpatientUtilizationCategoryBean> convertSelectedRowsToObjects(ResultSet rs, GetInpatientUtilizationCategoryRequest request,
		boolean displayDashes, boolean exportFlag) throws SQLException {

		List<InpatientUtilizationCategoryBean> list = new ArrayList<InpatientUtilizationCategoryBean>();

		while (rs.next()) {

			InpatientUtilizationCategoryBean item = new InpatientUtilizationCategoryBean();

			//Added for PCMSP-6869 : Starts
			if (rs.getString("categoryCode") != null) {
				item.setCategoryCode(rs.getString("categoryCode"));
			}

			if (rs.getString("category") != null) {
				item.setCategory(rs.getString("category"));
			}
			
			if (rs.getString("membersWithCondition") != null) {
				item.setMembersWithCondition(StringUtil.convertStringToCommaBigDecimal(
					rs.getBigDecimal("membersWithCondition").setScale(0, BigDecimal.ROUND_HALF_UP).toString(), 0));				
			}
			
			if (rs.getString("totalInpatientDays") != null) {
				item.setTotalInpatientDays(StringUtil.convertStringToCommaBigDecimal(
					rs.getBigDecimal("totalInpatientDays").setScale(0, BigDecimal.ROUND_HALF_UP).toString(), 0));	
			}

			if (rs.getString("dsply_dashes") != null && rs.getString("dsply_dashes").equalsIgnoreCase(Constants.Y)) {
				displayDashes = true;
			}
			else {
				displayDashes = false;
			}
			//Added for PCMSP-6869 : Ends

			if (displayDashes) {

				item.setTotalOpportunity(Constants.DASHES);
				item.setTenPercentImprovement(Constants.DASHES);
				item.setTotalOpportunityPMPM(Constants.DASHES);
				item.setTenPercentImprovementPMPM(Constants.DASHES);
				item.setSeverityAdjustment(Constants.DASHES);
				item.setCurrentPerformanceRate(Constants.DASHES);
				item.setPercentileBenchmark90(Constants.DASHES);
				item.setDaysOverBenchmark(Constants.DASHES);
				item.setAllowedCostPerDay(Constants.DASHES);
				item.setNumberOfAdmitsAboveBenchmark(Constants.DASHES);
				item.setLengthOfStayAboveBenchmark(Constants.DASHES);
				item.setTotalAdmissions(Constants.DASHES);
				//item.setHasCategoryDrilldownInd(Constants.BOOL_FALSE);
			}
			else {
				if (exportFlag) {

					if (rs.getString("totalOpportunity") != null) {
						item.setTotalOpportunity(StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("totalOpportunity").setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
					}
					else {
						item.setTotalOpportunity(Constants.DASHES);
					}
					if (rs.getString("tenPercentImprovement") != null) {
						item.setTenPercentImprovement(
							StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("tenPercentImprovement").setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
					}
					if (rs.getString("totalOpportunityPMPM") != null) {
						item.setTotalOpportunityPMPM(
							StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("totalOpportunityPMPM").setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
					}
					if (rs.getString("tenPercentImprovementPMPM") != null) {
						item.setTenPercentImprovementPMPM(
							StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("tenPercentImprovementPMPM").setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
					}
					if (rs.getString("membersWithCondition") != null) {
						item.setMembersWithCondition(StringUtil.convertStringToCommaBigDecimal(
							rs.getBigDecimal("membersWithCondition").setScale(0, BigDecimal.ROUND_HALF_UP).toString(), 0));
					}
					if (rs.getString("severityAdjustment") != null) {
						item.setSeverityAdjustment(StringUtil.convertStringToCommaBigDecimal(
							rs.getBigDecimal("severityAdjustment").setScale(2, BigDecimal.ROUND_HALF_UP).toString(), 2));

					}
					if (rs.getString("totalInpatientDays") != null) {
						item.setTotalInpatientDays(StringUtil.convertStringToCommaBigDecimal(
							rs.getBigDecimal("totalInpatientDays").setScale(0, BigDecimal.ROUND_HALF_UP).toString(), 0));
					}

					if (rs.getString("currentPerformanceRate") != null) {
						item.setCurrentPerformanceRate(StringUtil.convertStringToCommaBigDecimal(
							rs.getBigDecimal("currentPerformanceRate").setScale(2, BigDecimal.ROUND_HALF_UP).toString(), 2));

					}
					//Changed for PCMSP-6869  : Starts
					if (rs.getString("percentileBenchmark90") != null && rs.getShort("BNCH_90_CNT") == Constants.INT_ONE) {
						item.setPercentileBenchmark90(StringUtil.convertStringToCommaBigDecimal(
							rs.getBigDecimal("percentileBenchmark90").setScale(2, BigDecimal.ROUND_HALF_UP).toString(), 2));
					}
					else {
						item.setPercentileBenchmark90(Constants.DASHES);
					}
					//Changed for PCMSP-6869  : Ends

					if (rs.getString("daysOverBenchmark") != null) {
						item.setDaysOverBenchmark(StringUtil.convertStringToCommaBigDecimal(
							rs.getBigDecimal("daysOverBenchmark").setScale(0, BigDecimal.ROUND_HALF_UP).toString(), 0));

					}
					if (rs.getString("allowedCostPerDay") != null) {
						item.setAllowedCostPerDay(StringUtil.convertStringToDecimalCurrency(
							rs.getBigDecimal("allowedCostPerDay").setScale(2, BigDecimal.ROUND_HALF_UP).toString()));

					}
					if (rs.getString("numberOfAdmitsAboveBenchmark") != null) {
						item.setNumberOfAdmitsAboveBenchmark(StringUtil.convertStringToCommaBigDecimal(
							rs.getBigDecimal("numberOfAdmitsAboveBenchmark").setScale(0, BigDecimal.ROUND_HALF_UP).toString(), 0));

					}
					if (rs.getString("lengthOfStayAboveBenchmark") != null) {
						item.setLengthOfStayAboveBenchmark(StringUtil.convertStringToCommaBigDecimal(
							rs.getBigDecimal("lengthOfStayAboveBenchmark").setScale(1, BigDecimal.ROUND_HALF_UP).toString(), 1));//changed as per Rel:Q1-2018-PCMSP-18424

					}
					if (rs.getString("totalAdmissions") != null) {
						item.setTotalAdmissions(StringUtil.convertStringToCommaBigDecimal(
							rs.getBigDecimal("totalAdmissions").setScale(0, BigDecimal.ROUND_HALF_UP).toString(), 0));//PCMSP-16384
					}

					setTotalExport(rs.getInt("row_cnt"));  
				}
				else {

					if (rs.getString("totalOpportunity") != null) {
						item.setTotalOpportunity(rs.getString("totalOpportunity"));
					}
					else {
						item.setTotalOpportunity(Constants.DASHES);
					}
					if (rs.getString("tenPercentImprovement") != null) {
						item.setTenPercentImprovement(rs.getString("tenPercentImprovement"));
					}
					if (rs.getString("totalOpportunityPMPM") != null) {
						item.setTotalOpportunityPMPM(rs.getString("totalOpportunityPMPM"));
					}
					if (rs.getString("tenPercentImprovementPMPM") != null) {
						item.setTenPercentImprovementPMPM(rs.getString("tenPercentImprovementPMPM"));
					}
					if (rs.getString("membersWithCondition") != null) {
						item.setMembersWithCondition(rs.getString("membersWithCondition"));
					}
					if (rs.getString("severityAdjustment") != null) {
						item.setSeverityAdjustment(rs.getString("severityAdjustment"));
					}
					if (rs.getString("totalInpatientDays") != null) {
						item.setTotalInpatientDays(rs.getString("totalInpatientDays"));
					}
					if (rs.getString("currentPerformanceRate") != null) {
						item.setCurrentPerformanceRate(rs.getString("currentPerformanceRate"));
					}
					//Changed for PCMSP-6869  : Starts
					if (rs.getString("percentileBenchmark90") != null && rs.getShort("BNCH_90_CNT") == Constants.INT_ONE) {
						item.setPercentileBenchmark90(rs.getString("percentileBenchmark90"));
					}
					else {
						item.setPercentileBenchmark90(Constants.DASHES);
					}
					//Changed for PCMSP-6869  : Ends
					if (rs.getString("daysOverBenchmark") != null) {
						item.setDaysOverBenchmark(StringUtil.convertStringToCommaBigDecimal(
							rs.getBigDecimal("daysOverBenchmark").setScale(0, BigDecimal.ROUND_HALF_UP).toString(), 0));						
					}
					if (rs.getString("allowedCostPerDay") != null) {
						item.setAllowedCostPerDay(rs.getString("allowedCostPerDay"));
					}
					if (rs.getString("numberOfAdmitsAboveBenchmark") != null) {
						item.setNumberOfAdmitsAboveBenchmark(StringUtil.convertStringToCommaBigDecimal(
							rs.getBigDecimal("numberOfAdmitsAboveBenchmark").setScale(0, BigDecimal.ROUND_HALF_UP).toString(), 0));						
					}
					if (rs.getString("lengthOfStayAboveBenchmark") != null) {
						item.setLengthOfStayAboveBenchmark(StringUtil.convertStringToCommaBigDecimal(
							rs.getBigDecimal("lengthOfStayAboveBenchmark").setScale(1, BigDecimal.ROUND_HALF_UP).toString(), 1));//changed as per Rel:Q1-2018-PCMSP-18424						
					}
					if (rs.getString("totalAdmissions") != null) {
						item.setTotalAdmissions(rs.getString("totalAdmissions"));
					}
					//item.setHasCategoryDrilldownInd(request.isHasCategoryDrilldownInd());
				}
			}
			if (!displayDashes)
				item.setHasCategoryDrilldownInd(Boolean.TRUE);
			list.add(item);

			if (getRowCount() == 0) {
				setRowCount(rs.getInt("row_cnt"));
			}

		}

		return list;

	}

	private String buildSortClause(GetInpatientUtilizationCategoryRequest request) {

		StringBuilder query = new StringBuilder();
		String defaultColumn = " totalOpportunity ";
		String defaultSort = defaultColumn + " desc ";

		if (null != request.getSort()) {

			for (QuerySort sort : request.getSort()) {

				String dir = sort.getDirection().replaceAll("\"", "");
				String property = sort.getProperty();

				if (property.equals("category")) {
					query.append(" category " + dir + ", " + defaultSort);
				}
				else if (property.equals("totalOpportunity")) {
					query.append(" totalOpportunity " + dir + ", " + defaultSort);
				}
				else if (property.equals("tenPercentImprovement")) {
					query.append(" tenPercentImprovement " + dir + ", " + defaultSort);
				}
				else if (property.equals("totalOpportunityPMPM")) {
					query.append(" totalOpportunityPMPM " + dir + ", " + defaultSort);
				}
				else if (property.equals("tenPercentImprovementPMPM")) {
					query.append(" tenPercentImprovementPMPM " + dir + ", " + defaultSort);
				}
				else if (property.equals("membersWithCondition")) {
					query.append(" membersWithCondition " + dir + ", " + defaultSort);
				}
				else if (property.equals("severityAdjustment")) {
					query.append(" severityAdjustment " + dir + ", " + defaultSort);
				}
				else if (property.equals("totalInpatientDays")) {
					query.append(" totalInpatientDays " + dir + ", " + defaultSort);
				}
				else if (property.equals("currentPerformanceRate")) {
					query.append(" currentPerformanceRate " + dir + ", " + defaultSort);
				}
				else if (property.equals("percentileBenchmark90")) {
					query.append(" percentileBenchmark90 " + dir + ", " + defaultSort);
				}
				else if (property.equals("daysOverBenchmark")) {
					query.append(" daysOverBenchmark " + dir + ", " + defaultSort);
				}
				else if (property.equals("allowedCostPerDay")) {
					query.append(" allowedCostPerDay " + dir + ", " + defaultSort);
				}
				else if (property.equals("numberOfAdmitsAboveBenchmark")) {
					query.append(" numberOfAdmitsAboveBenchmark " + dir + ", " + defaultSort);
				}
				else if (property.equals("lengthOfStayAboveBenchmark")) {
					query.append(" lengthOfStayAboveBenchmark " + dir + ", " + defaultSort);
				}
				else if (property.equals("totalAdmissions")){
					query.append(" totalAdmissions " + dir + ", " + defaultSort);
				}
				else {
					query.append(defaultColumn + dir);
				}
			}

		}

		return query.toString();

	}

}