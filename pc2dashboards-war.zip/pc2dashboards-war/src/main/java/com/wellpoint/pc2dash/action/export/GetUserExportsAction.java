package com.wellpoint.pc2dash.action.export;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.data.dao.UserExports;
import com.wellpoint.pc2dash.data.dto.UserExport;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.ApplicationConfig;


public class GetUserExportsAction extends Action {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetUserExportsAction.class);

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetUserExportsRequest request = (GetUserExportsRequest) actionRequest;
		GetUserExportsResponse response = new GetUserExportsResponse();

		try {

			if (!request.isValid()) {
				throw new Exception("Invalid request.");
			}

			UserExports dao = new UserExports();
			Collection<UserExport> exports = new ArrayList<UserExport>();
			Collection<UserExport> updates = new ArrayList<UserExport>();

			ApplicationConfig cfg = ApplicationConfig.getInstance();
			int maxRuntime = Integer.parseInt(cfg.getProperty("export.runtime"));
			String path = cfg.getProperty("export.path");

			for (UserExport exp : dao.getUserExports(request)) {

				long dtm = System.currentTimeMillis();

				deleteExpiredFile(path, exp, dtm);

				if ("PENDING".equals(exp.getStatusCode())
					&& dtm > (exp.getSubmitDtm().getTime() + maxRuntime)) {

					exp.setStatusCode("ERROR");
					updates.add(exp);
				}

				processCompleteOrRemainingFiles(exports, updates, exp, dtm);
			}

			if (!updates.isEmpty()) {
				dao.updateStatus(updates);
			}

			response.setData(exports);
			response.setTotal(exports.size());
			response.setSuccess(true);
		}
		catch (Exception e) {

			logger.error("Unable to get user exports.", e);

			response.setMessage("Unable to retrieve your list of exports.");
			response.setSuccess(false);
		}

		return response;
	}

  /**
   * @param exports
   * @param updates
   * @param exp
   * @param dtm
   */
  private void processCompleteOrRemainingFiles(Collection<UserExport> exports,
      Collection<UserExport> updates, UserExport exp, long dtm) {
    if ("COMPLETE".equals(exp.getStatusCode())
    	&& dtm > exp.getExpirationDtm().getTime()) {

    	exp.setStatusCode("EXPIRED");
    	updates.add(exp);
    }
    else {

    	exports.add(exp);
    }
  }

  /**
   * @param path
   * @param exp
   * @param dtm
   */
  private void deleteExpiredFile(String path, UserExport exp, long dtm) {
    if (dtm > exp.getExpirationDtm().getTime()) {

    	File file = new File(path + exp.getPhysicalFileName());

    	if (file.exists()) {
    		file.delete();
    	}
    }
  }
}
