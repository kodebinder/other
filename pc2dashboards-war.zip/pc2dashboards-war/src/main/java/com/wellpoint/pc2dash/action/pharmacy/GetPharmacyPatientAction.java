package com.wellpoint.pc2dash.action.pharmacy;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.data.dao.PharmacyPatientGridDao;
import com.wellpoint.pc2dash.dto.pharmacy.PharmacyPatientGrid;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportGridColumn;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.population.PharmacyPatientExport;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetPharmacyPatientAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetPharmacyPatientRequest request = (GetPharmacyPatientRequest) actionRequest;
		ActionResponse response = new GetPharmacyPatientResponse();
		ErrorProperties err = ErrorProperties.getInstance();

		List<PharmacyPatientGrid> resultList = new ArrayList<PharmacyPatientGrid>();
		PharmacyPatientGridDao dao = new PharmacyPatientGridDao();
		List<String> grps = null;

		try {

			removeLobPgmPrefixes(request);

			if (StringUtils.isNotBlank(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			if (!StringUtil.isExportDest(request.getDest())) {
				preparePharmacyScriptsIconSuppressionCond(request);
			}

			if (null != grps && !grps.isEmpty()) {

				request.setProvGrpIdsWithoutClinicalCheck(StringUtils.join(grps, ','));
				grps = filterProvGrpsByClinicalInd(request, grps);
				request.setProvGrpIds(StringUtils.join(grps, ','));
			}

			if (StringUtil.isExportDest(request.getDest())) {

				List<ExportGridColumn> columns = dao.buildExportGridColumns(request);
				PharmacyPatientExport exp = new PharmacyPatientExport(request, columns);

				ExportProcessor.getInstance().submit(exp);

			}
			else {

				if (null != grps && !grps.isEmpty()) {

					resultList = dao.getPatientGrid(request);
					CommonQueries cq = new CommonQueries();

					MetaData metaData = buildMetaData(request, dao);
					metaData.setReportingPeriod(cq.getReportingPeriodForPharmacy());

					if (null == resultList || resultList.isEmpty()) {
						response.setMessage(err.getProperty("successNoData"));
					}
					else {
						response.setMetaData(metaData);
						response.setMessage(err.getProperty("successful"));
						response.setData(resultList);
						response.setTotal(dao.getRowCount());
					}
				}
			}

			response.setSuccess(true);
			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

	}

}
