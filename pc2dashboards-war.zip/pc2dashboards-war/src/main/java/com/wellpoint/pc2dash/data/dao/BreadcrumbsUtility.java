package com.wellpoint.pc2dash.data.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.utilization.GetBreadcrumbRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.patient.BreadCrumbTreeHierarchy;
import com.wellpoint.pc2dash.dto.utilization.UtilizationGDRDrugClass;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;
import com.wellpoint.pc2dash.service.scorecard.commercial.UtilizationBrandFormularyFilterServiceImpl;

public class BreadcrumbsUtility extends Quality {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(UtilizationConditionFilter.class);
	private String defaultToDate = null;
	private String defaultFromDate = null;

	public List<BreadCrumbTreeHierarchy> getBreadCrumbsData(GetBreadcrumbRequest request) throws Exception {

		CommonQueries commonQueries = new CommonQueries();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date toDate = commonQueries.getDefaultToDate();
		Date fromDate = commonQueries.getDefaultFromDate(toDate, 15);
		String subCompositeId = null;

		if (null != request && null != request.getSubCompositeId())
			subCompositeId = request.getSubCompositeId();

		this.defaultToDate = dateFormat.format(toDate);
		this.defaultFromDate = dateFormat.format(fromDate);

		List<BreadCrumbTreeHierarchy> result = new ArrayList<BreadCrumbTreeHierarchy>();
		List<UtilizationGDRDrugClass> lstGDRObj = new ArrayList<UtilizationGDRDrugClass>();

		cn = Database.getConnection(Constants.RPT_DATASOURCE);
		String sql;

		if (null != request.getParentId() && request.getParentId().equals("0") && null != request.getMeasureName() && request.getMeasureName().equalsIgnoreCase(Constants.GDR_AGG))
		{
			//Aggregate(sub-composite) level BreadCrumbs
			sql = buildAggregateSql(request);

		}
		else {
			//Measure level BreadCrumbs
			sql = buildMeasureSql(request);
		}

		try {


			buildPreparedStatement(request, sql);
			executeQuery(logger, sql);
			if (null != request.getParentId() && request.getParentId().equals("0") && null != request.getMeasureName()
				&& request.getMeasureName().equalsIgnoreCase(Constants.GDR_AGG))
			{
				lstGDRObj = convertSelectedRowsToObjects(rs);
				result = getGDRTreeStructure(lstGDRObj, subCompositeId, Constants.GDR);
			}
			else if (null != request.getMeasureName() && request.getMeasureName().equalsIgnoreCase(Constants.GDR))
			{
				result = getGDRMeasureTreeStructure(rs, request.getSubCompositeName(), request.getParentId(), request.getScoreId(), Constants.GDR);
			}
			else if (null != request.getMeasureName()
				&& (request.getMeasureName().equalsIgnoreCase(Constants.ASA) || request.getMeasureName().equalsIgnoreCase(Constants.LIER) || request.getMeasureName()
					.equalsIgnoreCase(Constants.RAR)))
			{
				result = getTreeStructure(rs, request.getSubCompositeId(), request.getMeasureName(), request.getScoreId(), request.getSubCompositeName());
			}


		}
		catch (Exception e) {
			throw new Exception("Exception during getBreadCrumbsData (" + request.toString() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}
	
	public List<BreadCrumbTreeHierarchy> getBrandFormularyBreadCrumbsData(GetBreadcrumbRequest request) throws Exception {
		
		List<BreadCrumbTreeHierarchy> nodeList = new ArrayList<BreadCrumbTreeHierarchy>();
		BreadCrumbTreeHierarchy node = new BreadCrumbTreeHierarchy();
		
		node.setId(request.getScoreId());
		node.setText(request.getSubCompositeName());
		
		UtilizationBrandFormularyFilterServiceImpl service = new UtilizationBrandFormularyFilterServiceImpl();
		node.setChildren(service.getChildrenForBreadcrumb());
		
		nodeList.add(node);
		
		return nodeList;
	}



	protected String buildAggregateSql(GetBreadcrumbRequest request) {
		String countWhereClause = "";

		StringBuilder sql = new StringBuilder().append(
			"select distinct " + "CUDF.CNDTN_CTGRY_NM, " + "MD.MSR_ID, " + "MD.MSR_DSPLY_NM, " + "PCF.BRND_NM ");

		sql.append(" from CMPLNC_UM_DTL_FACT AS CUDF ");
		sql.append(
			"join MSTR_CNSMR_FACT AS MCF ON (CUDF.MSTR_CNSMR_DIM_KEY = MCF.MSTR_CNSMR_DIM_KEY AND CUDF.PROV_GRP_DIM_KEY = MCF.PROV_GRP_DIM_KEY AND CUDF.PGM_DIM_KEY = MCF.PGM_DIM_KEY AND MCF.ATRBN_STTS_CD = 'ACTIVE' ) ");
		sql.append("join PGM_DIM AS PD ON (CUDF.PGM_DIM_KEY = PD.PGM_DIM_KEY and PD.PGM_ID = ?) ");
		sql.append("join prov_org_dim pod on (CUDF.prov_org_dim_key = pod.prov_org_dim_key) ");
		sql.append(
			"join PROV_GRP_DIM AS PGD ON (CUDF.PROV_GRP_DIM_KEY = PGD.PROV_GRP_DIM_KEY and PGD.PROV_GRP_ID = ?) ");
		sql.append("join MSR_DIM AS MD ON (CUDF.MSR_DIM_KEY = MD.MSR_DIM_KEY) ");
		sql.append("join prov_grp_hrchy_dim pghd on (CUDF.prov_grp_dim_key = pghd.prov_grp_dim_key ");
		sql.append("and CUDF.prov_org_dim_key = pghd.prov_org_dim_key ");
		sql.append("and CUDF.ip_dim_key = pghd.ip_dim_key ");
		sql.append("and mcf.PROV_GRP_HRCHY_DIM_KEY = pghd.PROV_GRP_HRCHY_DIM_KEY) ");
		sql.append("JOIN CLM_PHRMCY_UM_XREF PX ON PX.CMPLNC_UM_DTL_FACT_KEY = CUDF.CMPLNC_UM_DTL_FACT_KEY ");
		sql.append(
			"JOIN PHRMCY_CLM_FACT PCF ON (PCF.PHRMCY_CLM_FACT_KEY = PX.PHRMCY_CLM_FACT_KEY and PCF.DSPNSD_BRND_GNRC_IND = 'B' ) ");

		sql.append(" where ");

		sql.append(" CUDF.ANLYSS_AS_OF_DT = ? ");

		/*
		 * if (StringUtil.isNotBlankOrFalse(request.getScoreId())) { sql.append(
		 * "and md.msr_id = ? "); }
		 */

		sql.append(" and cudf.sub_cmpst_nm = 'GDR' ");

		if (StringUtil.isNotBlankOrFalse(request.getStartDate())
			&& StringUtil.isNotBlankOrFalse(request.getEndDate())) {
			sql.append(" and CUDF.CLM_LINE_SRVC_STRT_DT between ? " + "and " + " ? ");
		}

		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
			sql.append("AND CUDF.MSRMNT_PRD_STRT_DT = ? "); // measurementPeriodStartDt
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			sql.append(" and pghd.ip_dim_key in (" // NF31 (no longer
													// pghd.prov_grp_hrchy_dim_key)
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") "); // provDimKeys
		}
		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			sql.append(" and pod.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys()) + ") ");
		}

		sql.append(" order by CUDF.CNDTN_CTGRY_NM,MD.MSR_DSPLY_NM,PCF.BRND_NM with ur ");

		String sqlString = String.format(sql.toString(), new Object[] {countWhereClause, countWhereClause});

		return sqlString;
	}

	protected String buildMeasureSql(GetBreadcrumbRequest request) {
		String countWhereClause = "";
		StringBuilder sql = new StringBuilder();

		if (null != request.getMeasureName() && (request.getMeasureName().equals(Constants.ASA) || request.getMeasureName().equals(Constants.LIER)
			|| request.getMeasureName().equals(Constants.RAR))) {
			sql.append("select distinct CNDTN_CTGRY_NM ");
			sql.append("from CMPLNC_UM_DTL_FACT AS CUDF ");
		}
		else if (null != request.getMeasureName() && request.getMeasureName().contains(Constants.GDR)) {
			sql.append("select distinct BRND_NM ");
			sql.append("from PHRMCY_CLM_FACT PCF ");
			sql.append("JOIN CLM_PHRMCY_UM_XREF AS CPUX ON (CPUX.PHRMCY_CLM_FACT_KEY = PCF.PHRMCY_CLM_FACT_KEY and PCF.DSPNSD_BRND_GNRC_IND = 'B' )");
			sql.append("join CMPLNC_UM_DTL_FACT AS CUDF ON (CUDF.CMPLNC_UM_DTL_FACT_KEY = CPUX.CMPLNC_UM_DTL_FACT_KEY AND CUDF.MSTR_CNSMR_DIM_KEY = CPUX.MSTR_CNSMR_DIM_KEY) ");
		}
		if (null != request.getMeasureName() && (request.getMeasureName().equals(Constants.ASA) || request.getMeasureName().equals(Constants.LIER)
			|| request.getMeasureName().equals(Constants.RAR))) {
			sql.append("JOIN CLM_VST_UM_XREF AS CVUX ON (CUDF.CMPLNC_UM_DTL_FACT_KEY = CVUX.CMPLNC_UM_DTL_FACT_KEY ")
				.append(" AND CUDF.MSTR_CNSMR_DIM_KEY = CVUX.MSTR_CNSMR_DIM_KEY) ");
		}
		sql.append("join MSTR_CNSMR_FACT AS MCF ON (CUDF.MSTR_CNSMR_DIM_KEY = MCF.MSTR_CNSMR_DIM_KEY AND CUDF.PROV_GRP_DIM_KEY = MCF.PROV_GRP_DIM_KEY AND CUDF.PGM_DIM_KEY = MCF.PGM_DIM_KEY AND MCF.ATRBN_STTS_CD = 'ACTIVE' ) ");
		sql.append("join PGM_DIM AS PD ON (CUDF.PGM_DIM_KEY = PD.PGM_DIM_KEY and PD.PGM_ID = ?) ");
		sql.append("join prov_org_dim pod on (CUDF.prov_org_dim_key = pod.prov_org_dim_key) ");
		sql.append("join PROV_GRP_DIM AS PGD ON (CUDF.PROV_GRP_DIM_KEY = PGD.PROV_GRP_DIM_KEY and PGD.PROV_GRP_ID = ? ) ");
		sql.append("join MSR_DIM AS MD ON (CUDF.MSR_DIM_KEY = MD.MSR_DIM_KEY) ");
		sql.append("join prov_grp_hrchy_dim pghd on (CUDF.prov_grp_dim_key = pghd.prov_grp_dim_key ");
		sql.append("and CUDF.prov_org_dim_key = pghd.prov_org_dim_key ");
		sql.append("and CUDF.ip_dim_key = pghd.ip_dim_key ");
		sql.append("and mcf.PROV_GRP_HRCHY_DIM_KEY = pghd.PROV_GRP_HRCHY_DIM_KEY) ");

		sql.append(" where ");

		sql.append(" CUDF.ANLYSS_AS_OF_DT = ? ");

		if (!request.getProgramLobTypeCd().trim().equalsIgnoreCase(Constants.ESN_COMMERCIAL) && StringUtil.isNotBlankOrFalse(request.getScoreId())) {
			sql.append("and md.msr_id = ? ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getStartDate()) && StringUtil.isNotBlankOrFalse(request.getEndDate())) {
			sql.append(" and CUDF.CLM_LINE_SRVC_STRT_DT between ? "
				+ "and "
				+ " ? ");
		}
		if (request.getMeasureName() != null && request.getMeasureName().equals(Constants.RAR)) {
			sql.append(" and cudf.msr_nmrtr_ind='Y' ");
		}
		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
			sql.append(" and cudf.msrmnt_prd_strt_dt = ? ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			sql.append(" and pghd.ip_dim_key in (" // NF31 (no longer pghd.prov_grp_hrchy_dim_key)
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys())
				+ ") "); // provDimKeys
		}
		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			sql.append(" and pod.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}

		sql
			.append(" order by 1 with ur ");

		String sqlString = String.format(sql.toString(), new Object[] {countWhereClause, countWhereClause});

		return sqlString;
	}


	protected void buildPreparedStatement(GetBreadcrumbRequest request, String sql) throws SQLException {
		int i = 0;
		prepareStatement(logger, sql);

		// same order of null checks as buildSql() to make sure markers are populated correctly

		if (!StringUtils.isBlank(request.getProgramId())) {
			ps.setString(++i, request.getProgramId());
		}

		if (!StringUtils.isBlank(request.getProvGrpIds())) {
			ps.setString(++i, request.getProvGrpIds());
		}

		if(!request.getProgramLobTypeCd().equalsIgnoreCase(Constants.ESN_COMMERCIAL)) {
			CommonQueries cq = new CommonQueries();
			//String aaod = cq.selectAAODOther(request.getProgramId(), request.getMeasurementPeriodStartDt());
			String aaod = cq.selectAAODOther(request.getProgramId(), request.getMeasurementPeriodStartDt(), request.getProvGrpIds()); //PCMSP-13914
	
			ps.setString(++i, aaod);
		}else{
			if (!StringUtils.isBlank(request.getAnalysisAsOfDt())) {
				ps.setString(++i, request.getAnalysisAsOfDt());
			}
		}

		if (!request.getProgramLobTypeCd().trim().equalsIgnoreCase(Constants.ESN_COMMERCIAL) &&  null != request.getMeasureName() && !request.getMeasureName().equals(Constants.GDR_AGG)) {
			if (StringUtil.isNotBlankOrFalse(request.getScoreId())) {
				ps.setString(++i, request.getScoreId());
			}
		}
		String fromDateParam = "(current_date - (day(current_date) - 1) days - 1 years)";
		String toDateParam = "(current_date)";

		if (StringUtil.isNotBlankOrFalse(request.getStartDate()) && StringUtil.isNotBlankOrFalse(request.getEndDate())) {
			if ((request.getStartDate().equalsIgnoreCase(this.defaultFromDate) && request.getEndDate().equalsIgnoreCase(this.defaultToDate))) {
				fromDateParam = this.defaultFromDate;
				toDateParam = this.defaultToDate;
			}
			else {
				fromDateParam = StringUtil.convertDate(request.getStartDate());
				toDateParam = StringUtil.convertDate(request.getEndDate());
			}

			ps.setString(++i, fromDateParam);
			ps.setString(++i, toDateParam);
		}

		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
			ps.setString(++i, request.getMeasurementPeriodStartDt());
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) { // populated if the Organization filter is applied
			String[] array = request.getProvDimKeys().split(",");
			String loggedProvDimKeys = "";
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
				loggedProvDimKeys += "," + StringUtil.parseProviderId(item);
			}
			StringUtils.replaceOnce(loggedProvDimKeys, ",", "");
		}
		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}
	}

	protected List<UtilizationGDRDrugClass> convertSelectedRowsToObjects(ResultSet rs) throws SQLException {
		List<UtilizationGDRDrugClass> list = new ArrayList<UtilizationGDRDrugClass>();

		while (rs.next()) {
			UtilizationGDRDrugClass item = new UtilizationGDRDrugClass();

			item.setCndtnCtgryNm(rs.getString("CNDTN_CTGRY_NM"));
			item.setMsrId((rs.getString("MSR_ID")));
			item.setMsrDsplyNm(rs.getString("MSR_DSPLY_NM"));
			item.setBrndNm(rs.getString("BRND_NM"));

			list.add(item);
		}

		return list;
	}


	protected List<BreadCrumbTreeHierarchy> getGDRMeasureTreeStructure(ResultSet rs, String measureName,
		String parentId, String scoreId, String subCompositeCode) throws SQLException {

		//		List<BreadCrumbTreeHierarchy> subCompositeList = new ArrayList<BreadCrumbTreeHierarchy>();
		//		BreadCrumbTreeHierarchy subCompositeHierarchy = new BreadCrumbTreeHierarchy();
		List<BreadCrumbTreeHierarchy> measureList = new ArrayList<BreadCrumbTreeHierarchy>();
		BreadCrumbTreeHierarchy measureHierarchy = new BreadCrumbTreeHierarchy();
		List<BreadCrumbTreeHierarchy> drugList = new ArrayList<BreadCrumbTreeHierarchy>();
		BreadCrumbTreeHierarchy drugHierarchy = new BreadCrumbTreeHierarchy();

		if (null != rs) {

			drugList = new ArrayList<BreadCrumbTreeHierarchy>();
			while (rs.next())
			{
				drugHierarchy = new BreadCrumbTreeHierarchy();
				drugHierarchy.setId(scoreId + rs.getString("BRND_NM").hashCode() + "");
				drugHierarchy.setText(rs.getString("BRND_NM"));
				drugList.add(drugHierarchy);
			}
		}
		measureHierarchy.setId(scoreId);
		measureHierarchy.setText(measureName);
		measureHierarchy.setChildren(drugList);
		measureList.add(measureHierarchy);

		return measureList;

		// Per UI's request, as of 2.0, don't include the sub-composite node for GDR Measure drill-down, since clicking on it does nothing, since the data doesn't exist

		//		subCompositeHierarchy.setId(parentId);
		//		subCompositeHierarchy.setText(getSubCompositeText(subCompositeCode));
		//		subCompositeHierarchy.setChildren(measureList);
		//		subCompositeList.add(subCompositeHierarchy);
		//
		//		return subCompositeList;

	}

	protected List<BreadCrumbTreeHierarchy> getGDRTreeStructure(List<UtilizationGDRDrugClass> gdrDrugClassList,
		String subCompositeId, String subCompositeCode) {

		List<BreadCrumbTreeHierarchy> subCompositeList = new ArrayList<BreadCrumbTreeHierarchy>();
		BreadCrumbTreeHierarchy subCompositeHierarchy;
		List<BreadCrumbTreeHierarchy> categoryList;
		BreadCrumbTreeHierarchy categoryHierarchy;
		List<BreadCrumbTreeHierarchy> measureList;
		BreadCrumbTreeHierarchy measureHierarchy;
		List<BreadCrumbTreeHierarchy> drugList;
		BreadCrumbTreeHierarchy drugHierarchy;
		String subCompositeName = null;
		String categoryName = null;
		String measureName = null;
		String drugName = null;
		Iterator<BreadCrumbTreeHierarchy> iterCategory;
		Iterator<BreadCrumbTreeHierarchy> iterSubComposite;
		Iterator<BreadCrumbTreeHierarchy> iterMeasure;

		if (null != gdrDrugClassList & !gdrDrugClassList.isEmpty()) {
			Collections.sort(gdrDrugClassList);
			// Go to Block if gdrDrugClassList has value
			for (UtilizationGDRDrugClass item : gdrDrugClassList) {
				if (null != subCompositeName) {

					if (null != categoryName && categoryName.equalsIgnoreCase(item.getCndtnCtgryNm().trim())) {
						if (null != measureName && measureName.equalsIgnoreCase(item.getMsrDsplyNm().trim())) {
							if (null != drugName && !drugName.equalsIgnoreCase(item.getBrndNm().trim())) {
								drugName = item.getBrndNm();
								drugHierarchy = new BreadCrumbTreeHierarchy();

								drugHierarchy.setId(item.getMsrId() + drugName.hashCode() + "");
								drugHierarchy.setText(item.getBrndNm());

								iterSubComposite = subCompositeList.iterator();
								while (iterSubComposite.hasNext()) {
									BreadCrumbTreeHierarchy objSubComposite = iterSubComposite.next();
									if ((objSubComposite.getText()).equals(subCompositeName)) {
										categoryList = (List<BreadCrumbTreeHierarchy>) objSubComposite.getChildren();
										iterCategory = categoryList.iterator();

										while (iterCategory.hasNext()) {
											BreadCrumbTreeHierarchy objCategory = iterCategory.next();
											if (objCategory.getText().equals(categoryName)) {

												measureList = (List<BreadCrumbTreeHierarchy>) objCategory.getChildren();

												iterMeasure = measureList.iterator();
												while (iterMeasure.hasNext()) {
													BreadCrumbTreeHierarchy objMeasure = iterMeasure.next();
													if (objMeasure.getText().equals(measureName)) {
														drugList = (List<BreadCrumbTreeHierarchy>) objMeasure
															.getChildren();
														drugList.add(drugHierarchy);
														measureList.remove(objMeasure);
														objMeasure.setChildren(drugList);
														measureList.add(objMeasure);
														break;
													}

												}

												categoryList.remove(objCategory);
												objCategory.setChildren(measureList);
												categoryList.add(objCategory);
												break;
											}

										}

										subCompositeList.remove(objSubComposite);
										objSubComposite.setChildren(categoryList);
										subCompositeList.add(objSubComposite);
										break;
									}
								}
							}

						}
						else {
							measureName = item.getMsrDsplyNm();
							drugName = item.getBrndNm();
							drugHierarchy = new BreadCrumbTreeHierarchy();
							measureHierarchy = new BreadCrumbTreeHierarchy();
							drugList = new ArrayList<BreadCrumbTreeHierarchy>();

							drugHierarchy.setId(item.getMsrId() + drugName.hashCode() + "");
							drugHierarchy.setText(drugName);
							drugList.add(drugHierarchy);

							measureHierarchy.setId(item.getMsrId());
							measureHierarchy.setText(measureName);
							measureHierarchy.setChildren(drugList);

							iterSubComposite = subCompositeList.iterator();
							while (iterSubComposite.hasNext()) {
								BreadCrumbTreeHierarchy objSubComposite = iterSubComposite.next();
								if ((objSubComposite.getText()).equals(subCompositeName)) {
									categoryList = (List<BreadCrumbTreeHierarchy>) objSubComposite.getChildren();
									iterCategory = categoryList.iterator();

									while (iterCategory.hasNext()) {
										BreadCrumbTreeHierarchy objCategory = iterCategory.next();
										if (objCategory.getText().equals(categoryName)) {
											measureList = (List<BreadCrumbTreeHierarchy>) objCategory.getChildren();
											measureList.add(measureHierarchy);
											categoryList.remove(objCategory);
											objCategory.setChildren(measureList);
											categoryList.add(objCategory);
											break;
										}

									}

									subCompositeList.remove(objSubComposite);
									objSubComposite.setChildren(categoryList);
									subCompositeList.add(objSubComposite);
									break;
								}
							}
						}
					}
					else {
						categoryName = item.getCndtnCtgryNm();
						measureName = item.getMsrDsplyNm();
						drugName = item.getBrndNm();

						drugHierarchy = new BreadCrumbTreeHierarchy();
						measureHierarchy = new BreadCrumbTreeHierarchy();
						categoryHierarchy = new BreadCrumbTreeHierarchy();

						drugList = new ArrayList<BreadCrumbTreeHierarchy>();
						measureList = new ArrayList<BreadCrumbTreeHierarchy>();
						categoryList = new ArrayList<BreadCrumbTreeHierarchy>();

						drugHierarchy.setId(item.getMsrId() + drugName.hashCode() + "");
						drugHierarchy.setText(drugName);
						drugList.add(drugHierarchy);

						measureHierarchy.setId(item.getMsrId());
						measureHierarchy.setText(measureName);
						measureHierarchy.setChildren(drugList);
						measureList.add(measureHierarchy);

						categoryHierarchy.setId("DC" + categoryName.hashCode());
						categoryHierarchy.setText(categoryName);
						categoryHierarchy.setChildren(measureList);

						iterSubComposite = subCompositeList.iterator();

						while (iterSubComposite.hasNext()) {
							BreadCrumbTreeHierarchy objSubComposite = iterSubComposite.next();
							if (objSubComposite.getText().equals(subCompositeName)) {
								categoryList = (List<BreadCrumbTreeHierarchy>) objSubComposite.getChildren();
								categoryList.add(categoryHierarchy);
								subCompositeList.remove(objSubComposite);
								objSubComposite.setChildren(categoryList);
								subCompositeList.add(objSubComposite);
								break;
							}

						}

					}
				}
				else {
					subCompositeName = getSubCompositeText(subCompositeCode);
					categoryName = item.getCndtnCtgryNm();
					measureName = item.getMsrDsplyNm();
					drugName = item.getBrndNm();

					drugHierarchy = new BreadCrumbTreeHierarchy();
					measureHierarchy = new BreadCrumbTreeHierarchy();
					categoryHierarchy = new BreadCrumbTreeHierarchy();
					subCompositeHierarchy = new BreadCrumbTreeHierarchy();

					drugList = new ArrayList<BreadCrumbTreeHierarchy>();
					measureList = new ArrayList<BreadCrumbTreeHierarchy>();
					categoryList = new ArrayList<BreadCrumbTreeHierarchy>();
					subCompositeList = new ArrayList<BreadCrumbTreeHierarchy>();

					drugHierarchy.setId(item.getMsrId() + drugName.hashCode() + "");
					drugHierarchy.setText(drugName);
					drugList.add(drugHierarchy);

					measureHierarchy.setId(item.getMsrId());
					measureHierarchy.setText(measureName);
					measureHierarchy.setChildren(drugList);
					measureList.add(measureHierarchy);

					categoryHierarchy.setId("DC" + categoryName.hashCode());
					categoryHierarchy.setText(categoryName);
					categoryHierarchy.setChildren(measureList);
					categoryList.add(categoryHierarchy);

					subCompositeHierarchy.setId(subCompositeId);
					subCompositeHierarchy.setText(subCompositeName);
					subCompositeHierarchy.setChildren(categoryList);
					subCompositeList.add(subCompositeHierarchy);
				}
			}
		}
		else {
			subCompositeHierarchy = new BreadCrumbTreeHierarchy();
			subCompositeHierarchy.setId(subCompositeId);
			subCompositeHierarchy.setText(getSubCompositeText(subCompositeCode));
			subCompositeList.add(subCompositeHierarchy);
		}
		return subCompositeList;
	}



	private List<BreadCrumbTreeHierarchy> getTreeStructure(ResultSet rs, String subCompositeId, String subCompositeCode, String categoryId, String categoryName)
		throws SQLException
	{
		List<BreadCrumbTreeHierarchy> subCompositeList = new ArrayList<BreadCrumbTreeHierarchy>();
		BreadCrumbTreeHierarchy subCompositeHierarchy = new BreadCrumbTreeHierarchy();
		List<BreadCrumbTreeHierarchy> categoryList = new ArrayList<BreadCrumbTreeHierarchy>();
		BreadCrumbTreeHierarchy categoryHierarchy = new BreadCrumbTreeHierarchy();
		List<BreadCrumbTreeHierarchy> measureList = new ArrayList<BreadCrumbTreeHierarchy>();
		BreadCrumbTreeHierarchy measureHierarchy = new BreadCrumbTreeHierarchy();


		if (null != rs) {
			measureList = new ArrayList<BreadCrumbTreeHierarchy>();
			while (rs.next()) {
				measureHierarchy = new BreadCrumbTreeHierarchy();

				measureHierarchy.setId(categoryId + rs.getString("CNDTN_CTGRY_NM").hashCode() + "");
				measureHierarchy.setText(rs.getString("CNDTN_CTGRY_NM"));
				measureList.add(measureHierarchy);
			}
		}
		categoryHierarchy.setId(categoryId);
		categoryHierarchy.setText(categoryName);
		categoryHierarchy.setChildren(measureList);
		categoryList.add(categoryHierarchy);

		// Per UI's request, as of 2.0, don't include the sub-composite node for ASA, LIER, or RAR Measure drill-down, since clicking on it does nothing, since the data doesn't exist
		if (!subCompositeCode.contains(Constants.AGGREGATE)) {
			return categoryList;

		}

		subCompositeHierarchy.setId(subCompositeId);
		subCompositeHierarchy.setText(getSubCompositeText(subCompositeCode));
		subCompositeHierarchy.setChildren(categoryList);
		subCompositeList.add(subCompositeHierarchy);
		return subCompositeList;
	}


	private String getSubCompositeText(String subCompositeCode) {
		if (null != subCompositeCode && subCompositeCode.equals(Constants.GDR))
			return "Generic Dispensing Rate";
		else if (null != subCompositeCode && subCompositeCode.equals(Constants.ASA))
			return "Ambulatory Sensitive Admissions";
		else if (null != subCompositeCode && subCompositeCode.equals(Constants.LIER))
			return "Potentially Avoidable ERe";
		else if (null != subCompositeCode && subCompositeCode.equals(Constants.RAR))
			return "Readmission Rates";
		else
			return "";

	}

}
