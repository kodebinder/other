package com.wellpoint.pc2dash.data.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.quality.GetQualityMeasuresRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.quality.QualityMeasure;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;

public class MedicaidQualityMeasures extends Quality {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(QualityMeasures.class);

	/**
	 * This method will only be called for Quality Patient/Provider export.
	 * We need to use the list of selected measures from the UI, rather than the measures
	 * returned by GetQualityPatients or GetQualityProviders.
	 * [WLPRD01131580]
	 * 
	 * @param ids
	 * @return measure names as a comma-separated list
	 * @throws Exception
	 */
	public String getQualityMeasureNamesForExportHeader(String ids) {
		String result = "";

		if (StringUtil.isNotBlankOrFalse(ids)) { // Move the check up here - no sense in building the query if there are no ids

			try {
				String sql = "select distinct msr_dsply_nm from msr_dim where msr_id in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(ids)
					+ ") ";
				//			logger.debug("getMedicadQualityMeasureNamesForExportHeader SQL: " + sql);

				cn = Database.getConnection(Constants.RPT_DATASOURCE);
				prepareStatement(logger, sql);

				int i = 0;

				String[] array = ids.split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
				//logger.debug("qualityMeasureKey: " + ids);

				executeQuery(logger, sql);

				while (rs.next()) {
					result += ", " + getString(rs, "msr_dsply_nm");
				}
				result = result.substring(2); // remove leading comma and space

			}
			catch (Exception e) {
				logger.info("Exception during getMedicaidQualityMeasureNamesForExportHeader (" + ids + "). Returning empty string.", e);
				return "";
			}
			finally {

				close();
			}

		}

		return result;
	}

	public List<QualityMeasure> getImprovementQualityMeasures(GetQualityMeasuresRequest request) throws Exception {
		List<QualityMeasure> result = new ArrayList<QualityMeasure>();

		String sql = buildSql(request);

		try {
			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			buildPreparedStatement(request, sql);
			executeQuery(logger, sql);
			result = convertSelectedRowsToObjects(rs);

		}
		catch (Exception e) {
			throw new Exception("Exception during getQualityMeasures (" + request.toString() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}

	protected String buildSql(GetQualityMeasuresRequest request) {
		StringBuilder sql = new StringBuilder()
			.append("select distinct md.msr_dsply_nm ")
			.append(", md.msr_id ")
			.append(", smhd.sub_cmpst_defn_id ")
			.append(", smhd.sub_cmpst_nm ")
			.append(", smhd.cmpst_defn_id ")
			.append(", smhd.cmpst_nm ");

		// add to from and where clauses as necessary (adding some by default, since they're very likely to be required)

		// WLPRD01131663: join to different tables, and not to cmplnc_fact
		StringBuilder from = new StringBuilder("from scrcrd_pgm_msr_hrchy_fact spmhf ");
		from.append("join scrcrd_msr_hrchy_dim smhd on (spmhf.scrcrd_msr_hrchy_dim_key = smhd.scrcrd_msr_hrchy_dim_key) ");
		from.append("join msr_dim md on (smhd.msr_dim_key = md.msr_dim_key) ");
		//from.append("join prov_grp_pnl_assn_fact pgpaf on (spmhf.pgm_dim_key = pgpaf.pgm_dim_key) ");
		//from.append("join prov_grp_pgm_lob_fact pgpaf on (spmhf.pgm_dim_key = pgpaf.pgm_dim_key) ");

		StringBuilder where = new StringBuilder("where ");
		if (!StringUtils.isBlank(request.getProgramId())) {
			from.append("join pgm_dim pd on (spmhf.pgm_dim_key = pd.pgm_dim_key) ");

			where.append("and pd.pgm_id = ? "); // programId
		}

		if (!StringUtils.isBlank(request.getCompositeId())) {

			where.append("and smhd.cmpst_defn_id = ? "); // CompositeId
		}

		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {

			where.append("and spmhf.msrmnt_prd_strt_dt = ? "); // measurementPeriodStartDt
		}

		if (request.getCompositeType().equalsIgnoreCase(Constants.IMPCOMPOSITETYPE)) {

			if (!StringUtils.isBlank(request.getProvGrpIds())) {
				from.append("JOIN IMPRV_PROV_GRP_SMRY_FACT AS IMP ON pd.PGM_DIM_KEY = IMP.PGM_DIM_KEY  AND spmhf.MSRMNT_PRD_STRT_DT = IMP.MSRMNT_PRD_STRT_DT AND md.MSR_DIM_KEY = IMP.MSR_DIM_KEY ");
				from.append(" join prov_grp_dim pgd on (imp.prov_grp_dim_key = pgd.prov_grp_dim_key) ");

				if (request.getProgramLobTypeCd() != null && request.getProgramLobTypeCd().equalsIgnoreCase(Constants.MEDICAID))
				{
					where.append("and  IMP.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT > 0 ");
				}

				//	where.append("AND IMP.MNTH_ID = (SELECT MAX(IMPRV_PROV_GRP_SMRY_FACT.MNTH_ID) FROM IMPRV_PROV_GRP_SMRY_FACT where ANLYSS_AS_OF_DT = ? )");
				where.append(" AND  IMP.MNTH_ID = (select  MAX(ipgsf.MNTH_ID) from  IMPRV_PROV_GRP_SMRY_FACT ipgsf inner join PGM_DIM PD on pd.pgm_dim_key = ipgsf.pgm_dim_key ");
				where.append(" where  ipgsf.ANLYSS_AS_OF_DT = ?  and PD.PGM_ID = ?  and ipgsf.msrmnt_prd_strt_dt = ? )  ");
				where.append("and pgd.prov_grp_id = ? ");
			}
		}

		//where.append("and pgpaf.prov_grp_pgm_lob_trmntn_dt > sysdate "); // WLPRD01131663

		where = StringUtil.removeFirstOccurenceWithinString(where, "and");

		sql.append(from).append(where);

		sql = StringUtil.appendWithUr(sql);

		String sqlString = sql.toString();

		//		logger.debug("getMedicaidQualityMeasures SQL: " + sqlString);

		return sqlString;
	}

	protected void buildPreparedStatement(GetQualityMeasuresRequest request, String sql) throws SQLException {
		int i = 0;
		prepareStatement(logger, sql);

		// same order of null checks as buildSql() to make sure markers are populated correctly
		if (!StringUtils.isBlank(request.getProgramId())) {
			ps.setString(++i, request.getProgramId());
		}

		if (!StringUtils.isBlank(request.getCompositeId())) {
			ps.setString(++i, request.getCompositeId());
			//logger.debug("compositeId: " + request.getCompositeId());
		}

		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
			ps.setString(++i, request.getMeasurementPeriodStartDt());
		}

		if (request.getCompositeType().equalsIgnoreCase(Constants.IMPCOMPOSITETYPE)) {

			CommonQueries cq = new CommonQueries();
			String aaod = cq.selectAAODNImprovement(request.getProgramId(), request.getMeasurementPeriodStartDt());
			ps.setString(++i, aaod);

			if (!StringUtils.isBlank(request.getProgramId())) {
				ps.setString(++i, request.getProgramId());
			}

			if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
				ps.setString(++i, request.getMeasurementPeriodStartDt());
			}

			if (!StringUtils.isBlank(request.getProvGrpIds())) {
				ps.setString(++i, request.getProvGrpIds());
			}
		}
	}

	/**
	 * Populate a List of QualityMeasure objects. Each row's sub-composite id/name and composite id/name
	 * will be the same, and will be used to build a tree (a collection of collections) to be passed
	 * to the UI.
	 * 
	 * @param rs
	 * @return List<QualityMeasure>
	 * @throws SQLException
	 */
	protected List<QualityMeasure> convertSelectedRowsToObjects(ResultSet rs) throws SQLException {
		// Prepare to store the sub-composite and composite ids/names
		String subCompositeId = "";
		String subCompositeName = "";
		String compositeId = "";
		String compositeName = "";

		// Prepare to store the various QualityMeasure items we'll be populating
		QualityMeasure item = null;

		// Build the leaf nodes (3rd level)
		List<QualityMeasure> measures = new ArrayList<QualityMeasure>();
		while (rs.next()) {
			item = new QualityMeasure();

			item.setId(rs.getString("msr_id"));
			item.setText(rs.getString("msr_dsply_nm"));
			item.setLeaf(true);
			//2.0 - Hardcoded to false till more info.
			item.setChecked(false);
			item.setChildren(new ArrayList<QualityMeasure>());

			if (StringUtils.isBlank(subCompositeId)) { // Don't bother overwriting the values after the first time through - they'll be the same
				subCompositeId = rs.getString("sub_cmpst_defn_id");
				subCompositeName = rs.getString("sub_cmpst_nm");
				compositeId = rs.getString("cmpst_defn_id");
				compositeName = rs.getString("cmpst_nm");
			}

			measures.add(item);
		}

		// Build the sub-composite node (2nd level)
		List<QualityMeasure> subComposite = new ArrayList<QualityMeasure>();
		item = new QualityMeasure();

		item.setId(subCompositeId);
		item.setText(subCompositeName);
		item.setLeaf(false);
		//2.0 - Hardcoded to false till more info.
		item.setChecked(false);
		item.setChildren(measures);

		subComposite.add(item);

		// Build the composite node (1st level)
		List<QualityMeasure> composite = new ArrayList<QualityMeasure>();
		item = new QualityMeasure();

		item.setId(compositeId);
		item.setText(compositeName);
		item.setLeaf(false);
		//2.0 - Hardcoded to false till more info.
		item.setChecked(false);
		item.setChildren(subComposite);

		composite.add(item);

		return subComposite;
	}

}
