package com.wellpoint.pc2dash.action.pharmacy;

import com.wellpoint.pc2dash.data.dto.PharmacyReportRequest;

public class GetDrugClassFilterRequest extends PharmacyReportRequest {

}
