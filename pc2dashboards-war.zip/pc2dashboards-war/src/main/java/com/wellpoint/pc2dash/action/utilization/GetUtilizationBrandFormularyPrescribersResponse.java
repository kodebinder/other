package com.wellpoint.pc2dash.action.utilization;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetUtilizationBrandFormularyPrescribersResponse extends ActionResponse{

}
