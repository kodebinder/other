package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.action.tooltip.GetPatientDetailRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.patient.HccRiskScoreInds;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;


public class HccRiskScoresFacts extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(HccRiskScoresFacts.class);

	public boolean read(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void insert(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void update(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void delete(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	@Deprecated
	// Will be removed after Commercial and Medicare HCC Gap user stories are implemented in 1.9.2
	public Collection<HccRiskScoreInds> getHccRiskScores(GetPatientDetailRequest request) throws Exception {

		Collection<HccRiskScoreInds> result = new ArrayList<HccRiskScoreInds>();

		StringBuilder sql = new StringBuilder()
			.append("select ")
			.append("mcd.orgnl_enttlmnt_rsn_cd, ")
			.append("mcd.esrd_ind_cd ")
			.append("from ")
			.append("	mstr_cnsmr_dim mcd ")
			.append("join mstr_cnsmr_fact mcf on (mcd.mstr_cnsmr_dim_key = mcf.mstr_cnsmr_dim_key) ")
			.append("	join poit_user_scrty_acs pusa on ( ")
			.append("		mcf.prov_grp_id = pusa.prov_grp_id ")
			.append("		and case ")
			.append("				when pusa.prov_org_tax_id = '0' then mcf.prov_org_tax_id ")
			.append("				else pusa.prov_org_tax_id ")
			.append("			end = mcf.prov_org_tax_id ")
			.append("	) ")
			.append("where ")
			.append("	pusa.sesn_id = ? ")
			.append("	and pusa.enttlmnt_hash_key = ? ")
			.append("	and mcf.mstr_cnsmr_dim_key = ? ")
			.append("with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());
			ps.setString(1, request.getSessionId());
			ps.setString(2, request.getEntitlementId());
			ps.setString(3, request.getMemberKey());


			executeQuery(logger, sql.toString());


			while (rs.next()) {

				if (rs.getString("esrd_ind_cd") != null && rs.getString("esrd_ind_cd").trim().equals("Y"))
				{
					HccRiskScoreInds r = new HccRiskScoreInds();
					r.setRiskScoreIndicator("End Stage Renal Disease");
					result.add(r);
				}

				if (rs.getString("orgnl_enttlmnt_rsn_cd") != null && rs.getString("orgnl_enttlmnt_rsn_cd").trim().equals("1"))
				{
					HccRiskScoreInds r = new HccRiskScoreInds();
					r.setRiskScoreIndicator("Disabled Member");
					result.add(r);

				}
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get HccRiskScoresInds (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}
}
