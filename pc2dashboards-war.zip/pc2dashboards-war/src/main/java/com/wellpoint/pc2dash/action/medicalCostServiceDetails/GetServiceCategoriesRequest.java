package com.wellpoint.pc2dash.action.medicalCostServiceDetails;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.wellpoint.pc2dash.data.dto.PCMSRequest;

public class GetServiceCategoriesRequest extends PCMSRequest {

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
