package com.wellpoint.pc2dash.action.inpatientAdmissions;

import com.wellpoint.pc2dash.action.base.ActionResponse;

/**
 * @author AD90349
 *
 */
public class GetInpatientAdmissionPatientsResponse extends ActionResponse {

}
