package com.wellpoint.pc2dash.action.utilization;

import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;

public class GetPAERMeasuresRequest extends PerformanceManagementRequest {

}
