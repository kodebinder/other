package com.wellpoint.pc2dash.action.medicalCostPerformance;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.medicalCostTarget.GetMedicalCostTargetResponse;
import com.wellpoint.pc2dash.dao.McpFact;
import com.wellpoint.pc2dash.dto.performance.MedicalCostReport;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.performance.McpExport;
import com.wellpoint.pc2dash.service.medicalCost.MedicalCostPerformanceRetroServiceImpl;
import com.wellpoint.pc2dash.service.medicalCost.MedicalCostPerformanceServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;


public class GetMedicalCostPerformanceAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetMedicalCostPerformanceRequest request = (GetMedicalCostPerformanceRequest) actionRequest;
		GetMedicalCostTargetResponse response = new GetMedicalCostTargetResponse();
		ErrorProperties err = ErrorProperties.getInstance();

		MedicalCostPerformanceServiceImpl service = new MedicalCostPerformanceServiceImpl();
		MedicalCostPerformanceRetroServiceImpl retroService = new MedicalCostPerformanceRetroServiceImpl();
		List<McpFact> resultList = new ArrayList<McpFact>();
		List<String> grps = new ArrayList<String>();
		int totalRecords = 0;

		try {

			request.setShowMI(true);

			// Kill switch check on Provider groups
			if (StringUtil.isNotBlankOrFalse(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			// Financial access check on provider groups
			if (null != grps && grps.size() > 0) {
				grps = filterProvGrpsByFinancialInd(request, grps);
				//request.setProvGrpIds(StringUtils.join(grps, ','));
			}

			request.setProvGrpIds(StringUtils.join(grps, ','));

			if (null == request.getDest() || request.getDest().equalsIgnoreCase("json")) {

				ArrayList<MedicalCostReport> beanList = new ArrayList<MedicalCostReport>();
				if (StringUtil.isNotBlankOrFalse(request.getProviderGroupDimKey())) {

					if (!CollectionUtils.isEmpty(grps)) {
						if (request.getReportType() != null && request.getReportType().contains(Constants.MCPR)) {
							Map<String, Map<String, String>> resultMap = retroService.getData(request);

							List<Map<String, String>> retroResultMap = new ArrayList<Map<String, String>>();
							for (String key : resultMap.keySet())
								retroResultMap.add(resultMap.get(key));
							response.setData(retroResultMap);
							response.setTotal(retroResultMap.size());
							if (null == retroResultMap || (null != retroResultMap && retroResultMap.isEmpty())) {
								response.setMessage(err.getProperty("successNoData"));
							}
							else {
								response.setMessage(err.getProperty("successful"));
							}
						}
						else {
							resultList = service.getData(request);
							beanList = (ArrayList<MedicalCostReport>) service.getBeanList(resultList);
							totalRecords = service.getTotalRecords();

							response.setData(beanList);
							response.setTotal(totalRecords);

							if (null == resultList || (null != resultList && resultList.isEmpty())) {
								response.setMessage(err.getProperty("successNoData"));
							}
							else {
								response.setMessage(err.getProperty("successful"));
							}
						}
					}
					else {
						response.setData(resultList);
						response.setTotal(totalRecords);
						response.setMessage(err.getProperty("successful"));
					}

					/*if (resultList == null || (null!=resultList && resultList.isEmpty() )) {
					response.setMessage(err.getProperty("successNoData"));
					}
					else {
					response.setData(beanList);
					response.setTotal(totalRecords);
					response.setMessage(err.getProperty("successful"));
					}*/
				}
			}

			if (StringUtil.isExportDest(request.getDest())) {

				McpExport exp = new McpExport(request);
				ExportProcessor.getInstance().submit(exp);
			}

			response.setSuccess(true);

		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

		return response;
	}
}
