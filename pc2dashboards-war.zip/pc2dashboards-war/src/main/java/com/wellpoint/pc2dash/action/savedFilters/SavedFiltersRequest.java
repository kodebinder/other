package com.wellpoint.pc2dash.action.savedFilters;

import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.wellpoint.pc2dash.data.dto.PCMSRequest;
import com.wellpoint.pc2dash.dto.savedFilters.Filter;

public class SavedFiltersRequest extends PCMSRequest {

	private List<Filter> filters;


	public List<Filter> getFilters() {
		return filters;
	}


	public void setFilters(List<Filter> filters) {
		this.filters = filters;
	}


	/**
	 * @return The String representation of this class as constructed via
	 *         reflection by Apache Commons ToStringBuilder.
	 */
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
