package com.wellpoint.pc2dash.action.costOpportunity;

import java.util.List;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.dto.costOpportunity.LabUnitCountPopupBean;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.costOpportunity.CostOpportunityLabUnitCountPopUpExport;
import com.wellpoint.pc2dash.service.costOpportunity.LabUnitCountPopupServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetLabUnitCountPopupAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		List<LabUnitCountPopupBean> resultList = null;

		GetLabUnitCountPopupRequest request = (GetLabUnitCountPopupRequest) actionRequest;
		GetLabUnitCountPopupResponse response = new GetLabUnitCountPopupResponse();
		ErrorProperties err = ErrorProperties.getInstance();
		LabUnitCountPopupServiceImpl service = new LabUnitCountPopupServiceImpl();

		request.setProvGrpIdsWithoutClinicalCheck(request.getProvGrpIds());

		try {
			removeLobPgmPrefixes(request);			

            CommonQueries cq = new CommonQueries();
			MetaData metaData = new MetaData();
			metaData.setReportingPeriod(cq.getReportingPeriodForCostOpportunity(Constants.LABORATORY_SITE_OF_SERVICE));
			metaData.setReportDate(cq.getReportDateForCostOpportunity(Constants.LABORATORY_SITE_OF_SERVICE));

			if (StringUtil.isExportDest(request.getDest())) {
            	request.setReportingPeriod(metaData.getReportingPeriod());
            	request.setReportDate(metaData.getReportDate());
				CostOpportunityLabUnitCountPopUpExport ex = new CostOpportunityLabUnitCountPopUpExport(request);
				ExportProcessor.getInstance().submit(ex);
			}
			else {

				resultList = service.getData(request, Constants.BOOL_FALSE);

				if (null == resultList || resultList.isEmpty()) {
					response.setMessage(err.getProperty("successNoData"));
				}
				else {
					response.setMessage(err.getProperty("successful"));
					response.setData(resultList);
					response.setTotal(service.getNoOfRecords());
				}
			}

			response.setSuccess(true);
			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

	}

}
