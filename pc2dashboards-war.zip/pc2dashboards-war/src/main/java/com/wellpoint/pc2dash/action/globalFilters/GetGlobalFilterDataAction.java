package com.wellpoint.pc2dash.action.globalFilters;

import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.tinNpi.UserAcsIndicators;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.service.globalFilters.GlobalFilterDataFetchService;
import com.wellpoint.pc2dash.util.ErrorProperties;

public class GetGlobalFilterDataAction extends Action {

	ActionResponse response = new GetGlobalFilterDataResponse();

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		ErrorProperties err = ErrorProperties.getInstance();
		GetGlobalFilterDataRequest request = (GetGlobalFilterDataRequest) actionRequest;

		List<UserAcsIndicators> userAcsInfo = request.getUserAcsInfoJson();
		List<String> filteredProvGrpList = new ArrayList<String>();

		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < userAcsInfo.size(); i++) {
			if (i != userAcsInfo.size() - 1) {
				sb.append(userAcsInfo.get(i).getProvGrpId()).append(',');
			}
			else {
				sb.append(userAcsInfo.get(i).getProvGrpId());
			}
		}
		request.setProvGrpIds(sb.toString());
		filteredProvGrpList = filterProvGrpsByKillSwitch(request);
		for (int i = 0; i < userAcsInfo.size(); i++) {
			if (!filteredProvGrpList.contains(userAcsInfo.get(i).getProvGrpId())) // added ! to accommodate remove instead of adding to clone
			{
				userAcsInfo.remove(i);
			}
		}
		if (!userAcsInfo.isEmpty() && userAcsInfo.size() > 0) {
			GlobalFilterDataFetchService service = new GlobalFilterDataFetchService();
			try {
				List<?> resultList = service.getDataForGlobalFilter(userAcsInfo);
				response.setData(resultList);
				if (resultList.isEmpty()) {
					response.setMessage(err.getProperty("successNoData"));
				}
				else {
					response.setMessage(err.getProperty("successful"));
				}
				response.setSuccess(true);

			}
			catch (Exception pe) {
				Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
				return pce.checkException(pe, response);
			}
		}
		return response;
	}

}
