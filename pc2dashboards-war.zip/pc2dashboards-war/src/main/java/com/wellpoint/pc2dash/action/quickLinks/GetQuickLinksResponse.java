package com.wellpoint.pc2dash.action.quickLinks;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetQuickLinksResponse extends ActionResponse {

}
