package com.wellpoint.pc2dash.data.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.wellpoint.pc2dash.action.drilldown.GetDrillDownRequest;
import com.wellpoint.pc2dash.action.utilization.GetUtilizationProvidersRequest;
import com.wellpoint.pc2dash.dto.careOpportunities.Provider;
import com.wellpoint.pc2dash.dto.patient.EligibleMeasures;
import com.wellpoint.pc2dash.dto.quality.QualityProvider;
import com.wellpoint.pc2dash.dto.utilization.BrandFormularyDetails;
import com.wellpoint.pc2dash.dto.utilization.UtilizationProvider;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class GeneralProviders extends Quality {

	protected String buildSharedSelectGroupByColumns(GetDrillDownRequest request) {

		/**
		 * AD12140 - R1.8
		 * Changing the Table from prov_grp_hrchy_dim to ip_dim to pick NPI_TYPE_CD
		 */

		StringBuilder select = new StringBuilder();
		if ((null != request.getMeasureName() && request.getMeasureName().equals(Constants.LIER)) ||
			(null != request.getMeasureName() && request.getMeasureName().equals(Constants.ASA)) ||
			(null != request.getMeasureName() && request.getMeasureName().equals(Constants.RAR)) ||
			(null != request.getMeasureName() && request.getMeasureName().contains(Constants.GDR))) {
			select.append(" cudf.ip_dim_key ");
		}
		else {
			select.append(" cisf.ip_dim_key ");
		}
		select.append(", ip.ip_npi ")
			.append(", pod.prov_org_dim_key ")
			.append(", upper(pod.prov_org_full_nm) as prov_org_full_nm ")
			.append(", pghd.prov_grp_hrchy_dim_key ")
			.append(", pod.prov_org_tax_id as org_tin ")
			.append(", pghd.prov_grp_dim_key ")
			.append(", ip.npi_type_cd");

		/*if(null != request.getMeasureName() && request.getMeasureName().equals(Constants.GDR)){
			select.append(", cisf.rt_pct ");
		}*/
		if (isExport() && !(null != request.getMeasureName() && request.getMeasureName().contains(Constants.GDR))
			&& !(null != request.getProgramLobTypeCd() && request.getProgramLobTypeCd().trim().equalsIgnoreCase(Constants.ESN_COMMERCIAL)
			&& null != request.getMeasureName() && request.getMeasureName().contains(Constants.LIER))) {
			select.append(", md.msr_dsply_nm ");
		}

		return select.toString();
	}

	protected List<Provider> convertSelectedRowsToObjects(ResultSet rs, GetDrillDownRequest request) throws SQLException {
		List<Provider> list = new ArrayList<Provider>();

		while (rs.next()) {
			Provider item;
			if (request instanceof GetUtilizationProvidersRequest) {
				item = new UtilizationProvider();
				if (null != request.getMeasureName() && request.getMeasureName().contains(Constants.FRMLY)) {
					item.setTotalNonFormularyBrandRxDispensed(rs.getInt("total_nonf_disp_count"));
					float bfRate = rs.getFloat("bf_rate");
					item.setTotalBFR(Math.round(bfRate) + "%");
					//9482 export begins
					if (isExport()) {
						BrandFormularyDetails bfrDetailsForExport = new BrandFormularyDetails();
							bfrDetailsForExport.setDrugClass(rs.getString("drug_cls_nm"));
						bfrDetailsForExport.setNfClaimCount(rs.getInt("CLM_CNT"));
						bfrDetailsForExport.setFormularyBrandDrugsCnt(rs.getInt("formularyBrndDrugsCnt"));/*PCMSP-18709*/
						item.setBfrDetailsForExport(bfrDetailsForExport);
					}
					//9482 export ends
				}
				else {
					item.setTotalCount(rs.getInt("MEM_COUNT"));
					if (null != request.getMeasureName() && request.getMeasureName().equals(Constants.LIER)) {
						/*
						 * Hard coding right now - as per discussion; data is not available as of now. 
						 * For the iteration purposes, hard coding the JSON parameter to 100 to reflect on the UI
						 */
						/*
						 * Removing the hard coding - 12/17/2015 
						 * BR1.1.25 - The cost must be rounded to the nearest whole dollar (no decimals)
						 */
						String visitCost;
						Integer vstCost;
						if (null != rs.getBigDecimal("VST_COST") && item.getTotalCount() >= 5) {
							vstCost = Integer.valueOf(rs.getBigDecimal("VST_COST").setScale(0, BigDecimal.ROUND_HALF_UP).intValue());
							visitCost = vstCost.toString();
							if (isExport())
								item.setCostOfVisits(StringUtil.convertStringToCurrency(visitCost)); // PCMSP-1283
							else
								item.setCostOfAvoidableErVisits(visitCost);
						}
						else {
							item.setCostOfVisits(Constants.DASHES); // PCMSP-1283
							item.setCostOfAvoidableErVisits(Constants.DASHES);
						}

					}
					if (null != request.getMeasureName() && request.getMeasureName().equals(Constants.ASA)) {
						/*
						 * Hard coding right now - as per discussion; data is not available as of now. 
						 * For the iteration purposes, hard coding the JSON parameter to 100 to reflect on the UI
						 */
						/*
						 * Removing the hard coding - 12/17/2015 
						 * BR1.1.30 - The cost must be rounded to the nearest whole dollar (no decimals)
						 */
						String admitCost;
						Integer admtCost;
						if (null != rs.getBigDecimal("ADMT_COST") && item.getTotalCount() >= 5) {
							admtCost = Integer.valueOf(rs.getBigDecimal("ADMT_COST").setScale(0, BigDecimal.ROUND_HALF_UP).intValue());
							admitCost = admtCost.toString();
							if (isExport())
								item.setCostOfAdmits(StringUtil.convertStringToCurrency(admitCost)); // PCMSP-1283
							else
								item.setCostOfAmbulatoryAdmits(admitCost);
						}
						else {
							item.setCostOfAdmits(Constants.DASHES); // PCMSP-1283
							item.setCostOfAmbulatoryAdmits(Constants.DASHES);
						}
					}
					if (null != request.getMeasureName() && request.getMeasureName().contains(Constants.GDR)) {
						item.setTotalGDR(rs.getInt("rt_pct") + "%");
						/*
						 * Hard coding right now - as per discussion; data is not available as of now. 
						 * For the iteration purposes, hard coding the JSON parameter to 100 to reflect on the UI
						 */
						/*
						 * Descoped from R1.7 - 12/9/2015 
						 */
						//item.setCostOfBrandDrugs((isExport() ? "$" : "") + "100");
					}

				}
			}
			else {
				item = new QualityProvider();
				item.setNonCompliantCnt(rs.getInt("non_cmplnt_cnt"));
				item.setCompliantCnt(rs.getInt("cmplnt_cnt"));
				item.setTotalQualityMeasures(rs.getInt("ttl_qlty_msrs"));
				// export needs more data than the UI
				if (isExport()) {
					item.setProviderNPI(rs.getString("ip_npi"));
					if (!(null != request.getMeasureName() && (request.getMeasureName().contains(Constants.GDR) || request.getMeasureName().contains(Constants.FRMLY))
						&& !(null != request.getProgramLobTypeCd() && request.getProgramLobTypeCd().trim().equalsIgnoreCase(Constants.ESN_COMMERCIAL)
							&& null != request.getMeasureName() && request.getMeasureName().contains(Constants.LIER)) )) {
						EligibleMeasures measures = new EligibleMeasures();
						measures.setCareOppsDsplyNm(rs.getString("msr_dsply_nm")); // provider doesn't need other fields				
						item.setEligibleMeasures(measures);
					}
				}
			}

			item.setProviderId(StringUtil.buildUniqueProviderId(String.valueOf(rs.getLong("ip_dim_key")), rs.getString("prov_org_dim_key"))); // WLPRD01747130: ip_dim_key + prov_org_dim_key (previous comment: NF31: instead of prov_grp_hrchy_dim_key)

			//PCMSP-17949
			//PCMSP-13760
			if (null != request.getMeasureName() && request.getMeasureName().contains(Constants.FRMLY)) {
				item.setAttributedPhysicianName(rs.getString("prov_dsply_nm"));
			} else {
				item.setAttributedPhysicianName(
						StringUtil.buildProviderName(rs.getString("ip_last_nm"), rs.getString("ip_frst_nm"), rs.getString("npi_type_cd")));
			}
/*			if (null != request.getMeasureName() && request.getMeasureName().contains(Constants.FRMLY)) {
				item.setAttributedPhysicianName(rs.getString("prov_dsply_nm"));
			}
			else {
				if (!Constants.STAR.equalsIgnoreCase(rs.getString("ip_last_nm")) && !Constants.STAR.equalsIgnoreCase(rs.getString("ip_frst_nm"))) {
					item.setAttributedPhysicianName(rs.getString("ip_last_nm") + ", " + rs.getString("ip_frst_nm"));
				}
				else if (!Constants.STAR.equalsIgnoreCase(rs.getString("ip_last_nm"))) {
					item.setAttributedPhysicianName(rs.getString("ip_last_nm"));
				}
				else {
					item.setAttributedPhysicianName(Constants.UNK);
				}
			}*/
			//PCMSP-13760 - ends

			item.setOrganizationName(rs.getString("prov_org_full_nm"));
			item.setOrgTin(rs.getString("org_tin"));

			// export needs more data than the UI
			if (isExport()) {
				item.setProviderNPI(rs.getString("ip_npi"));
				if (!(null != request.getMeasureName() && (request.getMeasureName().contains(Constants.GDR) || request.getMeasureName().contains(Constants.FRMLY)))
					&& !(null != request.getProgramLobTypeCd() && request.getProgramLobTypeCd().trim().equalsIgnoreCase(Constants.ESN_COMMERCIAL)
						&& null != request.getMeasureName() && request.getMeasureName().contains(Constants.LIER)) ) {
					EligibleMeasures measures = new EligibleMeasures();
					measures.setCareOppsDsplyNm(rs.getString("msr_dsply_nm")); // provider doesn't need other fields				
					item.setEligibleMeasures(measures);
				}
			}

			list.add(item);

			setRowCount(rs.getInt("row_cnt"));
		}

		return list;
	}

	/**
	 * 
	 * @param column name from UI, sort direction
	 * @return column name for DB, sort direction (in case of member full name,
	 *         direction needs to be applied to both first/last name columns)
	 */
	protected String getSortClause(GetDrillDownRequest request) {
		String query = "";

		// Export: sort by last name, first name (per requirement BR1.1.15.9)
		// Display: sort by the parameters UI passes
		if (isExport()) {
			if (null != request.getMeasureName() && request.getMeasureName().contains(Constants.FRMLY))
				query += "prov_dsply_nm asc ";
			else
				query += "upper(ip.ip_last_nm) asc, upper(ip.ip_frst_nm) asc ";
		}
		else {
			HashMap<String, String> map = new HashMap<String, String>();

			for (QuerySort sort : request.getSort()) {
				String direction = sort.getDirection();
				String column = sort.getProperty();
				if (null != request.getMeasureName() && request.getMeasureName().contains(Constants.FRMLY)) {
					map.put("attributedPhysicianName"
						, "prov_dsply_nm " + direction);
				}
				else {
					map.put("attributedPhysicianName"
						, "upper(ip.ip_last_nm) " + direction + ", upper(ip.ip_frst_nm) " + direction);
				}

				if (null != request.getMeasureName() && request.getMeasureName().contains(Constants.FRMLY)) {
					map.put("organizationName"
						, "upper(A.prov_org_full_nm) " + direction);
				}
				else {
					map.put("organizationName"
						, "upper(pod.prov_org_full_nm) " + direction);
				}

				map.put("nonCompliantCnt"
					, "sum(cisf.msr_dnmntr_nbr - cisf.msr_nmrtr_nbr) " + direction);

				map.put("compliantCnt"
					, "sum(cisf.msr_nmrtr_nbr) " + direction);

				map.put("totalQualityMeasures"
					, "sum(cisf.msr_dnmntr_nbr) " + direction);

				if (null != request.getMeasureName() && request.getMeasureName().contains(Constants.FRMLY)) {
					map.put("totalNonFormularyBrandRxDispensed"
						, "total_nonf_disp_count " + direction);
					map.put("totalBFR"
						, "bf_rate " + direction);
				}
				else if (null != request.getMeasureName() && request.getMeasureName().contains(Constants.GDR)) {
					map.put("totalCount"
						, "(SUM(CUDF.MSR_DNMNTR_NBR) - SUM(CUDF.MSR_NMRTR_NBR)) " + direction);
				}
				else {
					map.put("totalCount"
						, "COUNT(CUDF.msr_nmrtr_nbr) " + direction);
				}

				/*map.put("totalGDR"
						, "(Cast(SUM(CUDF.MSR_NMRTR_NBR) as decimal(10,3))) / (Cast(SUM(CUDF.MSR_DNMNTR_NBR) as decimal(10,3)))* 100 " + direction);*/
				map.put("totalGDR"
					, "RT_PCT " + direction);
				/*
				 * Adding the sort clauses for the Cost of Visit / Admit
				 */
				//		map.put("costOfAmbulatoryAdmits" , "sum(vf.ALWD_AMT) " + direction);
				//		map.put("costOfAvoidableErVisits" , "sum(vf.ALWD_AMT) " + direction);

				map.put("costOfAmbulatoryAdmits", "case when count(cudf.MSR_NMRTR_NBR) < 5 then 1 else 0 end, sum(vf.ALWD_AMT) " + direction);
				map.put("costOfAvoidableErVisits", "case when count(cudf.MSR_NMRTR_NBR) < 5 then 1 else 0 end, sum(vf.ALWD_AMT) " + direction);

				query += " " + map.get(column) + " ";
			}
		}

		return query;
	}

}
