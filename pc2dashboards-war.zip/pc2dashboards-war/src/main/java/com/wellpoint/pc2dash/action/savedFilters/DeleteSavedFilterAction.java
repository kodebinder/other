package com.wellpoint.pc2dash.action.savedFilters;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.service.savedFilters.SavedFiltersImpl;


public class DeleteSavedFilterAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		SavedFiltersRequest request = (SavedFiltersRequest) actionRequest;
		ActionResponse response = new SavedFiltersResponse();

		SavedFiltersImpl service = new SavedFiltersImpl();

		try {

			boolean success = service.deleteFilter(request);
			response.setSuccess(success);
			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}

}
