package com.wellpoint.pc2dash.data.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


import com.wellpoint.pc2dash.action.scoreCard.GetEpisodeProvidersRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.scorecard.EpisodesPatientGrid;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class EpisodesProvidersDao extends ServiceImpl{


	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(EpisodesProvidersDao.class);


	public List<EpisodesPatientGrid> getProviderGrid(GetEpisodeProvidersRequest request, boolean exportFlag, int index, int limit) throws Exception {


		List<EpisodesPatientGrid> result = new ArrayList<EpisodesPatientGrid>();
		setRowCount(0);
		int start = 0;
		int stop = 0;

		StringBuilder sql = new StringBuilder()
			.append("select ")
			.append(" a.* ")
			.append("from ( ")
			.append("select ")
			.append(" row_number() over ( ")
			.append(" order by ")
			.append(buildSortClause(request))
			.append("	) as rank , count(*) over () as row_cnt,ip_dim_key,prov_org_dim_key,prov_org_full_nm,ip_frst_nm, ip_last_nm,totalAllowedAmt,totalEpisodeCount ");
			if (StringUtil.isExportDest(request.getDest())) {
				sql.append(" ,PROV_ORG_TAX_ID, IP_SPCLTY_NM, ip_npi ");
			}
			sql.append("from ")
			.append("	( ")
			.append("select ")
			.append(" ip_dim_key,prov_org_dim_key,prov_org_full_nm,ip_frst_nm, ip_last_nm,sum(totalAllowedAmt) as totalAllowedAmt, count(totalEpisodeCount) as totalEpisodeCount ");
		if (StringUtil.isExportDest(request.getDest())) {
			sql.append(" ,PROV_ORG_TAX_ID, IP_SPCLTY_NM, ip_npi ");
		}
		sql.append(" from  ")
			.append(" ( ")
			.append(" select psf.ip_dim_key,psf.prov_org_dim_key,upper(psf.prov_org_full_nm) as prov_org_full_nm, upper(psf.ip_frst_nm) as ip_frst_nm, upper(psf.ip_last_nm) as ip_last_nm,  ");
		if (StringUtil.isExportDest(request.getDest())) {
			sql.append(" psf.PROV_ORG_TAX_ID, psf.IP_SPCLTY_NM,psf.ip_npi, ");
		}
		sql.append(" ETG.TOTL_ANLZD_ALWD_AMT as totalAllowedAmt, ETG.EPSD_NBR as totalEpisodeCount ");
		sql.append(" from  ")
			.append(" SCRCRD_ESN_ETG_MCID_FACT ETG  ")
			.append(" JOIN PAT_SMRY_FACT PSF ON  PSF.MSTR_CNSMR_DIM_KEY = ETG.MSTR_CNSMR_DIM_KEY and PSF.prov_grp_dim_key = ETG.prov_grp_dim_key")
			.append(" and PSF.ip_dim_key = ETG.ip_dim_key ") // and PSF.prov_org_dim_key = ETG.prov_org_dim_key")
			.append("	join poit_user_scrty_acs pusa on ( ")
			.append("		psf.prov_grp_id = pusa.prov_grp_id ")
			.append("		and case ")
			.append("				when pusa.prov_org_tax_id = '0' then psf.prov_org_tax_id ")
			.append("				else pusa.prov_org_tax_id ")
			.append("			end = psf.prov_org_tax_id ")
			.append("	) ")
			.append("  WHERE ");
		sql.append("  PSF.ATRBN_STTS_CD = 'ACTIVE' ")
			.append(" and pusa.sesn_id = ? ")
			.append(" and pusa.enttlmnt_hash_key = ? ");
		
		sql = addAgeFilter(request, sql, "psf");

		if (StringUtil.isNotBlankOrFalse(request.getProvGrpIds())) {
			sql.append(" and psf.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvGrpIds()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProgramId())) {
			sql.append(" and psf.pgm_id in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProgramId()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getLobNm())) {
			/** 66200 PSL Desc Changes | ad87338 | START */
			sql.append(" and psf.lob_ctgry_nm in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getLobNm()) + ") ");
			/** 66200 PSL Desc Changes | ad87338 | END */
		}

		// Organization filter
		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			sql.append(" and psf.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			sql.append(" and psf.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}


		sql.append(" group by psf.ip_dim_key,psf.prov_org_dim_key,upper(psf.prov_org_full_nm), upper(psf.ip_frst_nm), upper(psf.ip_last_nm),ETG.TOTL_ANLZD_ALWD_AMT,ETG.EPSD_NBR ");
		if (StringUtil.isExportDest(request.getDest())) {
			sql.append(" ,psf.PROV_ORG_TAX_ID, psf.IP_SPCLTY_NM, psf.ip_npi )");
		}else {
			sql.append(" ) ");
		}
		
		sql.append(" group by  ip_dim_key,prov_org_dim_key,prov_org_full_nm,ip_frst_nm, ip_last_nm ");
			if (StringUtil.isExportDest(request.getDest())) {
				sql.append(" ,PROV_ORG_TAX_ID, IP_SPCLTY_NM, ip_npi )");
			}else {
				sql.append(" ) ");
			}
		sql.append( " ProviderGrid ) a  ");

		// Do not apply the limit if the request is for export
		//if (!StringUtil.isExportDest(request.getDest())
		//	&& StringUtils.isNotBlank(request.getStart()) && StringUtils.isNotBlank(request.getLimit())) {
			sql.append(" where a.rank between ? and ? ");
		//}

		sql.append(" order by a.rank ");
		sql.append(" with ur ");



		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, sql.toString());

			
			ps.setString(++i, request.getSessionId());
			ps.setString(++i, request.getEntitlementId());

			// Group Ids
			if (StringUtil.isNotBlankOrFalse(request.getProvGrpIds())) {
				String[] array = request.getProvGrpIds().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// Program filters
			if (StringUtil.isNotBlankOrFalse(request.getProgramId())) {
				String[] array = request.getProgramId().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// LOB filters
			if (StringUtil.isNotBlankOrFalse(request.getLobNm())) {
				String[] array = request.getLobNm().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			// Organization filter
			if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
				String[] array = request.getProvDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, StringUtil.parseProviderId(item));
				}
			}
			if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
				String[] array = request.getOrgDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}



			// Do not apply the limit if the request is for export
			if (!exportFlag) {

				start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
				stop = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
			}
			else {
				start = index;
				stop = limit;
			}
			
			ps.setInt(++i, start + 1);
			ps.setInt(++i, start + stop);

			executeQuery(logger, sql.toString());

			while (rs.next()) {

				EpisodesPatientGrid jsonResult = new EpisodesPatientGrid();

				jsonResult.setOrganizationName((null != (rs.getString("prov_org_full_nm"))
					&& !Constants.STAR.equalsIgnoreCase(rs.getString("prov_org_full_nm"))
						? rs.getString("prov_org_full_nm") : Constants.UNK));
				if ((!(Constants.STAR.equalsIgnoreCase(rs.getString("ip_last_nm")) || Constants.UNK.equalsIgnoreCase(rs.getString("ip_last_nm")))
					&& (null != rs.getString("ip_last_nm")))
					&& (!(Constants.STAR.equalsIgnoreCase(rs.getString("ip_frst_nm")) || Constants.UNK.equalsIgnoreCase(rs.getString("ip_frst_nm")))
						&& (null != rs.getString("ip_frst_nm")))) {
					jsonResult.setAttributedPhysicianName(rs.getString("ip_last_nm").trim() + ", " + rs.getString("ip_frst_nm").trim());
				}
				else if (!(Constants.STAR.equalsIgnoreCase(rs.getString("ip_last_nm")) || Constants.UNK.equalsIgnoreCase(rs.getString("ip_last_nm")))
					&& (null != rs.getString("ip_last_nm"))) {
					jsonResult.setAttributedPhysicianName(rs.getString("ip_last_nm").trim());
				}
				else {
					jsonResult.setAttributedPhysicianName(Constants.UNK);
				}
				if (rs.getString("totalAllowedAmt") != null){
					if (exportFlag) {
						jsonResult.setTotalAllowedAmount(StringUtil.convertStringToDecimalCurrency(
								rs.getBigDecimal("totalAllowedAmt").setScale(2, BigDecimal.ROUND_HALF_UP).toString()) );
					}else {
						jsonResult.setTotalAllowedAmount(rs.getString("totalAllowedAmt"));
					}
				}
					

				if (rs.getString("totalEpisodeCount") != null) {
					if(exportFlag) {
						String totEpisodeCount = StringUtil.convertStringToCommaBigDecimal(rs.getString("totalEpisodeCount"), 0);
						jsonResult.setTotalEpisodeCount(totEpisodeCount);
					} else {
						jsonResult.setTotalEpisodeCount(rs.getString("totalEpisodeCount"));
					}
					
				}
				jsonResult.setProviderId(StringUtil.buildUniqueProviderId(String.valueOf(rs.getLong("ip_dim_key")), rs.getString("prov_org_dim_key")));

				if (StringUtil.isExportDest(request.getDest())) {
					jsonResult.setAttributedPhysicianNPI(StringUtil.getValueOrDashes(rs.getString("ip_npi")));
					jsonResult.setAttributedProvSpclty(StringUtil.getValueOrDashes(rs.getString("IP_SPCLTY_NM")));
					jsonResult.setOrganizationTin(StringUtil.getValueOrDashes(rs.getString("PROV_ORG_TAX_ID")));

				}

				setTotalExport(rs.getInt("row_cnt"));
				setRowCount(rs.getInt("row_cnt"));

				result.add(jsonResult);
			}
			//	setRowCount(rs.getInt("row_cnt"));
		}
		catch (Exception e) {

			throw new Exception("Unable to get EpisodesProviderGrid (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;

	}

	private String buildSortClause(GetEpisodeProvidersRequest request) {

		StringBuilder query = new StringBuilder();
		String defaultSort = ", totalAllowedAmt desc" ;

		for (QuerySort sort : request.getSort()) {
			String dir = sort.getDirection().replaceAll("\"", "");
			String property = sort.getProperty();

			if (property.contains("totalAllowedAmount")) {
				query.append(" totalAllowedAmt " + dir  +defaultSort);
			}
			if (property.contains("attributedPhysicianName")) {
				query.append(" upper(ip_last_nm) " + dir + ", upper(ip_frst_nm) " + dir + defaultSort );   
			}
			if (property.contains("organizationName")) {
				query.append( "upper(prov_org_full_nm) " + dir  +defaultSort);
			}
			if (property.contains("totalEpisodeCount")) {
				query.append(" totalEpisodeCount " + dir  +defaultSort);
			}
		}

		return query.toString();
	}


}
