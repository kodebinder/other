package com.wellpoint.pc2dash.action.careOpportunities;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetCareOpportunitiesRateResponse extends ActionResponse {

}
