package com.wellpoint.pc2dash.action.tooltip;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.data.dao.TherapeuticClassToolTipDao;
import com.wellpoint.pc2dash.dto.pharmacy.TherapeuticClassToolTip;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.ErrorProperties;

public class GetTherapeuticClassesToolTipAction extends Action {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetTherapeuticClassesToolTipAction.class);

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetTherapeuticClassesToolTipRequest request = (GetTherapeuticClassesToolTipRequest) actionRequest;
		ActionResponse response = new GetTherapeuticClassesToolTipResponse();

		ErrorProperties err = ErrorProperties.getInstance();
		List<TherapeuticClassToolTip> resultList = new ArrayList<TherapeuticClassToolTip>();
		List<String> grps = null;

		try {

			removeLobPgmPrefixes(request);

			// CQ Defect: 303046
			// Pharmacy Report - Class drill down data is not suppressed when data on Class view is suppressed
			if (StringUtils.isNotBlank(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			if (null != grps && !grps.isEmpty()) {
				request.setProvGrpIdsWithoutClinicalCheck(StringUtils.join(grps, ','));
				grps = filterProvGrpsByClinicalInd(request, grps);
				request.setProvGrpIds(StringUtils.join(grps, ','));
			}

			TherapeuticClassToolTipDao dao = new TherapeuticClassToolTipDao();
			/*Collection<TherapeuticClassToolTip> vals = dao.getDrugClassToolTip(request);
			result.setData(vals);*/

			resultList = dao.getDrugClassToolTip(request);

			if (null == resultList || resultList.isEmpty()) {

				response.setMessage(err.getProperty("successNoData"));
			}
			else {
				response.setMessage(err.getProperty("successful"));
				response.setData(resultList);
				response.setTotal(resultList.size());
			}
			response.setSuccess(true);
			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

	}



}
