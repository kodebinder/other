package com.wellpoint.pc2dash.action.patients;

import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetChronicGapScoreResponse extends ActionResponse {

	private String id;
	private String text;
	private Collection<Object> children = new ArrayList<Object>();

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *        the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the text
	 */
	public String getText() {
		return text;
	}

	/**
	 * @param text
	 *        the text to set
	 */
	public void setText(String text) {
		this.text = text;
	}

	/**
	 * @return the children
	 */
	public Collection<Object> getChildren() {
		return children;
	}

	/**
	 * @param children
	 *        the children to set
	 */
	public void setChildren(Collection<Object> children) {
		this.children = children;
	}
}
