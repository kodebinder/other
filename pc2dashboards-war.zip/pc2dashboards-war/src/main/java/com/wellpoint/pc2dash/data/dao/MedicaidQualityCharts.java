package com.wellpoint.pc2dash.data.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.quality.GetQualityChartRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.drillDown.DrillDownChart;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QueryConstants;
import com.wellpoint.pc2dash.util.StringUtil;

public class MedicaidQualityCharts extends GeneralCharts {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(MedicaidQualityCharts.class);

	public List<DrillDownChart> getMedicaidQualityChart(GetQualityChartRequest request) throws Exception {

		List<DrillDownChart> result = new ArrayList<DrillDownChart>();
		String sql = buildSql(request);

		try {
			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			buildPreparedStatement(request, sql);
			executeQuery(logger, sql);
			result = convertSelectedRowsToObjects(rs);

		}
		catch (Exception e) {
			throw new Exception("Exception during getMedicaidQualityChart (" + request.toString() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}

	protected String buildSql(GetQualityChartRequest request) {
		String countWhereClause = "";

		StringBuilder sql = new StringBuilder()
			.append("select DISTINCT "
				+ "MD_Q.MSR_ID, "
				+ "SMHD.SUB_CMPST_NM, "
				+ "SMHD.SUB_CMPST_DEFN_ID, "
				+ "MD_Q.MSR_DSPLY_NM, "
				+ "cfq.MSR_NON_CMPLNT, "
				+ "EF.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT, "
				+ "cfq.MSR_CMPLNT ");

		// add to from and where clauses as necessary (adding some by default, since they're very likely to be required)

		StringBuilder from = new StringBuilder(" from scrcrd_pgm_msr_hrchy_fact spmhf ");
		from.append("join SCRCRD_MSR_HRCHY_DIM AS SMHD ON (spmhf.SCRCRD_MSR_HRCHY_DIM_KEY = SMHD.SCRCRD_MSR_HRCHY_DIM_KEY) ");
		from.append("join MSR_DIM AS MD_Q ON (SMHD.MSR_DIM_KEY = MD_Q.MSR_DIM_KEY)  ");
		from.append("join PGM_DIM AS PD ON (spmhf.PGM_DIM_KEY = PD.PGM_DIM_KEY) ");

		StringBuilder leftJoin = new StringBuilder(" left join ");

		StringBuilder innerSelect = new StringBuilder("(Select "
			+ buildSharedSelectGroupByColumns(request)
			+ ", COUNT(CASE WHEN CF.MSR_NMRTR_NBR = 0 THEN CF.MSTR_CNSMR_DIM_KEY END) AS MSR_NON_CMPLNT,"
			+ "COUNT(CASE WHEN CF.MSR_NMRTR_NBR = 1 THEN CF.MSTR_CNSMR_DIM_KEY END) AS MSR_CMPLNT, "
			+ "  count(CF.MSTR_CNSMR_DIM_KEY) as ELIGIBLE_CNT ");

		StringBuilder innerFrom = new StringBuilder(" from CMPLNC_FACT AS CF ");
		innerFrom
			.append(
				"join MSTR_CNSMR_FACT AS MCF ON (CF.MSTR_CNSMR_DIM_KEY = MCF.MSTR_CNSMR_DIM_KEY AND CF.PROV_GRP_DIM_KEY = MCF.PROV_GRP_DIM_KEY AND CF.PGM_DIM_KEY = MCF.PGM_DIM_KEY AND MCF.ATRBN_STTS_CD = 'ACTIVE' ) ");
		innerFrom.append("join PGM_DIM AS PD ON (CF.PGM_DIM_KEY = PD.PGM_DIM_KEY and PD.PGM_ID = ?) ");
		/** Commenting this join as part of fix for PCMSP-6629 */
		//innerFrom.append("join prov_org_dim pod on (cf.prov_org_dim_key = pod.prov_org_dim_key) "); // added for POIT join
		innerFrom.append("join PROV_GRP_DIM AS PGD ON (CF.PROV_GRP_DIM_KEY = PGD.PROV_GRP_DIM_KEY and PGD.PROV_GRP_ID = ? ) ");
		innerFrom.append("join SCRCRD_MSR_HRCHY_DIM AS SMHD ON (cf.SCRCRD_MSR_HRCHY_DIM_KEY = SMHD.SCRCRD_MSR_HRCHY_DIM_KEY and SMHD.CMPST_DEFN_ID = ? ) ");
		innerFrom.append("join MSR_DIM AS MD ON (CF.MSR_DIM_KEY = MD.MSR_DIM_KEY) ");
		innerFrom.append("LEFT JOIN psl_dim psl_dim on (MCF.psl_dim_key = psl_dim.psl_dim_key) ");

		/**
		 * Commenting the lob dim join as part of Defect fix for WLPRD02383426
		 * Author - AD12140
		 * Based on suggestions from Data team to remove lob checks from the Drill down Patient and chart queries
		 */
		//innerFrom.append("LEFT JOIN LOB_DIM AS LD ON (MCF.LOB_DIM_KEY = LD.LOB_DIM_KEY) ");

		innerFrom.append("join prov_grp_hrchy_dim pghd on (cf.prov_grp_dim_key = pghd.prov_grp_dim_key "); // Moved this join into the if-statement as it was causing too many rows to be returned
		innerFrom.append("and cf.prov_org_dim_key = pghd.prov_org_dim_key ");
		innerFrom.append("and cf.ip_dim_key = pghd.ip_dim_key "); // added this condition to the join so that Quality Charts returns the same counts as Quality Patients/Providers [WLPRD01083809]
		innerFrom.append("and mcf.PROV_GRP_HRCHY_DIM_KEY = pghd.PROV_GRP_HRCHY_DIM_KEY) ");
		innerFrom
			.append("join pat_smry_fact psf on (cf.mstr_cnsmr_dim_key = psf.mstr_cnsmr_dim_key and psf.ATRBN_STTS_CD = 'ACTIVE'  ")
			.append(" AND psf.prov_grp_dim_key=cf.prov_grp_dim_key and psf.pgm_dim_key=cf.pgm_dim_key ) ");//PCMSP-5778
		/** Defect PCMSP-6629 author ad02662 adding this join to keep the prov_org_tax_id's to be in sync with POIT and Pat_smry tables */
		innerFrom.append("join prov_org_dim pod on (psf.prov_org_dim_key = pod.prov_org_dim_key) "); 

		StringBuilder innerWhere = new StringBuilder(" where ");

		// POIT clause
		//	if (doPoitTableJoin(request.getGrpInd())) {
		innerFrom.append(getPoitTableJoin());

		innerWhere.append(getPoitTableWhere());
		//	}

		innerWhere.append("and CF.ANLYSS_AS_OF_DT = ? ");

		/**
		 * Commenting the lob dim key where clause as part of Defect fix for WLPRD02383426
		 * Author - AD12140
		 * Based on suggestions from Data team to remove lob checks from the Drill down Patient and chart queries
		 */
		/*innerWhere.append(" AND (LD.LOB_DIM_KEY IN ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getLobDimKeys()) 
				+ ") or (LD.LOB_DIM_KEY is null)) ");*/

		StringBuilder groupBy =
			new StringBuilder(" group by ")
				.append(buildSharedSelectGroupByColumns(request))
				.append(" ) cfq")
				.append(" on spmhf.PGM_DIM_KEY = cfq.PGM_DIM_KEY and spmhf.MSRMNT_PRD_STRT_DT = cfq.MSRMNT_PRD_STRT_DT and MD_Q.MSR_ID = cfq.MSR_ID ")
				.append(
					" JOIN ERNCNTR_FACT AS EF ON CFQ.PGM_DIM_KEY = EF.PGM_DIM_KEY AND CFQ.PROV_GRP_DIM_KEY = EF.PROV_GRP_DIM_KEY AND CFQ.MSRMNT_PRD_STRT_DT = EF.MSRMNT_PRD_STRT_DT ");

		StringBuilder where = new StringBuilder(" where ");

		if (!StringUtils.isBlank(request.getProgramId())) {

			where.append("and pd.pgm_id = ? "); // programId
		}

		if (StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys())) {

			innerWhere.append("and md.msr_id in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getQualityMeasureKeys())
				+ ") "); // qualityMeasureKeys (not smhd.msr_dim_key)
		}
		/** AF21144 | PCMSP-473 start */
		if (Constants.AND_OPERATOR.equalsIgnoreCase(request.getQualityMeasureKeysToggle()) || Constants.AND_OPERATOR.equalsIgnoreCase(request.getStatusCdsToggle())) {
			innerWhere.append(" and cf.MSTR_CNSMR_DIM_KEY in (select MSTR_CNSMR_DIM_KEY from ")
				.append("(select MSTR_CNSMR_DIM_KEY ");
			if (Constants.AND_OPERATOR.equalsIgnoreCase(request.getQualityMeasureKeysToggle()))
				innerWhere.append(", LISTAGG( md2.msr_id, ',') msr_list ");
			if (Constants.AND_OPERATOR.equalsIgnoreCase(request.getStatusCdsToggle()))
				innerWhere.append(", count(distinct cf2.MSR_NMRTR_NBR) as st_count ");

			innerWhere.append(" from CMPLNC_FACT cf2 ")
				.append(" join msr_dim md2 on cf2.msr_dim_key = md2.msr_dim_key");

			StringBuilder innerWhereCheck = new StringBuilder();
			innerWhereCheck.append(" where cf2.msrmnt_prd_strt_dt = ? ");
			if (StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys()))
				innerWhereCheck.append(" and md2.msr_id in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getQualityMeasureKeys())
					+ ") ");
			if (StringUtil.isNotBlankOrFalse(request.getStatusCds())) {
				innerWhereCheck.append(" and cf2.MSR_NMRTR_NBR in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getStatusCds())
					+ ") ");
			}
			innerWhere.append(innerWhereCheck);

			innerWhere.append(" group by MSTR_CNSMR_DIM_KEY) ");

			StringBuilder outerWhereCheck = new StringBuilder();
			if (Constants.AND_OPERATOR.equalsIgnoreCase(request.getQualityMeasureKeysToggle())) {
				outerWhereCheck.append(" where (");
				String[] msrIds = request.getQualityMeasureKeys().split(",");
				for (int i = 0; i < msrIds.length; i++) {
					if (i > 0)
						outerWhereCheck.append(" and ");
					outerWhereCheck.append(" msr_list like ? ");
				}
				outerWhereCheck.append(" ) ");
			}
			if (Constants.AND_OPERATOR.equalsIgnoreCase(request.getStatusCdsToggle())) {
				if (outerWhereCheck.length() > 0)
					outerWhereCheck.append(" and ");
				else
					outerWhereCheck.append(" where ");
				outerWhereCheck.append(" st_count = ? ");
			}

			innerWhere.append(outerWhereCheck);
			innerWhere.append(")");
		}

		if (!StringUtils.isBlank(request.getCompositeId())) {

			where.append("and smhd.cmpst_defn_id = ? "); // CompositeId
			where.append(" AND CFQ.ELIGIBLE_CNT > 0 ");
			where.append("  AND EF.MNTH_ID = (SELECT MAX(EF.MNTH_ID) FROM ERNCNTR_FACT EF INNER JOIN "
				+ " (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT FROM SCRCRD_PGM_MSR_HRCHY_FACT WHERE "
				+ " PGM_DIM_KEY=(SELECT PGM_DIM_KEY FROM PGM_DIM WHERE PGM_ID= ? )");
			if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {

				where.append("and msrmnt_prd_strt_dt = ? "); // measurementPeriodStartDt
			}
			where.append(" GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM "
				+ " ON EF.PGM_DIM_KEY=SC_PGM.PGM_DIM_KEY AND EF.MSRMNT_PRD_STRT_DT=SC_PGM.MSRMNT_PRD_STRT_DT ) AND SPMHF.TRNCH_DEFN_DIM_KEY = EF.TRNCH_DEFN_DIM_KEY ");
		}

		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {

			where.append("and spmhf.msrmnt_prd_strt_dt = ? "); // measurementPeriodStartDt
		}

		if (StringUtil.isNotBlankOrFalse(request.getCareOppsStatusCds())) {

			innerWhere.append("and CF.MSTR_CNSMR_DIM_KEY in "
				+ "(select COF.MSTR_CNSMR_DIM_KEY from CARE_OPRTNTY_FACT AS COF "
				+ "join MSR_DIM MD_CO on (MD_CO.MSR_DIM_KEY = COF.MSR_DIM_KEY) "
				+ "where MD.CARE_OPRTNTY_MSR_DIM_KEY = MD_CO.MSR_DIM_KEY "
				+ "and COF.prov_grp_dim_key = CF.PROV_GRP_DIM_KEY "
				+ "and COF.MSTR_CNSMR_DIM_KEY in ( "
				+ QueryConstants.getCareOppStatusImpQueryWithToggle(request)
				+ ") ) ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) { // populated if the Organization filter is applied
			innerWhere.append(" and psf.ip_dim_key in (" // NF31 (no longer pghd.prov_grp_hrchy_dim_key)
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys())
				+ ") "); // provDimKeys
		}
		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			innerWhere.append(" and psf.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}


		/** 57008 CHRONIC_CARE_GAP changes| ad87338 | START */
		//AF00030 made changes for PCMSP-1041 Medicaid Quality Charts
		QueryConstants.prepareChronicRiskFiltersFromPatTable(StringUtil.prepareMapForChronicRisk(request), innerWhere);
		//QueryConstants.prepareChronicRiskFilters(StringUtil.prepareMapForChronicRisk(request), innerWhere);
		/** 57008 CHRONIC_CARE_GAP changes| ad87338 | END */

		if (null != request.getProgramLobTypeCd() && !request.getProgramLobTypeCd().contains(Constants.FPCC_PGM_TYPE)) {

			// IHM Care Coordination filter: AP56, CP34, CO19, & SC92
			//			innerWhere.append(QueryConstants.buildIhmExistsCondition(request.getIhmIndToggle(),request.getIhmInd())); // Moved due to 2.0 toggle logic

			if (filterCMDMPrograms(request)) {
				innerFrom.append(" left join crmgt_dm_fact cdf on (mcf.mstr_cnsmr_dim_key = cdf.mstr_cnsmr_dim_key) ");

				if (StringUtil.isNotBlankOrFalse(request.getCmdmProgramKeys())) {

					innerWhere.append(QueryConstants.buildCmDmProgramKeysSubSelect(request));
				}

				if (StringUtil.isNotBlankOrFalse(request.getCmdmStatusKeys())) {
					// Quality Patients and Quality Charts (as well as Pop Mgt tabs) all use this same logic - reuse it.
					//					innerFrom.append(QueryConstants.buildCmDmStatusKeysFilterFromClause(request.getCmdmStatusKeys()));

					//					innerWhere.append(QueryConstants.buildCmDmStatusKeysFilterWhereClause(request.getCmdmStatusKeys(), "cf"));

					innerWhere.append(QueryConstants.buildCmDmStatusKeysSubSelectsWithPatTables(request));
				}
			}
			else {

				innerWhere.append(QueryConstants.buildIhmExistsCondition(request));
			}
		}

		where = StringUtil.removeFirstOccurenceWithinString(where, "and");
		innerWhere = StringUtil.removeFirstOccurenceWithinString(innerWhere, "and");

		sql.append(from).append(leftJoin).append(innerSelect).append(innerFrom).append(innerWhere).append(groupBy).append(where);


		/** AF21144 | PCMSP-473: additional logic to show selected measures in chart | start */
		if (StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys()) && Constants.AND_OPERATOR.equalsIgnoreCase(request.getQualityMeasureKeysToggle())) {
			sql.append("and md_q.msr_id in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getQualityMeasureKeys())
				+ ") ");
		}
		/** end */

		sql.append(" order by EF.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT DESC ");
		sql
			.append(" with ur ");

		String sqlString = String.format(sql.toString(), new Object[] {countWhereClause, countWhereClause});

		return sqlString;
	}

	protected String buildSharedSelectGroupByColumns(GetQualityChartRequest request) {
		StringBuilder select = new StringBuilder()
			.append(" cf.PGM_DIM_KEY ")
			.append(", CF.PROV_GRP_DIM_KEY ")
			.append(", cf.MSRMNT_PRD_STRT_DT ")
			.append(", md.msr_id ")
			.append(", smhd.sub_cmpst_nm ")
			.append(", smhd.sub_cmpst_defn_id ")
			.append(", md.msr_dsply_nm ");


		return select.toString();
	}

	protected void buildPreparedStatement(GetQualityChartRequest request, String sql) throws SQLException {
		int i = 0;
		prepareStatement(logger, sql);

		if (!StringUtils.isBlank(request.getProgramId())) {
			ps.setString(++i, request.getProgramId());
		}

		if (!StringUtils.isBlank(request.getProvGrpIds())) {
			ps.setString(++i, request.getProvGrpIds());
		}

		if (!StringUtils.isBlank(request.getCompositeId())) {
			ps.setString(++i, request.getCompositeId());
		}



		//	if (doPoitTableJoin(request.getGrpInd())) {			
		ps.setString(++i, request.getSessionId());

		ps.setString(++i, request.getEntitlementId());
		//	}

		CommonQueries cq = new CommonQueries();
		//String aaod = cq.selectAAODOther(request.getProgramId(), request.getMeasurementPeriodStartDt());
		String aaod = cq.selectAAODOther(request.getProgramId(), request.getMeasurementPeriodStartDt(), request.getProvGrpIds()); //PCMSP-13914
		ps.setString(++i, aaod);

		String[] msrArray = null;
		List<String> statArray = null;
		if (StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys()))
			msrArray = request.getQualityMeasureKeys().split(",");
		if (StringUtil.isNotBlankOrFalse(request.getStatusCds()))
			statArray = StringUtil.getStatusCdsFilters(request.getStatusCds());

		if (StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys())) {
			for (String item : msrArray) {
				ps.setString(++i, item);
			}
		}



		if (Constants.AND_OPERATOR.equalsIgnoreCase(request.getQualityMeasureKeysToggle()) || Constants.AND_OPERATOR.equalsIgnoreCase(request.getStatusCdsToggle())) {

			if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
				ps.setString(++i, request.getMeasurementPeriodStartDt());
			}

			if (StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys()))
				for (String item : msrArray) {
					ps.setString(++i, item);
				}

			if (StringUtil.isNotBlankOrFalse(request.getStatusCds()))
				for (String item : statArray) {
					ps.setString(++i, item);
				}


			/** AF21144 | PCMSP-473 start */
			if (Constants.AND_OPERATOR.equalsIgnoreCase(request.getQualityMeasureKeysToggle())) {
				if (StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys()))
					for (String item : msrArray) {
						ps.setString(++i, "%" + item + "%");
					}
			}
			/** end */

			/** AF21144 | PCMSP-472 start */
			if (Constants.AND_OPERATOR.equalsIgnoreCase(request.getStatusCdsToggle()))
				ps.setInt(++i, statArray.size());
			/** end */
		}

		/**
		 * Commenting the lob dim key where clause as part of Defect fix for WLPRD02383426
		 * Author - AD12140
		 * Based on suggestions from Data team to remove lob checks from the Drill down Patient and chart queries
		 */
		/*if (!StringUtils.isBlank(request.getLobDimKeys())) { // YJF: WLPRD01594317 lobDimKeys need to be set before careOppStatusCds
			String[] array = request.getLobDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}*/

		if (StringUtil.isNotBlankOrFalse(request.getCareOppsStatusCds())) {
			String[] array = request.getCareOppsStatusCds().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.convertCareOppsStatus(item));
			}
			ps.setInt(++i, array.length);
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) { // populated if the Organization filter is applied
			String[] array = request.getProvDimKeys().split(",");
			String loggedProvDimKeys = "";
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
				loggedProvDimKeys += "," + StringUtil.parseProviderId(item);
			}
			StringUtils.replaceOnce(loggedProvDimKeys, ",", "");
		}
		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		/** 57008 CHRONIC_CARE_GAP changes| ad87338 | START */
		// Risk Drivers filter
		/*if (null != request.getRiskDriverKeys() && StringUtil.isNotBlankOrFalse(request.getRiskDriverKeys())) {
			String[] array = request.getRiskDriverKeys().split(",");
			// Need to be set 4 times
			for (String item : array) {
				ps.setString(++i, item);
			}
			for (String item : array) {
				ps.setString(++i, item);
			}
			for (String item : array) {
				ps.setString(++i, item);
			}
			for (String item : array) {
				ps.setString(++i, item);
			}
		}*/

		// Risk Drivers filter
		if (StringUtil.isNotBlankOrFalse(request.getRiskDriverKeys())) {
			i = buildRiskDriversFilterPreparedStatement(request, i);
		}

		// Risk Drivers filter
		if (null != request.getChronicCareGapsKeys()
			&& StringUtil.isNotBlankOrFalse(request.getChronicCareGapsKeys())) {
			String[] array = request.getChronicCareGapsKeys().split(",");
			// Need to be set 4 times
			for (String item : array) {
				ps.setString(++i, item);
			}
			/*for (String item : array) {
				ps.setString(++i, item);
			}
			for (String item : array) {
				ps.setString(++i, item);
			}
			for (String item : array) {
				ps.setString(++i, item);
			}*/
		}
		/** 57008 CHRONIC_CARE_GAP changes| ad87338 | END */

		if (null != request.getProgramLobTypeCd() && !request.getProgramLobTypeCd().contains(Constants.FPCC_PGM_TYPE)) {
			if (filterCMDMPrograms(request)) {

				// CMDM Program filters
				i = buildCMDMPreparedStatement(request, i);

				// CMDM Status filters
				i = buildCMDMStatusPreparedStatement(request, i);
			}
		}

		if (!StringUtils.isBlank(request.getProgramId())) {
			ps.setString(++i, request.getProgramId());
		}

		if (!StringUtils.isBlank(request.getCompositeId())) {
			ps.setString(++i, request.getCompositeId());
		}

		if (!StringUtils.isBlank(request.getProgramId())) {
			ps.setString(++i, request.getProgramId());
		}

		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
			ps.setString(++i, request.getMeasurementPeriodStartDt());
		}

		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
			ps.setString(++i, request.getMeasurementPeriodStartDt());
		}

		/** AF21144 | PCMSP-473 start */
		if (StringUtil.isNotBlankOrFalse(request.getQualityMeasureKeys()) && Constants.AND_OPERATOR.equalsIgnoreCase(request.getQualityMeasureKeysToggle())) {
			String[] array = request.getQualityMeasureKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}
		/** end */

	}

	protected List<DrillDownChart> convertSelectedRowsToObjects(ResultSet rs) throws SQLException {
		List<DrillDownChart> list = new ArrayList<DrillDownChart>();

		while (rs.next()) {
			DrillDownChart item = new DrillDownChart();

			item.setMeasureID(rs.getString("msr_id")); // instead of cf.msr_dim_key
			item.setMeasureParent(rs.getString("sub_cmpst_nm"));
			item.setMeasureParentID(rs.getString("sub_cmpst_defn_id"));
			item.setMeasureName(rs.getString("msr_dsply_nm"));
			item.setMeasureNonCompliant(rs.getInt("msr_non_cmplnt"));
			item.setMeasureCompliant(rs.getInt("msr_cmplnt"));
			if (rs.getString("RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT") != null && !rs.getString("RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT").toString().equalsIgnoreCase("0.00")) {
				item.setTop4(true);
			}

			list.add(item);
		}

		return list;
	}
}
