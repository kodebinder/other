package com.wellpoint.pc2dash.action.reconciliationReports;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.patient.TreeHierarchy;
import com.wellpoint.pc2dash.dto.reconciliationReports.ReconciliationReport;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.performance.ReconciliationReportsExport;
import com.wellpoint.pc2dash.service.reconciliationReports.ReconciliationReportsServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;


public class GetReconciliationReportsAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetReconciliationReportsRequest request = (GetReconciliationReportsRequest) actionRequest;
		ActionResponse response = new GetReconciliationReportsResponse();
		ErrorProperties err = ErrorProperties.getInstance();

		ReconciliationReportsServiceImpl service = new ReconciliationReportsServiceImpl();
		List<String> grps = new ArrayList<String>();

		List<TreeHierarchy> resultList = null;
		int totalRecords = 0;

		try {

			// Kill switch check on Provider groups
			if (StringUtil.isNotBlankOrFalse(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			// Clinical access check on provider groups
			if (null != grps && !grps.isEmpty()) {
				grps = filterProvGrpsByFinancialInd(request, grps);
			}

			if (!grps.isEmpty()) {
				request.setProvGrpIds(StringUtils.join(grps, ','));
			}
			else {
				request.setProvGrpIds("0"); //changes for PCMSP-7605,to satisfy condition in serviceimpl
			}

			CommonQueries cq = new CommonQueries();
			request.setSuppression(cq.getActiveSuppressionForSelectComponents(request));
			request.setDest(request.getDest().equalsIgnoreCase(Constants.XLSX) ? Constants.XLS : request.getDest() );

			if (StringUtil.isExportDest(request.getDest())) {

				List<ReconciliationReport> reports = service.getSelectedReports(request);

				for (ReconciliationReport report : reports) {
					ReconciliationReportsExport exp = new ReconciliationReportsExport(request, report);
					ExportProcessor.getInstance().submit(exp);
				}
			}
			else {

				resultList = service.getData(request);
				totalRecords = service.getTotalRecords();

				((GetReconciliationReportsResponse) response).setChildren(resultList);
				response.setTotal(totalRecords);

				if (CollectionUtils.isEmpty(resultList)) {
					response.setMessage(err.getProperty("successNoData"));
				}
				else {
					response.setMessage(err.getProperty("successful"));
				}
			}

			response.setSuccess(true);
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

		return response;
	}
}
