package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.medicalCostTarget.GetMedicalCostTargetRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.medicalCostBaseline.McbSmryDto;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;

public class MedicalCostTargetRetroDAO extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(MedicalCostTargetRetroDAO.class);

	@Override
	public boolean read(Dto o) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void update(Dto o) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(Dto o) throws Exception {
		// TODO Auto-generated method stub

	}

	public List<McbSmryDto> getMCTRetroMetricData(GetMedicalCostTargetRequest request) {
		List<McbSmryDto> resultList = new ArrayList<McbSmryDto>();
		try {
			StringBuilder query = new StringBuilder();

			query.append("SELECT distinct ")
				.append("  mcbsf.MTRC_CD ")
				.append(", mcbsf.MTRC_NM ")
				.append(", mcbsf.PHRMCY_IND ")
				.append(", mcbsf.PSL_ID ")
				.append(", mcbsf.PG_PROD_NBR ")
				.append(", mcbsf.PROD_MDCL_NBR ")
				.append(", mcbsf.PG_IND ")
				.append(", mcbsf.DWNSD_RISK_IND ")
				.append(" FROM ")
				.append(" MCB_SMRY_FACT mcbsf")
				.append(" join MCT_RETRO_FACT mrf on (" + getJoinsBetweenMCTandMCB() + ")")
				.append(" join LOB_DIM lob on (mcbsf.LOB_DIM_KEY = lob.LOB_DIM_KEY)")
				.append(" WHERE ")
				.append(" mcbsf.MSRMNT_PRD_STRT_DT = ? ")
				.append(" AND mcbsf.MSRMNT_PRD_END_DT = ? ")
				.append(" AND mcbsf.PROV_GRP_ID = ? ") // switched from PROV_GRP_DIM_KEY for suppression purposes
				.append(" AND mcbsf.PGM_ID = ? ")
				.append(" AND lob.LOB_DESC = ? ")
				.append(" AND mcbsf.MDPNL_ID = ? ")
				.append(" AND mcbsf.MTRC_CD in (10,11,12,9,13,14,15,16,18,19) ")
				.append(" and mrf.INTRVL_MNTH_CNT = ? ");
			if (Constants.N.equals(request.getShowAll())) {
				query.append(" and mrf.INTRVL_MNTH_CNT in ("
					+ CommonQueries.getMctRetroInterval()
					+ " ) ");
			}

			query.append(" UNION ");

			query.append(" select distinct ")
				.append(" 32 as MTRC_CD ")
				.append(" ,'Market Retrospective Trend Factor' as MTRC_NM ")
				.append(" ,mrf.PHRMCY_IND ")
				.append(" ,mcbsf.PSL_ID ")
				.append(" ,null as PG_PROD_NBR ")
				.append(" ,mrf.RETRO_TRND_FCTR_PCT as PROD_MDCL_NBR ")
				.append(" ,'N' as PG_IND ")
				.append(", mcbsf.DWNSD_RISK_IND ")
				.append(" from MCT_RETRO_FACT mrf join ")
				.append(" MCB_SMRY_FACT mcbsf on (" + getJoinsBetweenMCTandMCB() + ") ")
				.append(" join  LOB_DIM lob on (mcbsf.LOB_DIM_KEY = lob.LOB_DIM_KEY) ")
				.append(" where mcbsf.MSRMNT_PRD_STRT_DT = ? ")
				.append(" and  mcbsf.MSRMNT_PRD_END_DT = ? ")
				.append(" and  mcbsf.PROV_GRP_ID = ? ")
				.append(" and  mcbsf.PGM_ID = ? ")
				.append(" and  lob.LOB_DESC = ? ")
				.append(" and  mcbsf.MDPNL_ID = ? ")
				.append(" and mrf.INTRVL_MNTH_CNT = ? ");
			if (Constants.N.equals(request.getShowAll())) {
				query.append(" and mrf.INTRVL_MNTH_CNT in ("
					+ CommonQueries.getMctRetroInterval()
					+ " ) ");
			}

			query.append(" UNION ");

			query.append(" select distinct ")
				.append(" 33 as MTRC_CD ")
				.append(" ,'Medical Retrospective Trend Factor' as MTRC_NM ")
				.append(" ,mrf.PHRMCY_IND ")
				.append(" ,mcbsf.PSL_ID ")
				.append(" ,null as PG_PROD_NBR ")
				.append(" ,mrf.RETRO_MDCL_TRND_FCTR_PCT as PROD_MDCL_NBR ")
				.append(" ,'N' as PG_IND ")
				.append(", mcbsf.DWNSD_RISK_IND ")
				.append(" from MCT_RETRO_FACT mrf join ")
				.append(" MCB_SMRY_FACT mcbsf on (" + getJoinsBetweenMCTandMCB() + ") ")
				.append(" join  LOB_DIM lob on (mcbsf.LOB_DIM_KEY = lob.LOB_DIM_KEY) ")
				.append(" where mcbsf.MSRMNT_PRD_STRT_DT = ? ")
				.append(" and  mcbsf.MSRMNT_PRD_END_DT = ? ")
				.append(" and  mcbsf.PROV_GRP_ID = ? ")
				.append(" and  mcbsf.PGM_ID = ? ")
				.append(" and  lob.LOB_DESC = ? ")
				.append(" and  mcbsf.MDPNL_ID = ? ")
				.append(" and mrf.INTRVL_MNTH_CNT = ? ");
			if (Constants.N.equals(request.getShowAll())) {
				query.append(" and mrf.INTRVL_MNTH_CNT in ("
					+ CommonQueries.getMctRetroInterval()
					+ " ) ");
			}

			query.append(" UNION ");

			query.append(" select distinct ")
				.append(" 34 as MTRC_CD ")
				.append(" ,'Pharmacy Retrospective Trend Factor' as MTRC_NM ")
				.append(" ,mrf.PHRMCY_IND ")
				.append(" ,mcbsf.PSL_ID ")
				.append(" ,null as PG_PROD_NBR ")
				.append(" ,mrf.RETRO_PHRMCY_TRND_FCTR_PCT as PROD_MDCL_NBR ")
				.append(" ,'N' as PG_IND ")
				.append(", mcbsf.DWNSD_RISK_IND ")
				.append(" from MCT_RETRO_FACT mrf join ")
				.append(" MCB_SMRY_FACT mcbsf on (" + getJoinsBetweenMCTandMCB() + ") ")
				.append(" join  LOB_DIM lob on (mcbsf.LOB_DIM_KEY = lob.LOB_DIM_KEY) ")
				.append(" where mcbsf.MSRMNT_PRD_STRT_DT = ? ")
				.append(" and  mcbsf.MSRMNT_PRD_END_DT = ? ")
				.append(" and  mcbsf.PROV_GRP_ID = ? ")
				.append(" and  mcbsf.PGM_ID = ? ")
				.append(" and  lob.LOB_DESC = ? ")
				.append(" and  mcbsf.MDPNL_ID = ? ")
				.append(" and mrf.INTRVL_MNTH_CNT = ? ");
			if (Constants.N.equals(request.getShowAll())) {
				query.append(" and mrf.INTRVL_MNTH_CNT in ("
					+ CommonQueries.getMctRetroInterval()
					+ " ) ");
			}

			query.append(" UNION ");

			query.append(" select distinct ")
				.append(" 35 as MTRC_CD ")
				.append(" ,'Medical Cost Target PMPM (Trended Baseline)' as MTRC_NM ")
				.append(" ,mrf.PHRMCY_IND ")
				.append(" ,mcbsf.PSL_ID ")
				.append(" ,null as PG_PROD_NBR ")
				.append(" ,mrf.MCT_TRNDD_PMPM_AMT as PROD_MDCL_NBR ")
				.append(" ,'N' as PG_IND ")
				.append(", mcbsf.DWNSD_RISK_IND ")
				.append(" from MCT_RETRO_FACT mrf join ")
				.append(" MCB_SMRY_FACT mcbsf on (" + getJoinsBetweenMCTandMCB() + ") ")
				.append(" join  LOB_DIM lob on (mcbsf.LOB_DIM_KEY = lob.LOB_DIM_KEY) ")
				.append(" where mcbsf.MSRMNT_PRD_STRT_DT = ? ")
				.append(" and  mcbsf.MSRMNT_PRD_END_DT = ? ")
				.append(" and  mcbsf.PROV_GRP_ID = ? ")
				.append(" and  mcbsf.PGM_ID = ? ")
				.append(" and  lob.LOB_DESC = ? ")
				.append(" and  mcbsf.MDPNL_ID = ? ")
				.append(" and mrf.INTRVL_MNTH_CNT = ? ");
			if (Constants.N.equals(request.getShowAll())) {
				query.append(" and mrf.INTRVL_MNTH_CNT in ("
					+ CommonQueries.getMctRetroInterval()
					+ " ) ");
			}



			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			prepareStatement(logger, query.toString());

			int i = 0;

			for (int j = 0; j < 5; j++) {
				ps.setString(++i, StringUtil.convertDate(request.getMeasurementPeriodStartDt()));
				ps.setString(++i, StringUtil.convertDate(request.getMeasurementPeriodEndDt()));
				//			ps.setString(++i, request.getFundingPool());
				ps.setString(++i, request.getProvGrpIds());
				ps.setString(++i, request.getProgramId());
				ps.setString(++i, request.getLobNm());
				ps.setString(++i, request.getMedicalPanelId());
				ps.setInt(++i, Integer.parseInt(request.getMeasurementInterval()));


			}

			executeQuery(logger, query.toString());

			while (rs.next()) {
				McbSmryDto mcbDto = new McbSmryDto();
				mcbDto.setMetricCd(rs.getString("MTRC_CD"));
				mcbDto.setMetricNm(rs.getString("MTRC_NM"));
				mcbDto.setPhrmcyInd(rs.getString("PHRMCY_IND"));
				mcbDto.setPslId(rs.getString("PSL_ID"));
				mcbDto.setPgProdNbr(rs.getBigDecimal("PG_PROD_NBR"));
				mcbDto.setProdMedNbr(rs.getBigDecimal("PROD_MDCL_NBR"));
				mcbDto.setPgInd(rs.getString("PG_IND"));
				mcbDto.setDwnsdRiskInd(rs.getString("DWNSD_RISK_IND"));
				resultList.add(mcbDto);
			}
		}
		catch (

		Exception e) {

			logger.error("Unable to get MCT Retrospective data.", e);
		}
		finally {

			close();
		}
		return resultList;
	}

	private String getJoinsBetweenMCTandMCB() {
		StringBuilder builder = new StringBuilder();
		builder.append(" mrf.MCT_RUN_RQST_ID = mcbsf.MCT_RUN_RQST_ID ")
			.append(" and  mrf.ACTV_IND = 'Y' ")
			.append(" and mcbsf.ACTV_IND = 'Y' ")
			.append(" and mcbsf.PHRMCY_IND = mrf.PHRMCY_IND ")
			.append(" and mcbsf.PSL_DIM_KEY = mrf.PSL_DIM_KEY ")
			.append(" and mcbsf.PGM_DIM_KEY = mrf.PGM_DIM_KEY ")
			.append(" and mcbsf.LOB_DIM_KEY = mrf.LOB_DIM_KEY ")
			.append(" and mcbsf.MDPNL_DIM_KEY = mrf.MDPNL_DIM_KEY ")
			.append(" and mcbsf.PROV_GRP_DIM_KEY = mrf.PROV_GRP_DIM_KEY ")
			.append(" and mcbsf.MSRMNT_PRD_STRT_DT = mrf.MSRMNT_PRD_STRT_DT ");
		return builder.toString();
	}

}
