package com.wellpoint.pc2dash.data.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.owasp.encoder.Encode;

import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.export.GetExportColumnsRequest;
import com.wellpoint.pc2dash.action.globalFilters.GetGlobalFilterDataAction;
import com.wellpoint.pc2dash.action.globalFilters.GetGlobalFilterDataRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.data.dto.AppProperty;
import com.wellpoint.pc2dash.data.dto.CareOppReportingPeriod;
import com.wellpoint.pc2dash.data.dto.PCMSRequest;
import com.wellpoint.pc2dash.data.dto.PopulationManagementRequest;
import com.wellpoint.pc2dash.data.dto.UserSessionInfo;
import com.wellpoint.pc2dash.dto.globalFilters.ProvGrpIdObj;
import com.wellpoint.pc2dash.dto.globalFilters.SubObjs;
import com.wellpoint.pc2dash.dto.savedFilters.Filter;
import com.wellpoint.pc2dash.dto.suppression.Suppression;
import com.wellpoint.pc2dash.dto.suppression.SuppressionBean;
import com.wellpoint.pc2dash.dto.tap.TapReportsBean;
import com.wellpoint.pc2dash.dto.tinNpi.UserAcsIndicators;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.savedFilters.SavedFiltersImpl;
import com.wellpoint.pc2dash.util.ApplicationConfig;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.DateUtil;
import com.wellpoint.pc2dash.util.JsonSerializer;
import com.wellpoint.pc2dash.util.QueryConstants;
import com.wellpoint.pc2dash.util.StringUtil;


public class AppProperties extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(AppProperties.class);
	private Suppression totalCostSuppression = new Suppression("totalCost");

	@Override
	public boolean read(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	@Override
	public void insert(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	@Override
	public void update(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	@Override
	public void delete(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	/**
	 * Get application property for given property owner and name.
	 * 
	 * @param ownerNm
	 * @param propNm
	 * @return
	 * @throws Exception
	 */
	public AppProperty getAppProperty(String ownerNm, String propNm) throws Exception {

		return getAppProperty(ownerNm, propNm, "ALL");
	}

	/**
	 * Get application property for given property owner, name, and group.
	 * 
	 * @param ownerNm
	 * @param propNm
	 * @param grpId
	 * @return
	 * @throws Exception
	 */
	public AppProperty getAppProperty(String ownerNm, String propNm, String grpId) throws Exception {

		AppProperty result = null;

		StringBuilder sql = new StringBuilder()
			.append("select ")
			.append("    p.aplctn_prpty_ownr_nm as prpty_ownr, ")
			.append("    p.aplctn_prpty_nm as prpty_nm, ")
			.append("    p.aplctn_prpty_val_txt as prpty_val ")
			.append("from ")
			.append("    aplctn_prpty p ")
			.append("where ")
			.append("    p.aplctn_prpty_ownr_nm = ? ")
			.append("    and p.aplctn_prpty_nm = ? ")
			//.append("    and p.prov_grp_id = ? ") // to cope up with new Admin UI, where prov_grp_id is being populated with guid
			.append("with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());
			ps.setString(1, ownerNm);
			ps.setString(2, propNm);
			//ps.setString(3, grpId);// to cope up with new Admin UI, where prov_grp_id is being populated with guid

			executeQuery(logger, sql.toString());

			if (rs.next()) {

				AppProperty r = new AppProperty();
				r.setOwner(getString(rs, "prpty_ownr"));
				r.setName(getString(rs, "prpty_nm"));

				// DF - 6472 - Sprint 10
				// Making exception for Pharmacy disclaimer
				// Did not change getString method as it is used application wide
				// Whenever disclaimer is a series of white spaces, then we send a blank value instead of default --- sent for other properties
				// Whenever disclaimer is null, then ---, i.e. default value of getString method is sent
				// * NOTE - Whenever default value in getSTring changes from ---, then the value returned when disclaimer is null should also be changed 
				//  		 in getPharmacyDisclaimerString to keep consistency.

				if (Constants.PHARMACY_CLASS_DISCLAIMER.equalsIgnoreCase(r.getName())
					|| Constants.PHARMACY_MEMBER_DISCLAIMER.equalsIgnoreCase(r.getName())
					|| Constants.PHARMACY_PROVIDER_DISCLAIMER.equalsIgnoreCase(r.getName())
					|| Constants.PHARMACY_SCRIPTS_DISCLAIMER.equalsIgnoreCase(r.getName())) {
					r.setValue(getPharmacyDisclaimerString(rs, "prpty_val"));
				}
				else {
					r.setValue(getString(rs, "prpty_val"));
				}

				result = r;
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get application property.", e);
		}
		finally {

			close();
		}

		return result;
	}

	public List<AppProperty> getAppPropertyWithOwnerNm(String ownerNm) throws Exception {

		List<AppProperty> result = new ArrayList<AppProperty>();

		StringBuilder sql = new StringBuilder()
			.append("select ")
			.append("    p.aplctn_prpty_ownr_nm as prpty_ownr, ")
			.append("    p.aplctn_prpty_nm as prpty_nm, ")
			.append("    p.aplctn_prpty_val_txt as prpty_val, ")
			.append("    p.cmnt_txt as cmnt_txt ")
			.append("from ")
			.append("    aplctn_prpty p ")
			.append("where ")
			.append("    p.aplctn_prpty_ownr_nm = ? ")
			.append("with ur ");

		try {
			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());
			ps.setString(1, ownerNm);

			executeQuery(logger, sql.toString());

			while (rs.next()) {

				AppProperty r = new AppProperty();
				r.setValue(getString(rs, "prpty_val"));
				r.setComment(getString(rs, "cmnt_txt"));

				result.add(r);
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get application property.", e);
		}
		finally {

			close();
		}

		return result;
	}


	/**
	 * Get application configuration properties for specified group.
	 * 
	 * @param grpId
	 * @return
	 * @throws Exception
	 */
	public Collection<AppProperty> getAppConfig(String grpId) throws Exception {

		Collection<AppProperty> result = new ArrayList<AppProperty>();

		StringBuilder sql = new StringBuilder()
			.append("select ")
			.append("    p.aplctn_prpty_ownr_nm as prpty_ownr, ")
			.append("    p.aplctn_prpty_nm as prpty_nm, ")
			.append("    coalesce(gp.aplctn_prpty_val_txt, p.aplctn_prpty_val_txt) as prpty_val ")
			.append("from ")
			.append("    aplctn_prpty p ")
			.append("    left join ( ")
			.append("        select ")
			.append("            aplctn_prpty_ownr_nm, ")
			.append("            aplctn_prpty_nm, ")
			.append("            aplctn_prpty_val_txt ")
			.append("        from ")
			.append("            aplctn_prpty ")
			.append("        where ")
			.append("            aplctn_prpty_ownr_nm in ('UI_CONFIG','MW_CONFIG','SYS_CONFIG') ")
			.append("            and prov_grp_id = ? ")
			.append("    ) gp on ( ")
			.append("        p.aplctn_prpty_ownr_nm = gp.aplctn_prpty_ownr_nm ")
			.append("        and p.aplctn_prpty_nm = gp.aplctn_prpty_nm ")
			.append("    ) ")
			.append("where ")
			.append("    p.aplctn_prpty_ownr_nm in ('UI_CONFIG','MW_CONFIG','SYS_CONFIG') ")
			//			.append("    and p.prov_grp_id = 'ALL' ")
			.append("union all ")
			.append("select ")
			.append("    'UI_CONFIG' as prpty_ownr, ")
			.append("    'reportDate' as prpty_nm, ")
			.append("    varchar_format(max(sor_dtm), 'mm/dd/yyyy') as prpty_val ")
			.append("from ")
			.append("    glbl_fltr_smry_fact ")
			.append("order by ")
			.append("    prpty_nm ")
			.append("with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());
			ps.setString(1, grpId);

			executeQuery(logger, sql.toString());

			while (rs.next()) {

				AppProperty r = new AppProperty();
				r.setOwner(getString(rs, "prpty_ownr"));
				r.setName(getString(rs, "prpty_nm"));

				// DF - 6472 - Sprint 10
				// Making exception for Pharmacy disclaimer
				// Did not change getString method as it is used application wide
				// Whenever disclaimer is a series of white spaces, then we send a blank value instead of default --- sent for other properties
				// Whenever disclaimer is null, then ---, i.e. default value of getString method is sent
				// * NOTE - Whenever default value in getSTring changes from ---, then the value returned when disclaimer is null should also be changed 
				//  		 in getPharmacyDisclaimerString to keep consistency.

				if (Constants.PHARMACY_CLASS_DISCLAIMER.equalsIgnoreCase(r.getName())
					|| Constants.PHARMACY_MEMBER_DISCLAIMER.equalsIgnoreCase(r.getName())
					|| Constants.PHARMACY_PROVIDER_DISCLAIMER.equalsIgnoreCase(r.getName())
					|| Constants.PHARMACY_SCRIPTS_DISCLAIMER.equalsIgnoreCase(r.getName())) {
					r.setValue(getPharmacyDisclaimerString(rs, "prpty_val"));
				}
				else {
					r.setValue(getString(rs, "prpty_val"));
				}

				result.add(r);
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get user interface config.", e);
		}
		finally {

			close();
		}

		return result;
	}

	/**
	 * Get component configuration for specified group.
	 * 
	 * @param usi, sesnId, entId
	 * @return Collection<AppComponent>
	 * @throws Exception
	 */
	public Collection<SuppressionBean> getComponentConfig(String sesnId, String entId) throws Exception {

		Collection<SuppressionBean> result = new ArrayList<SuppressionBean>();

		// Component Suppression
		StringBuilder sql = buildComponentSuppressionQuery();

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());
			int i = 0;
			ps.setString(++i, entId);
			ps.setString(++i, sesnId);

			executeQuery(logger, sql.toString());

			while (rs.next()) {

				SuppressionBean r = buildComponentSuppressionBean();

				result.add(r);
			}

		}
		catch (Exception e) {

			throw new Exception("Unable to get page config.", e);
		}
		finally {

			close();
		}

		return result;
	}

	/**
	 * Get column configuration for specified group.
	 * 1.8: Select lob_nm (even if it's null) to use with the Total Cost suppression logic.
	 * 
	 * @param usi, sesnId, entId
	 * @return Collection<AppComponent>
	 * @throws Exception
	 */
	public Collection<SuppressionBean> getColumnComponentConfig(PCMSRequest request) throws Exception {

		Collection<SuppressionBean> result = new ArrayList<SuppressionBean>();

		// Column Suppression
		StringBuilder sql = buildColumnSuppressionQuery();

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());
			int i = 0;
			ps.setString(++i, request.getEntitlementId());
			ps.setString(++i, request.getSessionId());
			ps.setString(++i, request.getCmpId());

			executeQuery(logger, sql.toString());

			while (rs.next()) {

				SuppressionBean r = buildColumnSuppressionBean();

				result.add(r);
			}

		}
		catch (Exception e) {

			throw new Exception("Unable to get page config.", e);
		}
		finally {

			close();
		}

		// 1.8: Avoid too much hardcoding when deciding on Total Cost suppression,
		// for which we have to pass UI a special component to satisfy all
		// business requirements.		
		// 1.92: In multi-GRP/PGM/LOB scenarios, rely solely on data suppression for columns;
		// which means remove the suppressed column from the list we're passing to UI.
		adjustMultiPrecedenceSuppression(request.getUserAcsInfoJson(), result);

		Set<SuppressionBean> resultSet = new HashSet<SuppressionBean>(result);

		return resultSet;
	}

	protected SuppressionBean buildComponentSuppressionBean() throws Exception, SQLException {
		SuppressionBean r = new SuppressionBean();
		r.setName(getString(rs, "cmp_nm"));
		r.setClassification(getString(rs, "cmp_class"));
		r.setStatus(getString(rs, "cmp_stts"));
		r.setMessage(getString(rs, "cmp_msg"));
		r.setRestrictedStatus("hidden"); // 2.0: hidden, not destroy anymore
		// using rs.getString to preserve the nulls for upcoming logic
		r.setLob(rs.getString("lob_nm"));
		return r;
	}

	protected SuppressionBean buildColumnSuppressionBean() throws Exception, SQLException {
		SuppressionBean r = new SuppressionBean();
		r.setName(getString(rs, "cmp_nm"));
		r.setClassification(getString(rs, "cmp_class"));
		r.setStatus(getString(rs, "cmp_stts"));
		r.setMessage(getString(rs, "cmp_msg"));
		r.setRestrictedStatus("hidden"); // 2.0: hidden, not destroy anymore
		// using rs.getString to preserve the nulls for upcoming logic
		r.setLob(rs.getString("lob_nm"));
		r.setProvGrpId(rs.getString("prov_grp_id"));
		r.setMarket(rs.getString("mrkt_nm"));
		r.setProgram(rs.getString("pgm_id"));
		return r;
	}

	/**
	 * Doesn't include b.prov_grp_id, b.all_id, b.mrkt_nm, b.pgm_id, b.precedence,
	 * since those are only necessary for column suppression, and result in invalid
	 * non-column component suppression entries being returned.
	 */
	protected StringBuilder buildComponentSuppressionQuery() {
		StringBuilder sql =
			new StringBuilder()
				.append("select  ")
				.append("    b.cmpnt_id as cmp_nm,  ")
				.append("    b.cmpnt_scrty_lvl_desc as cmp_class,  ")
				.append("    case  ")
				.append("        when min(b.cmp_display) = 0 then 'normal'  ")
				.append("        when max(b.cmp_stts) = 'normal' then 'normal'  ")
				.append("        when max(b.cmp_stts) = 'disabled' then 'disabled'  ")
				.append("        when max(b.cmp_stts) = 'html' then 'html'  ")
				.append("        when min(b.cmp_stts) <> max(b.cmp_stts) then 'destroy'  ")
				.append("        else min(b.cmp_stts)  ")
				.append("    end as cmp_stts, ")
				.append("    cast(coalesce (min(b.cmp_msg), '*') as varchar(500)) as cmp_msg, ")
				.append("    b.lob_nm ")
				.append("from   ")
				.append("(  ")
				.append("    select  ")
				.append("        c.prov_grp_id,  ")
				.append("        c.cmpnt_id,  ")
				.append("        c.cmpnt_scrty_lvl_desc,  ")
				.append("        case  ")
				.append("            when  ")
				.append("                coalesce(gs.st_mw_txt, ms.st_mw_txt, pgm_s.st_mw_txt, lob_s.st_mw_txt, app_s.st_mw_txt, 'normal') = 'normal'  ")
				.append("            then 0  ")
				.append("            else 1  ")
				.append("        end as cmp_display,  ")
				.append(
					QueryConstants
						.buildPrecedenceCaseStatement("cust_msg_desc", "cmp_msg",
							"when gs.st_mw_txt is null and ms.st_mw_txt is null and pgm_s.st_mw_txt is null and lob_s.st_mw_txt is null and app_s.st_mw_txt is null  then c.cmpnt_lvl_cust_msg_txt"))
				.append(", ")
				.append(QueryConstants.buildPrecedenceCaseStatement("st_mw_txt", "cmp_stts", ""))
				.append(", lob_s.lob_nm ")
				.append("    from  ")
				.append("        (  ")
				.append("            select  ")
				.append("                pusa.brnd_cd,  ")
				.append("                pusa.prov_grp_id,  ")
				.append("                sc.cmpnt_id,  ")
				.append("                sc.cmpnt_parnt_id,  ")
				.append("                sc.cmpnt_scrty_lvl_desc,  ")
				.append("                sc.cmpnt_lvl_cust_msg_txt  ")
				.append("            from  ")
				.append("                poit_user_scrty_acs pusa  ")
				.append("                join sprsn_cmpnt sc on (1 = 1)  ")
				.append("            where  ")
				.append("                pusa.enttlmnt_hash_key = ? ")
				.append("                and  pusa.sesn_id = ? ")
				.append("                and sc.cmpnt_parnt_id not like '%gridpanel' ")
				// non-column
				.append("            group by  ")
				.append("                pusa.brnd_cd,  ")
				.append("                pusa.prov_grp_id,  ")
				.append("                sc.cmpnt_id,  ")
				.append("                sc.cmpnt_parnt_id,  ")
				.append("                sc.cmpnt_scrty_lvl_desc,  ")
				.append("                sc.cmpnt_lvl_cust_msg_txt  ")
				.append("        ) c  ")
				.append(
					"    left join sprsn gs on (c.cmpnt_id = gs.cmpnt_id and gs.prov_grp_id = c.prov_grp_id and gs.prov_grp_id <> 'ALL' and gs.msrmnt_prd_strt_dt is null and gs.msrmnt_intrvl_cd is null) ")
				.append("    left join sprsn ms on (c.cmpnt_id = ms.cmpnt_id and ms.mrkt_nm = c.brnd_cd and ms.msrmnt_prd_strt_dt is null and ms.msrmnt_intrvl_cd is null) ")
				.append(
					"    left join sprsn pgm_s on ((c.cmpnt_id = pgm_s.cmpnt_id and pgm_s.pgm_id is not null and pgm_s.pgm_id != '' and pgm_s.msrmnt_prd_strt_dt is null and pgm_s.msrmnt_intrvl_cd is null) ")
				.append("        and   ")
				.append("        (  ")
				//				.append("            (c.cmpnt_parnt_id like '%gridpanel' and ") // PCMSP-7703: Commented out line, including "and"
				.append("            ((pgm_s.prov_grp_id = 'ALL' or pgm_s.prov_grp_id is null)  ") // PCMSP-7703: Added ( to compensate for commented out line above
				.append("            and exists (select 1 from prov_grp_pgm_lob_fact pgplf  ")
				.append("                    where c.prov_grp_id = pgplf.prov_grp_id  ")
				.append("                    and pgm_s.pgm_id = pgplf.pgm_id)  ")
				.append("            )  ")
				.append("        )  ")
				.append("    )  ")
				.append(
					"    left join sprsn lob_s on ((c.cmpnt_id = lob_s.cmpnt_id and lob_s.lob_nm is not null and lob_s.lob_nm != '' and lob_s.msrmnt_prd_strt_dt is null and lob_s.msrmnt_intrvl_cd is null) ")
				.append("        and   ")
				.append("        (  ")
				//				.append("            (c.cmpnt_parnt_id like '%gridpanel' and ") // PCMSP-7703: Commented out line, including "and"
				.append("            ((lob_s.prov_grp_id = 'ALL' or lob_s.prov_grp_id is null)  ") // PCMSP-7703: Added ( to compensate for commented out line above
				.append("            and exists (select 1 from glbl_fltr_smry_fact gfsf ")
				// switched to gfsf from pgplf due to the two often being out of sync, and issues with voided LOBs in pgplf
				.append("                    join lob_dim ld on (gfsf.lob_dim_key = ld.lob_dim_key) ")
				.append("                    join prov_grp_dim pgd on (gfsf.prov_grp_dim_key = pgd.prov_grp_dim_key) ")
				.append("                    where c.prov_grp_id = pgd.prov_grp_id  ")
				//		.append("            and exists (select 1 from prov_grp_pgm_lob_fact pgplf  ") 
				//		.append("                    join lob_dim ld on (pgplf.lob_dim_key = ld.lob_dim_key) ")
				//		.append("                    where c.prov_grp_id = pgplf.prov_grp_id  ")
				.append("                    and lob_s.lob_nm = ld.lob_ctgry_nm)  ")
				.append("            )  ")
				.append("        )  ")
				.append("    )  ")
				.append(
					"    left join sprsn app_s on (c.cmpnt_id = app_s.cmpnt_id and app_s.prov_grp_id = 'ALL' and app_s.msrmnt_prd_strt_dt is null and app_s.msrmnt_intrvl_cd is null)  ")
				.append(") b  ")
				.append("where b.cmp_stts is not null  ")
				.append("group by  ")
				.append("    b.cmpnt_id,  ")
				.append("    b.cmpnt_scrty_lvl_desc, ")
				.append("    b.lob_nm ")
				.append("with ur ");
		return sql;
	}

	protected StringBuilder buildColumnSuppressionQuery() {
		StringBuilder sql =
			new StringBuilder()
				.append("select distinct ")
				.append("    b.cmpnt_id as cmp_nm,  ")
				.append("    b.cmpnt_scrty_lvl_desc as cmp_class,  ")
				.append("    case  ")
				.append("        when min(b.cmp_display) = 0 then 'normal'  ")
				.append("        when max(b.cmp_stts) = 'normal' then 'normal'  ")
				.append("        when max(b.cmp_stts) = 'disabled' then 'disabled'  ")
				.append("        when max(b.cmp_stts) = 'html' then 'html'  ")
				.append("        when min(b.cmp_stts) <> max(b.cmp_stts) then 'destroy'  ")
				.append("        else min(b.cmp_stts)  ")
				.append("    end as cmp_stts, ")
				.append("    cast(coalesce (min(b.cmp_msg), '*') as varchar(500)) as cmp_msg, ")
				.append("    b.lob_nm, ")
				.append("    case ")
				.append("        when b.precedence = 'grp' ")
				.append("        then coalesce (b.all_id, b.prov_grp_id) ")
				.append("        else null ")
				.append("    end  as prov_grp_id, ")
				.append("    b.mrkt_nm, ")
				.append("    b.pgm_id, ")
				.append("    b.precedence ")
				.append("from   ")
				.append("(  ")
				.append("    select  ")
				.append("        c.prov_grp_id,  ")
				.append("        c.cmpnt_id,  ")
				.append("        c.cmpnt_scrty_lvl_desc,  ")
				.append("        case  ")
				.append("            when  ")
				.append("                coalesce(gs.st_mw_txt, ms.st_mw_txt, pgm_s.st_mw_txt, lob_s.st_mw_txt, app_s.st_mw_txt, 'normal') = 'normal'  ")
				.append("            then 0  ")
				.append("            else 1  ")
				.append("        end as cmp_display,  ")
				.append(
					QueryConstants
						.buildPrecedenceCaseStatement("cust_msg_desc", "cmp_msg",
							"when gs.st_mw_txt is null and ms.st_mw_txt is null and pgm_s.st_mw_txt is null and lob_s.st_mw_txt is null and app_s.st_mw_txt is null  then c.cmpnt_lvl_cust_msg_txt"))
				.append(", ")
				.append(QueryConstants.buildPrecedenceCaseStatement("st_mw_txt", "cmp_stts", ""))
				.append(", lob_s.lob_nm ")
				.append(", ms.mrkt_nm ")
				.append(", pgm_s.pgm_id ")
				.append(", app_s.prov_grp_id as all_id ")
				.append(", case  ")
				.append("    when gs.st_mw_txt is not null  ")
				.append("      then 'grp'  ")
				.append("    when gs.st_mw_txt is null and ms.st_mw_txt is not null  ")
				.append("      then 'mkt'  ")
				.append("    when gs.st_mw_txt is null and ms.st_mw_txt is null and pgm_s.st_mw_txt is not null  ")
				.append("      then 'pgm'  ")
				.append("    when gs.st_mw_txt is null and ms.st_mw_txt is null and pgm_s.st_mw_txt is null and lob_s.st_mw_txt is not null  ")
				.append("      then 'lob'  ")
				.append("    when gs.st_mw_txt is null and ms.st_mw_txt is null and pgm_s.st_mw_txt is null and lob_s.st_mw_txt is null and app_s.st_mw_txt is not null  ")
				.append("      then 'all'  ")
				.append(" end as precedence ")
				.append("    from  ")
				.append("        (  ")
				.append("            select  ")
				.append("                pusa.brnd_cd,  ")
				.append("                pusa.prov_grp_id,  ")
				.append("                sc.cmpnt_id,  ")
				.append("                sc.cmpnt_parnt_id,  ")
				.append("                sc.cmpnt_scrty_lvl_desc,  ")
				.append("                sc.cmpnt_lvl_cust_msg_txt  ")
				.append("            from  ")
				.append("                poit_user_scrty_acs pusa  ")
				.append("                join sprsn_cmpnt sc on (1 = 1)  ")
				.append("            where  ")
				.append("                pusa.enttlmnt_hash_key = ? ")
				.append("                and  pusa.sesn_id = ? ")
				.append("                and sc.cmpnt_parnt_id = ? ")
				// only columns from this grid
				.append("            group by  ")
				.append("                pusa.brnd_cd,  ")
				.append("                pusa.prov_grp_id,  ")
				.append("                sc.cmpnt_id,  ")
				.append("                sc.cmpnt_parnt_id,  ")
				.append("                sc.cmpnt_scrty_lvl_desc,  ")
				.append("                sc.cmpnt_lvl_cust_msg_txt  ")
				.append("        ) c  ")
				.append(
					"    left join sprsn gs on (c.cmpnt_id = gs.cmpnt_id and gs.prov_grp_id = c.prov_grp_id and gs.prov_grp_id <> 'ALL' and gs.msrmnt_prd_strt_dt is null and gs.msrmnt_intrvl_cd is null) ")
				.append("    left join sprsn ms on (c.cmpnt_id = ms.cmpnt_id and ms.mrkt_nm = c.brnd_cd and ms.msrmnt_prd_strt_dt is null and ms.msrmnt_intrvl_cd is null) ")
				.append(
					"    left join sprsn pgm_s on ((c.cmpnt_id = pgm_s.cmpnt_id and pgm_s.pgm_id is not null and pgm_s.pgm_id != '' and pgm_s.msrmnt_prd_strt_dt is null and pgm_s.msrmnt_intrvl_cd is null) ")
				.append("        and   ")
				.append("        (  ")
				.append("            ((pgm_s.prov_grp_id = 'ALL' or pgm_s.prov_grp_id is null)  ")
				.append("            and exists (select 1 from prov_grp_pgm_lob_fact pgplf  ")
				.append("                    where c.prov_grp_id = pgplf.prov_grp_id  ")
				.append("                    and pgm_s.pgm_id = pgplf.pgm_id)  ")
				.append("            )  ")
				.append("        )  ")
				.append("    )  ")
				.append(
					"    left join sprsn lob_s on ((c.cmpnt_id = lob_s.cmpnt_id and lob_s.lob_nm is not null and lob_s.lob_nm != '' and lob_s.msrmnt_prd_strt_dt is null and lob_s.msrmnt_intrvl_cd is null) ")
				.append("        and   ")
				.append("        (  ")
				.append("            ((lob_s.prov_grp_id = 'ALL' or lob_s.prov_grp_id is null)  ")
				.append("            and exists (select 1 from glbl_fltr_smry_fact gfsf ")
				// switched to gfsf from pgplf due to the two often being out of sync, and issues with voided LOBs in pgplf
				.append("                    join lob_dim ld on (gfsf.lob_dim_key = ld.lob_dim_key) ")
				.append("                    join prov_grp_dim pgd on (gfsf.prov_grp_dim_key = pgd.prov_grp_dim_key) ")
				.append("                    where c.prov_grp_id = pgd.prov_grp_id  ")
				//		.append("            and exists (select 1 from prov_grp_pgm_lob_fact pgplf  ") 
				//		.append("                    join lob_dim ld on (pgplf.lob_dim_key = ld.lob_dim_key) ")
				//		.append("                    where c.prov_grp_id = pgplf.prov_grp_id  ")
				.append("                    and lob_s.lob_nm = ld.lob_ctgry_nm)  ")
				.append("            )  ")
				.append("        )  ")
				.append("    )  ")
				.append(
					"    left join sprsn app_s on (c.cmpnt_id = app_s.cmpnt_id and app_s.prov_grp_id = 'ALL' and app_s.msrmnt_prd_strt_dt is null and app_s.msrmnt_intrvl_cd is null)  ")
				.append(") b  ")
				.append("where b.cmp_stts is not null  ")
				.append("group by  ")
				.append("    b.cmpnt_id,  ")
				.append("    b.cmpnt_scrty_lvl_desc, ")
				.append("    b.lob_nm, ")
				.append("    b.prov_grp_id, ")
				.append("    b.all_id, ")
				.append("    b.mrkt_nm, ")
				.append("    b.pgm_id, ")
				.append("    b.precedence ")
				.append("with ur ");
		return sql;
	}

	protected void adjustMultiPrecedenceSuppression(List<UserAcsIndicators> uaiList, Collection<SuppressionBean> result) throws Exception {
		Suppression global = getGlobalFilterValues(uaiList);

		// If a column was suppressed, but not for all GRP/MKT/PGM/LOB in the Global Filter, remove the column from the list.
		// Business wants to rely solely on data suppression in these situations.
		// Determine for which GRP/MKT/PGM/LOBs, for later comparison against Global Filter GRP/MKT/PGM/LOBs.
		for (Iterator<SuppressionBean> iterator = result.iterator(); iterator.hasNext();) {
			SuppressionBean c = iterator.next();
			if (c.getName().contains("gridpanel-") && !c.getStatus().equalsIgnoreCase("normal") && !"ALL".equalsIgnoreCase(c.getProvGrpId())) {

				Suppression columnSuppression = new Suppression(c.getName());

				// Take GRP/MKT/PGM/LOB precedence into account
				if (StringUtils.isNotBlank(c.getProvGrpId())) {
					columnSuppression.getSuppressedGRPs().add(c.getProvGrpId());

				}
				else if (StringUtils.isNotBlank(c.getMarket())) {
					columnSuppression.getSuppressedMKT().add(c.getMarket().substring(0, 2));

				}
				else if (StringUtils.isNotBlank(c.getProgram())) {
					columnSuppression.getSuppressedPGMs().add(c.getProgram());

				}
				else if (StringUtils.isNotBlank(c.getLob())) {
					columnSuppression.getSuppressedLOBs().add(c.getLob());

				}

				// Only proceed if suppression exists 
				if (!columnSuppression.getSuppressedLOBs().isEmpty()
					|| !columnSuppression.getSuppressedGRPs().isEmpty()
					|| !columnSuppression.getSuppressedMKT().isEmpty()
					|| !columnSuppression.getSuppressedPGMs().isEmpty()) {

					// Compare Admin GRP/MKT/PGM/LOBs and Global Filter GRP/MKT/PGM/LOBs. If any of them match exactly, tell UI to suppress Total Cost
					// using the agreed-upon component name/status.
					// 266112: Bring Total Cost in line with the requirements in Lauren's table from 11/1/2016.
					if (c.getName().endsWith("totalCost") && c.getStatus().equalsIgnoreCase("destroy")) {
						if ((global.getSuppressedLOBs().size() == 1 && columnSuppression.getSuppressedLOBs().equals(global.getSuppressedLOBs()))
							|| (global.getSuppressedGRPs().size() == 1 && columnSuppression.getSuppressedGRPs().equals(global.getSuppressedGRPs()))
							|| (global.getSuppressedMKT().size() == 1 && columnSuppression.getSuppressedMKT().equals(global.getSuppressedMKT()))
							|| (global.getSuppressedPGMs().size() == 1 && columnSuppression.getSuppressedPGMs().equals(global.getSuppressedPGMs()))) {

							// Set the component status to normal so that the trigger we're using for Total Cost suppression 
							// via Admin UI (Total Cost Column) doesn't override the logic we're applying below.
							//c.setStatus("normal");
							result.remove(c);

							// Add the agreed-upon component we're including for UI
							SuppressionBean b = new SuppressionBean();
							b.setName(c.getName());
							b.setClassification("CLINICAL");
							b.setStatus("destroy");
							b.setMessage("---");
							b.setRestrictedStatus("hidden"); // 2.0: hidden, not destroy anymore				
							result.add(b);

							iterator = result.iterator(); // avoid ConcurrentModificationException after calling .add()
						}

					}
					// Apply the logic below to all columns in a multi-precedence scenario - even Total Cost
					// Only delve deeper if the precedence in question has multiple values in the Global Filter
					// and not all available values of a certain precedence are suppressed
					// (and the precedence in question has suppression applied at its level)
					if (!columnSuppression.getSuppressedLOBs().isEmpty()
						&& (global.getSuppressedLOBs().size() > 1 && !columnSuppression.getSuppressedLOBs().equals(global.getSuppressedLOBs()))
						|| (!columnSuppression.getSuppressedGRPs().isEmpty() && global.getSuppressedGRPs().size() > 1 && !columnSuppression.getSuppressedGRPs().equals(
							global.getSuppressedGRPs()))
						|| (!columnSuppression.getSuppressedMKT().isEmpty() && global.getSuppressedMKT().size() > 1 && !columnSuppression.getSuppressedMKT().equals(
							global.getSuppressedMKT()))
						|| (!columnSuppression.getSuppressedPGMs().isEmpty() && global.getSuppressedPGMs().size() > 1 && !columnSuppression.getSuppressedPGMs().equals(
							global.getSuppressedPGMs()))) {

						// Set the component status to normal so that the column shows up as Tier 1,
						// so that MW can apply data-level suppression in relevant members' rows.
						// Note that data-level suppression requires specific MW code, and is currently only written for
						// HCC Risk Score and Total Cost columns.
						c.setStatus("normal");
					}
				}
			}
		}
	}

	/**
	 * In the case of Global Filters, Suppression is a bit of a misnomer,
	 * since we'll actually be storing GRP/MKT/LOB/PGM values that exist
	 * in the Global Filters;
	 * but the class provides a way for us to store Set<String>s that we
	 * need to reference to compare with a component's suppression settings.
	 * 
	 * @param uaiList
	 * @return Suppression
	 */
	public Suppression getGlobalFilterValues(List<UserAcsIndicators> uaiList) {
		// 263259: Column suppression logic update
		List list = getGlobalFilterDataList(uaiList);

		Suppression global = new Suppression("global");
		Set<String> lobsGlobal = new HashSet<String>();
		Set<String> grpsGlobal = new HashSet<String>();
		Set<String> mktsGlobal = new HashSet<String>();
		Set<String> pgmsGlobal = new HashSet<String>();

		for (Object o : list) {
			if (o instanceof SubObjs &&
				((SubObjs) o).getType().equalsIgnoreCase("lobId")) {
				// Roll up the text to Commercial, Medicaid, or Medicare; per the Business.
				lobsGlobal.add(((SubObjs) o).getLobCtgryNm());

			}
			else if (o instanceof ProvGrpIdObj &&
				((ProvGrpIdObj) o).getType().equalsIgnoreCase("provGrpId")) {
				String grp = ((ProvGrpIdObj) o).getValue();
				grpsGlobal.add(grp);
				mktsGlobal.add(grp.substring(0, 2)); // MKT isn't stored in global filters; glean it from GRP

			}
			else if (o instanceof SubObjs &&
				((SubObjs) o).getType().equalsIgnoreCase("programId")) {
				pgmsGlobal.add(((SubObjs) o).getDesc()); // So that we won't need programIds or pgmIdToPgmDimKeyMap
			}
		}

		global.setSuppressedLOBs(lobsGlobal);
		global.setSuppressedGRPs(grpsGlobal);
		global.setSuppressedMKT(mktsGlobal);
		global.setSuppressedPGMs(pgmsGlobal);
		return global;
	}

	protected List getGlobalFilterDataList(List<UserAcsIndicators> uaiList) {
		// Gather Global Filter LOBs - reuse Global Filter code without touching it (since it'll all change with the rewrite).
		GetGlobalFilterDataRequest request = new GetGlobalFilterDataRequest();
		request.setUserAcsInfoJson(uaiList);
		request.setCmpId("gl-populationmanagementpanel");

		GetGlobalFilterDataAction action = new GetGlobalFilterDataAction();
		ActionResponse response = action.process(request);
		List list = (List) response.getData();
		return list;
	}

	/*
	 * Method added for getting the reporting period for the care opps page. For
	 * release 1.4. the reporting period string will be in the global context of
	 * the web app.
	 */
	public String getReportingPeriodForPopMgnt(String entId)
		throws ParseException {

		List<CareOppReportingPeriod> reportingPeriodList = new ArrayList<CareOppReportingPeriod>();

		String sql = "SELECT DISTINCT LOB.LOB_CTGRY_NM, COF.ANLYSS_AS_OF_DT "
			/** R1.92 | CY Scorecard | AC94408 | Start **/
			+ " ,UPPER(COF.MSR_TYPE_CD) as MSR_TYPE_CD "
			/** R1.92 | CY Scorecard | AC94408 | End **/
			+ " FROM PROV_GRP_DIM PGD "
			+ " JOIN CARE_OPRTNTY_FACT COF ON COF.PROV_GRP_DIM_KEY = PGD.PROV_GRP_DIM_KEY "
			+ " JOIN LOB_DIM LOB ON LOB.LOB_DIM_KEY = COF.LOB_DIM_KEY "
			// Changes by LO to make reporting period dynamic
			+ " JOIN POIT_USER_SCRTY_ACS PUSA ON PUSA.PROV_GRP_ID = PGD.PROV_GRP_ID "
			+ " WHERE PUSA.ENTTLMNT_HASH_KEY = ?  "
			+ " group by LOB.LOB_CTGRY_NM, COF.ANLYSS_AS_OF_DT, COF.MSR_TYPE_CD "
			+ " ORDER BY LOB_CTGRY_NM";
		// End of LO Changes
		try {
			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			prepareStatement(logger, sql);
			ps.setString(1, entId);

			executeQuery(logger, sql);

			while (rs.next()) {
				String lobNm = rs.getString("LOB_CTGRY_NM").toLowerCase();
				String aaod = rs.getString("ANLYSS_AS_OF_DT");
				/** R1.92 | CY Scorecard | AC94408 | Start **/
				String msrTypeCd = rs.getString("MSR_TYPE_CD");

				CareOppReportingPeriod careOppReportingPeriod = new CareOppReportingPeriod();
				careOppReportingPeriod.setLobNm(lobNm);
				careOppReportingPeriod.setAaod(aaod);
				careOppReportingPeriod.setMsrTypeCd(msrTypeCd);

				reportingPeriodList.add(careOppReportingPeriod);
				//lobAaodMap.put(lobNm+Constants.HASH+msrTypeCd, aaod);
				/** R1.92 | CY Scorecard | AC94408 | End **/
			}

		}
		catch (SQLException e) {
			logger.error("SQL Exception occurred: ", e);
		}
		catch (Exception e) {
			logger.error("Exception occurred: ", e);
		}
		finally {

			close();
		}

		return calculateReportingPeriod(reportingPeriodList);



	}


	/**
	 * Introduced by LO
	 * Method to creating reporting period based on the provider groups selected in global filter.
	 * 
	 * @param request
	 * @return
	 * @throws ParseException
	 */
	public String getReportingPeriodForCareOpp(PopulationManagementRequest request)
		throws ParseException {

		List<CareOppReportingPeriod> reportingPeriodList = new ArrayList<CareOppReportingPeriod>();

		String sql = "select  LOB.LOB_CTGRY_NM, COF.ANLYSS_AS_OF_DT "
			/** R1.92 | CY Scorecard | AC94408 | Start **/
			+ " ,UPPER(COF.MSR_TYPE_CD) as MSR_TYPE_CD "
			/** R1.92 | CY Scorecard | AC94408 | End **/
			+ " from  PROV_GRP_DIM PGD "
			+ " JOIN CARE_OPRTNTY_FACT COF ON COF.PROV_GRP_DIM_KEY = PGD.PROV_GRP_DIM_KEY "
			+ " JOIN LOB_DIM LOB ON LOB.LOB_DIM_KEY = COF.LOB_DIM_KEY "
			//+ " JOIN POIT_USER_SCRTY_ACS PUSA ON PUSA.PROV_GRP_ID = PGD.PROV_GRP_ID " // Commenting as this join it is not necessary
			+ " WHERE PGD.PROV_GRP_ID IN ("
			+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvGrpIds())
			+ ") "
			+ " and LOB.lob_desc IN ("
			+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getLobIds())
			+ ") "

			+ " group by LOB.LOB_CTGRY_NM, COF.ANLYSS_AS_OF_DT, COF.MSR_TYPE_CD "
			+ " ORDER BY LOB_CTGRY_NM";

		try {
			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			prepareStatement(logger, sql);
			//ps.setString(1, entId);
			// POIT clause
			int i = 0;
			if (StringUtil.isNotBlankOrFalse(request.getProvGrpIds())) {
				String[] array = request.getProvGrpIds().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}
			if (StringUtil.isNotBlankOrFalse(request.getLobIds())) {
				String[] array = request.getLobIds().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			} //

			executeQuery(logger, sql.toString());
			while (rs.next()) {
				String lobNm = rs.getString("LOB_CTGRY_NM").toLowerCase();
				String aaod = rs.getString("ANLYSS_AS_OF_DT");
				/** R1.92 | CY Scorecard | AC94408 | Start **/
				String msrTypeCd = rs.getString("MSR_TYPE_CD");

				CareOppReportingPeriod careOppReportingPeriod = new CareOppReportingPeriod();
				careOppReportingPeriod.setLobNm(lobNm);
				careOppReportingPeriod.setAaod(aaod);
				careOppReportingPeriod.setMsrTypeCd(msrTypeCd);

				reportingPeriodList.add(careOppReportingPeriod);
				//lobAaodMap.put(lobNm+Constants.HASH+msrTypeCd, aaod);
				/** R1.92 | CY Scorecard | AC94408 | End **/
			}

		}
		catch (SQLException e) {
			logger.error(e);
		}
		catch (Exception e) {
			logger.error(e);
		}
		finally {

			close();
		}

		return calculateReportingPeriod(reportingPeriodList);
	}

	//Introduced by LO
	//Logic to calculate reporting period from getReportingPeriodForPopMgnt is moved to a separate method to reuse
	private String calculateReportingPeriod(List<CareOppReportingPeriod> reportingPeriodList)
		throws ParseException {
		StringBuilder repPrd = new StringBuilder();// repPrd is the
		// stringBuilder object
		// which will be used to
		// generate the entire
		// reporting period string.

		/**
		 * R1.92 | changing design for reporting period
		 * 
		 * @author AC94408
		 */
		boolean isCommercialOrMedicare = false;

		GregorianCalendar calendar = new GregorianCalendar();
		boolean hasRhi = false;// PCMSP-22286 - Indicator to identify if RHI reporting period has been added in UI
		for (CareOppReportingPeriod careOppReportingPeriod : reportingPeriodList) {
			if(repPrd.length() > 0){
				repPrd.append("<br/>");
			}
			String lobNm = careOppReportingPeriod.getLobNm().trim();
			String aaod = careOppReportingPeriod.getAaod().trim();
			String msrTypeCd = careOppReportingPeriod.getMsrTypeCd().trim();

			Date paidThru = DateUtil.stringToDate("yyyy-MM-dd",
				aaod.replaceAll("\"", ""));

			calendar.setTime(paidThru);

			//In case of multiple lobs
			if (reportingPeriodList.size() > 1) {
				if ((null != lobNm && (Constants.COMMERCIAL.equalsIgnoreCase(lobNm) || Constants.UNICARE.equalsIgnoreCase(lobNm) ||
					(Constants.MEDICARE.equalsIgnoreCase(lobNm) && !Constants.MRDM.equalsIgnoreCase(msrTypeCd))) && !isCommercialOrMedicare)) {

					calendar.add(Calendar.YEAR, -1);
					calendar.add(Calendar.DATE, 1);

					String incurredDt = DateUtil.formatDateToString("MM/dd/yyyy",
						calendar.getTime());
					String paidThrough = DateUtil.formatDateToString("MM/dd/yyyy",
						paidThru);
					repPrd.append(Constants.INCURRED).append(incurredDt)
						.append(" - ")
						.append(paidThrough).append(Constants.PAID_THROUGH)
						.append(paidThrough);

					isCommercialOrMedicare = true;
					hasRhi = true; // PCMSP-22286 - set to true as commercial is RHI data
				}
				else if (null != lobNm && Constants.MEDICARE.equalsIgnoreCase(lobNm) && Constants.MRDM.equalsIgnoreCase(msrTypeCd)) {
					//Replaced add function with set - PCMSP-5675
					calendar.set(Calendar.MONTH, Calendar.JANUARY); //calendar.add(Calendar.MONTH, 1);
					calendar.set(Calendar.DATE, 1);//calendar.add(Calendar.DATE, 1);

					String incurredDt = DateUtil.formatDateToString("MM/dd/yyyy",
						calendar.getTime());
					String paidThrough = DateUtil.formatDateToString("MM/dd/yyyy",
						paidThru);
					repPrd.append(Constants.INCURRED_MEDICARE).append(incurredDt)
						.append(" - ")
						.append(paidThrough).append(Constants.PAID_THROUGH)
						.append(paidThrough);

				}
				else if (null != lobNm && Constants.MEDICAID.equalsIgnoreCase(lobNm) && (!hasRhi || !Constants.RHI.equalsIgnoreCase(msrTypeCd))) { // PCMSP-22286 - hasRhi to ignore the medicaid med-adherence RP if commercial is added

					calendar.add(Calendar.YEAR, -1);
					calendar.add(Calendar.DATE, 1);

					String incurredDt = DateUtil.formatDateToString("MM/dd/yyyy",
						calendar.getTime());
					String paidThrough = DateUtil.formatDateToString("MM/dd/yyyy",
						paidThru);
					if(Constants.RHI.equalsIgnoreCase(msrTypeCd) )
						repPrd.append(Constants.INCURRED_MED_ADHERENCE_MEDICAID);
					else
						repPrd.append(Constants.INCURRED_QUALITY_MEDICAID);
					repPrd.append(incurredDt)
						.append(" - ")
						.append(paidThrough).append(Constants.PAID_THROUGH)
						.append(paidThrough);

				}
			}
			//In case of single lob
			else {

				if (null != lobNm && (Constants.COMMERCIAL.equalsIgnoreCase(lobNm) ||
					Constants.UNICARE.equalsIgnoreCase(lobNm) ||
					(Constants.MEDICARE.equalsIgnoreCase(lobNm) && !Constants.MRDM.equalsIgnoreCase(msrTypeCd)) ||
					Constants.MEDICAID.equalsIgnoreCase(lobNm))) {

					calendar.add(Calendar.YEAR, -1);
					calendar.add(Calendar.DATE, 1);

				}
				//Specific for Medicare CY 
				else if (null != lobNm && Constants.MEDICARE.equalsIgnoreCase(lobNm) && Constants.MRDM.equalsIgnoreCase(msrTypeCd)) {
					//Replaced add function with set - PCMSP-7596
					calendar.set(Calendar.MONTH, Calendar.JANUARY); //calendar.add(Calendar.MONTH, 1);
					calendar.set(Calendar.DATE, 1);//calendar.add(Calendar.DATE, 1);
				}

				String incurredDt = DateUtil.formatDateToString("MM/dd/yyyy",
					calendar.getTime());
				String paidThrough = DateUtil.formatDateToString("MM/dd/yyyy",
					paidThru);
				if(Constants.MEDICAID.equalsIgnoreCase(lobNm)){
					if(Constants.RHI.equalsIgnoreCase(msrTypeCd))
						repPrd.append(Constants.INCURRED_MED_ADHERENCE_MEDICAID);
					else
						repPrd.append(Constants.INCURRED_QUALITY_MEDICAID);
				}
				else
					repPrd.append(Constants.INCURRED);
				repPrd.append(incurredDt)
					.append(" - ")
					.append(paidThrough).append(Constants.PAID_THROUGH)
					.append(paidThrough);
			}
		}
		return repPrd.toString();
	}


	public Suppression getTotalCostSuppression() {
		return totalCostSuppression;
	}

	/**
	 * Get application property bag for given property owner.
	 * 
	 * @param ownerNm
	 * @return
	 * @throws Exception
	 */
	public Map<String, String> getPropertyBag(String ownerNm) throws Exception {

		Map<String, String> result = new HashMap<String, String>();

		StringBuilder sql = new StringBuilder()
			.append("select ")
			.append("    p.aplctn_prpty_ownr_nm as prpty_ownr, ")
			.append("    p.aplctn_prpty_nm as prpty_nm, ")
			.append("    p.aplctn_prpty_val_txt as prpty_val ")
			.append("from ")
			.append("    aplctn_prpty p ")
			.append("where ")
			.append("    p.aplctn_prpty_ownr_nm = ? ")
			.append("with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());
			ps.setString(1, ownerNm);

			executeQuery(logger, sql.toString());

			while (rs.next()) {
				result.put(getString(rs, "prpty_nm"), getString(rs, "prpty_val"));
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get property bag.", e);
		}
		finally {

			close();
		}

		return result;
	}

	/**
	 * Get application properties that match a list of substrings.
	 * Currently used to retrieve metaData for the export pop up window.
	 * Can be made more generic in the future if we end up needing to
	 * retrieve other properties that contain specific substrings;
	 * keeping it specific for the moment to keep the code simpler,
	 * since we'd just end up sending in "pdf" and "export" from the
	 * one Action class that calls this method.
	 */
	public Map<String, String> getPropertiesRelatedToExport(GetExportColumnsRequest request) throws Exception {

		Map<String, String> result = new HashMap<String, String>();
		String exportDataStopTextGeneric = "";

		/**
		 * Ultimately, this part of the metaData retrieval may go away,
		 * if UI only relies on the metaData retrieved from the exprt_grid call below.
		 */
		StringBuilder sql = new StringBuilder()
			.append("select ")
			.append("    p.aplctn_prpty_nm as prpty_nm, ")
			.append("    p.aplctn_prpty_val_txt as prpty_val ")
			.append("from ")
			.append("    aplctn_prpty p ")
			.append("where ")
			.append("    aplctn_prpty_nm like ? or ")
			.append("    aplctn_prpty_nm like ? ")
			.append("with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());

			ps.setString(1, "pdf%");
			ps.setString(2, "export%");

			executeQuery(logger, sql.toString());

			while (rs.next()) {
				String name = getString(rs, "prpty_nm");
				String value = getString(rs, "prpty_val");
				result.put(name, value);

				if ("exportDataStopText".equalsIgnoreCase(name)) {
					exportDataStopTextGeneric = value;
				}
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get properties.", e);
		}
		finally {

			close();
		}

		/**
		 * Retrieve grid-specific export properties for the metaData object for the UI.
		 */
		sql = new StringBuilder()
			.append("select ")
			.append("    warn_col_cnt ")
			.append("    , warn_row_cnt ")
			.append("    , stop_row_cnt ")
			.append("from ")
			.append("    exprt_grid ")
			.append("where ")
			.append("    grid_cd = ? ")
			.append("with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());

			ps.setString(1, request.getCmpId());

			executeQuery(logger, sql.toString());

			while (rs.next()) {
				String stopRowCnt = getString(rs, "stop_row_cnt");
				result.put("pdfExportColumnLimit", getString(rs, "warn_col_cnt"));
				result.put("exportDataWarningLimit", getString(rs, "warn_row_cnt"));
				result.put("exportDataStopLimit", stopRowCnt);

				String exportDataStopText = exportDataStopTextGeneric.replaceAll("\\{limit\\}", stopRowCnt);
				result.put("exportDataStopText", exportDataStopText); // Used to be dsclmr_txt (incorrect use of that column)
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get properties.", e);
		}
		finally {

			close();
		}

		return result;
	}

	/**
	 * Serves as the new endpoint, now that vars.jsp is gone.
	 * 
	 * @param session
	 * @throws Exception
	 */
	public String getConfig(HttpSession session, String sessionId) throws Exception {

		String json = "";
		HashMap<String, Object> cfg = new HashMap<String, Object>();
		HashMap<String, String> sys = new HashMap<String, String>();

		/*
		 * Get session attributes.
		 */
		UserSessionInfo usi = (UserSessionInfo) session
			.getAttribute("userSessionInfo");
		HashMap<String, UserAcsIndicators> acs = usi.getUserAccessIndicators();
		String grpId = usi.getProvGrpId();

		if (acs != null && acs.containsKey(grpId)) {

			/*
			 * Get app and page configurations.
			 */
			AppProperties dao = new AppProperties();
			Collection<AppProperty> props = dao.getAppConfig(grpId);
			//Collection<SuppressionBean> cmps = dao.getComponentConfig(session.getId(), usi.getEntitlementId());
			//Collection<SuppressionBean> cmps = dao.getComponentConfig(sessionId, usi.getEntitlementId());
			Collection<SuppressionBean> cmps = dao.getKillSwitchConfig(sessionId, usi.getEntitlementId(), null);
			dao.updateComponentConfig(cmps, sessionId, usi.getEntitlementId()); // PCMSP-2455
			String reportingPeriod = dao.getReportingPeriodForPopMgnt(grpId);

			cfg.put("reportingPeriod", reportingPeriod);

			String reportingPeriodIncurredFromDate = null;
			String reportingPeriodIncurredToDate = null;

			for (AppProperty a : props) {
				if (a.getName() != null
					&& a.getName().equalsIgnoreCase("reportDate")
					&& a.getOwner().equalsIgnoreCase("UI_CONFIG")) {
					SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
					Date date = sdf.parse(a.getValue());
					Calendar cal = Calendar.getInstance();
					cal.setTime(date);
					reportingPeriodIncurredToDate = sdf.format(cal.getTime());
					cal.add(Calendar.MONTH, -15);
					cal.set(Calendar.DAY_OF_MONTH, 1);
					reportingPeriodIncurredFromDate = sdf.format(cal.getTime());
				}
			}

			cfg.put("reportingPeriodIncurredFromDate",
				reportingPeriodIncurredFromDate);
			cfg.put("reportingPeriodIncurredToDate",
				reportingPeriodIncurredToDate);

			/*
			 * Get user access privileges.
			 */
			boolean rvwrAcs = (usi.getShowAll().equals("Y")) ? true : false;
			boolean clinAcs = false;
			boolean finAcs = false;

			for (UserAcsIndicators u : acs.values()) {
				if (u.getClinicalInd().equals("Y")) {
					clinAcs = true;
				}
				if (u.getFinancialInd().equals("Y")) {
					finAcs = true;
				}
			}

			/*
			 * Create list of effective roles.
			 */
			ArrayList<String> roles = new ArrayList<String>();
			if (clinAcs)
				roles.add("CLINICAL");
			if (finAcs)
				roles.add("FINANCIAL");
			if (rvwrAcs)
				roles.add("REVIEWER");

			/*
			 * Add user, entitlement and role info.
			 */
			cfg.put("userId", usi.getUserId());
			cfg.put("userFirstName", usi.getFirstName());
			cfg.put("userLastName", usi.getLastName());
			cfg.put("groups", usi.getUserAccessIndicators());
			cfg.put("groupName", usi.getEntitlementName());
			cfg.put("roles", roles);

			/*
			 * Add build info.
			 */
			ApplicationConfig appCfg = ApplicationConfig.getInstance();
			cfg.put("buildVersion", appCfg.getProperty("buildVersion"));
			cfg.put("buildDate", appCfg.getProperty("buildDate"));

			/*
			 * Add UI configs and catpure system configs.
			 */
			for (AppProperty p : props) {
				if (p.getOwner().equals("UI_CONFIG")) {
					cfg.put(p.getName(), p.getValue());
				}
				if (p.getOwner().equals("SYS_CONFIG")) {
					sys.put(p.getName(), p.getValue());
				}
			}

			/*
			 * Add component configuration.
			 * UI expects cmpConfig, so make sure it's always present, even if it's empty. 
			 */
			HashMap<String, HashMap<String, String>> cmpCfg = new HashMap<String, HashMap<String, String>>();
			if (!rvwrAcs) {

				boolean appEnabled = (sys.get("APP_ENABLED").equals("Y")) ? true
					: false;

				for (SuppressionBean c : cmps) {

					String nm = c.getName();
					String cls = c.getClassification();

					if (!appEnabled || (cls.equals("CLINICAL") && !clinAcs)
						|| (cls.equals("FINANCIAL") && !finAcs)) {
						c.setStatus(c.getRestrictedStatus());
					}

					if (!appEnabled && nm.equals(sys.get("APP_HOME"))) {
						c.setMessage(sys.get("APP_MSG"));
						c.setStatus("html");
					}

					if (!c.getStatus().equalsIgnoreCase("normal")) {

						String msg = c.getMessage();

						HashMap<String, String> prps = new HashMap<String, String>();
						prps.put("html", (!msg.equals("*")) ? msg : null);
						prps.put("state", c.getStatus().toLowerCase());

						cmpCfg.put(c.getName(), prps);
					}
				}

			}
			cfg.put("cmpConfig", cmpCfg);

			/**
			 * Add user filters
			 */
			SavedFiltersImpl impl = new SavedFiltersImpl();
			List<Filter> filters = impl.selectFilters(usi.getUserId(),
				usi.getEntitlementId());
			cfg.put("userFltr", filters);

			/**
			 * Add brand logo (new as of 2.0)
			 */
			String logo = Encode.forUriComponent(usi.getLogoFileName());
			cfg.put("brandLogo", logo);
		}

		json = JsonSerializer.serialize(cfg);

		return json;
	}

	public Collection<SuppressionBean> getKillSwitchConfig(String sessionId,
		String entitlementId, String cmpntId) throws Exception {

		Collection<SuppressionBean> result = new ArrayList<SuppressionBean>();

		try {
			executeKillSwitchQuery(sessionId, entitlementId, cmpntId);

			while (rs.next()) {

				//SuppressionBean r = buildComponentSuppressionBean();
				SuppressionBean r = buildComponentKillSwitchBean();

				result.add(r);
			}

		}
		catch (Exception e) {

			throw new Exception("Unable to get page config.", e);
		}
		finally {

			close();
		}

		return result;
	}

	public ResultSet executeKillSwitchQuery(String sessionId,
		String entitlementId, String cmpntId) throws Exception {
		// Component Suppression
		StringBuilder sql = buildComponentKillSwitchQuery(cmpntId);

		cn = Database.getConnection(Constants.RPT_DATASOURCE);

		prepareStatement(logger, sql.toString());
		int i = 0;
		ps.setString(++i, entitlementId);
		ps.setString(++i, sessionId);
		if (null != cmpntId && !cmpntId.isEmpty()) {
			for (int j = 0; j < 5; j++) {
				for (String s : StringUtil.parseCommaSeparatedString(cmpntId)) {
					ps.setString(++i, s);
				}
			}
		}

		executeQuery(logger, sql.toString());
		return rs;
	}

	private SuppressionBean buildComponentKillSwitchBean() throws Exception, SQLException {
		SuppressionBean r = new SuppressionBean();
		r.setName(getString(rs, "cmp_nm"));
		r.setClassification(getString(rs, "cmp_class"));
		r.setStatus(getString(rs, "cmp_stts"));
		r.setMessage(getString(rs, "cmp_msg"));
		r.setRestrictedStatus("hidden"); // 2.0: hidden, not destroy anymore
		// using rs.getString to preserve the nulls for upcoming logic

		return r;
	}

	private StringBuilder buildComponentKillSwitchQuery(String cmpntId) {
		String cmpJoin;
		if (null != cmpntId && !cmpntId.isEmpty()) {
			cmpJoin = "AND C.CMPNT_ID IN ( " + StringUtil.buildPlaceholdersFromCommaSeparatedList(cmpntId) + " ) ";
		}
		else {
			cmpJoin = "";
		}

		StringBuilder sql =
			new StringBuilder();
		sql.append(" SELECT CMPNT_ID AS CMP_NM, CMPNT_SCRTY_LVL_DESC AS CMP_CLASS, ")
			.append(" CASE ")
			.append("WHEN MIN(CMP_DISPLAY) = 0 THEN 'normal' ")
			.append("WHEN MAX(CMP_STTS) = 'normal' THEN 'normal' ")
			.append("WHEN MAX(CMP_STTS) = 'disabled' THEN 'disabled'  ")
			.append(" WHEN MAX(CMP_STTS) = 'html' THEN 'html' ")
			.append("WHEN MIN(CMP_STTS) <> MAX(CMP_STTS) THEN 'destroy' ")
			.append("ELSE MIN(CMP_STTS) ")
			.append("END AS CMP_STTS, CAST (COALESCE(MIN(CMP_MSG), '*') AS VARCHAR (500)) AS CMP_MSG, SORT_NBR, CMPNT_DESC ")
			.append("FROM ")
			.append("(SELECT C.CMPNT_ID, C.CMPNT_SCRTY_LVL_DESC, CASE WHEN COALESCE(GS.ST_MW_TXT, MS.ST_MW_TXT, PGM_S.ST_MW_TXT, LOB_S.ST_MW_TXT, ")
			.append("APP_S.ST_MW_TXT, 'normal') = 'normal' THEN 0 ELSE 1 END AS CMP_DISPLAY, ")
			.append("CASE ")
			.append("WHEN GS.ST_MW_TXT IS NOT NULL THEN GS.CUST_MSG_DESC ")
			.append("WHEN GS.ST_MW_TXT IS NULL AND MS.ST_MW_TXT IS NOT NULL THEN MS.CUST_MSG_DESC ")
			.append("WHEN GS.ST_MW_TXT IS NULL AND MS.ST_MW_TXT IS NULL AND PGM_S.ST_MW_TXT IS NOT NULL THEN PGM_S.CUST_MSG_DESC ")
			.append("WHEN GS.ST_MW_TXT IS NULL AND MS.ST_MW_TXT IS NULL AND PGM_S.ST_MW_TXT IS NULL ")
			.append("AND LOB_S.ST_MW_TXT IS NOT NULL THEN LOB_S.CUST_MSG_DESC ")
			.append("WHEN GS.ST_MW_TXT IS NULL AND MS.ST_MW_TXT IS NULL AND PGM_S.ST_MW_TXT IS NULL ")
			.append("AND LOB_S.ST_MW_TXT IS NULL AND APP_S.ST_MW_TXT IS NOT NULL THEN APP_S.CUST_MSG_DESC ")
			.append("WHEN GS.ST_MW_TXT IS NULL AND MS.ST_MW_TXT IS NULL AND PGM_S.ST_MW_TXT IS NULL ")
			.append("AND LOB_S.ST_MW_TXT IS NULL AND APP_S.ST_MW_TXT IS NULL THEN C.CMPNT_LVL_CUST_MSG_TXT ")
			.append("END AS CMP_MSG, CASE ")
			.append("WHEN GS.ST_MW_TXT IS NOT NULL THEN GS.ST_MW_TXT ")
			.append("WHEN GS.ST_MW_TXT IS NULL AND MS.ST_MW_TXT IS NOT NULL THEN MS.ST_MW_TXT ")
			.append("WHEN GS.ST_MW_TXT IS NULL AND MS.ST_MW_TXT IS NULL AND PGM_S.ST_MW_TXT IS NOT NULL THEN PGM_S.ST_MW_TXT ")
			.append("WHEN GS.ST_MW_TXT IS NULL AND MS.ST_MW_TXT IS NULL AND PGM_S.ST_MW_TXT IS NULL ")
			.append("AND LOB_S.ST_MW_TXT IS NOT NULL THEN LOB_S.ST_MW_TXT ")
			.append("WHEN GS.ST_MW_TXT IS NULL AND MS.ST_MW_TXT IS NULL AND PGM_S.ST_MW_TXT IS NULL ")
			.append("AND LOB_S.ST_MW_TXT IS NULL AND APP_S.ST_MW_TXT IS NOT NULL THEN APP_S.ST_MW_TXT ")
			.append("END AS CMP_STTS, C.SORT_NBR, C.CMPNT_DESC ")
			.append("FROM (SELECT SC.CMPNT_ID, PUSA.BRND_CD, PUSA.PROV_GRP_ID,PGPLF.PGM_ID, LD.LOB_CTGRY_NM, SC.CMPNT_PARNT_ID, ")
			.append("SC.CMPNT_SCRTY_LVL_DESC, SC.CMPNT_LVL_CUST_MSG_TXT, SC.SORT_NBR, SC.CMPNT_DESC ")

			.append("FROM ")
			.append("PROV_GRP_PGM_LOB_FACT AS PGPLF  ")
			.append("LEFT JOIN LOB_DIM LD ON (PGPLF.LOB_ID=LD.LOB_ID) ")
			.append("JOIN POIT_USER_SCRTY_ACS AS PUSA ON (PGPLF.PROV_GRP_ID = PUSA.PROV_GRP_ID) JOIN SPRSN_CMPNT AS SC ON (1 = 1) ")
			.append("WHERE PUSA.ENTTLMNT_HASH_KEY = ? ")
			.append("AND PUSA.SESN_ID = ? ")
			.append("AND SC.CMPNT_PARNT_ID NOT LIKE '%gridpanel' ")
			//PCMSP-13913 - start
			.append(" and pgplf.prov_grp_pgm_lob_trmntn_dt > current date ")
			//PCMSP-13913 - end
			.append("GROUP BY SC.CMPNT_ID, PUSA.BRND_CD, PUSA.PROV_GRP_ID, ")
			.append("PGPLF.PGM_ID, LD.LOB_CTGRY_NM, SC.CMPNT_PARNT_ID, ")
			.append(
				"SC.CMPNT_SCRTY_LVL_DESC, SC.CMPNT_LVL_CUST_MSG_TXT, SC.SORT_NBR, SC.CMPNT_DESC ) AS C LEFT OUTER JOIN SPRSN AS GS ON (C.CMPNT_ID = GS.CMPNT_ID AND GS.PROV_GRP_ID = C.PROV_GRP_ID ")
			.append("AND GS.PROV_GRP_ID <> 'ALL' AND GS.MSRMNT_PRD_STRT_DT IS NULL ")
			.append("AND GS.MSRMNT_INTRVL_CD IS NULL ")
			.append(cmpJoin)
			.append(") LEFT OUTER JOIN SPRSN AS MS ON (C.CMPNT_ID = MS.CMPNT_ID AND MS.MRKT_NM = C.BRND_CD ")
			.append("AND MS.MSRMNT_PRD_STRT_DT IS NULL AND MS.MSRMNT_INTRVL_CD IS NULL ")
			.append(cmpJoin)
			.append(") LEFT OUTER JOIN SPRSN AS PGM_S ON (C.CMPNT_ID = PGM_S.CMPNT_ID AND C.PGM_ID = PGM_S.PGM_ID AND PGM_S.PGM_ID IS NOT NULL AND PGM_S.PGM_ID <> '' ")
			.append("AND PGM_S.MSRMNT_PRD_STRT_DT IS NULL AND PGM_S.MSRMNT_INTRVL_CD IS NULL ")
			.append(cmpJoin)
			.append(") LEFT OUTER JOIN SPRSN AS LOB_S ON (C.CMPNT_ID = LOB_S.CMPNT_ID AND C.LOB_CTGRY_NM= LOB_S.LOB_NM AND LOB_S.LOB_NM IS NOT NULL AND LOB_S.LOB_NM <> '' ")
			.append("AND LOB_S.MSRMNT_PRD_STRT_DT IS NULL AND LOB_S.MSRMNT_INTRVL_CD IS NULL ")
			.append(cmpJoin)
			.append(") LEFT OUTER JOIN SPRSN AS APP_S ON (C.CMPNT_ID = APP_S.CMPNT_ID AND APP_S.PROV_GRP_ID = 'ALL' ")
			.append("AND APP_S.MSRMNT_PRD_STRT_DT IS NULL AND APP_S.MSRMNT_INTRVL_CD IS NULL ")
			.append(cmpJoin)
			.append(") ")
			.append("GROUP BY ")
			.append("C.CMPNT_ID, C.CMPNT_SCRTY_LVL_DESC, ")
			.append("CASE WHEN COALESCE(GS.ST_MW_TXT, MS.ST_MW_TXT, PGM_S.ST_MW_TXT, LOB_S.ST_MW_TXT, ")
			.append("APP_S.ST_MW_TXT, 'normal') = 'normal' THEN 0 ELSE 1 END, ")
			.append("CASE ")
			.append("WHEN GS.ST_MW_TXT IS NOT NULL THEN GS.CUST_MSG_DESC ")
			.append("WHEN GS.ST_MW_TXT IS NULL AND MS.ST_MW_TXT IS NOT NULL THEN MS.CUST_MSG_DESC ")
			.append("WHEN GS.ST_MW_TXT IS NULL AND MS.ST_MW_TXT IS NULL AND PGM_S.ST_MW_TXT IS NOT NULL THEN PGM_S.CUST_MSG_DESC ")
			.append("WHEN GS.ST_MW_TXT IS NULL AND MS.ST_MW_TXT IS NULL AND PGM_S.ST_MW_TXT IS NULL ")
			.append("AND LOB_S.ST_MW_TXT IS NOT NULL THEN LOB_S.CUST_MSG_DESC ")
			.append("WHEN GS.ST_MW_TXT IS NULL AND MS.ST_MW_TXT IS NULL AND PGM_S.ST_MW_TXT IS NULL ")
			.append("AND LOB_S.ST_MW_TXT IS NULL AND APP_S.ST_MW_TXT IS NOT NULL THEN APP_S.CUST_MSG_DESC ")
			.append("WHEN GS.ST_MW_TXT IS NULL AND MS.ST_MW_TXT IS NULL AND PGM_S.ST_MW_TXT IS NULL ")
			.append("AND LOB_S.ST_MW_TXT IS NULL AND APP_S.ST_MW_TXT IS NULL THEN C.CMPNT_LVL_CUST_MSG_TXT ")
			.append("END , CASE ")
			.append("WHEN GS.ST_MW_TXT IS NOT NULL THEN GS.ST_MW_TXT ")
			.append("WHEN GS.ST_MW_TXT IS NULL AND MS.ST_MW_TXT IS NOT NULL THEN MS.ST_MW_TXT ")
			.append("WHEN GS.ST_MW_TXT IS NULL AND MS.ST_MW_TXT IS NULL AND PGM_S.ST_MW_TXT IS NOT NULL THEN PGM_S.ST_MW_TXT ")
			.append("WHEN GS.ST_MW_TXT IS NULL AND MS.ST_MW_TXT IS NULL AND PGM_S.ST_MW_TXT IS NULL ")
			.append("AND LOB_S.ST_MW_TXT IS NOT NULL THEN LOB_S.ST_MW_TXT ")
			.append("WHEN GS.ST_MW_TXT IS NULL AND MS.ST_MW_TXT IS NULL AND PGM_S.ST_MW_TXT IS NULL ")
			.append("AND LOB_S.ST_MW_TXT IS NULL AND APP_S.ST_MW_TXT IS NOT NULL THEN APP_S.ST_MW_TXT ")
			.append("END, C.SORT_NBR, C.CMPNT_DESC ) AS B ")
			.append("WHERE CMP_STTS IS NOT NULL ")
			.append("GROUP BY CMPNT_ID, CMPNT_SCRTY_LVL_DESC, SORT_NBR, CMPNT_DESC ")
			.append(" WITH UR ");
		return sql;

	}

	public ResultSet getChildrenCmpnts(String cmpntId) throws Exception {
		List<TapReportsBean> list = new ArrayList<TapReportsBean>();

		StringBuilder sql = new StringBuilder()
			.append("SELECT CMPNT_ID AS CMP_NM, 'normal' AS CMP_STTS, CMPNT_DESC AS CMPNT_DESC, SORT_NBR AS SORT_NBR ")
			.append("FROM SPRSN_CMPNT ")
			.append("WHERE CMPNT_PARNT_ID IN ( ? ) ");

		cn = Database.getConnection(Constants.RPT_DATASOURCE);

		prepareStatement(logger, sql.toString());
		int i = 0;
		ps.setString(++i, "tap-reports-" + cmpntId);

		executeQuery(logger, sql.toString());


		return rs;

	}

	protected void updateComponentConfig(Collection<SuppressionBean> cmps, String sessionId, String entitlementId) throws Exception {

		for (SuppressionBean cmp : cmps) {
			if ("performance".equalsIgnoreCase(cmp.getName())
				&& !"hidden".equalsIgnoreCase(cmp.getStatus())
				&& hidePerformanceManagementTab(sessionId, entitlementId)) {

				cmp.setStatus(cmp.getRestrictedStatus());

			}
		}

	}

	/**
	 * Determine if the Performance Management Tab should be hidden because the logged in user has no Performance Management data.
	 * 
	 * @param sesnId, entId
	 * @return boolean
	 * @throws Exception
	 */
	public boolean hidePerformanceManagementTab(String sesnId, String entId) throws Exception {

		boolean empty = true;

		StringBuilder sql = new StringBuilder()
			.append("select * ")
			.append("from prfrmn_mngmnt_glbl_fltr_smry pmgfs ")
			.append("join poit_user_scrty_acs pusa on (pusa.prov_grp_id = pmgfs.prov_grp_id) ")
			.append("where pusa.enttlmnt_hash_key = ? ")
			.append("and pusa.sesn_id = ? ")
			.append("with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());
			int i = 0;
			ps.setString(++i, entId);
			ps.setString(++i, sesnId);

			executeQuery(logger, sql.toString());

			if (rs.next()) {

				empty = false;

			}

		}
		catch (Exception e) {

			throw new Exception("Unable to determine whether to hide Performance Management Tab.", e);
		}
		finally {

			close();
		}

		return empty;
	}


	private String getPharmacyDisclaimerString(ResultSet rs, String columnName) throws Exception {

		String result = rs.getString(columnName);
		result = (result != null) ? result.trim() : Constants.DASHES;

		return (result.length() > 0) ? result : Constants.BLANK;
	}
}
