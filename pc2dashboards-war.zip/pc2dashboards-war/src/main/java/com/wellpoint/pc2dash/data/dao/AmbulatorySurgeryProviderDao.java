package com.wellpoint.pc2dash.data.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.costOpportunity.GetAmbulatorySurgeryProviderRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.dto.costOpportunity.AmbulatorySurgeryProviderBean;
import com.wellpoint.pc2dash.dto.costOpportunity.MinimumCriteriaBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class AmbulatorySurgeryProviderDao extends ServiceImpl {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(AmbulatorySurgeryProviderDao.class);

	public List<AmbulatorySurgeryProviderBean> getData(GetAmbulatorySurgeryProviderRequest request, boolean exportFlag, int index, int limit) throws Exception {

		List<AmbulatorySurgeryProviderBean> result = new ArrayList<AmbulatorySurgeryProviderBean>();
		MinimumCriteriaBean minCrit = new MinimumCriteriaBean("srgry_cnt", "coc_asc_ctgry_smry", "COC_ASC_MIN_TOTL_SRGRY", "sub_mtrc_nm");
		setRowCount(0);

		CommonQueries cq = new CommonQueries();
		boolean displayDashes = cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request, minCrit);

		String dir = getSort(request);
		String masked = "asc".equalsIgnoreCase(dir) ? String.valueOf(Integer.MAX_VALUE) : String.valueOf(Integer.MIN_VALUE); // we want masked values to always be at the bottom, so use either the biggest or smallest value, depending
		String dashesClause =
			" (sum(srgry_cnt) < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_ASC_MIN_TOTL_SRGRY' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG')) "
				+ " and (true = " + displayDashes + ") "; // PCMSP-12566

		StringBuilder query =
			new StringBuilder()
				.append(" select   c.* ")
				.append(" from   ( ")
				.append(" 	select   b.*, row_number() over( order by ")
				.append(buildSortClause(request))
				.append("   ) as row_nbr ")
				.append(" 	from   ( ")
				.append(" 		select ")
				.append(" 			a.provName, ")
				.append(" 			a.ipDimKey, ")
				.append(" 			a.provOrgDimKey, ")
				.append(" 			a.orgName, ")
				.append("           a.prov_org_tax_id, ")
				.append("           a.IP_NPI, ")
				.append("           a.IP_SPCLTY_NM, ")
				.append(" 			a.totalSurgeryCount, ")
				.append(" 			a.percentSurgeriesAtHigherCost, ")
				.append(" 			a.memberCount, ")
				.append(" 			a.costOpportunity, ")
				.append("      	    a.dsply_dashes, ")
				.append(" 			a.row_cnt as row_cnt ")
				.append(" 		from  ( ")
				.append(" 			select ")
				.append(" 				prov_dsply_nm as provName, ")
				.append(" 				smry.ip_dim_key as ipDimKey, ")
				.append(" 				prov_org_dim_key as provOrgDimKey, ")
				.append(" 				prov_org_full_nm as orgName, ")
				.append("               smry.prov_org_tax_id as prov_org_tax_id, ")
				.append("               smry.IP_NPI IP_NPI, ")
				.append("               cd.cd_val_nm IP_SPCLTY_NM, ")
				.append(" 				sum(srgry_cnt) as totalSurgeryCount, ")
				.append(" 				(CASE WHEN SUM(SRGRY_CNT) > 0 THEN (SUM(HCOST_SITE_CASE_CNT) / CAST (SUM(SRGRY_CNT) AS decimal (18,3))) ELSE 0.00 END) * 100 as percentSurgeriesAtHigherCost, ") //query changes done as per suggested by Sathish
				.append(" 				sum(mbr_cnt) as memberCount, ")
				.append(" 				case when ")
				.append(dashesClause)
				.append(" then ")
				.append(masked)
				.append(" when sum(cost_oprtnty_amt) >= 0 then sum(cost_oprtnty_amt) else 0.00 end as costOpportunity,  count(*) over () as row_cnt, ")

				.append(" case when ")
				.append(dashesClause)
				.append(" then 'Y' else 'N' end as dsply_dashes ")
				.append(" 				    FROM coc_asc_ctgry_smry smry ")
				.append("                 join   IP_DIM ip on ( ip.ip_dim_key = smry.ip_dim_key ) ")
				.append("                join  cd_dim cd on ( cd.cd_dim_key = ip.SPCLTY_CD_DIM_KEY) ")
				.append(" 			join  poit_user_scrty_acs pusa on (smry.prov_grp_id = pusa.prov_grp_id ")
				.append(" 					and ")
				.append(" 				case ")
				.append(" 						when    pusa.prov_org_tax_id = '0' ")
				.append(" 						then    smry.prov_org_tax_id ")
				.append(" 						else    pusa.prov_org_tax_id end = smry.prov_org_tax_id) ")
				.append(" 			where  pusa.sesn_id = ? ")
				.append(" 				and  pusa.enttlmnt_hash_key = ? ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and smry.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and smry.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and smry.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and smry.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and smry.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}

		// Changes for PCMSP-7421 - Procedure Filter
		if (StringUtil.isNotBlankOrFalse(request.getProcedureCode())) {
			query.append(" and smry.SUB_MTRC_CD in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProcedureCode())
				+ ") ");
		}

		query.append(" 			group by ")
			.append(" 				smry.prov_dsply_nm, ")
			.append(" 				smry.ip_dim_key, ")
			.append(" 				smry.prov_org_dim_key, ")
			.append(" 				smry.prov_org_full_nm, ")
			.append("               smry.IP_NPI, ")
			.append("               smry.prov_org_tax_id, ")
			.append("               cd_val_nm")
			.append(" 		) as a ")
			.append(" 	) as b ")
			.append(" ) as c ");

//		if (!exportFlag) {
//			query.append(" where c.row_nbr between ? and ? ");
//		}
//		query.append(" order by c.row_nbr  with ur ");
		query.append(" where c.row_nbr between ? and ? ");
		query.append(" order by c.row_nbr  with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());

			buildPreparedStatement(request, i, exportFlag, index, limit);

			executeQuery(logger, query.toString());

			result = convertSelectedRowsToObjects(rs, request, displayDashes, exportFlag);

		}
		catch (Exception e) {

			throw new Exception("Unable to get AmbulatorySurgeryProviderDao (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;

	}

	protected String getSort(GetAmbulatorySurgeryProviderRequest request) {
		String dir = "";
		if (CollectionUtils.isNotEmpty(request.getSort())
			&& request.getSort().get(0) != null
			&& StringUtils.isNotBlank(request.getSort().get(0).getDirection())) {
			dir = request.getSort().get(0).getDirection();
		}
		return dir;
	}

	private void buildPreparedStatement(GetAmbulatorySurgeryProviderRequest request, int i, boolean exportFlag, int index, int limit) throws SQLException {

		int start = 0;
		int stop = 0;

		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProcedureCode())) { // PCMSP-7421
			String[] array = request.getProcedureCode().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (!exportFlag) {
			start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
			stop = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
		}
		else {
			start = index;
			stop = limit;
		}
		ps.setInt(++i, start + 1);
		ps.setInt(++i, start + stop);

	}

	private List<AmbulatorySurgeryProviderBean> convertSelectedRowsToObjects(ResultSet rs, GetAmbulatorySurgeryProviderRequest request, boolean displayDashes, boolean exportFlag)
		throws SQLException {

		List<AmbulatorySurgeryProviderBean> list = new ArrayList<AmbulatorySurgeryProviderBean>();
		if (exportFlag) {
			while (rs.next()) {

				AmbulatorySurgeryProviderBean item = new AmbulatorySurgeryProviderBean();

				item.setAttributedPhysicianName(rs.getString("provName"));
				item.setAttributedProvNpi(StringUtil.getValueOrDashes(rs.getString("IP_NPI")));
				item.setAttributedProvSpeciality(StringUtil.getValueOrDashes(rs.getString("IP_SPCLTY_NM")));
				item.setOrganizationName(rs.getString("orgName"));
				item.setOrgTin(rs.getString("prov_org_tax_id"));
				item.setTotalSurgeryCount(rs.getString("totalSurgeryCount"));

				if (rs.getString("percentSurgeriesAtHigherCost") != null) {
					item.setPercentageHighCostSurgeryCount(StringUtil.convertStringToCommaBigDecimal(
						rs.getBigDecimal("percentSurgeriesAtHigherCost").setScale(2, BigDecimal.ROUND_HALF_UP).toString(), 2).concat("%"));
				}

				if (displayDashes ||
					rs.getString("dsply_dashes") != null && rs.getString("dsply_dashes").equalsIgnoreCase(Constants.Y)) {
					displayDashes = true;
				}
				else {
					displayDashes = false;
				}

				if (displayDashes) {
					item.setCostOpportunity(Constants.DASHES);
					item.setHighCostSurgeryPercentageInd(false);
				}
				else {
					if (rs.getString("costOpportunity") != null) {
						item.setCostOpportunity(StringUtil.convertStringToDecimalCurrency(rs
							.getBigDecimal("costOpportunity").setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
					}
					item.setHighCostSurgeryPercentageInd(true);
				}


				list.add(item);

				if (getRowCount() == 0) {
					setRowCount(rs.getInt("row_cnt"));
				}
				setTotalExport(rs.getInt("row_cnt"));  
			}
			 
		}
		else {
			while (rs.next()) {

				AmbulatorySurgeryProviderBean item = new AmbulatorySurgeryProviderBean();

				item.setAttributedPhysicianName(rs.getString("provName"));
				item.setOrganizationName(rs.getString("orgName"));
				item.setProviderId(StringUtil.buildUniqueProviderId(rs.getString("ipDimKey"), rs.getString("provOrgDimKey")));
				item.setTotalSurgeryCount(rs.getString("totalSurgeryCount"));
				item.setPercentageHighCostSurgeryCount(rs.getString("percentSurgeriesAtHigherCost"));

				if (displayDashes ||
					rs.getString("dsply_dashes") != null && rs.getString("dsply_dashes").equalsIgnoreCase(Constants.Y)) {
					displayDashes = true;
				}
				else {
					displayDashes = false;
				}

				if (displayDashes) {
					item.setCostOpportunity(Constants.DASHES);
					item.setHighCostSurgeryPercentageInd(false);
				}
				else {
					item.setCostOpportunity(rs.getString("costOpportunity"));
					item.setHighCostSurgeryPercentageInd(true);
				}
				item.setHasDetailsDrilldownInd(request.isHasDetailsDrilldownInd());

				list.add(item);

				if (getRowCount() == 0) {
					setRowCount(rs.getInt("row_cnt"));
				}

			}
		}
		return list;

	}

	private String buildSortClause(GetAmbulatorySurgeryProviderRequest request) {

		StringBuilder query = new StringBuilder();
		String defaultColumn = " costOpportunity ";
		String defaultSort = defaultColumn + " desc ";

		if (null != request.getSort()) {

			for (QuerySort sort : request.getSort()) {

				String dir = sort.getDirection().replaceAll("\"", "");
				String property = sort.getProperty();

				if (property.equals("attributedPhysicianName")) {
					query.append(" provName " + dir + ", " + defaultSort);
				}
				else if (property.equals("organizationName")) {
					query.append(" orgName " + dir + ", " + defaultSort);
				}
				else if (property.equals("totalSurgeryCount")) {
					query.append(" totalSurgeryCount " + dir + ", " + defaultSort);
				}
				else if (property.equals("percentageHighCostSurgeryCount")) {
					query.append(" percentSurgeriesAtHigherCost " + dir + ", " + defaultSort);
				}
				else {
					query.append(defaultColumn + dir);
				}
			}

		}
		else {
			query.append(defaultSort);
		}

		return query.toString();

	}

	/*private String getMaskedOrActualValue(boolean displayDashes, String maskedValue, String columnName) {
	
		String value;
	
		if (displayDashes) {
			value = maskedValue;
		}
		else {
			value = columnName;
		}
	
		return value;
	
	}*/

}
