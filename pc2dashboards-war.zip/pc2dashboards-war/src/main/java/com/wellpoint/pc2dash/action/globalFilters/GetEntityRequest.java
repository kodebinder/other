package com.wellpoint.pc2dash.action.globalFilters;

import com.wellpoint.pc2dash.data.dto.PCMSRequest;

public class GetEntityRequest extends PCMSRequest {

}
