package com.wellpoint.pc2dash.data.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.action.costOpportunity.GetHighValueSpecialistReferralsProviderRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.costOpportunity.HighValueSpecialistReferralsProviderBean;
import com.wellpoint.pc2dash.dto.costOpportunity.MinimumCriteriaBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class HighValueSpecialistReferralsProviderDao extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(HighValueSpecialistReferralsProviderDao.class);

	public List<HighValueSpecialistReferralsProviderBean> getData(GetHighValueSpecialistReferralsProviderRequest request, boolean exportFlag, int index, int limit) 
			throws Exception {

		List<HighValueSpecialistReferralsProviderBean> result = new ArrayList<HighValueSpecialistReferralsProviderBean>();
		MinimumCriteriaBean minCrit = new MinimumCriteriaBean("epsd_cnt", "coc_spclty_ctgry_smry", "COC_SPL_MIN_RFRL", null); //  Populate with correct values if they differ. If a change to this logic is requested, see AmbulatorySurgeryProviderDao for an example.
		MinimumCriteriaBean minCritSpclty = new MinimumCriteriaBean("epsd_cnt", "coc_spclty_ctgry_smry", "COC_SPL_MIN_RFRL", "sub_mtrc_nm"); //PCMSP-6867
		setRowCount(0);

		CommonQueries cq = new CommonQueries();
		boolean displayDashes = cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request, minCrit);
		boolean displayDashesSpclty  = cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request, minCritSpclty); //PCMSP-6867

		//String dir = request.getSort().get(0).getDirection();
		//String masked = "asc".equalsIgnoreCase(dir) ? String.valueOf(Integer.MAX_VALUE) : String.valueOf(Integer.MIN_VALUE); // we want masked values to always be at the bottom, so use either the biggest or smallest value, depending

		StringBuilder query = new StringBuilder().append(" select   a.* ")
			.append(" from   ( ")
			.append(" 	select   row_number() over( order by ")
			.append(buildSortClause(request))
			.append(" ) as row_nbr, ")
			.append(" 		prov_dsply_nm as provName, ")
			.append(" 		smry.ip_dim_key as ipDimKey, ")
			.append(" 		prov_org_dim_key as provOrgDimKey, ")
			.append(" 		prov_org_full_nm as orgName, ")
			.append("       smry.PROV_ORG_TAX_ID as orgTaxId, ")
			.append("       smry.IP_NPI as provNPI, ")
			.append("       cd.cd_val_nm as IP_SPCLTY_NM, ")
			.append(" 		sum(epsd_cnt) as totalEpisodeCount, ")
			.append(" 		sum(epsd_cost_amt) as totalEpisodeCost, ")
			.append(" 		sum(hcost_epsd_cnt) as totalEpisodeHigherCostCount, ")
			.append(" 		count( distinct spclty_prov_id) as specialistsCount, ")
			.append(" 		sum(cost_oprtnty_amt) as costOpportunity, ")
			.append(" 		count(*) over () as row_cnt ")
			.append(" 	from coc_spclty_ctgry_smry smry ")
			.append("   join  IP_DIM ip on ( ip.ip_dim_key = smry.ip_dim_key ) ")
			.append("   join  cd_dim cd on ( cd.cd_dim_key = ip.SPCLTY_CD_DIM_KEY) ")
			.append(" 	join  poit_user_scrty_acs pusa on (smry.prov_grp_id = pusa.prov_grp_id ")
			.append(" 			and ")
			.append(" 		case ")
			.append(" 				when    pusa.prov_org_tax_id = '0' ")
			.append(" 				then    smry.prov_org_tax_id ")
			.append(" 				else    pusa.prov_org_tax_id end = smry.prov_org_tax_id) ")
			.append(" 	where  pusa.sesn_id = ? ")
			.append(" 			and  pusa.enttlmnt_hash_key = ? ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and smry.prov_grp_id in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and smry.pgm_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and smry.lob_desc in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and smry.ip_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and smry.prov_org_dim_key in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getSpecialtyCode())) {
			query.append(" and smry.SUB_MTRC_CD in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getSpecialtyCode())
				+ ") ");
		}

		query.append(" 	group by ")
			.append(" 		smry.prov_dsply_nm, ")
			.append(" 		smry.ip_dim_key, ")
			.append(" 		smry.prov_org_dim_key, ")
			.append(" 		smry.prov_org_full_nm, ")
			.append(" 		smry.PROV_ORG_TAX_ID, ")
			.append(" 		smry.IP_NPI, ")
			.append(" 		cd_val_nm ")
			.append(" ) as a ");
/*		if (!exportFlag) {
			query.append(" where a.row_nbr between ? and ? ");
		}
		query.append(" order by a.row_nbr  with ur ");*/
		query.append(" where a.row_nbr between ? and ? ");
		query.append(" order by a.row_nbr  with ur ");

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, query.toString());

			buildPreparedStatement(request, i, exportFlag, index, limit);

			executeQuery(logger, query.toString());

			result = convertSelectedRowsToObjects(rs, request, displayDashes, displayDashesSpclty, exportFlag);

		}
		catch (Exception e) {

			throw new Exception("Unable to get HighValueSpecialistReferralsProviderDao (" + request.getEntitlementId() + ").", e);
		}
		finally {

			close();
		}

		return result;

	}

	private void buildPreparedStatement(GetHighValueSpecialistReferralsProviderRequest request, int i, boolean exportFlag, int index, int limit) 
			throws SQLException {
		
		int start = 0;
		int stop = 0;

		ps.setString(++i, request.getSessionId());
		ps.setString(++i, request.getEntitlementId());

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			String[] array = request.getProvDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, StringUtil.parseProviderId(item));
			}
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			String[] array = request.getOrgDimKeys().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}
		
		if (StringUtil.isNotBlankOrFalse(request.getSpecialtyCode())) {
			String[] array = request.getSpecialtyCode().split(",");
			for (String item : array) {
				ps.setString(++i, item);
			}
		}

		if (!exportFlag) {
			start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
			stop = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
		}
		else {
			start = index;
			stop = limit;
		}
		ps.setInt(++i, start + 1);
		ps.setInt(++i, start + stop);

	}

	private List<HighValueSpecialistReferralsProviderBean> convertSelectedRowsToObjects(ResultSet rs, GetHighValueSpecialistReferralsProviderRequest request,
		boolean displayDashes, boolean displayDashesSpclty, boolean exportFlag)
		throws SQLException {

		List<HighValueSpecialistReferralsProviderBean> list = new ArrayList<HighValueSpecialistReferralsProviderBean>();

		while (rs.next()) {

			HighValueSpecialistReferralsProviderBean item = new HighValueSpecialistReferralsProviderBean();

			item.setAttributedPhysicianName(rs.getString("provName"));
			item.setOrganizationName(rs.getString("orgName"));
			item.setProviderId(StringUtil.buildUniqueProviderId(rs.getString("ipDimKey"), rs.getString("provOrgDimKey")));
			//PCMSP - 6867 
			item.setSpecialistsCount(rs.getString("specialistsCount"));
			item.setTotalEpisodeCount(rs.getString("totalEpisodeCount"));
			item.setTotalEpisodeHigherCostCount(rs.getString("totalEpisodeHigherCostCount"));
			if(exportFlag){ 
				item.setTotalEpisodeCost((rs.getBigDecimal("totalEpisodeCost").intValue() >= 0)
					? StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("totalEpisodeCost").setScale(2, BigDecimal.ROUND_HALF_UP).toString())
					: Constants.DASHES);
				item.setOrganizationTin(rs.getString("orgTaxId"));
                item.setAttributedProvNpi(StringUtil.getValueOrDashes(rs.getString("provNPI")));
                item.setAttributedProvSpeciality(StringUtil.getValueOrDashes(rs.getString("IP_SPCLTY_NM")));
			

			}else{
				item.setTotalEpisodeCost(rs.getString("totalEpisodeCost"));
			}

			/*PCMSP-20354 STARTS 1*/
			/*
			if (displayDashes || displayDashesSpclty) {
				item.setCostOpportunity(Constants.DASHES);
				//item.setSpecialistsCount(Constants.DASHES); //PCMSP - 6867
				//item.setTotalEpisodeCost(Constants.DASHES); //PCMSP - 6867
				//item.setTotalEpisodeCount(Constants.DASHES); //PCMSP - 6867
				//item.setTotalEpisodeHigherCostCount(Constants.DASHES); //PCMSP - 6867
			}
			else {
			*/
			if (exportFlag) {
				if (null != rs.getString("costOpportunity")) {
					if (displayDashes || displayDashesSpclty) {
						if ((Integer.parseInt(rs.getString("totalEpisodeCount")) < Constants.HVSR_MIN_EPSD_CNT)) {
							item.setCostOpportunity(Constants.DASHES);
						}else {
							item.setCostOpportunity((rs.getBigDecimal("costOpportunity").intValue() >= 0)
									? StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("costOpportunity")
											.setScale(2, BigDecimal.ROUND_HALF_UP).toString())
									: Constants.DASHES);
						}
					} else {
						if ((Integer.parseInt(rs.getString("totalEpisodeCount")) < Constants.HVSR_MIN_EPSD_CNT)) {
							item.setCostOpportunity(Constants.DASHES);
						}else {
							item.setCostOpportunity((rs.getBigDecimal("costOpportunity").intValue() >= 0)
									? StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("costOpportunity")
											.setScale(2, BigDecimal.ROUND_HALF_UP).toString())
									: Constants.DASHES);
						}
					}
				} else {
					item.setCostOpportunity(Constants.DASHES);
				}
			} else {
				if (null != rs.getString("costOpportunity")) {
					if (displayDashes || displayDashesSpclty) {
						if ((Integer.parseInt(rs.getString("totalEpisodeCount")) < Constants.HVSR_MIN_EPSD_CNT)) {
							item.setCostOpportunity(Constants.DASHES);
						}else {
							item.setCostOpportunity(rs.getString("costOpportunity"));
						}
					} else {
						if ((Integer.parseInt(rs.getString("totalEpisodeCount")) < Constants.HVSR_MIN_EPSD_CNT)) {
							item.setCostOpportunity(Constants.DASHES);
						}else {
							item.setCostOpportunity(rs.getString("costOpportunity"));
						}
					}
				} else {
					item.setCostOpportunity(Constants.DASHES);
				}
			}
				
			//}
			/*PCMSP-20354 ENDS 1*/
			item.setHasEpisodesDrilldownInd(request.isHasEpisodesDrilldownInd());

			list.add(item);

			if (getRowCount() == 0) {
				setRowCount(rs.getInt("row_cnt"));
			}
			if (exportFlag) {
				setTotalExport(rs.getInt("row_cnt"));
			}
		}

		return list;

	}

	private String buildSortClause(GetHighValueSpecialistReferralsProviderRequest request) {

		StringBuilder query = new StringBuilder();
		String defaultColumn = " sum(cost_oprtnty_amt) ";
		String defaultSort = defaultColumn + " desc ";

		if (null != request.getSort()) {

			for (QuerySort sort : request.getSort()) {

				String dir = sort.getDirection().replaceAll("\"", "");
				String property = sort.getProperty();

				if (property.equals("organizationName")) {
					query.append(" prov_org_full_nm " + dir + ", " + defaultSort);
				}
				else if (property.equals("attributedPhysicianName")) {
					query.append(" prov_dsply_nm " + dir + ", " + defaultSort);
				}
				else if (property.equals("totalEpisodeCount")) {
					query.append(" sum(epsd_cnt) " + dir + ", " + defaultSort);
				}
				else if (property.equals("totalEpisodeCost")) {
					query.append(" sum(epsd_cost_amt) " + dir + ", " + defaultSort);
				}
				else if (property.equals("totalEpisodeHigherCostCount")) {
					query.append(" sum(hcost_epsd_cnt) " + dir + ", " + defaultSort);
				}
				else if (property.equals("specialistsCount")) {
					query.append(" count(distinct spclty_prov_id) " + dir + ", " + defaultSort);
				}
				else {
					query.append(defaultColumn + dir);
				}
			}

		}
		else {

		}

		return query.toString();

	}

	/*private String getMaskedOrActualValue(boolean displayDashes, String maskedValue, String columnName) {

		String value;

		if (displayDashes) {
			value = maskedValue;
		}
		else {
			value = columnName;
		}

		return value;

	}
*/
	@Override
	public boolean read(Dto o) throws Exception {
		
		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {

		
	}

	@Override
	public void update(Dto o) throws Exception {

		
	}

	@Override
	public void delete(Dto o) throws Exception {

		
	}

}