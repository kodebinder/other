package com.wellpoint.pc2dash.action.careOpportunities;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.careOpportunities.CareOppChartBean;
import com.wellpoint.pc2dash.dto.careOpportunities.CareOpportunitiesChartJson;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.careopportunities.CareOpportunitiesChartServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;


public class GetCareOpportunitiesChartAction extends Action {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetCareOpportunitiesChartAction.class);

	@SuppressWarnings("unchecked")
	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		List<CareOppChartBean> resultList = null;

		ActionResponse response = new GetCareOpportunitiesChartResponse();
		GetCareOpportunitiesChartRequest request = (GetCareOpportunitiesChartRequest) actionRequest;
		ErrorProperties err = ErrorProperties.getInstance();

		List<String> filteredProvGrpList = new ArrayList<String>();
		ArrayList<CareOpportunitiesChartJson> chartList = new ArrayList<CareOpportunitiesChartJson>();
		try {
			//			PCMSRequest request = getDataMap(getCareOpportunitiesChartRequest);

			// preserve dataMap logic
			removeLobPgmPrefixes(request);
			prepareChronicCareGapMap(request);

			//Kill switch check on Provider groups
			if (StringUtils.isNotBlank(request.getCmpId())) {
				filteredProvGrpList = filterProvGrpsByKillSwitch(request);
			}
			//Clinical access check on provider groups
			if (null != filteredProvGrpList && filteredProvGrpList.size() > 0) {
				filteredProvGrpList = filterProvGrpsByClinicalInd(request, filteredProvGrpList);
			}

			CareOpportunitiesChartServiceImpl service = new CareOpportunitiesChartServiceImpl();
			if (null != filteredProvGrpList && !filteredProvGrpList.isEmpty()) {
				request.setProvGrpIds(StringUtils.join(filteredProvGrpList, ','));
				request.setGrpInd(Constants.GRP_IND_N);

				CommonQueries cq = new CommonQueries();
				request.setSuppression(cq.getActiveSuppressionForSelectComponents(request));

				resultList = service.getData(request);
			}

			if (null != resultList && !resultList.isEmpty()) {
				chartList = (ArrayList<CareOpportunitiesChartJson>) service.getBeanList(resultList);
				response.setData(chartList);
				response.setMessage(err.getProperty("successful"));
			}
			else {
				response.setMessage(err.getProperty("successNoData"));
			}

			logger.debug("Chart returned");
			response.setSuccess(true);
			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}

	//	public Map<String, String> getDataMap(GetCareOpportunitiesChartRequest request) throws JsonException{
	//		//PCMSRequest request = new HashMap<String, String>();
	//		
	//		if(request != null){
	//			request.put("provGrpId", request.getProvGrpId());
	//			request.put("panelHierarchy", request.getProvDimKeys());
	//			request.put("orgDimKeys", request.getOrgDimKeys());
	//			request.put("referralOutcomeKeys", request.getReferralOutcomeKeys());
	//			
	//			//For TIN NPI
	//			//request.put("sessionId", request.getSessionId());
	//			//request.put("entitlementId", request.getEntitlementId());
	//			request.put("grpInd", request.getGrpInd());
	//			
	//			//CM/DM
	//			request.put("cmdmProgramKeys", request.getCmdmProgramKeys());
	//			request.put("cmdmStatusKeys", request.getCmdmStatusKeys());
	//			request.put("ihmInd", request.getIhmInd());
	//			
	//			//request.setCmpId(request.getCmpId());
	//			//request.setProvGrpIds(request.getProvGrpIds());
	//			request.put(Constants.USER_ACS_INFO_JSON, request.getUserAcsInfoJson());
	//			request.put("pslId", request.getPslIds());
	//			request.put("lobId", JSONUtils.removeFirstOccurenceOfCharsFromJsonString(request.getLobIds(), Constants.LOB_ID_PREFIX));
	//	        request.put("programIds", JSONUtils.removeFirstOccurenceOfCharsFromJsonString(request.getProgramIds(), Constants.PRGM_ID_PREFIX));
	//	        /** 57008 CHRONIC_CARE_GAP changes| ad87338 | START */
	//	        request.put("riskDriverKeys", request.getRiskDriverKeys());
	//			prepareChronicCareGapMap(request, request);
	//			/** 57008 CHRONIC_CARE_GAP changes| ad87338 | END */
	//		
	//		}
	//		
	//		return request;
	//	}
}
