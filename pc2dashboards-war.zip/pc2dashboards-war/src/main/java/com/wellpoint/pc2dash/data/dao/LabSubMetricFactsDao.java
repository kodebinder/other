package com.wellpoint.pc2dash.data.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.costOpportunity.GetLabCostOppByLabRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.costOpportunity.CostOppForLabsBean;
import com.wellpoint.pc2dash.dto.costOpportunity.MinimumCriteriaBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.ServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QuerySort;
import com.wellpoint.pc2dash.util.StringUtil;

public class LabSubMetricFactsDao extends ServiceImpl {
	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(LabSubMetricFactsDao.class);
	private boolean displayDashesSmry = false;
	private boolean displayDashesLabProv = false;

	@Override
	public boolean read(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	@Override
	public void insert(Dto o) throws Exception {
		throw new Exception("Not implemented");

	}

	@Override
	public void update(Dto o) throws Exception {
		throw new Exception("Not implemented");

	}

	@Override
	public void delete(Dto o) throws Exception {
		throw new Exception("Not implemented");

	}


	public List<CostOppForLabsBean> getLabGriddata(GetLabCostOppByLabRequest request, boolean exportFlag, int index, int limit) throws Exception {
		List<CostOppForLabsBean> resultList = new ArrayList<CostOppForLabsBean>();
		MinimumCriteriaBean minCritSmry = new MinimumCriteriaBean("unit_cnt", "coc_lab_prov_smry", "COC_LAB_MIN_LABS", null);
		//MinimumCriteriaBean minCritLabProv = new MinimumCriteriaBean("unit_cnt", "coc_lab_prov_smry", "COC_LAB_MIN_LABS", "IP_DIM_KEY"); //Commenting the code as of now as we have to show data only in case if the minimum criteria is met for LAB view.
		
		CommonQueries cq = new CommonQueries();
		displayDashesSmry = cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request, minCritSmry); // PCMSP-6866
		//displayDashesLabProv = cq.displayDashesBasedOnSummaryLevelMinimumCriteria(request, minCritLabProv); //Commenting the code as of now as we have to show data only in case if the minimum criteria is met for LAB view.
		//PCMSP-10846 Minimum Criteria for Minimum Criteria
		String dashesClause = " sum(LSMRY.unit_cnt) < (select distinct APLCTN_PRPTY_VAL_TXT FROM APLCTN_PRPTY where APLCTN_PRPTY_NM = 'COC_LAB_MIN_LABS' and APLCTN_PRPTY_OWNR_NM = 'MW_CONFIG') "; 
		String dir = getSort(request);
		String masked = "asc".equalsIgnoreCase(dir) ? String.valueOf(Integer.MAX_VALUE) : String.valueOf(Integer.MIN_VALUE);

		StringBuilder query = new StringBuilder();

		query.append(" select B.* ")
			.append(" from (SELECT A.*, ")
			.append(" count(*) over () as row_cnt, ")
			.append(" ROW_NUMBER() OVER( ORDER BY ")
			.append(buildSortClause(request))
			.append(" ) as row_nbr ")
			.append(" FROM ( ")
			.append(" select 	ILV.LAB_TAX_ID as LAB_TAX_ID, ")
			.append(" ILV.LAB_NM as LAB_NM, ")
			.append(" ILV.PARG_CD as PARG_CD, ")
			.append(" case when ILV.SM_PCT_STD_RT < 0 then 0.000 else ILV.SM_PCT_STD_RT*100 end as PCT_STD_RT, ")
			.append(" case when ILV.ALWD_AMT < 0 then 0.000 else ILV.ALWD_AMT end as ALWD_AMT, ")
			.append(" case when ILV.UNIT_CNT < 0 then 0.000 else ILV.UNIT_CNT end as UNIT_CNT, ")
			.append(" case when ILV.PROV_CNT < 0 then 0.000 else ILV.PROV_CNT end as PROV_CNT, ")
			.append(" case when ILV.MBR_CNT < 0 then 0.000 else ILV.MBR_CNT end as VIEW_DTL, ")
			.append(" case when dsply_dashes = 'Y' ")
			.append(" then ")
			.append(masked)
			.append(" when ILV.COST_OPRTNTY < 0 then 0.000 else ILV.COST_OPRTNTY end as COST_OPRTNTY, dsply_dashes ")
			.append(" from	( ")
			.append(" SELECT 	LSMRY.LAB_TAX_ID as LAB_TAX_ID, LSMRY.LAB_NM AS LAB_NM,  ")
			.append(" LSMRY.PARG_CD AS PARG_CD, ")
			.append(" case when sum(LSMRY.TOTL_ALWD_AMT)>0 and sum(LSMRY.STNDRD_RT_AMT) > 0 then ")
			.append(" cast (sum(LSMRY.TOTL_ALWD_AMT) as decimal(18,3))/ cast(sum(LSMRY.STNDRD_RT_AMT) as decimal(18,3))  ")
			.append(" else 0.000 end as SM_PCT_STD_RT, ")
			.append(" sum(LSMRY.TOTL_ALWD_AMT) AS ALWD_AMT,  ")
			.append(" sum(LSMRY.UNIT_CNT) AS UNIT_CNT,  ")
			.append(" COUNT(distinct LSMRY.IP_DIM_KEY) AS PROV_CNT, ")
			.append(" sum(LSMRY.MBR_CNT) AS MBR_CNT,  ")
			.append(" sum(LSMRY.COST_OPRTNTY_AMT) AS COST_OPRTNTY, ")
			.append(" case when ")
			.append(dashesClause)
			.append(" then 'Y' else 'N' end as dsply_dashes ")
			.append(" FROM 	COC_LAB_PROV_SMRY AS LSMRY ")
			.append(" join poit_user_scrty_acs pusa on (LSMRY.prov_grp_id = pusa.prov_grp_id  ")
			.append(" and   case   when  pusa.prov_org_tax_id = '0' then  LSMRY.prov_org_tax_id  ")
			.append(" else  pusa.prov_org_tax_id   end = LSMRY.prov_org_tax_id ) ")
			.append(" where    pusa.sesn_id = ?  ")
			.append(" and pusa.enttlmnt_hash_key = ?  ");

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
			query.append(" and LSMRY.PROV_GRP_ID in (" +
				StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "GRP")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
			query.append(" and LSMRY.PGM_DIM_KEY in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "PGM")) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
			query.append(" and LSMRY.LOB_DESC in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(StringUtil.getUnsuppressedValuesForTapId(request, "LOB")) + ") ");
		}

		// Organization filter
		if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
			query.append(" and LSMRY.IP_DIM_KEY in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProvDimKeys()) + ") ");
		}

		if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
			query.append(" and LSMRY.PROV_ORG_DIM_KEY in ("
				+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getOrgDimKeys())
				+ ") ");
		}
		//PCMSP-20002
		if (StringUtil.isNotBlankOrFalse(request.getScorecardAnalysisOfDate())) {
			query.append(" and upper(lsmry.rpt_type_ind) = 'SC' ");
		}else{
			query.append(" and upper(lsmry.rpt_type_ind) = 'COC' ");
		}

		query.append(" GROUP BY LSMRY.LAB_TAX_ID,LSMRY.LAB_NM, LSMRY.PARG_CD ) AS ILV ) AS A) AS B");
		/*if (!exportFlag) {
			query.append(" where B.row_nbr between ? and ? ");
		}
		query.append(" order by B.row_nbr ")*/
		query.append(" where B.row_nbr between ? and ? ");
		query.append(" order by B.row_nbr ");

		try {
			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;

			int start = 0;
			int stop = 0;
			
			prepareStatement(logger, query.toString());
			ps.setString(++i, request.getSessionId());
			ps.setString(++i, request.getEntitlementId());


			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "GRP"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "GRP").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}


			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "PGM"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "PGM").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}


			if (StringUtil.isNotBlankOrFalse(StringUtil.getUnsuppressedValuesForTapId(request, "LOB"))) {
				String[] array = StringUtil.getUnsuppressedValuesForTapId(request, "LOB").split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (StringUtil.isNotBlankOrFalse(request.getProvDimKeys())) {
				String[] array = request.getProvDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, StringUtil.parseProviderId(item));
				}
			}
			if (StringUtil.isNotBlankOrFalse(request.getOrgDimKeys())) {
				String[] array = request.getOrgDimKeys().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}

			if (!exportFlag) {
				start = (null != request.getStart()) ? Integer.parseInt(request.getStart()) : 0;
				stop = (null != request.getLimit()) ? Integer.parseInt(request.getLimit()) : 100;
			}
			else {
				start = index;
				stop = limit;
			}
			ps.setInt(++i, start + 1);
			ps.setInt(++i, start + stop);

			executeQuery(logger, query.toString());
			resultList = convertSelectedRowsToObjects(rs, request, exportFlag, displayDashesSmry /*, displayDashesLabProv*/);

		}
		catch (Exception e) {
			throw new Exception("Exception during LabSubMetricFactsDao (" + request.toString() + ").", e);
		}
		finally {

			close();
		}

		return resultList;

	}

	//PCMSP-10846
	protected String getSort(GetLabCostOppByLabRequest request) {
		String dir = "";
		if (CollectionUtils.isNotEmpty(request.getSort())
			&& request.getSort().get(0) != null
			&& StringUtils.isNotBlank(request.getSort().get(0).getDirection())) {
			dir = request.getSort().get(0).getDirection();
		}
		return dir;
	}
	
	private String buildSortClause(GetLabCostOppByLabRequest request) {
		StringBuilder query = new StringBuilder();
		String defaultSort = ", A.LAB_NM asc ";

		if (null != request.getSort()) {
			for (QuerySort sort : request.getSort()) {

				String dir = sort.getDirection().replaceAll("\"", "");
				String property = sort.getProperty();

				if (property.equals("labName")) {
					query.append("  A.LAB_NM " + dir);
				}
				else if (property.equals("networkStatus")) {
					query.append("  A.PARG_CD " + dir + defaultSort);
				}

				else if (property.equals("stdRate")) {
					query.append(" case when  A.PCT_STD_RT <0  then 0 else A.PCT_STD_RT end  " + dir + defaultSort);
				}
				else if (property.equals("unitCount")) {
					query.append(" case when A.UNIT_CNT < 0 then 0 else A.UNIT_CNT end  " + dir + defaultSort);
				}
				else if (property.equals("providerCount")) {
					query.append(" case when A.PROV_CNT < 0 then 0 else A.PROV_CNT end  " + dir + defaultSort);
				}
				else if (property.equals("detailsCount")) {
					query.append(" case when A.VIEW_DTL < 0 then 0 else A.VIEW_DTL end  " + dir + defaultSort);
				}
				else if (property.equals("costOpportunity")) {
					query.append(" case when A.COST_OPRTNTY < 0 then 0 else A.COST_OPRTNTY end  " + dir + defaultSort);
				}
				else {
					query.append("  A.LAB_NM ASC ");
				}
			}
		}
		else {
			query.append("  A.LAB_NM ASC ");
		}
		return query.toString();

	}

	private List<CostOppForLabsBean> convertSelectedRowsToObjects(ResultSet rs, GetLabCostOppByLabRequest request, boolean exportFlag, boolean displayDashesSmry/*, boolean displayDashesLabProv*/)
		throws Exception {
		List<CostOppForLabsBean> results = new ArrayList<CostOppForLabsBean>();

		while (rs.next()) {
			CostOppForLabsBean item = new CostOppForLabsBean();
			

			if (!exportFlag) {
				if (rs.getString("LAB_NM") != null) {
					item.setLabName(rs.getString("LAB_NM").replaceAll("\\s+"," "));
				}

				if (rs.getString("LAB_TAX_ID") != null) {
					item.setLabTaxId(rs.getString("LAB_TAX_ID"));
				}

				if (rs.getString("PARG_CD") != null) {
					item.setNetworkStatus(rs.getString("PARG_CD"));
				}else{
					item.setNetworkStatus(Constants.DASHES);
				}
				if (rs.getBigDecimal("PCT_STD_RT") != null) {
					item.setStdRate(rs.getBigDecimal("PCT_STD_RT").setScale(2, BigDecimal.ROUND_HALF_UP).toString());//Changed for PCMSP-6866
				}else{
					item.setStdRate(Constants.DASHES);
				}
				if (rs.getBigDecimal("UNIT_CNT") != null) {
					item.setUnitCount(rs.getBigDecimal("UNIT_CNT").setScale(0, BigDecimal.ROUND_HALF_UP).toString());//Changed for PCMSP-6866
				}else{
					item.setUnitCount(Constants.DASHES);
				}
				if (rs.getBigDecimal("PROV_CNT") != null) {
					item.setProviderCount(rs.getBigDecimal("PROV_CNT").setScale(0, BigDecimal.ROUND_HALF_UP).toString());//Changed for PCMSP-6866
				}else{
					item.setProviderCount(Constants.DASHES);
				}
				if (rs.getBigDecimal("VIEW_DTL") != null) {
					item.setDetailsCount(rs.getBigDecimal("VIEW_DTL").setScale(0, BigDecimal.ROUND_HALF_UP).toString());//Changed for PCMSP-6866
				}else{
					item.setDetailsCount(Constants.DASHES);
				}
				if (rs.getBigDecimal("COST_OPRTNTY") != null && !displayDashesSmry /*&& !displayDashesLabProv*/ && (rs.getString("dsply_dashes") != null && rs.getString("dsply_dashes").equalsIgnoreCase(Constants.N))) {
					item.setCostOpportunity(rs.getBigDecimal("COST_OPRTNTY").setScale(2, BigDecimal.ROUND_HALF_UP).toString());//Changed for PCMSP-6866
				}else{
					item.setCostOpportunity(Constants.DASHES);
				}

			}
			else {
				
				setTotalExport(rs.getInt("row_cnt"));   

				if (rs.getString("LAB_NM") != null) {
					item.setLabName(rs.getString("LAB_NM").replaceAll("\\s+"," "));
				}

				if (rs.getString("LAB_TAX_ID") != null) {
					item.setLabTaxId(rs.getString("LAB_TAX_ID"));
				}

				if (rs.getString("PARG_CD") != null) {
					item.setNetworkStatus(rs.getString("PARG_CD"));
				}else{
					item.setNetworkStatus(Constants.DASHES);
				}
				if (rs.getBigDecimal("PCT_STD_RT") != null) {
					item.setStdRate(StringUtil.convertStringToCommaBigDecimal(rs.getBigDecimal("PCT_STD_RT").setScale(2, BigDecimal.ROUND_HALF_UP).toString(), 2) + Constants.PERCENT_SIGN);
				}else{
					item.setStdRate(Constants.DASHES);
				}
				if (rs.getBigDecimal("UNIT_CNT") != null) {
					item.setUnitCount(StringUtil.convertStringToCommaBigDecimal(rs.getBigDecimal("UNIT_CNT").setScale(0, BigDecimal.ROUND_HALF_UP).toString(), 0));
				}else{
					item.setUnitCount(Constants.DASHES);
				}
				if (rs.getBigDecimal("PROV_CNT") != null) {
					item.setProviderCount(StringUtil.convertStringToCommaBigDecimal(rs.getBigDecimal("PROV_CNT").setScale(0, BigDecimal.ROUND_HALF_UP).toString(), 0));
				}else{
					item.setProviderCount(Constants.DASHES);
				}
				if (rs.getBigDecimal("COST_OPRTNTY") != null && !displayDashesSmry /*&& !displayDashesLabProv*/ && (rs.getString("dsply_dashes") != null && rs.getString("dsply_dashes").equalsIgnoreCase(Constants.N))) {
					item.setCostOpportunity(StringUtil.convertStringToDecimalCurrency(rs.getBigDecimal("COST_OPRTNTY").setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
				}else{
					item.setCostOpportunity(Constants.DASHES);
				}

			}
			item.setHasDetailsDrilldownInd(request.isHasDetailsDrilldownInd());

			results.add(item);

			if (getRowCount() == 0) {
				setRowCount(rs.getInt("row_cnt"));
			}
		}

		return results;
	}

}
