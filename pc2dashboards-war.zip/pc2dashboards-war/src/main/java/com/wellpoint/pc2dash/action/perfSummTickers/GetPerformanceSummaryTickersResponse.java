package com.wellpoint.pc2dash.action.perfSummTickers;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetPerformanceSummaryTickersResponse extends ActionResponse {

}
