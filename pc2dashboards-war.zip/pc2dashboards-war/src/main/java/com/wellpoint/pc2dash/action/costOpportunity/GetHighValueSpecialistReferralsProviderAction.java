package com.wellpoint.pc2dash.action.costOpportunity;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.action.base.MetaData;
import com.wellpoint.pc2dash.dto.costOpportunity.HighValueSpecialistReferralsProviderBean;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.export.ExportGridColumn;
import com.wellpoint.pc2dash.export.ExportProcessor;
import com.wellpoint.pc2dash.export.costOpportunity.HighValueSpecialistReferralsProviderExport;
import com.wellpoint.pc2dash.service.costOpportunity.HighValueSpecialistReferralsProviderServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetHighValueSpecialistReferralsProviderAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		List<HighValueSpecialistReferralsProviderBean> resultList = null;

		GetHighValueSpecialistReferralsProviderRequest request = (GetHighValueSpecialistReferralsProviderRequest) actionRequest;
		GetHighValueSpecialistReferralsProviderResponse response = new GetHighValueSpecialistReferralsProviderResponse();
		ErrorProperties err = ErrorProperties.getInstance();
		HighValueSpecialistReferralsProviderServiceImpl service = new HighValueSpecialistReferralsProviderServiceImpl();


		List<String> grps = null;

		try {

			removeLobPgmPrefixes(request);

			if (StringUtils.isNotBlank(request.getCmpId())) {
				grps = filterProvGrpsByKillSwitch(request);
			}

			if (null != grps && !grps.isEmpty()) {
				request.setProvGrpIdsWithoutClinicalCheck(StringUtils.join(grps, ','));
				grps = filterProvGrpsByClincalFinancialInd(request, grps);
				request.setProvGrpIds(CollectionUtils.isNotEmpty(grps) ? StringUtils.join(grps, ',') : Constants.DASHES);
			}

			CommonQueries cq = new CommonQueries();
			request.setTapId(request.getMetricViewId());
			request.setSuppression(cq.getActiveSuppressionForSelectComponents(request));
			
			MetaData metaData = new MetaData();
			metaData.setReportingPeriod(cq.getReportingPeriodForCostOpportunity(Constants.HIGH_VALUE_SPECIALIST_REFERRALS));
			metaData.setReportDate(cq.getReportDateForCostOpportunity(Constants.HIGH_VALUE_SPECIALIST_REFERRALS));
			
			if (StringUtil.isExportDest(request.getDest())) {
            	request.setReportingPeriod(metaData.getReportingPeriod());
            	request.setReportDate(metaData.getReportDate());
				List<ExportGridColumn> columns = service.buildExportGridColumns(request);
				HighValueSpecialistReferralsProviderExport exp = new HighValueSpecialistReferralsProviderExport(request, columns);

				ExportProcessor.getInstance().submit(exp);
			}
			else {

				if (null != grps && !grps.isEmpty()) {

					request.setHasEpisodesDrilldownInd(isUserClinical(request));
					resultList = service.getData(request);

					if (null == resultList || resultList.isEmpty()) {
						response.setMessage(err.getProperty("successNoData"));
					}
					else {
						response.setMetaData(metaData);
						response.setMessage(err.getProperty("successful"));
						response.setData(resultList);
						response.setTotal(service.getNoOfRecords());
					}
				}
			}

			response.setSuccess(true);
			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

	}

}
