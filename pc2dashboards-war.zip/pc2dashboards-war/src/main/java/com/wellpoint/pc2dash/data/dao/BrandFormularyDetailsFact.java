package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.Collection;
import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.tooltip.GetPatientDetailRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.utilization.BrandFormularyDetails;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;

public class BrandFormularyDetailsFact extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(BrandFormularyDetailsFact.class);

	public Collection<BrandFormularyDetails> getBrandFormularyDetailsFact(GetPatientDetailRequest request) throws Exception {

		Collection<BrandFormularyDetails> result = new ArrayList<BrandFormularyDetails>();

		setRowCount(0);
		String sql = null;

		sql = buildSqlForProviderPopUpDetails(request);

		try {
			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			buildPreparedStatementForProviderPopUpDetails(request, sql);

			executeQuery(logger, sql);
			while (rs.next()) {
					BrandFormularyDetails r = new BrandFormularyDetails();
					if (rs.getString("DRUG_CLS_NM") != null) {
						r.setDrugClass(rs.getString("DRUG_CLS_NM"));
					}
					r.setNfClaimCount(rs.getInt("clm_cnt"));
					r.setFormularyBrandDrugsCnt(rs.getInt("formularyBrndDrugsCnt")); /*PCMSP-18705*/
					result.add(r);
			}

		}
		catch (Exception e) {
			throw new Exception("Exception during getBrandFormularyDetailsFact (" + request.toString() + ").", e);
		}
		finally {

			close();
		}

		return result;

	}

	//Added for PCMSP-9484 : Starts
	public Collection<BrandFormularyDetails> getBrandFormularyPrescriberDetailsFact(GetPatientDetailRequest request) throws Exception {

		Collection<BrandFormularyDetails> result = new ArrayList<BrandFormularyDetails>();

		setRowCount(0);
		String sql = null;

		sql = buildSqlForPrescriberPopUpDetails(request);

		try {
			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			buildPreparedStatementForPrescriberPopUpDetails(request, sql);

			executeQuery(logger, sql);
			while (rs.next()) {
				BrandFormularyDetails r = new BrandFormularyDetails();
				if (rs.getString("DRUG_CLS_NM") != null) {
					r.setDrugClass(rs.getString("DRUG_CLS_NM"));
				}
				r.setNfClaimCount(rs.getInt("clm_cnt"));
				r.setFormularyBrandDrugsCnt(rs.getInt("formularyBrndDrugsCnt"));/*PCMSP-18705*/
				result.add(r);
			}

		}
		catch (Exception e) {
			throw new Exception("Exception during getBrandFormularyPrescriberDetailsFact (" + request.toString() + ").", e);
		}
		finally {

			close();
		}

		return result;

	}

	//Added for PCMSP-9484 : Ends
	private void buildPreparedStatementForProviderPopUpDetails(GetPatientDetailRequest request, String sql) throws Exception {


		int i = 0;
		prepareStatement(logger, sql);
		if (null != request.getMeasureName() && request.getMeasureName().equalsIgnoreCase(Constants.FRMLY)) {
			if (StringUtil.isNotBlankOrFalse(request.getPhrmcyMsrIds())) {
				String[] array = request.getPhrmcyMsrIds().split(",");
				for (String item : array) {
					ps.setString(++i, item.trim());
				}
			}
		}
		ps.setString(++i, StringUtil.parseProviderId(request.getProviderId()));

		// same order of null checks as buildSql() to make sure markers are populated correctly
		if (!StringUtils.isBlank(request.getProvGrpIds())) {
			ps.setString(++i, request.getProvGrpIds());
		}
		ps.setString(++i, request.getSessionId());

		ps.setString(++i, request.getEntitlementId());

		if (null != request.getMeasureName() && (request.getMeasureName().contains(Constants.FRMLY))) {

			if (!StringUtils.isBlank(request.getProgramId())) {
				ps.setString(++i, request.getProgramId());
			}

			//			if (StringUtil.isNotBlankOrFalse(request.getParentId()) && !request.getParentId().equalsIgnoreCase(Constants.ZERO)) {
			//				ps.setString(++i, request.getScoreId());
			//			}

			if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
				ps.setString(++i, request.getMeasurementPeriodStartDt());
				//adding analysis as of date to be in sync with utilization patients -- Varun
				//				CommonQueries cq = new CommonQueries();
				//				//String aaod = cq.selectAAODOther(request.getProgramId(), request.getMeasurementPeriodStartDt());
				//				String aaod = cq.selectAAODOther(request.getProgramId(), request.getMeasurementPeriodStartDt(), request.getProvGrpIds()); //PCMSP-13914
				//				ps.setString(++i, aaod);
			}

			//			if (StringUtil.isNotBlankOrFalse(request.getPhrmcyMsrIds()) && StringUtil.isNotBlankOrFalse(request.getParentId())
			//				&& request.getParentId().equalsIgnoreCase(Constants.ZERO)) {
			//				String[] msrIdarray = request.getPhrmcyMsrIds().split(",");
			//				for (String item : msrIdarray) {
			//					ps.setString(++i, item.trim());
			//				}
			//			}

			if(!StringUtils.isBlank(request.getProviderId())){
				String orgKey = request.getProviderId().substring(request.getProviderId().lastIndexOf("_") +1);
				ps.setString(++i, orgKey);
			}
			if (StringUtil.isNotBlankOrFalse(request.getDrugClassKeys())) {
				if (!StringUtils.isBlank(request.getProvGrpIds())) {
					ps.setString(++i, request.getProvGrpIds());
				}
				if (!StringUtils.isBlank(request.getProgramId())) {
					ps.setString(++i, request.getProgramId());
				}

				if (StringUtil.isNotBlankOrFalse(request.getDrugClassKeys())) {
					ps.setString(++i, StringUtil.parseProviderId(request.getProviderId()));
					String[] array = request.getDrugClassKeys().split(",");
					for (String item : array) {
						ps.setString(++i, item);
					}
				}
			}
		}

	}

	//Added for PCMSP-9484 : Starts
	private void buildPreparedStatementForPrescriberPopUpDetails(GetPatientDetailRequest request, String sql) throws Exception {
		int i = 0;
		prepareStatement(logger, sql);
		if (null != request.getMeasureName() && request.getMeasureName().equalsIgnoreCase(Constants.FRMLY)) {
			if (StringUtil.isNotBlankOrFalse(request.getPhrmcyMsrIds())) {
				String[] array = request.getPhrmcyMsrIds().split(",");
				for (String item : array) {
					ps.setString(++i, item.trim());
				}
			}
		}
		ps.setString(++i, request.getPrescriberId());


		if (!StringUtils.isBlank(request.getProvGrpIds())) {
			ps.setString(++i, request.getProvGrpIds());
		}

		ps.setString(++i, request.getSessionId());

		ps.setString(++i, request.getEntitlementId());


		if (null != request.getMeasureName() && (request.getMeasureName().contains(Constants.FRMLY))) {

			if (!StringUtils.isBlank(request.getProgramId())) {
				ps.setString(++i, request.getProgramId());
			}
		}

		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
			ps.setString(++i, request.getMeasurementPeriodStartDt());

		}



		if (StringUtil.isNotBlankOrFalse(request.getDrugClassKeys())) {
			if (!StringUtils.isBlank(request.getProvGrpIds())) {
				ps.setString(++i, request.getProvGrpIds());
			}
			if (!StringUtils.isBlank(request.getProgramId())) {
				ps.setString(++i, request.getProgramId());
			}

			if (StringUtil.isNotBlankOrFalse(request.getDrugClassKeys())) {
				ps.setString(++i, StringUtil.parseProviderId(request.getPrescriberId()));
				String[] array = request.getDrugClassKeys().split(",");
				for (String item : array) {
					ps.setString(++i, item);
				}
			}
		}
	}


	//Added for PCMSP-9484 : Ends

	private String buildSqlForProviderPopUpDetails(GetPatientDetailRequest request) {

		StringBuilder sql = new StringBuilder()
			.append(" select A.* ")
			.append(" from( ")
			.append(" select  row_number() over (order by SUM(SFPS.NONF_CLM_CNT)) as rank, ")
			.append(" SFPS.DRUG_CLS_NM as drug_cls_nm,  ")
			.append(" SUM(SFPS.NMRTR_CNT) as  formularyBrndDrugsCnt, ")/*PCMSP-18705*/
			.append(" SUM(SFPS.NONF_CLM_CNT) as clm_cnt, ")
			.append(" count(*) over () as row_cnt ");

		sql.append(" from ")
			.append(" SCRCRD_FRMLRY_PROV_SMRY SFPS ")
			//			.append(" join IP_DIM IP on (SFPS.IP_DIM_KEY = IP.IP_DIM_KEY) ")
			.append(" join  PROV_GRP_DIM PGD ON (SFPS.PROV_GRP_DIM_KEY = PGD.PROV_GRP_DIM_KEY) ")
			.append(" join PGM_DIM PD ON (SFPS.PGM_DIM_KEY = PD.PGM_DIM_KEY)  ")
			.append(" join prov_org_dim pod on (SFPS.PROV_ORG_DIM_KEY = POD.PROV_ORG_DIM_KEY) ")
			.append(getPoitTableJoin())
			.append(" JOIN (SELECT MD.MSR_DIM_KEY ")
			.append(" FROM MSR_DIM MD ")
			//			.append(" WHERE CURRENT_DATE BETWEEN MD.MSR_EFCTV_DT AND MD.MSR_TRMNTN_DT");
			.append(" Where  ")
			.append("  MD.MSR_SRC_CD = 'SCRCRD' ")
			.append(" AND MD.RCRD_STTS_CD = 'ACT' ");
		if (null != request.getMeasureName() && request.getMeasureName().equalsIgnoreCase(Constants.FRMLY)) {
			if (StringUtil.isNotBlankOrFalse(request.getPhrmcyMsrIds())) {
				sql.append(" and md.msr_id in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getPhrmcyMsrIds())
					+ ") ");
			}
		}
		sql.append(" GROUP BY MD.MSR_DIM_KEY) MD_I  ")
			.append(" ON MD_I.MSR_DIM_KEY = SFPS.MSR_DIM_KEY ")

			.append(" Where SFPS.IP_DIM_KEY = ? ");
		if (!StringUtils.isBlank(request.getProvGrpIds())) {
			sql.append(" and pgd.prov_grp_id = ? "); // providerGroupId
		}
		sql.append(getPoitTableWhere());

		if (!StringUtils.isBlank(request.getProgramId())) {
			sql.append("and pd.pgm_id = ? "); // programId
		}

		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
			sql.append("and SFPS.msrmnt_prd_strt_dt = ? "); // measurementPeriodStartDt
			//				sql.append("and SFPS.ANLYSS_AS_OF_DT = ? ");
		}

		//Add Organization filter
		if(!StringUtils.isBlank(request.getProviderId())){
			sql.append("and SFPS.PROV_ORG_DIM_KEY= ? ");
		}
		if (StringUtil.isNotBlankOrFalse(request.getDrugClassKeys())) {
			sql.append("and SFPS.IP_DIM_KEY IN  ")
				.append(" (SELECT SFPS1.IP_DIM_KEY  ")
				.append(" FROM SCRCRD_FRMLRY_PROV_SMRY SFPS1 ")
				.append(" JOIN PROV_GRP_DIM PGD1 ON (SFPS1.PROV_GRP_DIM_KEY = PGD1.PROV_GRP_DIM_KEY )");
			if (!StringUtils.isBlank(request.getProvGrpIds())) {
				sql.append("and PGD1.prov_grp_id = ? "); // providerGroupId
			}

			sql.append(" JOIN PGM_DIM PD1 ON (SFPS1.PGM_DIM_KEY = PD1.PGM_DIM_KEY )");
			if (!StringUtils.isBlank(request.getProgramId())) {
				sql.append("and PD1.pgm_id = ? "); // programId
			}

			if (StringUtil.isNotBlankOrFalse(request.getDrugClassKeys())) {
				sql.append(" WHERE SFPS1.ip_dim_key = ? and SFPS1.GPI_04_CLS_CD IN ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getDrugClassKeys())
					+ ") ");
			}
			sql.append(" GROUP BY SFPS1.IP_DIM_KEY) ");
		}
		sql.append(" group by SFPS.ip_dim_key, SFPS.DRUG_CLS_NM )A ");



		sql.append("with ur");

		return sql.toString();
	}

	//Added for PCMSP-9484 : Starts
	private String buildSqlForPrescriberPopUpDetails(GetPatientDetailRequest request) {


		StringBuilder sql = new StringBuilder()
			.append(" select A.* ")
			.append(" from ( ")
			.append(" select  row_number() over ( order by clm_cnt DESC ) as rank, ")
			.append(" drug_cls_nm , ")
			.append(" formularyBrndDrugsCnt, ")/*PCMSP-18705*/
			.append(" clm_cnt , ")
			.append(" count(*) over () as row_cnt from ( ")
			.append(" select SFPS.DRUG_CLS_NM as drug_cls_nm,  ")
			.append(" SUM(SFPS.NMRTR_CNT) as  formularyBrndDrugsCnt, ")/*PCMSP-18705*/
			.append(" SUM(SFPS.NONF_CLM_CNT) as clm_cnt ")
			.append(" from ")
			.append(" SCRCRD_FRMLRY_PRSCRBR_SMRY SFPS ")
			.append(" join  PROV_GRP_DIM PGD ON (SFPS.PROV_GRP_DIM_KEY = PGD.PROV_GRP_DIM_KEY) ")
			.append(" join PGM_DIM PD ON (SFPS.PGM_DIM_KEY = PD.PGM_DIM_KEY)  ")
			
			 .append(" join prov_org_dim pod on (SFPS.PROV_ORG_DIM_KEY = POD.PROV_ORG_DIM_KEY) ")
			 .append(getPoitTableJoin()) 
			
			.append(" JOIN (SELECT MD.MSR_DIM_KEY ")
			.append(" FROM MSR_DIM MD ")
			.append(" Where  ")
			.append("  MD.MSR_SRC_CD = 'SCRCRD' ")
			.append(" AND MD.RCRD_STTS_CD = 'ACT' ");
		if (null != request.getMeasureName() && request.getMeasureName().equalsIgnoreCase(Constants.FRMLY)) {
			if (StringUtil.isNotBlankOrFalse(request.getPhrmcyMsrIds())) {
				sql.append(" and md.msr_id in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getPhrmcyMsrIds())
					+ ") ");
			}
		}
		sql.append(" GROUP BY MD.MSR_DIM_KEY) MD_I  ")
			.append(" ON MD_I.MSR_DIM_KEY = SFPS.MSR_DIM_KEY ")
			.append(" Where SFPS.PRSCRBR_IP_DIM_KEY = ? ");

		if (!StringUtils.isBlank(request.getProvGrpIds())) {
			sql.append(" and pgd.prov_grp_id = ? "); // providerGroupId
		}
		sql.append(getPoitTableWhere()); 

		if (!StringUtils.isBlank(request.getProgramId())) {
			sql.append("and pd.pgm_id = ? "); // programId
		}

		if (!StringUtils.isBlank(request.getMeasurementPeriodStartDt())) {
			sql.append("and SFPS.msrmnt_prd_strt_dt = ? ");
		}


		if (StringUtil.isNotBlankOrFalse(request.getDrugClassKeys())) {
			sql.append("and SFPS.PRSCRBR_IP_DIM_KEY IN  ")
				.append(" (SELECT SFPS1.PRSCRBR_IP_DIM_KEY  ")
				.append(" FROM SCRCRD_FRMLRY_PRSCRBR_SMRY SFPS1 ")
				.append(" JOIN PROV_GRP_DIM PGD1 ON (SFPS1.PROV_GRP_DIM_KEY = PGD1.PROV_GRP_DIM_KEY )");
			if (!StringUtils.isBlank(request.getProvGrpIds())) {
				sql.append("and PGD1.prov_grp_id = ? "); // providerGroupId
			}

			sql.append(" JOIN PGM_DIM PD1 ON (SFPS1.PGM_DIM_KEY = PD1.PGM_DIM_KEY )");
			if (!StringUtils.isBlank(request.getProgramId())) {
				sql.append("and PD1.pgm_id = ? "); // programId
			}

			if (StringUtil.isNotBlankOrFalse(request.getDrugClassKeys())) {
				sql.append(" WHERE SFPS1.PRSCRBR_IP_DIM_KEY = ? and SFPS1.GPI_04_CLS_CD IN ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getDrugClassKeys())
					+ ") ");
			}
			sql.append(" GROUP BY SFPS1.PRSCRBR_IP_DIM_KEY) ");
		}
		sql.append(" group by SFPS.PRSCRBR_IP_DIM_KEY, SFPS.DRUG_CLS_NM ))A ");



		sql.append("with ur");

		return sql.toString();
	}
	//Added for PCMSP-9484

	public String getPoitTableJoin() {
		StringBuilder from = new StringBuilder();
		from.append("join poit_user_scrty_acs pusa on ( ");
		from.append("pgd.prov_grp_id = pusa.prov_grp_id ");
		from.append("and case ");
		from.append("when pusa.prov_org_tax_id = '0' then pod.prov_org_tax_id ");
		from.append("else pusa.prov_org_tax_id ");
		from.append("end = pod.prov_org_tax_id ");
		from.append(") ");
		return from.toString();
	}

	public String getPoitTableWhere() {
		StringBuilder where = new StringBuilder();
		where.append("and pusa.sesn_id = ? ");
		where.append("and pusa.enttlmnt_hash_key = ? ");
		return where.toString();
	}

	@Override
	public boolean read(Dto o) throws Exception {

		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {


	}

	@Override
	public void update(Dto o) throws Exception {


	}

	@Override
	public void delete(Dto o) throws Exception {


	}

}
