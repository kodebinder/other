package com.wellpoint.pc2dash.action.quickLinks;

import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.data.dao.AppProperties;
import com.wellpoint.pc2dash.data.dao.QuickLinks;
import com.wellpoint.pc2dash.data.dto.AppProperty;
import com.wellpoint.pc2dash.dto.quickLinks.QuickLinksBean;
import com.wellpoint.pc2dash.dto.quickLinks.QuickLinksJson;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;


public class GetQuickLinksAction extends Action {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetQuickLinksAction.class);

	public ActionResponse process(ActionRequest actionRequest) {

		ActionResponse result = new GetQuickLinksResponse();
		GetQuickLinksRequest request = (GetQuickLinksRequest) actionRequest;

		try {

			QuickLinks dao = new QuickLinks();
			Collection<Object> links = new ArrayList<Object>();

			/*
			 * Toggle between old and new queries for now
			 */
			Collection<QuickLinksBean> quickLinks = getQuickLinksViaToggle(request, dao);

			for (QuickLinksBean link : quickLinks) {

				/*
				 * Check for disabled link.
				*/
				if (!"Y".equalsIgnoreCase(link.getLnkDisbldInd())) {

					QuickLinksJson json = new QuickLinksJson();
					json.setId(link.getLnkId());
					json.setCategory(link.getLnkCtgryDesc());
					json.setText(link.getLnkMsgTxt());
					json.setUrl(link.getLnkUrlTxt());
					json.setExternalLinkInd(link.getExtrnlLnkInd());

					/*
					 * Update Day 1 and CPC links.
					*/
					if (link.getLnkTypeDesc().equalsIgnoreCase("Day1") || link.getLnkTypeDesc().equalsIgnoreCase("CPC")) {

						String url = link.getLnkUrlTxt().trim();
						String host = request.getRequestUrl();

						/*
						 * Modify URL based on host name.
						*/
						if (host.contains("anthem"))
							url = url.replace("wellpoint", "anthem");
						if (host.contains("unicare"))
							url = url.replace("wellpoint", "unicare");

						/*
						 * Append appropriate entitlement id.
						*/
						if (link.getLnkTypeDesc().equalsIgnoreCase("CPC")) {
							url += request.getCpcEntitlementId();
						}
						else {
							url += request.getEntitlementId();
						}

						json.setUrl(url);
					}

					/*
					 * Update document links.
					*/
					if (link.getLnkTypeDesc().equalsIgnoreCase("popmngdoc") || link.getLnkTypeDesc().equalsIgnoreCase("perfmngdoc")) {
						json.setUrl("Controller?cmd=getQuickLinkDocument&dest=file&lnkId=" + link.getLnkId());
					}

					/*
					 * Append link to result set.
					*/
					links.add(json);
				}
			}

			result.setData(links);
			result.setTotal(links.size());
			result.setSuccess(true);
		}
		catch (Exception e) {

			logger.error("Unable to retrieve quick links.", e);

			result.setMessage("Unable to retrieve quick links.");
			result.setSuccess(false);
		}

		return result;
	}

	protected Collection<QuickLinksBean> getQuickLinksViaToggle(GetQuickLinksRequest request, QuickLinks dao) throws Exception {
		AppProperties props = new AppProperties();
		AppProperty prop = props.getAppProperty("ADMIN_CONFIG", "useLnkAcsQuery");

		Collection<QuickLinksBean> quickLinks;
		if (prop != null && "true".equalsIgnoreCase(prop.getValue())) {
			quickLinks = dao.getQuickLinks_Acs(request);
		}
		else {
			quickLinks = dao.getQuickLinks(request);
		}
		return quickLinks;
	}
}
