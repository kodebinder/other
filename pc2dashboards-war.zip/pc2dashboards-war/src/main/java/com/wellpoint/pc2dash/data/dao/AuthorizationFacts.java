package com.wellpoint.pc2dash.data.dao;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.data.dto.AuditEntry;
import com.wellpoint.pc2dash.data.dto.PCMSRequest;
import com.wellpoint.pc2dash.dto.patient.InpatientAdmissions;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.QueryConstants;


public class AuthorizationFacts extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(AuthorizationFacts.class);
	private boolean attested = false;
	private boolean sensitive = false;
	
	public boolean read(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void insert(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void update(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void delete(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public Collection<InpatientAdmissions> getInpatientAdmissions(PCMSRequest request) throws Exception {

		Collection<InpatientAdmissions> result = new ArrayList<InpatientAdmissions>();

		StringBuilder sql = new StringBuilder()
			.append("select ")
			.append("	af.authrzd_fclty_nm, ")
			.append("	af.authrzd_days_qty, ")
			.append("	af.admt_dt, ")
			.append("	coalesce(af.dschrg_dt, af.admt_dt + af.authrzd_days_qty days) as dschrg_dt, ")
			//.append("	cd.cd_val_nm as admt_diag_cd, ")
			//.append("	cd.CD_VAL_LONG_DESC as admt_diag_cd, ")
			.append("	(case when cd.cd_set_nm like '%ICD9' then cd.cd_val_nm else cd.cd_val_long_desc end ) as admt_diag_cd , ")
			.append("	round(af.readmsn_risk_pct, 2) as readmsn_risk_pct, ")
			.append("	case ")
			.append("		when af.dschrg_dt is null then 1 ")
			.append("		else 0 ")
			.append("	end as dschrg_dt_ind, ")
			.append("	cd.snstv_cd ")
			.append("from ")
			.append("	authrzn_fact af ")
			.append("	join mstr_cnsmr_fact mcf on (af.mstr_cnsmr_dim_key = mcf.mstr_cnsmr_dim_key) ")
			.append("	join "+QueryConstants.diagnosisDataQuery()+" cd on (af.diag_cd_dim_key = cd.cd_dim_key) ")
			.append("	join poit_user_scrty_acs pusa on ( ")
			.append("		mcf.prov_grp_id = pusa.prov_grp_id ")
			.append("		and case ")
			.append("				when pusa.prov_org_tax_id = '0' then mcf.prov_org_tax_id ")
			.append("				else pusa.prov_org_tax_id ")
			.append("			end = mcf.prov_org_tax_id ")
			.append("	) ")
			.append("where ")
			.append("	pusa.sesn_id = ? ")
			.append("	and pusa.enttlmnt_hash_key = ? ")
			.append("	and mcf.mstr_cnsmr_dim_key = ? ")
			.append("	and af.authrzd_stts_ind_cd = 'Y' ")
			.append("order by ")
			.append("	af.admt_dt ")
			.append("with ur ");

		//		logger.debug("getInpatientAdmissions SQL: " + sql.toString());

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());
			ps.setString(1, request.getSessionId());
			ps.setString(2, request.getEntitlementId());
			ps.setString(3, request.getMemberKey());

			//logger.debug("sesn_id: " + request.getSessionId());
			//logger.debug("enttlmnt_hash_key: " + request.getEntitlementId());
			//logger.debug("mstr_cnsmr_dim_key: " + request.getMemberKey());

			executeQuery(logger, sql.toString());
			
			attested = CommonQueries.checkAttestation(request);
			
			while (rs.next()) {

				InpatientAdmissions r = new InpatientAdmissions();
				r.setFacilityName(getString(rs, "authrzd_fclty_nm"));
				r.setLengthOfStay(rs.getBigDecimal("authrzd_days_qty")); /* add helper? */
				r.setAdmissionDate(getDate(rs, "admt_dt"));
				r.setDischargeDate(getDate(rs, "dschrg_dt"));
				if(Constants.ONE.equalsIgnoreCase(getString(rs, "snstv_cd"))){
					if(attested)
						r.setAdmittingDiagnosis(getString(rs, "admt_diag_cd"));
					else{
						r.setAdmittingDiagnosis(Constants.RA_MASK);
						sensitive = true;
					}
				}
				else
					r.setAdmittingDiagnosis(getString(rs, "admt_diag_cd"));
				//changes done for AP53630
				if (rs.getBigDecimal("readmsn_risk_pct") != null)
				{
					r.setReadmissionRisk(rs.getBigDecimal("readmsn_risk_pct").setScale(2, BigDecimal.ROUND_HALF_UP).toString());
				}
				else
				{
					r.setReadmissionRisk("---");
				}
				//end of changes
				r.setDischargeDateCalculated(getInt(rs, "dschrg_dt_ind"));

				result.add(r);
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get inpatient admissions (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}
	
	public boolean isAttested() {
		return attested;
	}

	public boolean isSensitive() {
		return sensitive;
	}
}
