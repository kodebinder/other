package com.wellpoint.pc2dash.action.pharmacy;

import java.util.List;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.data.dao.PharmacyDrugClassFilter;
import com.wellpoint.pc2dash.dto.pharmacy.DrugClassFilter;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.ErrorProperties;

public class GetCostOfCareDrugClassFilterAction extends Action {

    private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetCostOfCareDrugClassFilterAction.class);

    List<DrugClassFilter> resultList;
    ActionResponse response = new GetDrugClassFilterResponse();
    ErrorProperties err = ErrorProperties.getInstance();

    @Override
    public ActionResponse process(ActionRequest actionRequest) {

        GetDrugClassFilterRequest request = (GetDrugClassFilterRequest) actionRequest;
        PharmacyDrugClassFilter dao = new PharmacyDrugClassFilter();

        try {
            resultList = dao.getCostOfCarePharmacyDrugDetails(request);

            if (null == resultList || resultList.isEmpty()) {
                response.setMessage(err.getProperty("successNoData"));
            }
            else {
                response.setData(resultList);
                response.setMessage(err.getProperty("successful"));
            }

            response.setSuccess(true);
            return response;
        }
        catch (Exception pe) {

            logger.error("Unable to get GetCostOfCareDrugClassFilterAction.", pe);

            Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
            return pce.checkException(pe, response);
        }

    }
}
