package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.data.dto.PCMSRequest;
import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;
import com.wellpoint.pc2dash.dto.scorecard.ScorecardCompositeBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.DateUtil;
import com.wellpoint.pc2dash.util.StringUtil;


public class EsnMedicareScorecardByCompositeFactsDao extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(EsnMedicareScorecardByCompositeFactsDao.class);

	public boolean read(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void insert(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void update(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void delete(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public Collection<ScorecardCompositeBean> getEsnScorecardComposites(PerformanceManagementRequest request) throws Exception {


		Collection<ScorecardCompositeBean> result = new ArrayList<ScorecardCompositeBean>();
		StringBuilder sql = new StringBuilder();

			
			sql = createQueryForQuality(request)
				.append(" UNION ")
				.append(createQueryForUtilization(request));

		sql = StringUtil.appendWithUr(sql);

		try {

			int i = 1;

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			prepareStatement(logger, sql.toString());

			//for (int q = 0; q < 2; q++) {

				ps.setString(i++, request.getProgramId());
				ps.setString(i++, request.getMeasurementPeriodStartDt());
				ps.setString(i++, request.getProvGrpIds());
				ps.setString(i++, request.getProgramLobTypeCd().toUpperCase());

				if (null != Constants.getQuarterName(request.getMeasurementInterval())) {
					if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
						ps.setString(i++, "Y");
					}
					else {
						ps.setString(i++, Constants.getQuarterName(request.getMeasurementInterval()));
					}

				}
				else {
					ps.setString(i++, request.getProvGrpIds());
					ps.setString(i++, request.getProgramId());
					ps.setString(i++, request.getMeasurementPeriodStartDt());
					ps.setString(i++, request.getProgramId());

				}
				
				ps.setString(i++, request.getProgramId());
				ps.setString(i++, request.getMeasurementPeriodStartDt());
				ps.setString(i++, request.getProvGrpIds());
				ps.setString(i++, request.getProgramLobTypeCd().toUpperCase());

				if (null != Constants.getQuarterName(request.getMeasurementInterval())) {
					if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
						ps.setString(i++, "Y");
					}
					else {
						ps.setString(i++, Constants.getQuarterName(request.getMeasurementInterval()));
					}

				}
				else {
					ps.setString(i++, request.getProvGrpIds());
					ps.setString(i++, request.getProgramId());
					ps.setString(i++, request.getMeasurementPeriodStartDt());
					ps.setString(i++, request.getProgramId());

				}
			//}

			executeQuery(logger, sql.toString());

			while (rs.next()) {

				ScorecardCompositeBean sc = new ScorecardCompositeBean();
				sc.setCompositeId(getString(rs, "cmpst_defn_id"));
				sc.setCompositeName(getString(rs, "cmpst_nm"));
				sc.setCompositeTypeDesc(getString(rs, "cmpst_type_desc"));
				sc.setSsavUpsdDstrbnPct(getString(rs, "ssav"));
				sc.setErncntrPct(getString(rs, "erncntr"));
				sc.setQualityGate(getString(rs, "qlty_gate_thrshld_pct"));
				sc.setQualityScore(getString(rs, "qlty_scor_pct"));
				sc.setQualityGateInd(getString(rs, "qlty_gate_ind"));
				if(rs.getString("anlyss_as_of_dt") != null && rs.getString("incrd_thru_dt") != null){
				sc.setAnlyssAsOfDt(DateUtil.formatDateToMMDDYYYY("yyyy-MM-dd", "MM/dd/yyyy", rs.getDate("anlyss_as_of_dt").toString()));
				sc.setIncrdThruDt(DateUtil.formatDateToMMDDYYYY("yyyy-MM-dd", "MM/dd/yyyy", rs.getDate("incrd_thru_dt").toString()));
				sc.setPcvQualityGate(getString(rs, "pcv_qlty_gate_thrshld_pct"));
				sc.setPcvQualityScore(getString(rs, "pcv_qlty_scor_pct"));
				sc.setPcvQualityGateInd(getString(rs, "pcv_qlty_gate_ind"));
				}

				result.add(sc);
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get EsnMedicareComposite details.", e);
		}
		finally {

			close();
		}
		if (null != result && !result.isEmpty()) {
			Set<ScorecardCompositeBean> resultMap = new HashSet<ScorecardCompositeBean>(result);
			result = new ArrayList<ScorecardCompositeBean>(resultMap);
		}

		return result;
	}

	public StringBuilder createQueryForQuality(PCMSRequest request) {

		StringBuilder sql = new StringBuilder()
			.append("select cmpst_nm, cmpst_defn_id, cmpst_type_desc, sum(erncntr) as erncntr, sum(ssav) as ssav, qlty_gate_thrshld_pct, qlty_scor_pct, qlty_gate_ind,anlyss_as_of_dt,incrd_thru_dt from ( ")
			.append("select ")
			.append(" smhd.cmpst_nm, ")
			.append(" smhd.cmpst_defn_id, ")
			.append(" smhd.cmpst_type_desc, ")
			.append(" ef.rdstrbtd_erncntr_pct as erncntr, ")
			.append(" ef.ssav_upsd_dstrbtn_pct as ssav, ") //PCMSP-19956
			.append(" case when upper(smhd.cmpst_nm) like '%ETG%' then ef.anlyss_as_of_dt else null end as anlyss_as_of_dt, ")
			.append(" case when upper(smhd.cmpst_nm) like '%ETG%' then ef.incrd_thru_dt else null end as incrd_thru_dt, ")
			.append(" smhd.sub_cmpst_nm,")
			.append(" max(case when upper(smhd.cmpst_nm) like '%QUALITY%' then ef.qlty_gate_thrshld_pct end) as qlty_gate_thrshld_pct,  ")
			.append(" max(case when upper(smhd.cmpst_nm) like '%QUALITY%' then ef.qlty_scor_pct end) as qlty_scor_pct,  ")
			.append(" max(case when upper(smhd.cmpst_nm) like '%QUALITY%' then ef.qlty_gate_ind end) as qlty_gate_ind, ")
			.append(" max(case when upper(smhd.cmpst_nm) like '%PER%' then ef.qlty_gate_thrshld_pct end) as pcv_qlty_gate_thrshld_pct,  ")
			.append(" max(case when upper(smhd.cmpst_nm) like '%PER%' then ef.qlty_scor_pct end) as pcv_qlty_scor_pct,  ")
			.append(" max(case when upper(smhd.cmpst_nm) like '%PER%' then ef.qlty_gate_ind end) as pcv_qlty_gate_ind,  ")
			.append(" from ")
			.append(" erncntr_fact ef ")
			.append(" join pgm_dim pgm on ( ")
			.append("   ef.pgm_dim_key = pgm.pgm_dim_key ")
			.append(") ")
			.append(" join prov_grp_dim pg on ( ")
			.append("   ef.prov_grp_dim_key = pg.prov_grp_dim_key ")
			.append(") ")
			.append(" join scrcrd_pgm_msr_hrchy_fact spmhf on ( ")
			.append("   ef.pgm_dim_key = spmhf.pgm_dim_key  and ")
			.append("   ef.trnch_defn_dim_key = spmhf.trnch_defn_dim_key and ")
			.append("   ef.mnth_id = spmhf.mnth_id and ")
			.append("   ef.msrmnt_prd_strt_dt = spmhf.msrmnt_prd_strt_dt ")
			.append(") ")
			.append(" join scrcrd_msr_hrchy_dim smhd on ( ")
			.append("   spmhf.scrcrd_msr_hrchy_dim_key = smhd.scrcrd_msr_hrchy_dim_key ")
			.append(") ")
			.append(" where ")
			.append(" pgm.pgm_id = ? and ")
			.append(" ef.msrmnt_prd_strt_dt = ? and ")
			.append(" pg.prov_grp_id = ? and ")
			.append(" smhd.cmpst_type_desc in ('Quality','Enhanced','Improvement') and ")
			.append(" spmhf.pgm_lob_type_cd = ? ");

		if (null != Constants.getQuarterName(request.getMeasurementInterval())) { // null denotes "Current"
			if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
				sql.append(" AND ef.BSLN_SCRCRD_IND = ? ");
			}
			else {
				sql.append(" AND ef.QTR_ID = ? ");
			}
		}
		else {
			sql.append(" AND EF.MNTH_ID = (SELECT MAX(EF.MNTH_ID) ");
			sql.append(" 					FROM ERNCNTR_FACT EF  ");
			sql.append(" 					INNER JOIN (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT ");
			sql.append(" 								FROM SCRCRD_PGM_MSR_HRCHY_FACT ");
			//sql.append(" 	WHERE PGM_DIM_KEY = (SELECT  PGM_DIM_KEY FROM PROV_GRP_PGM_LOB_FACT WHERE PGM_ID = ? and PGM_PG_TRMNTN_DT > CURRENT_DATE GROUP BY PGM_DIM_KEY) ");
			sql.append(" 		WHERE PGM_DIM_KEY = (SELECT PGM_DIM_KEY FROM PROV_GRP_PGM_LOB_FACT A ");
			sql.append(" 		inner join   PROV_GRP_DIM B ON A.PROV_GRP_DIM_KEY=B.PROV_GRP_DIM_KEY and  B.PROV_GRP_ID = ? ");
			sql.append("		WHERE A.PGM_ID = ? and A.PGM_PG_TRMNTN_DT > CURRENT_DATE GROUP BY A.PGM_DIM_KEY) ");
			sql.append("  and  MSRMNT_PRD_STRT_DT = ? ");
			sql.append(" 								GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM ");
			sql.append(" 					ON EF.PGM_DIM_KEY = SC_PGM.PGM_DIM_KEY AND EF.MSRMNT_PRD_STRT_DT = SC_PGM.MSRMNT_PRD_STRT_DT) ");
			sql.append(
				" and (select max(ef.mnth_id)MAX_MON from ERNCNTR_FACT ef join PGM_DIM pd on ef.pgm_dim_key = pd.pgm_dim_key where pd.pgm_id = ? ) <=  INT(TO_CHAR(ef.msrmnt_prd_strt_dt + 15 months, 'YYYYMM')) ");

		}

		sql.append(
			" group by smhd.CMPST_NM ,smhd.CMPST_DEFN_ID, smhd.CMPST_TYPE_DESC,ef.rdstrbtd_erncntr_pct,ef.ssav_upsd_dstrbtn_pct,smhd.sub_cmpst_nm,case when upper(smhd.cmpst_nm) like '%ETG%' then ef.anlyss_as_of_dt else null end,case when upper(smhd.cmpst_nm) like '%ETG%' then ef.incrd_thru_dt else null end ")
			.append(" order by smhd.CMPST_NM")
			.append(") group by cmpst_nm,cmpst_defn_id, cmpst_type_desc,anlyss_as_of_dt,incrd_thru_dt, qlty_gate_thrshld_pct, qlty_scor_pct, qlty_gate_ind, pcv_qlty_gate_thrshld_pct, pcv_qlty_scor_pct, pcv_qlty_gate_ind ");

		return sql;
	}

	public StringBuilder createQueryForUtilization(PCMSRequest request) {

		StringBuilder sql = new StringBuilder()
			.append("select cmpst_nm, cmpst_defn_id, cmpst_type_desc, sum(erncntr) as erncntr, sum(ssav) as ssav,anlyss_as_of_dt,incrd_thru_dt, qlty_gate_thrshld_pct, qlty_scor_pct, qlty_gate_ind, pcv_qlty_gate_thrshld_pct, pcv_qlty_scor_pct, pcv_qlty_gate_ind from ( ")
			.append("select ")
			.append(" smhd.cmpst_nm, ")
			.append(" smhd.cmpst_defn_id, ")
			.append(" smhd.cmpst_type_desc, ")
			.append(" ef.rdstrbtd_erncntr_pct as erncntr, ")
			.append(" ef.ssav_upsd_dstrbtn_pct as ssav, ") //PCMSP-19956
			.append(" smhd.sub_cmpst_nm,null as anlyss_as_of_dt,null as incrd_thru_dt, ")
			.append(" max(case when upper(smhd.cmpst_nm) like '%QUALITY%' then ef.qlty_gate_thrshld_pct end) as qlty_gate_thrshld_pct,  ")
			.append(" max(case when upper(smhd.cmpst_nm) like '%QUALITY%' then ef.qlty_scor_pct end) as qlty_scor_pct,  ")
			.append(" max(case when upper(smhd.cmpst_nm) like '%QUALITY%' then ef.qlty_gate_ind end) as qlty_gate_ind, ")
			.append(" max(case when upper(smhd.cmpst_nm) like '%PER%' then ef.qlty_gate_thrshld_pct end) as pcv_qlty_gate_thrshld_pct,  ")
			.append(" max(case when upper(smhd.cmpst_nm) like '%PER%' then ef.qlty_scor_pct end) as pcv_qlty_scor_pct,  ")
			.append(" max(case when upper(smhd.cmpst_nm) like '%PER%' then ef.qlty_gate_ind end) as pcv_qlty_gate_ind  ")
			.append(" from ")
			.append(" erncntr_fact ef ")
			.append(" join pgm_dim pgm on ( ")
			.append("   ef.pgm_dim_key = pgm.pgm_dim_key ")
			.append(") ")
			.append(" join prov_grp_dim pg on ( ")
			.append("   ef.prov_grp_dim_key = pg.prov_grp_dim_key ")
			.append(") ")
			.append(" join scrcrd_pgm_msr_hrchy_fact spmhf on ( ")
			.append("   ef.pgm_dim_key = spmhf.pgm_dim_key  and ")
			.append("   ef.trnch_defn_dim_key = spmhf.trnch_defn_dim_key and ")
			.append("   ef.mnth_id = spmhf.mnth_id and ")
			.append("   ef.msrmnt_prd_strt_dt = spmhf.msrmnt_prd_strt_dt ")
			.append(") ")
			.append(" join scrcrd_msr_hrchy_dim smhd on ( ")
			.append("   spmhf.scrcrd_msr_hrchy_dim_key = smhd.scrcrd_msr_hrchy_dim_key ")
			.append(") ")
			.append(" where ")
			.append(" pgm.pgm_id = ? and ")
			.append(" ef.msrmnt_prd_strt_dt = ? and ")
			.append(" pg.prov_grp_id = ? and ")
			.append(" smhd.cmpst_type_desc in ('Utilization') and ")
			.append(" spmhf.pgm_lob_type_cd = ? ");

		if (null != Constants.getQuarterName(request.getMeasurementInterval())) { // null denotes "Current"
			if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
				sql.append(" AND ef.BSLN_SCRCRD_IND = ? ");
			}
			else {
				sql.append(" AND ef.QTR_ID = ? ");
			}
		}
		else {
			sql.append(" AND EF.MNTH_ID = (SELECT MAX(EF.MNTH_ID) ");
			sql.append(" 					FROM ERNCNTR_FACT EF  ");
			sql.append(" 					INNER JOIN (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT ");
			sql.append(" 								FROM SCRCRD_PGM_MSR_HRCHY_FACT ");
			sql.append(" 		WHERE PGM_DIM_KEY = (SELECT PGM_DIM_KEY FROM PROV_GRP_PGM_LOB_FACT A ");
			sql.append(" 		inner join   PROV_GRP_DIM B ON A.PROV_GRP_DIM_KEY=B.PROV_GRP_DIM_KEY and  B.PROV_GRP_ID = ? ");
			sql.append("		WHERE A.PGM_ID = ? and A.PGM_PG_TRMNTN_DT > CURRENT_DATE GROUP BY A.PGM_DIM_KEY) ");
			sql.append("  and  MSRMNT_PRD_STRT_DT = ? ");
			sql.append(" 								GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM ");
			sql.append(" 					ON EF.PGM_DIM_KEY = SC_PGM.PGM_DIM_KEY AND EF.MSRMNT_PRD_STRT_DT = SC_PGM.MSRMNT_PRD_STRT_DT) ");
			sql.append(
				" and (select max(ef.mnth_id)MAX_MON from ERNCNTR_FACT ef join PGM_DIM pd on ef.pgm_dim_key = pd.pgm_dim_key where pd.pgm_id = ? ) <=  INT(TO_CHAR(ef.msrmnt_prd_strt_dt + 15 months, 'YYYYMM')) ");

		}

		sql.append(
			" group by smhd.CMPST_NM ,smhd.CMPST_DEFN_ID, smhd.CMPST_TYPE_DESC,ef.rdstrbtd_erncntr_pct,ef.ssav_upsd_dstrbtn_pct,smhd.sub_cmpst_nm,anlyss_as_of_dt,incrd_thru_dt ")
			.append(" order by smhd.CMPST_NM")
			.append(") group by cmpst_nm,cmpst_defn_id, cmpst_type_desc,anlyss_as_of_dt,incrd_thru_dt, qlty_gate_thrshld_pct, qlty_scor_pct, qlty_gate_ind, pcv_qlty_gate_thrshld_pct, pcv_qlty_scor_pct, pcv_qlty_gate_ind ");

		return sql;
	}


}
