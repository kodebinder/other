package com.wellpoint.pc2dash.action.costOpportunity;

//import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.data.dto.PopulationManagementRequest;

//PCMSP-21873
public class GetTotalSurgeryCountRequest extends PopulationManagementRequest {
	
//	private String providerId;
	private String FacilityTaxId;
	//private String  SessionId;

	public String getFacilityTaxId() {
		return FacilityTaxId;
	}

	public void setFacilityTaxId(String facilityTaxId) {
		FacilityTaxId = facilityTaxId;
	}

	
}
