package com.wellpoint.pc2dash.action.scoreCard;

import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;

public class GetScorecardMeasuresRequest extends PerformanceManagementRequest {

	/*private String subCompositeId;

	public String getSubCompositeId() {
		return subCompositeId;
	}

	public void setSubCompositeId(String subCompositeId) {
		this.subCompositeId = subCompositeId;
	}*/

}
