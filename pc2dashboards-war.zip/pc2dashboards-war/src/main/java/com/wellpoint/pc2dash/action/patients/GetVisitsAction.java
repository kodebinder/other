package com.wellpoint.pc2dash.action.patients;

import java.util.ArrayList;
import java.util.List;
import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.patient.ErVisitTypeFilter;
import com.wellpoint.pc2dash.dto.patient.Visits;
import com.wellpoint.pc2dash.dto.patient.VisitsBean;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.service.patient.VisitsServiceImpl;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;


public class GetVisitsAction extends Action {

	List<Visits> resultList;
	ActionResponse response = new GetVisitsResponse();
	ErrorProperties err = ErrorProperties.getInstance();
	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(GetVisitsAction.class);

	@SuppressWarnings("unchecked")
	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		//PCMSRequest request = new HashMap<String, String>();
		GetVisitsRequest request = (GetVisitsRequest) actionRequest;
		//		if(request.getCardId()!= null){
		//		request.put("cardId", request.getCardId());
		//		}
		VisitsServiceImpl pC2Service = new VisitsServiceImpl();

		try {

			if (request.getCardId() != null) {
				if (request.getCardId().contains("pm-emergencyroomcontainer")) {
					ArrayList<ErVisitTypeFilter> erTypeVisitList = (ArrayList<ErVisitTypeFilter>) pC2Service.getErVisitTypeFilterList(resultList);
					response = populateResponseForErTypeVisit(erTypeVisitList);
					response.setSuccess(true);
				}
				else if (request.getCardId().contains("pm-patientcontainer")) {
					resultList = pC2Service.getData(request);
					ArrayList<VisitsBean> visitList = (ArrayList<VisitsBean>) pC2Service.getBeanList(resultList);
					response = populateResponse(visitList);
					response.setSuccess(true);
					if (resultList.isEmpty()) {
						response.setMessage(err.getProperty("successNoData"));
					}
					else {
						response.setMessage(err.getProperty("successful"));
					}
				}
			}

			return response;
		}
		catch (Exception pe) {

			logger.error("Unable to get visits.", pe);

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}

	private ActionResponse populateResponseForErTypeVisit(ArrayList<ErVisitTypeFilter> erTypeVisitList) {
		response.setMessage(StringUtil.buildMessage(erTypeVisitList.isEmpty()));
		((GetVisitsResponse) response).setText("."); // Currently hardcoded to what UI expects
		((GetVisitsResponse) response).setId("0"); // Currently hardcoded to what UI expects
		((GetVisitsResponse) response).getChildren().addAll(erTypeVisitList);
		return response;
	}

	private ActionResponse populateResponse(ArrayList<VisitsBean> visitList) {
		((GetVisitsResponse) (response)).setData(visitList);
		((GetVisitsResponse) (response)).setChildren(null);
		return response;
	}
}
