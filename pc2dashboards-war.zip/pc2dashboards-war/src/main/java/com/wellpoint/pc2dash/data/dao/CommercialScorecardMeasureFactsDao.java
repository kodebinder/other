package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;
import com.wellpoint.pc2dash.dto.scorecard.ScorecardMeasureBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.DateUtil;
import com.wellpoint.pc2dash.util.StringUtil;

public class CommercialScorecardMeasureFactsDao extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(CommercialScorecardMeasureFactsDao.class);

	public boolean read(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void insert(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void update(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	public void delete(Dto o) throws Exception {
		throw new Exception("Not implemented");
	}

	/**
	 * @param entitlementId
	 * @param provGrpId
	 * @param compositeId
	 * @param subCompositeId
	 * @param msrmntPrdStrtDt
	 * @param msrmntPrdEndDt
	 * @param bslnPrdStrtDt
	 * @param bslnPrdEndDt
	 * @return
	 * @throws Exception
	 */
	public Collection<ScorecardMeasureBean> getScorecardMeasuresQuery(PerformanceManagementRequest request) throws Exception {

		Collection<ScorecardMeasureBean> resultList = new ArrayList<ScorecardMeasureBean>();
		ScorecardMeasureBean measureBean = null;
		
		//PCMSP-10059
				String measStartDate = request.getMeasurementPeriodStartDt();
				boolean isMPGreaterThanOrEqual01012018 = DateUtil.dateComparator(measStartDate, Constants.IND_MTRC_STRT_DT);

		StringBuilder query = new StringBuilder()
			//	.append(" select distinct z.* from ( " 
			.append("  select "
				+ "smhd.CMPST_DEFN_ID, "
				+ "smhd.CMPST_NM, "
				+ " smhd.SUB_CMPST_DEFN_ID,"
				+ " smhd.SUB_CMPST_NM,"
				+ "   msr.MSR_DSPLY_NM, "
				+ "   msr.MSR_DIM_KEY ,"
				+ "  cosf1.MSR_NMRTR_NBR AS COSF_MSR_NMRTR_NBR,"
				+ "  cosf1.MSR_DNMNTR_NBR AS COSF_MSR_DNMNTR_NBR, "
				+ "  cosf1.RISK_ADJSTMNT_FCTR AS COSF_RISK_ADJSTMNT_FCTR,"
				+ "  cpgsf1.MSR_NMRTR_NBR AS CPGSF_MSR_NMRTR_NBR, "
				+ "  cpgsf1.MSR_DNMNTR_NBR AS CPGSF_MSR_DNMNTR_NBR,"
				+ "  cpgsf1.RISK_ADJSTMNT_FCTR AS CPGSF_RISK_ADJSTMNT_FCTR,"
				+ "   cmsf1.MDPNL_DIM_KEY,"
				+ "   cmsf1.MSR_NMRTR_NBR AS CMSF_MSR_NMRTR_NBR,"
				+ "   cmsf1.MSR_DNMNTR_NBR AS CMSF_MSR_DNMNTR_NBR, "
				+ "   cmsf1.RISK_ADJSTMNT_FCTR AS CMSF_RISK_ADJSTMNT_FCTR,"
				+ "   spgmhf.MRKT_RT_PCT, "
				+ "	  EF.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT, "
				+ " smhd.CMPST_TYPE_DESC, cmsf1.mdpnl_id,"
				+ "	cpgsf1.rt_pct as CPGSF_RT_PCT,cmsf1.rt_pct as CMSF_RT_PCT,cosf1.rt_pct as COSF_RT_PCT  "
				/*	+ " , rank() over (partition by ef.prov_grp_dim_key, ef.pgm_dim_key, ef.msrmnt_prd_strt_dt order by case when ef.sor_dtm > pgpa1.prov_grp_pnl_assn_trmntn_dt then 999 " 
					+" else timestampdiff(16, pgpa1.prov_grp_pnl_assn_trmntn_dt - ef.sor_dtm) end, pgpa1.prov_grp_pnl_assn_trmntn_dt desc) as pnl_rank "*/
				+ "from "
				+ " SCRCRD_PGM_MSR_HRCHY_FACT spgmhf "
				+ " INNER JOIN  ERNCNTR_FACT ef"
				+ " 			on  ef.mnth_id = spgmhf.mnth_id "
				+ " AND EF.PGM_DIM_KEY = SPGMHF.PGM_DIM_KEY "
				+ "  AND EF.MSRMNT_PRD_STRT_DT = SPGMHF.MSRMNT_PRD_STRT_DT "
				+ "  AND EF.TRNCH_DEFN_DIM_KEY = SPGMHF.TRNCH_DEFN_DIM_KEY "
				+ "      INNER JOIN SCRCRD_MSR_HRCHY_DIM smhd "
				+ "            on spgmhf.SCRCRD_MSR_HRCHY_DIM_KEY = smhd.SCRCRD_MSR_HRCHY_DIM_KEY "
				+ "      INNER JOIN MSR_DIM  msr "
				+ "            on smhd.msr_dim_key = msr.msr_dim_key"
				+ " and SPGMHF.msrmnt_prd_strt_dt >= msr.MSR_EFCTV_DT and SPGMHF.msrmnt_prd_end_dt <= msr.MSR_TRMNTN_DT"
				+ "      INNER JOIN PGM_DIM pgm "
				+ "      on spgmhf.PGM_DIM_key = pgm.PGM_DIM_KEY"
				+ " inner join PROV_GRP_DIM as PGD on ef.prov_grp_dim_key=pgd.prov_grp_dim_key "
				//	+ " inner join prov_grp_pgm_lob_fact pgplf on ef.prov_grp_dim_key = pgplf.prov_grp_dim_key and ef.pgm_dim_key= pgplf.pgm_dim_key "
				//	+ " inner join lob_dim ld on ld.lob_dim_key = PGPLF.LOB_DIM_KEY "

				/*	+ " inner join "
				    +"   (Select pgpa.prov_grp_dim_key, pgpa.pgm_dim_key, pgpa.mdpnl_dim_key, pgpa.PROV_GRP_PNL_ASSN_EFCTV_DT, pgpa.prov_grp_pnl_assn_trmntn_dt  "
				    +"   FROM prov_grp_pnl_assn_fact pgpa "
				    +"   group by pgpa.prov_grp_dim_key, pgpa.pgm_dim_key, pgpa.mdpnl_dim_key, pgpa.PROV_GRP_PNL_ASSN_EFCTV_DT, pgpa.prov_grp_pnl_assn_trmntn_dt) pgpa1 "
				    +"   on pgm.PGM_DIM_KEY=pgpa1.PGM_DIM_KEY " 
				 //   + " and spgmhf.msrmnt_prd_strt_dt >= pgpa1.PROV_GRP_PNL_ASSN_EFCTV_DT  "      //commented based  on the confirmation from data team since the PG can come in middle of MP
				    +"   inner join prov_grp_dim pgd on pgpa1.prov_grp_dim_key=pgd.prov_grp_dim_key "
				    + "	and ef.prov_grp_dim_key = pgd.prov_grp_dim_key " 
				  //  +"   and pgd.prov_grp_id = ? and  pgd.PROV_GRP_TRMNTN_DT >= pgpa1.prov_grp_pnl_assn_trmntn_dt "
				  + " and pgd.prov_grp_id = ?  and ( ef.msrmnt_prd_strt_dt <= pgpa1.prov_grp_pnl_assn_trmntn_dt and ef.msrmnt_prd_end_dt >= pgpa1.PROV_GRP_PNL_ASSN_EFCTV_DT ) "*/
				+ "    LEFT OUTER JOIN "
				+ "      (select cosf.PGM_DIM_key,cosf.MSRMNT_PRD_STRT_DT,cosf.SCRCRD_MSR_HRCHY_DIM_KEY,"
				+ "      cosf.MSR_NMRTR_NBR,cosf.MSR_DNMNTR_NBR,cosf.RISK_ADJSTMNT_FCTR, POD.PROV_ORG_DIM_KEY, pgd.PROV_GRP_DIM_KEY,cosf.rt_pct"
				+ "            FROM CMPLNC_ORG_SMRY_FACT cosf  "
				+ "            inner join PROV_ORG_DIM  pod"
				+ "           on cosf.PROV_ORG_DIM_KEY = pod.PROV_ORG_DIM_KEY "
				+ "                  and pod.PROV_ORG_DIM_KEY = ? " // Result of NF31: PROV_ORG_TAX_ID changed to PROV_ORG_DIM_KEY
				+ "            inner join PROV_GRP_DIM pgd "
				+ "            on cosf.PROV_GRP_DIM_KEY = pgd.PROV_GRP_DIM_KEY "
				+ "                  and pgd.PROV_GRP_ID = ? and cosf.ANLYSS_AS_OF_DT= ?) cosf1 "
				+ "      on (spgmhf.PGM_DIM_key = cosf1.PGM_DIM_key "
				+ "      and spgmhf.MSRMNT_PRD_STRT_DT = cosf1.MSRMNT_PRD_STRT_DT  "
				+ "      and spgmhf.SCRCRD_MSR_HRCHY_DIM_KEY = cosf1.SCRCRD_MSR_HRCHY_DIM_KEY ) "
				+ "    LEFT OUTER JOIN "
				+ "      (select cpgsf.MSR_NMRTR_NBR, cpgsf.MSR_DNMNTR_NBR, cpgsf.RISK_ADJSTMNT_FCTR, cpgsf.MDPNL_DIM_KEY, "
				+ "            cpgsf.SCRCRD_MSR_HRCHY_DIM_KEY,pgd.PROV_GRP_DIM_KEY, cpgsf.PGM_DIM_key, cpgsf.MSRMNT_PRD_STRT_DT,cpgsf.rt_pct "
				+ "            FROM CMPLNC_PROV_GRP_SMRY_FACT  cpgsf "
				+ "            inner join PROV_GRP_DIM pgd "
				+ "            on cpgsf.PROV_GRP_DIM_KEY = pgd.PROV_GRP_DIM_KEY "
				+ "                  and pgd.PROV_GRP_ID = ? and cpgsf.ANLYSS_AS_OF_DT= ? ) cpgsf1 "
				+ "            on (spgmhf.PGM_DIM_key = cpgsf1.PGM_DIM_key "
				+ "            and spgmhf.MSRMNT_PRD_STRT_DT = cpgsf1.MSRMNT_PRD_STRT_DT "
				+ "            and spgmhf.SCRCRD_MSR_HRCHY_DIM_KEY = cpgsf1.SCRCRD_MSR_HRCHY_DIM_KEY ) "
				+ "    LEFT OUTER JOIN "
				+ "      (select cmsf.MSR_NMRTR_NBR, cmsf.MSR_DNMNTR_NBR , cmsf.RISK_ADJSTMNT_FCTR, cmsf.MDPNL_DIM_KEY, "
				+ "            cmsf.PGM_DIM_key, cmsf.MSRMNT_PRD_STRT_DT, cmsf.SCRCRD_MSR_HRCHY_DIM_KEY, md.mdpnl_id,cmsf.rt_pct  "
				+ "            FROM CMPLNC_MDPNL_SMRY_FACT  cmsf inner join mdpnl_dim md on md.mdpnl_dim_key = cmsf.mdpnl_dim_key "
				+ "				 where cmsf.ANLYSS_AS_OF_DT= ?   and md.mdpnl_id = ?"
				+ "            ) cmsf1 "
				+ "                  on (spgmhf.PGM_DIM_key = cmsf1.PGM_DIM_key "
				+ "                  and spgmhf.MSRMNT_PRD_STRT_DT = cmsf1.MSRMNT_PRD_STRT_DT  "
				+ "                  and spgmhf.SCRCRD_MSR_HRCHY_DIM_KEY = cmsf1.SCRCRD_MSR_HRCHY_DIM_KEY "
				+ "                  and ef.MDPNL_DIM_KEY = cmsf1.MDPNL_DIM_KEY ) "
				+ " where "
				+ "      pgm.PGM_ID = ? "
				+ "      and smhd.CMPST_DEFN_ID = ? "
				+ "      and spgmhf.MSRMNT_PRD_STRT_DT = ? "
				+ "      and spgmhf.PGM_LOB_TYPE_CD = ? "
				+ "  	and pgd.prov_grp_id = ? ");
		//	+ "       and cmsf1.mdpnl_id = ? " );

		/*int counter = 0;
		query.append("AND ld.LOB_DIM_KEY IN (");
		for(String lobDimKey : Arrays.asList(request.get("lobDimKeys").split(","))){
			if (Arrays.asList(request.get("lobDimKeys").split(",")).size() == 1 || counter == Arrays.asList(request.get("lobDimKeys").split(",")).size() - 1) {
				query.append("'" + lobDimKey + "'");
			} else {
				query.append("'" + lobDimKey + "'" + ",");
			}
			counter++;
		}
		query.append(" ) ");*/
		/*
		if(null!=request.getSubCompositeId()){
			query.append(" AND smhd.SUB_CMPST_DEFN_ID = ?");
			query.append("ORDER BY  smhd.SUB_CMPST_NM ");
		}else{
			query.append("ORDER BY  EF.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT DESC, smhd.SUB_CMPST_NM ");
		}*/

		if (null != request.getSubCompositeId() && !request.getSubCompositeId().equalsIgnoreCase("null")
			&& (Constants.COMMERCIAL_UTILIZATION.equalsIgnoreCase(request.getCompositeName()) || (request.getMeasurementPeriodStartDt() != null && isMPGreaterThanOrEqual01012018)) ) {
			query.append(" AND smhd.SUB_CMPST_DEFN_ID = ?");
		}

		if (null != Constants
			.getQuarterName(request.getMeasurementInterval())) {
			if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
				query.append(" AND ef.BSLN_SCRCRD_IND = ? ");
			}
			else {
				query.append(" AND ef.QTR_ID = ? ");
			}
		}
		else {
			// Changing the implementation of the month id clause based on the query snippet suggested by vishwa
			//Commenting the code earlier
			//query.append(" AND spgmhf.MNTH_ID = (SELECT MAX(MNTH_ID) FROM  SCRCRD_PGM_MSR_HRCHY_FACT ) ");

			query.append(" AND EF.MNTH_ID = (SELECT MAX(EF.MNTH_ID) ");
			query.append("                   FROM ERNCNTR_FACT EF  ");
			query.append("                   INNER JOIN ");
			query.append("                   (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT ");
			query.append("                    FROM SCRCRD_PGM_MSR_HRCHY_FACT ");
			query.append("                    WHERE PGM_DIM_KEY = (SELECT PGM_DIM_KEY FROM PGM_DIM WHERE PGM_ID = ? ) and MSRMNT_PRD_STRT_DT=? ");
			query.append("                    GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM ");
			query.append("                    ON EF.PGM_DIM_KEY = SC_PGM.PGM_DIM_KEY AND EF.MSRMNT_PRD_STRT_DT = SC_PGM.MSRMNT_PRD_STRT_DT) ");

		}

		/*	query.append(" ) z where z.pnl_rank = 1 ") ;
			query.append("ORDER BY z.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT DESC, z.SUB_CMPST_NM , z.MSR_DSPLY_NM ");*/
		/*query.append("ORDER BY EF.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT DESC, smhd.SUB_CMPST_NM ,msr.MSR_DSPLY_NM ");*/
		query.append("ORDER BY smhd.SUB_CMPST_NM , EF.RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT DESC , msr.MSR_DSPLY_NM ");

		query = StringUtil.appendWithUr(query);

		//		logger.debug("getScorecardMeasuresQuery SQL: " + query.toString());

		try
		{
			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			prepareStatement(logger, query.toString());

			//ps.setString(1, request.getProvGrpId());
			ps.setString(1, request.getOrganizationId());
			ps.setString(2, request.getProvGrpIds());
			ps.setString(3, request.getAnalysisAsOfDt());
			ps.setString(4, request.getProvGrpIds());
			ps.setString(5, request.getAnalysisAsOfDt());
			ps.setString(6, request.getAnalysisAsOfDt());
			ps.setString(7, request.getMedicalPanelId());
			ps.setString(8, request.getProgramId());
			ps.setString(9, request.getCompositeId());
			ps.setString(10, request.getMeasurementPeriodStartDt());
			ps.setString(11, request.getProgramLobTypeCd().toUpperCase());
			ps.setString(12, request.getProvGrpIds());

			//logger.debug("provGrpId: " + request.getProvGrpId());
			//logger.debug("organizationId: " + request.getOrganizationId());
			//logger.debug("provGrpId: " + request.getProvGrpId());
			//logger.debug("analysisAsOfDt: " + request.getAnalysisAsOfDt());
			//logger.debug("provGrpId: " + request.getProvGrpId());
			//logger.debug("analysisAsOfDt: " + request.getAnalysisAsOfDt());
			//logger.debug("analysisAsOfDt: " + request.getAnalysisAsOfDt());
			//logger.debug("prgmId: " + request.getProgramId());
			//logger.debug("compositeId: " + request.getCompositeId());
			//logger.debug("msrmntStrtDt: " + request.getMeasurementPeriodStartDt());
			//logger.debug("programLobTypeCd: " + request.getProgramLobTypeCd().toUpperCase());

			int i = 13;
			if (null != request.getSubCompositeId() && !request.getSubCompositeId().equalsIgnoreCase("null")
				&& (Constants.COMMERCIAL_UTILIZATION.equalsIgnoreCase(request.getCompositeName()) || (request.getMeasurementPeriodStartDt() != null && isMPGreaterThanOrEqual01012018))) {
				ps.setString(i++, request.getSubCompositeId());
				//logger.debug("subCompositeId: " + request.getSubCompositeId());
			}

			if (null != Constants.getQuarterName(request
				.getMeasurementInterval())) {
				if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
					ps.setString(i++, "Y");
				}
				else {
					ps.setString(i++, Constants.getQuarterName(request
						.getMeasurementInterval()));
				}
				//logger.debug("measurementInterval: " + Constants.getQuarterName(request.getMeasurementInterval()));
			}
			else {
				ps.setString(i++, request.getProgramId());
				ps.setString(i++, request.getMeasurementPeriodStartDt());
				//logger.debug("prgmId: " + request.getProgramId());
			}

			executeQuery(logger, query.toString());
			while (rs.next())
			{
				measureBean = new ScorecardMeasureBean();
				if (rs.getString("CMPST_TYPE_DESC") != null) {
					measureBean.setCompTypeDesc(rs.getString("CMPST_TYPE_DESC"));
				}
				if (rs.getString("CMPST_DEFN_ID") != null) {
					measureBean.setCmpstDefnId(rs.getString("CMPST_DEFN_ID"));
				}
				if (rs.getString("CMPST_NM") != null) {
					measureBean.setCmpstNm(rs.getString("CMPST_NM"));
				}
				if (rs.getString("SUB_CMPST_DEFN_ID") != null) {
					measureBean.setSubCmpstDefnId(rs.getString("SUB_CMPST_DEFN_ID"));
				}
				if (rs.getString("SUB_CMPST_NM") != null) {
					measureBean.setSubCmpstNm(rs.getString("SUB_CMPST_NM"));
				}
				if (rs.getString("MSR_DIM_KEY") != null) {
					measureBean.setMsrId(rs.getString("MSR_DIM_KEY"));
				}
				if (rs.getString("MSR_DSPLY_NM") != null) {
					measureBean.setMsrDsplyNm(rs.getString("MSR_DSPLY_NM"));
				}

				//Setting values for Organization Level
				if (rs.getString("COSF_MSR_NMRTR_NBR") != null) {
					measureBean.getScorecardMeasureOrgLvl().setMsrNmrtrNbr(Integer.valueOf(rs.getInt("COSF_MSR_NMRTR_NBR")));
				}
				if (rs.getString("COSF_MSR_DNMNTR_NBR") != null) {
					measureBean.getScorecardMeasureOrgLvl().setMsrDnmntrNbr(Integer.valueOf(rs.getInt("COSF_MSR_DNMNTR_NBR")));
				}
				if (rs.getString("COSF_RT_PCT") != null)
					measureBean.getScorecardMeasureOrgLvl().setRtPct(rs.getString("COSF_RT_PCT"));
				//Setting values for Group Level
				if (rs.getString("CPGSF_MSR_NMRTR_NBR") != null) {
					measureBean.getScorecardMeasureGrpLvl().setMsrNmrtrNbr(Integer.valueOf(rs.getString("CPGSF_MSR_NMRTR_NBR")));
				}
				if (rs.getString("CPGSF_MSR_DNMNTR_NBR") != null) {
					measureBean.getScorecardMeasureGrpLvl().setMsrDnmntrNbr(Integer.valueOf(rs.getString("CPGSF_MSR_DNMNTR_NBR")));
				}
				if (rs.getString("CPGSF_RT_PCT") != null)
					measureBean.getScorecardMeasureGrpLvl().setRtPct(rs.getString("CPGSF_RT_PCT"));

				//Setting values for Panel Level
				if (rs.getString("CMSF_MSR_NMRTR_NBR") != null) {
					measureBean.getScorecardMeasurePnlLvl().setMsrNmrtrNbr(Integer.valueOf(rs.getString("CMSF_MSR_NMRTR_NBR")));
				}
				if (rs.getString("CMSF_MSR_DNMNTR_NBR") != null) {
					measureBean.getScorecardMeasurePnlLvl().setMsrDnmntrNbr(Integer.valueOf(rs.getString("CMSF_MSR_DNMNTR_NBR")));
				}
				if (rs.getString("CMSF_RT_PCT") != null)
					measureBean.getScorecardMeasurePnlLvl().setRtPct(rs.getString("CMSF_RT_PCT"));

				if (rs.getBigDecimal("MRKT_RT_PCT") != null) {
					measureBean.setMrktRtPct(rs.getBigDecimal("MRKT_RT_PCT"));
				}

				if (rs.getBigDecimal("RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT") != null) {
					measureBean.setWeight(rs.getBigDecimal("RDSTRBTD_SSAV_UPSD_DSTRBTN_PCT"));
				}
				//Setting Bean values for Composite: Utilization
				if (rs.getString("CMPST_TYPE_DESC") != null && rs.getString("CMPST_TYPE_DESC").equalsIgnoreCase("Utilization"))
				{
					if (rs.getBigDecimal("COSF_RISK_ADJSTMNT_FCTR") != null) {
						measureBean.getScorecardMeasureOrgLvl().setRiskAdjstmntFctr(rs.getBigDecimal("COSF_RISK_ADJSTMNT_FCTR"));
					}
					if (rs.getBigDecimal("CPGSF_RISK_ADJSTMNT_FCTR") != null) {
						measureBean.getScorecardMeasureGrpLvl().setRiskAdjstmntFctr(rs.getBigDecimal("CPGSF_RISK_ADJSTMNT_FCTR"));
					}
					if (rs.getBigDecimal("CMSF_RISK_ADJSTMNT_FCTR") != null) {
						measureBean.getScorecardMeasurePnlLvl().setRiskAdjstmntFctr(rs.getBigDecimal("CMSF_RISK_ADJSTMNT_FCTR"));
					}
				}
				resultList.add(measureBean);
			}

		}
		catch (Exception e) {
			logger.error("Exception during getScorecardMeasuresQuery", e);
		}
		finally {
			close();
		}

		return resultList;
	}
}
