package com.wellpoint.pc2dash.action.costOpportunity;

import com.wellpoint.pc2dash.data.dto.PopulationManagementRequest;

public class GetInpatientUtilizationCategoryRequest extends PopulationManagementRequest {
	
	private boolean hasCategoryDrilldownInd;

	public boolean isHasCategoryDrilldownInd() {
		return hasCategoryDrilldownInd;
	}

	public void setHasCategoryDrilldownInd(boolean hasCategoryDrilldownInd) {
		this.hasCategoryDrilldownInd = hasCategoryDrilldownInd;
	}

	
	
}
