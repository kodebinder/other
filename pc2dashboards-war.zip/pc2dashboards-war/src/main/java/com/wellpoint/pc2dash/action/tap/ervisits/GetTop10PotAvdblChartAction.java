package com.wellpoint.pc2dash.action.tap.ervisits;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.JsonSyntaxException;
import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.tap.ervisits.Top10PotAvdblChartBean;
import com.wellpoint.pc2dash.exception.PC2Exception;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.service.tap.ervisits.Top10PotAvdblChartServiceImpl;
import com.wellpoint.pc2dash.util.CommonQueries;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.ErrorProperties;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetTop10PotAvdblChartAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		GetTop10PotAvdblChartRequest request = (GetTop10PotAvdblChartRequest) actionRequest;
		GetTop10PotAvdblChartResponse response = new GetTop10PotAvdblChartResponse();
		ErrorProperties err = ErrorProperties.getInstance();

		Top10PotAvdblChartServiceImpl service = new Top10PotAvdblChartServiceImpl();
		List<String> grps = null;

		try {

			removeLobPgmPrefixes(request);
			prepareChronicCareGapMap(request);

			grps = addKillSwitchToGroups(request, grps);

			grps = clinicalAccessCheck(request, grps);

			/*
			 * Need to populate HCC/Total Cost suppression values for the chart, so the chart/grid
			 * queries can be kept in sync.
			 */
			CommonQueries cq = new CommonQueries();
			request.setGroupsWithActionCenterSuppressed(cq.getGroupsWithComponentSuppressed(request, Constants.AC_RF_CARDCONTAINER));
			request.setSuppression(cq.getActiveSuppressionForSelectComponents(request));
			request.setUnsuppressedLOBsTotalCost(getLOBsWithoutTotalCostSuppressed(request));

			if (null != grps && !grps.isEmpty()) {

				processResponse(request, response, err, service);
			}

			response.setSuccess(true);
			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}

	}

  /**
   * @param request
   * @param response
   * @param err
   * @param service
   * @throws PC2Exception
   */
  private void processResponse(GetTop10PotAvdblChartRequest request,
      GetTop10PotAvdblChartResponse response, ErrorProperties err,
      Top10PotAvdblChartServiceImpl service) throws PC2Exception {
    if (StringUtil.isExportDest(request.getDest())) {
    	//					To Be Coded - When Export component comes into picture
    }
    else {

    	List<Top10PotAvdblChartBean> results = service.getTAPReportData(request);

    	setResponseInfo(response, err, results);
    }
  }

  /**
   * @param response
   * @param err
   * @param results
   */
  private void setResponseInfo(GetTop10PotAvdblChartResponse response, ErrorProperties err,
      List<Top10PotAvdblChartBean> results) {
    if (null != results && !results.isEmpty()) {

    	response.setData(results);
    	response.setMessage(err.getProperty("successful"));
    	response.setTotal(1);//setting a default value
    }
    else {

    	response.setMessage(err.getProperty("successNoData"));
    }
  }

  /**
   * @param request
   * @param grps
   * @return
   * @throws JsonSyntaxException
   * @throws ClassNotFoundException
   */
  private List<String> clinicalAccessCheck(GetTop10PotAvdblChartRequest request, List<String> groups)
      throws ClassNotFoundException {
    List<String> grps = groups;
    // Clinical access check on provider groups
    if (null != grps && !grps.isEmpty()) {

    	request.setProvGrpIdsWithoutClinicalCheck(StringUtils.join(grps, ','));
    	grps = filterProvGrpsByClinicalInd(request, grps);
    	request.setProvGrpIds(StringUtils.join(grps, ','));
    }
    return grps;
  }

  /**
   * @param request
   * @param grps
   * @return
   */
  private List<String> addKillSwitchToGroups(GetTop10PotAvdblChartRequest request,
      List<String> groups) {
    List<String> grps = groups;
    // Kill switch check on Provider groups
    // Setting it as reviewer login as suppression is not applicable
    // Remove the reviewer login check hardcoding if suppression comes into picture for TAP Reports
    if (StringUtils.isNotBlank(request.getCmpId())) {
    	grps = filterProvGrpsByKillSwitch(request);
    }
    return grps;
  }

}
