package com.wellpoint.pc2dash.dao;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MsrDim implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long msrDimKey;

	private Long crtdLoadLogKey;

	private String msrDsplyNm;

	private Date msrEfctvDt;

	private String msrId;

	private String msrIntrnlNm;

	private String msrShrtNm;

	private String msrSrcCd;

	private Date msrTrmntnDt;

	private String msrTypeCd;

	private String rcrdSttsCd;

	private Timestamp sorDtm;

	private Long updtdLoadLogKey;

	// bi-directional many-to-one association to CareOprtntyFact
	private List<CareOprtntyFact> careOprtntyFacts;

	// bi-directional many-to-one association to ClnclMsrHrchyDim
	private List<ClnclMsrHrchyDim> clnclMsrHrchyDims = new ArrayList<ClnclMsrHrchyDim>();

	public MsrDim() {}

	public Long getMsrDimKey() {
		return this.msrDimKey;
	}

	public void setMsrDimKey(Long msrDimKey) {
		this.msrDimKey = msrDimKey;
	}

	public Long getCrtdLoadLogKey() {
		return this.crtdLoadLogKey;
	}

	public void setCrtdLoadLogKey(Long crtdLoadLogKey) {
		this.crtdLoadLogKey = crtdLoadLogKey;
	}

	public String getMsrDsplyNm() {
		return this.msrDsplyNm;
	}

	public void setMsrDsplyNm(String msrDsplyNm) {
		this.msrDsplyNm = msrDsplyNm;
	}

	public Date getMsrEfctvDt() {
		return this.msrEfctvDt;
	}

	public void setMsrEfctvDt(Date msrEfctvDt) {
		this.msrEfctvDt = msrEfctvDt;
	}

	public String getMsrId() {
		return this.msrId;
	}

	public void setMsrId(String msrId) {
		this.msrId = msrId;
	}

	public String getMsrIntrnlNm() {
		return this.msrIntrnlNm;
	}

	public void setMsrIntrnlNm(String msrIntrnlNm) {
		this.msrIntrnlNm = msrIntrnlNm;
	}

	public String getMsrShrtNm() {
		return msrShrtNm;
	}

	public void setMsrShrtNm(String msrShrtNm) {
		this.msrShrtNm = msrShrtNm;
	}

	public String getMsrSrcCd() {
		return this.msrSrcCd;
	}

	public void setMsrSrcCd(String msrSrcCd) {
		this.msrSrcCd = msrSrcCd;
	}

	/*
	 * public String getMsrSttsCd() { return this.msrSttsCd; }
	 * 
	 * public void setMsrSttsCd(String msrSttsCd) { this.msrSttsCd = msrSttsCd; }
	 */

	public Date getMsrTrmntnDt() {
		return this.msrTrmntnDt;
	}

	public void setMsrTrmntnDt(Date msrTrmntnDt) {
		this.msrTrmntnDt = msrTrmntnDt;
	}

	public String getMsrTypeCd() {
		return this.msrTypeCd;
	}

	public void setMsrTypeCd(String msrTypeCd) {
		this.msrTypeCd = msrTypeCd;
	}

	public String getRcrdSttsCd() {
		return this.rcrdSttsCd;
	}

	public void setRcrdSttsCd(String rcrdSttsCd) {
		this.rcrdSttsCd = rcrdSttsCd;
	}

	public Timestamp getSorDtm() {
		return this.sorDtm;
	}

	public void setSorDtm(Timestamp sorDtm) {
		this.sorDtm = sorDtm;
	}

	public Long getUpdtdLoadLogKey() {
		return this.updtdLoadLogKey;
	}

	public void setUpdtdLoadLogKey(Long updtdLoadLogKey) {
		this.updtdLoadLogKey = updtdLoadLogKey;
	}

	public List<CareOprtntyFact> getCareOprtntyFacts() {
		return this.careOprtntyFacts;
	}

	public void setCareOprtntyFacts(List<CareOprtntyFact> careOprtntyFacts) {
		this.careOprtntyFacts = careOprtntyFacts;
	}

	public List<ClnclMsrHrchyDim> getClnclMsrHrchyDims() {
		return this.clnclMsrHrchyDims;
	}

	public void setClnclMsrHrchyDims(List<ClnclMsrHrchyDim> clnclMsrHrchyDims) {
		this.clnclMsrHrchyDims = clnclMsrHrchyDims;
	}

}
