package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.data.dto.PCMSRequest;
import com.wellpoint.pc2dash.data.dto.PerformanceManagementRequest;
import com.wellpoint.pc2dash.dto.scorecard.ScorecardCompositeBean;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.DateUtil;
import com.wellpoint.pc2dash.util.StringUtil;

public class MedicareScorecardByCompositeFactsDao extends AbstractDao {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(MedicareScorecardByCompositeFactsDao.class);

	public Collection<ScorecardCompositeBean> getMedicareScorecardComposites(PerformanceManagementRequest request) throws Exception {
		Collection<ScorecardCompositeBean> result = new ArrayList<ScorecardCompositeBean>();
		StringBuilder sql = new StringBuilder();

		String pgmLobTypeCd = null;
		//PCMSP-11158
		String measStartDate = request.getMeasurementPeriodStartDt();
		boolean isMPGreaterThan2017 = DateUtil.dateComparator(measStartDate, Constants.IND_MTRC_STRT_DT);
		if (null != request.getProgramLobTypeCd()) {
			pgmLobTypeCd = request.getProgramLobTypeCd();
			if (pgmLobTypeCd.contains(Constants.FPCC_PGM_TYPE)) {
				sql = createQueryForFpccComposites(request,isMPGreaterThan2017);
			}
			else {
				sql = createQueryForEphcComposites(request,isMPGreaterThan2017);
			}
			sql = sql.append(" UNION ")
				.append(createQueryForImprovement(request))
				.append(" UNION ")
				.append(createQueryForUtilization(request));
			sql = StringUtil.appendWithUr(sql);
		}

		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);

			int i = 0;
			prepareStatement(logger, sql.toString());
			for (int q = 0; q < 3; q++) {
				ps.setString(++i, request.getProgramId());
				ps.setString(++i, request.getMeasurementPeriodStartDt());
				ps.setString(++i, request.getProvGrpIds());
				ps.setString(++i, request.getProgramLobTypeCd().toUpperCase());

				if (null == Constants.getQuarterName(request.getMeasurementInterval())) {
					ps.setString(++i, request.getProvGrpIds());
					ps.setString(++i, request.getProgramId());
					ps.setString(++i, request.getMeasurementPeriodStartDt());
					ps.setString(++i, request.getProgramId());
				}
			}

			executeQuery(logger, sql.toString());

			ScorecardCompositeBean compositeBean;

			while (rs.next()) {
				compositeBean = new ScorecardCompositeBean();
				compositeBean.setCompositeId(getString(rs, "cmpst_defn_id"));
				compositeBean.setCompositeName(getString(rs, "cmpst_nm"));
				compositeBean.setCompositeTypeDesc(getString(rs, "cmpst_type_desc"));
				compositeBean.setSsavUpsdDstrbnPct(getString(rs, "ssav"));
				compositeBean.setErncntrPct(getString(rs, "erncntr"));
				if (null != pgmLobTypeCd && !pgmLobTypeCd.contains(Constants.FPCC_PGM_TYPE)) {
					compositeBean.setQualityGate(getString(rs, "qlty_gate_thrshld_pct"));
					compositeBean.setQualityScore(getString(rs, "qlty_scor_pct"));
					compositeBean.setQualityGateInd(getString(rs, "qlty_gate_ind"));
				}
				compositeBean.setMedicareTier1ErncntrPct(getString(rs, "MDCR_TOTL_ERCNTR_PCT"));  //PCMSP-11254
				compositeBean.setTier2Ind(getString(rs, "MDCR_TIER_2_IND"));
				result.add(compositeBean);
			}
		}
		catch (Exception e) {
			logger.error("Exception during getMedicareScorecardComposites", e);
		}
		finally {
			close();
		}
		return result;
	}

	/**
	 * @param request
	 * @return
	 */
	private StringBuilder createQueryForEphcComposites(PCMSRequest request,boolean isMPGreaterThan2017) {
		StringBuilder sql = new StringBuilder()
			.append("select cmpst_nm, cmpst_defn_id, cmpst_type_desc, erncntr, ssav, qlty_gate_thrshld_pct, qlty_scor_pct, qlty_gate_ind,MDCR_TOTL_ERCNTR_PCT,MDCR_TIER_2_IND  from ( ") //PCMSP-11254
			.append("select ")
			.append(" smhd.cmpst_nm, ")
			.append(" smhd.cmpst_defn_id, ")
			.append(" smhd.cmpst_type_desc, ")
			.append(" sum(ef.rdstrbtd_erncntr_pct) as erncntr, ")
			//.append(" sum(ef.rdstrbtd_ssav_upsd_dstrbtn_pct) as ssav, ")//changed for PCMSP-52
			.append(" sum(ef.SSAV_UPSD_DSTRBTN_PCT) as ssav, ")
			.append(" ef.qlty_gate_thrshld_pct, ")
			.append(" ef.qlty_scor_pct, ")
			.append(" ef.qlty_gate_ind, ")
			.append(" smhd.sub_cmpst_nm, ")
			.append(" epgsf.MDCR_TOTL_ERCNTR_PCT ,epgsf.MDCR_TIER_2_IND ")  //PCMSP-11254
			.append(" from ")
			.append(" erncntr_fact ef ")
			.append(" join pgm_dim pgm on ( ")
			.append(" ef.pgm_dim_key = pgm.pgm_dim_key ")
			.append(" ) ")
			.append(" join prov_grp_dim pg on ( ")
			.append(" ef.prov_grp_dim_key = pg.prov_grp_dim_key ")
			.append(" ) ")
			.append(" join scrcrd_pgm_msr_hrchy_fact spmhf on ( ")
			.append(" ef.pgm_dim_key = spmhf.pgm_dim_key and ")
			.append(" ef.trnch_defn_dim_key = spmhf.trnch_defn_dim_key and ")
			.append(" ef.mnth_id = spmhf.mnth_id and ")
			.append(" ef.msrmnt_prd_strt_dt = spmhf.msrmnt_prd_strt_dt ")
			.append(" ) ")
			.append(" join scrcrd_msr_hrchy_dim smhd on ( ")
			.append(" spmhf.scrcrd_msr_hrchy_dim_key = smhd.scrcrd_msr_hrchy_dim_key ")
			.append(" ) ")
			.append(" JOIN ERNCNTR_PROV_GRP_SMRY_FACT epgsf on  epgsf.prov_grp_dim_key = ef.prov_grp_dim_key and epgsf.pgm_dim_key = ef.pgm_dim_key ")
			.append(" and  epgsf.mnth_id = ef.mnth_id and   epgsf.msrmnt_prd_strt_dt = ef.msrmnt_prd_strt_dt ")
			.append(" where ")
			.append(" pgm.pgm_id = ? and ")
			.append(" ef.msrmnt_prd_strt_dt = ? and ")
			.append(" pg.prov_grp_id = ? and ")
			.append(" spmhf.pgm_lob_type_cd = ? and ");
			//PCMSP-11158
			if(isMPGreaterThan2017){
				sql.append(" smhd.cmpst_type_desc in ('Quality', 'Enhanced','Improvement') ");
			}else{
				sql.append(" smhd.cmpst_type_desc in ('Quality', 'Enhanced') ");
			}

		if (null != Constants.getQuarterName(request.getMeasurementInterval())) {
			if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
				sql.append(" AND ef.BSLN_SCRCRD_IND = 'Y' ");
			}
			else {
				sql.append(" AND ef.QTR_ID = '" + Constants.getQuarterName(request.getMeasurementInterval()) + "' ");
			}
		}
		else {
			sql.append(" AND ef.MNTH_ID "
				+ "=  (SELECT MAX(EF.MNTH_ID) FROM ERNCNTR_FACT EF INNER JOIN "
				+ " (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT FROM SCRCRD_PGM_MSR_HRCHY_FACT WHERE  ");
			//+" PGM_DIM_KEY=(SELECT PGM_DIM_KEY FROM PROV_GRP_PGM_LOB_FACT WHERE PGM_ID = ? and PGM_PG_TRMNTN_DT > CURRENT_DATE GROUP BY PGM_DIM_KEY) "
			sql.append(" 		 PGM_DIM_KEY = (SELECT PGM_DIM_KEY FROM PROV_GRP_PGM_LOB_FACT A ");
			sql.append(" 		inner join   PROV_GRP_DIM B ON A.PROV_GRP_DIM_KEY=B.PROV_GRP_DIM_KEY and  B.PROV_GRP_ID = ?");
			sql.append("		WHERE A.PGM_ID = ? and A.PGM_PG_TRMNTN_DT > CURRENT_DATE GROUP BY A.PGM_DIM_KEY) "
				+ "  and  MSRMNT_PRD_STRT_DT = ? "
				+ "GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM "
				+ "ON EF.PGM_DIM_KEY=SC_PGM.PGM_DIM_KEY AND EF.MSRMNT_PRD_STRT_DT=SC_PGM.MSRMNT_PRD_STRT_DT) "
				+ " and (select max(ef.mnth_id)MAX_MON from ERNCNTR_FACT ef join PGM_DIM pd on ef.pgm_dim_key = pd.pgm_dim_key where pd.pgm_id = ? ) <=  INT(TO_CHAR(ef.msrmnt_prd_strt_dt + 15 months, 'YYYYMM')) ");

		}
		sql.append(" group by smhd.CMPST_NM ,smhd.CMPST_DEFN_ID, smhd.CMPST_TYPE_DESC,smhd.sub_cmpst_nm, ef.qlty_gate_thrshld_pct, ef.qlty_scor_pct, ef.qlty_gate_ind,epgsf.MDCR_TOTL_ERCNTR_PCT,epgsf.MDCR_TIER_2_IND ")
			.append(" order by smhd.CMPST_NM")
			.append(") group by cmpst_nm,cmpst_defn_id, cmpst_type_desc, qlty_gate_thrshld_pct, qlty_scor_pct, qlty_gate_ind, ssav, erncntr,MDCR_TOTL_ERCNTR_PCT,MDCR_TIER_2_IND ");

		//sql = StringUtil.appendWithUr(sql);
		return sql;
	}

	/**
	 * @param request
	 * @return
	 */
	private StringBuilder createQueryForFpccComposites(PCMSRequest request,boolean isMPGreaterThan2017) {
		StringBuilder sql = new StringBuilder()
			.append("select cmpst_nm, cmpst_defn_id, cmpst_type_desc, erncntr, ssav, qlty_gate_thrshld_pct, qlty_scor_pct, qlty_gate_ind,MDCR_TOTL_ERCNTR_PCT,MDCR_TIER_2_IND  from ( ")  //PCMSP-11254
			.append("select ")
			.append(" smhd.cmpst_nm, ")
			.append(" smhd.cmpst_defn_id, ")
			.append(" smhd.cmpst_type_desc, ")
			.append(" sum(ef.rdstrbtd_erncntr_pct) as erncntr, ")
			//.append(" sum(ef.rdstrbtd_ssav_upsd_dstrbtn_pct) as ssav, ")//Changed for PCMSP-52
			.append(" sum(ef.SSAV_UPSD_DSTRBTN_PCT) as ssav, ")
			.append(" ef.qlty_gate_thrshld_pct, ")
			.append(" ef.qlty_scor_pct, ")
			.append(" ef.qlty_gate_ind, ")
			.append(" epgsf.MDCR_TOTL_ERCNTR_PCT ,epgsf.MDCR_TIER_2_IND ")  //PCMSP-11254
			.append(" from ")
			.append(" erncntr_fact ef ")
			.append(" join pgm_dim pgm on ( ")
			.append(" ef.pgm_dim_key = pgm.pgm_dim_key ")
			.append(" ) ")
			.append(" join prov_grp_dim pg on ( ")
			.append(" ef.prov_grp_dim_key = pg.prov_grp_dim_key ")
			.append(" ) ")
			.append(" join scrcrd_pgm_msr_hrchy_fact spmhf on ( ")
			.append(" ef.pgm_dim_key = spmhf.pgm_dim_key  and ")
			.append(" ef.trnch_defn_dim_key = spmhf.trnch_defn_dim_key and ")
			.append(" ef.mnth_id = spmhf.mnth_id and ")
			.append(" ef.msrmnt_prd_strt_dt = spmhf.msrmnt_prd_strt_dt ")
			.append(" ) ")
			.append(" join scrcrd_msr_hrchy_dim smhd on ( ")
			.append(" spmhf.scrcrd_msr_hrchy_dim_key = smhd.scrcrd_msr_hrchy_dim_key ")
			.append(" ) ")
			.append(" JOIN ERNCNTR_PROV_GRP_SMRY_FACT epgsf on  epgsf.prov_grp_dim_key = ef.prov_grp_dim_key and epgsf.pgm_dim_key = ef.pgm_dim_key ")
			.append(" and  epgsf.mnth_id = ef.mnth_id and   epgsf.msrmnt_prd_strt_dt = ef.msrmnt_prd_strt_dt ")
			.append(" where ")
			.append(" pgm.pgm_id = ?  and ")
			.append(" ef.msrmnt_prd_strt_dt = ?  and ")
			.append(" pg.prov_grp_id = ? and ")
			.append(" spmhf.pgm_lob_type_cd = ? and ");
			//PCMSP-11158
			if(isMPGreaterThan2017){
				sql.append(" smhd.cmpst_type_desc in ('Enhanced','Improvement') ");
			}else{
				sql.append(" smhd.cmpst_type_desc in ('Enhanced') ");
			}
			

		if (null != Constants.getQuarterName(request.getMeasurementInterval())) {
			if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
				sql.append(" AND ef.BSLN_SCRCRD_IND = 'Y' ");
			}
			else {
				sql.append(" AND ef.QTR_ID = '" + Constants.getQuarterName(request.getMeasurementInterval()) + "' ");
			}
		}
		else {
			sql.append(" AND ef.MNTH_ID "
				+ "=  (SELECT MAX(EF.MNTH_ID) FROM ERNCNTR_FACT EF INNER JOIN "
				+ " (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT FROM SCRCRD_PGM_MSR_HRCHY_FACT WHERE  ");
			//+" PGM_DIM_KEY=(SELECT PGM_DIM_KEY FROM PROV_GRP_PGM_LOB_FACT WHERE PGM_ID = ? and PGM_PG_TRMNTN_DT > CURRENT_DATE GROUP BY PGM_DIM_KEY) "
			sql.append(" 		 PGM_DIM_KEY = (SELECT PGM_DIM_KEY FROM PROV_GRP_PGM_LOB_FACT A ");
			sql.append(" 		inner join   PROV_GRP_DIM B ON A.PROV_GRP_DIM_KEY=B.PROV_GRP_DIM_KEY and  B.PROV_GRP_ID = ?");
			sql.append("		WHERE A.PGM_ID = ? and A.PGM_PG_TRMNTN_DT > CURRENT_DATE GROUP BY A.PGM_DIM_KEY) "
				+ "  and  MSRMNT_PRD_STRT_DT = ? "
				+ " GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM "
				+ "ON EF.PGM_DIM_KEY=SC_PGM.PGM_DIM_KEY AND EF.MSRMNT_PRD_STRT_DT=SC_PGM.MSRMNT_PRD_STRT_DT) "
				+ " and (select max(ef.mnth_id)MAX_MON from ERNCNTR_FACT ef join PGM_DIM pd on ef.pgm_dim_key = pd.pgm_dim_key where pd.pgm_id = ? ) <=  INT(TO_CHAR(ef.msrmnt_prd_strt_dt + 15 months, 'YYYYMM')) ");

		}
		sql.append(" group by smhd.CMPST_NM ,smhd.CMPST_DEFN_ID, smhd.CMPST_TYPE_DESC,ef.qlty_gate_thrshld_pct, ef.qlty_scor_pct, ef.qlty_gate_ind,epgsf.MDCR_TOTL_ERCNTR_PCT ,epgsf.MDCR_TIER_2_IND ")
			.append(" order by smhd.CMPST_NM")
			.append(") group by cmpst_nm,cmpst_defn_id, cmpst_type_desc,qlty_gate_thrshld_pct, qlty_scor_pct, qlty_gate_ind, ssav, erncntr,MDCR_TOTL_ERCNTR_PCT,MDCR_TIER_2_IND ");

		//sql = StringUtil.appendWithUr(sql);
		return sql;
	}

	public StringBuilder createQueryForImprovement(PCMSRequest request) {

		StringBuilder sql = new StringBuilder()
			.append("select cmpst_nm, cmpst_defn_id, cmpst_type_desc, sum(erncntr) as erncntr, sum(ssav) as ssav, qlty_gate_thrshld_pct, qlty_scor_pct, qlty_gate_ind,MDCR_TOTL_ERCNTR_PCT,MDCR_TIER_2_IND from ( ")
			.append("select ")
			.append(" ipgsf.rdstrbtd_erncntr_pct as erncntr, ")
			.append(" ipgsf.rdstrbtd_ssav_upsd_dstrbtn_pct as ssav, ")
			.append(" smhd.cmpst_nm, ")
			.append(" smhd.cmpst_defn_id, ")
			.append(" ef.qlty_gate_thrshld_pct, ")
			.append(" ef.qlty_scor_pct, ")
			.append(" ef.qlty_gate_ind, ")
			.append(" smhd.cmpst_type_desc, ")
			.append(" epgsf.MDCR_TOTL_ERCNTR_PCT ,epgsf.MDCR_TIER_2_IND ")  //PCMSP-11254
			.append(" from ")
			.append(" imprv_prov_grp_smry_fact ipgsf, ")
			.append(" erncntr_fact ef, ")
			.append(" scrcrd_msr_hrchy_dim smhd, ")
			.append(" pgm_dim pgm, ")
			.append(" prov_grp_dim pg, ")
			.append(" scrcrd_pgm_msr_hrchy_fact spmhf, ")
			.append(" ERNCNTR_PROV_GRP_SMRY_FACT epgsf ")  //PCMSP-11254
			//.append(" prov_grp_pgm_lob_fact pgplf, ")      //added as a part of R1.3
			//.append(" lob_dim ld ")						   //added as a part of R1.3
			.append(" where ")
			.append(" ipgsf.pgm_dim_key=pgm.pgm_dim_key and ")
			.append(" ipgsf.pgm_dim_key=spmhf.pgm_dim_key  and ")
			.append(" ipgsf.mnth_id = spmhf.mnth_id and ")
			.append(" IPGSF.MNTH_ID = EF.MNTH_ID and ") //Added for Defect fix R1.3
			.append(" ef.pgm_dim_key=ipgsf.pgm_dim_key and ")
			.append(" ef.prov_grp_dim_key = ipgsf.prov_grp_dim_key and ")
			.append(" ipgsf.msrmnt_prd_strt_dt = ef.msrmnt_prd_strt_dt and ")
			//.append(" ipgsf.trnch_defn_dim_key = spmhf.trnch_defn_dim_key and ") 
			.append(" ipgsf.prov_grp_dim_key = pg.prov_grp_dim_key and ")
			.append(" ipgsf.msrmnt_prd_strt_dt = spmhf.msrmnt_prd_strt_dt and ")//Added as per Dasmeet's email.
			.append(" spmhf.scrcrd_msr_hrchy_dim_key=smhd.scrcrd_msr_hrchy_dim_key and ")
			.append(" ipgsf.scrcrd_msr_hrchy_dim_key=smhd.scrcrd_msr_hrchy_dim_key and ")
			.append(" epgsf.prov_grp_dim_key = ef.prov_grp_dim_key and epgsf.pgm_dim_key = ef.pgm_dim_key and ") //PCMSP-11254
			.append(" epgsf.mnth_id = ef.mnth_id and   epgsf.msrmnt_prd_strt_dt = ef.msrmnt_prd_strt_dt and ")
			//.append(" ipgsf.prov_grp_dim_key = pgplf.prov_grp_dim_key and ") //added as a part of R1.3
			//.append(" ipgsf.pgm_dim_key= pgplf.pgm_dim_key and ")             //added as a part of R1.3
			//.append(" ld.lob_dim_key = pgplf.lob_dim_key and ")
			.append(" pgm.pgm_id = ? and ")
			.append(" ipgsf.msrmnt_prd_strt_dt = ? and ")
			.append(" pg.prov_grp_id = ? and ")
			.append(" spmhf.pgm_lob_type_cd = ? ");

		if (null != Constants.getQuarterName(request.getMeasurementInterval())) {
			if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
				sql.append(" AND ipgsf.BSLN_SCRCRD_IND = 'Y' ");
			}
			else {
				sql.append(" AND ipgsf.QTR_ID = '" + Constants.getQuarterName(request.getMeasurementInterval()) + "' ");
			}
		}
		else {

			//Changing the implementation of the month id clause based on the query snippet suggested by vishwa
			//Commenting the code earlier
			//sql.append(" AND ipgsf.MNTH_ID = (Select max(ipgsf.mnth_id) from imprv_prov_grp_smry_fact ipgsf) ");

			sql.append(" AND ipgsf.MNTH_ID = (SELECT MAX(IPGSF.MNTH_ID) ");
			sql.append(" 					FROM IMPRV_PROV_GRP_SMRY_FACT IPGSF ");
			sql.append(" 					INNER JOIN (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT  ");
			sql.append(" 								FROM SCRCRD_PGM_MSR_HRCHY_FACT ");
			//sql.append(" 					WHERE PGM_DIM_KEY = (SELECT PGM_DIM_KEY FROM PROV_GRP_PGM_LOB_FACT WHERE PGM_ID = ? and PGM_PG_TRMNTN_DT > CURRENT_DATE GROUP BY PGM_DIM_KEY ) ");
			sql.append(" 		WHERE PGM_DIM_KEY = (SELECT PGM_DIM_KEY FROM PROV_GRP_PGM_LOB_FACT A ");
			sql.append(" 		inner join   PROV_GRP_DIM B ON A.PROV_GRP_DIM_KEY=B.PROV_GRP_DIM_KEY and  B.PROV_GRP_ID = ?");
			sql.append("		WHERE A.PGM_ID = ? and A.PGM_PG_TRMNTN_DT > CURRENT_DATE GROUP BY A.PGM_DIM_KEY) ");
			sql.append("  and  MSRMNT_PRD_STRT_DT = ? ");
			sql.append(" 								GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM ");
			sql.append(" 					ON IPGSF.PGM_DIM_KEY = SC_PGM.PGM_DIM_KEY AND IPGSF.MSRMNT_PRD_STRT_DT = SC_PGM.MSRMNT_PRD_STRT_DT) ");
			//sql.append(" and (select max(ef.mnth_id)MAX_MON from IMPRV_PROV_GRP_SMRY_FACT ef join PGM_DIM pd on ef.pgm_dim_key = pd.pgm_dim_key where pd.pgm_id = ? ) <=  INT(TO_CHAR(ef.msrmnt_prd_strt_dt + 15 months, 'YYYYMM')) " );
			sql.append(" and (select max(ef.mnth_id)MAX_MON from ERNCNTR_FACT ef join PGM_DIM pd on ef.pgm_dim_key = pd.pgm_dim_key where pd.pgm_id = ? ) <=  INT(TO_CHAR(ef.msrmnt_prd_strt_dt + 15 months, 'YYYYMM')) ");
		}

		sql.append(
			" group by smhd.CMPST_NM ,smhd.CMPST_DEFN_ID, smhd.CMPST_TYPE_DESC,ipgsf.rdstrbtd_erncntr_pct,ipgsf.rdstrbtd_ssav_upsd_dstrbtn_pct,smhd.msr_dim_key, ef.qlty_gate_thrshld_pct, ef.qlty_scor_pct, ef.qlty_gate_ind,epgsf.MDCR_TOTL_ERCNTR_PCT ,epgsf.MDCR_TIER_2_IND ")
			//.append(" order by smhd.CMPST_NM")
			.append(") group by cmpst_nm,cmpst_defn_id, cmpst_type_desc, qlty_gate_thrshld_pct, qlty_scor_pct, qlty_gate_ind,MDCR_TOTL_ERCNTR_PCT,MDCR_TIER_2_IND ");

		return sql;
	}

	public StringBuilder createQueryForUtilization(PCMSRequest request) {

		StringBuilder sql = new StringBuilder()
			.append("select cmpst_nm, cmpst_defn_id, cmpst_type_desc, sum(erncntr) as erncntr, sum(ssav) as ssav,qlty_gate_thrshld_pct, qlty_scor_pct,qlty_gate_ind,MDCR_TOTL_ERCNTR_PCT,MDCR_TIER_2_IND from ( ")
			.append("select ")
			.append(" smhd.cmpst_nm, ")
			.append(" smhd.cmpst_defn_id, ")
			.append(" smhd.cmpst_type_desc, ")
			.append(" ef.rdstrbtd_erncntr_pct as erncntr, ")
			//.append(" ef.rdstrbtd_ssav_upsd_dstrbtn_pct as ssav, ")//changed for PCMSP-52
			.append(" ef.SSAV_UPSD_DSTRBTN_PCT as ssav, ")
			.append(" ef.qlty_gate_thrshld_pct, ")
			.append(" ef.qlty_scor_pct, ")
			.append(" ef.qlty_gate_ind, ")
			.append(" smhd.sub_cmpst_nm, ")
			.append(" smhd.msr_dim_key, ")
			.append(" epgsf.MDCR_TOTL_ERCNTR_PCT ,epgsf.MDCR_TIER_2_IND ")  //PCMSP-11254
			.append(" from ")
			.append(" erncntr_fact ef, ")
			.append(" scrcrd_msr_hrchy_dim smhd, ")
			.append(" pgm_dim pgm, ")
			.append(" prov_grp_dim pg, ")
			.append(" scrcrd_pgm_msr_hrchy_fact spmhf, ")
			.append(" ERNCNTR_PROV_GRP_SMRY_FACT epgsf ")  //PCMSP-11254
			//.append(" prov_grp_pgm_lob_fact pgplf, ")      //added as a part of R1.3
			//.append(" lob_dim ld ")						   //added as a part of R1.3
			.append(" where ")
			.append(" ef.pgm_dim_key=pgm.pgm_dim_key and ")
			.append(" ef.pgm_dim_key=spmhf.pgm_dim_key  and ")
			.append(" ef.trnch_defn_dim_key = spmhf.trnch_defn_dim_key and ")
			.append(" ef.mnth_id = spmhf.mnth_id and ")
			.append(" ef.prov_grp_dim_key = pg.prov_grp_dim_key and ")
			.append(" ef.msrmnt_prd_strt_dt = spmhf.msrmnt_prd_strt_dt and ")//Added as per Dasmeet's email.
			.append(" spmhf.scrcrd_msr_hrchy_dim_key=smhd.scrcrd_msr_hrchy_dim_key and ")
			.append(" epgsf.prov_grp_dim_key = ef.prov_grp_dim_key and epgsf.pgm_dim_key = ef.pgm_dim_key and ") //PCMSP-11254
			.append(" epgsf.mnth_id = ef.mnth_id and   epgsf.msrmnt_prd_strt_dt = ef.msrmnt_prd_strt_dt and ")
			//.append(" ef.prov_grp_dim_key = pgplf.prov_grp_dim_key and ") //added as a part of R1.3
			//.append(" ef.pgm_dim_key= pgplf.pgm_dim_key and ")             //added as a part of R1.3
			//.append(" ld.lob_dim_key = pgplf.lob_dim_key and ")		  //added as a part of R1.3
			.append(" pgm.pgm_id = ? and ")
			.append(" ef.msrmnt_prd_strt_dt = ? and ")
			.append(" pg.prov_grp_id = ? and ")
			.append(" smhd.cmpst_type_desc = 'Utilization' and ")
			.append(" spmhf.pgm_lob_type_cd = ? ");

		if (null != Constants.getQuarterName(request.getMeasurementInterval())) {
			if ("1".equalsIgnoreCase(request.getMeasurementInterval())) {
				sql.append(" AND ef.BSLN_SCRCRD_IND = 'Y' ");
			}
			else {
				sql.append(" AND ef.QTR_ID = '" + Constants.getQuarterName(request.getMeasurementInterval()) + "' ");
			}
		}
		else {

			// Changing the implementation of the month id clause based on the query snippet suggested by vishwa
			//Commenting the code earlier
			//sql.append(" AND ef.MNTH_ID = (Select max(ef.mnth_id) from ERNCNTR_FACT ef) ");
			sql.append(" AND EF.MNTH_ID = (SELECT MAX(EF.MNTH_ID) ");
			sql.append(" 					FROM ERNCNTR_FACT EF  ");
			sql.append(" 					INNER JOIN (Select PGM_DIM_KEY, MSRMNT_PRD_STRT_DT ");
			sql.append(" 								FROM SCRCRD_PGM_MSR_HRCHY_FACT ");
			//sql.append(" 		WHERE PGM_DIM_KEY = (SELECT PGM_DIM_KEY FROM PROV_GRP_PGM_LOB_FACT WHERE PGM_ID = ? and PGM_PG_TRMNTN_DT > CURRENT_DATE GROUP BY PGM_DIM_KEY ) ");
			sql.append(" 		WHERE PGM_DIM_KEY = (SELECT PGM_DIM_KEY FROM PROV_GRP_PGM_LOB_FACT A ");
			sql.append(" 		inner join   PROV_GRP_DIM B ON A.PROV_GRP_DIM_KEY=B.PROV_GRP_DIM_KEY and  B.PROV_GRP_ID = ?");
			sql.append("		WHERE A.PGM_ID = ? and A.PGM_PG_TRMNTN_DT > CURRENT_DATE GROUP BY A.PGM_DIM_KEY) ");
			sql.append("  and  MSRMNT_PRD_STRT_DT = ? ");
			sql.append(" 								GROUP BY PGM_DIM_KEY, MSRMNT_PRD_STRT_DT) SC_PGM ");
			sql.append(" 					ON EF.PGM_DIM_KEY = SC_PGM.PGM_DIM_KEY AND EF.MSRMNT_PRD_STRT_DT = SC_PGM.MSRMNT_PRD_STRT_DT) ");
			sql.append(" and (select max(ef.mnth_id)MAX_MON from ERNCNTR_FACT ef join PGM_DIM pd on ef.pgm_dim_key = pd.pgm_dim_key where pd.pgm_id = ? ) <=  INT(TO_CHAR(ef.msrmnt_prd_strt_dt + 15 months, 'YYYYMM')) ");

		}

		sql.append(
			" group by smhd.CMPST_NM ,smhd.CMPST_DEFN_ID, smhd.CMPST_TYPE_DESC,ef.rdstrbtd_erncntr_pct,/*ef.rdstrbtd_ssav_upsd_dstrbtn_pct,*/ef.SSAV_UPSD_DSTRBTN_PCT,smhd.sub_cmpst_nm, smhd.msr_dim_key, ef.qlty_gate_thrshld_pct, ef.qlty_scor_pct, ef.qlty_gate_ind,epgsf.MDCR_TOTL_ERCNTR_PCT ,epgsf.MDCR_TIER_2_IND ")
			.append(" order by smhd.CMPST_NM")
			.append(") group by cmpst_nm,cmpst_defn_id, cmpst_type_desc, qlty_gate_thrshld_pct, qlty_scor_pct, qlty_gate_ind,MDCR_TOTL_ERCNTR_PCT,MDCR_TIER_2_IND ");

		return sql;
	}

	@Override
	public boolean read(Dto o) throws Exception {

		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {


	}

	@Override
	public void update(Dto o) throws Exception {


	}

	@Override
	public void delete(Dto o) throws Exception {


	}

}
