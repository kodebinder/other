package com.wellpoint.pc2dash.data.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wellpoint.pc2dash.dto.drillDown.DrillDownChart;

public class GeneralCharts extends Quality {

	protected List<DrillDownChart> convertSelectedRowsToObjects(ResultSet rs) throws SQLException {
		List<DrillDownChart> list = new ArrayList<DrillDownChart>();

		while (rs.next()) {
			DrillDownChart item = new DrillDownChart();

			item.setMeasureID(rs.getString("msr_id")); // instead of cf.msr_dim_key
			item.setMeasureParent(rs.getString("sub_cmpst_nm"));
			item.setMeasureParentID(rs.getString("sub_cmpst_defn_id"));
			item.setMeasureName(rs.getString("msr_dsply_nm"));
			item.setMeasureNonCompliant(rs.getInt("msr_non_cmplnt"));
			item.setMeasureCompliant(rs.getInt("msr_cmplnt"));

			list.add(item);
		}

		return list;
	}

}
