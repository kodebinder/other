package com.wellpoint.pc2dash.action.savedFilters;

import java.util.HashMap;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.service.savedFilters.SavedFiltersImpl;
import com.wellpoint.pc2dash.util.ErrorProperties;


public class AddSavedFilterAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		SavedFiltersRequest request = (SavedFiltersRequest) actionRequest;
		ActionResponse response = new SavedFiltersResponse();
		ErrorProperties err = ErrorProperties.getInstance();

		SavedFiltersImpl service = new SavedFiltersImpl();

		try {

			String id = service.insertFilter(request);

			if (StringUtils.isBlank(id)) {

				response.setMessage(err.getProperty("successNoData"));
			}
			else {

				response.setMessage(err.getProperty("successful"));
				response.setTotal(1); // Can only insert 1 at a time

				HashMap<String, String> data = new HashMap<String, String>();
				data.put("id", id);
				response.setData(data);
			}

			response.setSuccess(true);
			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}
}
