package com.wellpoint.pc2dash.action.costOpportunity;

import com.wellpoint.pc2dash.data.dto.PopulationManagementRequest;

public class GetLabProviderCountPopupRequest extends PopulationManagementRequest {

	//private String labName; moved to PopulationManagementRequest
	private String networkStatus;
	private String labTaxId;

	public String getNetworkStatus() {
		return networkStatus;
	}

	public void setNetworkStatus(String networkStatus) {
		this.networkStatus = networkStatus;
	}

	public String getLabTaxId() {
		return labTaxId;
	}

	public void setLabTaxId(String labTaxId) {
		this.labTaxId = labTaxId;
	}
	
	

	/* moved to PopulationManagementRequest
	  public String getLabName() {
		return labName;
	}

	public void setLabName(String labName) {
		this.labName = labName;
	}*/

}
