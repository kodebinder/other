package com.wellpoint.pc2dash.action.quality;

import java.util.Collection;
import java.util.Vector;

public class GetQualityMeasuresResponse extends GetQualityResponse {

	private String text;
	private Collection<Object> children = new Vector<Object>();

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Collection<Object> getChildren() {
		return children;
	}

	public void setChildren(Collection<Object> children) {
		this.children = children;
	}

}
