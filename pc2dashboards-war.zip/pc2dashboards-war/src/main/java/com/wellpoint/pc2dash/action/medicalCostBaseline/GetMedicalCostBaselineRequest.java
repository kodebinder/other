package com.wellpoint.pc2dash.action.medicalCostBaseline;

import com.wellpoint.pc2dash.action.medicalCostServiceDetails.GetMedicalCostServiceDetailsRequest;

public class GetMedicalCostBaselineRequest extends GetMedicalCostServiceDetailsRequest {
	
	

}
