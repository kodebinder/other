package com.wellpoint.pc2dash.action.quality;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.data.dao.CommercialImprovementQualityCharts;
import com.wellpoint.pc2dash.data.dao.MedicaidImprovementQualityCharts;
import com.wellpoint.pc2dash.data.dao.MedicaidQualityCharts;
import com.wellpoint.pc2dash.data.dao.QualityCharts;
import com.wellpoint.pc2dash.dto.drillDown.DrillDownChart;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.DateUtil;
import com.wellpoint.pc2dash.util.StringUtil;

public class GetQualityChartAction extends GetQualityAction {

	ActionResponse response = new GetQualityResponse();

	@Override
	public ActionResponse process(ActionRequest actionRequest) {
		GetQualityChartRequest request = (GetQualityChartRequest) actionRequest;
		List<String> filteredProvGrpList = new ArrayList<String>();
		List<DrillDownChart> resultList = new ArrayList<DrillDownChart>();

		try {
			String measStartDate = request.getMeasurementPeriodStartDt();
			boolean isMPGreaterThanOrEqual01012018 = DateUtil.dateComparator(measStartDate, Constants.IND_MTRC_STRT_DT);
			request = (GetQualityChartRequest) cleanRequest(request);

			if (StringUtil.isJson(request)) {

				//				//PCMSRequest request = getDataMap((GetDrillDownRequest) actionRequest);
				//Kill switch check on Provider groups
				if (null != request) {
					filteredProvGrpList = filterProvGrpsByKillSwitch(request);
				}

				//Clinical access check on provider groups
				if (null != request && null != filteredProvGrpList && filteredProvGrpList.size() > 0) {
					filteredProvGrpList = filterProvGrpsByClinicalInd(request, filteredProvGrpList);
				}


				if (null != filteredProvGrpList && !filteredProvGrpList.isEmpty()) {
					request.setProvGrpIds(StringUtils.join(filteredProvGrpList, ','));
					request.setGrpInd(Constants.GRP_IND_N);
					if (!request.getCompositeType().equalsIgnoreCase(Constants.IMPCOMPOSITETYPE)) {
						if (!request.getProgramLobTypeCd().equalsIgnoreCase(Constants.MEDICAID)) {
							QualityCharts dao1 = new QualityCharts();
							resultList.addAll(dao1.getQualityChart(request));
						}
						if (request.getProgramLobTypeCd().equalsIgnoreCase(Constants.MEDICAID)) {
							MedicaidQualityCharts dao2 = new MedicaidQualityCharts();
							resultList.addAll(dao2.getMedicaidQualityChart(request));
						}
					}
					if (request.getCompositeType().equalsIgnoreCase(Constants.IMPCOMPOSITETYPE)) {
                        if ((request.getProgramLobTypeCd().equalsIgnoreCase(Constants.MEDICARE) || request.getProgramLobTypeCd().equalsIgnoreCase(Constants.FPCC_MEDICARE)) && isMPGreaterThanOrEqual01012018) {
                               QualityCharts dao1 = new QualityCharts();
                               resultList.addAll(dao1.getQualityChart(request));
                        }
                        else if (request.getProgramLobTypeCd().equalsIgnoreCase(Constants.COMMERCIAL) || request.getProgramLobTypeCd().startsWith(Constants.FPCC_PGM_TYPE)) {
                               CommercialImprovementQualityCharts dao3 = new CommercialImprovementQualityCharts();
                               resultList.addAll(dao3.getCommercialImprovementQualityChart(request));
                        }
                        else if (request.getProgramLobTypeCd().equalsIgnoreCase(Constants.MEDICAID)) {
                               MedicaidImprovementQualityCharts dao3 = new MedicaidImprovementQualityCharts();
                               resultList.addAll(dao3.getMedicaidImprovementQualityChart(request));
                        }
                 }

				}

				if (null == resultList || (null != resultList && resultList.isEmpty())) {
					response.setMessage(StringUtil.buildMessage(resultList.isEmpty()));
				}
				else {

					// PCMSP-1276: Remove duplicates
					Set<DrillDownChart> resultListNoDuplicates = new HashSet<DrillDownChart>(resultList);

					response.setData(resultListNoDuplicates);
					response.setTotal(resultListNoDuplicates.size()); // calculates total without another query
					response.setMessage(StringUtil.buildMessage(resultListNoDuplicates.isEmpty()));
				}

				response.setSuccess(true); // based on GetCareOpportunitiesPatientAction.process(), MW never returns "false"
			}
			// TODO else if for getDest() of xls?

		}
		catch (Exception e) {
			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(e, response);
		}

		return response;
	}

}
