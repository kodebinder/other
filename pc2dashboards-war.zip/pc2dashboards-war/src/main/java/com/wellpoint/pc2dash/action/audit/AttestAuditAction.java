package com.wellpoint.pc2dash.action.audit;

import java.util.HashMap;
import java.util.Map;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.data.dto.AuditEntry;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;


public class AttestAuditAction extends Action {

	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(AttestAuditAction.class);

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		AuditRequest request = (AuditRequest) actionRequest;
		AuditResponse response = new AuditResponse();

		try {

			if (!request.isValid()) {
				throw new Exception("Missing required fields.");
			}

			AuditEntry ae = new AuditEntry();
			ae.setUserId(request.getUserId());
			ae.setSessionId(request.getSessionId());
			ae.setPatientId(request.getPatientId());
			ae.setAccessType(request.getAccessType());

			Map<String, Boolean> result = new HashMap<String, Boolean>();
			result.put("attested", ae.read());

			response.setData(result);
			response.setSuccess(true);
		}
		catch (Exception e) {

			logger.error("Unable to retrieve audit entry.", e);

			response.setMessage("Unable to audit access.");
			response.setSuccess(false);
		}

		return response;
	}
}
