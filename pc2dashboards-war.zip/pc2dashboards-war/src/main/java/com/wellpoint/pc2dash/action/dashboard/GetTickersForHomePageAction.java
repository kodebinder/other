package com.wellpoint.pc2dash.action.dashboard;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wellpoint.pc2dash.action.base.Action;
import com.wellpoint.pc2dash.action.base.ActionRequest;
import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.dashboard.HomePageTickersBean;
import com.wellpoint.pc2dash.dto.dashboard.HomePageTickersJson;
import com.wellpoint.pc2dash.exception.Pc2ExceptionGenerator;
import com.wellpoint.pc2dash.service.dashboard.HomePageTickersServiceImpl;
import com.wellpoint.pc2dash.util.ErrorProperties;


public class GetTickersForHomePageAction extends Action {

	@Override
	public ActionResponse process(ActionRequest actionRequest) {

		HomePageTickersServiceImpl srvc = new HomePageTickersServiceImpl();
		GetTickersForHomePageActionRequest request = (GetTickersForHomePageActionRequest) actionRequest;
		ActionResponse response = new ActionResponse();
		ErrorProperties err = ErrorProperties.getInstance();

		List<HomePageTickersJson> results = new ArrayList<HomePageTickersJson>();
		List<HomePageTickersBean> tickers = null;
		List<String> grps = null;

		try {

			//			//PCMSRequest request = getDataMap(request);

			// preserve dataMap logic
			if (null != request) {

				removeLobPgmPrefixes(request);
				
				if (StringUtils.isNotBlank(request.getCmpId())) {
					grps = filterProvGrpsByKillSwitch(request);
				}

				if (null != grps && grps.size() > 0) {

					grps = filterProvGrpsByClincalFinancialInd(request, grps);
					request.setProvGrpIds(StringUtils.join(grps, ','));
				}

				if (null != grps && !grps.isEmpty()) {

					tickers = srvc.getData(request);
					results = srvc.getBeanList(tickers);
				}
			}

			response.setData(results);
			response.setTotal(srvc.getRowCount());
			response.setSuccess(true);

			if (null == results || (null != results && results.isEmpty())) {
				response.setMessage(err.getProperty("successNoData"));
			}
			else {
				response.setMessage(err.getProperty("successful"));
			}

			return response;
		}
		catch (Exception pe) {

			Pc2ExceptionGenerator pce = new Pc2ExceptionGenerator();
			return pce.checkException(pe, response);
		}
	}

	//	public Map<String, String> getDataMap(GetTickersForHomePageActionRequest request) throws JsonException{
	//
	//		//PCMSRequest request = new HashMap<String, String>();
	//		request.put("provGrpId",request.getProvGrpId());
	//		//request.put("sessionId", request.getSessionId());
	//		//request.put("entitlementId", request.getEntitlementId());
	//		request.put("grpInd", request.getGrpInd());
	//		//request.setCmpId(request.getCmpId());
	//		//request.setProvGrpIds(request.getProvGrpIds());
	//		request.put(Constants.USER_ACS_INFO_JSON, request.getUserAcsInfoJson());
	//		request.put("pslId", request.getPslIds());
	//        request.put("lobId", JSONUtils.removeFirstOccurenceOfCharsFromJsonString(request.getLobIds(), Constants.LOB_ID_PREFIX));
	//        request.put("programIds", JSONUtils.removeFirstOccurenceOfCharsFromJsonString(request.getProgramIds(), Constants.PRGM_ID_PREFIX));
	//        request.put("orgDimKeys", request.getOrgDimKeys());
	//        request.put("provDimKeys", request.getProvDimKeys());
	//
	//        return request;
	//	}
}
