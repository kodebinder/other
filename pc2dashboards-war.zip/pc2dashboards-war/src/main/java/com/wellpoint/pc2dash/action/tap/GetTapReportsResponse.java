package com.wellpoint.pc2dash.action.tap;

import com.wellpoint.pc2dash.action.base.ActionResponse;

public class GetTapReportsResponse extends ActionResponse {

}
