package com.wellpoint.pc2dash.action.utilization;

import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.action.base.ActionResponse;
import com.wellpoint.pc2dash.dto.patient.TreeHierarchy;

public class GetBrandFormularyDrugClassesResponse extends ActionResponse {

	private Collection<TreeHierarchy> children = new ArrayList<TreeHierarchy>();
	private String text = ".";

	public Collection<TreeHierarchy> getChildren() {
		return children;
	}

	public void setChildren(Collection<TreeHierarchy> children) {
		this.children = children;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

}
