package com.wellpoint.pc2dash.data.dao;

import java.util.ArrayList;
import java.util.Collection;

import com.wellpoint.pc2dash.action.tooltip.GetPatientDetailRequest;
import com.wellpoint.pc2dash.data.Database;
import com.wellpoint.pc2dash.data.Dto;
import com.wellpoint.pc2dash.dto.utilization.BrandFormularyDrugDetails;
import com.wellpoint.pc2dash.logging.Pc2DashLogger;
import com.wellpoint.pc2dash.util.Constants;
import com.wellpoint.pc2dash.util.StringUtil;

public class BrandFormularyDrugDetailsFacts extends AbstractDao {


	private static final Pc2DashLogger logger = Pc2DashLogger.getLogger(BrandFormularyDrugDetailsFacts.class);

	public Collection<BrandFormularyDrugDetails> getBrandFormularyDrugDetails(GetPatientDetailRequest request) throws Exception {

		Collection<BrandFormularyDrugDetails> result = new ArrayList<BrandFormularyDrugDetails>();

		StringBuilder sql = new StringBuilder()
			.append(" select distinct ")
			.append(" pcf.CLM_ADJSTMNT_Key, pcf.RX_FILLED_DT,pcf.LBL_NM,udf.CNDTN_CTGRY_NM,pcf.DAYS_SPLY_NBR, ")
			.append(" pcf.PRSCRBR_IP_DIM_KEY,pcf.APRVD_CPAY_AMT,pcf.DSPNSD_BRND_GNRC_IND,ip.ip_frst_nm,ip.ip_last_nm, ip.NPI_TYPE_CD, ")
			.append("  CD.CD_VAL_NM, PCF.FRMLRY_NM, COALESCE(X.DRUG_CLS_NM,'OTHERS') AS DRUG_CLS_NM ")
			.append(" from CMPLNC_UM_DTL_FACT udf ")
			.append(" JOIN CLM_PHRMCY_UM_XREF xref ON xref.CMPLNC_UM_DTL_FACT_KEY = udf.CMPLNC_UM_DTL_FACT_KEY and udf.MSTR_CNSMR_DIM_KEY = xref.MSTR_CNSMR_DIM_KEY ")
			.append(" JOIN PHRMCY_CLM_FACT PCF ON (PCF.PHRMCY_CLM_FACT_KEY = xref.PHRMCY_CLM_FACT_KEY) ")
			.append(" JOIN MSR_DIM MD ON (MD.MSR_DIM_KEY = udf.MSR_DIM_KEY) ")
			.append(" left join IP_DIM AS IP ON (IP.IP_DIM_KEY = PCF.PRSCRBR_IP_DIM_KEY) ")
			.append(" JOIN CD_DIM AS CD ON (PCF.THRPTC_CLS_CD_DIM_KEY=CD.CD_DIM_KEY) ")
			.append(" left JOIN SCRCRD_FRMLRY_DRUG_CLS_XWALK AS X ON (SUBSTR(PCF.GPI_04_CLS_CD, 1, 4) = X.GPI_04_CLS_CD) ")
			.append(" where ")
			.append(" udf.MSTR_CNSMR_DIM_KEY = ? ")
			.append("	and pcf.clm_line_srvc_strt_dt >= (current_date - day(current_date) day +1 day) - 15 MONTHS ");
		if (null != request.getMeasureName() && request.getMeasureName().equalsIgnoreCase(Constants.FRMLY)) {
			if (StringUtil.isNotBlankOrFalse(request.getPhrmcyMsrIds())) {
				sql.append(" and md.msr_id in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getPhrmcyMsrIds())
					+ ") ");
			}
		}

		//Vignesh- Changes to resolve duplicate records in the FRMLRY drug details pop-up		
		if (null != request && null != request.getMeasurementPeriodStartDt()) {
			sql.append(" and udf.msrmnt_prd_strt_dt = ? ");
		}

		/*
		if(StringUtil.isNotBlankOrFalse(request.getPhrmcyFullNms())){
			sql.append( " and trim(PCF.BRND_NM) in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getPhrmcyFullNms())
					+ ") ");
		}*/
		//PCMSP-9481 STARTS 2
		sql.append(" and PCF.FRMRLY_CD = 'NONF' ") //Req 6. Must exclude HIX member population from the scorecard formulary metrics.
			.append(" and PCF.DSPNSD_BRND_GNRC_IND = 'B' ");
		//PCMSP-9481 ENDS 2
		sql.append(" order by ")
			.append(" pcf.RX_FILLED_DT desc ");



		try {

			cn = Database.getConnection(Constants.RPT_DATASOURCE);
			int i = 0;
			prepareStatement(logger, sql.toString());
			ps.setString(++i, request.getMemberKey());

			if (null != request.getMeasureName() && request.getMeasureName().equalsIgnoreCase(Constants.FRMLY)) {
				if (StringUtil.isNotBlankOrFalse(request.getPhrmcyMsrIds())) {
					String[] array = request.getPhrmcyMsrIds().split(",");
					for (String item : array) {
						ps.setString(++i, item.trim());
					}
				}
			}

			//Vignesh- Changes to resolve duplicate records in the FRMLRY drug details pop-up		
			if (null != request && null != request.getMeasurementPeriodStartDt()) {
				ps.setString(++i, request.getMeasurementPeriodStartDt());
			}
			/*
			if (StringUtil.isNotBlankOrFalse(request.getPhrmcyFullNms())) {
				String[] array = request.getPhrmcyFullNms().split(",");
				for (String item : array) {
					ps.setString(++i, item.trim());
				}
			}*/

			executeQuery(logger, sql.toString());

			while (rs.next()) {

				BrandFormularyDrugDetails r = new BrandFormularyDrugDetails();

				//1. FILL_DATE
				if (rs.getDate("RX_FILLED_DT") != null) {
					r.setFillDate(getDate(rs, "RX_FILLED_DT"));
				}
				//2. DRUG_NAME
				if (rs.getString("LBL_NM") != null) {
					r.setDrugName(getString(rs, "LBL_NM"));
				}
				//3. THERAPEUTIC_CLASS
				if (rs.getString("CD_VAL_NM") != null) {
					r.setTherapeuticClass(getString(rs, "CD_VAL_NM"));
				}
				//4. DRUG_CLASS
				if (rs.getString("DRUG_CLS_NM") != null) {
					r.setDrugClass(getString(rs, "DRUG_CLS_NM"));
				}
				//5. DAYS_SUPPLY
				if (rs.getBigDecimal("DAYS_SPLY_NBR") != null) {
					Integer ds = rs.getBigDecimal("DAYS_SPLY_NBR").intValue();
					r.setDaysSupply(ds.toString());
				}

				//6. PRESCRIBING PROVIDER 1
				String firstName = getString(rs, "ip_frst_nm");
				String lastName = getString(rs, "ip_last_nm");
				String npiTypeCd = getString(rs, "NPI_TYPE_CD") != null ? rs.getString("NPI_TYPE_CD") : "1";
				if (firstName == null) {
					firstName = "*";
				}
				if (lastName == null) {
					lastName = "*";
				}

				//6. PRESCRIBING PROVIDER 2
				if (!Constants.STAR.equalsIgnoreCase(lastName) && !Constants.STAR.equalsIgnoreCase(firstName)) {
					r.setPrescribingProviderName(lastName + ", " + firstName);
				}
				else if (!Constants.STAR.equalsIgnoreCase(lastName)) {
					r.setPrescribingProviderName(lastName);
				}
				else {
					r.setPrescribingProviderName(Constants.UNK);
				}
				
				if(Constants.UNK.equalsIgnoreCase(lastName) && Constants.UNK.equalsIgnoreCase(firstName))
					r.setPrescribingProviderName(Constants.UNK);

				//7. PATIENT COST SHARE
				if (rs.getString("APRVD_CPAY_AMT") != null) {
					r.setPatientCost(rs.getString("APRVD_CPAY_AMT"));
				}
				if (rs.getString("DSPNSD_BRND_GNRC_IND") != null) {
					r.setGenericInd(rs.getString("DSPNSD_BRND_GNRC_IND").trim().equalsIgnoreCase("G") ? 1 : 0);
				}


				//8. FORMULARY NAME				
				if (rs.getString("FRMLRY_NM") != null) {
					r.setFormularyName(getString(rs, "FRMLRY_NM"));
				}

				result.add(r);
			}
		}
		catch (Exception e) {

			throw new Exception("Unable to get BrandFormularyDrugDetailsFacts (" + request.getEntitlementId() + ", " + request.getMemberKey() + ").", e);
		}
		finally {

			close();
		}

		return result;
	}

	@Override
	public boolean read(Dto o) throws Exception {

		return false;
	}

	@Override
	public void insert(Dto o) throws Exception {


	}

	@Override
	public void update(Dto o) throws Exception {


	}

	@Override
	public void delete(Dto o) throws Exception {


	}

}
